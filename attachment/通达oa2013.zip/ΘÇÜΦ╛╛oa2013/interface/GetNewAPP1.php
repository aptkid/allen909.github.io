<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
include_once( "../inc/conn.php" );
include_once( "../inc/utility_sms1.php" );
include_once( "../inc/utility.php" );
include_once( "../inc/utility_file.php" );
include_once( "../inc/utility_all.php" );
include_once( "inc/header.inc.php" );
echo "\r\n\r\n\r\n\r\n<body class=\"bodycolor\">\r\n";
$query0 = "select * from CONNECT_CONFIG  where MEMBER_NAME='".$APP_UNIT."'";
$cursor0 = exequery( ( ), $query0 );
if ( $ROW0 = mysql_fetch_array( $cursor0 ) )
{
    $query = "insert into LOGIN_APP(APP_UNIT,APP_USER_ID,APP_TIME,APP_USERS,APP_USERS_NAME,STATE) values('".$APP_UNIT."','{$APP_SUBMITER}','{$APP_TIME}','{$APP_USER_ID}','{$APP_USER_NAME}',0)";
    exequery( ( ), $query );
    $ID = mysql_insert_id( );
    $REMIND_URL = "1:uconnect/app_manage/pass.php?ID=".$ID;
    $SMS_CONTENT = _( "�봦������" ).$APP_UNIT._( "��Զ�̷�������" );
    send_sms( $SEND_TIME, "admin", "admin", 69, $SMS_CONTENT, $REMIND_URL );
    message( "", _( "�������ύ��" ) );
}
else
{
    message( "", _( "���ڵ�λ�������ܲ���¼��һ�£�����ϵ�ܲ���" ) );
}
button_back( );
echo "</body>\r\n</html>";
?>
