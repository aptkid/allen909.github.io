<?php
function ext_login_check( $USERNAME )
{
    include_once( "inc/utility_all.php" );
    $USER_IP = get_client_ip( );
    $PARA_ARRAY = get_sys_para( "SEC_PASS_FLAG,SEC_PASS_TIME,SEC_RETRY_BAN,SEC_RETRY_TIMES,SEC_BAN_TIME,SEC_USER_MEM,SEC_KEY_USER,LOGIN_KEY,SEC_ON_STATUS,SEC_INIT_PASS" );
    while ( list( $PARA_NAME, $PARA_VALUE ) = each( &$PARA_ARRAY ) )
    {
        $$PARA_NAME = $PARA_VALUE;
    }
    $query = "SELECT * from USER where USER_ID='".$USERNAME."' or BYNAME='{$USERNAME}'";
    $cursor = exequery( ( ), $query );
    if ( $ROW = mysql_fetch_array( $cursor ) )
    {
        add_log( 10, "USERNAME=".$USERNAME, $USERNAME );
        return _( "�û������������ע���Сд!" );
    }
    $UID = $ROW['UID'];
    $USER_ID = $ROW['USER_ID'];
    $BYNAME = $ROW['BYNAME'];
    $USER_NAME = $ROW['USER_NAME'];
    $BIND_IP = $ROW['BIND_IP'];
    $USEING_KEY = $ROW['USEING_KEY'];
    $ON_STATUS = $ROW['ON_STATUS'];
    if ( !( $USERNAME != $USER_ID ) || $USERNAME != $BYNAME || $USERNAME == "" )
    {
        add_log( 10, "USERNAME=".$USERNAME, $USERNAME );
        return _( "�û������������ע���Сд3!" );
    }
    $NOT_LOGIN = $ROW['NOT_LOGIN'];
    if ( check_ip( $USER_IP, "0", $USER_ID ) )
    {
        add_log( 9, "USERNAME=".$USERNAME, $USERNAME );
        return sprintf( _( "����Ȩ�޴Ӹ�IP(%s)��¼!" ), $USER_IP );
    }
    if ( $BIND_IP != "" )
    {
        $NET_MATCH = FALSE;
        $IP_ARRAY = explode( ",", $BIND_IP );
        foreach ( $IP_ARRAY as $NETWORK )
        {
            if ( netmatch( $NETWORK, $USER_IP ) )
            {
                $NET_MATCH = TRUE;
                break;
            }
        }
        if ( $NET_MATCH )
        {
            return sprintf( _( "�û� %s �������Ӹ�IP(%s)��¼��" ), $USERNAME, $USER_IP );
        }
    }
    $LOGIN_USER_PRIV = $ROW['USER_PRIV'];
    $USER_PRIV_OTHER = $ROW['USER_PRIV_OTHER'];
    $LOGIN_AVATAR = $ROW['AVATAR'];
    $LOGIN_DEPT_ID = $ROW['DEPT_ID'];
    $LOGIN_DEPT_ID_OTHER = $ROW['DEPT_ID_OTHER'];
    $LAST_PASS_TIME = $ROW['LAST_PASS_TIME'];
    $LOGIN_THEME = $ROW['THEME'];
    $LOGIN_NOT_VIEW_USER = $ROW['NOT_VIEW_USER'];
    if ( $LOGIN_THEME == "" )
    {
        $LOGIN_THEME = "1";
    }
    if ( find_id( $USER_PRIV_OTHER, $LOGIN_USER_PRIV ) )
    {
        $USER_PRIV_OTHER .= $LOGIN_USER_PRIV.",";
    }
    $LOGIN_FUNC_STR = "";
    $query1 = "SELECT FUNC_ID_STR from USER_PRIV where find_in_set(USER_PRIV,'".$USER_PRIV_OTHER."')";
    $cursor1 = exequery( ( ), $query1 );
}
if ( $ROW = mysql_fetch_array( $cursor1 ) )
{
    $FUNC_STR = $ROW['FUNC_ID_STR'];
    $MY_ARRAY = explode( ",", $FUNC_STR );
    $ARRAY_COUNT = sizeof( $MY_ARRAY );
    if ( $MY_ARRAY[$ARRAY_COUNT - 1] == "" )
    {
        --$ARRAY_COUNT;
    }
    $I = 0;
    do
    {
        for ( ; $I < $ARRAY_COUNT; do
 {
 ++$I, } while ( 1 ) )
        {
            if ( find_id( $LOGIN_FUNC_STR, $MY_ARRAY[$I] ) )
            {
                $LOGIN_FUNC_STR .= $MY_ARRAY[$I].",";
            }
        } while ( 1 );
    }
    $query = "SELECT * from INTERFACE";
    $cursor1 = exequery( ( ), $query );
    if ( $ROW = mysql_fetch_array( $cursor1 ) )
    {
        $THEME_SELECT = $ROW['THEME_SELECT'];
        $THEME = $ROW['THEME'];
        if ( $THEME_SELECT == "0" )
        {
            $LOGIN_THEME = $THEME;
        }
    }
    $LOGIN_UID = $UID;
    $LOGIN_USER_ID = $USER_ID;
    $LOGIN_BYNAME = $BYNAME;
    $LOGIN_USER_NAME = $USER_NAME;
    $LOGIN_ANOTHER = "0";
    $LOGIN_USER_PRIV_OTHER = $USER_PRIV_OTHER;
    $_SESSION['LOGIN_UID'] = $LOGIN_UID;
    $_SESSION['LOGIN_USER_ID'] = $LOGIN_USER_ID;
    $_SESSION['LOGIN_BYNAME'] = $LOGIN_BYNAME;
    $_SESSION['LOGIN_USER_NAME'] = $LOGIN_USER_NAME;
    $_SESSION['LOGIN_USER_PRIV'] = $LOGIN_USER_PRIV;
    $_SESSION['LOGIN_USER_PRIV_OTHER'] = $LOGIN_USER_PRIV_OTHER;
    $_SESSION['LOGIN_DEPT_ID'] = $LOGIN_DEPT_ID;
    $_SESSION['LOGIN_DEPT_ID_OTHER'] = $LOGIN_DEPT_ID_OTHER;
    $_SESSION['LOGIN_AVATAR'] = $LOGIN_AVATAR;
    $_SESSION['LOGIN_THEME'] = $LOGIN_THEME;
    $_SESSION['LOGIN_FUNC_STR'] = $LOGIN_FUNC_STR;
    $_SESSION['LOGIN_NOT_VIEW_USER'] = $LOGIN_NOT_VIEW_USER;
    $_SESSION['LOGIN_ANOTHER'] = $LOGIN_ANOTHER;
    update_my_online_status( 0 );
    clear_online_status( );
    if ( file_exists( MYOA_ATTACH_PATH."new_sms/".$LOGIN_UID.".sms" ) )
    {
        new_sms_remind( $LOGIN_UID, 0 );
    }
    if ( $SEC_ON_STATUS != "1" && $ON_STATUS != "1" )
    {
        $update_str .= ",ON_STATUS='1'";
    }
    $query = "update USER set LAST_VISIT_TIME='".date( "Y-m-d H:i:s" )."'".$update_str.( " where UID='".$LOGIN_UID."'" );
    exequery( ( ), $query );
    if ( $SEC_USER_MEM == 1 )
    {
        setcookie( "USER_NAME_COOKIE", $USERNAME, time( ) + 86400000 );
    }
    else
    {
        setcookie( "USER_NAME_COOKIE", "", time( ) + 86400000 );
    }
    setcookie( "OA_USER_ID", $LOGIN_USER_ID );
    setcookie( "SID_".$UID, dechex( crc32( session_id( ) ) ), time( ) + 86400000, "/" );
    add_log( 1, "", $LOGIN_USER_ID );
    affair_sms( );
    return "1";
}

include_once( "inc/session.php" );
if ( $OA_USER == "admin" )
{
    echo _( "���ʺ���Ȩ����" );
    exit( );
}
session_start( );
ob_start( );
if ( $LOGIN_USER_ID != $OA_USER )
{
    $result = ext_login_check( $OA_USER );
    if ( $result != "1" )
    {
        echo $result;
        exit( );
    }
}
header( "P3P: CP=\"CURa ADMa DEVa PSAo PSDo OUR BUS UNI PUR INT DEM STA PRE COM NAV OTC NOI DSP COR\"" );
header( "location: /general/" );
?>
