<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
include_once( "inc/conn.php" );
include_once( "inc/utility_all.php" );
include_once( "./inc.php" );
$PASSWORD = td_authcode( $PASSWORD, "DECODE", "607a93f847b659cd6fb597f13138b3df" );
$USERNAME = mb_convert_encoding( $USERNAME, MYOA_CHARSET, "utf-8" );
$PASSWORD = mb_convert_encoding( $PASSWORD, MYOA_CHARSET, "utf-8" );
$RESULT = login_check( $USERNAME, $PASSWORD );
if ( is_array( $RESULT ) )
{
    finish_exit( 1, "", $RESULT );
}
else
{
    finish_exit( 0, $RESULT );
}
ob_end_clean( );
echo json_encode( $RESULT );
?>
