<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
$SYNC_DATA['calendar'][] = "drop table if exists calendar;\r\n                            drop table if exists affair;\r\n\t\t\t\t\t\t\tdrop table if exists task";
$SYNC_DATA['calendar'][] = "create table if not exists calendar( \r\n  CAL_ID integer(11) NOT NULL PRIMARY KEY,  \r\n  USER_ID varchar(20) NOT NULL,\r\n  CAL_TIME integer(10)  NOT NULL,\r\n  END_TIME integer(10)  NOT NULL,\r\n  CAL_TYPE char(1) NOT NULL ,\r\n  CAL_LEVEL char(1) NOT NULL ,\r\n  CONTENT text NOT NULL,\r\n  MANAGER_ID varchar(20),\r\n  OVER_STATUS varchar(20) NOT NULL ,\r\n  BEFORE_REMAIND varchar(20) NOT NULL,\r\n  ADD_TIME datetime,\r\n  OWNER text NOT NULL,\r\n  TAKER text NOT NULL);\r\n  \r\ncreate table if not exists affair (\r\n  AFF_ID int(11) NOT NULL PRIMARY KEY,\r\n  USER_ID varchar(20) NOT NULL,\r\n  BEGIN_TIME int(10)  NOT NULL,\r\n  END_TIME int(10)  NOT NULL,\r\n  AFF_TYPE char(1) NOT NULL,\r\n  REMIND_DATE varchar(200) NOT NULL,\r\n  REMIND_TIME time NOT NULL,\r\n  CONTENT text NOT NULL,\r\n  LAST_REMIND date,\r\n  SMS_REMIND char(1) NOT NULL,\r\n  SMS2_REMIND varchar(2) NOT NULL,\r\n  LAST_SMS2_REMIND date NOT NULL,\r\n  MANAGER_ID varchar(20) NOT NULL,\r\n  CAL_TYPE char(1) NOT NULL,\r\n  ADD_TIME datetime NOT NULL,\r\n  TAKER text NOT NULL);\r\n  \r\ncreate table if not exists task (\r\n  TASK_ID int(11) NOT NULL PRIMARY KEY,\r\n  USER_ID varchar(20) NOT NULL ,\r\n  TASK_NO int(11) NOT NULL,\r\n  TASK_TYPE varchar(10) NOT NULL ,\r\n  TASK_STATUS varchar(10) NOT NULL ,\r\n  COLOR varchar(10) NOT NULL ,\r\n  IMPORTANT varchar(10) NOT NULL ,\r\n  SUBJECT varchar(200) NOT NULL ,\r\n  EDIT_TIME datetime NOT NULL,\r\n  BEGIN_DATE date NOT NULL,\r\n  END_DATE date NOT NULL,\r\n  CONTENT text NOT NULL,\r\n  RATE varchar(10) NOT NULL ,\r\n  FINISH_TIME datetime NOT NULL,\r\n  TOTAL_TIME varchar(10) NOT NULL ,\r\n  USE_TIME varchar(10) NOT NULL ,\r\n  CAL_ID int(11) NOT NULL,\r\n  MANAGER_ID varchar(20) NOT NULL,\r\n  ADD_TIME datetime NOT NULL);\r\n  ";
$query = "SELECT * from CALENDAR where (USER_ID='".$CUR_USER_ID."' or find_in_set('{$CUR_USER_ID}',TAKER) or find_in_set('{$CUR_USER_ID}',OWNER))";
$cursor = exequery( ( ), $query );
$SQL = "";
while ( $ROW = mysql_fetch_array( $cursor ) )
{
    $USER_ID = $ROW['USER_ID'];
    $TAKER = $ROW['TAKER'];
    $OWNER = $ROW['OWNER'];
    $CAL_ID = $ROW['CAL_ID'];
    $CAL_TIME = $ROW['CAL_TIME'];
    $END_TIME = $ROW['END_TIME'];
    $CAL_TYPE = $ROW['CAL_TYPE'];
    $CAL_LEVEL = $ROW['CAL_LEVEL'];
    $CONTENT = $ROW['CONTENT'];
    $MANAGER_ID = $ROW['MANAGER_ID'];
    $OVER_STATUS = $ROW['OVER_STATUS'];
    $NOTAGS_CONTENT = sqlite_escape_string( strip_tags( $CONTENT ) );
    $SQL .= "insert into CALENDAR(CAL_ID,USER_ID,CAL_TIME,END_TIME,CAL_TYPE,CAL_LEVEL,CONTENT,OVER_STATUS,BEFORE_REMAIND,TAKER,OWNER) values ('".$CAL_ID."','{$USER_ID}','{$CAL_TIME}','{$END_TIME}','{$CAL_TYPE}','{$CAL_LEVEL}','{$NOTAGS_CONTENT}','{$OVER_STATUS}','{$BEFORE_REMAIND}','{$TAKER}','{$OWNER}');";
}
$query = "SELECT * from AFFAIR where (USER_ID='".$CUR_USER_ID."' or find_in_set('{$CUR_USER_ID}',TAKER)) order by BEGIN_TIME desc";
$cursor = exequery( ( ), $query );
while ( $ROW = mysql_fetch_array( $cursor ) )
{
    $AFF_ID = $ROW['AFF_ID'];
    $USER_ID = $ROW['USER_ID'];
    $BEGIN_TIME = $ROW['BEGIN_TIME'];
    $END_TIME = $ROW['END_TIME'];
    $TYPE = $ROW['TYPE'];
    $REMIND_DATE = $ROW['REMIND_DATE'];
    $REMIND_TIME = $ROW['REMIND_TIME'];
    $CONTENT = $ROW['CONTENT'];
    $CAL_TYPE = $ROW['CAL_TYPE'];
    $ADD_TIME = $ROW['ADD_TIME'];
    $MANAGER_ID = $ROW['MANAGER_ID'];
    $MANAGER_ID_NAME = getusernamebyid( $MANAGER_ID );
    $TAKER = $ROW['TAKER'];
    $SMS_REMIND = $ROW['SMS_REMIND'];
    $SMS2_REMIND = $ROW['SMS2_REMIND'];
    $LAST_SMS2_REMIND = $ROW['LAST_SMS2_REMIND'];
    $NOTAGS_CONTENT = sqlite_escape_string( strip_tags( $CONTENT ) );
    $SQL .= "insert into AFFAIR(AFF_ID,USER_ID,BEGIN_TIME,END_TIME,AFF_TYPE,REMIND_DATE,REMIND_TIME,CONTENT,SMS_REMIND,SMS2_REMIND,CAL_TYPE,ADD_TIME,MANAGER_ID,TAKER,LAST_SMS2_REMIND) values ('".$AFF_ID."','{$USER_ID}','{$BEGIN_TIME}','{$END_TIME}','{$TYPE}','{$REMIND_DATE}','{$REMIND_TIME}','{$NOTAGS_CONTENT}','{$SMS_REMIND}','{$SMS2_REMIND}','{$CAL_TYPE}','{$ADD_TIME}','{$MANAGER_ID_NAME}','{$TAKER}','{$LAST_SMS2_REMIND}');";
}
$CUR_DATE_T = date( "Y-m-d" );
$query = "SELECT * from TASK where USER_ID='".$CUR_USER_ID."' and BEGIN_DATE<='{$CUR_DATE_T}' and (END_DATE>='{$CUR_DATE_T}' or END_DATE='0000-00-00') order by TASK_ID desc";
$cursor = exequery( ( ), $query );
while ( $ROW = mysql_fetch_array( $cursor ) )
{
    $USER_ID = $ROW['USER_ID'];
    $CAL_ID = $ROW['CAL_ID'];
    $TASK_ID = $ROW['TASK_ID'];
    $TASK_NO = $ROW['TASK_NO'];
    $BEGIN_DATE = $ROW['BEGIN_DATE'];
    $END_DATE = $ROW['END_DATE'];
    $EDIT_TIME = $ROW['EDIT_TIME'];
    $FINISH_TIME = $ROW['FINISH_TIME'];
    $TOTAL_TIME = $ROW['TOTAL_TIME'];
    $USE_TIME = $ROW['USE_TIME'];
    $TASK_TYPE = $ROW['TASK_TYPE'];
    $TASK_STATUS = $ROW['TASK_STATUS'];
    $COLOR = $ROW['COLOR'];
    $IMPORTANT = $ROW['IMPORTANT'];
    $RATE = intval( $ROW['RATE'] );
    $MANAGER_ID = $ROW['MANAGER_ID'];
    if ( substr( $MANAGER_ID, -1 ) != "," )
    {
        $MANAGER_NEW_ID = $MANAGER_ID.",";
    }
    $MANAGER_ID_NAME = getusernamebyid( $MANAGER_NEW_ID );
    if ( substr( $MANAGER_ID_NAME, -1 ) == "," )
    {
        $MANAGER_ID_NAME = substr( $MANAGER_ID_NAME, 0, -1 );
    }
    $ADD_TIME = $ROW['ADD_TIME'];
    $SUBJECT = $ROW['SUBJECT'];
    $CONTENT = $ROW['CONTENT'];
    $NOTAGS_CONTENT = sqlite_escape_string( strip_tags( $CONTENT ) );
    $SQL .= "insert into TASK(USER_ID,TASK_ID, TASK_NO , TASK_TYPE , TASK_STATUS , COLOR, IMPORTANT, SUBJECT, EDIT_TIME, BEGIN_DATE, END_DATE,CONTENT,RATE, FINISH_TIME , TOTAL_TIME , USE_TIME , CAL_ID,MANAGER_ID,ADD_TIME)\r\nVALUES ('".$USER_ID."', '{$TASK_ID}','{$TASK_NO}', '{$TASK_TYPE}', '{$TASK_STATUS}', '{$COLOR}', '{$IMPORTANT}', '{$SUBJECT}', '{$EDIT_TIME}', '{$BEGIN_DATE}', '{$END_DATE}', '{$NOTAGS_CONTENT}', '{$RATE}', '{$FINISH_TIME}', '{$TOTAL_TIME}', '{$USE_TIME}', '{$CAL_ID}','{$MANAGER_ID_NAME}','{$ADD_TIME}');";
}
if ( $SQL != "" )
{
    $SYNC_DATA['calendar'][] = mb_convert_encoding( $SQL, "utf-8", MYOA_CHARSET );
}
?>
