<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
$SYNC_DATA['diary'][] = "drop table if exists diary;";
$SYNC_DATA['diary'][] = "create table if not exists diary (\r\n  DIA_ID integer(11) NOT NULL PRIMARY KEY,\r\n  USER_ID varchar(20) NOT NULL,\r\n  DIA_DATE date NOT NULL,\r\n  DIA_TIME datetime NOT NULL,\r\n  DIA_TYPE char(1) NOT NULL,\r\n  SUBJECT varchar(200) NOT NULL,\r\n  CONTENT mediumtext NOT NULL,\r\n  ATTACHMENT_ID text NOT NULL,\r\n  ATTACHMENT_NAME text NOT NULL,\r\n  TO_ID text NOT NULL,\r\n  COMPRESS_CONTENT blob NOT NULL\r\n)";
if ( function_exists( "sqlite_escape_string" ) )
{
    $THE_PATH = realpath( MYOA_ROOT_PATH."../" )."\\bin\\";
    message( _( "请联系管理员开启SQLITE扩展" ), sprintf( _( "1、确认文件%sphp_sqlite.dll存在；%s2、用记事本打开%sphp.ini；%s3、在文件找到Windows Extensions加入“extension=php_sqlite.dll”，然后保存并关闭文件；%s4、重新启动Office_Anywhere服务。" ), $THE_PATH, "<br>", $THE_PATH, "<br>", "<br>" ) );
    exit( );
}
$query = "SELECT DIA_ID,USER_ID,DIA_DATE,DIA_TIME,DIA_TYPE,SUBJECT,COMPRESS_CONTENT,ATTACHMENT_ID,ATTACHMENT_NAME,CONTENT,TO_ID from DIARY where USER_ID='".$CUR_USER_ID."' order by DIA_TIME desc";
$cursor = exequery( ( ), $query );
$SQL = "";
while ( $ROW = mysql_fetch_array( $cursor ) )
{
    $DIA_ID = $ROW['DIA_ID'];
    $USER_ID = $ROW['USER_ID'];
    $DIA_DATE = $ROW['DIA_DATE'];
    $DIA_TIME = $ROW['DIA_TIME'];
    $DIA_TYPE = $ROW['DIA_TYPE'];
    $SUBJECT = $ROW['SUBJECT'];
    $CONTENT = $ROW['CONTENT'];
    $NOTAGS_CONTENT = sqlite_escape_string( strip_tags( $CONTENT ) );
    $COMPRESS_CONTENT = $ROW['COMPRESS_CONTENT'];
    $COMPRESS_CONTENT = @gzuncompress( $COMPRESS_CONTENT );
    $COMPRESS_CONTENT = bin2hex( gzcompress( $COMPRESS_CONTENT ) );
    $TO_ID = $ROW['TO_ID'];
    $ATTACHMENT_ID = $ROW['ATTACHMENT_ID'];
    $ATTACHMENT_NAME = $ROW['ATTACHMENT_NAME'];
    $SQL .= "INSERT INTO DIARY(DIA_ID,USER_ID,DIA_DATE,DIA_TIME,DIA_TYPE,SUBJECT,CONTENT,COMPRESS_CONTENT,ATTACHMENT_ID,ATTACHMENT_NAME,TO_ID) values ('".$DIA_ID."','{$USER_ID}','{$DIA_DATE}','{$DIA_TIME}','{$DIA_TYPE}','{$SUBJECT}','{$NOTAGS_CONTENT}',x'{$COMPRESS_CONTENT}','{$ATTACHMENT_ID}','{$ATTACHMENT_NAME}','{$TO_ID}');";
}
if ( $SQL != "" )
{
    $SYNC_DATA['diary'][] = mb_convert_encoding( $SQL, "utf-8", MYOA_CHARSET );
}
?>
