<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
$SYNC_DATA['address'][] = "drop table if exists address;";
$SYNC_DATA['address'][] = "create table if not exists address (\r\n  ADD_ID integer(11) NOT NULL PRIMARY KEY,\r\n  USER_ID varchar(20) NOT NULL,\r\n  GROUP_ID integer(11) NOT NULL,\r\n  PSN_NAME varchar(120) NOT NULL,\r\n  SEX char(1) NOT NULL ,\r\n  NICK_NAME varchar(50) NOT NULL ,\r\n  BIRTHDAY date NOT NULL,\r\n  MINISTRATION varchar(50) NOT NULL,\r\n  MATE varchar(50) NOT NULL,\r\n  CHILD varchar(50) NOT NULL,\r\n  DEPT_NAME varchar(50) NOT NULL,\r\n  ADD_DEPT varchar(200) NOT NULL,\r\n  POST_NO_DEPT varchar(50) NOT NULL,\r\n  TEL_NO_DEPT varchar(50) NOT NULL,\r\n  FAX_NO_DEPT varchar(50) NOT NULL,\r\n  ADD_HOME varchar(200) NOT NULL,\r\n  POST_NO_HOME varchar(50) NOT NULL,\r\n  TEL_NO_HOME varchar(50) NOT NULL,\r\n  MOBIL_NO varchar(50) NOT NULL,\r\n  BP_NO varchar(50) NOT NULL,\r\n  EMAIL varchar(100) NOT NULL,\r\n  OICQ_NO varchar(50) NOT NULL,\r\n  ICQ_NO varchar(50) NOT NULL,\r\n  NOTES text NOT NULL,\r\n  PSN_NO integer(11) NOT NULL,\r\n\r\n  SHARE_USER text NOT NULL,\r\n  MANAGE_USER text NOT NULL,\r\n  ADD_SHARE_NAME text NOT NULL,\r\n  ATTACHMENT_ID text NOT NULL,\r\n  ATTACHMENT_NAME text NOT NULL\r\n  )";
$query = "SELECT * from ADDRESS where (find_in_set('".$CUR_USER_ID."',SHARE_USER) or USER_ID='{$CUR_USER_ID}' or USER_ID='' ) order by PSN_NAME";
$cursor = exequery( ( ), $query );
$SQL = "";
while ( $ROW = mysql_fetch_array( $cursor ) )
{
    $ADD_ID = $ROW['ADD_ID'];
    $USER_ID = $ROW['USER_ID'];
    $GROUP_ID = $ROW['GROUP_ID'];
    $PSN_NAME = $ROW['PSN_NAME'];
    $SEX = $ROW['SEX'];
    $BIRTHDAY = $ROW['BIRTHDAY'];
    $NICK_NAME = $ROW['NICK_NAME'];
    $MINISTRATION = $ROW['MINISTRATION'];
    $MATE = $ROW['MATE'];
    $CHILD = $ROW['CHILD'];
    $DEPT_NAME = $ROW['DEPT_NAME'];
    $ADD_DEPT = $ROW['ADD_DEPT'];
    $POST_NO_DEPT = $ROW['POST_NO_DEPT'];
    $TEL_NO_DEPT = $ROW['TEL_NO_DEPT'];
    $FAX_NO_DEPT = $ROW['FAX_NO_DEPT'];
    $ADD_HOME = $ROW['ADD_HOME'];
    $POST_NO_HOME = $ROW['POST_NO_HOME'];
    $TEL_NO_HOME = $ROW['TEL_NO_HOME'];
    $MOBIL_NO = $ROW['MOBIL_NO'];
    $BP_NO = $ROW['BP_NO'];
    $EMAIL = $ROW['EMAIL'];
    $OICQ_NO = $ROW['OICQ_NO'];
    $ICQ_NO = $ROW['ICQ_NO'];
    $PSN_NO = $ROW['PSN_NO'];
    $NOTES = $ROW['NOTES'];
    $ATTACHMENT_ID = $ROW['ATTACHMENT_ID'];
    $ATTACHMENT_NAME = $ROW['ATTACHMENT_NAME'];
    $SHARE_USER = $ROW['SHARE_USER'];
    $MANAGE_USER = $ROW['MANAGE_USER'];
    $ADD_SHARE_NAME = $ROW['ADD_SHARE_NAME'];
    $NOTES = sqlite_escape_string( strip_tags( $NOTES ) );
    $SQL .= "insert into ADDRESS(ADD_ID,USER_ID,GROUP_ID,PSN_NAME,SEX,BIRTHDAY,NICK_NAME,MINISTRATION,MATE,CHILD,DEPT_NAME,ADD_DEPT,POST_NO_DEPT,TEL_NO_DEPT,FAX_NO_DEPT,ADD_HOME,POST_NO_HOME,TEL_NO_HOME,MOBIL_NO,BP_NO,EMAIL,OICQ_NO,ICQ_NO,NOTES,PSN_NO,ATTACHMENT_ID,ATTACHMENT_NAME,MANAGE_USER,SHARE_USER,ADD_SHARE_NAME)\r\n    values ('".$ADD_ID."','{$USER_ID}','{$GROUP_ID}','{$PSN_NAME}','{$SEX}','{$BIRTHDAY}','{$NICK_NAME}','{$MINISTRATION}','{$MATE}','{$CHILD}','{$DEPT_NAME}','{$ADD_DEPT}','{$POST_NO_DEPT}','{$TEL_NO_DEPT}','{$FAX_NO_DEPT}','{$ADD_HOME}','{$POST_NO_HOME}','{$TEL_NO_HOME}','{$MOBIL_NO}','{$BP_NO}','{$EMAIL}','{$OICQ_NO}','{$ICQ_NO}','{$NOTES}','{$PSN_NO}','{$ATTACHMENT_ID}','{$ATTACHMENT_NAME}','{$MANAGE_USER}','{$SHARE_USER}','{$ADD_SHARE_NAME}');";
}
if ( $SQL != "" )
{
    $SYNC_DATA['address'][] = mb_convert_encoding( $SQL, "utf-8", MYOA_CHARSET );
}
?>
