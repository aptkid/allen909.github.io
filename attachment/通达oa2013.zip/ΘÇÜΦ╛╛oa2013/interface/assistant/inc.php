<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
function finish_exit( $code, $info = "", $data = array( ) )
{
    $result = array( "code" => $code, "info" => mb_convert_encoding( $info, "utf-8", MYOA_CHARSET ), "data" => $data );
    ob_end_clean( );
    echo json_encode( $result );
    exit( );
}

function login_check( $USERNAME, $PASSWORD )
{
    $USERNAME = strip_tags( $USERNAME );
    if ( $USERNAME == "" )
    {
        return _( "�û�������Ϊ��!" );
    }
    if ( strstr( $USERNAME, "'" ) )
    {
        return _( "�û�������Ϣ�����Ƿ��ַ�" );
    }
    $USER_IP = get_client_ip( );
    $PARA_ARRAY = get_sys_para( "SEC_RETRY_BAN,SEC_RETRY_TIMES,SEC_BAN_TIME,LOGIN_USE_DOMAIN,DOMAIN_SYNC_CONFIG" );
    while ( list( $PARA_NAME, $PARA_VALUE ) = each( &$PARA_ARRAY ) )
    {
        $$PARA_NAME = $PARA_VALUE;
    }
    if ( $SEC_RETRY_BAN == "1" )
    {
        $query = "SELECT count(*) from SYS_LOG where (TYPE='2' or TYPE='9' or TYPE='10') and USER_ID='".$USERNAME."' and IP='{$USER_IP}' and UNIX_TIMESTAMP()-UNIX_TIMESTAMP(TIME)<'".$SEC_BAN_TIME * 60."'";
        $cursor = exequery( ( ), $query );
        if ( $ROW = mysql_fetch_array( $cursor ) )
        {
            $LOGIN_RETRY_COUNT = $ROW[0];
        }
        if ( $SEC_RETRY_TIMES <= $LOGIN_RETRY_COUNT )
        {
            return sprintf( _( "�û�����������󳬹� %s �Σ���ȴ� %s ���Ӻ�����!" ), $SEC_RETRY_TIMES, $SEC_BAN_TIME );
        }
    }
    $query = "SELECT * from USER where USER_ID='".$USERNAME."' or BYNAME='{$USERNAME}'";
    $cursor = exequery( ( ), $query );
    if ( $ROW = mysql_fetch_array( $cursor ) )
    {
        add_log( 10, "USERNAME=".$USERNAME, $USERNAME );
        return sprintf( _( "������û���[%s]������" ), $USERNAME );
    }
    $UID = $ROW['UID'];
    $USER_ID = $ROW['USER_ID'];
    $BYNAME = $ROW['BYNAME'];
    $USER_NAME = $ROW['USER_NAME'];
    $PWD = $ROW['PASSWORD'];
    $SEX = $ROW['SEX'];
    $NOT_LOGIN = $ROW['NOT_LOGIN'];
    if ( $NOT_LOGIN )
    {
        return sprintf( _( "�û� %s ���趨Ϊ��ֹ��¼��" ), $USERNAME );
    }
    $USER_GUID = "";
    if ( $LOGIN_USE_DOMAIN == "1" )
    {
        $query = "select * from USER_MAP where USER_ID='".$USER_ID."'";
        $cursor1 = exequery( ( ), $query );
        if ( $ROW1 = mysql_fetch_array( $cursor1 ) )
        {
            $USER_GUID = $ROW1['USER_GUID'];
        }
    }
    if ( $USER_GUID == "" )
    {
        if ( crypt( $PASSWORD, $PWD ) != $PWD )
        {
            $ERROR_PWD = maskstr( $PASSWORD, 2, 1 );
            add_log( 2, $ERROR_PWD, $USER_ID );
            return _( "�������ע���Сд!" );
        }
    }
    if ( $PASSWORD == "" )
    {
        return _( "�󶨵����û����벻��Ϊ��" );
    }
    include_once( "inc/utility_user.php" );
    include_once( "inc/ldap/adLDAP.php" );
    $result = FALSE;
    try
    {
        $SYNC_CONFIG = unserialize( $DOMAIN_SYNC_CONFIG );
        $option = get_ldap_option( $SYNC_CONFIG );
        $adldap = new adLDAP( $option );
        if ( $adldap )
        {
            return _( "��ʼ������֤ʧ��" );
        }
        if ( $SYNC_CONFIG['AD_PWD']( $SYNC_CONFIG['AD_USER'], $SYNC_CONFIG['AD_PWD'] ) )
        {
            return sprintf( _( "����ز�����������(%s)" ), $adldap->get_last_error( ) );
        }
        $user_info = $adldap->user_info( $USER_GUID, array( "samaccountname" ), TRUE );
        if ( $user_info === FALSE )
        {
            return sprintf( _( "��ȡ�û�[%s]�����û�������(%s)" ), $USER_ID, $adldap->get_last_error( ) );
        }
        $user_info = $user_info[0];
        if ( !is_array( $user_info ) || !is_array( $user_info['samaccountname'] ) || $user_info['samaccountname'][0] == "" )
        {
            return sprintf( _( "��ѯ�����û�[%s]��Ӧ�����û�" ), $USER_ID );
        }
        $DOMAIN_USER = $user_info['samaccountname'][0];
        $adldap = new adLDAP( $option );
        $result = iconv( MYOA_CHARSET, "utf-8", $PASSWORD )( $DOMAIN_USER, iconv( MYOA_CHARSET, "utf-8", $PASSWORD ) );
        if ( $result )
        {
            return sprintf( _( "�û�[%s]����֤ʧ��(%s)" ), $USER_ID, $adldap->get_last_error( ) );
        }
    }
    catch ( adLDAPException $e )
    {
        return var_export( $e, TRUE );
}
add_log( 1, "", $_SESSION['LOGIN_USER_ID'] );
return array( "uid" => $UID, "user_id" => mb_convert_encoding( $USER_ID, "utf-8", MYOA_CHARSET ), "user_name" => mb_convert_encoding( $USER_NAME, "utf-8", MYOA_CHARSET ), "sex" => $SEX );
}

$DEMAND_VERSION = "5.5.120910";
?>
