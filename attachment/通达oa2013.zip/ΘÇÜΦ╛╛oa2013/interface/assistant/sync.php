<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
include_once( "inc/conn.php" );
include_once( "inc/utility_all.php" );
include_once( "inc/utility_org.php" );
include_once( "./inc.php" );
if ( $APP_VERSION < $DEMAND_VERSION )
{
    finish_exit( 0, sprintf( _( "���ĳ���汾̫�ͣ��������� %s �����ϰ汾�����ԡ�" ), $DEMAND_VERSION ) );
}
$PASSWORD = td_authcode( $PASSWORD, "DECODE", "607a93f847b659cd6fb597f13138b3df" );
$USERNAME = mb_convert_encoding( $USERNAME, MYOA_CHARSET, "utf-8" );
$PASSWORD = mb_convert_encoding( $PASSWORD, MYOA_CHARSET, "utf-8" );
$RESULT = login_check( $USERNAME, $PASSWORD );
if ( is_array( $RESULT ) )
{
    finish_exit( 0, $RESULT );
}
$CUR_UID = $RESULT['uid'];
$CUR_USER_ID = mb_convert_encoding( $RESULT['user_id'], MYOA_CHARSET, "utf-8" );
$SYNC_DATA = array( );
$MODULE_ARRAY = explode( ",", $MODULES );
foreach ( $MODULE_ARRAY as $MODULE )
{
    $MODULE = trim( $MODULE );
    if ( $MODULE == "" || !file_exists( "./sync_".$MODULE.".php" ) )
    {
    }
    else
    {
        include( "./sync_".$MODULE.".php" );
    }
}
finish_exit( 1, "", $SYNC_DATA );
?>
