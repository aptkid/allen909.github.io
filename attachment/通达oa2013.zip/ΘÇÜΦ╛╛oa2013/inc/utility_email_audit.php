<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
function check_email_audit( $type )
{
    switch ( $type )
    {
        case "1" :
            return getsysparabyparaname( "EMAIL_AUDIT_OPTION" ) == 1;
        case "2" :
            return dongle_optional( "SEC_RULE" ) == 1;
        case "3" :
            return dongle_optional( "SEC_RULE" ) == 1;
        default :
            return FALSE;
    }
}

function getEmailRefUsersByBodyId( $body_id )
{
    $EmailRefInfo = array( );
    $query = "SELECT from_id, subject, to_id2, copy_to_id, secret_to_id, SMS_REMIND FROM email_body WHERE body_id = '".$body_id."'";
    $cursor = exequery( ( ), $query );
    if ( $row = mysql_fetch_assoc( $cursor ) )
    {
        $EmailRefInfo['audit_man'] = $row['to_id2'].$row['copy_to_id'].$row['secret_to_id'];
        $EmailRefInfo['from_id'] = $row['from_id'];
        $EmailRefInfo['subject'] = $row['subject'];
        $EmailRefInfo['SMS_REMIND'] = $row['SMS_REMIND'];
    }
    return $EmailRefInfo;
}

function getDeptAuditMansByDeptId( $dept_id )
{
    $query = "SELECT DEPT_EMAIL_AUDITS_IDS FROM department WHERE dept_id = '".$dept_id."'";
    $cursor = exequery( ( ), $query );
    if ( $row = mysql_fetch_assoc( $cursor ) )
    {
        $audit_man = email_trim( $_SESSION['LOGIN_USER_ID'], $row['DEPT_EMAIL_AUDITS_IDS'] );
        return $audit_man;
    }
    return FALSE;
}

function email_trim( $str_find, $strings, $trim_str = "," )
{
    $str_find = substr( $str_find, -1, 1 ) == "," ? $str_find : $str_find.",";
    $strings = substr( $strings, -1, 1 ) == "," ? $strings : $strings.",";
    if ( strpos( $strings, $str_find ) === 0 )
    {
        return substr( $strings, strlen( $str_find ) );
    }
    return str_replace( $str_find, ",", $strings );
}

function getSysParaByParaName( $ParaName )
{
    $PARA_ARRAY = get_sys_para( $ParaName );
    return $PARA_ARRAY[$ParaName];
}

function addEmailAuditLog( $log_type, $uid = 0, $log_data = array( ) )
{
    global $email_audit_level_config;
    global $log_type_config_arr;
    $from_body_id = 0;
    $to_body_id = 0;
    switch ( $log_type )
    {
        case "71" :
            $audit_option_arr = array( "0" => _( "ͣ��" ), "1" => _( "����" ) );
            $data_remark = _( "��[" ).$audit_option_arr[$log_data['src']]._( "]״̬���Ϊ[" ).$audit_option_arr[$log_data['des']]._( "]״̬" );
        case "72" :
            $data_remark = _( "�û�[" ).td_trim( getusernamebyid( $log_data['change_user'] ) )._( "]���ܼ���[" ).$email_audit_level_config[$log_data['src']]._( "]���Ϊ[" ).$email_audit_level_config[$log_data['des']]._( "]״̬" );
        case "73" :
            $data_remark = _( "����[" ).td_trim( getdeptnamebyid( $log_data['dept_id'] ) )._( "]" );
            if ( $log_data['src'] != $log_data['des'] )
            {
                $data_remark .= _( " �����ʼ��������[" ).td_trim( getusernamebyid( $log_data['src'] ) )._( "]���Ϊ[" ).td_trim( getusernamebyid( $log_data['des'] ) )._( "]" );
            }
        case "77" :
            $audit_result_config = array( "0" => _( "��ͨ��" ), "1" => _( "ͨ��" ) );
            $from_body_id = $log_data['body_id'];
            $data_remark = _( "�û�[" ).td_trim( getusernamebyid( $log_data['from_id'] ) )._( "]���͵�����Ϊ[" ).$log_data['subject']._( "]�ʼ�ִ�����[" ).$audit_result_config[$log_data['audit_type']]._( "]����" )._( "#$#BODY_ID(" ).$log_data['body_id']._( ")" );
        case "78" :
            $data_remark = _( "������Ա��[" ).$log_data['src']._( "]���Ϊ[" ).$log_data['des']."]";
        case "79" :
            $from_body_id = $log_data['src'];
            $to_body_id = $log_data['des'];
            $data_remark = _( "���˻��ʼ��е��ʼ��༭�ٷ���#$#BODY_ID(" ).$log_data['src']._( ")����BODY_ID(" ).$log_data['des'].")";
        case "80" :
            $from_body_id = $log_data['body_id'];
            $data_remark = _( "�����ʼ������⣺[" ).$log_data['subject']."]"._( " �ܼ���[" ).$log_data['select']."]"._( " ����ˣ�[" ).$log_data['auitstr']."]"._( "#$#BODY_ID(" ).$log_data['body_id'].")";
        case "81" :
            $from_body_id = $log_data['body_id'];
            $data_remark = _( "�����ʼ������⣺[" ).$log_data['subject']."]"._( " �ܼ���[" ).$log_data['select']."]"._( "#$#BODY_ID(" ).$log_data['body_id'].")";
        default :
            return add_email_secure_log( $log_type, $data_remark, $uid, $from_body_id, $to_body_id );
    }
}

function add_email_secure_log( $RULE_ID, $REMARK = "", $UID = 0, $from_body_id = 0, $to_body_id = 0 )
{
    $RULE_ID = intval( $RULE_ID );
    $UID = $UID == 0 ? $_SESSION['LOGIN_UID'] : intval( $UID );
    $IP = get_client_ip( );
    $REMARK = mysql_escape_string( $REMARK );
    $query = "insert into SECURE_LOG (RULE_ID,UID,LOG_TIME,IP,REMARK,from_body_id, to_body_id) values ('".$RULE_ID."','{$UID}','".time( ).( "','".$IP."','{$REMARK}', '{$from_body_id}' , '{$to_body_id}')" );
    exequery( ( ), $query );
    return mysql_insert_id( );
}

function getEmailFromManAndSubjectByBodyId( $body_id, $COPY_TIME = "" )
{
    $email_info = array( );
    $query = "SELECT from_id, subject FROM email_body".$COPY_TIME.( " WHERE body_id = '".$body_id."'" );
    $cursor = exequery( ( ), $query );
    if ( $row = mysql_fetch_assoc( $cursor ) )
    {
        $email_info['from_id'] = $row['from_id'];
        $email_info['subject'] = $row['subject'];
    }
    return $email_info;
}

function GetSelectLevel( $UID )
{
    $USER_SECRET_LEVEL = "";
    if ( $UID == "" )
    {
        return FALSE;
    }
    $query = "select SECRET_LEVEL from USER where UID='".$UID."'";
    $cursor = exequery( ( ), $query );
    if ( $ROW = mysql_fetch_array( $cursor ) )
    {
        $USER_SECRET_LEVEL = $ROW['SECRET_LEVEL'];
    }
    if ( $USER_SECRET_LEVEL === "0" )
    {
        $USER_SECRET_LEVEL = 1;
    }
    return $USER_SECRET_LEVEL;
}

$email_audit_level_config = array( 1 => _( "������" ), 2 => _( "����(һ��)" ), 3 => _( "����(��Ҫ)" ), 4 => _( "����(�ǳ���Ҫ)" ) );
$log_type_config_arr = array( "71" => _( "����ʼ���˿���" ), "72" => _( "����û��ܼ�" ), "73" => _( "������ŵ��ʼ������" ), "77" => _( "����ʼ�" ), "78" => _( "����ʼ�������Ա" ), "79" => _( "�˻��ʼ��༭�ٷ���" ), "80" => _( "����������ʼ�" ), "81" => _( "����������ʼ�" ) );
?>
