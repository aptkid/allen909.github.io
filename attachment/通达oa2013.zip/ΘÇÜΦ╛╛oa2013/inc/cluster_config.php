<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
$MYOA_JS_SERVER = "";
$MYOA_STATIC_SERVER = "";
$MYOA_DB_USE_REPLICATION = 0;
$MYOA_MASTER_DB = array( "id" => 1, "host" => $MYSQL_SERVER, "user" => $MYSQL_USER, "pwd" => $MYSQL_PASS, "db" => $MYSQL_DB, "db_archive" => $MYSQL_DB_ARCHIVE, "db_crscell" => $MYSQL_DB_CRSCELL, "weight" => 1 );
$MYOA_SLAVE_DB = array( );
?>
