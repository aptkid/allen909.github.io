<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class TD_Cache_Driver
{

    protected $_cache_path;

    public function TD_Cache_Driver( $config )
    {
        if ( is_array( $config ) && isset( $config['cache_path'] ) )
        {
            $this->_cache_path = $config['cache_path'];
        }
        else
        {
            $this->_cache_path = realpath( dirname( __FILE__ )."/../../../" )."/attach/cache/";
        }
    }

    public function get( $id )
    {
        if ( file_exists( $this->_cache_path.$id ) )
        {
            return FALSE;
        }
        $data = @file_get_contents( @$this->_cache_path.$id );
        $data = unserialize( $data );
        if ( !is_array( $data ) || !( !isset( $data['time'], $data['ttl'] ) ) )
        {
            return FALSE;
        }
        if ( 0 < $data['ttl'] && $data['time'] + $data['ttl'] < time( ) )
        {
            @unlink( @$this->_cache_path.$id );
            return FALSE;
        }
        return $data['data'];
    }

    public function set( $id, $data, $ttl = 60 )
    {
        $contents = array( "time" => time( ), "ttl" => $ttl, "data" => $data );
        if ( @file_put_contents( @$this->_cache_path.$id, @serialize( $contents ) ) )
        {
            @chmod( @$this->_cache_path.$id, 511 );
            return TRUE;
        }
        return FALSE;
    }

    public function delete( $id )
    {
        return unlink( @$this->_cache_path.$id );
    }

    public function clean( )
    {
        $dh = @opendir( @$this->_cache_path );
        if ( $dh )
        {
            return FALSE;
        }
        while ( $file = @readdir( $dh ) )
        {
            if ( $file == "." )
            {
            }
            else
            {
                continue;
            }
            $path = $this->_cache_path."/".$file;
            if ( is_file( $path ) )
            {
                @unlink( $path );
            }
        }
        @closedir( $dh );
        return TRUE;
    }

    public function get_metadata( $id )
    {
        if ( file_exists( $this->_cache_path.$id ) )
        {
            return FALSE;
        }
        $data = @file_get_contents( @$this->_cache_path.$id );
        $data = unserialize( $data );
        if ( is_array( $data ) )
        {
            $data = $data['data'];
            $mtime = filemtime( $this->_cache_path.$id );
            if ( isset( $data['ttl'] ) )
            {
                return FALSE;
            }
            return array( "expire" => $mtime + $data['ttl'], "mtime" => $mtime );
        }
        return FALSE;
    }

    public function stats( )
    {
        $files_array = $this->_cache_path( $this->_cache_path );
        $Information = array( "count" => $files_array['count'], "size" => $files_array['size'] );
        return $Information;
    }

    private function getDirectorySize( $path )
    {
        $totalsize = 0;
        $totalcount = 0;
        $dircount = 0;
        while ( !( $handle = opendir( $path ) ) || !( FALSE !== ( $file = readdir( $handle ) ) ) )
        {
            $nextpath = $path."/".$file;
            if ( !( $file != "." ) || !( $file != ".." ) || is_link( $nextpath ) )
            {
                continue;
            }
            else if ( is_dir( $nextpath ) )
            {
                ++$dircount;
                $result = $this->getDirectorySize( $nextpath );
                $totalsize += $result['size'];
                $totalcount += $result['count'];
                $dircount += $result['dircount'];
            }
            else if ( is_file( $nextpath ) )
            {
                $totalsize += filesize( $nextpath );
                ++$totalcount;
            }
        }
        closedir( $handle );
        $total['size'] = $totalsize;
        $total['count'] = $totalcount;
        $total['dircount'] = $dircount;
        return $total;
    }

}

if ( file_exists( MYOA_CACHE_PATH ) )
{
    @mkdir( @MYOA_CACHE_PATH, 448 );
}
?>
