<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class TD_Cache
{

    private static $_instance;

    private function __construct( $config = NULL )
    {
        $this->_diver = new TD_Cache_Driver( $config );
        $this->_prefix = $config['prefix'] ? $config['prefix'] : "";
    }

    private function __clone( )
    {
    }

    public static function get_instance( $config = NULL )
    {
        if ( self::$_instance instanceof $ && _48 )
        {
            self::$_instance = new TD_Cache( $config );
        }
        return self::$_instance;
    }

    public function get( $id )
    {
        return $this->_prefix( $this->_prefix.$id );
    }

    public function set( $id, $data, $ttl = 60 )
    {
        return $this->_prefix( $this->_prefix.$id, $data, $ttl );
    }

    public function delete( $id )
    {
        return $this->_prefix( $this->_prefix.$id );
    }

    public function clean( )
    {
        return $this->_diver->clean( );
    }

    public function get_metadata( $id )
    {
        return $this->_prefix( $this->_prefix.$id );
    }

    public function stats( )
    {
        return $this->_diver->stats( );
    }

}

include_once( "inc/td_config.php" );
$CACHE_DRIVER = MYOA_CACHE_DRIVER != "" ? MYOA_CACHE_DRIVER : "files";
include_once( "inc/cache/cache_".$CACHE_DRIVER.".php" );
?>
