<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class TD_Cache_Driver
{

    public function TD_Cache_Driver( $config = NULL )
    {
    }

    public function get( $id )
    {
        $data = apc_fetch( $id );
        if ( is_array( $data ) )
        {
            $data = apc_fetch( $id );
        }
        if ( is_array( $data ) )
        {
            return $data[0];
        }
        return FALSE;
    }

    public function set( $id, $data, $ttl = 60 )
    {
        return apc_store( $id, array( $data, time( ), $ttl ), $ttl );
    }

    public function delete( $id )
    {
        return apc_delete( $id );
    }

    public function clean( )
    {
        return apc_clear_cache( "user" );
    }

    public function get_metadata( $id )
    {
        $stored = apc_fetch( $id );
        if ( count( $stored ) !== 3 )
        {
            return FALSE;
        }
        $ttl = $stored[2];
        $time = $stored[1];
        $data = $stored[0];
        return array( "expire" => $time + $ttl, "mtime" => $time, "data" => $data );
    }

    public function stats( )
    {
        return apc_cache_info( "user", TRUE );
    }

}

?>
