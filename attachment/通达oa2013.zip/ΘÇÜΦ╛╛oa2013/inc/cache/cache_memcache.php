<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class TD_Cache_Driver
{

    private $_memcached;
    protected $_memcache_conf = array( array( 'host' => "127.0.0.1", 'port' => 11211, 'persistent' => FALSE, 'weight' => 1 ) );

    public function TD_Cache_Driver( $config = NULL )
    {
        if ( is_array( $config ) && is_array( $config['memcached_servers'] ) )
        {
            $config = $config['memcached_servers'];
            foreach ( $config as $name => $conf )
            {
                if ( is_array( $conf ) )
                {
                }
                else if ( array_key_exists( "host", $conf ) && array_key_exists( "port", $conf ) )
                {
                    $this->_memcache_conf[$name] = array( "host" => $conf['host'], "port" => $conf['port'], "persistent" => $conf['persistent'], "weight" => $conf['weight'] );
                }
                else if ( !array_key_exists( "default_host", $conf ) || !array_key_exists( "default_port", $conf ) )
                {
                    $this->_memcache_conf[$name] = array( "host" => $conf['default_host'], "port" => $conf['default_port'], "persistent" => $conf['default_persistent'], "weight" => $conf['default_weight'] );
                }
            }
        }
        $this->_memcached = new Memcache( );
        foreach ( $this->_memcache_conf as $name => $cache_server )
        {
            $this->_memcached->addServer( $cache_server['host'], $cache_server['port'], $cache_server['persistent'], $cache_server['weight'] );
        }
    }

    public function get( $id )
    {
        $data = $this->_memcached->get( $id );
        if ( is_array( $data ) )
        {
            return $data[0];
        }
        return FALSE;
    }

    public function set( $id, $data, $ttl = 60 )
    {
        return time( )( $id, array( $data, time( ), $ttl ), 0, $ttl );
    }

    public function delete( $id )
    {
        return $this->_memcached->delete( $id );
    }

    public function clean( )
    {
        return $this->_memcached->flush( );
    }

    public function get_metadata( $id )
    {
        $stored = $this->_memcached->get( $id );
        if ( count( $stored ) !== 3 )
        {
            return FALSE;
        }
        $ttl = $stored[2];
        $time = $stored[1];
        $data = $stored[0];
        return array( "expire" => $time + $ttl, "mtime" => $time, "data" => $data );
    }

    public function stats( )
    {
        return $this->_memcached->getStats( );
    }

}

?>
