<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
function Message_reg( $type, $title, $tips, $button = NULL )
{
    if ( $type == "" )
    {
        $type = "error";
    }
    $html = "";
    if ( $button[0]['href'] )
    {
        $html = " href=\"".$button[0]['href']."\" ";
    }
    else if ( $button[0]['click'] )
    {
        $html = " href=\"javascript:;\" onclick=\"".$button[0]['click']."\" ";
    }
    echo "<div class=\"bd-msg-box\"><div class=\"msg-box-bd ".$type."\"><div class=\"msg-box-bd-title\"><div class=\"msg-box-bd-title-a\">".$title."</div></div><div class=\"msg-box-bd-title-b\">".$tips."</div></div><div class=\"msg-box-ft\"><a class=\"hd-reg-btn normal\" ".$html."><span>".$button[0]['value']."</span></a></div></div>";
}

include_once( "inc/td_core.php" );
include_once( "inc/itask/itask.php" );
$HTML_PAGE_TITLE = TD_MYOA_PRODUCT_NAME;
include_once( "inc/header.inc.php" );
$SYS_VERSION = ( "SYS_VERSION" );
echo "<body class=\"reg-body\">\r\n<link rel=\"stylesheet\" type=\"text/css\" href=\"";
echo MYOA_STATIC_SERVER;
echo "/static/modules/system/reg/style.css\">\r\n<div class=\"hd\">\r\n  <div class=\"hd-wrapper clearfix\">\r\n      <div class=\"hd-title-wrapper\">\r\n          <div class=\"hd-title\">";
echo TD_MYOA_PRODUCT_NAME;
echo " ";
echo _( "�ӳ�������" );
echo "</div>\r\n          <div class=\"hd-subtitle\">\r\n            ";
echo _( "�ڲ��汾�ţ�" );
echo $SYS_VERSION['VER'];
echo "&nbsp;\r\n            ";
echo TD_MYOA_COMPANY_NAME;
echo " ";
echo _( "��Ȩ����" );
echo "&nbsp;\r\n            <a href=\"http://";
echo TD_MYOA_WEB_SITE;
echo "\" target=\"_blank\">";
echo TD_MYOA_WEB_SITE;
echo "</a>\r\n          </div>\r\n      </div>\r\n    <div class=\"hd-desc\">\r\n        <a href=\"http://www.tongda2000.com/oa/hero/?OA_VER=2013adv&VER=";
echo TD_MYOA_VERSION;
echo "\" target=\"_blank\" style=\"color:#ff0000;\" class=\"hd-desc-tips\">";
echo _( "�����û����õǼǣ��ӳ���������90��" );
echo "</a>\r\n    </div>\r\n  </div>\r\n</div>\r\n<div class=\"bd\">\r\n";
if ( tdoa_check_reg( ) )
{
    message_reg( "success", _( "��ʾ" ), _( "ϵͳ�Ѿ�ע��Ϊ��ʽ�棬�����ӳ�������" ), array( array( "value" => _( "����" ), "click" => "history.back()" ) ) );
    exit( );
}
if ( $USER_READ != "on" )
{
    message_reg( "error", _( "ʧ��" ), _( "������ͬ������ʹ��������ܽ�������������" ), $BUTTON_BACK );
    exit( );
}
$ATTACHMENT_NAME = $_FILES['REGISTER_FILE']['name'];
$ATTACHMENT = $_FILES['REGISTER_FILE']['tmp_name'];
if ( file_exists( $ATTACHMENT ) )
{
    message_reg( "error", _( "ʧ��" ), _( "��Ȩ�ļ�������" ), $BUTTON_BACK );
    exit( );
}
if ( $ATTACHMENT_NAME != "tdtrial7.dat" )
{
    message_reg( "error", _( "ʧ��" ), _( "��Ȩ�ļ�������" ), $BUTTON_BACK );
    exit( );
}
$TRAIL_DATA = file_get_contents( $ATTACHMENT );
$TRAIL_DATA = trim( $TRAIL_DATA );
if ( $TRAIL_DATA === FALSE || strlen( $TRAIL_DATA ) < 30 || 512 < strlen( $TRAIL_DATA ) )
{
    message_reg( "error", _( "ע��ʧ��" ), _( "��Ȩ�ļ���С����ȷ" ), $BUTTON_BACK );
    exit( );
}
$result = itask( array( "PARA_2 ".$TRAIL_DATA ) );
if ( $result === FALSE )
{
    message_reg( "error", _( "ʧ��" ), itask_last_error( ), $BUTTON_BACK );
    exit( );
}
$result = $result[0];
if ( substr( $result, 0, 3 ) == "+OK" )
{
    message_reg( "success", _( "��ʾ" ), _( "�ӳ������ڳɹ���" ), array( array( "value" => _( "��¼ͨ��OA�칫ϵͳ" ), "click" => "window.open('/')" ) ) );
}
else
{
    message_reg( "error", _( "�ӳ�������ʧ��" ), substr( $result, 5 ), $BUTTON_BACK );
}
cache_unit( );
cache_sys_para( );
add_log( 18, $_SESSION['LOGIN_USER_ID'], "admin" );
echo "</div>\r\n</body>\r\n</html>";
?>
