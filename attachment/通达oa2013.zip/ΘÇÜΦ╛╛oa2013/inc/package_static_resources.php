<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class PackageStaticResources
{

    public static $ServerPath = "";
    public static $RootPath = "";
    public static $EOL = "\n";

    public function __construct( $cfg = array( ), $serverCfg )
    {
        self::$ServerPath = "http://".$serverCfg['HTTP_HOST']."/";
        self::$RootPath = $serverCfg['DOCUMENT_ROOT'];
        foreach ( $cfg as $index => $packageCfg )
        {
            foreach ( $packageCfg as $key => $value )
            {
                $this->package( $key, $value );
            }
        }
    }

    public function package( $dest, $res )
    {
        $content = "// \"".implode( "\",\"", $res )."\"".self::$EOL;
        foreach ( $res as $path )
        {
            $content .= $this->getComments( $path ).self::$EOL;
            $content .= $this->getFileContent( $path ).self::$EOL;
        }
        $this->buildFile( $dest, $content );
        return $content;
    }

    private function buildFile( $dest, $content )
    {
        $path = self::$RootPath.$dest;
        file_put_contents( $path, $content );
    }

    private function getFileContent( $path = "" )
    {
        if ( $path == "" )
        {
            return "";
        }
        if ( @preg_match( "/\\.php$/i", $path ) )
        {
            $realPath = self::$ServerPath.$path;
            return file_get_contents( $realPath );
        }
        $realPath = self::$RootPath.$path;
        if ( file_exists( $realPath ) )
        {
            return file_get_contents( $realPath );
        }
    }

    private function getComments( $path = "" )
    {
        if ( $path == "" )
        {
            return "";
        }
        return "/* \"".$path."\" */";
    }

}

$json = file_get_contents( "inc/package_static_resources.json" );
$config = json_decode( $json, TRUE );
if ( 0 < strlen( trim( $json ) ) && $config == NULL )
{
    throw $ && _25804480;
}
$package = new PackageStaticResources( $config, $_SERVER );
?>
