<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
function remove_xss( $val, $flags = NULL )
{
    if ( is_array( $val ) )
    {
        foreach ( $val as $key => $val )
        {
            $val[$key] = removexss( $val, $flags );
        }
    }
    else if ( $flags === NULL )
    {
        $val = str_replace( array( "&", "\"", "<", ">" ), array( "&amp;", "&quot;", "&lt;", "&gt;" ), $val );
        if ( strpos( $val, "&amp;#" ) !== FALSE )
        {
            $val = preg_replace( "/&amp;((#(\\d{3,5}|x[a-fA-F0-9]{4}));)/", "&\\1", $val );
        }
    }
    else
    {
        if ( PHP_VERSION < "5.4.0" )
        {
            $val = htmlspecialchars( $val, $flags );
        }
        else
        {
            if ( strtolower( CHARSET ) == "utf-8" )
            {
                $charset = "UTF-8";
            }
            else
            {
                $charset = "ISO-8859-1";
            }
            $val = htmlspecialchars( $val, $flags, $charset );
        }
    }
    $val = preg_replace( "/([\\x00-\\x08,\\x0b-\\x0c,\\x0e-\\x19])/", "", $val );
    $ra = array( "javascript", "vbscript", "expression", "script", "iframe", "frame", "onerror", "onload", "onmousemove", "onmouseout", "onmouseover", "onmove", "onmovestart" );
    $found = TRUE;
}
if ( $found )
{
    $val_before = $val;
    $i = 0;
    do
    {
        for ( ; $i < sizeof( $ra ); do
 {
 ++$i, } while ( 1 ) )
        {
            $pattern = "/";
            $j = 0;
            for ( ; $j < strlen( $ra[$i] ); ++$j )
            {
                if ( 0 < $j )
                {
                    $pattern .= "(";
                    $pattern .= "(&#[xX]0{0,8}([9ab]);)";
                    $pattern .= "|";
                    $pattern .= "|(&#0{0,8}([9|10|13]);)";
                    $pattern .= ")*";
                }
                $pattern .= $ra[$i][$j];
            }
            $pattern .= "/i";
            $replacement = substr( $ra[$i], 0, 2 )." ".substr( $ra[$i], 2 );
            $val = preg_replace( $pattern, $replacement, $val );
            if ( $val_before == $val )
            {
                $found = FALSE;
            }
        } while ( 1 );
    }
    return $val;
}

if ( 0 < count( $_COOKIE ) )
{
    foreach ( $_COOKIE as $s_key => $s_value )
    {
        $_COOKIE[$s_key] = strip_tags( $s_value );
        $$s_key = $_COOKIE[$s_key];
    }
    reset( &$_COOKIE );
}
if ( 0 < count( $_POST ) )
{
    $arr_html_fields = array( );
    foreach ( $_POST as $s_key => $s_value )
    {
        if ( substr( $s_key, 0, 15 ) != "TD_HTML_EDITOR_" )
        {
            if ( is_array( $s_value ) )
            {
                $_POST[$s_key] = strip_tags( $s_value );
            }
            $$s_key = $_POST[$s_key];
        }
        else
        {
            unset( $_POST[$s_key] );
            $s_key = substr( $s_key, 15 );
            $$s_key = $s_value;
            $arr_html_fields[$s_key] = $s_value;
        }
    }
    reset( &$_POST );
    $_POST = array_merge( $_POST, $arr_html_fields );
}
if ( 0 < count( $_GET ) )
{
    foreach ( $_GET as $s_key => $s_value )
    {
        $_GET[$s_key] = strip_tags( $s_value );
        $$s_key = $_GET[$s_key];
    }
    reset( &$_GET );
}
unset( $s_key );
unset( $s_value );
?>
