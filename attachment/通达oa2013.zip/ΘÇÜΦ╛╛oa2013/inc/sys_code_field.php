<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
function proj_get_field_text( $TYPE_CODE_NO, $IDENTY_ID )
{
    $DEF_FIELD_ARRAY = array( );
    $POSTFIX = _( "��" );
    $query = "select * from PROJ_FIELDSETTING where TYPE_CODE_NO='".$TYPE_CODE_NO."' order by ORDERNO";
    $cursor = exequery( ( ), $query );
    if ( mysql_num_rows( $cursor ) <= 0 || $IDENTY_ID == "" )
    {
        return $DEF_FIELD_ARRAY;
    }
    while ( $ROW = mysql_fetch_array( $cursor ) )
    {
        $FIELDNAME = $ROW['FIELDNAME'];
        $FIELDNO = $ROW['FIELDNO'];
        $STYPE = $ROW['STYPE'];
        $TYPENAME = $ROW['TYPENAME'];
        $TYPEVALUE = $ROW['TYPEVALUE'];
        $TYPECODE = $ROW['TYPECODE'];
        $ITEM_DATE = "";
        $ITEM_DATE_DESC = "";
        $query = "select ITEM_DATE from PROJ_FIELD_DATE where TYPE_CODE_NO='".$TYPE_CODE_NO."' and FIELDNO='{$FIELDNO}'and IDENTY_ID='{$IDENTY_ID}'";
        $cursor1 = exequery( ( ), $query );
        if ( $ROW1 = mysql_fetch_array( $cursor1 ) )
        {
            $ITEM_DATE = $ROW1['ITEM_DATE'];
        }
        if ( ( $STYPE == "D" || $STYPE == "C" || $STYPE == "R" ) && $ITEM_DATE != "" )
        {
            if ( $TYPECODE == "" )
            {
                $TYPEVALUE = str_replace( "��", ",", $TYPEVALUE );
                $TYPEVALUE_ARRAY = explode( ",", $TYPEVALUE );
                $TYPENAME = str_replace( "��", ",", $TYPENAME );
                $TYPENAME_ARRAY = explode( ",", $TYPENAME );
                $I = 0;
                for ( ; $I < count( $TYPENAME_ARRAY ); ++$I )
                {
                    if ( find_id( $ITEM_DATE, $TYPEVALUE_ARRAY[$I] ) )
                    {
                        $ITEM_DATE_DESC .= $TYPENAME_ARRAY[$I].$POSTFIX;
                        if ( $STYPE != "C" )
                        {
                        }
                    }
                }
                $ITEM_DATE_DESC = substr( $ITEM_DATE_DESC, 0, 0 - strlen( $POSTFIX ) );
            }
            else
            {
                $ITEM_DATE_DESC = get_code_name( $ITEM_DATE, $TYPECODE );
            }
        }
        else
        {
            $ITEM_DATE_DESC = $ITEM_DATE;
        }
        $DEF_FIELD_ARRAY[$FIELDNO]['FIELDNAME'] = $FIELDNAME;
        $DEF_FIELD_ARRAY[$FIELDNO]['HTML'] = $ITEM_DATE_DESC;
    }
    return $DEF_FIELD_ARRAY;
}

function proj_get_field_html( $TYPE_CODE_NO, $IDENTY_ID = "", $IS_QUERY = "0" )
{
    $DEF_FIELD_ARRAY = array( );
    if ( substr( $TYPE_CODE_NO, 0, 1 ) == "G" )
    {
        $G_TYPE_CODE_NO = "G";
    }
    else
    {
        $G_TYPE_CODE_NO = $TYPE_CODE_NO;
    }
    if ( $IS_QUERY == "0" )
    {
        $query = "select * from PROJ_FIELDSETTING where TYPE_CODE_NO='".$G_TYPE_CODE_NO."' order by ORDERNO";
    }
    else
    {
        $query = "select * from PROJ_FIELDSETTING where TYPE_CODE_NO='".$G_TYPE_CODE_NO."' and ISQUERY='1' order by ORDERNO";
    }
    $cursor = exequery( ( ), $query );
    if ( mysql_num_rows( $cursor ) <= 0 )
    {
        return $DEF_FIELD_ARRAY;
    }
    while ( $ROW = mysql_fetch_array( $cursor ) )
    {
        $FIELDNAME = $ROW['FIELDNAME'];
        $FIELDNO = $ROW['FIELDNO'];
        $STYPE = $ROW['STYPE'];
        $TYPENAME = $ROW['TYPENAME'];
        $TYPEVALUE = $ROW['TYPEVALUE'];
        $TYPECODE = $ROW['TYPECODE'];
        $ITEM_DATE = "";
        if ( $IDENTY_ID != "" && $IS_QUERY == "0" )
        {
            $query = "select ITEM_DATE from PROJ_FIELD_DATE where TYPE_CODE_NO='".$TYPE_CODE_NO."' and FIELDNO='{$FIELDNO}'and IDENTY_ID='{$IDENTY_ID}'";
            $cursor1 = exequery( ( ), $query );
            if ( $ROW1 = mysql_fetch_array( $cursor1 ) )
            {
                $ITEM_DATE = $ROW1['ITEM_DATE'];
            }
        }
        $OPTION_STR = "";
        $HTML_STR = "";
        if ( substr( $TYPE_CODE_NO, 0, 1 ) == "G" )
        {
            $FIELDNO = "G".$ROW['FIELDNO'];
        }
        if ( !( $STYPE == "D" ) && !( $STYPE == "C" ) && !( $STYPE == "R" ) || !( $TYPECODE == "" ) )
        {
            $TYPEVALUE = str_replace( "��", ",", $TYPEVALUE );
            $TYPEVALUE_ARRAY = explode( ",", $TYPEVALUE );
            $TYPENAME = str_replace( "��", ",", $TYPENAME );
            $TYPENAME_ARRAY = explode( ",", $TYPENAME );
            $I = 0;
            for ( ; $I < count( $TYPENAME_ARRAY ); ++$I )
            {
                if ( $TYPEVALUE_ARRAY[$I] == "" )
                {
                    continue;
                }
                else if ( $STYPE == "D" )
                {
                    $OPTION_STR .= "<option value=\"".$TYPEVALUE_ARRAY[$I]."\"";
                    if ( $IS_QUERY == "0" && $ITEM_DATE == $TYPEVALUE_ARRAY[$I] )
                    {
                        $OPTION_STR .= " selected";
                    }
                    $OPTION_STR .= ">".$TYPENAME_ARRAY[$I]."</option>\n";
                }
                else if ( $STYPE == "C" )
                {
                    $OPTION_STR .= "<input type=\"checkbox\" name=\"".$FIELDNO."_".$TYPEVALUE_ARRAY[$I]."\" id=\"".$FIELDNO."_".$TYPEVALUE_ARRAY[$I]."\" value=\"".$TYPEVALUE_ARRAY[$I]."\"";
                    if ( $IS_QUERY == "0" && find_id( $ITEM_DATE, $TYPEVALUE_ARRAY[$I] ) )
                    {
                        $OPTION_STR .= " checked";
                    }
                    $OPTION_STR .= "><label for=\"".$FIELDNO."_".$TYPEVALUE_ARRAY[$I]."\">".$TYPENAME_ARRAY[$I]."</label>\n";
                }
                else if ( $STYPE == "R" )
                {
                    $OPTION_STR .= "<input type=\"radio\" name=\"".$FIELDNO."\" id=\"".$FIELDNO."_".$TYPEVALUE_ARRAY[$I]."\" value=\"".$TYPEVALUE_ARRAY[$I]."\"";
                    if ( $IS_QUERY == "0" && $ITEM_DATE == $TYPEVALUE_ARRAY[$I] )
                    {
                        $OPTION_STR .= " checked";
                    }
                    $OPTION_STR .= "><label for=\"".$FIELDNO."_".$TYPEVALUE_ARRAY[$I]."\">".$TYPENAME_ARRAY[$I]."</label>\n";
                }
            }
        }
        if ( $STYPE == "T" )
        {
            $HTML_STR .= "<input type=\"text\" name=\"".$FIELDNO."\" class=\"BigInput\" value=\"".$ITEM_DATE."\" size=\"30\">";
        }
        else if ( $STYPE == "MT" )
        {
            $HTML_STR .= "<textarea cols=37 rows=3 name=\"".$FIELDNO."\" class=\"BigInput\">".$ITEM_DATE."</textarea>";
        }
        else if ( $STYPE == "D" )
        {
            $HTML_STR .= "<select name=\"".$FIELDNO."\" class=\"BigSelect\">\n";
            if ( $IS_QUERY == "1" )
            {
                $HTML_STR .= "<option value=\"\"></option>\n";
            }
            if ( $TYPECODE != "" )
            {
                $HTML_STR .= code_list( $TYPECODE, $ITEM_DATE );
            }
            else
            {
                $HTML_STR .= $OPTION_STR;
            }
            $TABLE_STR .= "</select>\n";
        }
        else if ( $STYPE == "C" || $STYPE == "R" )
        {
            if ( $TYPECODE != "" )
            {
                $HTML_STR .= code_list( $TYPECODE, $ITEM_DATE, $STYPE, $FIELDNO );
            }
            else
            {
                $HTML_STR .= $OPTION_STR;
            }
        }
        $DEF_FIELD_ARRAY[$FIELDNO]['FIELDNAME'] = $FIELDNAME;
        $DEF_FIELD_ARRAY[$FIELDNO]['HTML'] = $HTML_STR;
    }
    return $DEF_FIELD_ARRAY;
}

function proj_save_field_data( $TYPE_CODE_NO, $IDENTY_ID, $FORM )
{
    $USERDEF_FIELD = array( );
    while ( list( $key, $value ) = each( &$FORM ) )
    {
        if ( substr( $key, 0, 7 ) != "USERDEF" )
        {
        }
        else
        {
            continue;
        }
        $USERDEF_FIELD[$key] = $value;
    }
    reset( &$FORM );
    while ( list( $key, $value ) = each( &$FORM ) )
    {
        if ( substr( $key, 0, 7 ) != "USERDEF" || !strstr( substr( $key, 7 ), "_" ) )
        {
        }
        else
        {
            $ARRAY = explode( "_", substr( $key, 7 ) );
            $USERDEF_FIELD .= "USERDEF".$ARRAY[0];
        }
    }
    while ( list( $key, $value ) = each( &$USERDEF_FIELD ) )
    {
        $query = "select * from PROJ_FIELD_DATE where TYPE_CODE_NO='".$TYPE_CODE_NO."' and FIELDNO='{$key}' and IDENTY_ID='{$IDENTY_ID}';";
        $cursor = exequery( ( ), $query );
        if ( 0 < mysql_num_rows( $cursor ) )
        {
            $query = "update PROJ_FIELD_DATE set ITEM_DATE='".$value."' where TYPE_CODE_NO='{$TYPE_CODE_NO}' and FIELDNO='{$key}' and IDENTY_ID='{$IDENTY_ID}';";
        }
        else
        {
            $query = "insert into PROJ_FIELD_DATE (TYPE_CODE_NO,FIELDNO,IDENTY_ID,ITEM_DATE) values ('".$TYPE_CODE_NO."','{$key}','{$IDENTY_ID}','{$value}');";
        }
        exequery( ( ), $query );
    }
}

function proj_save_field_data_g( $TYPE_CODE_NO, $IDENTY_ID, $FORM )
{
    $TYPE_CODE_NO = "G".$TYPE_CODE_NO;
    $USERDEF_FIELD = array( );
    while ( list( $key, $value ) = each( &$FORM ) )
    {
        if ( substr( $key, 0, 8 ) != "GUSERDEF" )
        {
        }
        else
        {
            continue;
        }
        $USERDEF_FIELD[substr( $key, 1 )] = $value;
    }
    reset( &$FORM );
    while ( list( $key, $value ) = each( &$FORM ) )
    {
        if ( substr( $key, 0, 8 ) != "GUSERDEF" || !strstr( substr( $key, 8 ), "_" ) )
        {
        }
        else
        {
            $ARRAY = explode( "_", substr( $key, 8 ) );
            $USERDEF_FIELD .= "USERDEF".$ARRAY[0];
        }
    }
    while ( list( $key, $value ) = each( &$USERDEF_FIELD ) )
    {
        $query = "select * from PROJ_FIELD_DATE where TYPE_CODE_NO='".$TYPE_CODE_NO."' and FIELDNO='{$key}' and IDENTY_ID='{$IDENTY_ID}';";
        $cursor = exequery( ( ), $query );
        if ( 0 < mysql_num_rows( $cursor ) )
        {
            $query = "update PROJ_FIELD_DATE set ITEM_DATE='".$value."' where TYPE_CODE_NO='{$TYPE_CODE_NO}' and FIELDNO='{$key}' and IDENTY_ID='{$IDENTY_ID}';";
        }
        else
        {
            $query = "insert into PROJ_FIELD_DATE (TYPE_CODE_NO,FIELDNO,IDENTY_ID,ITEM_DATE) values ('".$TYPE_CODE_NO."','{$key}','{$IDENTY_ID}','{$value}');";
        }
        exequery( ( ), $query );
    }
}

function proj_del_field_data( $IDENTY_ID )
{
    $query = "delete from PROJ_FIELD_DATE where IDENTY_ID='".$IDENTY_ID."';";
    exequery( ( ), $query );
}

function proj_del_field_datastr( $TYPE_CODE_NO, $DELETE_STR )
{
    $query = "delete from PROJ_FIELD_DATE where TYPE_CODE_NO='".$TYPE_CODE_NO."'and IDENTY_ID in ({$DELETE_STR})";
    exequery( ( ), $query );
}

function proj_field_where_str( $TYPE_CODE_NO, $FORM, $ID_FIELD_NAME )
{
    $USERDEF_FIELD = array( );
    while ( list( $key, $value ) = each( &$FORM ) )
    {
        if ( substr( $key, 0, 7 ) != "USERDEF" || strstr( substr( $key, 7 ), "_" ) )
        {
        }
        else
        {
            continue;
        }
        $USERDEF_FIELD[$key] = $value;
        $FIELDNO_STR .= $key.",";
    }
    reset( &$FORM );
    while ( list( $key, $value ) = each( &$FORM ) )
    {
        if ( substr( $key, 0, 7 ) != "USERDEF" )
        {
            if ( strstr( substr( $key, 7 ), "_" ) )
            {
            }
        }
        else
        {
            continue;
        }
        $ARRAY = explode( "_", substr( $key, 7 ) );
        $USERDEF_FIELD .= "USERDEF".$ARRAY[0];
        $FIELDNO_STR .= "USERDEF".$ARRAY[0].",";
    }
    $query = "select * from PROJ_FIELDSETTING where TYPE_CODE_NO='".$TYPE_CODE_NO."' and find_in_set(FIELDNO,'{$FIELDNO_STR}') order by ORDERNO;";
    $cursor = exequery( ( ), $query );
    while ( $ROW = mysql_fetch_array( $cursor ) )
    {
        $FIELDNO = $ROW['FIELDNO'];
        $STYPE = $ROW['STYPE'];
        $TYPENAME = $ROW['TYPENAME'];
        $TYPEVALUE = $ROW['TYPEVALUE'];
        $TYPECODE = $ROW['TYPECODE'];
        $IDENTY_ID_STR = "";
        $query = "select * from PROJ_FIELD_DATE where TYPE_CODE_NO='".$TYPE_CODE_NO."' and FIELDNO='{$FIELDNO}';";
        $cursor1 = exequery( ( ), $query );
        while ( $ROW = mysql_fetch_array( $cursor1 ) )
        {
            $IDENTY_ID = $ROW['IDENTY_ID'];
            $ITEM_DATE = $ROW['ITEM_DATE'];
            if ( $STYPE == "T" || $STYPE == "MT" )
            {
                if ( stristr( $ITEM_DATE, $USERDEF_FIELD[$FIELDNO] ) )
                {
                    $IDENTY_ID_STR .= $IDENTY_ID.",";
                }
            }
            else if ( $STYPE == "R" || $STYPE == "D" )
            {
                if ( $ITEM_DATE == $USERDEF_FIELD[$FIELDNO] )
                {
                    $IDENTY_ID_STR .= $IDENTY_ID.",";
                }
            }
            else if ( $STYPE == "C" )
            {
                $TOK_ARRAY = explode( ",", $USERDEF_FIELD[$FIELDNO] );
                $I = 0;
                do
                {
                    do
                    {
                        ++$I;
                    } while ( 1 );
                } while ( $TOK_ARRAY == "" || find_id( $ITEM_DATE, $TOK_ARRAY[$I] ) );
                if ( $I == count( $TOK_ARRAY ) - 1 )
                {
                    $IDENTY_ID_STR .= $IDENTY_ID.",";
                }
            }
        }
        $WHERE_STR .= " and find_in_set(".$ID_FIELD_NAME.", '".$IDENTY_ID_STR."')";
    }
    return $WHERE_STR;
}

function proj_get_field_table( $DEF_FIELD_ARRAY )
{
    if ( !is_array( $DEF_FIELD_ARRAY ) || count( $DEF_FIELD_ARRAY ) <= 0 )
    {
    }
    else
    {
        $TABLE_STR = "<table class=\"TableBlock\" width=\"100%\">\n";
        while ( list( $key, $value ) = each( &$DEF_FIELD_ARRAY ) )
        {
            $TABLE_STR .= "<tr><td class=\"TableContent\"  width=\"20%\">".$value['FIELDNAME']._( "��" )."</td><td class=\"TableData\" >".$value['HTML']."</td></tr>\n";
        }
        $TABLE_STR .= "</table>\n";
        return $TABLE_STR;
    }
}

function proj_get_field_table_g( $DEF_FIELD_ARRAY )
{
    if ( !is_array( $DEF_FIELD_ARRAY ) || count( $DEF_FIELD_ARRAY ) <= 0 )
    {
    }
    else
    {
        $TABLE_STR = "<table class=\"TableBlock\" width=\"100%\">\n";
        while ( list( $key, $value ) = each( &$DEF_FIELD_ARRAY ) )
        {
            $TABLE_STR .= "<tr><td nowrap class=\"TableContent\" width=\"20%\">".$value['FIELDNAME']._( "��" )."</td><td class=\"TableData\">".$value['HTML']."</td></tr>\n";
        }
        $TABLE_STR .= "</table>\n";
        return $TABLE_STR;
    }
}

function proj_get_field_title( $TYPE_CODE_NO )
{
    $USERDEF_FIELD = array( );
    $query = "select * from PROJ_FIELDSETTING where TYPE_CODE_NO='".$TYPE_CODE_NO."' order by ORDERNO;";
    $cursor = exequery( ( ), $query );
    while ( $ROW = mysql_fetch_array( $cursor ) )
    {
        $FIELDNO = $ROW['FIELDNO'];
        $FIELDNAME = $ROW['FIELDNAME'];
        $USERDEF_FIELD[trim( $FIELDNAME )] = $FIELDNO;
    }
    return $USERDEF_FIELD;
}

function proj_get_field_info( $TYPE_CODE_NO )
{
    $USERDEF_FIELD = array( );
    $query = "select * from PROJ_FIELDSETTING where TYPE_CODE_NO='".$TYPE_CODE_NO."' order by ORDERNO;";
    $cursor = exequery( ( ), $query );
    while ( $ROW = mysql_fetch_array( $cursor ) )
    {
        $FIELDNO = $ROW['FIELDNO'];
        $STYPE = $ROW['STYPE'];
        $TYPENAME = $ROW['TYPENAME'];
        $TYPEVALUE = $ROW['TYPEVALUE'];
        $TYPECODE = $ROW['TYPECODE'];
        $FIELD_INFO = array( "STYPE" => $STYPE, "CODE" => array( ) );
        if ( !( $STYPE == "C" ) && !( $STYPE == "R" ) && !( $STYPE == "D" ) )
        {
            if ( $TYPECODE != "" )
            {
                $FIELD_INFO['CODE'] = get_code_array( $TYPECODE, TRUE );
            }
            else
            {
                $NAME_ARRAY = explode( ",", $TYPENAME );
                $VALUE_ARRAY = explode( ",", $TYPEVALUE );
                $I = 0;
                for ( ; $I < count( $NAME_ARRAY ); ++$I )
                {
                    if ( $NAME_ARRAY[$I] == "" )
                    {
                        $FIELD_INFO['CODE'][$NAME_ARRAY[$I]] = $VALUE_ARRAY[$I];
                    }
                }
            }
        }
        $USERDEF_FIELD[$FIELDNO] = $FIELD_INFO;
    }
    return $USERDEF_FIELD;
}

function proj_get_data_array( $TYPE_CODE_NO, $IDENTY_ID )
{
    $TYPE_CODE_NO = "G".$TYPE_CODE_NO;
    $ARRAY_GDATA = array( );
    $query = "SELECT * FROM PROJ_FIELDSETTING s, PROJ_FIELD_DATE d WHERE s.TYPE_CODE_NO='G' and s.FIELDNO=d.FIELDNO and d.TYPE_CODE_NO='".$TYPE_CODE_NO."' and d.IDENTY_ID = '{$IDENTY_ID}' and s.IS_SHOWLIST=1";
    $cursor = exequery( ( ), $query );
    while ( $ROW = mysql_fetch_array( $cursor ) )
    {
        $FIELDNO = $ROW['FIELDNO'];
        $STYPE = $ROW['STYPE'];
        $FIELDNAME = $ROW['FIELDNAME'];
        $TYPENAME = $ROW['TYPENAME'];
        $TYPEVALUE = $ROW['TYPEVALUE'];
        $ITEM_DATE = $ROW['ITEM_DATE'];
        if ( !( $STYPE == "C" ) && !( $STYPE == "R" ) && !( $STYPE == "D" ) )
        {
            $ITEM_ARRAY = explode( ",", $ITEM_DATE );
            $NAME_ARRAY = explode( ",", $TYPENAME );
            $VALUE_ARRAY = explode( ",", $TYPEVALUE );
            $I = 0;
            for ( ; do
 {
 $I < count( $NAME_ARRAY ); }
 ++$I, } while ( 1 ) )
        {
            $J = 0;
            do
            {
                for ( ; $J < count( $ITEM_ARRAY ); do
 {
 ++$J, } while ( 1 ) )
                {
                    if ( $ITEM_ARRAY[$J] == $VALUE_ARRAY[$I] )
                    {
                        $ARRAY_GDATA[$FIELDNO] = $NAME_ARRAY[$I];
                    }
                } while ( 1 );
            }
            $ARRAY_GDATA[$FIELDNO] = $ITEM_DATE;
        }
    }
    return $ARRAY_GDATA;
}

function proj_get_data_array_all( $TYPE_CODE_NO, $IDENTY_ID )
{
    $TYPE_CODE_NO = "G".$TYPE_CODE_NO;
    $ARRAY_GDATA = array( );
    $query = "SELECT * FROM PROJ_FIELDSETTING s, PROJ_FIELD_DATE d WHERE s.TYPE_CODE_NO='G' and s.FIELDNO=d.FIELDNO and d.TYPE_CODE_NO='".$TYPE_CODE_NO."' and d.IDENTY_ID = '{$IDENTY_ID}'";
    $cursor = exequery( ( ), $query );
    while ( $ROW = mysql_fetch_array( $cursor ) )
    {
        $FIELDNO = $ROW['FIELDNO'];
        $STYPE = $ROW['STYPE'];
        $FIELDNAME = $ROW['FIELDNAME'];
        $TYPENAME = $ROW['TYPENAME'];
        $TYPEVALUE = $ROW['TYPEVALUE'];
        $TYPECODE = $ROW['TYPECODE'];
        $ITEM_DATE = $ROW['ITEM_DATE'];
        if ( !( $STYPE == "C" ) && !( $STYPE == "R" ) && !( $STYPE == "D" ) || !( $TYPECODE == "" ) )
        {
            $ITEM_ARRAY = explode( ",", $ITEM_DATE );
            $NAME_ARRAY = explode( ",", $TYPENAME );
            $VALUE_ARRAY = explode( ",", $TYPEVALUE );
            $I = 0;
            for ( ; do
 {
 $I < count( $NAME_ARRAY ); }
 ++$I, } while ( 1 ) )
        {
            $J = 0;
            do
            {
                for ( ; $J < count( $ITEM_ARRAY ); do
 {
 ++$J, } while ( 1 ) )
                {
                    if ( $ITEM_ARRAY[$J] == $VALUE_ARRAY[$I] )
                    {
                        $ARRAY_GDATA[$FIELDNO] = $NAME_ARRAY[$I];
                    }
                } while ( 1 );
            }
            if ( $TYPECODE != "" )
            {
                $ARRAY_GDATA[$FIELDNO] = get_code_name( $ITEM_DATE, $TYPECODE );
            }
            else
            {
                $ARRAY_GDATA[$FIELDNO] = $ITEM_DATE;
            }
        }
    }
    return $ARRAY_GDATA;
}

function get_settings( )
{
    $ARRAY_SETTINGS = array( );
    $query = "SELECT * FROM PROJ_FIELDSETTING WHERE TYPE_CODE_NO='G' AND IS_SHOWLIST=1";
    $cursor = exequery( ( ), $query );
    while ( $ROW = mysql_fetch_array( $cursor ) )
    {
        $FIELDNO = $ROW['FIELDNO'];
        $FIELDNAME = $ROW['FIELDNAME'];
        $ARRAY_SETTINGS[] = array( "FIELDNO" => $FIELDNO, "FIELDNAME" => $FIELDNAME );
    }
    return $ARRAY_SETTINGS;
}

function get_all_settings( )
{
    $ARRAY_SETTINGS = array( );
    $query = "SELECT * FROM PROJ_FIELDSETTING WHERE TYPE_CODE_NO='G'";
    $cursor = exequery( ( ), $query );
    while ( $ROW = mysql_fetch_array( $cursor ) )
    {
        $FIELDNO = $ROW['FIELDNO'];
        $FIELDNAME = $ROW['FIELDNAME'];
        $ARRAY_SETTINGS[] = array( "FIELDNO" => $FIELDNO, "FIELDNAME" => $FIELDNAME );
    }
    return $ARRAY_SETTINGS;
}

function proj_get_field_lines( $data, $TYPE_CODE_NO )
{
    $title = get_field_title( $TYPE_CODE_NO );
    $lines = csv2array( $data, $title );
    $field = get_field_info( $TYPE_CODE_NO );
    $I = 0;
    for ( ; $I < count( $lines ); ++$I, } )
{
    do
    {
        do
        {
            if ( list( $key, $value ) = each( &$lines[$I] ) )
            {
                $value = str_replace( "��", ",", trim( $value ) );
                if ( !( $field[$key]['STYPE'] == "R" ) && !( $field[$key]['STYPE'] == "D" ) )
                {
                    $lines[$I][$key] = $field[$key]['CODE'][$value];
                }
            }
        } while ( 1 );
    } while ( !( $field[$key]['STYPE'] == "C" ) );
    $lines[$I][$key] = "";
    $name_array = explode( ",", $value );
    $J = 0;
    do
    {
        for ( ; $J < count( $name_array ); do
 {
 ++$J, } while ( 1 ) )
        {
            $name = $name_array[$J];
            if ( $name == "" )
            {
            }
            else
            {
                continue;
            }
            $lines[$I] .= $key;
        } while ( 1 );
    }
    return $lines;
}

function GET_SUB_TYPE_SELECT( $CODE_ID, $HTML_NAME, $PASS_CODE_ID = "", $PROJ_ID = "", $IS_DISABLE = "" )
{
    $query = "SELECT * FROM sys_code WHERE PARENT_NO ='".$CODE_ID."'";
    $cursor = exequery( ( ), $query );
    if ( $IS_DISABLE == "DISABLE" )
    {
        $query = "SELECT * FROM sys_code WHERE CODE_NO ='".$PASS_CODE_ID."'";
        $cursor = exequery( ( ), $query );
        $ROW = mysql_fetch_array( $cursor );
        $CODE_NAME = $ROW['CODE_NAME'];
        echo "<input type=\"hidden\" name=\"".$HTML_NAME."\" value=\"".$CODE_NO."\" />";
        echo "<input value=\"".$CODE_NAME."\" readOnly=\"true\" style=\"background-color:#FFF;border:1px;\" />";
    }
    else
    {
        echo "<select name=\"".$HTML_NAME."\" class=\"SmallSelect\" id=\"USER_CUST_DEFINE\" onChange=\"get_define_type(this.options[this.selectedIndex].value,PROJ_ID)\">";
        echo "<option value=\"\"></option>";
        while ( $ROW = mysql_fetch_array( $cursor ) )
        {
            $CODE_NO = $ROW['CODE_NO'];
            $CODE_NAME = $ROW['CODE_NAME'];
            $CODE_EXT = unserialize( $ROW['CODE_EXT'] );
            if ( is_array( $CODE_EXT ) && $CODE_EXT[MYOA_LANG_COOKIE] != "" )
            {
                $CODE_NAME = $CODE_EXT[MYOA_LANG_COOKIE];
            }
            if ( $PASS_CODE_ID == $CODE_NO )
            {
                echo "<option value=\"".$CODE_NO."\" selected>".$CODE_NAME."</option>";
            }
            else
            {
                echo "<option value=\"".$CODE_NO."\">".$CODE_NAME."</option>";
            }
        }
        echo "</select>";
    }
}

function get_code_name_plus( $CODE_ID, $PARENT_NO )
{
    if ( $CODE_ID == "" || $PARENT_NO == "" )
    {
        return "";
    }
    $POSTFIX = _( "��" );
    $query = "SELECT CODE_NAME from SYS_CODE where PARENT_NO='".$PARENT_NO."' and find_in_set(CODE_ID,'{$CODE_ID}')";
    $cursor = exequery( ( ), $query );
    while ( $ROW = mysql_fetch_array( $cursor ) )
    {
        $CODE_NAME = $ROW['CODE_NAME'];
        $CODE_EXT = unserialize( $ROW['CODE_EXT'] );
        if ( is_array( $CODE_EXT ) && $CODE_EXT[MYOA_LANG_COOKIE] != "" )
        {
            $CODE_NAME = $CODE_EXT[MYOA_LANG_COOKIE];
        }
        $CODE_NAME .= $CODE_NAME.$POSTFIX;
    }
    return substr( $CODE_NAME, 0, 0 - strlen( $POSTFIX ) );
}

include_once( "inc/utility_all.php" );
?>
