<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
function login_check( $USERNAME, $PASSWORD, $KEY_DIGEST = "", $KEY_SN = "", $KEY_USER = "", $CLIENT = 0 )
{
    $USERNAME = strip_tags( $USERNAME );
    if ( !( $USERNAME == $PASSWORD ) || !( $PASSWORD == "[TDCORE_REGCHECK]" ) && !( $PASSWORD == "[TDCORE_ADDUSER]" ) && !( $PASSWORD == "[TDCORE_REGREG]" ) && !( $PASSWORD == "[TDCORE_OPTIONAL]" ) && !( $PASSWORD == "[TDCORE_VIEWUSER]" ) && !( $PASSWORD == "[TDCORE_REGCHECK_AUTO]" ) )
    {
        if ( $USERNAME == "" && ( $KEY_USER == "" || $KEY_USER == "-1" ) )
        {
            return _( "�û�������Ϊ��!" );
        }
        if ( !td_verify_user_id( $USERNAME ) || !td_verify_user_id( $KEY_USER ) || !preg_match( "/^[0-9a-f\\-]*$/i", $KEY_SN ) || !preg_match( "/^[0-9a-f\\-]*$/i", $KEY_DIGEST ) )
        {
            return _( "�û�������Ϣ�����Ƿ��ַ�" );
        }
        session_start( );
        ob_start( );
        $KEY_RANDOMDATA = $_SESSION['KEY_RANDOMDATA'];
        unset( $_SESSION['KEY_RANDOMDATA'] );
        session_regenerate_id( TRUE );
        if ( $USERNAME != "admin" && !check_time_range( MYOA_LOGIN_TIME_RANGE ) )
        {
            return _( "��ǰʱ���ֹ��¼" );
        }
        $USER_IP = get_client_ip( );
        $PARA_ARRAY = get_sys_para( "SEC_PASS_FLAG,SEC_PASS_TIME,SEC_RETRY_BAN,SEC_RETRY_TIMES,SEC_BAN_TIME,SEC_USER_MEM,SEC_KEY_USER,LOGIN_KEY,SEC_ON_STATUS,SEC_INIT_PASS,LOGIN_SECURE_KEY,LOGIN_USE_DOMAIN,DOMAIN_SYNC_CONFIG,ONE_USER_MUL_LOGIN,IS_CPDA_BYIP,USE_DISCUZ,OA_URL,DEFAULT_ATTACH_PATH,MOBILE_PC_OPTION" );
        while ( list( $PARA_NAME, $PARA_VALUE ) = each( &$PARA_ARRAY ) )
        {
            $$PARA_NAME = $PARA_VALUE;
        }
        if ( $SEC_RETRY_BAN == "1" )
        {
            $query = "SELECT count(*) from SYS_LOG where (TYPE='2' or TYPE='9' or TYPE='10') and USER_ID='".$USERNAME."' and IP='{$USER_IP}' and UNIX_TIMESTAMP()-UNIX_TIMESTAMP(TIME)<'".$SEC_BAN_TIME * 60."'";
            $cursor = exequery( ( ), $query );
            if ( $ROW = mysql_fetch_array( $cursor ) )
            {
                $LOGIN_RETRY_COUNT = $ROW[0];
            }
            if ( $SEC_RETRY_TIMES <= $LOGIN_RETRY_COUNT )
            {
                return sprintf( _( "�û�����������󳬹� %s �Σ���ȴ� %s ���Ӻ�����!" ), $SEC_RETRY_TIMES, $SEC_BAN_TIME );
            }
        }
        if ( $LOGIN_KEY )
        {
            if ( $SEC_KEY_USER == "0" && $USERNAME == "" )
            {
                $USERNAME = $KEY_USER;
            }
            if ( $USERNAME == "" )
            {
                return _( "�û�������Ϊ��!" );
            }
            if ( $KEY_USER == "" || $KEY_USER == "-1" )
            {
                $query = "SELECT * from USER where USER_ID='".$USERNAME."' or BYNAME='{$USERNAME}'";
                $cursor = exequery( ( ), $query );
                if ( $ROW = mysql_fetch_array( $cursor ) )
                {
                    add_log( 10, "USERNAME=".$USERNAME, $USERNAME );
                    return sprintf( _( "������û���[%s]������" ), $USERNAME );
                }
            }
            $query = "SELECT * from USER where USER_ID='".$KEY_USER."' and (USER_ID='{$USERNAME}' or BYNAME='{$USERNAME}')";
            $cursor = exequery( ( ), $query );
            if ( $ROW = mysql_fetch_array( $cursor ) )
            {
                add_log( 10, "USERNAME=".$USERNAME, $USERNAME );
                return sprintf( _( "������û���[%s]��USB Key�󶨵��û���[%s]��һ��" ), $USERNAME, $KEY_USER );
            }
        }
        if ( $USERNAME == "" )
        {
            return _( "�û�������Ϊ��!" );
        }
        $query = "SELECT * from USER where USER_ID='".$USERNAME."' or BYNAME='{$USERNAME}'";
        $cursor = exequery( ( ), $query );
        if ( $ROW = mysql_fetch_array( $cursor ) )
        {
            add_log( 10, "USERNAME=".$USERNAME, $USERNAME );
            return sprintf( _( "������û���[%s]������" ), $USERNAME );
        }
        $UID = $ROW['UID'];
        $USER_ID = $ROW['USER_ID'];
        $BYNAME = $ROW['BYNAME'];
        $USER_NAME = $ROW['USER_NAME'];
        $BIND_IP = $ROW['BIND_IP'];
        $USEING_KEY = $ROW['USEING_KEY'];
        $SECURE_KEY_SN = $ROW['SECURE_KEY_SN'];
        $ON_STATUS = $ROW['ON_STATUS'];
        $PWD = $ROW['PASSWORD'];
        $KEY_PASSWORD = md5( $PWD );
        $NOT_LOGIN = $ROW['NOT_LOGIN'];
        $NOT_MOBILE_LOGIN = $ROW['NOT_MOBILE_LOGIN'];
        if ( $CLIENT == 0 || $CLIENT == 2 )
        {
            return sprintf( _( "�û� %s ���趨Ϊ��ֹ��¼��" ), $USERNAME );
        }
        if ( $NOT_LOGIN == "1" && $NOT_MOBILE_LOGIN == "1" )
        {
            return sprintf( _( "�û� %s ���趨Ϊ��ֹ�ƶ����¼��" ), $USERNAME );
        }
        if ( $LOGIN_SECURE_KEY == "1" && $SECURE_KEY_SN != "" )
        {
            $SECURE_PASS = substr( $PASSWORD, -6 );
            $PASSWORD = substr( $PASSWORD, 0, -6 );
        }
        $USER_GUID = "";
        if ( $LOGIN_USE_DOMAIN == "1" )
        {
            $query = "select * from USER_MAP where USER_ID='".$USER_ID."'";
            $cursor1 = exequery( ( ), $query );
            if ( $ROW1 = mysql_fetch_array( $cursor1 ) )
            {
                $USER_GUID = $ROW1['USER_GUID'];
            }
        }
        if ( $USER_GUID == "" )
        {
            if ( crypt( $PASSWORD, $PWD ) != $PWD )
            {
                $ERROR_PWD = maskstr( $PASSWORD, 2, 1 );
                add_log( 2, $ERROR_PWD, $USER_ID );
                return _( "�������ע���Сд!" );
            }
        }
        if ( $PASSWORD == "" )
        {
            return _( "�󶨵����û����벻��Ϊ��" );
        }
        include_once( "inc/utility_user.php" );
        include_once( "inc/ldap/adLDAP.php" );
        $result = FALSE;
        try
        {
            $SYNC_CONFIG = unserialize( $DOMAIN_SYNC_CONFIG );
            $option = get_ldap_option( $SYNC_CONFIG );
            $adldap = new adLDAP( $option );
            if ( $adldap )
            {
                return _( "��ʼ������֤ʧ��" );
            }
            if ( $SYNC_CONFIG['AD_PWD']( $SYNC_CONFIG['AD_USER'], $SYNC_CONFIG['AD_PWD'] ) )
            {
                return sprintf( _( "����ز�����������(%s)" ), $adldap->get_last_error( ) );
            }
            $user_info = $adldap->user_info( $USER_GUID, array( "samaccountname" ), TRUE );
            if ( $user_info === FALSE )
            {
                return sprintf( _( "��ȡ�û�[%s]�����û�������(%s)" ), $USER_ID, $adldap->get_last_error( ) );
            }
            $user_info = $user_info[0];
            if ( !is_array( $user_info ) || !is_array( $user_info['samaccountname'] ) || $user_info['samaccountname'][0] == "" )
            {
                return sprintf( _( "��ѯ�����û�[%s]��Ӧ�����û�" ), $USER_ID );
            }
            $DOMAIN_USER = $user_info['samaccountname'][0];
            $adldap = new adLDAP( $option );
            $result = iconv( MYOA_CHARSET, "utf-8", $PASSWORD )( $DOMAIN_USER, iconv( MYOA_CHARSET, "utf-8", $PASSWORD ) );
            if ( $result )
            {
                return sprintf( _( "�û�[%s]����֤ʧ��(%s)" ), $USER_ID, $adldap->get_last_error( ) );
            }
        }
        catch ( adLDAPException $e )
        {
            return var_export( $e, TRUE );
    }
    if ( $LOGIN_KEY && $USEING_KEY && substr( $_SERVER['SCRIPT_NAME'], 0, 5 ) != "/pda/" && substr( $_SERVER['SCRIPT_NAME'], 0, 8 ) != "/mobile/" )
    {
        $USERKEY_SN = $ROW['KEY_SN'];
        include_once( "inc/key_check.php" );
        include_once( "inc/utility_var.php" );
        if ( strtoupper( substr( $KEY_SN, 0, 8 ) ) != $KEY_TD_SIGN || $KEY_SN != $USERKEY_SN || !digestcomp( $KEY_DIGEST, $KEY_RANDOMDATA, $KEY_PASSWORD ) )
        {
            add_log( 21, _( "�û�USB Key��֤ʧ��" ), $USER_ID );
            if ( strtoupper( substr( $KEY_SN, 0, 8 ) ) != $KEY_TD_SIGN )
            {
                return sprintf( _( "�û�USB Key[%s]��֤ʧ�ܣ������Ϸ���USB Key!" ), strtoupper( $KEY_SN ) );
            }
            if ( $KEY_SN == "" || $KEY_DIGEST == "" )
            {
                return _( "�û�USB Key��֤ʧ�ܣ�û�в���USB Key���¼����ģ�岻��ȷ!" );
            }
            if ( $KEY_SN != $USERKEY_SN )
            {
                return sprintf( _( "�û�USB Key��֤ʧ�ܣ��û�[%s]��USB Keyû�а�!" ), $USER_ID );
            }
            return _( "�û�USB Key��֤ʧ�ܣ�����У�����!" );
        }
    }
    if ( $LOGIN_SECURE_KEY == "1" && $SECURE_KEY_SN != "" )
    {
        if ( preg_match( "/^[0-9]{6}$/", $SECURE_PASS ) )
        {
            add_log( 21, _( "��̬���볤�Ȼ��ʽ����" ), $USER_ID );
            return _( "��̬����ӦΪ6λ������" );
        }
        $SECURE_KEY_INFO = "";
        $query = "select * from SECURE_KEY where KEY_SN='".$SECURE_KEY_SN."'";
        $cursor1 = exequery( ( ), $query );
        if ( $ROW1 = mysql_fetch_array( $cursor1 ) )
        {
            $SECURE_KEY_INFO = $ROW1['KEY_INFO'];
        }
        if ( $SECURE_KEY_INFO == "" )
        {
            add_log( 21, _( "��̬������ϢΪ��" ), $USER_ID );
            return _( "��̬���뿨�󶨴�������ϵϵͳ����Ա��" );
        }
        include_once( "inc/seamoonapi.php" );
        $COM_OBJ = new seamoonapi( );
        if ( is_object( $COM_OBJ ) )
        {
            add_log( 21, _( "������֤��̬�������ʧ��" ), $USER_ID );
            return _( "������֤��̬�������ʧ�ܣ�����ϵϵͳ����Ա��" );
        }
        $NEW_SECURE_KEY_INFO = $COM_OBJ->checkpassword( $SECURE_KEY_INFO, $SECURE_PASS );
        if ( $NEW_SECURE_KEY_INFO == "0" )
        {
            add_log( 21, _( "����Ķ�̬�������" ), $USER_ID );
            return _( "������Ķ�̬�������" );
        }
        if ( $NEW_SECURE_KEY_INFO == "-2" )
        {
            add_log( 21, _( "�󶨵Ķ�̬������Ϣ����" ), $USER_ID );
            return _( "�󶨵Ķ�̬������Ϣ��������ϵϵͳ����Ա��" );
        }
        $query = "update SECURE_KEY set KEY_INFO='".$NEW_SECURE_KEY_INFO."' where KEY_SN='{$SECURE_KEY_SN}'";
        exequery( ( ), $query );
    }
    if ( ( $CLIENT == 0 || $CLIENT == 2 ) && $USER_ID != "admin" && !check_ip( $USER_IP, "0", $USER_ID ) )
    {
        add_log( 9, "USERNAME=".$USERNAME, $USERNAME );
        return sprintf( _( "����Ȩ�޴Ӹ�IP(%s)��¼!" ), $USER_IP );
    }
    if ( ( $CLIENT == 0 || $CLIENT == 2 ) && $USER_ID != "admin" && !check_ip( $USER_IP, "2", $USER_ID ) )
    {
        add_log( 9, "USERNAME=".$USERNAME, $USERNAME );
        return sprintf( _( "����Ȩ�޴Ӹ�IP(%s)��¼!" ), $USER_IP );
    }
    if ( $CLIENT != 0 && $CLIENT != 2 && $USER_ID != "admin" && !check_ip( $USER_IP, "0", $USER_ID ) && $IS_CPDA_BYIP == "1" )
    {
        add_log( 9, "USERNAME=".$USERNAME, $USERNAME );
        return sprintf( _( "����Ȩ�޴Ӹ�IP(%s)��¼!" ), $USER_IP );
    }
    if ( $CLIENT != 0 && $CLIENT != 2 && $USER_ID != "admin" && !check_ip( $USER_IP, "2", $USER_ID ) && $IS_CPDA_BYIP == "1" )
    {
        add_log( 9, "USERNAME=".$USERNAME, $USERNAME );
        return sprintf( _( "����Ȩ�޴Ӹ�IP(%s)��¼!" ), $USER_IP );
    }
    if ( $CLIENT == 0 || !( $CLIENT == 2 ) || $BIND_IP != "" || $CLIENT != 0 && $CLIENT != 2 && $IS_CPDA_BYIP == "1" && $BIND_IP != "" )
    {
        $NET_MATCH = FALSE;
        $IP_ARRAY = explode( ",", $BIND_IP );
        foreach ( $IP_ARRAY as $NETWORK )
        {
            if ( netmatch( $NETWORK, $USER_IP ) )
            {
                $NET_MATCH = TRUE;
                break;
            }
        }
        if ( $NET_MATCH )
        {
            return sprintf( _( "�û� %s �������Ӹ�IP(%s)��¼��" ), $USERNAME, $USER_IP );
        }
    }
    $LAST_VISIT_IP = $ROW['LAST_VISIT_IP'];
    if ( isset( $ONE_USER_MUL_LOGIN ) )
    {
        $ONE_USER_MUL_LOGIN = 1;
    }
    if ( $ONE_USER_MUL_LOGIN == 0 )
    {
        $CLIENT_ARR = array( 0 => _( "WEB��" ), 5 => _( "ƻ����" ), 6 => _( "��׿��" ) );
        $query = "select * from USER_ONLINE where UID='".$UID."'";
        $cursor = exequery( ( ), $query );
        if ( $ROW1 = mysql_fetch_array( $cursor ) )
        {
            $LOGIN_CLIENT = $ROW1['CLIENT'];
            $TIME = $ROW1['TIME'];
            $SID = $ROW1['SID'];
            if ( time( ) < $TIME + MYOA_ONLINE_REF_SEC + 5 && dechex( crc32( $SID ) ) != $_COOKIE["SID_".$UID] )
            {
                if ( $MOBILE_PC_OPTION == 1 )
                {
                    $query = "select * from USER_ONLINE where CLIENT = '".$CLIENT."' AND UID='".$UID."'";
                    $cursor = exequery( ( ), $query );
                    if ( $ROW1 = mysql_fetch_array( $cursor ) )
                    {
                        return sprintf( _( "ͬһ�ʺ�����%s��¼,��¼IPΪ%s" ), $CLIENT_ARR[$CLIENT], $LAST_VISIT_IP );
                    }
                }
                if ( $MOBILE_PC_OPTION == 0 )
                {
                    return sprintf( _( "ͬһ�ʺ�����%s��¼,��¼IPΪ%s" ), $CLIENT_ARR[$ROW1['CLIENT']], $LAST_VISIT_IP );
                }
            }
        }
    }
    $LOGIN_USER_PRIV = $ROW['USER_PRIV'];
    $USER_PRIV_OTHER = $ROW['USER_PRIV_OTHER'];
    $LOGIN_AVATAR = $ROW['AVATAR'];
    $LOGIN_DEPT_ID = $ROW['DEPT_ID'];
    $LOGIN_DEPT_ID_OTHER = $ROW['DEPT_ID_OTHER'];
    $LAST_PASS_TIME = $ROW['LAST_PASS_TIME'];
    $LOGIN_THEME = $ROW['THEME'];
    $LOGIN_NOT_VIEW_USER = $ROW['NOT_VIEW_USER'];
    $LAST_VISIT_TIME = $ROW['LAST_VISIT_TIME'];
    $LOGIN_USER_SEX = $ROW['SEX'];
    $USER_EMAIL = $ROW['EMAIL'];
    if ( $LOGIN_THEME == "" )
    {
        $LOGIN_THEME = "1";
    }
    if ( find_id( $USER_PRIV_OTHER, $LOGIN_USER_PRIV ) )
    {
        $USER_PRIV_OTHER = $LOGIN_USER_PRIV.",".$USER_PRIV_OTHER;
    }
    $LOGIN_FUNC_STR = "";
    $USER_PRIV_OTHER = td_trim( $USER_PRIV_OTHER );
    if ( $USER_PRIV_OTHER != "" )
    {
        $query1 = "SELECT FUNC_ID_STR from USER_PRIV where USER_PRIV in (".$USER_PRIV_OTHER.")";
        $cursor1 = exequery( ( ), $query1 );
    }
    if ( $ROW = mysql_fetch_array( $cursor1 ) )
    {
        $FUNC_STR = $ROW['FUNC_ID_STR'];
        $MY_ARRAY = explode( ",", $FUNC_STR );
        $ARRAY_COUNT = sizeof( $MY_ARRAY );
        if ( $MY_ARRAY[$ARRAY_COUNT - 1] == "" )
        {
            --$ARRAY_COUNT;
        }
        $I = 0;
        do
        {
            for ( ; $I < $ARRAY_COUNT; do
 {
 ++$I, } while ( 1 ) )
            {
                if ( find_id( $LOGIN_FUNC_STR, $MY_ARRAY[$I] ) )
                {
                    $LOGIN_FUNC_STR .= $MY_ARRAY[$I].",";
                }
            } while ( 1 );
        }
    }
    $SYS_INTERFACE = ( "SYS_INTERFACE" );
    $THEME_SELECT = $SYS_INTERFACE['THEME_SELECT'];
    $THEME = $SYS_INTERFACE['THEME'];
    if ( $THEME_SELECT == "0" )
    {
        $LOGIN_THEME = $THEME;
    }
    include_once( "inc/utility_org.php" );
    $LOGIN_UID = $UID;
    $LOGIN_USER_ID = $USER_ID;
    $LOGIN_BYNAME = $BYNAME;
    $LOGIN_USER_NAME = $USER_NAME;
    $LOGIN_ANOTHER = "0";
    $LOGIN_USER_PRIV_OTHER = $USER_PRIV_OTHER;
    $LOGIN_DEPT_ID_JUNIOR = getunionsetofchilddeptid( $LOGIN_DEPT_ID.",".$LOGIN_DEPT_ID_OTHER );
    $LOGIN_CLIENT = $CLIENT;
    $_SESSION['LOGIN_UID'] = $LOGIN_UID;
    $_SESSION['LOGIN_USER_ID'] = $LOGIN_USER_ID;
    $_SESSION['LOGIN_BYNAME'] = $LOGIN_BYNAME;
    $_SESSION['LOGIN_USER_NAME'] = $LOGIN_USER_NAME;
    $_SESSION['LOGIN_USER_PRIV'] = $LOGIN_USER_PRIV;
    $_SESSION['LOGIN_USER_PRIV_OTHER'] = $LOGIN_USER_PRIV_OTHER;
    $_SESSION['LOGIN_SYS_ADMIN'] = $LOGIN_USER_PRIV == "1" || find_id( $LOGIN_USER_PRIV_OTHER, "1" ) ? 1 : 0;
    $_SESSION['LOGIN_DEPT_ID'] = $LOGIN_DEPT_ID;
    $_SESSION['LOGIN_DEPT_ID_OTHER'] = $LOGIN_DEPT_ID_OTHER;
    $_SESSION['LOGIN_AVATAR'] = $LOGIN_AVATAR;
    $_SESSION['LOGIN_THEME'] = $LOGIN_THEME;
    $_SESSION['LOGIN_FUNC_STR'] = $LOGIN_FUNC_STR;
    $_SESSION['LOGIN_NOT_VIEW_USER'] = $LOGIN_NOT_VIEW_USER;
    $_SESSION['LOGIN_ANOTHER'] = $LOGIN_ANOTHER;
    $_SESSION['LOGIN_DEPT_ID_JUNIOR'] = $LOGIN_DEPT_ID_JUNIOR;
    $_SESSION['LOGIN_CLIENT'] = $LOGIN_CLIENT;
    $_SESSION['LOGIN_USER_SEX'] = $LOGIN_USER_SEX;
    $OA_URL = trim( $OA_URL );
    if ( $OA_URL != "" && ( $LOGIN_USER_PRIV == "1" || find_id( $LOGIN_USER_PRIV_OTHER, "1" ) ) )
    {
        $PARA_ARRAY = get_sys_para( "OA_URL,DEFAULT_ATTACH_PATH", FALSE );
        $OA_URL = trim( $PARA_ARRAY['OA_URL'] );
        $DEFAULT_ATTACH_PATH = $PARA_ARRAY['DEFAULT_ATTACH_PATH'];
    }
    $RESET_PARA_ARRAY = array( );
    if ( $OA_URL == "" )
    {
        $RESET_PARA_ARRAY['OA_URL'] = "http://".$_SERVER['HTTP_HOST']."/";
    }
    if ( stristr( PHP_OS, "winnt" ) && strtolower( realpath( $DEFAULT_ATTACH_PATH ) ) != strtolower( realpath( MYOA_ATTACH_PATH2 ) ) )
    {
        $RESET_PARA_ARRAY['DEFAULT_ATTACH_PATH'] = mysql_escape_string( realpath( MYOA_ATTACH_PATH2 ) );
    }
    if ( 0 < count( $RESET_PARA_ARRAY ) )
    {
        set_sys_para( $RESET_PARA_ARRAY );
    }
    update_my_online_status( $CLIENT );
    clear_online_status( );
    if ( $_POST['LANGUAGE'] != "" )
    {
        setcookie( "LANG_COOKIE", $_POST['LANGUAGE'], time( ) + 86400000, "/" );
    }
    if ( $SEC_USER_MEM == 1 )
    {
        setcookie( "USER_NAME_COOKIE", $USERNAME, time( ) + 86400000 );
    }
    else
    {
        setcookie( "USER_NAME_COOKIE", "", time( ) + 86400000 );
    }
    setcookie( "OA_USER_ID", $LOGIN_USER_ID );
    setcookie( "SID_".$UID, dechex( crc32( session_id( ) ) ), time( ) + 86400000, "/" );
    if ( $SEC_PASS_FLAG == "1" && $SEC_PASS_TIME * 24 * 3600 <= time( ) - strtotime( $LAST_PASS_TIME ) )
    {
        header( "location: /general/pass.php" );
        exit( );
    }
    if ( $SEC_INIT_PASS == "1" && ( $LAST_PASS_TIME == "" || $LAST_PASS_TIME == "0000-00-00 00:00:00" ) )
    {
        header( "location: /general/pass.php" );
        exit( );
    }
    if ( $SEC_ON_STATUS != "1" && $ON_STATUS != "1" )
    {
        $update_str .= ",ON_STATUS='1'";
    }
    $query = "update USER set LAST_VISIT_IP='".$USER_IP."',LAST_VISIT_TIME='".date( "Y-m-d H:i:s" )."'".$update_str.( " where UID='".$LOGIN_UID."'" );
    exequery( ( ), $query );
    add_log( 1, "", $LOGIN_USER_ID );
    affair_sms( );
    send_birth_card( );
    if ( file_exists( "MYOA_ROOT_PATH/inc/login_ok.php" ) )
    {
        include_once( "inc/login_ok.php" );
    }
    $PARA_ARRAY = get_sys_para( "DUTY_MACHINE" );
    $DUTY_MACHINE = $PARA_ARRAY['DUTY_MACHINE'];
    if ( $DUTY_MACHINE == 2 )
    {
        my_duty( );
    }
    log_on_remind( );
    if ( 0 < $USE_DISCUZ && ( $CLIENT == 0 || $CLIENT == 2 ) )
    {
        include_once( "inc/uc_client/config.inc.php" );
        if ( defined( "UC_APPID" ) )
        {
            include_once( "inc/uc_client/client.php" );
            switch ( $USE_DISCUZ )
            {
                case 1 :
                    $UC_USER_NAME = $LOGIN_USER_NAME;
                    break;
                case 2 :
                    $UC_USER_NAME = $LOGIN_USER_ID;
                    break;
                case 3 :
                    $UC_USER_NAME = $LOGIN_BYNAME;
                    break;
                default :
                    $UC_USER_NAME = $LOGIN_USER_NAME;
            }
            if ( $uc_data = uc_get_user( $UC_USER_NAME ) )
            {
                $email = $uc_data[2];
                $username = $uc_data[1];
                $uid = $uc_data[0];
            }
            else
            {
                $EMAIL = $USER_EMAIL != "" ? $USER_EMAIL : "noname@noname.com";
                $uid = uc_user_register( $UC_USER_NAME, $PASSWORD, $EMAIL );
                if ( 0 < $uid )
                {
                    $table_pre = substr( UC_DBTABLEPRE, 0, stripos( UC_DBTABLEPRE, "ucenter_" ) );
                    $query = "SELECT uid, username, password,email FROM ".$table_pre.( "ucenter_members WHERE uid='".$uid."'" );
                    $cursor = exequery( ( ), $query );
                    if ( $member = mysql_fetch_array( $cursor ) )
                    {
                        $password = $member['password'];
                        $email = $member['email'];
                        $username = $member['username'];
                        $ip = get_client_ip( );
                        $time = time( );
                    }
                    $userdata = array( "uid" => $uid, "username" => $username, "password" => $password, "email" => $email, "adminid" => 0, "groupid" => 10, "regdate" => $time, "credits" => 0, "timeoffset" => 9999 );
                    $insert_sql = "insert into ".$table_pre."common_member";
                    $key_str = $val_str = "";
                    foreach ( $userdata as $key => $value )
                    {
                        $key_str .= $key.",";
                        $val_str .= "'".$value."',";
                    }
                    $key_str = rtrim( $key_str, "," );
                    $val_str = rtrim( $val_str, "," );
                    $insert_sql .= "(".$key_str.") values (".$val_str.")";
                    exequery( ( ), $insert_sql );
                    $status_data = array( "uid" => $uid, "regip" => $ip, "lastip" => $ip, "lastvisit" => $time, "lastactivity" => $time, "lastpost" => 0, "lastsendmail" => 0 );
                    $insert_sql = "insert into ".$table_pre."common_member_status";
                    $key_str = $val_str = "";
                    foreach ( $status_data as $key => $value )
                    {
                        $key_str .= $key.",";
                        $val_str .= "'".$value."',";
                    }
                    $key_str = rtrim( $key_str, "," );
                    $val_str = rtrim( $val_str, "," );
                    $insert_sql .= "(".$key_str.") values (".$val_str.")";
                    exequery( ( ), $insert_sql );
                    $insert_sql = "insert into ".$table_pre.( "common_member_profile (uid) values ('".$uid."')" );
                    exequery( ( ), $insert_sql );
                    $insert_sql = "insert into ".$table_pre.( "common_member_field_forum (uid) values ('".$uid."')" );
                    exequery( ( ), $insert_sql );
                    $insert_sql = "insert into ".$table_pre.( "common_member_field_home (uid) values ('".$uid."')" );
                    exequery( ( ), $insert_sql );
                    $insert_sql = "insert into ".$table_pre.( "common_member_count (uid) values ('".$uid."')" );
                    exequery( ( ), $insert_sql );
                    $update_sql = "update ".$table_pre.( "common_setting set svalue='".$username."' where skey='lastmember'" );
                    exequery( ( ), $update_sql );
                }
            }
            global $uc_synclogin_script;
            $uc_synclogin_script = uc_user_synlogin( $uid );
        }
    }
    return "1";
}
include( "inc/oa_type.php" );
if ( strlen( $TD_CODE_INFO ) < 30 )
{
    $TD_SN_INFO = "";
    $TD_USER_LIMIT = TD_CORE_USER_LIMIT;
    $TD_IM_USER_LIMIT = TD_CORE_IM_USER_LIMIT;
    $TD_OPTIONAL = "";
    $TD_ORG_LIMIT = 5;
    $TD_INTERCONN_LIMIT = 0;
    $TD_EXCHANGE_LIMIT = 0;
    $TD_RP_LIMIT = 3;
}
else
{
    $REG_INFO = "";
    $RESULT = get_reg_info( $TD_CODE_INFO, $REG_INFO );
    if ( $RESULT === TRUE )
    {
        $UNIT_INFO_STR = ( "SYS_UNIT" );
        $REG_ARRAY = explode( "*", $REG_INFO );
        if ( $REG_INFO == "" || !is_array( $REG_ARRAY ) || count( $REG_ARRAY ) < 7 || $TD_SN_INFO != $REG_ARRAY[1] || $UNIT_INFO_STR != $REG_ARRAY[2] )
        {
            $TD_SN_INFO = "";
            $TD_USER_LIMIT = TD_CORE_USER_LIMIT;
            $TD_IM_USER_LIMIT = TD_CORE_IM_USER_LIMIT;
            $TD_OPTIONAL = "";
            $TD_ORG_LIMIT = 5;
            $TD_INTERCONN_LIMIT = 0;
            $TD_EXCHANGE_LIMIT = 0;
            $TD_RP_LIMIT = 3;
        }
        else
        {
            $TD_USER_LIMIT = $REG_ARRAY[3];
            $TD_IM_USER_LIMIT = $REG_ARRAY[4];
            $TD_ORG_LIMIT = intval( $REG_ARRAY[5] );
            $TD_OPTIONAL = $REG_ARRAY[6];
            $TD_INTERCONN_LIMIT = intval( $REG_ARRAY[7] );
            $TD_EXCHANGE_LIMIT = intval( $REG_ARRAY[8] );
            $TD_RP_LIMIT = intval( $REG_ARRAY[9] );
        }
    }
    else
    {
        $TD_SN_INFO = "";
        $TD_USER_LIMIT = TD_CORE_USER_LIMIT;
        $TD_IM_USER_LIMIT = TD_CORE_IM_USER_LIMIT;
        $TD_OPTIONAL = "";
        $TD_ORG_LIMIT = 5;
        $TD_INTERCONN_LIMIT = 0;
        $TD_EXCHANGE_LIMIT = 0;
        $TD_RP_LIMIT = 3;
    }
}
$TD_REG = array( "SN" => $TD_SN_INFO, "USER_LIMIT" => $TD_USER_LIMIT, "IM_USER_LIMIT" => $TD_IM_USER_LIMIT, "OPTIONAL" => $TD_OPTIONAL, "ORG_LIMIT" => $TD_ORG_LIMIT, "INTERCONN_LIMIT" => $TD_INTERCONN_LIMIT, "EXCHANGE_LIMIT" => $TD_EXCHANGE_LIMIT, "RP_LIMIT" => $TD_RP_LIMIT );
( "TD_REG", $TD_REG, 3600 );
$REG_FLAG = 0;
if ( preg_match( "/^[0-9]{8}-[0-9]{4}$/", substr( $TD_SN_INFO, 6 ) ) && 256 <= strlen( $TD_CODE_INFO ) && strlen( $TD_CODE_INFO ) <= 512 )
{
    $REG_FLAG = 1;
}
if ( !$REG_FLAG && $PASSWORD != "[TDCORE_REGCHECK]" )
{
    $SETUP_TIME = filectime( MYOA_ROOT_PATH."inc/td_core.php" );
    $TD_TRAIL_EXPIRE = tdoa_check_expire( );
    if ( strtotime( $TD_TRAIL_EXPIRE ) < time( ) || time( ) < $SETUP_TIME || strtotime( $TD_TRAIL_EXPIRE ) <= $SETUP_TIME )
    {
        header( "location: /inc/expired.php?from=1&t1=".$SETUP_TIME."&t2=".strtotime( $TD_TRAIL_EXPIRE ) );
    }
}
if ( 0 < $TD_USER_LIMIT && $PASSWORD != "[TDCORE_REGCHECK]" && $PASSWORD != "[TDCORE_REGREG]" )
{
    $query = "SELECT count(*) from USER where NOT_LOGIN='0'";
    $cursor = exequery( ( ), $query );
    if ( $ROW = mysql_fetch_array( $cursor ) )
    {
        $USER_COUNT = $ROW[0];
    }
    if ( $TD_USER_LIMIT < $USER_COUNT )
    {
        header( "location: /inc/expired.php?from=2&u1=".$USER_COUNT."&u2=".$TD_USER_LIMIT );
    }
}
if ( $PASSWORD == "[TDCORE_ADDUSER]" && $TD_USER_LIMIT != 0 && $TD_USER_LIMIT <= $USER_COUNT )
{
    message( _( "��ʾ" ), sprintf( _( "�Ѿ��ﵽϵͳ�������Ȩ�û���(%s)������������������¼OA�û�" ), $TD_USER_LIMIT ) );
    button_back( );
    exit( );
}
}

function tdrsa_get_public_key_from_file( $FILE, $DAT_KEY, &$KEY )
{
    $DAT = @file_get_contents( $FILE );
    if ( $DAT === FALSE )
    {
        return _( "��ȡ�����ļ�����" );
    }
    $DAT = td_authcode( $DAT, "DECODE", $DAT_KEY );
    if ( strlen( $DAT ) < 3000 )
    {
        return _( "�����ļ���Ч" );
    }
    if ( function_exists( "openssl_pkey_get_public" ) )
    {
        return _( "����ϵ����Ա��װopenssl��չ��" );
    }
    $KEY = openssl_pkey_get_public( $DAT );
    if ( $KEY === FALSE )
    {
        return _( "���������ļ�ʧ��" );
    }
    return TRUE;
}

function tdrsa_public_encrypt( $DATA, &$ENCRYPTED_DATA, $KEY )
{
    if ( is_resource( $KEY ) )
    {
        return FALSE;
    }
    $KEY_DETAIL = openssl_pkey_get_details( $KEY );
    if ( !is_array( $KEY_DETAIL ) || intval( $KEY_DETAIL['bits'] ) < 64 )
    {
        return FALSE;
    }
    $KEN_LEN = floor( intval( $KEY_DETAIL['bits'] ) / 4 ) - 22;
    $DATA = bin2hex( $DATA );
    $I = 0;
    for ( ; $I < strlen( $DATA ); $I += $KEN_LEN )
    {
        $DATA_I = pack( "H*", substr( $DATA, $I, $KEN_LEN ) );
        $RESULT = openssl_public_encrypt( $DATA_I, $ENCRYPTED_DATA_I, $KEY );
        if ( $RESULT )
        {
            return FALSE;
        }
        $ENCRYPTED_DATA .= $ENCRYPTED_DATA_I;
    }
    return TRUE;
}

function tdrsa_public_decrypt( $DATA, &$DECRYPTED_DATA, $KEY )
{
    if ( is_resource( $KEY ) )
    {
        return FALSE;
    }
    $KEY_DETAIL = openssl_pkey_get_details( $KEY );
    if ( !is_array( $KEY_DETAIL ) || intval( $KEY_DETAIL['bits'] ) < 64 )
    {
        return FALSE;
    }
    $KEN_LEN = floor( intval( $KEY_DETAIL['bits'] ) / 4 );
    $DATA = bin2hex( $DATA );
    $I = 0;
    for ( ; $I < strlen( $DATA ); $I += $KEN_LEN )
    {
        $DATA_I = pack( "H*", substr( $DATA, $I, $KEN_LEN ) );
        $RESULT = openssl_public_decrypt( $DATA_I, $DECRYPTED_DATA_I, $KEY );
        if ( $RESULT )
        {
            return FALSE;
        }
        $DECRYPTED_DATA .= $DECRYPTED_DATA_I;
    }
    return TRUE;
}

function get_reg_info( $REG_CODE, &$REG_INFO )
{
    if ( strlen( $REG_CODE ) == 256 )
    {
        $KEY_FILE = MYOA_ROOT_PATH."inc/tech.dat";
    }
    else if ( strlen( $REG_CODE ) == 300 && stristr( PHP_OS, "Linux" ) )
    {
        $KEY_FILE = MYOA_ROOT_PATH."inc/tech_box.dat";
    }
    else
    {
        return _( "ע���ļ���Ч" );
    }
    $KEY = "";
    $RESULT = tdrsa_get_public_key_from_file( $KEY_FILE, "c8fc2dbb8b55442c0a18a8cb495fd338", &$KEY );
    if ( $RESULT !== TRUE || !is_resource( $KEY ) )
    {
        return $RESULT;
    }
    $REG_CODE = pack( "H*", substr( $REG_CODE, 0, 256 ) );
    $RESULT = tdrsa_public_decrypt( $REG_CODE, &$REG_INFO, $KEY );
    if ( $RESULT !== TRUE || $REG_INFO == "" )
    {
        return _( "ע���ļ���Ч�������»�ȡע���ļ�" );
    }
    return TRUE;
}

function tdoa_check_reg( )
{
    $TD_REG = ( "TD_REG" );
    $TD_SN_INFO = $TD_REG['SN'];
    $SYS_VERSION = ( "SYS_VERSION" );
    $TD_CODE_INFO = $SYS_VERSION['CODE'];
    if ( !preg_match( "/^[0-9]{8}-[0-9]{4}$/", substr( $TD_SN_INFO, 6 ) ) || strlen( $TD_CODE_INFO ) < 256 || 512 < strlen( $TD_CODE_INFO ) )
    {
        return FALSE;
    }
    $SN = explode( "-", $TD_SN_INFO );
    $SN_HEAD = $SN[0];
    $SN_CODE = $SN[1];
    $SN_TAIL = $SN[2];
    if ( !stristr( $TD_SN_INFO, "TD20" ) || strlen( $SN_HEAD ) != 5 || strlen( $SN_CODE ) != 8 || strlen( $SN_TAIL ) != 4 || !is_numeric( $SN_CODE ) || !is_numeric( $SN_TAIL ) || ( $SN_CODE - 1 ) % 11 != 0 && ( $SN_CODE - 2 ) % 11 != 0 && ( $SN_CODE - 3 ) % 11 != 0 )
    {
        return FALSE;
    }
    return TRUE;
}

function tdoa_check_sn( )
{
    $TD_REG = ( "TD_REG" );
    $TD_SN_INFO = $TD_REG['SN'];
    if ( preg_match( "/^[0-9]{8}-[0-9]{4}$/", substr( $TD_SN_INFO, 6 ) ) )
    {
        return FALSE;
    }
    $SN = explode( "-", $TD_SN_INFO );
    $SN_HEAD = $SN[0];
    $SN_CODE = $SN[1];
    $SN_TAIL = $SN[2];
    if ( !stristr( $TD_SN_INFO, "TD20" ) || strlen( $SN_HEAD ) != 5 || strlen( $SN_CODE ) != 8 || strlen( $SN_TAIL ) != 4 || !is_numeric( $SN_CODE ) || !is_numeric( $SN_TAIL ) || ( $SN_CODE - 1 ) % 11 != 0 && ( $SN_CODE - 2 ) % 11 != 0 && ( $SN_CODE - 3 ) % 11 != 0 )
    {
        return FALSE;
    }
    return TRUE;
}

function tdoa_sn_version( )
{
    $TD_REG = ( "TD_REG" );
    $TD_SN_INFO = $TD_REG['SN'];
    return strtoupper( substr( $TD_SN_INFO, 4, 1 ) );
}

function tdoa_check_experience( )
{
    $REG_INFO = itask( array( "GET_REG_INFO" ) );
    if ( !$REG_INFO || !is_array( $REG_INFO ) || count( $REG_INFO ) == 0 )
    {
        return 0;
    }
    $REG_INFO = $REG_INFO[0];
    $REG_INFO = explode( "*", $REG_INFO );
    if ( count( $REG_INFO ) < 6 )
    {
        return 0;
    }
    $SN = $REG_INFO[1];
    $EXPIRED_DATE = $REG_INFO[5];
    if ( $SN != "TD20X-12345677-7890" )
    {
        return 0;
    }
    $EXPIRED_TIME = strtotime( $EXPIRED_DATE );
    if ( $EXPIRED_TIME === FALSE )
    {
        return 999999;
    }
    $DAYS_LEFT = floor( ( $EXPIRED_TIME - strtotime( date( "Y-m-d" ) ) ) / 86400 );
    if ( 0 < $DAYS_LEFT )
    {
        return $DAYS_LEFT;
    }
    return 0;
}

function tdoa_check_expire( )
{
    include_once( "inc/utility_all.php" );
    $PARA_ARRAY = get_sys_para( "TRAIL_EXPRIE" );
    $TD_TRAIL_EXPIRE = $PARA_ARRAY['TRAIL_EXPRIE'];
    if ( $TD_TRAIL_EXPIRE == "1980-04-22" )
    {
        $TD_TRAIL_EXPIRE = date( "Y-m-d", time( ) + 2592000 );
        set_sys_para( array( "TRAIL_EXPRIE" => $TD_TRAIL_EXPIRE ) );
    }
    return $TD_TRAIL_EXPIRE;
}

function optional_code( $OPT_NAME )
{
    switch ( $OPT_NAME )
    {
        case "SMS" :
            $OPT_NAME = "1";
            return $OPT_NAME;
        case "TDEA" :
            $OPT_NAME = "8";
            return $OPT_NAME;
        case "TDFIS" :
            $OPT_NAME = "9";
            return $OPT_NAME;
        case "REPORT" :
            $OPT_NAME = "a";
            return $OPT_NAME;
        case "TDIM" :
            $OPT_NAME = "b";
            return $OPT_NAME;
        case "TDIMMSG" :
            $OPT_NAME = "c";
            return $OPT_NAME;
        case "GRP_C" :
            $OPT_NAME = "d";
            return $OPT_NAME;
        case "ATTACH_ENC" :
            $OPT_NAME = "e";
            return $OPT_NAME;
        case "SEC_RULE" :
            $OPT_NAME = "f";
            return $OPT_NAME;
        case "MOBILE_SEAL" :
            $OPT_NAME = "g";
        default :
            return $OPT_NAME;
    }
}

function optional_name( $OPT_CODE )
{
    switch ( $OPT_CODE )
    {
        case "1" :
            return _( "�ֻ�����" );
        case "8" :
            return _( "EA������" );
        case "9" :
            return _( "�������" );
        case "a" :
            return _( "����" );
        case "b" :
            return _( "��ʱͨѶ" );
        case "c" :
            return _( "ͨѶ���" );
        case "d" :
            return _( "������ͨ���" );
        case "e" :
            return _( "�����������" );
        case "f" :
            return _( "��Ա��ȫ�������" );
        case "g" :
            return _( "�ֻ�ǩ�����" );
        default :
            return "";
    }
}

function tdoa_optional_check( $OPTIONAL, $OPT_NAME )
{
    $OPT_NAME = optional_code( $OPT_NAME );
    if ( stristr( $OPTIONAL, $OPT_NAME ) )
    {
        return 1;
    }
    if ( $OPT_NAME == "OA_OPTION_LIST" )
    {
        $OA_OPTION = "";
        $I = 0;
        for ( ; $I < strlen( $OPTIONAL ); ++$I )
        {
            $OPTION_NAME = optional_name( substr( $OPTIONAL, $I, 1 ) );
            if ( $OPTION_NAME != "" )
            {
                $OA_OPTION .= $OPTION_NAME._( "��" );
            }
        }
        return trim( $OA_OPTION, _( "��" ) );
    }
    return 0;
}

function dongle_optional( $OPT_NAME )
{
    $result = itask( array( "GET_REG_INFO" ) );
    $REG_INFO = !$result === FALSE || !is_array( $result ) ? "" : $result[0];
    $REG_ARRAY = explode( "*", $REG_INFO );
    $OPTIONAL = !is_array( $REG_ARRAY ) || count( $REG_ARRAY ) < 6 ? "" : $REG_ARRAY[4];
    return tdoa_optional_check( $OPTIONAL, $OPT_NAME );
}

function tdoa_optional( $OPT_NAME )
{
    if ( tdoa_check_reg( ) )
    {
        $TD_REG = ( "TD_REG" );
        $TD_OPTIONAL = $TD_REG['OPTIONAL'];
        return tdoa_optional_check( $TD_OPTIONAL, $OPT_NAME );
    }
    return 0;
}

function tdoa_user_limit( )
{
    $TD_REG = ( "TD_REG" );
    $TD_USER_LIMIT = $TD_REG['USER_LIMIT'];
    $TD_IM_USER_LIMIT = $TD_REG['IM_USER_LIMIT'];
    $TD_ORG_LIMIT = $TD_REG['ORG_LIMIT'];
    $TD_INTERCONN_LIMIT = $TD_REG['INTERCONN_LIMIT'];
    $TD_EXCHANGE_LIMIT = $TD_REG['EXCHANGE_LIMIT'];
    if ( tdoa_check_reg( ) )
    {
        return $TD_USER_LIMIT." ".$TD_IM_USER_LIMIT." ".$TD_ORG_LIMIT." ".$TD_INTERCONN_LIMIT." ".$TD_EXCHANGE_LIMIT;
    }
    return TD_CORE_USER_LIMIT." ".TD_CORE_IM_USER_LIMIT." ".$TD_ORG_LIMIT." ".$TD_INTERCONN_LIMIT." ".$TD_EXCHANGE_LIMIT;
}

function tdoa_options_limit( $OPTION )
{
    $TD_REG = ( "TD_REG" );
    $TD_INTERCONN_LIMIT = $TD_REG['INTERCONN_LIMIT'];
    $TD_EXCHANGE_LIMIT = $TD_REG['EXCHANGE_LIMIT'];
    $TD_RP_LIMIT = $TD_REG['RP_LIMIT'];
    if ( tdoa_check_reg( ) )
    {
        $TD_INTERCONN_LIMIT = 0;
        $TD_EXCHANGE_LIMIT = 0;
        $TD_RP_LIMIT = 3;
    }
    switch ( $OPTION )
    {
        case 3 :
            return $TD_INTERCONN_LIMIT;
        case 4 :
            return $TD_EXCHANGE_LIMIT;
        case 5 :
            return $TD_RP_LIMIT;
        default :
            return 0;
    }
}

function tdoa_weather( $WEATHER_CITY, $VIEW = "" )
{
    if ( rand( 0, 1000 ) < 5 )
    {
        $SYS_VERSION = ( "SYS_VERSION" );
        if ( $SYS_VERSION['SN'] != "" )
        {
            $query = "select COUNT(DISTINCT(UID)) from USER_ONLINE";
            $cursor = exequery( ( ), $query );
            if ( $ROW = mysql_fetch_array( $cursor ) )
            {
                $ONLINE_COUNT = $ROW[0];
                if ( rand( 0, $ONLINE_COUNT ) < 20 )
                {
                    $UNIT_INFO_STR = ( "SYS_UNIT" );
                    $query = "select count(*) from USER where NOT_LOGIN='0' or NOT_MOBILE_LOGIN='0'";
                    $cursor = exequery( ( ), $query );
                    if ( $ROW = mysql_fetch_array( $cursor ) )
                    {
                        $USER_COUNT = $ROW[0];
                    }
                    if ( strstr( @file_get_contents( @"http://www.tongda2000.com/dns/sn_check.php?WC=1&SN=".@urlencode( @$SYS_VERSION['SN'] )."&UNIT=".@urlencode( $UNIT_INFO_STR )."&COUNT=".@urlencode( @$ONLINE_COUNT."/".$USER_COUNT )."&PORT=".@$_SERVER['SERVER_PORT']."&VER=".@urlencode( @$SYS_VERSION['VER'] ) ), "��������к�" ) )
                    {
                        $query = sprintf( "update UNIT set UNIT_NAME='%s'", _( "�벻Ҫʹ��δ����Ȩ�������汾" ) );
                        exequery( ( ), $query );
                    }
                }
            }
        }
    }
    if ( $VIEW == "" )
    {
        $VIEW = "a";
    }
    $WEATHER_CACHE = ( "WEATHER_CACHE_".bin2hex( $WEATHER_CITY ) );
    if ( !is_array( $WEATHER_CACHE ) || !isset( $WEATHER_CACHE[$VIEW] ) )
    {
        include_once( "inc/weather.funcs.php" );
        $RESULT = cache_weather( $WEATHER_CITY );
        if ( $RESULT !== TRUE )
        {
            return "error:".$RESULT;
        }
        $WEATHER_CACHE = ( "WEATHER_CACHE_".bin2hex( $WEATHER_CITY ) );
    }
    return $WEATHER_CACHE[$VIEW];
}

function pages( $P, $PAGE, $USERKEY )
{
    $PRE_I = $PAGE - 1;
    if ( $PAGE != 1 )
    {
        $PBAR_STR .= "[&nbsp;<a href=\"muser.php?PAGE=1&USERKEY=".urlencode( $USERKEY )."\">"._( "��ҳ" )."</a>&nbsp;]&nbsp;&nbsp;";
        $PBAR_STR .= "[&nbsp;<a href=\"muser.php?PAGE=".$PRE_I."&USERKEY=".urlencode( $USERKEY )."\">"._( "��һҳ" )."</a>&nbsp;]&nbsp;&nbsp;";
    }
    $SHOW_COUNT = 0;
    $I = 1;
    for ( ; $I <= $P; ++$I )
    {
        if ( $I == $PAGE )
        {
            ++$SHOW_COUNT;
            $PBAR_STR .= "&nbsp;".$I."&nbsp;&nbsp;&nbsp;";
        }
        else if ( $P - 10 < $PAGE && $P - 10 < $I )
        {
            ++$SHOW_COUNT;
            if ( 10 < $SHOW_COUNT )
            {
                break;
            }
            else
            {
                $PBAR_STR .= "[&nbsp;<a href=\"muser.php?PAGE=".$I."&USERKEY=".urlencode( $USERKEY )."\">".$I."</a>&nbsp;]&nbsp;&nbsp;";
            }
        }
        else if ( $PAGE - 5 < $I )
        {
            ++$SHOW_COUNT;
            if ( 10 < $SHOW_COUNT )
            {
                $PBAR_STR .= "[&nbsp;<a href=\"muser.php?PAGE=".$I."&USERKEY=".urlencode( $USERKEY )."\">".$I."</a>&nbsp;]&nbsp;&nbsp;";
            }
        }
    }
    $NEXT_I = $PAGE + 1;
    if ( $PAGE < $P )
    {
        $PBAR_STR .= "[&nbsp;<a href=\"muser.php?PAGE=".$NEXT_I."&USERKEY=".urlencode( $USERKEY )."\">"._( "��һҳ" )."</a>&nbsp;]&nbsp;&nbsp;";
        $PBAR_STR .= "[&nbsp;<a href=\"muser.php?PAGE=".$P."&USERKEY=".urlencode( $USERKEY )."\">"._( "ĩҳ" )."</a>&nbsp;]&nbsp;&nbsp;";
    }
    return $PBAR_STR;
}

function log_on_remind( )
{
    $SMS_CONTENT = "";
    $TO_ID = "";
    $ONLINE_USER_ARRAY = ( "SYS_ONLINE_USER" );
    $query = "select UID, USER_ID from USER_EXT where find_in_set('".$_SESSION['LOGIN_USER_ID']."', CONCERN_USER)";
    $cursor = exequery( ( ), $query );
    while ( $ROW = mysql_fetch_array( $cursor ) )
    {
        $UID = $ROW['UID'];
        $USER_ID = $ROW['USER_ID'];
        if ( array_key_exists( $UID, $ONLINE_USER_ARRAY ) )
        {
            $TO_ID .= $USER_ID.",";
        }
    }
    $SMS_CONTENT = $_SESSION['LOGIN_USER_NAME'];
    if ( $_SESSION['LOGIN_DEPT_ID'] )
    {
        $LOGIN_DEPT_NAME = getdeptnamebyid( $_SESSION['LOGIN_DEPT_ID'] );
        if ( substr( $LOGIN_DEPT_NAME, strlen( $LOGIN_DEPT_NAME ) - 1, 1 ) == "," )
        {
            $LOGIN_DEPT_NAME = substr( $LOGIN_DEPT_NAME, 0, -1 );
        }
        $SMS_CONTENT .= "(".$LOGIN_DEPT_NAME.")";
    }
    $SMS_CONTENT .= _( "�Ѿ����ߣ�" );
    if ( $TO_ID != "" )
    {
        send_sms( "", $_SESSION['LOGIN_USER_ID'], $TO_ID, 24, $SMS_CONTENT, "" );
    }
}

function my_duty( )
{
    $CUR_DATE = date( "Y-m-d" );
    $CUR_TIME = date( "Y-m-d H:i:s" );
    $query = "select * from ATTEND_DUTY where USER_ID='".$_SESSION['LOGIN_USER_ID']."' and REGISTER_TYPE='1' and to_days(REGISTER_TIME)=to_days('{$CUR_DATE}')";
    $cursor = exequery( ( ), $query );
    if ( 0 < mysql_num_rows( $cursor ) )
    {
    }
    else
    {
        $USER_IP = get_client_ip( );
        if ( check_ip( $USER_IP, "1", $_SESSION['LOGIN_USER_ID'] ) )
        {
        }
        else
        {
            $query = "select * from ATTEND_HOLIDAY where BEGIN_DATE <='".$CUR_DATE."' and END_DATE>='{$CUR_DATE}'";
            $cursor = exequery( ( ), $query );
            if ( 0 < mysql_num_rows( $cursor ) )
            {
            }
            else
            {
                $query = "select * from ATTEND_LEAVE where USER_ID='".$_SESSION['LOGIN_USER_ID']."' and ALLOW='1' and LEAVE_DATE1<='{$CUR_TIME}' and LEAVE_DATE2>='{$CUR_TIME}'";
                $cursor = exequery( ( ), $query );
                if ( 0 < mysql_num_rows( $cursor ) )
                {
                }
                else
                {
                    $query = "select DUTY_TYPE from USER_EXT where UID='".$_SESSION['LOGIN_UID']."'";
                    $cursor = exequery( ( ), $query );
                    if ( $ROW = mysql_fetch_array( $cursor ) )
                    {
                        $DUTY_TYPE = $ROW['DUTY_TYPE'];
                    }
                    $query = "SELECT * from ATTEND_CONFIG where DUTY_TYPE=".intval( $DUTY_TYPE );
                    $cursor = exequery( ( ), $query );
                    if ( $ROW = mysql_fetch_array( $cursor ) )
                    {
                        $DUTY_TIME = $ROW['DUTY_TIME1'];
                        $DUTY_TYPE = $ROW['DUTY_TYPE1'];
                    }
                    $DUTY_INTERVAL_BEFORE = "DUTY_INTERVAL_BEFORE".$DUTY_TYPE;
                    $DUTY_INTERVAL_AFTER = "DUTY_INTERVAL_AFTER".$DUTY_TYPE;
                    $PARA_ARRAY = get_sys_para( "{$DUTY_INTERVAL_BEFORE},{$DUTY_INTERVAL_AFTER}" );
                    while ( list( $PARA_NAME, $PARA_VALUE ) = each( &$PARA_ARRAY ) )
                    {
                        $$PARA_NAME = $PARA_VALUE;
                    }
                    $REGISTER_TIME = $CUR_DATE." ".$DUTY_TIME;
                    if ( $DUTY_INTERVAL_BEFORE1 * 60 < strtotime( $REGISTER_TIME ) - strtotime( $CUR_TIME ) || $DUTY_INTERVAL_AFTER1 * 60 < strtotime( $CUR_TIME ) - strtotime( $REGISTER_TIME ) )
                    {
                    }
                    else
                    {
                        $query = "insert into ATTEND_DUTY(USER_ID,REGISTER_TYPE,REGISTER_TIME,REGISTER_IP,REMARK,DUTY_TYPE) values ('".$_SESSION['LOGIN_USER_ID']."','1','{$CUR_TIME}','".get_client_ip( )."','','1')";
                        exequery( ( ), $query );
                    }
                }
            }
        }
    }
}

include_once( "inc/session.php" );
include_once( "inc/utility_all.php" );
include_once( "inc/itask/itask.php" );
if ( file_exists( dirname( __FILE__ )."/cloud.inc.php" ) )
{
    include_once( dirname( __FILE__ )."/cloud.inc.php" );
}
define( TD_MYOA_VERSION_MAJOR, 7 );
define( TD_MYOA_VERSION_BUILD, 25 );
define( TD_MYOA_VERSION_DATE, "141212" );
define( TD_MYOA_VERSION, sprintf( "%s.%s.%s", TD_MYOA_VERSION_MAJOR, TD_MYOA_VERSION_BUILD, TD_MYOA_VERSION_DATE ) );
if ( defined( "TD_MYOA_IS_CLOUD" ) && TD_MYOA_IS_CLOUD == 1 )
{
    define( TD_MYOA_COMPANY_NAME, "��������ͨ�������޹�˾������ͨ���ſƿƼ����޹�˾" );
}
else
{
    define( TD_MYOA_COMPANY_NAME, "����ͨ���ſƿƼ����޹�˾" );
}
define( TD_MYOA_PRODUCT_NAME, "Office Anywhere 2013 ��ǿ��" );
define( TD_MYOA_WEB_AD, "http://down.tongda2000.com/hero/tongdainfo.php" );
if ( MYOA_IS_UN )
{
    define( TD_MYOA_WEB_SITE, "un.tongda2000.com" );
    define( TD_MYOA_WEB_SP_URL, "http://un.tongda2000.com/sp2013adv.php" );
}
else if ( defined( "TD_MYOA_IS_CLOUD" ) && TD_MYOA_IS_CLOUD == 1 )
{
    define( TD_MYOA_WEB_SITE, "www.tongdayun.com" );
    define( TD_MYOA_WEB_SP_URL, "http://www.tongdayun.com/download/sp2013adv.php" );
}
else
{
    define( TD_MYOA_WEB_SITE, "www.tongda2000.com" );
    define( TD_MYOA_WEB_SP_URL, "http://www.tongda2000.com/download/sp2013adv.php" );
}
define( TD_CORE_USER_LIMIT, 100 );
define( TD_CORE_IM_USER_LIMIT, 50 );
if ( $KEY == "yh" )
{
    echo TD_MYOA_COMPANY_NAME.TD_MYOA_PRODUCT_NAME.TD_MYOA_WEB_SITE."����ͨ���ſƿƼ����޹�˾��Ȩ����";
}
if ( rand( 0, 1000 ) <= 50 && !stristr( $SCRIPT_NAME, "expired.php" ) && !stristr( $SCRIPT_NAME, "reg.php" ) && !stristr( $SCRIPT_NAME, "reg_submit.php" ) )
{
    login_check( "[TDCORE_REGCHECK_AUTO]", "[TDCORE_REGCHECK_AUTO]" );
}
?>
