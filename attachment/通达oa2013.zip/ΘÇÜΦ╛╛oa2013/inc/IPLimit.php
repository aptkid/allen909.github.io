<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
function GetIPLimitConfigFilePath( )
{
    $path = dirname( __FILE__ );
    $path = dirname( $path );
    $path .= "\\";
    $path .= IPLIMIT_CONFIGFILE_NAME;
    return $path;
}

function IsVisitorLimited( $visitorIP )
{
    if ( strpos( $visitorIP, LOCAL_IP_PREFIX ) !== FALSE )
    {
        return FALSE;
    }
    $iplimitConfigFilePath = getiplimitconfigfilepath( );
    if ( file_exists( $iplimitConfigFilePath ) )
    {
        return FALSE;
    }
    $isLimitEnabled = "0";
    $arPermittedIP = array( );
    getiplimitinfo( $iplimitConfigFilePath, $isLimitEnabled, $arPermittedIP );
    if ( $isLimitEnabled == "0" )
    {
        return FALSE;
    }
    if ( in_array( $visitorIP, $arPermittedIP, FALSE ) )
    {
        return FALSE;
    }
    return TRUE;
}

function GetIPLimitInfo( $iplimitConfigFilePath, &$isLimitEnabled, &$arPermittedIP )
{
    $isLimitEnabled = "0";
    $dom = domxml_open_file( $iplimitConfigFilePath );
    if ( $dom == NULL )
    {
        header( "http/1.1 404 domxml_open_file failed!" );
        exit( );
    }
    $dom_root = $dom->document_element( );
    if ( $dom_root == NULL )
    {
        header( "http/1.1 404 ip limit config file invalid!" );
        exit( );
    }
    $sdkhttpNode = NULL;
    $arPropertyChildNodes = $dom_root->child_nodes( );
    $i = 0;
    for ( ; $i < count( $arPropertyChildNodes ); ++$i )
    {
        if ( strcasecmp( $arPropertyChildNodes[$i]->node_name( ), ELEM_SDKHTTP ) == 0 )
        {
            $sdkhttpNode = $arPropertyChildNodes[$i];
        }
    }
    if ( $sdkhttpNode != NULL )
    {
        $arSDKCgiChildNodes = $sdkhttpNode->child_nodes( );
        foreach ( $arSDKCgiChildNodes as $sdkcgiChildNode )
        {
            if ( strcasecmp( $sdkcgiChildNode->node_name( ), ELEM_IPLIMIT ) == 0 )
            {
                $arAttr = $sdkcgiChildNode->attributes( );
                $i = 0;
                for ( ; $i < count( $arAttr ); ++$i )
                {
                    if ( strcasecmp( $arAttr[$i]->name, ATTR_LIMITENABLED ) == 0 )
                    {
                        $isLimitEnabled = $arAttr[$i]->value( );
                    }
                }
                if ( !( $isLimitEnabled == "1" ) )
                {
                    break;
                }
                else
                {
                    $arChildNodesIP = $sdkcgiChildNode->child_nodes( );
                    foreach ( $arChildNodesIP as $childNodeIP )
                    {
                        if ( strcasecmp( $childNodeIP->node_name( ), ELEM_IP ) == 0 )
                        {
                            array_push( &$arPermittedIP, trim( $childNodeIP->get_content( ) ) );
                        }
                    }
                }
                break;
            }
        }
    }
}

$visitorIP = $_SERVER['REMOTE_ADDR'];
$visitorIP = trim( $visitorIP );
define( "LOCAL_IP_PREFIX", "127.0.0." );
define( "IPLIMIT_CONFIGFILE_NAME", "SDKProperty.xml" );
define( "ELEM_SDKHTTP", "SDKHttp" );
define( "ELEM_IPLIMIT", "IPLimit" );
define( "ATTR_LIMITENABLED", "Enabled" );
define( "ELEM_IP", "IP" );
if ( isvisitorlimited( $visitorIP ) )
{
    echo _( "IP ���ޣ�����ϵ����Ա�������� IP" );
    exit( );
}
?>
