<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
include_once( "inc/td_config.php" );
$OA_UPDATE_FILE1 = MYOA_ROOT_PATH."attachment/update/1.php";
$OA_UPDATE_FILE2 = MYOA_ROOT_PATH."attachment/update/2.php";
$OA_UPDATE_FILE3 = MYOA_ROOT_PATH."attachment/update/3.php";
$OA_UPDATE_FILE4 = MYOA_ROOT_PATH."attachment/update/4.php";
$OA_UPDATE_LOCK_FILE = MYOA_ROOT_PATH."attachment/update/lock.txt";
if ( ( file_exists( $OA_UPDATE_FILE1 ) || file_exists( $OA_UPDATE_FILE2 ) || file_exists( $OA_UPDATE_FILE3 ) || file_exists( $OA_UPDATE_FILE4 ) ) && !file_exists( $OA_UPDATE_LOCK_FILE ) )
{
    if ( $UPDATE )
    {
        echo "<script>\r\nfunction start_update()\r\n{\r\n  document.write(\"<div style='position:absolute;left:10px;top:10px;'>�Ѿ���ʼ�����������ĵȴ���ֱ�����ֵ�¼����......</div>\");\r\n  location=\"index.php?UPDATE=1\";\r\n}\r\n</script>\r\n�������������ļ������� <a href='javascript:start_update()'>��ʼ����</a> ������������OA����Ա��������<br><br>";
        exit( );
    }
    include_once( "inc/utility_update.php" );
    update_lock( $OA_UPDATE_LOCK_FILE, TRUE );
    if ( file_exists( $OA_UPDATE_FILE1 ) )
    {
        include_once( $OA_UPDATE_FILE1 );
        unlink( $OA_UPDATE_FILE1 );
    }
    if ( file_exists( $OA_UPDATE_FILE2 ) )
    {
        include_once( $OA_UPDATE_FILE2 );
        unlink( $OA_UPDATE_FILE2 );
    }
    if ( file_exists( $OA_UPDATE_FILE3 ) )
    {
        include_once( $OA_UPDATE_FILE3 );
        unlink( $OA_UPDATE_FILE3 );
    }
    if ( file_exists( $OA_UPDATE_FILE4 ) )
    {
        include_once( $OA_UPDATE_FILE4 );
        unlink( $OA_UPDATE_FILE4 );
    }
    update_lock( $OA_UPDATE_LOCK_FILE, FALSE );
}
?>
