<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
function GetNotifyNum( $USER_ID_STR = "", $BEGIN_TIME = "", $END_TIME = "" )
{
    $USER_ID_STR = td_trim( $USER_ID_STR );
    $WHERE = "";
    $ARRARY = array( );
    if ( $USER_ID_STR != "" )
    {
        $WHERE .= " and find_in_set(FROM_ID,'".$USER_ID_STR."') ";
    }
    if ( $BEGIN_TIME != "" )
    {
        $WHERE .= " and SEND_TIME >= '".$BEGIN_TIME."' ";
    }
    if ( $END_TIME != "" )
    {
        $WHERE .= " and SEND_TIME <= '".$END_TIME."' ";
    }
    $query = "select FROM_ID,count(FROM_ID) from NOTIFY  where FROM_ID<>'' ".$WHERE." and PUBLISH=1   group by FROM_ID";
    $cursor = exequery( ( ), $query );
    while ( $ROW = mysql_fetch_array( $cursor ) )
    {
        $ARRARY[$ROW[0]] = $ROW[1];
    }
    return $ARRARY;
}

function GetAuditNotifyNum( $USER_ID_STR = "", $BEGIN_TIME = "", $END_TIME = "" )
{
    $USER_ID_STR = td_trim( $USER_ID_STR );
    $WHERE = "";
    $ARRARY = array( );
    if ( $USER_ID_STR != "" )
    {
        $WHERE .= " and find_in_set(AUDITER,'".$USER_ID_STR."') ";
    }
    if ( $BEGIN_TIME != "" )
    {
        $WHERE .= " and SEND_TIME >= '".$BEGIN_TIME."' ";
    }
    if ( $END_TIME != "" )
    {
        $WHERE .= " and SEND_TIME <= '".$END_TIME."' ";
    }
    $query = "select AUDITER,count(AUDITER) from NOTIFY  where AUDITER<>'' ".$WHERE." and (PUBLISH='1' or PUBLISH='3')  group by AUDITER";
    $cursor = exequery( ( ), $query );
    while ( $ROW = mysql_fetch_array( $cursor ) )
    {
        $ARRARY[$ROW[0]] = $ROW[1];
    }
    return $ARRARY;
}

function GetNewsNum( $USER_ID_STR = "", $BEGIN_TIME = "", $END_TIME = "" )
{
    $USER_ID_STR = td_trim( $USER_ID_STR );
    $WHERE = "";
    $ARRARY = array( );
    if ( $USER_ID_STR != "" )
    {
        $WHERE .= " and find_in_set(PROVIDER,'".$USER_ID_STR."') ";
    }
    if ( $BEGIN_TIME != "" )
    {
        $WHERE .= " and NEWS_TIME >= '".$BEGIN_TIME."' ";
    }
    if ( $END_TIME != "" )
    {
        $WHERE .= " and NEWS_TIME <= '".$END_TIME."' ";
    }
    $query = "select PROVIDER,count(PROVIDER) from NEWS where  PROVIDER<>'' ".$WHERE." and PUBLISH=1 group by PROVIDER";
    $cursor = exequery( ( ), $query );
    while ( $ROW = mysql_fetch_array( $cursor ) )
    {
        $ARRARY[$ROW[0]] = $ROW[1];
    }
    return $ARRARY;
}

function GetNewsCommentNum( $USER_ID_STR = "", $BEGIN_TIME = "", $END_TIME = "" )
{
    $USER_ID_STR = td_trim( $USER_ID_STR );
    $WHERE = "";
    $ARRARY = array( );
    if ( $USER_ID_STR != "" )
    {
        $WHERE .= " and find_in_set(USER_ID,'".$USER_ID_STR."') ";
    }
    if ( $BEGIN_TIME != "" )
    {
        $WHERE .= " and RE_TIME >= '".$BEGIN_TIME."' ";
    }
    if ( $END_TIME != "" )
    {
        $WHERE .= " and RE_TIME <= '".$END_TIME."' ";
    }
    $query = "select USER_ID,count(USER_ID) from NEWS_COMMENT where  USER_ID<>'' ".$WHERE."  group by USER_ID";
    $cursor = exequery( ( ), $query );
    while ( $ROW = mysql_fetch_array( $cursor ) )
    {
        $ARRARY[$ROW[0]] = $ROW[1];
    }
    return $ARRARY;
}

function get_my_notify( $type = 0, $start = 0, $limit = 10, $order_by = "" )
{
    $CUR_TIME = time( );
    $arr_return = array( );
    $sql = "select NOTIFY_ID,SUBJECT,READERS,FORMAT,TOP,TOP_DAYS,TYPE_ID,BEGIN_DATE,SUBJECT_COLOR FROM NOTIFY where \r\n            PUBLISH='1' and BEGIN_DATE<='".$CUR_TIME."' and (END_DATE>='{$CUR_TIME}' or END_DATE='0')\r\n            and (TO_ID='ALL_DEPT' or find_in_set('".$_SESSION['LOGIN_DEPT_ID']."',TO_ID)\r\n                                  or find_in_set('".$_SESSION['LOGIN_USER_PRIV']."',PRIV_ID)\r\n                                  or find_in_set('".$_SESSION['LOGIN_USER_ID']."',USER_ID)".priv_other_sql( "PRIV_ID" ).dept_other_sql( "TO_ID" ).")";
    if ( $type != 0 )
    {
        $sql .= " and TYPE_ID='".$type."'";
    }
    $order_by = $order_by == "" ? "TOP desc,BEGIN_DATE desc,SEND_TIME desc" : $order_by;
    $sql .= " order by ".$order_by." limit {$start},{$limit}";
    $cursor = exequery( ( ), $sql );
    while ( $row = mysql_fetch_array( $cursor ) )
    {
        $arr_return[] = $row;
    }
    return $arr_return;
}

include_once( "inc/conn.php" );
include_once( "inc/utility.php" );
?>
