<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class TCPDF2DBarcode
{

    protected $barcode_array = FALSE;

    public function __construct( $code, $type )
    {
        $this->setBarcode( $code, $type );
    }

    public function getBarcodeArray( )
    {
        return $this->barcode_array;
    }

    public function getBarcodeSVG( $w = 3, $h = 3, $color = "black" )
    {
        $code = $this->getBarcodeSVGcode( $w, $h, $color );
        header( "Content-Type: application/svg+xml" );
        header( "Cache-Control: public, must-revalidate, max-age=0" );
        header( "Pragma: public" );
        header( "Expires: Sat, 26 Jul 1997 05:00:00 GMT" );
        header( "Last-Modified: ".gmdate( "D, d M Y H:i:s" )." GMT" );
        header( "Content-Disposition: inline; filename=\"".md5( $code ).".svg\";" );
        echo $code;
    }

    public function getBarcodeSVGcode( $w = 3, $h = 3, $color = "black" )
    {
        $repstr = array( "\x00" => "", "&" => "&amp;", "<" => "&lt;", ">" => "&gt;" );
        $svg = "<?xml version=\"1.0\" standalone=\"no\"?>\n";
        $svg .= "<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\">\n";
        $svg .= "<svg width=\"".round( $this->barcode_array['num_cols'] * $w, 3 )."\" height=\"".round( $this->barcode_array['num_rows'] * $h, 3 )."\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\">\n";
        $svg .= "\t<desc>".strtr( $this->barcode_array['code'], $repstr )."</desc>\n";
        $svg .= "\t<g id=\"elements\" fill=\"".$color."\" stroke=\"none\">\n";
        $y = 0;
        $r = 0;
        for ( ; $r < $this->barcode_array['num_rows']; ++$r )
        {
            $x = 0;
            $c = 0;
            for ( ; $c < $this->barcode_array['num_cols']; ++$c )
            {
                if ( $this->barcode_array['bcode'][$r][$c] == 1 )
                {
                    $svg .= "\t\t<rect x=\"".$x."\" y=\"".$y."\" width=\"".$w."\" height=\"".$h."\" />\n";
                }
                $x += $w;
            }
            $y += $h;
        }
        $svg .= "\t</g>\n";
        $svg .= "</svg>\n";
        return $svg;
    }

    public function getBarcodeHTML( $w = 10, $h = 10, $color = "black" )
    {
        $html = "<div style=\"font-size:0;position:relative;\">\n";
        $y = 0;
        $r = 0;
        for ( ; $r < $this->barcode_array['num_rows']; ++$r )
        {
            $x = 0;
            $c = 0;
            for ( ; $c < $this->barcode_array['num_cols']; ++$c )
            {
                if ( $this->barcode_array['bcode'][$r][$c] == 1 )
                {
                    $html .= "<div style=\"background-color:".$color.";width:".$w."px;height:".$h."px;position:absolute;left:".$x."px;top:".$y."px;\">&nbsp;</div>\n";
                }
                $x += $w;
            }
            $y += $h;
        }
        $html .= "</div>\n";
        return $html;
    }

    public function getBarcodePNG( $w = 3, $h = 3, $color = array( 0, 0, 0 ) )
    {
        $width = $this->barcode_array['num_cols'] * $w;
        $height = $this->barcode_array['num_rows'] * $h;
        if ( function_exists( "imagecreate" ) )
        {
            $imagick = FALSE;
            $png = imagecreate( $width, $height );
            $bgcol = imagecolorallocate( $png, 255, 255, 255 );
            imagecolortransparent( $png, $bgcol );
            $fgcol = imagecolorallocate( $png, $color[0], $color[1], $color[2] );
        }
        else if ( extension_loaded( "imagick" ) )
        {
            $imagick = TRUE;
            $bgcol = new imagickpixel( "rgb(255,255,255" );
            $fgcol = new imagickpixel( "rgb(".$color[0].",".$color[1].",".$color[2].")" );
            $png = new Imagick( );
            $png->newImage( $width, $height, "none", "png" );
            $bar = new imagickdraw( );
            $bar->setfillcolor( $fgcol );
        }
        else
        {
            return FALSE;
        }
        $y = 0;
        $r = 0;
        for ( ; $r < $this->barcode_array['num_rows']; ++$r )
        {
            $x = 0;
            $c = 0;
            for ( ; $c < $this->barcode_array['num_cols']; ++$c )
            {
                if ( $this->barcode_array['bcode'][$r][$c] == 1 )
                {
                    if ( $imagick )
                    {
                        $bar->rectangle( $x, $y, $x + $w, $y + $h );
                    }
                    else
                    {
                        imagefilledrectangle( $png, $x, $y, $x + $w, $y + $h, $fgcol );
                    }
                }
                $x += $w;
            }
            $y += $h;
        }
        header( "Content-Type: image/png" );
        header( "Cache-Control: public, must-revalidate, max-age=0" );
        header( "Pragma: public" );
        header( "Expires: Sat, 26 Jul 1997 05:00:00 GMT" );
        header( "Last-Modified: ".gmdate( "D, d M Y H:i:s" )." GMT" );
        if ( $imagick )
        {
            $png->drawimage( $bar );
            echo $png;
        }
        else
        {
            imagepng( $png );
            imagedestroy( $png );
        }
    }

    public function setBarcode( $code, $type )
    {
        $mode = explode( ",", $type );
        $qrtype = strtoupper( $mode[0] );
        switch ( $qrtype )
        {
            case "DATAMATRIX" :
                require_once( dirname( __FILE__ )."/datamatrix.php" );
                $qrcode = new Datamatrix( $code );
                $this->barcode_array = $qrcode->getBarcodeArray( );
                $this->barcode_array['code'] = $code;
                return;
            case "PDF417" :
                require_once( dirname( __FILE__ )."/pdf417.php" );
                if ( !isset( $mode[1] ) || $mode[1] === "" )
                {
                    $aspectratio = 2;
                }
                else
                {
                    $aspectratio = floatval( $mode[1] );
                }
                if ( !isset( $mode[2] ) || $mode[2] === "" )
                {
                    $ecl = -1;
                }
                else
                {
                    $ecl = intval( $mode[2] );
                }
                $macro = array( );
                if ( $mode[5] !== "" )
                {
                    $macro['segment_total'] = intval( $mode[3] );
                    $macro['segment_index'] = intval( $mode[4] );
                    $macro['file_id'] = strtr( $mode[5], "�", "," );
                    $i = 0;
                    for ( ; $i < 7; ++$i )
                    {
                        $o = $i + 6;
                        if ( !isset( $mode[$o] ) || !( $mode[$o] !== "" ) )
                        {
                            $macro["option_".$i] = strtr( $mode[$o], "�", "," );
                        }
                    }
                }
                $qrcode = new PDF417( $code, $ecl, $aspectratio, $macro );
                $this->barcode_array = $qrcode->getBarcodeArray( );
                $this->barcode_array['code'] = $code;
                return;
            case "QRCODE" :
                require_once( dirname( __FILE__ )."/qrcode.php" );
                if ( !isset( $mode[1] ) || !in_array( $mode[1], array( "L", "M", "Q", "H" ) ) )
                {
                    $mode[1] = "L";
                }
                $qrcode = new QRcode( $code, strtoupper( $mode[1] ) );
                $this->barcode_array = $qrcode->getBarcodeArray( );
                $this->barcode_array['code'] = $code;
                return;
            case "RAW" :
            case "RAW2" :
                $code = preg_replace( "/[\\s]*/si", "", $code );
                if ( strlen( $code ) < 3 )
                {
                    if ( $qrtype == "RAW" )
                    {
                        $rows = explode( ",", $code );
                    }
                    else
                    {
                        $code = substr( $code, 1, -1 );
                        $rows = explode( "][", $code );
                    }
                    $this->barcode_array['num_rows'] = count( $rows );
                    $this->barcode_array['num_cols'] = strlen( $rows[0] );
                    $this->barcode_array['bcode'] = array( );
                    foreach ( $rows as $r )
                    {
                        $this->barcode_array['bcode'][] = str_split( $r, 1 );
                    }
                    $this->barcode_array['code'] = $code;
                    return;
                }
            case "TEST" :
                $this->barcode_array['num_rows'] = 5;
                $this->barcode_array['num_cols'] = 15;
                $this->barcode_array['bcode'] = array( array( 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1 ), array( 0, 1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0 ), array( 0, 1, 0, 0, 1, 1, 0, 0, 1, 1, 1, 0, 0, 1, 0 ), array( 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0 ), array( 0, 1, 0, 0, 1, 1, 1, 0, 1, 1, 1, 0, 0, 1, 0 ) );
                $this->barcode_array['code'] = $code;
                return;
        }
        $this->barcode_array = FALSE;
    }

}

?>
