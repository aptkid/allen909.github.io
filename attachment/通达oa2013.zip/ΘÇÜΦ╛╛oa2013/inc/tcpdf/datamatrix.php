<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class Datamatrix
{

    protected $barcode_array = array( );
    protected $last_enc = ENC_ASCII;
    protected $symbattr = array( array( 10, 10, 8, 8, 10, 10, 8, 8, 1, 1, 1, 3, 5, 1, 3, 5 ), array( 12, 12, 10, 10, 12, 12, 10, 10, 1, 1, 1, 5, 7, 1, 5, 7 ), array( 14, 14, 12, 12, 14, 14, 12, 12, 1, 1, 1, 8, 10, 1, 8, 10 ), array( 16, 16, 14, 14, 16, 16, 14, 14, 1, 1, 1, 12, 12, 1, 12, 12 ), array( 18, 18, 16, 16, 18, 18, 16, 16, 1, 1, 1, 18, 14, 1, 18, 14 ), array( 20, 20, 18, 18, 20, 20, 18, 18, 1, 1, 1, 22, 18, 1, 22, 18 ), array( 22, 22, 20, 20, 22, 22, 20, 20, 1, 1, 1, 30, 20, 1, 30, 20 ), array( 24, 24, 22, 22, 24, 24, 22, 22, 1, 1, 1, 36, 24, 1, 36, 24 ), array( 26, 26, 24, 24, 26, 26, 24, 24, 1, 1, 1, 44, 28, 1, 44, 28 ), array( 32, 32, 28, 28, 16, 16, 14, 14, 2, 2, 4, 62, 36, 1, 62, 36 ), array( 36, 36, 32, 32, 18, 18, 16, 16, 2, 2, 4, 86, 42, 1, 86, 42 ), array( 40, 40, 36, 36, 20, 20, 18, 18, 2, 2, 4, 114, 48, 1, 114, 48 ), array( 44, 44, 40, 40, 22, 22, 20, 20, 2, 2, 4, 144, 56, 1, 144, 56 ), array( 48, 48, 44, 44, 24, 24, 22, 22, 2, 2, 4, 174, 68, 1, 174, 68 ), array( 52, 52, 48, 48, 26, 26, 24, 24, 2, 2, 4, 204, 84, 2, 102, 42 ), array( 64, 64, 56, 56, 16, 16, 14, 14, 4, 4, 16, 280, 112, 2, 140, 56 ), array( 72, 72, 64, 64, 18, 18, 16, 16, 4, 4, 16, 368, 144, 4, 92, 36 ), array( 80, 80, 72, 72, 20, 20, 18, 18, 4, 4, 16, 456, 192, 4, 114, 48 ), array( 88, 88, 80, 80, 22, 22, 20, 20, 4, 4, 16, 576, 224, 4, 144, 56 ), array( 96, 96, 88, 88, 24, 24, 22, 22, 4, 4, 16, 696, 272, 4, 174, 68 ), array( 104, 104, 96, 96, 26, 26, 24, 24, 4, 4, 16, 816, 336, 6, 136, 56 ), array( 120, 120, 108, 108, 20, 20, 18, 18, 6, 6, 36, 1050, 408, 6, 175, 68 ), array( 132, 132, 120, 120, 22, 22, 20, 20, 6, 6, 36, 1304, 496, 8, 163, 62 ), array( 144, 144, 132, 132, 24, 24, 22, 22, 6, 6, 36, 1558, 620, 10, 156, 62 ), array( 8, 18, 6, 16, 8, 18, 6, 16, 1, 1, 1, 5, 7, 1, 5, 7 ), array( 8, 32, 6, 28, 8, 16, 6, 14, 1, 2, 2, 10, 11, 1, 10, 11 ), array( 12, 26, 10, 24, 12, 26, 10, 24, 1, 1, 1, 16, 14, 1, 16, 14 ), array( 12, 36, 10, 32, 12, 18, 10, 16, 1, 2, 2, 12, 18, 1, 12, 18 ), array( 16, 36, 14, 32, 16, 18, 14, 16, 1, 2, 2, 32, 24, 1, 32, 24 ), array( 16, 48, 14, 44, 16, 24, 14, 22, 1, 2, 2, 49, 28, 1, 49, 28 ) );
    protected $chset_id = array( 'ENC_C40' => ?id #20673288, 'ENC_TXT' => ?id #20673384, 'ENC_X12' => ?id #20673480 );
    protected $chset = array( 'C40' => array( 'S1' => 0, 'S2' => 1, 'S3' => 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39 ), 'TXT' => array( 'S1' => 0, 'S2' => 1, 'S3' => 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39 ), 'SH1' => array( 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31 ), 'SH2' => array( 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 'F1' => 27, 'US' => 30 ), 'S3C' => array( 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31 ), 'S3T' => array( 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31 ), 'X12' => array( 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39 ) );

    public function __construct( $code )
    {
        $barcode_array = array( );
        if ( is_null( $code ) || $code == "\\0" || $code == "" )
        {
            return FALSE;
        }
        $cw = $this->getHighLevelEncoding( $code );
        $nd = count( $cw );
        if ( 1558 < $nd )
        {
            return FALSE;
        }
        foreach ( $this->symbattr as $params )
        {
            if ( $nd <= $params[11] )
            {
                break;
            }
        }
        if ( $params[11] < $nd )
        {
            return FALSE;
        }
        if ( $nd < $params[11] )
        {
            if ( $this->last_enc == ENC_EDF )
            {
                $cw[] = 124;
                ++$nd;
            }
            else if ( $this->last_enc != ENC_ASCII && $this->last_enc != ENC_BASE256 )
            {
                $cw[] = 254;
                ++$nd;
            }
            if ( $nd < $params[11] )
            {
                $cw[] = 129;
                ++$nd;
                $i = $nd;
                for ( ; $i <= $params[11]; ++$i )
                {
                    $cw[] = $this->get253StateCodeword( 129, $i );
                }
            }
        }
        $cw = $params[15]( $cw, $params[13], $params[14], $params[15] );
        $grid = array_fill( 0, $params[2] * $params[3], 0 );
        $places = $params[3]( $params[2], $params[3] );
        $grid = array( );
        $i = 0;
        $rdri = $params[4] - 1;
        $rdci = $params[5] - 1;
        $vr = 0;
        for ( ; $vr < $params[9]; ++$vr )
        {
            $r = 0;
            for ( ; $r < $params[4]; ++$r )
            {
                $row = $vr * $params[4] + $r;
                $hr = 0;
                for ( ; $hr < $params[8]; ++$hr )
                {
                    $c = 0;
                    for ( ; $c < $params[5]; ++$c )
                    {
                        $col = $hr * $params[5] + $c;
                        if ( $r == 0 )
                        {
                            if ( $c % 2 )
                            {
                                $grid[$row][$col] = 0;
                            }
                            else
                            {
                                $grid[$row][$col] = 1;
                            }
                        }
                        else if ( $r == $rdri )
                        {
                            $grid[$row][$col] = 1;
                        }
                        else if ( $c == 0 )
                        {
                            $grid[$row][$col] = 1;
                        }
                        else
                        {
                            if ( $c == $rdci )
                            {
                                if ( $r % 2 )
                                {
                                    $grid[$row][$col] = 1;
                                }
                                else
                                {
                                    $grid[$row][$col] = 0;
                                }
                            }
                            else
                            {
                                if ( $places[$i] < 2 )
                                {
                                    $grid[$row][$col] = $places[$i];
                                }
                                else
                                {
                                    $cw_id = floor( $places[$i] / 10 ) - 1;
                                    $cw_bit = pow( 2, 8 - $places[$i] % 10 );
                                    $grid[$row][$col] = ( $cw[$cw_id] & $cw_bit ) == 0 ? 0 : 1;
                                }
                                ++$i;
                            }
                        }
                    }
                }
            }
        }
        $this->barcode_array['num_rows'] = $params[0];
        $this->barcode_array['num_cols'] = $params[1];
        $this->barcode_array['bcode'] = $grid;
    }

    public function getBarcodeArray( )
    {
        return $this->barcode_array;
    }

    protected function getGFProduct( $a, $b, $log, $alog, $gf )
    {
        if ( $a == 0 || $b == 0 )
        {
            return 0;
        }
        return $alog[( $log[$a] + $log[$b] ) % ( $gf - 1 )];
    }

    protected function getErrorCorrection( $wd, $nb, $nd, $nc, $gf = 256, $pp = 301 )
    {
        $log[0] = 0;
        $alog[0] = 1;
        $i = 1;
        for ( ; $i < $gf; ++$i )
        {
            $alog[$i] = $alog[$i - 1] * 2;
            if ( $gf <= $alog[$i] )
            {
                $alog ^= $i;
            }
            $log[$alog[$i]] = $i;
        }
        ksort( &$log );
        $c = array_fill( 0, $nc + 1, 0 );
        $c[0] = 1;
        $i = 1;
        for ( ; $i <= $nc; ++$i )
        {
            $c[$i] = $c[$i - 1];
            $j = $i - 1;
            for ( ; 1 <= $j; --$j )
            {
                $c[$j] = $c[$j - 1] ^ $alog[$i]( $c[$j], $alog[$i], $log, $alog, $gf );
            }
            $c[0] = $alog[$i]( $c[0], $alog[$i], $log, $alog, $gf );
        }
        ksort( &$c );
        $num_wd = $nb * $nd;
        $num_we = $nb * $nc;
        $b = 0;
        for ( ; $b < $nb; ++$b )
        {
            $block = array( );
            $n = $b;
            for ( ; $n < $num_wd; $n += $nb )
            {
                $block[] = $wd[$n];
            }
            $we = array_fill( 0, $nc + 1, 0 );
            $i = 0;
            for ( ; $i < $nd; ++$i )
            {
                $k = $we[0] ^ $block[$i];
                $j = 0;
                for ( ; $j < $nc; ++$j )
                {
                    $we[$j] = $we[$j + 1] ^ $c[$nc - $j - 1]( $k, $c[$nc - $j - 1], $log, $alog, $gf );
                }
            }
            $j = 0;
            $i = $b;
            for ( ; $i < $num_we; $i += $nb )
            {
                $wd[$num_wd + $i] = $we[$j];
                ++$j;
            }
        }
        ksort( &$wd );
        return $wd;
    }

    protected function get253StateCodeword( $cwpad, $cwpos )
    {
        $pad = $cwpad + ( 149 * $cwpos % 253 + 1 );
        if ( 254 < $pad )
        {
            $pad -= 254;
        }
        return $pad;
    }

    protected function get255StateCodeword( $cwpad, $cwpos )
    {
        $pad = $cwpad + ( 149 * $cwpos % 255 + 1 );
        if ( 255 < $pad )
        {
            $pad -= 256;
        }
        return $pad;
    }

    protected function isCharMode( $chr, $mode )
    {
        $status = FALSE;
        switch ( $mode )
        {
            case ENC_ASCII :
                $status = $chr <= 127;
                return $status;
            case ENC_C40 :
                $status = $chr == 32 || $chr <= 57 || $chr <= 90;
                return $status;
            case ENC_TXT :
                $status = $chr == 32 || $chr <= 57 || $chr <= 122;
                return $status;
            case ENC_X12 :
                $status = $chr == 62;
                return $status;
            case ENC_EDF :
                $status = $chr <= 94;
                return $status;
            case ENC_BASE256 :
                $status = $chr == 241;
                return $status;
            case ENC_ASCII_EXT :
                $status = $chr <= 255;
                return $status;
            case ENC_ASCII_NUM :
                $status = $chr <= 57;
            default :
                return $status;
        }
    }

    protected function lookAheadTest( $data, $pos, $mode )
    {
        $data_length = strlen( $data );
        if ( $data_length <= $pos )
        {
            return $mode;
        }
        $charscount = 0;
        if ( $mode == ENC_ASCII )
        {
            $numch = array( 0, 1, 1, 1, 1, 1.25 );
        }
        else
        {
            $numch = array( 1, 2, 2, 2, 2, 2.25 );
            $numch[$mode] = 0;
        }
        do
        {
            do
            {
                if ( $pos + $charscount == $data_length )
                {
                    if ( $numch[ENC_ASCII] <= ceil( min( $numch[ENC_C40], $numch[ENC_TXT], $numch[ENC_X12], $numch[ENC_EDF], $numch[ENC_BASE256] ) ) )
                    {
                        return ENC_ASCII;
                    }
                    if ( $numch[ENC_BASE256] < ceil( min( $numch[ENC_ASCII], $numch[ENC_C40], $numch[ENC_TXT], $numch[ENC_X12], $numch[ENC_EDF] ) ) )
                    {
                        return ENC_BASE256;
                    }
                    if ( $numch[ENC_EDF] < ceil( min( $numch[ENC_ASCII], $numch[ENC_C40], $numch[ENC_TXT], $numch[ENC_X12], $numch[ENC_BASE256] ) ) )
                    {
                        return ENC_EDF;
                    }
                    if ( $numch[ENC_TXT] < ceil( min( $numch[ENC_ASCII], $numch[ENC_C40], $numch[ENC_X12], $numch[ENC_EDF], $numch[ENC_BASE256] ) ) )
                    {
                        return ENC_TXT;
                    }
                    if ( $numch[ENC_X12] < ceil( min( $numch[ENC_ASCII], $numch[ENC_C40], $numch[ENC_TXT], $numch[ENC_EDF], $numch[ENC_BASE256] ) ) )
                    {
                        return ENC_X12;
                    }
                    return ENC_C40;
                }
                $chr = ord( $data[$pos + $charscount] );
                ++$charscount;
                if ( $this->isCharMode( $chr, ENC_ASCII_NUM ) )
                {
                    $numch += ENC_ASCII;
                }
                else if ( $this->isCharMode( $chr, ENC_ASCII_EXT ) )
                {
                    $numch[ENC_ASCII] = ceil( $numch[ENC_ASCII] );
                    $numch += ENC_ASCII;
                }
                else
                {
                    $numch[ENC_ASCII] = ceil( $numch[ENC_ASCII] );
                    $numch += ENC_ASCII;
                }
                if ( $this->isCharMode( $chr, ENC_C40 ) )
                {
                    $numch += ENC_C40;
                }
                else if ( $this->isCharMode( $chr, ENC_ASCII_EXT ) )
                {
                    $numch += ENC_C40;
                }
                else
                {
                    $numch += ENC_C40;
                }
                if ( $this->isCharMode( $chr, ENC_TXT ) )
                {
                    $numch += ENC_TXT;
                }
                else if ( $this->isCharMode( $chr, ENC_ASCII_EXT ) )
                {
                    $numch += ENC_TXT;
                }
                else
                {
                    $numch += ENC_TXT;
                }
                if ( $this->isCharMode( $chr, ENC_X12 ) || $this->isCharMode( $chr, ENC_C40 ) )
                {
                    $numch += ENC_X12;
                }
                else if ( $this->isCharMode( $chr, ENC_ASCII_EXT ) )
                {
                    $numch += ENC_X12;
                }
                else
                {
                    $numch += ENC_X12;
                }
                if ( $this->isCharMode( $chr, ENC_EDF ) )
                {
                    $numch += ENC_EDF;
                }
                else if ( $this->isCharMode( $chr, ENC_ASCII_EXT ) )
                {
                    $numch += ENC_EDF;
                }
                else
                {
                    $numch += ENC_EDF;
                }
                if ( $this->isCharMode( $chr, ENC_BASE256 ) )
                {
                    $numch += ENC_BASE256;
                }
                else
                {
                    $numch += ENC_BASE256;
                }
                if ( $numch[ENC_ASCII] + 1 <= min( $numch[ENC_C40], $numch[ENC_TXT], $numch[ENC_X12], $numch[ENC_EDF], $numch[ENC_BASE256] ) )
                {
                    return ENC_ASCII;
                }
                if ( $numch[ENC_BASE256] + 1 < min( $numch[ENC_C40], $numch[ENC_TXT], $numch[ENC_X12], $numch[ENC_EDF] ) )
                {
                    return ENC_BASE256;
                }
                if ( $numch[ENC_EDF] + 1 < min( $numch[ENC_ASCII], $numch[ENC_C40], $numch[ENC_TXT], $numch[ENC_X12], $numch[ENC_BASE256] ) )
                {
                    return ENC_EDF;
                }
                if ( $numch[ENC_TXT] + 1 < min( $numch[ENC_ASCII], $numch[ENC_C40], $numch[ENC_X12], $numch[ENC_EDF], $numch[ENC_BASE256] ) )
                {
                    return ENC_TXT;
                }
                if ( $numch[ENC_X12] + 1 < min( $numch[ENC_ASCII], $numch[ENC_C40], $numch[ENC_TXT], $numch[ENC_EDF], $numch[ENC_BASE256] ) )
                {
                    return ENC_X12;
                }
                if ( $numch[ENC_C40] < $numch[ENC_X12] )
                {
                    return ENC_C40;
                }
            } while ( !( $numch[ENC_C40] == $numch[ENC_X12] ) );
        } while ( !( $numch[ENC_C40] == $numch[ENC_X12] ) );
        $k = $pos + $charscount + 1;
        while ( $k < $data_length )
        {
            $tmpchr = ord( $data[$k] );
            if ( $this->isCharMode( $tmpchr, ENC_X12 ) )
            {
                return ENC_X12;
            }
            if ( $this->isCharMode( $tmpchr, ENC_C40 ) )
            {
            }
            else
            {
                ++$k;
            }
        }
        return ENC_C40;
    }

    protected function getSwitchEncodingCodeword( $mode )
    {
        switch ( $mode )
        {
            case ENC_ASCII :
                $cw = 254;
                return $cw;
            case ENC_C40 :
                $cw = 230;
                return $cw;
            case ENC_TXT :
                $cw = 239;
                return $cw;
            case ENC_X12 :
                $cw = 238;
                return $cw;
            case ENC_EDF :
                $cw = 240;
                return $cw;
            case ENC_BASE256 :
                $cw = 231;
            default :
                return $cw;
        }
    }

    protected function getMaxDataCodewords( $numcw )
    {
        foreach ( $this->symbattr as $key => $matrix )
        {
            if ( $numcw <= $matrix[11] )
            {
                return $matrix[11];
                break;
            }
        }
        return 0;
    }

    protected function getHighLevelEncoding( $data )
    {
        $enc = ENC_ASCII;
        $pos = 0;
        $cw = array( );
        $cw_num = 0;
        $data_lenght = strlen( $data );
}
}
}
while ( $pos < $data_lenght )
{
case ENC_ASCII :
    switch ( $enc )
    {
            if ( 1 < $data_lenght && $pos < $data_lenght - 1 && ord( $data[$pos] )( ord( $data[$pos] ), ENC_ASCII_NUM ) && ord( $data[$pos + 1] )( ord( $data[$pos + 1] ), ENC_ASCII_NUM ) )
            {
                $cw[] = intval( substr( $data, $pos, 2 ) ) + 130;
                ++$cw_num;
                $pos += 2;
            }
            else
            {
                $newenc = $this->lookAheadTest( $data, $pos, $enc );
                if ( $newenc != $enc )
                {
                    $enc = $newenc;
                    $cw[] = $this->getSwitchEncodingCodeword( $enc );
                    ++$cw_num;
                }
                else
                {
                    $chr = ord( $data[$pos] );
                    ++$pos;
                    if ( $this->isCharMode( $chr, ENC_ASCII_EXT ) )
                    {
                        $cw[] = 235;
                        $cw[] = $chr - 127;
                        $cw_num += 2;
                    }
                    else
                    {
                        $cw[] = $chr + 1;
                        ++$cw_num;
                        continue;
                    }
                }
            }
        case ENC_C40 :
            switch ( $enc )
            {
                case ENC_TXT :
                case ENC_X12 :
                    $temp_cw = array( );
                    $p = 0;
                    $epos = $pos;
                    $set_id = $this->chset_id[$enc];
                    $charset = $this->chset[$set_id];
                    do
                    {
                        $chr = ord( $data[$epos] );
                        ++$epos;
                        if ( $chr & 128 )
                        {
                            if ( $enc == ENC_X12 )
                            {
                                return FALSE;
                            }
                            $chr &= 127;
                            $temp_cw[] = 1;
                            $temp_cw[] = 30;
                            $p += 2;
                        }
                        if ( isset( $charset[$chr] ) )
                        {
                            $temp_cw[] = $charset[$chr];
                            ++$p;
                        }
                        else
                        {
                            if ( isset( $this->chset['SH1'][$chr] ) )
                            {
                                $temp_cw[] = 0;
                                $shiftset = $this->chset['SH1'];
                            }
                            else if ( isset( $chr ) && isset( $this->chset['SH2'][$chr] ) )
                            {
                                $temp_cw[] = 1;
                                $shiftset = $this->chset['SH2'];
                            }
                            else if ( $enc == ENC_C40 && isset( $this->chset['S3C'][$chr] ) )
                            {
                                $temp_cw[] = 2;
                                $shiftset = $this->chset['S3C'];
                            }
                            else if ( $enc == ENC_TXT && isset( $this->chset['S3T'][$chr] ) )
                            {
                                $temp_cw[] = 2;
                                $shiftset = $this->chset['S3T'];
                            }
                            else
                            {
                                return FALSE;
                            }
                            $temp_cw[] = $shiftset[$chr];
                            $p += 2;
                        }
                        if ( 3 <= $p )
                        {
                            $c1 = array_shift( &$temp_cw );
                            $c2 = array_shift( &$temp_cw );
                            $c3 = array_shift( &$temp_cw );
                            $p -= 3;
                            $tmp = 1600 * $c1 + 40 * $c2 + $c3 + 1;
                            $cw[] = $tmp >> 8;
                            $cw[] = $tmp % 256;
                            $cw_num += 2;
                            $pos = $epos;
                            $newenc = $this->lookAheadTest( $data, $pos, $enc );
                            if ( $newenc != $enc )
                            {
                                $enc = $newenc;
                                $cw[] = $this->getSwitchEncodingCodeword( $enc );
                                ++$cw_num;
                                break;
                                break;
                            }
                        }
                        else
                        {
                        }
                    } while ( 0 < $p && $epos < $data_lenght );
                    if ( 0 < $p )
                    {
                        $cwr = $this->getMaxDataCodewords( $cw_num + 2 ) - $cw_num;
                        if ( $cwr == 1 && $p == 1 )
                        {
                            $c1 = array_shift( &$temp_cw );
                            --$p;
                            $cw[] = $c1 + 1;
                            ++$cw_num;
                        }
                        else
                        {
                            if ( $cwr == 2 && $p == 1 )
                            {
                                $c1 = array_shift( &$temp_cw );
                                --$p;
                                $cw[] = 254;
                                $cw[] = $c1 + 1;
                                $cw_num += 2;
                            }
                            else
                            {
                                if ( $cwr == 2 && $p == 2 )
                                {
                                    $c1 = array_shift( &$temp_cw );
                                    $c2 = array_shift( &$temp_cw );
                                    $p -= 2;
                                    $tmp = 1600 * $c1 + 40 * $c2 + 1;
                                    $cw[] = $tmp >> 8;
                                    $cw[] = $tmp % 256;
                                    $cw_num += 2;
                                }
                                else
                                {
                                    $enc = ENC_ASCII;
                                    $cw[] = $this->getSwitchEncodingCodeword( $enc );
                                    ++$cw_num;
                                    continue;
                                }
                            }
                        }
                    }
                case ENC_EDF :
                    switch ( $enc )
                    {
                            $temp_cw = array( );
                            $epos = $pos;
                            $field_lenght = 0;
                            do
                            {
                                if ( $epos < $data_lenght )
                                {
                                    $chr = ord( $data[$epos] );
                                    ++$epos;
                                    $temp_cw[] = $chr;
                                    ++$field_lenght;
                                    if ( $field_lenght == 4 || $epos == $data_lenght )
                                    {
                                        if ( $field_lenght < 4 )
                                        {
                                            $temp_cw[] = 31;
                                            ++$field_lenght;
                                            $enc = ENC_ASCII;
                                            $i = $field_lenght;
                                            for ( ; $i < 4; ++$i )
                                            {
                                                $temp_cw[] = 0;
                                            }
                                        }
                                        $cw[] = ( ( $temp_cw[0] & 63 ) << 2 ) + ( ( $temp_cw[1] & 48 ) >> 4 );
                                        $cw[] = ( ( $temp_cw[1] & 15 ) << 4 ) + ( ( $temp_cw[2] & 60 ) >> 2 );
                                        $cw[] = ( ( $temp_cw[2] & 3 ) << 6 ) + ( $temp_cw[3] & 63 );
                                        $cw_num += 3;
                                        $temp_cw = array( );
                                        $pos = $epos;
                                        $field_lenght = 0;
                                    }
                                    $cwr = $this->getMaxDataCodewords( $cw_num + 2 ) - $cw_num;
                                    if ( $cwr < 3 )
                                    {
                                        $enc = ENC_ASCII;
                                    }
                                    else
                                    {
                                        $newenc = $this->lookAheadTest( $data, $pos, $enc );
                                    }
                                }
                            } while ( !( $newenc != $enc ) );
                            $enc = $newenc;
                            $cw[] = $this->getSwitchEncodingCodeword( $enc );
                            ++$cw_num;
                            continue;
                        case ENC_BASE256 :
                            $temp_cw = array( );
                            $field_lenght = 0;
                            while ( $field_lenght <= 1555 )
                            {
                                $newenc = $this->lookAheadTest( $data, $pos, $enc );
                                if ( $newenc != $enc )
                                {
                                    $enc = $newenc;
                                    $cw[] = $this->getSwitchEncodingCodeword( $enc );
                                    ++$cw_num;
                                }
                                else
                                {
                                    $chr = ord( $data[$pos] );
                                    ++$pos;
                                    $temp_cw[] = $chr;
                                    ++$field_lenght;
                                }
                            }
                            if ( $field_lenght <= 249 )
                            {
                                $cw[] = $field_lenght;
                                ++$cw_num;
                            }
                            else
                            {
                                $cw[] = floor( $field_lenght / 250 ) + 249;
                                $cw[] = $field_lenght % 250;
                                $cw_num += 2;
                            }
                            if ( empty( $temp_cw ) )
                            {
                                foreach ( $temp_cw as $p => $cht )
                                {
                                    $cw[] = $this->get255StateCodeword( $chr, $cw_num + $p );
                                }
                            }
                        }
                        $this->last_enc = $enc;
                        return $cw;
                    }

    protected function placeModule( $marr, $nrow, $ncol, $row, $col, $chr, $bit )
    {
        if ( $row < 0 )
        {
            $row += $nrow;
            $col += 4 - ( $nrow + 4 ) % 8;
        }
        if ( $col < 0 )
        {
            $col += $ncol;
            $row += 4 - ( $ncol + 4 ) % 8;
        }
        $marr[$row * $ncol + $col] = 10 * $chr + $bit;
        return $marr;
    }

    protected function placeUtah( $marr, $nrow, $ncol, $row, $col, $chr )
    {
        $marr = $this->placeModule( $marr, $nrow, $ncol, $row - 2, $col - 2, $chr, 1 );
        $marr = $this->placeModule( $marr, $nrow, $ncol, $row - 2, $col - 1, $chr, 2 );
        $marr = $this->placeModule( $marr, $nrow, $ncol, $row - 1, $col - 2, $chr, 3 );
        $marr = $this->placeModule( $marr, $nrow, $ncol, $row - 1, $col - 1, $chr, 4 );
        $marr = $this->placeModule( $marr, $nrow, $ncol, $row - 1, $col, $chr, 5 );
        $marr = $this->placeModule( $marr, $nrow, $ncol, $row, $col - 2, $chr, 6 );
        $marr = $this->placeModule( $marr, $nrow, $ncol, $row, $col - 1, $chr, 7 );
        $marr = $this->placeModule( $marr, $nrow, $ncol, $row, $col, $chr, 8 );
        return $marr;
    }

    protected function placeCornerA( $marr, $nrow, $ncol, $chr )
    {
        $marr = $this->placeModule( $marr, $nrow, $ncol, $nrow - 1, 0, $chr, 1 );
        $marr = $this->placeModule( $marr, $nrow, $ncol, $nrow - 1, 1, $chr, 2 );
        $marr = $this->placeModule( $marr, $nrow, $ncol, $nrow - 1, 2, $chr, 3 );
        $marr = $this->placeModule( $marr, $nrow, $ncol, 0, $ncol - 2, $chr, 4 );
        $marr = $this->placeModule( $marr, $nrow, $ncol, 0, $ncol - 1, $chr, 5 );
        $marr = $this->placeModule( $marr, $nrow, $ncol, 1, $ncol - 1, $chr, 6 );
        $marr = $this->placeModule( $marr, $nrow, $ncol, 2, $ncol - 1, $chr, 7 );
        $marr = $this->placeModule( $marr, $nrow, $ncol, 3, $ncol - 1, $chr, 8 );
        return $marr;
    }

    protected function placeCornerB( $marr, $nrow, $ncol, $chr )
    {
        $marr = $this->placeModule( $marr, $nrow, $ncol, $nrow - 3, 0, $chr, 1 );
        $marr = $this->placeModule( $marr, $nrow, $ncol, $nrow - 2, 0, $chr, 2 );
        $marr = $this->placeModule( $marr, $nrow, $ncol, $nrow - 1, 0, $chr, 3 );
        $marr = $this->placeModule( $marr, $nrow, $ncol, 0, $ncol - 4, $chr, 4 );
        $marr = $this->placeModule( $marr, $nrow, $ncol, 0, $ncol - 3, $chr, 5 );
        $marr = $this->placeModule( $marr, $nrow, $ncol, 0, $ncol - 2, $chr, 6 );
        $marr = $this->placeModule( $marr, $nrow, $ncol, 0, $ncol - 1, $chr, 7 );
        $marr = $this->placeModule( $marr, $nrow, $ncol, 1, $ncol - 1, $chr, 8 );
        return $marr;
    }

    protected function placeCornerC( $marr, $nrow, $ncol, $chr )
    {
        $marr = $this->placeModule( $marr, $nrow, $ncol, $nrow - 3, 0, $chr, 1 );
        $marr = $this->placeModule( $marr, $nrow, $ncol, $nrow - 2, 0, $chr, 2 );
        $marr = $this->placeModule( $marr, $nrow, $ncol, $nrow - 1, 0, $chr, 3 );
        $marr = $this->placeModule( $marr, $nrow, $ncol, 0, $ncol - 2, $chr, 4 );
        $marr = $this->placeModule( $marr, $nrow, $ncol, 0, $ncol - 1, $chr, 5 );
        $marr = $this->placeModule( $marr, $nrow, $ncol, 1, $ncol - 1, $chr, 6 );
        $marr = $this->placeModule( $marr, $nrow, $ncol, 2, $ncol - 1, $chr, 7 );
        $marr = $this->placeModule( $marr, $nrow, $ncol, 3, $ncol - 1, $chr, 8 );
        return $marr;
    }

    protected function placeCornerD( $marr, $nrow, $ncol, $chr )
    {
        $marr = $this->placeModule( $marr, $nrow, $ncol, $nrow - 1, 0, $chr, 1 );
        $marr = $this->placeModule( $marr, $nrow, $ncol, $nrow - 1, $ncol - 1, $chr, 2 );
        $marr = $this->placeModule( $marr, $nrow, $ncol, 0, $ncol - 3, $chr, 3 );
        $marr = $this->placeModule( $marr, $nrow, $ncol, 0, $ncol - 2, $chr, 4 );
        $marr = $this->placeModule( $marr, $nrow, $ncol, 0, $ncol - 1, $chr, 5 );
        $marr = $this->placeModule( $marr, $nrow, $ncol, 1, $ncol - 3, $chr, 6 );
        $marr = $this->placeModule( $marr, $nrow, $ncol, 1, $ncol - 2, $chr, 7 );
        $marr = $this->placeModule( $marr, $nrow, $ncol, 1, $ncol - 1, $chr, 8 );
        return $marr;
    }

    protected function getPlacemetMap( $nrow, $ncol )
    {
        $marr = array_fill( 0, $nrow * $ncol, 0 );
        $chr = 1;
        $row = 4;
        $col = 0;
        do
        {
            if ( $row == $nrow && $col == 0 )
            {
                $marr = $this->placeCornerA( $marr, $nrow, $ncol, $chr );
                ++$chr;
            }
            if ( $row == $nrow - 2 && $col == 0 && $ncol % 4 )
            {
                $marr = $this->placeCornerB( $marr, $nrow, $ncol, $chr );
                ++$chr;
            }
            if ( $row == $nrow - 2 && $col == 0 && $ncol % 8 == 4 )
            {
                $marr = $this->placeCornerC( $marr, $nrow, $ncol, $chr );
                ++$chr;
            }
            if ( $row == $nrow + 4 && $col == 2 && !( $ncol % 8 ) )
            {
                $marr = $this->placeCornerD( $marr, $nrow, $ncol, $chr );
                ++$chr;
            }
            do
            {
                if ( $row < $nrow && 0 <= $col && !$marr[$row * $ncol + $col] )
                {
                    $marr = $this->placeUtah( $marr, $nrow, $ncol, $row, $col, $chr );
                    ++$chr;
                }
                $row -= 2;
                $col += 2;
            } while ( 0 <= $row && $col < $ncol );
            ++$row;
            $col += 3;
            do
            {
                if ( 0 <= $row && $col < $ncol && !$marr[$row * $ncol + $col] )
                {
                    $marr = $this->placeUtah( $marr, $nrow, $ncol, $row, $col, $chr );
                    ++$chr;
                }
                $row += 2;
                $col -= 2;
            } while ( $row < $nrow && 0 <= $col );
            $row += 3;
            ++$col;
        } while ( $row < $nrow || $col < $ncol );
        if ( $marr[$nrow * $ncol - 1] )
        {
            $marr[$nrow * $ncol - 1] = 1;
            $marr[$nrow * $ncol - $ncol - 2] = 1;
        }
        return $marr;
    }

}

if ( defined( "DATAMATRIXDEFS" ) )
{
    define( "DATAMATRIXDEFS", TRUE );
}
define( "ENC_ASCII", 0 );
define( "ENC_C40", 1 );
define( "ENC_TXT", 2 );
define( "ENC_X12", 3 );
define( "ENC_EDF", 4 );
define( "ENC_BASE256", 5 );
define( "ENC_ASCII_EXT", 6 );
define( "ENC_ASCII_NUM", 7 );
?>
