<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class TCPDF_FILTERS
{

    private $available_filters = array( "ASCIIHexDecode", "ASCII85Decode", "LZWDecode", "FlateDecode", "RunLengthDecode" );

    public function getAvailableFilters( )
    {
        return $this->available_filters;
    }

    public function decodeFilter( $filter, $data )
    {
        switch ( $filter )
        {
            case "ASCIIHexDecode" :
                return $this->decodeFilterASCIIHexDecode( $data );
            case "ASCII85Decode" :
                return $this->decodeFilterASCII85Decode( $data );
            case "LZWDecode" :
                return $this->decodeFilterLZWDecode( $data );
            case "FlateDecode" :
                return $this->decodeFilterFlateDecode( $data );
            case "RunLengthDecode" :
                return $this->decodeFilterRunLengthDecode( $data );
            case "CCITTFaxDecode" :
                return $this->decodeFilterCCITTFaxDecode( $data );
            case "JBIG2Decode" :
                return $this->decodeFilterJBIG2Decode( $data );
            case "DCTDecode" :
                return $this->decodeFilterDCTDecode( $data );
            case "JPXDecode" :
                return $this->decodeFilterJPXDecode( $data );
            case "Crypt" :
                return $this->decodeFilterCrypt( $data );
            default :
                return decodefilterstandard( $data );
        }
    }

    public function decodeFilterStandard( $data )
    {
        return $data;
    }

    public function decodeFilterASCIIHexDecode( $data )
    {
        $decoded = "";
        $data = preg_replace( "/[\\s]/", "", $data );
        $eod = strpos( $data, ">" );
        if ( $eod !== FALSE )
        {
            $data = substr( $data, 0, $eod );
            $eod = TRUE;
        }
        $data_length = strlen( $data );
        if ( $data_length % 2 != 0 )
        {
            if ( $eod )
            {
                $data = substr( $data, 0, -1 )."0".substr( $data, -1 );
            }
            else
            {
                $this->Error( "decodeASCIIHex: invalid code" );
            }
        }
        if ( 0 < preg_match( "/[^a-fA-F\\d]/", $data ) )
        {
            $this->Error( "decodeASCIIHex: invalid code" );
        }
        $decoded = pack( "H*", $data );
        return $decoded;
    }

    public function decodeFilterASCII85Decode( $data )
    {
        $decoded = "";
        $data = preg_replace( "/[\\s]/", "", $data );
        if ( strpos( $data, "<~" ) !== FALSE )
        {
            $data = substr( $data, 2 );
        }
        $eod = strpos( $data, "~>" );
        if ( $eod !== FALSE )
        {
            $data = substr( $data, 0, $eod );
        }
        $data_length = strlen( $data );
        if ( 0 < preg_match( "/[^\\x21-\\x75,\\x74]/", $data ) )
        {
            $this->Error( "decodeASCII85: invalid code" );
        }
        $zseq = chr( 0 ).chr( 0 ).chr( 0 ).chr( 0 );
        $group_pos = 0;
        $tuple = 0;
        $pow85 = array( 52200625, 614125, 7225, 85, 1 );
        $last_pos = $data_length - 1;
        $i = 0;
        for ( ; $i < $data_length; ++$i )
        {
            $char = ord( $data[$i] );
            if ( $char == 122 )
            {
                if ( $group_pos == 0 )
                {
                    $decoded .= $zseq;
                }
                else
                {
                    $this->Error( "decodeASCII85: invalid code" );
                }
            }
            else
            {
                $tuple += ( $char - 33 ) * $pow85[$group_pos];
                if ( $group_pos == 4 )
                {
                    $decoded .= chr( $tuple >> 24 ).chr( $tuple >> 16 ).chr( $tuple >> 8 ).chr( $tuple );
                    $tuple = 0;
                    $group_pos = 0;
                }
                else
                {
                    ++$group_pos;
                }
            }
        }
        if ( 1 < $group_pos )
        {
            $tuple += $pow85[$group_pos - 1];
        }
        switch ( $group_pos )
        {
            case 4 :
                $decoded .= chr( $tuple >> 24 ).chr( $tuple >> 16 ).chr( $tuple >> 8 );
                return $decoded;
            case 3 :
                $decoded .= chr( $tuple >> 24 ).chr( $tuple >> 16 );
                return $decoded;
            case 2 :
                $decoded .= chr( $tuple >> 24 );
                return $decoded;
            case 1 :
                $this->Error( "decodeASCII85: invalid code" );
            default :
                return $decoded;
        }
    }

    public function decodeFilterLZWDecode( $data )
    {
        $decoded = "";
        $data_length = strlen( $data );
        $bitstring = "";
        $i = 0;
        for ( ; $i < $data_length; ++$i )
        {
            $bitstring .= sprintf( "%08b", ord( $data[$i] ) );
        }
        $data_length = strlen( $bitstring );
        $bitlen = 9;
        $dix = 258;
        $dictionary = array( );
        $i = 0;
        for ( ; $i < 256; ++$i )
        {
            $dictionary[$i] = chr( $i );
        }
        $prev_index = 0;
        while ( !( 0 < $data_length ) || !( ( $index = bindec( substr( $bitstring, 0, $bitlen ) ) ) != 257 ) )
        {
            $bitstring = substr( $bitstring, $bitlen );
            $data_length -= $bitlen;
            if ( $index == 256 )
            {
                $bitlen = 9;
                $dix = 258;
                $prev_index = 256;
                $dictionary = array( );
                $i = 0;
                for ( ; do
 {
 $i < 256; do
 {
 ++$i, } while ( 1 ) )
                    {
                        $dictionary[$i] = chr( $i );
                    } while ( 1 );
                }
                if ( $prev_index == 256 )
                {
                    $decoded .= $dictionary[$index];
                    $prev_index = $index;
                }
                else
                {
                    if ( $index < $dix )
                    {
                        $decoded .= $dictionary[$index];
                        $dic_val = $dictionary[$prev_index].$dictionary[$index][0];
                        $prev_index = $index;
                    }
                    else
                    {
                        $dic_val = $dictionary[$prev_index].$dictionary[$prev_index][0];
                        $decoded .= $dic_val;
                    }
                    $dictionary[$dix] = $dic_val;
                    ++$dix;
                    if ( $dix == 2047 )
                    {
                        $bitlen = 12;
                    }
                    else if ( $dix == 1023 )
                    {
                        $bitlen = 11;
                    }
                    else if ( $dix == 511 )
                    {
                        $bitlen = 10;
                    }
                }
            }
        }
        return $decoded;
    }

    public function decodeFilterFlateDecode( $data )
    {
        $decoded = gzuncompress( $data );
        if ( $decoded === FALSE )
        {
            $this->Error( "decodeFlate: invalid code" );
        }
        return $decoded;
    }

    public function decodeFilterRunLengthDecode( $data )
    {
        $decoded = "";
        $data_length = strlen( $data );
        $i = 0;
        while ( $i < $data_length )
        {
            $byte = ord( $data[$i] );
            if ( $byte == 128 )
            {
            }
            else if ( $byte < 128 )
            {
                $decoded .= substr( $data, $i + 1, $byte + 1 );
                $i += $byte + 2;
            }
            else
            {
                $decoded .= str_repeat( $data[$i + 1], 257 - $byte );
                $i += 2;
            }
        }
        return $decoded;
    }

    public function decodeFilterCCITTFaxDecode( $data )
    {
        return $data;
    }

    public function decodeFilterJBIG2Decode( $data )
    {
        return $data;
    }

    public function decodeFilterDCTDecode( $data )
    {
        return $data;
    }

    public function decodeFilterJPXDecode( $data )
    {
        return $data;
    }

    public function decodeFilterCrypt( $data )
    {
        return $data;
    }

    public function Error( $msg )
    {
        exit( "<strong>TCPDF_FILTERS ERROR: </strong>".$msg );
    }

}

?>
