<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class TCPDF_PARSER
{

    private $pdfdata = "";
    protected $xref = array( );
    protected $objects = array( );
    private $FilterDecoders;

    public function __construct( $data )
    {
        if ( empty( $data ) )
        {
            $this->Error( "Empty PDF data." );
        }
        $this->pdfdata = $data;
        $pdflen = strlen( $this->pdfdata );
        $this->FilterDecoders = new TCPDF_FILTERS( );
        $this->xref = $this->getXrefData( );
        $this->objects = array( );
        foreach ( $this->xref['xref'] as $obj => $offset )
        {
            if ( isset( $this->objects[$obj] ) )
            {
                $this->objects[$obj] = $this->getIndirectObject( $obj, $offset, TRUE );
            }
        }
        $this->pdfdata = "";
    }

    public function getParsedData( )
    {
        return array( $this->xref, $this->objects );
    }

    protected function getXrefData( $offset = 0, $xref = array( ) )
    {
        if ( preg_match_all( "/[\\r\\n]startxref[\\s]*[\\r\\n]+([0-9]+)[\\s]*[\\r\\n]+%%EOF/i", $this->pdfdata, $matches, PREG_SET_ORDER, $offset ) == 0 )
        {
            $this->Error( "Unable to find startxref" );
        }
        $matches = array_pop( &$matches );
        $startxref = $matches[1];
        if ( strpos( $this->pdfdata, "xref", $startxref ) != $startxref )
        {
            $this->Error( "Unable to find xref" );
        }
        $offset = $startxref + 5;
        $obj_num = 0;
        while ( 0 < preg_match( "/^([0-9]+)[\\s]([0-9]+)[\\s]?([nf]?)/im", $this->pdfdata, $matches, PREG_OFFSET_CAPTURE, $offset ) )
        {
            $offset = strlen( $matches[0][0] ) + $matches[0][1];
            if ( $matches[3][0] == "n" )
            {
                $index = $obj_num."_".intval( $matches[2][0] );
                if ( isset( $xref['xref'][$index] ) )
                {
                    $xref['xref'][$index] = intval( $matches[1][0] );
                }
                ++$obj_num;
                $offset += 2;
            }
            else if ( $matches[3][0] == "f" )
            {
                ++$obj_num;
                $offset += 2;
            }
            else
            {
                $obj_num = intval( $matches[1][0] );
            }
        }
        if ( 0 < preg_match( "/trailer[\\s]*<<(.*)>>[\\s]*[\\r\\n]+startxref[\\s]*[\\r\\n]+/isU", $this->pdfdata, $matches, PREG_OFFSET_CAPTURE, $offset ) )
        {
            $trailer_data = $matches[1][0];
            if ( isset( $xref['trailer'] ) )
            {
                $xref['trailer'] = array( );
                if ( 0 < preg_match( "/Size[\\s]+([0-9]+)/i", $trailer_data, $matches ) )
                {
                    $xref['trailer']['size'] = intval( $matches[1] );
                }
                if ( 0 < preg_match( "/Root[\\s]+([0-9]+)[\\s]+([0-9]+)[\\s]+R/i", $trailer_data, $matches ) )
                {
                    $xref['trailer']['root'] = intval( $matches[1] )."_".intval( $matches[2] );
                }
                if ( 0 < preg_match( "/Encrypt[\\s]+([0-9]+)[\\s]+([0-9]+)[\\s]+R/i", $trailer_data, $matches ) )
                {
                    $xref['trailer']['encrypt'] = intval( $matches[1] )."_".intval( $matches[2] );
                }
                if ( 0 < preg_match( "/Info[\\s]+([0-9]+)[\\s]+([0-9]+)[\\s]+R/i", $trailer_data, $matches ) )
                {
                    $xref['trailer']['info'] = intval( $matches[1] )."_".intval( $matches[2] );
                }
                if ( 0 < preg_match( "/ID[\\s]*[\\[][\\s]*[<]([^>]*)[>][\\s]*[<]([^>]*)[>]/i", $trailer_data, $matches ) )
                {
                    $xref['trailer']['id'] = array( );
                    $xref['trailer']['id'][0] = $matches[1];
                    $xref['trailer']['id'][1] = $matches[2];
                }
            }
            if ( 0 < preg_match( "/Prev[\\s]+([0-9]+)/i", $trailer_data, $matches ) )
            {
                $xref = getxrefdata( substr( $this->pdfdata, 0, $startxref ), intval( $matches[1] ), $xref );
                return $xref;
            }
        }
        $this->Error( "Unable to find trailer" );
        return $xref;
    }

    protected function getRawObject( $offset = 0 )
    {
        $objtype = "";
        $objval = "";
        $offset += strspn( $this->pdfdata, "\x00\t\n\x0C\r ", $offset );
        $char = $this->pdfdata[$offset];
        switch ( $char )
        {
            case "%" :
                $next = strcspn( $this->pdfdata, "\r\n", $offset );
                if ( 0 < $next )
                {
                    $offset += $next;
                    return $this->pdfdata( $this->pdfdata, $offset );
                }
            case "/" :
                $objtype = $char;
                ++$offset;
                if ( preg_match( "/^([^\\x00\\x09\\x0a\\x0c\\x0d\\x20\\s\\x28\\x29\\x3c\\x3e\\x5b\\x5d\\x7b\\x7d\\x2f\\x25]+)/", substr( $this->pdfdata, $offset, 256 ), $matches ) == 1 )
                {
                    $objval = $matches[1];
                    $offset += strlen( $objval );
                    break;
                }
            case "(" :
            case ")" :
                $objtype = $char;
                ++$offset;
                $strpos = $offset;
                if ( $char == "(" )
                {
                    $open_bracket = 1;
                    while ( 0 < $open_bracket )
                    {
                        if ( isset( $this->pdfdata[$strpos] ) )
                        {
                        }
                        else
                        {
                            $ch = $this->pdfdata[$strpos];
                            switch ( $ch )
                            {
                                case "\\" :
                                    ++$strpos;
                                    break;
                                case "(" :
                                    ++$open_bracket;
                                    break;
                                case ")" :
                                    --$open_bracket;
                            }
                            ++$strpos;
                        }
                    }
                    $objval = substr( $this->pdfdata, $offset, $strpos - $offset - 1 );
                    $offset = $strpos;
                    break;
                }
            case "[" :
            case "]" :
                $objtype = $char;
                ++$offset;
                if ( $char == "[" )
                {
                    $objval = array( );
                    do
                    {
                        $element = $this->getRawObject( $offset );
                        $offset = $element[2];
                        $objval[] = $element;
                    } while ( $element[0] != "]" );
                    array_pop( &$objval );
                    break;
                }
            case "<" :
            case ">" :
                if ( isset( $this->pdfdata[$offset + 1] ) && $this->pdfdata[$offset + 1] == $char )
                {
                    $objtype = $char.$char;
                    $offset += 2;
                    if ( $char == "<" )
                    {
                        $objval = array( );
                        do
                        {
                            $element = $this->getRawObject( $offset );
                            $offset = $element[2];
                            $objval[] = $element;
                        } while ( $element[0] != ">>" );
                        array_pop( &$objval );
                        break;
                    }
                }
                else
                {
                    $objtype = $char;
                    ++$offset;
                    if ( !( $char == "<" ) || !( preg_match( "/^([0-9A-Fa-f]+)[>]/iU", substr( $this->pdfdata, $offset ), $matches ) == 1 ) )
                    {
                        $objval = $matches[1];
                        $offset += strlen( $matches[0] );
                        break;
                    }
                }
            default :
                if ( substr( $this->pdfdata, $offset, 6 ) == "endobj" )
                {
                    $objtype = "endobj";
                    $offset += 6;
                }
                else if ( substr( $this->pdfdata, $offset, 4 ) == "null" )
                {
                    $objtype = "null";
                    $offset += 4;
                    $objval = "null";
                }
                else if ( substr( $this->pdfdata, $offset, 4 ) == "true" )
                {
                    $objtype = "boolean";
                    $offset += 4;
                    $objval = "true";
                }
                else if ( substr( $this->pdfdata, $offset, 5 ) == "false" )
                {
                    $objtype = "boolean";
                    $offset += 5;
                    $objval = "false";
                }
                else if ( substr( $this->pdfdata, $offset, 6 ) == "stream" )
                {
                    $objtype = "stream";
                    $offset += 6;
                    if ( preg_match( "/^[\\r\\n]+(.*)[\\r\\n]*endstream/isU", substr( $this->pdfdata, $offset ), $matches ) == 1 )
                    {
                        $objval = $matches[1];
                        $offset += strlen( $matches[0] );
                    }
                }
                else if ( substr( $this->pdfdata, $offset, 9 ) == "endstream" )
                {
                    $objtype = "endstream";
                    $offset += 9;
                }
                else if ( preg_match( "/^([0-9]+)[\\s]+([0-9]+)[\\s]+R/iU", substr( $this->pdfdata, $offset, 33 ), $matches ) == 1 )
                {
                    $objtype = "ojbref";
                    $offset += strlen( $matches[0] );
                    $objval = intval( $matches[1] )."_".intval( $matches[2] );
                }
                else if ( preg_match( "/^([0-9]+)[\\s]+([0-9]+)[\\s]+obj/iU", substr( $this->pdfdata, $offset, 33 ), $matches ) == 1 )
                {
                    $objtype = "ojb";
                    $objval = intval( $matches[1] )."_".intval( $matches[2] );
                    $offset += strlen( $matches[0] );
                }
                else if ( 0 < ( $numlen = strspn( $this->pdfdata, "+-.0123456789", $offset ) ) )
                {
                    $objtype = "numeric";
                    $objval = substr( $this->pdfdata, $offset, $numlen );
                    $offset += $numlen;
                }
        }
        return array( $objtype, $objval, $offset );
    }

    protected function getIndirectObject( $obj_ref, $offset = 0, $decoding = TRUE )
    {
        $obj = explode( "_", $obj_ref );
        if ( $obj === FALSE || count( $obj ) != 2 )
        {
            $this->Error( "Invalid object reference: ".$obj );
        }
        else
        {
            $objref = $obj[0]." ".$obj[1]." obj";
            if ( strpos( $this->pdfdata, $objref, $offset ) != $offset )
            {
                return array( "null", "null", $offset );
            }
            $offset += strlen( $objref );
            $objdata = array( );
            $i = 0;
            do
            {
                $element = $this->getRawObject( $offset );
                $offset = $element[2];
                if ( $decoding && $element[0] == "stream" && isset( $objdata[$i - 1][0] ) && $objdata[$i - 1][0] == "<<" )
                {
                    $element[3] = $element[1]( $objdata[$i - 1][1], $element[1] );
                }
                $objdata[$i] = $element;
                ++$i;
            } while ( $element[0] != "endobj" );
            array_pop( &$objdata );
            return $objdata;
        }
    }

    protected function getObjectVal( $obj )
    {
        if ( $obj[0] == "objref" )
        {
            if ( isset( $this->objects[$obj[1]] ) )
            {
                return $this->objects[$obj[1]];
            }
            if ( isset( $this->xref[$obj[1]] ) )
            {
                $this->objects[$obj[1]] = $this->xref[$obj[1]]( $obj[1], $this->xref[$obj[1]], FALSE );
                return $this->objects[$obj[1]];
            }
        }
        return $obj;
    }

    protected function decodeStream( $sdic, $stream )
    {
        $slength = strlen( $stream );
        $filters = array( );
        foreach ( $sdic as $k => $v )
        {
            if ( !( $v[0] == "/" ) )
            {
                continue;
            }
            else if ( $v[1] == "Length" && isset( $sdic[$k + 1] ) && $sdic[$k + 1][0] == "numeric" )
            {
                $declength = intval( $sdic[$k + 1][1] );
                if ( $declength < $slength )
                {
                    $stream = substr( $stream, 0, $declength );
                    $slength = $declength;
                }
            }
            else if ( !( $v[1] == "Filter" ) || !isset( $sdic[$k + 1] ) )
            {
                $objval = $sdic[$k + 1]( $sdic[$k + 1] );
                if ( $objval[0] == "/" )
                {
                    $filters[] = $objval[1];
                }
                else if ( $objval[0] == "[" )
                {
                    foreach ( $objval[1] as $flt )
                    {
                        if ( $flt[0] == "/" )
                        {
                            $filters[] = $flt[1];
                        }
                    }
                }
            }
        }
        $remaining_filters = array( );
        foreach ( $filters as $filter )
        {
            if ( in_array( $filter, $this->FilterDecoders->getAvailableFilters( ) ) )
            {
                $stream = $this->FilterDecoders->decodeFilter( $filter, $stream );
            }
            else
            {
                $remaining_filters[] = $filter;
            }
        }
        return array( $stream, $remaining_filters );
    }

    public function Error( $msg )
    {
        exit( "<strong>TCPDF_PARSER ERROR: </strong>".$msg );
    }

}

require_once( dirname( __FILE__ )."/tcpdf_filters.php" );
?>
