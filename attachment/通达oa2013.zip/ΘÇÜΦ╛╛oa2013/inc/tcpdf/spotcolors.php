<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
$spotcolor = array( "mytcpdfblack" => array( 0, 0, 0, 100, "My TCPDF Black" ), "mytcpdfred" => array( 30, 100, 90, 10, "My TCPDF Red" ), "mytcpdfgreen" => array( 100, 30, 100, 0, "My TCPDF Green" ), "mytcpdfblue" => array( 100, 60, 10, 5, "My TCPDF Blue" ), "mytcpdfyellow" => array( 0, 20, 100, 0, "My TCPDF Yellow" ) );
?>
