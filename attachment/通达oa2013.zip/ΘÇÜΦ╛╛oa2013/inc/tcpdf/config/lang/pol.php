<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
global $l;
$l = array( );
$l['a_meta_charset'] = "UTF-8";
$l['a_meta_dir'] = "ltr";
$l['a_meta_language'] = "pl";
$l['w_page'] = "strona";
?>
