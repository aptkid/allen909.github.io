<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
function Message( $TITLE, $CONTENT, $STYLE = "", $BUTTONS = array( ) )
{
    $WIDTH = strlen( $CONTENT ) * 15 + 140;
    $WIDTH = 500 < $WIDTH ? 500 : $WIDTH;
    if ( $WIDTH < 220 )
    {
        $WIDTH = 220;
    }
    if ( $STYLE == "blank" )
    {
        $WIDTH -= 70;
    }
    if ( $STYLE == "" )
    {
        if ( $TITLE == _( "����" ) )
        {
            $STYLE = "error";
        }
        else if ( $TITLE == _( "����" ) )
        {
            $STYLE = "warning";
        }
        else if ( $TITLE == _( "ֹͣ" ) )
        {
            $STYLE = "stop";
        }
        else if ( $TITLE == _( "��ֹ" ) )
        {
            $STYLE = "forbidden";
        }
        else if ( $TITLE == _( "����" ) )
        {
            $STYLE = "help";
        }
        else
        {
            $STYLE = "info";
        }
    }
    echo "<table class=\"MessageBox\" align=\"center\" width=\"";
    echo $WIDTH;
    echo "\" cellpadding=\"0\" cellspacing=\"0\">\r\n";
    if ( $TITLE != "" )
    {
        echo "   <tr class=\"head\">\r\n      <td class=\"left\"></td>\r\n      <td class=\"center\">\r\n         <div class=\"title\">";
        echo $TITLE;
        echo "</div>\r\n      </td>\r\n      <td class=\"right\"></td>\r\n   </tr>\r\n";
    }
    else
    {
        echo "   <tr class=\"head-no-title\">\r\n      <td class=\"left\"></td>\r\n      <td class=\"center\">\r\n      </td>\r\n      <td class=\"right\"></td>\r\n   </tr>\r\n";
    }
    echo "   <tr class=\"msg\">\r\n      <td class=\"left\"></td>\r\n      <td class=\"center ";
    echo $STYLE;
    echo "\">\r\n         <div class=\"msg-content\">";
    echo $CONTENT;
    echo "</div>\r\n      </td>\r\n      <td class=\"right\"></td>\r\n   </tr>\r\n";
    if ( is_array( $BUTTONS ) && 0 < count( $BUTTONS ) )
    {
        echo "   <tr class=\"control\">\r\n      <td class=\"left\"></td>\r\n      <td class=\"center\">\r\n";
        foreach ( $BUTTONS as $BUTTON )
        {
            echo "<a class=\"BigBtn\" href=\"".( $BUTTON['href'] != "" ? str_replace( "\"", "\\\"", $BUTTON['href'] ) : "javascript:;" )."\"";
            if ( $BUTTON['click'] != "" )
            {
                echo " onclick=\"".str_replace( "\"", "\\\"", $BUTTON['click'] )."\"";
            }
            echo "><span>".$BUTTON['value']."</span></a>&nbsp;&nbsp;";
        }
        echo "      </td>\r\n      <td class=\"right\"></td>\r\n   </tr>\r\n";
    }
    echo "   <tr class=\"foot\">\r\n      <td class=\"left\"></td>\r\n      <td class=\"center\"><b></b></td>\r\n      <td class=\"right\"></td>\r\n   </tr>\r\n</table>\r\n";
}

function Button_Close( $HTML_CHARSET = "", $VALUENAME = "" )
{
    if ( $VALUENAME )
    {
        $VALUE = _( $VALUENAME );
    }
    else
    {
        $VALUE = _( "�ر�" );
    }
    if ( $HTML_CHARSET != "" )
    {
        $VALUE = iconv( MYOA_CHARSET, $HTML_CHARSET, $VALUE );
    }
    echo "   <br><center><input type=\"button\" class=\"BigButtonA\" value=\"";
    echo $VALUE;
    echo "\" onclick=\"window.close();\"></center>\r\n";
}

function Button_Back( $HTML_CHARSET = "" )
{
    $VALUE = _( "����" );
    if ( $HTML_CHARSET != "" )
    {
        $VALUE = iconv( MYOA_CHARSET, $HTML_CHARSET, $VALUE );
    }
    echo "   <br><center><input type=\"button\" class=\"BigButtonA\" value=\"";
    echo $VALUE;
    echo "\" onclick=\"history.back();\"></center>\r\n";
}

function Button_Back_Law( )
{
    echo "<br><center><input type=\"button\" class=\"BigButtonB\" value=\"";
    echo _( "����һ��" );
    echo "\" onclick=\"history.back();\">&nbsp;&nbsp;<input type=\"button\" class=\"BigButton\" value=\"";
    echo _( "����Ŀ¼" );
    echo "\" onclick=\"location='/general/info/law/';\"></center><br>";
}

function find_id( $STRING, $ID )
{
    $STRING = ltrim( $STRING, "," );
    if ( $ID == "" || $ID == "," )
    {
        return FALSE;
    }
    if ( substr( $STRING, -1 ) != "," )
    {
        $STRING .= ",";
    }
    if ( 0 < strpos( $STRING, ",".$ID."," ) )
    {
        return TRUE;
    }
    if ( strpos( $STRING, $ID."," ) === 0 )
    {
        return TRUE;
    }
    if ( !strstr( $ID, "," ) && $STRING == $ID )
    {
        return TRUE;
    }
    return FALSE;
}

function remove_id( $STRING, $ID )
{
    if ( strpos( $STRING, $ID."," ) == 0 )
    {
        $STRING = substr( $STRING, strlen( $ID ) + 1 );
        return $STRING;
    }
    $STRING = str_replace( ",".$ID.",", "", $STRING );
    return $STRING;
}

function merge_id( )
{
    $argc = func_num_args( );
    $argv = func_get_args( );
    $result = array( );
    $i = 0;
    for ( ; $i < $argc; ++$i )
    {
        $result = array_merge( $result, explode( ",", rtrim( $argv[$i], "," ) ) );
    }
    return implode( ",", array_unique( $result ) );
}

function check_priv_other( $str, $needle )
{
    $arr = explode( ",", $needle );
    if ( 0 < count( $arr ) )
    {
        foreach ( $arr as $key => $value )
        {
            if ( find_id( $str, $value ) )
            {
                return TRUE;
                break;
            }
        }
        return FALSE;
    }
}

function find_id_plus( $mixstr, $ID, $septor )
{
    if ( $ID == "" || $ID == "," )
    {
        return FALSE;
    }
    $arr_string = explode( $septor, $mixstr );
    $STRING = "";
    foreach ( $arr_string as $k => $v )
    {
        $v = ltrim( $v, "," );
        if ( substr( $v, -1 ) != "," )
        {
            $v .= ",";
        }
        $STRING .= $v;
    }
    if ( substr( $STRING, -1 ) != "," )
    {
        $STRING .= ",";
    }
    if ( 0 < strpos( $STRING, ",".$ID."," ) )
    {
        return TRUE;
    }
    if ( strpos( $STRING, $ID."," ) === 0 )
    {
        return TRUE;
    }
    if ( !strstr( $ID, "," ) && $STRING == $ID )
    {
        return TRUE;
    }
    return FALSE;
}

function check_id( $STRING, $ID, $FLAG = TRUE )
{
    $MY_ARRAY = explode( ",", $ID );
    $ARRAY_COUNT = sizeof( $MY_ARRAY );
    if ( $MY_ARRAY[$ARRAY_COUNT - 1] == "" )
    {
        --$ARRAY_COUNT;
    }
    $I = 0;
    for ( ; $I < $ARRAY_COUNT; ++$I )
    {
        if ( $FLAG )
        {
            if ( find_id( $STRING, $MY_ARRAY[$I] ) )
            {
                $ID_STR .= $MY_ARRAY[$I].",";
            }
        }
        else if ( find_id( $STRING, $MY_ARRAY[$I] ) )
        {
            $ID_STR .= $MY_ARRAY[$I].",";
        }
    }
    return $ID_STR;
}

function update_my_online_status( $CLIENT = 0 )
{
    $query = "update USER_ONLINE set TIME='".time( )."',CLIENT='".$CLIENT."' where SID='".session_id( )."'";
    exequery( ( ), $query );
    if ( mysql_affected_rows( ) == 0 )
    {
        $query = "insert into USER_ONLINE values('".$_SESSION['LOGIN_UID']."','".time( )."','".session_id( )."','".$CLIENT."')";
        exequery( ( ), $query );
    }
}

function clear_online_status( )
{
    $query = "delete from USER_ONLINE where TIME<'".( time( ) - MYOA_ONLINE_REF_SEC - 10 )."'";
    $cursor = exequery( ( ), $query );
    $ONLINE_UID_STR = "";
    $ONLINE_CLIENT_STR = "";
    $DEPT_ID_STR = "";
    $DEPARTMENT_ARRAY = ( "SYS_DEPARTMENT" );
    $TIME = time( ) - MYOA_ONLINE_REF_SEC - 10;
    $USER_ONLINE = $NEW_USER_ONLINE = array( );
    $query = "select UID,CLIENT from USER_ONLINE where TIME>='".$TIME."'";
    $cursor = exequery( ( ), $query, TRUE );
    while ( $ROW = mysql_fetch_array( $cursor ) )
    {
        $USER_ONLINE[$ROW['UID']][] = $ROW['CLIENT'];
    }
    $online_policy = array( "2", "5", "6", "0" );
    foreach ( $USER_ONLINE as $key => $value )
    {
        foreach ( $online_policy as $k => $v )
        {
            if ( in_array( $v, $value ) )
            {
                $NEW_USER_ONLINE[$key] = $v;
                break;
            }
        }
    }
    $query = "select USER.UID,USER_ID,USER_NAME,DEPT_ID,DEPT_ID_OTHER,SEX,ON_STATUS,USER_PRIV,USER_PRIV_NO,CLIENT from USER,USER_ONLINE where USER_ONLINE.TIME>='".$TIME."' and USER.UID=USER_ONLINE.UID and USER.DEPT_ID!=0 group by USER_ONLINE.UID order by USER_PRIV_NO,USER_NO,USER_NAME";
    $cursor = exequery( ( ), $query, TRUE );
}
if ( $ROW = mysql_fetch_array( $cursor ) )
{
    $UID = $ROW['UID'];
    $USER_ID = $ROW['USER_ID'];
    $USER_NAME = $ROW['USER_NAME'];
    $SEX = $ROW['SEX'];
    $ON_STATUS = $ROW['ON_STATUS'];
    $DEPT_ID = $ROW['DEPT_ID'];
    $DEPT_ID_OTHER = $ROW['DEPT_ID_OTHER'];
    $USER_PRIV = $ROW['USER_PRIV'];
    $PRIV_NO = $ROW['USER_PRIV_NO'];
    $CLIENT = $NEW_USER_ONLINE[$UID];
    if ( substr( $USER_ID, -1 ) == "\\" )
    {
        $USER_ID .= "\\";
    }
    if ( substr( $USER_NAME, -1 ) == "\\" )
    {
        $USER_NAME .= "\\";
    }
    $SEX = $SEX == "" ? "0" : $SEX;
    $ON_STATUS = $ON_STATUS != "2" && $ON_STATUS != "3" ? "1" : $ON_STATUS;
    $USER_STR .= "   \"".$UID."\"=> array(\"USER_ID\" => \"".$USER_ID."\", \"USER_NAME\" => \"".$USER_NAME."\", \"DEPT_ID\" => \"".$DEPT_ID."\", \"DEPT_ID_OTHER\" => \"".$DEPT_ID_OTHER."\", \"SEX\" => \"".$SEX."\", \"ON_STATUS\" => \"".$ON_STATUS."\", \"USER_PRIV\" => \"".$USER_PRIV."\", \"PRIV_NO\" => \"".$PRIV_NO."\", \"CLIENT\" => \"".$CLIENT."\"),\n";
    $ONLINE_UID_STR .= $UID.",";
    $ONLINE_CLIENT_STR .= $CLIENT.",";
    $ON_STATUS_STR .= $ON_STATUS.",";
    $DEPT_ID_ALL = $DEPT_ID.",".$DEPT_ID_OTHER;
    $DEPT_ID_ARRAY = explode( ",", $DEPT_ID_ALL );
    $I = 0;
    do
    {
        for ( ; $I < count( $DEPT_ID_ARRAY ); do
 {
 ++$I, } while ( 1 ) )
        {
            $DEPT_ID = $DEPT_ID_ARRAY[$I];
            do
            {
            } while ( $DEPT_ID == "" || !( 0 < $DEPT_ID ) || find_id( $DEPT_ID_STR, $DEPT_ID ) );
            $DEPT_ID_STR .= $DEPT_ID.",";
            $DEPT_ID = $DEPARTMENT_ARRAY[$DEPT_ID]['DEPT_PARENT'];
        } while ( 1 );
    }
    while ( list( $DEPT_ID, $DEPT ) = each( &$DEPARTMENT_ARRAY ) )
    {
        if ( find_id( $DEPT_ID_STR, $DEPT_ID ) )
        {
            $DEPT_STR .= "   \"".$DEPT_ID."\"=> array(\"DEPT_NAME\" => \"".$DEPT['DEPT_NAME']."\", \"DEPT_PARENT\" => \"".$DEPT['DEPT_PARENT']."\", \"DEPT_LONG_NAME\" => \"".$DEPT['DEPT_LONG_NAME']."\", \"IS_ORG\" => \"".$DEPT['IS_ORG']."\"),\n";
        }
    }
    $USER_ARRAY = "\$SYS_ONLINE_USER = array(\n".$USER_STR.");";
    $DEPT_ARRAY = "\$SYS_ONLINE_DEPT = array(\n".$DEPT_STR.");";
    eval( $USER_ARRAY );
    eval( $DEPT_ARRAY );
    $SYS_ONLINE_UID_CLIENT = $ONLINE_UID_STR."|".$ONLINE_CLIENT_STR."|".$ON_STATUS_STR;
    ( "SYS_ONLINE_USER", $SYS_ONLINE_USER, MYOA_ONLINE_REF_SEC + 10 );
    ( "SYS_ONLINE_DEPT", $SYS_ONLINE_DEPT, MYOA_ONLINE_REF_SEC + 10 );
    ( "SYS_ONLINE_UID_CLIENT", $SYS_ONLINE_UID_CLIENT, MYOA_ONLINE_REF_SEC + 10 );
}

function cache_menu( )
{
    include_once( "utility_all.php" );
    $LANG_ARRAY = get_lang_array( );
    $CACHE_ARRAY = array( );
    $query = "SELECT * from SYS_MENU order by MENU_ID";
    $cursor = exequery( ( ), $query, TRUE );
    do
    {
        if ( $ROW = mysql_fetch_array( $cursor ) )
        {
            $MENU_NAME = str_replace( array( "\"", "\\", "'" ), array( "", "/", "" ), $ROW['MENU_NAME'] );
            $IMAGE = str_replace( array( "\"", "\\", "'" ), array( "", "/", "" ), $ROW['IMAGE'] );
            $MENU_EXT = unserialize( $ROW['MENU_EXT'] );
            reset( &$LANG_ARRAY );
            foreach ( $LANG_ARRAY as $LANG => $VALUE )
            {
                if ( is_array( $MENU_EXT ) && $MENU_EXT[$LANG] != "" )
                {
                    $MENU_NAME_SHOW = $MENU_EXT[$LANG];
                }
                else
                {
                    $MENU_NAME_SHOW = $MENU_NAME;
                }
                $CACHE_ARRAY[$LANG] .= "cache2";
                $CACHE_ARRAY[$LANG] .= "cache3";
            }
            $query = "SELECT * from SYS_FUNCTION where MENU_ID like '".$ROW['MENU_ID']."%' order by MENU_ID";
            $cursor1 = exequery( ( ), $query, TRUE );
            do
            {
            } while ( !( $ROW = mysql_fetch_array( $cursor1 ) ) );
            $FUNC_ID = $ROW['FUNC_ID'];
            $FUNC_NAME = str_replace( array( "\"", "\\", "'" ), array( "", "/", "" ), $ROW['FUNC_NAME'] );
            $FUNC_CODE = str_replace( array( "\"", "\\", "'" ), array( "", "/", "" ), $ROW['FUNC_CODE'] );
            $FUNC_EXT = unserialize( $ROW['FUNC_EXT'] );
            $OPEN_WINDOW = substr( $FUNC_CODE, 0, 2 ) == "1:" ? 1 : 0;
            $FUNC_CODE = substr( $FUNC_CODE, 0, 2 ) == "1:" ? substr( $FUNC_CODE, 2 ) : $FUNC_CODE;
            if ( 10000 <= $FUNC_ID && $FUNC_ID <= 20000 )
            {
                $IMAGE = "fis";
            }
            else if ( stristr( $FUNC_CODE, "http://" ) )
            {
                $IMAGE = "menu_url";
            }
            else if ( stristr( $FUNC_CODE, "file://" ) )
            {
                $IMAGE = "winexe";
            }
            else if ( stristr( $FUNC_CODE, "/" ) )
            {
                $IMAGE = substr( $FUNC_CODE, 0, strpos( $FUNC_CODE, "/" ) );
            }
            else
            {
                $IMAGE = $FUNC_CODE;
            }
            reset( &$LANG_ARRAY );
            foreach ( $LANG_ARRAY as $LANG => $VALUE )
            {
                if ( is_array( $FUNC_EXT ) && $FUNC_EXT[$LANG] != "" )
                {
                    $FUNC_NAME_SHOW = $FUNC_EXT[$LANG];
                }
                else
                {
                    $FUNC_NAME_SHOW = $FUNC_NAME;
                }
                $FUNC_NAME_INDEX = convertchnprefix( trim( getchnprefix( $FUNC_NAME_SHOW ), "*" ) );
                $CACHE_ARRAY[$LANG] .= "cache1";
                $CACHE_ARRAY[$LANG] .= "cache2";
                $CACHE_ARRAY[$LANG] .= "cache3";
                if ( $OPEN_WINDOW )
                {
                    $CACHE_ARRAY[$LANG] .= "cache2";
                    $CACHE_ARRAY[$LANG] .= "cache3";
                }
                $CACHE_ARRAY[$LANG] .= "cache2";
                $CACHE_ARRAY[$LANG] .= "cache3";
            }
        } while ( 1 );
    }
    foreach ( $CACHE_ARRAY as $LANG => $VALUE )
    {
        $name1 = "SYS_FUNCTION_".bin2hex( $LANG );
        $name2 = "SYS_FUNCTION_ALL_".bin2hex( $LANG );
        $cache1 = "\$".$name1." = array(\n".substr( $CACHE_ARRAY[$LANG]['cache1'], 0, -2 )."\n);";
        $cache2 = "\$".$name2." = array(\n".substr( $CACHE_ARRAY[$LANG]['cache2'], 0, -2 )."\n);";
        eval( $cache1 );
        eval( $cache2 );
        ( $name1, $$name1, 0 );
        ( $name2, $$name2, 0 );
        $cache3 = "var func_array={};\n".$CACHE_ARRAY[$LANG]['cache3'];
        $cache_file3 = MYOA_ATTACH_PATH."cache/sys_function_".bin2hex( $LANG ).".js";
        if ( file_exists( $cache_file3 ) && !is_writable( $cache_file3 ) )
        {
            file_put_contents( $cache_file3, $cache3 );
        }
    }
}

function get_lang_array( )
{
    $LANG_ARRAY = array( "zh-CN" => _( "��������" ) );
    $LANG_FILE = MYOA_ROOT_PATH."lang/language.ini";
    if ( MYOA_IS_UN != 1 || !file_exists( $LANG_FILE ) )
    {
        return $LANG_ARRAY;
    }
    $ARRAY = parse_ini_file( $LANG_FILE );
    foreach ( $ARRAY as $LANG => $LANG_DESC )
    {
        $LANG = trim( $LANG );
        $LANG_DESC = trim( $LANG_DESC );
        if ( array_key_exists( $LANG, $LANG_ARRAY ) )
        {
            $LANG_ARRAY[$LANG] = $LANG_DESC;
        }
    }
    return $LANG_ARRAY;
}

function new_sms_remind( $UID, $REMIND = 1, $TYPE = 0 )
{
    if ( file_exists( MYOA_ATTACH_PATH."new_sms" ) )
    {
        mkdir( MYOA_ATTACH_PATH."new_sms", 448 );
    }
    $SMS_FILE = MYOA_ATTACH_PATH."new_sms/".$UID.".sms";
    if ( file_exists( $SMS_FILE ) )
    {
        file_put_contents( $SMS_FILE, "00" );
    }
    $fp = fopen( $SMS_FILE, "r+" );
    if ( $fp )
    {
        $DATA = fread( $fp, 2 );
        $REMIND_1 = intval( substr( $DATA, 0, 1 ) );
        $REMIND_2 = intval( substr( $DATA, 1, 1 ) );
        if ( $TYPE == 0 )
        {
            $DATA_NEW = sprintf( "%d%d", $REMIND, $REMIND_2 );
        }
        else
        {
            $DATA_NEW = sprintf( "%d%d", $REMIND_1, $REMIND );
        }
        if ( $DATA != $DATA_NEW )
        {
            fseek( $fp, 0 );
            fwrite( $fp, $DATA_NEW );
        }
        fclose( $fp );
    }
    return $DATA_NEW;
}

function td_trim( $STR, $charlist = " ,\t\n\r\x00\x0B" )
{
    return trim( $STR, $charlist );
}

function is_default_charset( $str )
{
    $str_utf8 = iconv( MYOA_CHARSET, "utf-8", $str );
    $str_default = iconv( "utf-8", MYOA_CHARSET, $str_utf8 );
    return $str_default == $str;
}

function get_attachment_filename( $filename )
{
    $filename_utf8 = iconv( MYOA_CHARSET, "utf-8", $filename );
    $filename_encoded = str_replace( "+", "%20", urlencode( $filename_utf8 ) );
    $filename_return = "";
    if ( preg_match( "/msie|trident/i", $_SERVER['HTTP_USER_AGENT'] ) )
    {
        if ( MYOA_IS_UN )
        {
            $filename_return = "filename=\"".$filename_encoded."\"";
        }
        else
        {
            $filename_return = "filename=\"".$filename."\"";
        }
    }
    else if ( preg_match( "/Firefox/", $_SERVER['HTTP_USER_AGENT'] ) )
    {
        if ( "8.0" <= substr( $_SERVER['HTTP_USER_AGENT'], stripos( $_SERVER['HTTP_USER_AGENT'], "Firefox" ) + 8, 3 ) )
        {
            $filename_return = "filename=\"".$filename_utf8."\"";
        }
        else
        {
            $filename_return = "filename*=\"utf8''".$filename_utf8."\"";
        }
    }
    else
    {
        $filename_return = "filename=\"".$filename_utf8."\"";
    }
    if ( preg_match_all( "/&#([0-9a-z]{4}|[0-9a-z]{6});/i", $filename_return, $array ) )
    {
        $i = 0;
        for ( ; $i < count( $array[0] ); ++$i )
        {
            $filename_return = str_replace( $array[0][$i], mb_convert_encoding( $array[0][$i], MYOA_CHARSET, "HTML-ENTITIES" ), $filename_return );
        }
    }
    return $filename_return;
}

function get_client_ip( )
{
    $ip = $_SERVER['REMOTE_ADDR'];
    if ( isset( $_SERVER['HTTP_CLIENT_IP'] ) && preg_match( "/^([0-9]{1,3}\\.){3}[0-9]{1,3}$/", $_SERVER['HTTP_CLIENT_IP'] ) )
    {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
        return $ip;
    }
    if ( isset( $_SERVER['HTTP_X_FORWARDED_FOR'] ) && preg_match_all( "#\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}#s", $_SERVER['HTTP_X_FORWARDED_FOR'], $matches ) )
    {
        foreach ( $matches[0] as $xip )
        {
            if ( $xip != "127.0.0.1" )
            {
                $ip = $xip;
                break;
            }
        }
    }
    return $ip;
}

function td_htmlspecialchars( $str, $chars = "" )
{
    if ( $chars == "" )
    {
        return htmlspecialchars( $str );
    }
    $chars_array = array_unique( str_split( $chars ) );
    $chars_array = array_intersect( $chars_array, array( "<", ">", "\"", "'", "&" ) );
    if ( !is_array( $chars_array ) || count( $chars_array ) == 0 )
    {
        return $str;
    }
    $replace_array = array( );
    $i = 0;
    for ( ; $i < count( $chars_array ); ++$i )
    {
        $replace_array[$i] = htmlspecialchars( $chars_array[$i] );
    }
    return str_replace( $chars_array, $replace_array, $str );
}

function td_json_encode( $a = NULL )
{
    if ( is_null( $a ) )
    {
        return "null";
    }
    if ( $a === FALSE )
    {
        return "false";
    }
    if ( $a === TRUE )
    {
        return "true";
    }
    if ( is_scalar( $a ) )
    {
        if ( is_float( $a ) )
        {
            return floatval( str_replace( ",", ".", strval( $a ) ) );
        }
        if ( is_string( $a ) )
        {
            static $jsonReplaces = array( array( "\\", "/", "\n", "\t", "\r", "\\b", "\\f", "\"" ), array( "\\\\", "\\/", "\\n", "\\t", "\\r", "\\b", "\\f", "\\\"" ) );
            return "\"".str_replace( $jsonReplaces[0], $jsonReplaces[1], $a )."\"";
        }
        return $a;
    }
    $isList = TRUE;
    $i = 0;
    reset( &$a );
    for ( ; $i < count( $a ); ++$i, next( &$a ) )
    {
        if ( key( &$a ) !== $i )
        {
            $isList = FALSE;
        }
    }
    $result = array( );
    if ( $isList )
    {
        foreach ( $a as $v )
        {
            $result[] = td_json_encode( $v );
        }
        return "[".join( ",", $result )."]";
    }
    foreach ( $a as $k => $v )
    {
        $result[] = td_json_encode( $k ).":".td_json_encode( $v );
    }
    return "{".join( ",", $result )."}";
}

function td_json_decode( $json )
{
    $comment = FALSE;
    $out = "\$x=";
    $i = 0;
    for ( ; $i < strlen( $json ); ++$i )
    {
        if ( $comment )
        {
            if ( $json[$i] == "{" )
            {
                $out .= " array(";
            }
            else
            {
                if ( $json[$i] == "}" )
                {
                    $out .= ")";
                }
                else
                {
                    if ( $json[$i] == ":" )
                    {
                        $out .= "=>";
                    }
                    else
                    {
                        $out .= $json[$i];
                    }
                }
            }
        }
        else
        {
            $out .= $json[$i];
        }
        if ( $json[$i] == "\"" )
        {
            $comment = !$comment;
        }
    }
    eval( $out.";" );
    return $x;
}

function td_explode( $spr, $str, $charset = "" )
{
    if ( $charset == "" )
    {
        $charset = MYOA_CHARSET;
    }
    $arr = array( );
    $arr = explode( $spr, iconv( $charset, "UTF-8", $str ) );
    foreach ( $arr as $k => $v )
    {
        $arr[$k] = iconv( "UTF-8", $charset, $v );
    }
    return $arr;
}

function help( $q_id, $sort_code )
{
    return "<a href=\"/module/help/answer.php?q_id=".$q_id."&sort_code=".$sort_code."\" target=\"_blank\"><img src=\"".MYOA_STATIC_SERVER."/static/images/help.png\" /></a>";
}

function td_verify_ids( $ids )
{
    return !preg_match( "/[^0-9,]+/", $ids );
}

function td_verify_user_id( $user_id )
{
    return !preg_match( "/['\"<>\\/\\\\:;,%\\&\\+]+/", $user_id );
}

function td_verify_user_ids( $user_ids )
{
    return !preg_match( "/['\"<>\\/\\\\:;%\\&\\+]+/", $user_ids );
}

include_once( "inc/td_config.php" );
$BUTTON_BACK = array( array( "value" => _( "����" ), "href" => "javascript:history.back();" ) );
$BUTTON_CLOSE = array( array( "value" => _( "�ر�" ), "href" => "javascript:window.close();" ) );
$BUTTON_CLOSE_TAB = array( array( "value" => _( "�ر�" ), "href" => "javascript:window.top.closeTab();" ) );
?>
