<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
include_once( "inc/auth.inc.php" );
ob_end_clean( );
include_once( "inc/header.inc.php" );
echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"";
echo MYOA_STATIC_SERVER;
echo "/static/images/org/ui.dynatree.css";
echo $GZIP_POSTFIX;
echo "\">\r\n<style>\r\n*{padding:0px;margin:0px;}\r\n</style>\r\n<script type=\"text/javascript\" src=\"";
echo MYOA_JS_SERVER;
echo "/static/js/jquery-1.5.1/jquery.min.js";
echo $GZIP_POSTFIX;
echo "\"></script>\r\n<script type=\"text/javascript\" src=\"/inc/js_lang.php\"></script>\r\n<script type=\"text/javascript\" src=\"";
echo MYOA_JS_SERVER;
echo "/static/js/tree.js";
echo $GZIP_POSTFIX;
echo "\"></script>\r\n<script type=\"text/javascript\">\r\nvar show_ip = ";
echo $SHOW_IP ? "true" : "false";
echo ";\r\nvar tree = null;\r\nwindow.onload = function(){\r\n   tree = new Tree(\"";
echo $TREE_ID;
echo "\", \"";
echo $JSON_URL;
echo "\", '";
echo MYOA_STATIC_SERVER;
echo "/static/images/org/', ";
echo $SHOW_BUTTON ? "true" : "false";
echo ", 3, {\"minExpandLevel\":2});\r\n   tree.BuildTree();\r\n   \r\n   //��¼��ʽͼ����ʾ\r\n   $(\"#orgTree0 li[dtnode]\").live('mouseenter', function(){\r\n      var node = $(this).attr(\"dtnode\");\r\n      if(typeof(node.data.client) != 'undefined')\r\n      {\r\n         if($(\"#\" + node.data.key + '_client').length <= 0)\r\n         {\r\n            var html = '<span id=\"' + node.data.key + '_client\" style=\"display:none;\">';\r\n            html += '<img src=\"";
echo MYOA_STATIC_SERVER;
echo "/static/images/client_type_' + node.data.client + '.png\" title=\"' + get_client_type(node.data.client) +  td_lang.inc.msg_107+'\">';//����\r\n            html += '</span>';\r\n            \r\n            $(this).append(html);\r\n         }\r\n         $(\"#\" + node.data.key + '_client').show();\r\n      }\r\n   });\r\n   \r\n   $(\"#orgTree0 li[dtnode]\").live('mouseleave', function(){\r\n      var node = $(this).attr(\"dtnode\");\r\n      if(typeof(node.data.client) != 'undefined')\r\n      {\r\n         $(\"#\" + node.data.key + '_client').hide();\r\n      }\r\n   });\r\n      \r\n}\r\n</script>\r\n<body style=\"background:transparent;\">\r\n<div id=\"";
echo $TREE_ID;
echo "\"></div>\r\n</body>\r\n</html>";
?>
