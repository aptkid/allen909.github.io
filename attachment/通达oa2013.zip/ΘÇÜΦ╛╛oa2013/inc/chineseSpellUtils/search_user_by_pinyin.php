<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
function iconvUnicode16( $name )
{
    $name = iconv( MYOA_CHARSET, "UCS-2", $name );
    $len = strlen( $name );
    $str = "";
    $i = 0;
    for ( ; $i < $len - 1; $i += 2 )
    {
        $c = $name[$i];
        $c2 = $name[$i + 1];
        if ( 0 < ord( $c ) )
        {
            $str .= "\\u".join( "\\u", str_split( array_pop( unpack( "H*0", $c.$c2 ) ), 4 ) );
        }
        else
        {
            $str .= $c2;
        }
    }
    return $str;
}

include_once( "inc/auth.inc.php" );
include_once( "inc/utility.php" );
include_once( "inc/utility_all.php" );
include_once( "inc/utility_cache.php" );
include_once( "inc/chineseSpellUtils/pinyin_table.php" );
$i_count = 0;
$s_userlist = "";
$a_cache = array( );
$a_cache = ( "C_USER_PINYIN_DATA" );
if ( $a_cache['count'] )
{
    $query = "SELECT USER_ID,USER_NAME,DEPT_ID from USER where (NOT_LOGIN='0' or NOT_MOBILE_LOGIN='0') AND DEPT_ID!=0";
    $cursor = exequery( ( ), $query );
    while ( $ROW = mysql_fetch_array( $cursor ) )
    {
        ++$i_count;
        $USER_ID = $ROW['USER_ID'];
        $USER_NAME = $ROW['USER_NAME'];
        $DEPT_NAME = dept_long_name( $ROW['DEPT_ID'] );
        $USER_NAME_PY = get_pinyin_array( $USER_NAME );
        $USER_NAME_PY = str_replace( " ", "|", strtolower( rtrim( $USER_NAME_PY[0] ) ) );
        $USER_NAME_UN = iconvunicode16( $USER_NAME );
        $s_userlist .= "[\"".$USER_ID."\",\"{$USER_NAME_UN}\",\"{$USER_NAME_PY}\", \"{$DEPT_NAME}"."\"],";
    }
    $a_cache = array( "count" => $i_count, "data" => trim( $s_userlist, "," ) );
    ( "C_USER_PINYIN_DATA", $a_cache, 86400 );
}
$s_userlist = "{\"result\":".$a_cache['count'].",\"info\":[".$a_cache['data']."]}";
if ( $s_userlist )
{
    echo $s_userlist;
}
?>
