<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
$HTML_PAGE_TITLE = _( "��װ USB Key ���" );
include_once( "inc/header.inc.php" );
echo "<Script Language=\"JavaScript\">\r\nfunction checkCabState()\r\n{\r\n \tif(ConfirmXEnrollLoaded())\r\n\t{\r\n\t\talert(\"";
echo _( "USB Key �����װ�ɹ�" );
echo "\");\r\n\t\t//history.back();\r\n\t\treturn;\r\n\t}\r\n\tsetTimeout(\"checkCabState()\", 500);\r\n}\r\n</script>\r\n<Script Language=\"VBScript\">\r\nFunction ConfirmXEnrollLoaded()\r\n\tOn Error Resume Next\r\n\tePass1000nd.GetLibVersion\r\n\t\r\n\tIf Err.number = &H1B6 Then\r\n\t\tConfirmXEnrollLoaded = false\r\n        Exit function\r\n    end if\r\n    ConfirmXEnrollLoaded = true\r\nEnd Function\r\n</Script>\r\n<body onload=\"checkCabState();\">\r\n<div id=spnePass1000ND>\r\n\t";
echo _( "���ڰ�װ USB Key ��������Ժ�" );
echo "...\r\n</div>\r\n\r\n<object CLASSID=\"clsid:0272DA76-96FB-449E-8298-178876E0EA89\" CODEBASE=\"";
echo MYOA_JS_SERVER;
echo "/static/js/tdPass_";
echo stristr( $_SERVER['HTTP_USER_AGENT'], "x64" ) ? "x64" : "x86";
echo ".cab#version=1,2,12,1023\" BORDER=\"0\" VSPACE=\"0\" HSPACE=\"0\" ALIGN=\"TOP\" HEIGHT=\"0\" WIDTH=\"0\" id=\"tdPass\" style=\"LEFT: 0px; TOP: 0px\" name=\"tdPass\" VIEWASTEXT></object>\r\n</body>\r\n</html>";
?>
