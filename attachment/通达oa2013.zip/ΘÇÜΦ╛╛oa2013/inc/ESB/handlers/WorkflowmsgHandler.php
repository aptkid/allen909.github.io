<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
include_once( "Handler.php" );
class WorkflowmsgHandler extends Handler
{

    public final function run( )
    {
        $ATTACHMENT_ID = $ATTACHMENT_NAME = "";
        $zip = zip_open( $this->_filePath );
        if ( $zip )
        {
            while ( $zip_entry = zip_read( $zip ) )
            {
                $fileName = basename( zip_entry_name( $zip_entry ) );
                if ( !( strcasecmp( $fileName, "data.xml" ) == 0 ) || !zip_entry_open( $zip, $zip_entry, "r" ) )
                {
                    $xml = zip_entry_read( $zip_entry, zip_entry_filesize( $zip_entry ) );
                    zip_entry_close( $zip_entry );
                    $dom = new DOMDocument( );
                    $dom->loadXML( $xml );
                    $RUN_NAME = $dom->getElementsByTagName( "RUN_NAME" )->item( 0 )->nodeValue;
                    $GUID = $dom->getElementsByTagName( "GUID" )->item( 0 )->nodeValue;
                    $RUN_ID = $dom->getElementsByTagName( "RUN_ID" )->item( 0 )->nodeValue;
                    $PRCS_ID = $dom->getElementsByTagName( "PRCS_ID" )->item( 0 )->nodeValue;
                    $FLOW_PRCS = $dom->getElementsByTagName( "FLOW_PRCS" )->item( 0 )->nodeValue;
                    $RUN_DATA = $dom->getElementsByTagName( "RUN_DATA" )->item( 0 )->nodeValue;
                    if ( !( $GUID != "" ) || !( $RUN_DATA != "" ) )
                    {
                        $RUN_DATA = unserialize( base64_decode( $RUN_DATA ) );
                        foreach ( $RUN_DATA as $ITEM )
                        {
                            $ITEM_ID = $ITEM['ITEM_ID'];
                            $VALUE = $ITEM['VALUE'];
                            $sql = "update FLOW_RUN_DATA set ITEM_DATA ='".$VALUE."' WHERE RUN_ID='{$RUN_ID}' and ITEM_ID='{$ITEM_ID}'";
                            exequery( ( ), $sql );
                        }
                        $query = "select FLOW_ID FROM FLOW_RUN WHERE RUN_ID='".$RUN_ID."'";
                        $cursor = exequery( ( ), $query );
                        if ( $ROW = mysql_fetch_array( $cursor ) )
                        {
                            $FLOW_ID = $ROW['FLOW_ID'];
                        }
                        $query = "select PRCS_TO,AUTO_USER_OP,AUTO_USER FROM FLOW_PROCESS WHERE FLOW_ID='".$FLOW_ID."' AND PRCS_ID='{$FLOW_PRCS}'";
                        $cursor = exequery( ( ), $query );
                        if ( $ROW = mysql_fetch_array( $cursor ) )
                        {
                            $PRCS_TO = $ROW['PRCS_TO'];
                            $AUTO_USER_OP = $ROW['AUTO_USER_OP'];
                            $AUTO_USER = $ROW['AUTO_USER'];
                        }
                    }
                }
            }
            $PRCS_ID_NEW = $PRCS_ID + 1;
            $CUR_TIME = date( "Y-m-d H:i:s", time( ) );
            $query_dept = "SELECT DEPT_ID FROM user WHERE USER_ID = '".$AUTO_USER_OP."';";
            $cursor_dept = exequery( ( ), $query_dept );
            if ( $row_dept = mysql_fetch_array( $cursor_dept ) )
            {
                $PRCS_DEPT = $row_dept['DEPT_ID'];
            }
            $query = "insert into FLOW_RUN_PRCS(RUN_ID,PRCS_ID,USER_ID,PRCS_DEPT,PRCS_FLAG,FLOW_PRCS,OP_FLAG,TOP_FLAG,PARENT,CREATE_TIME) values ('".$RUN_ID."','{$PRCS_ID_NEW}','{$AUTO_USER_OP}','".$PRCS_DEPT.( "','1','".$PRCS_TO."','1','0','{$FLOW_PRCS}','{$CUR_TIME}')" );
            exequery( ( ), $query );
            $query = "update FLOW_RUN_PRCS set DELIVER_TIME='".$CUR_TIME."',PRCS_FLAG='4' WHERE RUN_ID='{$RUN_ID}' and PRCS_ID='{$PRCS_ID}' and FLOW_PRCS='{$FLOW_PRCS}' and PRCS_FLAG in ('1','2')";
            exequery( ( ), $query );
        }
    }

}

?>
