<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
abstract class Handler
{

    protected $_filePath;
    protected $_fromDept;
    protected $_guid;

    public function __construct( $filePath, $fromDept, $guid )
    {
        $this->_filePath = $filePath;
        $this->_fromDept = $fromDept;
        $this->_guid = $guid;
    }

    public abstract function run( );

}

include_once( "inc/conn.php" );
include_once( "inc/utility_file.php" );
?>
