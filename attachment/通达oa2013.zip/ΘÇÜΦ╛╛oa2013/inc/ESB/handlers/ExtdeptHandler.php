<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
include_once( "Handler.php" );
class ExtdeptHandler extends Handler
{

    public final function run( )
    {
        $zip = zip_open( $this->_filePath );
        do
        {
            if ( $zip && ( $zip_entry = zip_read( $zip ) ) )
            {
                $fileName = basename( zip_entry_name( $zip_entry ) );
            }
        } while ( !( strcasecmp( $fileName, "data.xml" ) == 0 ) );
        if ( zip_entry_open( $zip, $zip_entry, "r" ) )
        {
            $xml = zip_entry_read( $zip_entry, zip_entry_filesize( $zip_entry ) );
            zip_entry_close( $zip_entry );
            $dom = new DOMDocument( );
            $dom->loadXML( $xml );
            $DEPTS = $dom->getElementsByTagName( "item" );
            $sql = "TRUNCATE TABLE `EXT_DEPT`";
            exequery( ( ), $sql );
            foreach ( $DEPTS as $DEPT )
            {
                $DEPT_ID = $DEPT->getElementsByTagName( "DEPT_ID" )->item( 0 )->nodeValue;
                $DEPT_NO = $DEPT->getElementsByTagName( "DEPT_NO" )->item( 0 )->nodeValue;
                $DEPT_NAME = $DEPT->getElementsByTagName( "DEPT_NAME" )->item( 0 )->nodeValue;
                $DEPT_PARENT = $DEPT->getElementsByTagName( "DEPT_PARENT" )->item( 0 )->nodeValue;
                $ESB_USER = $DEPT->getElementsByTagName( "ESB_USER" )->item( 0 )->nodeValue;
                $DEPT_DESC = $DEPT->getElementsByTagName( "DEPT_DESC" )->item( 0 )->nodeValue;
                $DEPT_NAME = iconv( "utf-8", MYOA_CHARSET, $DEPT_NAME );
                $DEPT_DESC = iconv( "utf-8", MYOA_CHARSET, $DEPT_DESC );
                $ESB_USER = iconv( "utf-8", MYOA_CHARSET, $ESB_USER );
                $sql = "insert into `EXT_DEPT` (DEPT_ID,DEPT_NO,DEPT_NAME,DEPT_PARENT,ESB_USER,DEPT_DESC) values ('".$DEPT_ID."', '{$DEPT_NO}', '{$DEPT_NAME}', '{$DEPT_PARENT}', '{$ESB_USER}', '{$DEPT_DESC}')";
                exequery( ( ), $sql );
            }
        }
    }

}

?>
