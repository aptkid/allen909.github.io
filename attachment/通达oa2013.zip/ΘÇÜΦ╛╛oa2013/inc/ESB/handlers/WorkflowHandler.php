<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
include_once( "Handler.php" );
include_once( "general/ext_data/workflow/my/utility_rule.func.php" );
include_once( "inc/utility_sms1.php" );
class WorkflowHandler extends Handler
{

    public final function run( )
    {
        $ATTACHMENT_ID = $ATTACHMENT_NAME = "";
        $zip = zip_open( $this->_filePath );
        if ( $zip )
        {
            while ( $zip_entry = zip_read( $zip ) )
            {
                $file_name = basename( zip_entry_name( $zip_entry ) );
                if ( strcasecmp( $file_name, "data.xml" ) == 0 )
                {
                    if ( zip_entry_open( $zip, $zip_entry, "r" ) )
                    {
                        $xml = zip_entry_read( $zip_entry, zip_entry_filesize( $zip_entry ) );
                        zip_entry_close( $zip_entry );
                        $dom = new DOMDocument( );
                        $dom->loadXML( $xml );
                        $RUN_ID = $dom->getElementsByTagName( "RUN_ID" )->item( 0 )->nodeValue;
                        $PRCS_ID = $dom->getElementsByTagName( "PRCS_ID" )->item( 0 )->nodeValue;
                        $FLOW_PRCS = $dom->getElementsByTagName( "FLOW_PRCS" )->item( 0 )->nodeValue;
                        $RUN_NAME = $dom->getElementsByTagName( "RUN_NAME" )->item( 0 )->nodeValue;
                        $RUN_FORM = $dom->getElementsByTagName( "RUN_FORM" )->item( 0 )->nodeValue;
                        $RUN_TIME = $dom->getElementsByTagName( "RUN_TIME" )->item( 0 )->nodeValue;
                        $FLOW_NAME = $dom->getElementsByTagName( "FLOW_NAME" )->item( 0 )->nodeValue;
                        $FLOW_ID = $dom->getElementsByTagName( "FLOW_ID" )->item( 0 )->nodeValue;
                        $FIELD = $dom->getElementsByTagName( "FIELD" )->item( 0 )->nodeValue;
                        $RUN_NAME = iconv( "utf-8", MYOA_CHARSET, $RUN_NAME );
                        $RUN_FORM = iconv( "utf-8", MYOA_CHARSET, $RUN_FORM );
                        $FLOW_NAME = iconv( "utf-8", MYOA_CHARSET, $FLOW_NAME );
                        $RUN_FORM = bin2hex( gzcompress( $RUN_FORM ) );
                    }
                }
                else if ( zip_entry_open( $zip, $zip_entry, "r" ) )
                {
                    $file_content = zip_entry_read( $zip_entry, zip_entry_filesize( $zip_entry ) );
                    zip_entry_close( $zip_entry );
                    $ATTACH_ID = create_attach( $file_name, $file_content, "ext_data" );
                    $ATTACHMENT_ID .= $ATTACH_ID.",";
                    $ATTACHMENT_NAME .= $file_name."*";
                }
            }
            $query = "select DEPT_NAME from ext_dept where ESB_USER = '".$this->_fromDept."'";
            $cursor = exequery( ( ), $query );
            if ( $ROW = mysql_fetch_array( $cursor ) )
            {
                $DEPT_NAME = $ROW['DEPT_NAME'];
            }
            $sql = "insert into `ESB_WORKFLOW` (RUN_FROM,RUN_ID,PRCS_ID,FLOW_PRCS,RUN_NAME,FLOW_NAME,FLOW_ID,RUN_TIME,RUN_FORM,RUN_DATA ,ATTACHMENT_ID,ATTACHMENT_NAME,GUID) values ('".$this->_fromDept.( "', '".$RUN_ID."', '{$PRCS_ID}', '{$FLOW_PRCS}', '{$RUN_NAME}', '{$FLOW_NAME}', '{$FLOW_ID}', '{$RUN_TIME}', 0x{$RUN_FORM}, '{$FIELD}', '{$ATTACHMENT_ID}', '{$ATTACHMENT_NAME}','" ).$this->_guid."')";
            exequery( ( ), $sql );
            $WID = mysql_insert_id( );
            $USER_ID_STR = getrunrulepriv( $RUN_NAME, $FLOW_NAME, $DEPT_NAME );
            $SMS_CONTENT = _( "�ⲿ������ת�����ѣ�" ).csubstr( $RUN_NAME, 0, 100 );
            $REMIND_URL = "1:ext_data/workflow/my/do_form.php?WID=".$WID;
            send_sms( "", "admin", $USER_ID_STR, 7, $SMS_CONTENT, $REMIND_URL );
        }
    }

}

?>
