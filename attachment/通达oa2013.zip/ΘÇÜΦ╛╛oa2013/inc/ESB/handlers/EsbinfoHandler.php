<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
include_once( "Handler.php" );
class EsbinfoHandler extends Handler
{

    public final function run( )
    {
        $ATTACHMENT_ID = $ATTACHMENT_NAME = "";
        $zip = zip_open( $this->_filePath );
        if ( $zip )
        {
            while ( $zip_entry = zip_read( $zip ) )
            {
                $file_name = basename( zip_entry_name( $zip_entry ) );
                if ( strcasecmp( $file_name, "data.xml" ) == 0 )
                {
                    if ( zip_entry_open( $zip, $zip_entry, "r" ) )
                    {
                        $xml = zip_entry_read( $zip_entry, zip_entry_filesize( $zip_entry ) );
                        zip_entry_close( $zip_entry );
                        $dom = new DOMDocument( );
                        $dom->loadXML( $xml );
                        $INFO_TITLE = $dom->getElementsByTagName( "INFO_TITLE" )->item( 0 )->nodeValue;
                        $INFO_CONTENT = $dom->getElementsByTagName( "INFO_CONTENT" )->item( 0 )->nodeValue;
                        $INFO_TYPE = $dom->getElementsByTagName( "INFO_TYPE" )->item( 0 )->nodeValue;
                        $INFO_TIME = $dom->getElementsByTagName( "INFO_TIME" )->item( 0 )->nodeValue;
                        $INFO_TITLE = iconv( "utf-8", MYOA_CHARSET, $INFO_TITLE );
                        $INFO_CONTENT = iconv( "utf-8", MYOA_CHARSET, $INFO_CONTENT );
                        $INFO_TYPE = iconv( "utf-8", MYOA_CHARSET, $INFO_TYPE );
                    }
                }
                else if ( zip_entry_open( $zip, $zip_entry, "r" ) )
                {
                    $file_content = zip_entry_read( $zip_entry, zip_entry_filesize( $zip_entry ) );
                    zip_entry_close( $zip_entry );
                    $ATTACH_ID = create_attach( $file_name, $file_content, "ext_data" );
                    $ATTACHMENT_ID .= $ATTACH_ID.",";
                    $ATTACHMENT_NAME .= $file_name."*";
                }
            }
            $sql = "insert into `ESB_INFO` (INFO_FROM,INFO_TITLE,INFO_CONTENT,INFO_TYPE,INFO_TIME,TYPE_FLAG,ATTACHMENT_ID,ATTACHMENT_NAME,GUID) values ('".$this->_fromDept.( "', '".$INFO_TITLE."', '{$INFO_CONTENT}', '{$INFO_TYPE}', '{$INFO_TIME}', '1', '{$ATTACHMENT_ID}', '{$ATTACHMENT_NAME}','{$this->_guid}')" );
            exequery( ( ), $sql );
        }
    }

}

?>
