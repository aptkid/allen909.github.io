<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
include_once( "ESBClient.php" );
include_once( "inc/utility_all.php" );
include_once( "inc/utility_flow.php" );
class PackWorkflow extends ESBClient
{

    private $xml;
    private $files = array( );
    private $flow_prcs;
    private $prcs_id;

    public function __construct( $run_id, $prcs_id, $flow_prcs )
    {
        ( );
        if ( empty( $run_id ) || empty( $prcs_id ) || empty( $flow_prcs ) )
        {
            $this->_setError( -101 );
        }
        else
        {
            $this->uniqueId = $run_id;
            $this->flow_prcs = $flow_prcs;
            $this->prcs_id = $prcs_id;
            $this->module = "workflow";
            $this->_getData( );
        }
    }

    private function _getData( )
    {
        $query = "SELECT a.RUN_NAME,a.FLOW_ID as FLOW_ID,a.ATTACHMENT_ID,a.ATTACHMENT_NAME,b.FLOW_NAME from FLOW_RUN as a,FLOW_TYPE as b WHERE a.RUN_ID='".$this->uniqueId."' AND a.FLOW_ID=b.FLOW_ID";
        $cursor = exequery( ( ), $query );
        if ( $data = mysql_fetch_assoc( $cursor ) )
        {
            $data['MODULE'] = $this->module;
            $data['TITLE'] = $data['RUN_NAME'];
            $data['RUN_ID'] = $this->uniqueId;
            $data['PRCS_ID'] = $this->prcs_id;
            $data['FLOW_PRCS'] = $this->flow_prcs;
            $data['RUN_TIME'] = time( );
            $data['FIELD']( &$data['RUN_FORM'], &$data['FIELD'] );
            $data['RUN_FORM'] = "<![CDATA[".str_replace( "<img", "<span", $data['RUN_FORM'] )."]]>";
            $this->xml = $this->array2xml( $data );
            if ( $data['ATTACHMENT_ID'] != "" )
            {
                $ATTACHMENT_ID_ARRAY = explode( ",", $data['ATTACHMENT_ID'] );
                $ATTACHMENT_NAME_ARRAY = explode( "*", $data['ATTACHMENT_NAME'] );
                foreach ( $ATTACHMENT_ID_ARRAY as $key => $ATTACH_ID )
                {
                    if ( $ATTACH_ID != "" )
                    {
                        $ATTACH_NAME = $ATTACHMENT_NAME_ARRAY[$key];
                        $this->files["{$ATTACH_NAME}"] = attach_real_path( $ATTACH_ID, $ATTACH_NAME, "ext_data" );
                    }
                }
            }
        }
    }

    public final function genPackage( )
    {
        $zipfiles = array_merge( array( "data.xml" => $this->xml ), $this->files );
        $this->_writePackage( $zipfiles );
    }

    public final function getLastError( )
    {
        $errMsg = "";
        if ( -100 < $this->errCode && $this->errCode < 0 )
        {
            $errMsg = $this->_getBaseError( );
            return $errMsg;
        }
        switch ( $this->errCode )
        {
            case -101 :
                $errMsg = _( "��Ч����ˮ��" );
        }
        return $errMsg;
    }

    private function __getForm( &$FORM_HTML, &$FIELD )
    {
        $query = "SELECT * from FLOW_RUN WHERE RUN_ID='".$this->uniqueId."'";
        $cursor = exequery( ( ), $query );
        if ( $ROW = mysql_fetch_array( $cursor ) )
        {
            $RUN_NAME = $ROW['RUN_NAME'];
            $FLOW_ID = $ROW['FLOW_ID'];
            $BEGIN_TIME = $ROW['BEGIN_TIME'];
        }
        $query = "SELECT * from FLOW_TYPE WHERE FLOW_ID='".$FLOW_ID."'";
        $cursor1 = exequery( ( ), $query );
        if ( $ROW = mysql_fetch_array( $cursor1 ) )
        {
            $FLOW_NAME = $ROW['FLOW_NAME'];
            $FLOW_TYPE = $ROW['FLOW_TYPE'];
            $FORM_ID = $ROW['FORM_ID'];
            $FORM_TYPE = $ROW['FORM_TYPE'];
            $FLOW_DOC = $ROW['FLOW_DOC'];
            $AUTO_NUM = $ROW['AUTO_NUM'];
        }
        $query = "SELECT * from FLOW_FORM_TYPE WHERE FORM_ID='".$FORM_ID."'";
        $cursor1 = exequery( ( ), $query );
        if ( $ROW = mysql_fetch_array( $cursor1 ) )
        {
            $FORM_NAME = $ROW['FORM_NAME'];
            $PRINT_MODEL = $ROW['PRINT_MODEL_SHORT'];
            $SCRIPT = $ROW['SCRIPT'];
            $CSS = $ROW['CSS'];
        }
        $PRINT_MODEL = str_replace( _( "#[����]" ), _( "<b>".$FORM_NAME."</b>" ), $PRINT_MODEL );
        $PRINT_MODEL = str_replace( _( "#[�ĺ�]" ), $RUN_NAME, $PRINT_MODEL );
        $PRINT_MODEL = str_replace( _( "#[ʱ��]" ), _( "���ڣ�".$BEGIN_TIME ), $PRINT_MODEL );
        $PRINT_MODEL = str_replace( _( "#[��ˮ��]" ), $RUN_ID, $PRINT_MODEL );
        $PRINT_MODEL = str_replace( _( "#[�ĺż�����]" ), $AUTO_NUM, $PRINT_MODEL );
        $table_name = "flow_data_".$FLOW_ID;
        $query = " select * from ".$table_name." where run_id='".$this->uniqueId."' limit 1";
        $cursor = exequery( ( ), $query );
        if ( $ROW = mysql_fetch_assoc( $cursor ) )
        {
            foreach ( $ROW as $key => $value )
            {
                if ( strtolower( substr( $key, 0, 5 ) ) == "data_" )
                {
                    $STR = strtoupper( $key );
                    $$STR = $value;
                }
            }
        }
        $query = "SELECT PRCS_ITEM from FLOW_PROCESS WHERE FLOW_ID='".$FLOW_ID."' AND PRCS_ID='".$this->flow_prcs."'";
        $cursor1 = exequery( ( ), $query );
        if ( $ROW = mysql_fetch_array( $cursor1 ) )
        {
            $PRCS_ITEM = $ROW['PRCS_ITEM'];
        }
        $WORKFLOW_ELEMENT_ARRAY = ( "workflow/form/ELEMENT_ARRAY_".$FORM_ID );
        foreach ( $WORKFLOW_ELEMENT_ARRAY as $ENAME )
        {
            $ETITLE = $ITEM['TITLE'];
            $ITEM['VALUE'] = $$ENAME;
            $ITEM['WRITEABLE'] = FALSE;
            if ( find_id( $PRCS_ITEM, $ETITLE ) )
            {
                $ITEM['WRITEABLE'] = TRUE;
            }
        }
        $FIELD = base64_encode( serialize( $WORKFLOW_ELEMENT_ARRAY ) );
        $FORM_HTML .= "<style type=\"text/css\">".$CSS."</style>";
        $FORM_HTML .= "<script>".$SCRIPT."</script>";
        $FORM_HTML .= $PRINT_MODEL;
    }

}

?>
