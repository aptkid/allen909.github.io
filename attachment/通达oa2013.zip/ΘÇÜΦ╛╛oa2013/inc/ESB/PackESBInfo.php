<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
include_once( "ESBClient.php" );
class PackESBInfo extends ESBClient
{

    private $xml;
    private $files = array( );

    public function __construct( $infoId )
    {
        ( );
        if ( empty( $infoId ) )
        {
            $this->_setError( -101 );
        }
        else
        {
            $this->uniqueId = $infoId;
            $this->module = "esbinfo";
            $this->_getData( );
        }
    }

    private function _getData( )
    {
        $query = "SELECT INFO_TITLE,INFO_CONTENT,INFO_FROM,INFO_TO,INFO_TYPE,INFO_TIME,ATTACHMENT_ID,ATTACHMENT_NAME from ESB_INFO WHERE INFO_ID='".$this->uniqueId."'";
        $cursor = exequery( ( ), $query );
        if ( $data = mysql_fetch_assoc( $cursor ) )
        {
            $data['MODULE'] = "esbinfo";
            $data['TITLE'] = $data['INFO_TITLE'];
            $data['INFO_CONTENT'] = "<![CDATA[".$data['INFO_CONTENT']."]]>";
            $this->xml = $this->array2xml( $data );
            if ( $data['ATTACHMENT_ID'] != "" )
            {
                $ATTACHMENT_ID_ARRAY = explode( ",", $data['ATTACHMENT_ID'] );
                $ATTACHMENT_NAME_ARRAY = explode( "*", $data['ATTACHMENT_NAME'] );
                foreach ( $ATTACHMENT_ID_ARRAY as $key => $ATTACH_ID )
                {
                    if ( $ATTACH_ID != "" )
                    {
                        $ATTACH_NAME = $ATTACHMENT_NAME_ARRAY[$key];
                        $this->files["{$ATTACH_NAME}"] = attach_real_path( $ATTACH_ID, $ATTACH_NAME, "ext_data" );
                    }
                }
            }
        }
    }

    public final function genPackage( )
    {
        $zipfiles = array_merge( array( "data.xml" => $this->xml ), $this->files );
        $this->_writePackage( $zipfiles );
    }

    public final function getLastError( )
    {
        $errMsg = "";
        if ( -100 < $this->errCode && $this->errCode < 0 )
        {
            $errMsg = $this->_getBaseError( );
            return $errMsg;
        }
        switch ( $this->errCode )
        {
            case -101 :
                $errMsg = _( "��Ч�ı�����ϢID" );
        }
        return $errMsg;
    }

}

?>
