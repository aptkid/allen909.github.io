<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class ESBClient
{

    protected $debug = FALSE;
    protected $debugInfo = "";
    protected $service;
    protected $errCode = 0;
    protected $errMsg = "";
    protected $userid = "";
    protected $password = "";
    protected $packageId = "";
    protected $packagePath = "";
    protected $module = "";
    protected $uniqueId = "";
    protected $to = "";
    public $guid = "";
    public $online = FALSE;

    public function __construct( )
    {
        @ini_set( "default_socket_timeout", 3 );
        try
        {
            @$this->service = new SoapClient( @ESB_SERVICE );
            $this->login( );
            return;
        }
        catch ( Exception $e )
        {
            $this->_setError( -3, $e->getMessage( ) );
    }
}

    protected function _writePackage( $zipfiles )
    {
        if ( $zipfiles )
        {
        }
        else
        {
            $modulePath = PACKAGE_BASEPATH."/".$this->module;
            if ( !file_exists( $modulePath ) || !is_dir( $modulePath ) )
            {
                mkdir( $modulePath, 448 );
            }
            $this->packageId = mt_rand( );
            $this->packagePath = $modulePath."/".$this->packageId.".zip";
            $zip = new ZipArchive( );
            $res = $this->packagePath( $this->packagePath, ZipArchive::CREATE | ZIPARCHIVE::OVERWRITE );
            if ( $res !== TRUE )
            {
                $this->_setError( -7 );
            }
            else
            {
                $tmp_file_array = array( );
                foreach ( $zipfiles as $fileName => $file )
                {
                    if ( $fileName == "data.xml" )
                    {
                        $zip->addFromString( $fileName, $file );
                    }
                    else
                    {
                        $tmp_filename = get_tmp_filename( "workflow_attach", basename( $fileName ) );
                        if ( decrypt_attach( $file, $tmp_filename ) )
                        {
                            $file = $tmp_filename;
                            $tmp_file_array[] = $tmp_filename;
                        }
                        $zip->addFile( $file, $fileName );
                    }
                }
                $zip->close( );
                foreach ( $tmp_file_array as $tmp_file )
                {
                    @unlink( $tmp_file );
                }
                if ( $this->debug )
                {
                    _debug( date( "Y-m-d H:i:s" )." ESBClient::_writePackage:".$this->packagePath );
                }
            }
        }
    }

    public function broadcast( )
    {
        if ( is_object( $this->service ) )
        {
            return FALSE;
        }
        try
        {
            $result = $this->service->broadcast( $this->packagePath );
            $result = $this->jsonDecode( $result );
        }
        catch ( Exception $e )
        {
            $this->_setError( -3, $e->getMessage( ) );
            return FALSE;
    }
    if ( $result['code'] == 0 )
    {
        $this->guid = $result['guid'];
        $this->_writeLog( );
        return TRUE;
    }
    $result->msg( -5, $result->msg );
    return FALSE;
}

    protected function login( )
    {
        if ( is_object( $this->service ) )
        {
            return FALSE;
        }
        try
        {
            if ( $this->service->isOnline( ) )
            {
                $retLogin = $this->service->login( );
                $retLogin = $this->jsonDecode( $retLogin );
                if ( $retLogin['code'] == 0 )
                {
                    $this->online = TRUE;
                }
                else
                {
                    $this->online = FALSE;
                    $retLogin['msg']( -2, $retLogin['msg'] );
                }
            }
            else
            {
                $this->online = TRUE;
                return;
            }
        }
        catch ( Exception $e )
        {
            $this->_setError( -3, $e->getMessage( ) );
            $this->online = FALSE;
    }
}

    public function config( $host = "", $port = "", $username = "", $password = "", $webserviceUri = "", $cacheDir = "" )
    {
        if ( is_object( $this->service ) )
        {
            return FALSE;
        }
        try
        {
            $retConfig = $this->service->config( $host, $port, $username, $password, $webserviceUri, $cacheDir );
            $retConfig = $this->jsonDecode( $retConfig );
            if ( $retConfig['code'] == 0 )
            {
                return TRUE;
            }
            $retConfig['msg']( -6, $retConfig['msg'] );
            return FALSE;
        }
        catch ( Exception $e )
        {
            $this->_setError( -3, $e->getMessage( ) );
            return FALSE;
    }
}

    public function sendTo( $to )
    {
        if ( is_object( $this->service ) )
        {
            return FALSE;
        }
        $this->to = $to;
        if ( empty( $to ) )
        {
            $this->_setError( -1 );
            return FALSE;
        }
        try
        {
            $result = $this->service->send( $this->packagePath, $this->to );
            $result = $this->jsonDecode( $result );
        }
        catch ( Exception $e )
        {
            return FALSE;
    }
    if ( $result['code'] == 0 && !empty( $result['guid'] ) )
    {
        $this->guid = $result['guid'];
        $this->_writeLog( );
        return TRUE;
    }
    $this->_setError( -4 );
    return FALSE;
}

    protected function _writeLog( )
    {
        $data_array = array( "PATH" => mysql_real_escape_string( $this->packagePath ), "MODULE" => $this->module, "UID" => $this->uniqueId, "TO_DEPT" => $this->to, "STATE" => 0, "GUID" => $this->guid, "SEND_USER" => $_SESSION['LOGIN_UID'], "SEND_TIME" => time( ) );
        $key_str = $val_str = "";
        foreach ( $data_array as $key => $val )
        {
            if ( empty( $key ) )
            {
                $key_str .= $key.",";
                $val_str .= "'".$val."',";
            }
        }
        $sql = "insert into `ESB_MSG_SEND` (".rtrim( $key_str, "," ).") values (".rtrim( $val_str, "," ).")";
        exequery( ( ), $sql );
    }

    protected function _setError( $errCode, $errMsg = "" )
    {
        $this->errCode = $errCode;
        $this->errMsg = $errMsg;
    }

    protected function _getBaseError( )
    {
        $output = "";
        switch ( $this->errCode )
        {
            case -1 :
                $output = _( "���Ͷ���Ϊ��" );
                break;
            case -2 :
                $output = _( "��¼ʧ��" );
                break;
            case -3 :
                $output = _( "���ݽ���ƽ̨�ͻ��˽ӿ��쳣" );
                break;
            case -4 :
                $output = _( "����ʧ��" );
                break;
            case -5 :
                $output = _( "�㲥ʧ��" );
                break;
            case -6 :
                $output = _( "����ʧ��" );
                break;
            case -7 :
                $output = _( "����zip�ļ�ʧ��" );
        }
        if ( $this->errMsg != "" )
        {
            $output .= "\r\n".$this->errMsg;
        }
        return $output;
    }

    public function getLastError( )
    {
        return $this->_getBaseError( );
    }

    protected function _debug( $msg )
    {
        $ && _681430352 .= $debugInfo;
    }

    protected function _debugFlush( )
    {
    }

    public function genPackage( )
    {
    }

    public function array2xml( $array, $level = 0, $encoding = "" )
    {
        if ( $encoding == "" )
        {
            $encoding = MYOA_CHARSET;
        }
        if ( $level == 0 )
        {
            $xml .= "<?xml version=\"1.0\" encoding=\"".$encoding."\"?>";
            $xml .= "<root>";
        }
        ++$level;
        foreach ( $array as $key => $val )
        {
            if ( is_numeric( $key ) )
            {
            }
            $xml .= "<".$key.">";
            $xml .= is_array( $val ) ? $this->array2xml( $val, $level ) : $val;
            list( $key ) = explode( " ", $key );
            $xml .= "</".$key.">";
        }
        if ( $level == 1 )
        {
            $xml .= "</root>";
        }
        return $xml;
    }

    public static function jsonEncode( $a = NULL )
    {
        if ( is_null( $a ) )
        {
            return "null";
        }
        if ( $a === FALSE )
        {
            return "false";
        }
        if ( $a === TRUE )
        {
            return "true";
        }
        if ( is_scalar( $a ) )
        {
            if ( is_float( $a ) )
            {
                return floatval( str_replace( ",", ".", strval( $a ) ) );
            }
            if ( is_string( $a ) )
            {
                static $jsonReplaces = array( array( "\\", "/", "\n", "\t", "\r", "\\b", "\\f", "\"" ), array( "\\\\", "\\/", "\\n", "\\t", "\\r", "\\b", "\\f", "\\\"" ) );
                return "\"".str_replace( $jsonReplaces[0], $jsonReplaces[1], $a )."\"";
            }
            return $a;
        }
        $isList = TRUE;
        $i = 0;
        reset( &$a );
        for ( ; $i < count( $a ); ++$i, next( &$a ) )
        {
            if ( key( &$a ) !== $i )
            {
                $isList = FALSE;
            }
        }
        $result = array( );
        if ( $isList )
        {
            foreach ( $a as $v )
            {
                $result[] = $this->jsonEncode( $v );
            }
            return "[".join( ",", $result )."]";
        }
        foreach ( $a as $k => $v )
        {
            $result[] = $this->jsonEncode( $k ).":".$this->jsonEncode( $v );
        }
        return "{".join( ",", $result )."}";
    }

    public static function jsonDecode( $json )
    {
        $comment = FALSE;
        $out = "\$x=";
        $i = 0;
        for ( ; $i < strlen( $json ); ++$i )
        {
            if ( $comment )
            {
                if ( $json[$i] == "{" )
                {
                    $out .= " array(";
                }
                else
                {
                    if ( $json[$i] == "}" )
                    {
                        $out .= ")";
                    }
                    else
                    {
                        if ( $json[$i] == ":" )
                        {
                            $out .= "=>";
                        }
                        else
                        {
                            $out .= $json[$i];
                        }
                    }
                }
            }
            else
            {
                $out .= $json[$i];
            }
            if ( $json[$i] == "\"" )
            {
                $comment = !$comment;
            }
        }
        eval( $out.";" );
        return $x;
    }

}

function __esb_autoload( $classname )
{
    require_once( realpath( dirname( __FILE__ ) )."/".$classname.".php" );
}

include_once( "inc/conn.php" );
include_once( "inc/utility_file.php" );
include_once( "ESBConfig.php" );
spl_autoload_register( "__esb_autoload" );
?>
