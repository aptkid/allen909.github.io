<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
include_once( "inc/utility_all.php" );
$PARA_ARRAY = get_sys_para( "ESB_CONFIG" );
$ESB_CFG = array( );
if ( $PARA_ARRAY['ESB_CONFIG'] !== "" )
{
    $ESB_CFG = unserialize( base64_decode( $PARA_ARRAY['ESB_CONFIG'] ) );
}
if ( $ESB_CFG['clientAddr'] == "" )
{
}
if ( $ESB_CFG['clientPort'] == "" || !is_numeric( $ESB_CFG['clientPort'] ) )
{
}
$ESBWebserviceUri = "http://".$ESB_CFG['clientAddr'].":".$ESB_CFG['clientPort']."/t9/services/T9EsbService?wsdl";
if ( $ESB_CFG['appAddr'] == "" )
{
}
if ( $ESB_CFG['appPort'] == "" || !is_numeric( $ESB_CFG['appPort'] ) )
{
}
$OAWebserviceUri = "http://".$ESB_CFG['appAddr'].":".$ESB_CFG['appPort']."/webservice/esbmessage.php?WSDL";
if ( $ESB_CFG['cacheDir'] == "" )
{
}
define( "ESB_SERVICE", $ESBWebserviceUri );
define( "PACKAGE_BASEPATH", $ESB_CFG['cacheDir'] );
?>
