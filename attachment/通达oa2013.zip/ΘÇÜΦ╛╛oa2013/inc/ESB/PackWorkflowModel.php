<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
include_once( "ESBClient.php" );
include_once( "inc/utility_all.php" );
include_once( "inc/utility_flow.php" );
class PackWorkflowModel extends ESBClient
{

    private $xml;
    private $files = array( );

    public function __construct( $send_id )
    {
        ( );
        if ( empty( $send_id ) )
        {
            $this->_setError( -101 );
        }
        else
        {
            $this->uniqueId = $send_id;
            $this->module = "workflowModel";
            $this->_getData( );
        }
    }

    private function _getData( )
    {
        $query = "select FLOW_ID,FORM_ID, FORM_DATA, FIELD, TO_DEPT from esb_workflow_model_send where SEND_ID='".$this->uniqueId."'";
        $cursor = exequery( ( ), $query );
        if ( $data = mysql_fetch_assoc( $cursor ) )
        {
            $query1 = "select FORM_NAME from FLOW_FORM_TYPE where FORM_ID = '".$data['FORM_ID']."'";
            $cursor1 = exequery( ( ), $query1 );
            if ( $ROW1 = mysql_fetch_array( $cursor1 ) )
            {
                $FORM_NAME = $ROW1['FORM_NAME'];
            }
            $query1 = "select FLOW_NAME from FLOW_TYPE where FLOW_ID = '".$data['FLOW_ID']."'";
            $cursor1 = exequery( ( ), $query1 );
            if ( $ROW1 = mysql_fetch_array( $cursor1 ) )
            {
                $FLOW_NAME = $ROW1['FLOW_NAME'];
            }
            $data['FLOW_NAME'] = $FLOW_NAME;
            $data['FORM_NAME'] = $FORM_NAME;
            $data['MODULE'] = $this->module;
            $data['TITLE'] = $FORM_NAME;
            $data['TO_TIME'] = time( );
            $data['FORM_DATA'] = "<![CDATA[".str_replace( "<img", "<span", $data['FORM_DATA'] )."]]>";
            $this->xml = $this->array2xml( $data );
        }
    }

    public final function genPackage( )
    {
        $zipfiles = array_merge( array( "data.xml" => $this->xml ), $this->files );
        $this->_writePackage( $zipfiles );
    }

    public final function getLastError( )
    {
        $errMsg = "";
        if ( -100 < $this->errCode && $this->errCode < 0 )
        {
            $errMsg = $this->_getBaseError( );
            return $errMsg;
        }
        switch ( $this->errCode )
        {
            case -101 :
                $errMsg = _( "��Ч����ˮ��" );
        }
        return $errMsg;
    }

}

?>
