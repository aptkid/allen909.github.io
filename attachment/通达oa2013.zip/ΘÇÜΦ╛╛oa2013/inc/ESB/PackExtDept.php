<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
include_once( "ESBClient.php" );
class PackExtDept extends ESBClient
{

    private $xml;

    public function __construct( )
    {
        ( );
        $this->module = "extdept";
        $this->_getData( );
    }

    private function _getData( )
    {
        $data = array( );
        $data['MODULE'] = $this->module;
        $data['TITLE'] = _( "��֯����ͬ��" );
        $data['DEPT'] = array( );
        $query = "SELECT * from EXT_DEPT where ACTIVE=1 ORDER BY DEPT_NO";
        $cursor = exequery( ( ), $query );
        while ( $row = mysql_fetch_assoc( $cursor ) )
        {
            $DEPT_ID = $row['DEPT_ID'];
            $data['DEPT'][$DEPT_ID] = $row;
        }
        $this->xml = $this->array2xml( $data );
    }

    public final function genPackage( )
    {
        $zipfiles = array( "data.xml" => $this->xml );
        $this->_writePackage( $zipfiles );
    }

    public final function getLastError( )
    {
        $errMsg = "";
        if ( -100 < $this->errCode && $this->errCode < 0 )
        {
            $errMsg = $this->_getBaseError( );
            return $errMsg;
        }
        switch ( $this->errCode )
        {
            case -101 :
                $errMsg = "";
        }
        return $errMsg;
    }

}

?>
