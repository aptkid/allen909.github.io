<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
include_once( "ESBClient.php" );
class PackWorkflowMsg extends ESBClient
{

    private $xml;
    private $files = array( );

    public function __construct( $wid )
    {
        ( );
        if ( empty( $wid ) )
        {
            $this->_setError( -101 );
        }
        else
        {
            $this->uniqueId = $wid;
            $this->module = "workflowmsg";
            $this->_getData( );
        }
    }

    private function _getData( )
    {
        $query = "SELECT RUN_ID,PRCS_ID,FLOW_PRCS,RUN_NAME,RUN_DATA,GUID FROM ESB_WORKFLOW where WID='".$this->uniqueId."'";
        $cursor = exequery( ( ), $query );
        if ( $data = mysql_fetch_assoc( $cursor ) )
        {
            $data['MODULE'] = $this->module;
            $data['TITLE'] = $data['RUN_NAME'];
            $data['RUN_DATA'] = "<![CDATA[".$data['RUN_DATA']."]]>";
            $data['RUN_TIME'] = time( );
            $this->xml = $this->array2xml( $data );
        }
    }

    public final function genPackage( )
    {
        $zipfiles = array_merge( array( "data.xml" => $this->xml ), $this->files );
        $this->_writePackage( $zipfiles );
    }

    public final function getLastError( )
    {
        $errMsg = "";
        if ( -100 < $this->errCode && $this->errCode < 0 )
        {
            $errMsg = $this->_getBaseError( );
            return $errMsg;
        }
        switch ( $this->errCode )
        {
            case -101 :
                $errMsg = _( "��Ч����ˮ��" );
        }
        return $errMsg;
    }

}

?>
