<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
include_once( "inc/auth.inc.php" );
$HTML_PAGE_TITLE = _( "ͼƬԤ��" );
include_once( "inc/header.inc.php" );
include_once( "inc/utility_file.php" );
if ( !( $MEDIA_URL != "" ) && ( !( $_GET['ATTACHMENT_ID'] != "" ) || !( $_GET['ATTACHMENT_NAME'] != "" ) || !( $_GET['MODULE'] != "" ) ) )
{
    message( "", _( "������Ƭ" ), "blank" );
    exit( );
}
if ( $MEDIA_URL == "" )
{
    $ATTACHMENT_ID = strip_tags( $_GET['ATTACHMENT_ID'] );
    $ATTACHMENT_NAME = strip_tags( $_GET['ATTACHMENT_NAME'] );
    $MODULE = strip_tags( $_GET['MODULE'] );
    $a_attach = array( );
    $a_attach = attach_url( $ATTACHMENT_ID, $ATTACHMENT_NAME, $MODULE, array( "VIEW" => array( "THUMB" => 1 ) ) );
    if ( is_array( $a_attach ) && 0 < count( $a_attach ) )
    {
        $img_url = $a_attach['view'];
        $FILE_PATH = attach_real_path( $ATTACHMENT_ID, $ATTACHMENT_NAME, $MODULE );
        $FILE_PATH = substr( $FILE_PATH, 0, strlen( $FILE_PATH ) - strlen( $ATTACHMENT_NAME ) )."thumb_".$ATTACHMENT_NAME;
        if ( file_exists( $FILE_PATH ) )
        {
            $img_thumb_url = $a_attach['thumb'];
        }
        else
        {
            $img_thumb_url = $img_url;
        }
        $has_thumb = TRUE;
    }
    else
    {
        message( "", _( "������Ƭ" ), "blank" );
        exit( );
    }
}
$img_url = intval( $MEDIA_ENCODE ) == 1 ? iconv( "UTF-8", MYOA_CHARSET, $MEDIA_URL ) : $MEDIA_URL;
if ( $VIEW_MODE == "gallery" )
{
    $CURRID = intval( $CURRID );
    if ( strpos( $MEDIA_URL, "@~@" ) !== FALSE )
    {
        $img_url_arr = explode( "@~@", $MEDIA_URL );
        $img_url = $img_url_arr[intval( $CURRID )];
    }
}
$has_thumb = FALSE;
echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"";
echo MYOA_JS_SERVER;
echo "/static/js/jquery-1.10.2/lhpMegaImgViewer/css/reset.css\" />\r\n<link rel=\"stylesheet\" type=\"text/css\" href=\"";
echo MYOA_JS_SERVER;
echo "/static/js/jquery-1.10.2/jquery-ui/css/flick/jquery-ui-1.10.3.custom.css\" />\r\n<link rel=\"stylesheet\" type=\"text/css\" href=\"";
echo MYOA_JS_SERVER;
echo "/static/js/jquery-1.10.2/lhpMegaImgViewer/css/lhp_miv.css\" />\r\n<script type=\"text/javascript\" src=\"";
echo MYOA_JS_SERVER;
echo "/static/js/jquery-1.10.2/jquery.min.js";
echo $GZIP_POSTFIX;
echo "\"></script>\r\n<script type=\"text/javascript\" src=\"";
echo MYOA_JS_SERVER;
echo "/static/js/jquery-1.10.2/jquery-ui/js/jquery-ui-1.10.3.custom.min.js";
echo $GZIP_POSTFIX;
echo "\"></script>\r\n<script type=\"text/javascript\" src=\"";
echo MYOA_JS_SERVER;
echo "/static/js/jquery-1.10.2/jquery.easing.1.3.js";
echo $GZIP_POSTFIX;
echo "\"></script>\r\n<script type=\"text/javascript\" src=\"";
echo MYOA_JS_SERVER;
echo "/static/js/jquery-1.5.1/jscrollpane/jquery.mousewheel.js";
echo $GZIP_POSTFIX;
echo "\"></script>\r\n<script type=\"text/javascript\" src=\"/inc/js_lang.php\"></script>\r\n<script type=\"text/javascript\" src=\"";
echo MYOA_JS_SERVER;
echo "/static/js/jquery-1.10.2/lhpMegaImgViewer/js/jquery.lhpMegaImgViewer.min.js";
echo $GZIP_POSTFIX;
echo "\"></script>\r\n<style>\r\nbody, html{height: 100%; width: 100%; overflow: hidden;}\r\n#image-show-wrapper{position:relative;height: 100%;width: 100%;*+position:inherit; /*ie7 hack*/}\r\n#image-show-dom{overflow:hidden; background:#000;width:100%;height:100%;position: absolute;}\r\na.image-arrow-wrapper{height: 120px;width: 60px;position: absolute;top: 50%;z-index: 100;margin-top: -60px;opacity:0.5;filter:alpha(opacity=50);display: block;cursor: pointer;}\r\na.image-arrow-wrapper:hover{opacity:1;filter:alpha(opacity=100);}\r\n.image-arrow-wrapper div{height: 60px;width: 34px;background: transparent url(";
echo MYOA_STATIC_SERVER;
echo "/static/modules/picture/images/arrows.png) no-repeat 0 0;margin-top: 30px;margin-left: 15px;}\r\na.image-arrow-wrapper.left-arrow{left:0;}\r\na.image-arrow-wrapper.right-arrow{right: 0;}\r\n.image-arrow-wrapper.right-arrow div{margin-right: 15px;background-position: -34px 0;}\r\na.image-arrow-wrapper.disabled{opacity:0.1;filter:alpha(opacity=10);}\r\n#image-tips{width: 200px;height: 100px;position: absolute;left:50%;top:-50%;margin-left:-100px;margin-top: -50px;z-index: 10;text-align: center;color: #ffffff;border-radius: 4px;}\r\n#image-tips .image-tips-warpper{position: absolute;top:0;left:0;right:0;bottom:0;background-color: #000; opacity:0.5;filter:alpha(opacity=50);z-index: 100;}\r\n#image-tips .image-tips-content{position: absolute;top:0;left:0;right:0;bottom:0;z-index: 101;}\r\n#image-tips a {cursor: pointer;display: inline-block;padding:0 10px;height: 27px;line-height: 27px;text-align: center;color: #ffffff;margin-right: 5px;font-size:12px;}\r\n#image-tips p{height: 50px;line-height:50px;margin: 0;padding: 0;font-size:14px;}\r\n#image-tips a.bBtns{background-color: #0594fc;}\r\n#image-tips a.rBtns{background-color: #802420;}\r\n</style>\r\n<script type=\"text/javascript\">\r\nfunction MyLoad()\r\n{\r\n    if(typeof(window.external.OA_SMS) == 'undefined')\r\n    {\r\n        var offset_height = 310 - document.body.offsetHeight;\r\n        if(offset_height != 0)\r\n        {\r\n            window.moveBy(0, -(offset_height));\r\n            window.resizeBy(0,offset_height);\r\n        }\r\n    }\r\n    else\r\n    {\r\n        window.external.OA_SMS(640, 480, 'SET_SIZE');\r\n    }\r\n}\r\n</script>\r\n<body>\r\n<div id=\"image-show-wrapper\">\r\n";
if ( $VIEW_MODE == "gallery" )
{
    echo "    <div id=\"image-tips\">\r\n        <div class=\"image-tips-warpper\"></div>\r\n        <div class=\"image-tips-content\">\r\n            <p>";
    echo _( "ͼ����������!" );
    echo "</p>\r\n            <p>\r\n                <a href=\"javascript:;\" class=\"bBtns\" node-type=\"reBrowse\">";
    echo _( "�������" );
    echo "</a>\r\n                <a href=\"javascript:;\" class=\"rBtns\" node-type=\"close\">";
    echo _( "�ر�" );
    echo "</a>\r\n            </p>\r\n        </div>\r\n    </div>\r\n    <a class=\"image-arrow-wrapper left-arrow\" href=\"javascript:;\" node-type=\"imageArrow\" node-data=\"left\"><div></div></a>\r\n    <a class=\"image-arrow-wrapper right-arrow\" href=\"javascript:;\" node-type=\"imageArrow\" node-data=\"right\"><div></div></a>\r\n";
}
echo "    <div id=\"image-show-dom\"></div>\r\n</div>\r\n<script type=\"text/javascript\">\r\n";
if ( $VIEW_MODE == "gallery" )
{
    echo "    var gimg = \r\n    {\r\n        tips : false,\r\n        sources : ";
    echo json_encode( $img_url_arr );
    echo ",\r\n        currId : ";
    echo $CURRID;
    echo ",\r\n        init: function(){\r\n            if(this.currId == (this.sources.length - 1))\r\n                this.tips = true;                                                \r\n        },\r\n        dom:{\r\n            l : $('a[node-type=\"imageArrow\"][node-data=\"left\"]'),\r\n            r : $('a[node-type=\"imageArrow\"][node-data=\"right\"]'),\r\n            t : $('#image-tips')\r\n        },\r\n        resetArrow: function(){\r\n            if(this.currId == 0){\r\n                this.dom.l.addClass(\"disabled\");\r\n                this.dom.r.removeClass(\"disabled\");   \r\n            }else if(this.currId == (this.sources.length - 1)){\r\n                this.dom.l.removeClass(\"disabled\");\r\n                this.dom.r.addClass(\"disabled\");\r\n            }else{\r\n                this.hideTips();\r\n                this.dom.l.removeClass(\"disabled\");\r\n                this.dom.r.removeClass(\"disabled\");\r\n            }\r\n        },\r\n        stepBackward : function(){\r\n            if(this.currId == 0) {\r\n                return;\r\n            }\r\n            this.currId-= 1;\r\n            this.settings.contentUrl = this.sources[this.currId];\r\n            $('#image-show-dom').lhpMegaImgViewer('destroy');\r\n            $('#image-show-dom').lhpMegaImgViewer(this.settings).focus();\r\n            this.resetArrow();\r\n        },\r\n        stepForward : function(callback){\r\n            if(this.currId == (this.sources.length - 1)){\r\n                this.showTips();\r\n                return;    \r\n            }\r\n            this.currId+= 1;\r\n            this.settings.contentUrl = this.sources[this.currId];\r\n            $('#image-show-dom').lhpMegaImgViewer('destroy');\r\n            $('#image-show-dom').lhpMegaImgViewer(this.settings).focus();\r\n            this.resetArrow();\r\n            if(this.currId == (this.sources.length - 1))\r\n                this.showTips();        \r\n        },\r\n        showTips: function(){\r\n            if(this.tips)\r\n                this.dom.t.animate({ top: \"50%\", opacity: 1}, 500);\r\n            else\r\n                this.tips = true;\r\n        },\r\n        hideTips: function(){\r\n            if(this.tips)\r\n            {\r\n                this.dom.t.animate({ top: \"-50%\", opacity: 0}, 500);\r\n                this.tips = false;   \r\n            }\r\n        },\r\n        settings : $.noop\r\n    }\r\n";
}
echo "$(document).ready(function() {\r\n\r\n    var settings = {\r\n        'viewportWidth': '100%',\r\n        'viewportHeight': '100%',\r\n        'fitToViewportShortSide': false,\r\n        'contentSizeOver100': false,\r\n        'startScale': .5,\r\n        'startX': 0,\r\n        'startY': 0,\r\n        'animTime': 500,\r\n        'draggInertia': 10,\r\n        'contentUrl': '";
echo $img_url;
echo "',\r\n        'intNavEnable': true,\r\n        'intNavPos': 'B',\r\n        'intNavAutoHide': true,\r\n        'intNavMoveDownBtt': true,\r\n        'intNavMoveUpBtt': true,\r\n        'intNavMoveRightBtt': true,\r\n        'intNavMoveLeftBtt': true,\r\n        'intNavZoomBtt': true,\r\n        'intNavUnzoomBtt': true,\r\n        'intNavFitToViewportBtt': true,\r\n        'intNavFullSizeBtt': true,\r\n        'intNavBttSizeRation': 1,\r\n        'mapEnable': ";
echo $has_thumb ? "true" : "false";
echo ",\r\n        'mapThumb': '";
echo $img_thumb_url;
echo "',\r\n        'mapPos': 'BL',\r\n        'popupShowAction': 'click',\r\n        'testMode': false\r\n    };\r\n\r\n    $('#image-show-dom').lhpMegaImgViewer(settings).focus();\r\n\r\n    $(window).resize(function(){\r\n        $('#image-show-dom').lhpMegaImgViewer('destroy');\r\n        ";
if ( $VIEW_MODE == "gallery" )
{
    echo "            $('#image-show-dom').lhpMegaImgViewer(window.gimg.settings).focus();\r\n        ";
}
else
{
    echo "            $('#image-show-dom').lhpMegaImgViewer(settings).focus();\r\n        ";
}
echo "        \r\n    });\r\n\r\n";
if ( $VIEW_MODE == "gallery" )
{
    echo "    \r\n    window.gimg.settings = settings;\r\n\r\n    window.gimg.resetArrow();\r\n\r\n    window.gimg.init();\r\n\r\n    $('a[node-type=\"imageArrow\"]').click(function(){\r\n        if(window.gimg.currId)\r\n        {\r\n            currId = window.gimg.currId;\r\n            allItems = window.gimg.sources.length;\r\n        }\r\n        var rDom = $('a[node-type=\"imageArrow\"][node-data=\"right\"]');\r\n        var lDom = $('a[node-type=\"imageArrow\"][node-data=\"left\"]');\r\n        var action = $(this).attr('node-data');\r\n\r\n        if(action == \"left\")\r\n        {   \r\n            window.gimg.stepBackward();\r\n        }else{\r\n            window.gimg.stepForward();\r\n        }\r\n    });\r\n\r\n    $(document).keydown(function(e){\r\n        e.preventDefault();\r\n        e.stopPropagation();\r\n        var e = e||event;\r\n        var currKey=e.keyCode||e.which||e.charCode;\r\n        if(currKey == 37 || currKey == 39)\r\n        {\r\n            switch(currKey)\r\n            {\r\n                case 37:\r\n                    window.gimg && window.gimg.stepBackward();\r\n                    break;\r\n                case 39:\r\n                    window.gimg && window.gimg.stepForward();\r\n                    break;\r\n                default:\r\n                    break;\r\n            }\r\n        }\r\n    });\r\n\r\n    $('a[node-type=\"reBrowse\"]').click(function(){\r\n        window.gimg.currId = 0;\r\n        window.gimg.settings.contentUrl = window.gimg.sources[0];\r\n        $('#image-show-dom').lhpMegaImgViewer('destroy');\r\n        $('#image-show-dom').lhpMegaImgViewer(window.gimg.settings).focus();\r\n        window.gimg.resetArrow();\r\n        window.gimg.hideTips();\r\n    });\r\n\r\n    $('a[node-type=\"close\"]').click(function(){\r\n        window.close();\r\n    });\r\n\r\n";
}
echo "}); \r\n</script>\r\n</body>\r\n</html>";
?>
