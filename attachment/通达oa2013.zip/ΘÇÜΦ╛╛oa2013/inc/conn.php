<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
function OpenConnection( $MYSQL, $SELECT_DB = "" )
{
    if ( function_exists( "mysql_pconnect" ) )
    {
        echo _( "PHP�������󣬲��ܵ���Mysql�����⣬�����й�����" );
        exit( );
    }
    $C = @mysql_pconnect( @$MYSQL['host'], @$MYSQL['user'], @$MYSQL['pwd'], @MYSQL_CLIENT_COMPRESS );
    if ( $C === FALSE )
    {
        printerror( _( "�������ӵ�MySQL���ݿ⣬���飺1��MySQL�����Ƿ�������2��MySQL������ǽ��ֹ��3������MySQL���û����������Ƿ���ȷ��" ) );
        exit( );
    }
    $Q = "SET character_set_connection=".MYOA_DB_CHARSET.",character_set_results=".MYOA_DB_CHARSET.",character_set_client=binary;";
    if ( mysql_query( $Q, $C ) )
    {
        printerror( _( "�����ַ���ʧ��" ) );
        exit( );
    }
    if ( $SELECT_DB == "" )
    {
        $SELECT_DB = $MYSQL['db'];
    }
    if ( @mysql_select_db( $SELECT_DB, $C ) )
    {
        printerror( sprintf( _( "���ݿ� %s ������" ), $SELECT_DB ) );
        exit( );
    }
    return $C;
}

function exequery( $C, $Q, $QUERY_MASTER = FALSE, $LOG = FALSE )
{
    $cursor = @db_query( $Q, $C, $QUERY_MASTER );
    if ( $cursor )
    {
        printerror( "<b>"._( "SQL���:" )."</b> ".$Q, $LOG );
    }
    return $cursor;
}

function db_query( $Q, $C, $QUERY_MASTER = FALSE )
{
    $Q = sql_injection( $Q );
    if ( MYOA_DB_USE_REPLICATION && ( $QUERY_MASTER || strtolower( substr( ltrim( $Q ), 0, 6 ) ) != "select" && strtolower( substr( ltrim( $Q ), 0, 3 ) ) != "set" ) )
    {
        if ( $C == TD::$_res_conn && $C != TD::$_res_conn_master )
        {
            if ( is_resource( TD::$_res_conn_master ) )
            {
                TD::$_res_conn_master = openconnection( TD::$_arr_db_master, TD::$_arr_db_master['db'] );
            }
            $C = TD::$_res_conn_master;
        }
        else if ( $C == TD::$_res_conn_crscell && $C != TD::$_res_conn_crscell_master )
        {
            if ( is_resource( TD::$_res_conn_crscell_master ) )
            {
                TD::$_res_conn_crscell_master = openconnection( TD::$_arr_db_master, TD::$_arr_db_master['db_crscell'] );
            }
            $C = TD::$_res_conn_crscell_master;
        }
    }
    return mysql_query( $Q, $C );
}

function db_set_charset( $CHARSET, $C )
{
    return mysql_set_charset( $CHARSET, $C );
}

function PrintError( $MSG, $LOG = FALSE )
{
    echo "<fieldset style=\"line-height:150%;font-size:12px;\">";
    echo "<legend>&nbsp;"._( "��������ϵ����Ա" )."&nbsp;</legend>";
    echo $MSG."<br>";
    echo "<b>"._( "�ļ���" )."</b>".$_SERVER['SCRIPT_NAME'];
    if ( mysql_errno( ) == 1030 )
    {
        echo "<br>"._( "����ϵ����Ա�� ϵͳ����-���ݿ���� ���޸����ݿ�����" );
    }
    echo "</fieldset>";
    $LOG_PATH = realpath( MYOA_ROOT_PATH."../logs" );
    if ( $LOG )
    {
        if ( file_exists( $LOG_PATH ) && is_writable( $LOG_PATH ) )
        {
            $DATA = date( "[Y-m-d H:i:s]" )."\r\n";
            $DATA .= _( "����#" ).mysql_errno( ).": ".mysql_error( )."\r\n";
            $DATA .= strip_tags( $MSG )."\r\n";
            $DATA .= _( "�ļ���" ).htmlspecialchars( $_SERVER['REQUEST_URI'] )."\r\n";
            $DATA .= "\r\n";
            $LOG_FILE = $LOG_PATH."/mysql_error.log";
            $FP = @fopen( $LOG_FILE, "a" );
            if ( $FP )
            {
                fwrite( $FP, $DATA );
                fclose( $FP );
            }
        }
        if ( $LOG )
        {
            exit( );
        }
    }
}

function sql_injection( $db_string )
{
    $clean = "";
    $error = "";
    $old_pos = 0;
    $pos = -1;
    do
    {
        $pos = strpos( $db_string, "'", $pos + 1 );
        if ( $pos === FALSE )
        {
            break;
        }
        else
        {
            $clean .= substr( $db_string, $old_pos, $pos - $old_pos );
            do
            {
                $pos1 = strpos( $db_string, "'", $pos + 1 );
                $pos2 = strpos( $db_string, "\\", $pos + 1 );
                if ( $pos1 === FALSE )
                {
                }
                else if ( !$pos2 || $pos1 < $pos2 )
                {
                    $pos = $pos1;
                }
                else
                {
                    $pos = $pos2 + 1;
                }
            } while ( 1 );
        }
        $clean .= "\$s\$";
        $old_pos = $pos + 1;
    } while ( 1 );
    $clean .= substr( $db_string, $old_pos );
    $clean = trim( strtolower( preg_replace( array( "~\\s+~s" ), array( " " ), $clean ) ) );
    $fail = FALSE;
    if ( strpos( $clean, "union" ) !== FALSE && preg_match( "~(^|[^a-z])union($|[^[a-z])~s", $clean ) != 0 )
    {
        $fail = TRUE;
        $error = _( "���ϲ�ѯ" );
    }
    else if ( 2 < strpos( $clean, "/*" ) || strpos( $clean, "--" ) !== FALSE || strpos( $clean, "#" ) !== FALSE )
    {
        $fail = TRUE;
        $error = _( "ע�ʹ���" );
    }
    else if ( strpos( $clean, "sleep" ) !== FALSE && preg_match( "~(^|[^a-z])sleep($|[^[a-z])~s", $clean ) != 0 )
    {
        $fail = TRUE;
        $error = "sleep";
    }
    else if ( strpos( $clean, "benchmark" ) !== FALSE && preg_match( "~(^|[^a-z])benchmark($|[^[a-z])~s", $clean ) != 0 )
    {
        $fail = TRUE;
        $error = "benchmark";
    }
    else if ( strpos( $clean, "load_file" ) !== FALSE && preg_match( "~(^|[^a-z])load_file($|[^[a-z])~s", $clean ) != 0 )
    {
        $fail = TRUE;
        $error = _( "Load�ļ�" );
    }
    else if ( strpos( $clean, "cast" ) !== FALSE && preg_match( "~(^|[^a-z])mid($|[^[a-z])~s", $clean ) != 0 )
    {
        $fail = TRUE;
        $error = "cast";
    }
    else if ( strpos( $clean, "ord" ) !== FALSE && preg_match( "~(^|[^a-z])ord($|[^[a-z])~s", $clean ) != 0 )
    {
        $fail = TRUE;
        $error = "ord";
    }
    else if ( strpos( $clean, "ascii" ) !== FALSE && preg_match( "~(^|[^a-z])ascii($|[^[a-z])~s", $clean ) != 0 )
    {
        $fail = TRUE;
        $error = "ascii";
    }
    else if ( strpos( $clean, "extractvalue" ) !== FALSE && preg_match( "~(^|[^a-z])extractvalue($|[^[a-z])~s", $clean ) != 0 )
    {
        $fail = TRUE;
        $error = "extractvalue";
    }
    else if ( strpos( $clean, "updatexml" ) !== FALSE && preg_match( "~(^|[^a-z])updatexml($|[^[a-z])~s", $clean ) != 0 )
    {
        $fail = TRUE;
        $error = "updatexml";
    }
    else if ( strpos( $clean, "into outfile" ) !== FALSE && preg_match( "~(^|[^a-z])into\\s+outfile($|[^[a-z])~s", $clean ) != 0 )
    {
        $fail = TRUE;
        $error = _( "�����ļ�" );
    }
    if ( $fail )
    {
        echo _( "����ȫ��SQL��䣺" ).$error."<br />";
        echo htmlspecialchars( $db_string );
        exit( );
    }
    return $db_string;
}

include_once( "inc/td_config.php" );
include_once( "inc/common.inc.php" );
?>
