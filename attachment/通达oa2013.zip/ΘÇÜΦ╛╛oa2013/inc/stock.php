<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
include_once( "inc/td_config.php" );
$output = "";
$sh_res = @file_get_contents( "http://hq.sinajs.cn/?list=s_sh000001" );
if ( $sh_res )
{
    $sh_res = substr( $sh_res, strpos( $sh_res, "\"" ), -2 );
    $output .= "\"sh\":".$sh_res.",";
}
$sz_res = @file_get_contents( "http://hq.sinajs.cn/?list=s_sz399001" );
if ( $sz_res )
{
    $sz_res = substr( $sz_res, strpos( $sz_res, "\"" ), -2 );
    $output .= "\"sz\":".$sz_res.",";
}
$output = iconv( "gbk", MYOA_CHARSET, $output );
ob_end_clean( );
echo "var hq = {".rtrim( $output, "," )."};";
?>
