<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
$ATTACH_BACKUP_PATH = $ATTACH_PATH2."bak/";
$MYOA_CACHE_PATH = $ATTACH_PATH2."cache/";
$MYOA_RECYCLE_PATH = $ATTACH_PATH2."recycle/";
$SMS_REF_SEC = 30;
$ONLINE_REF_SEC = 120;
$ATTACH_LOCK_REF_SEC = 180;
$OFFLINE_TIME_MIN = 0;
$STATUS_REF_SEC = 3600;
$SMS_REF_MAX = 3;
$SMS_CALLSOUND_INTERVAL = 3;
$FLOW_REMIND_TIME = 0;
$UPLOAD_LIMIT = 1;
$UPLOAD_LIMIT_TYPE = "php,php3,php4,php5,";
$EDIT_LIMIT_TYPE = "php,php3,php4,php5,phpt,inc,jsp,asp,aspx,js,cgi,pl,";
$CORRECT_BUTTON = 1;
$ONE_USER_MUL_LOGIN = 1;
$ATTACH_UTF8 = 0;
$ATTACH_OFFICE_OPEN_IN_IE = 0;
$SMS_DELAY_PER_ROWS = 60;
$SMS_DELAY_SECONDS = 60;
$MYOA_LOGIN_TIME_RANGE = "00:00:00 ~ 23:59:59";
$MYOA_GAME_TIME_RANGE = "00:00:00 ~ 23:59:59";
$MYOA_IS_RECYCLE = 1;
$MYOA_IS_DEMO = 0;
$MYOA_IM_REMIND_ROWS = 60;
$MYOA_USE_OS_BROWSER = 0;
$MYOA_SUPPORT_GZIP = 1;
$MYOA_MEMCACHED_SERVERS = array( array( "host" => "127.0.0.1", "port" => 11211, "persistent" => FALSE, "weight" => 1 ) );
$MYOA_SESS_SAVE_HANDLER = "files";
$MYOA_CACHE_DRIVER = "apc";
$MYOA_CACHE_CONFIG = array( "prefix" => "", "cache_path" => $MYOA_CACHE_PATH, "memcached_servers" => $MYOA_MEMCACHED_SERVERS );
$MYSQL_SERVER = "localhost:3336";
$MYSQL_USER = "root";
$MYSQL_DB = "TD_OA";
$MYSQL_PASS = "myoa888";
?>
