<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
echo "<style>\r\n.vmPanel{padding-left:9px;margin: 10px 0;background: url(\"";
echo MYOA_STATIC_SERVER;
echo "/static/images/voicemsg/sound_bg.png\") no-repeat left top;height:38px;line-height:38px;cursor:pointer;}\r\n.vmContent {background:url(\"";
echo MYOA_STATIC_SERVER;
echo "/static/images/voicemsg/sound_bg.png\") no-repeat right -38px;font-size:12px; font-weight:bold; color:#668A0D; text-align:right;padding-right: 10px;} \r\n.vmContent .icoVoice, .vmContent .icoVoicePlaying, .vmContent .icoVoiceDown {float:left;width:32px;height:32px;margin-top:4px;display: inline;}\r\n.vmContent .icoVoice{background: url(\"";
echo MYOA_STATIC_SERVER;
echo "/static/images/voicemsg/icon_sound.png\") no-repeat 0 3px;}\r\n.vmContent .icoVoiceDown{background: url(\"";
echo MYOA_STATIC_SERVER;
echo "/static/images/voicemsg/icon_download.png\") no-repeat -32px 0;} \r\n.vmContent .icoVoicePlaying{background: url(\"";
echo MYOA_STATIC_SERVER;
echo "/static/images/voicemsg/you_voice_play.gif\") no-repeat 0 4px;}\r\n.vmPanel.vmYou{background-position:left top;}\r\n.vmPanel.vmYou .vmContent{background-position:right -38px;}\r\n\r\n.vmPanel.vmMe{background-position:left -76px;}\r\n.vmPanel.vmMe .vmContent{background-position:right -114px;color:#9e9e9e;}\r\n.vmPanel.vmMe .vmContent .icoVoice{background: url(\"";
echo MYOA_STATIC_SERVER;
echo "/static/images/voicemsg/icon_sound.png\") no-repeat -31px 3px;}\r\n.vmPanel.vmMe .vmContent .icoVoiceDown{background: url(\"";
echo MYOA_STATIC_SERVER;
echo "/static/images/voicemsg/icon_download.png\") no-repeat 0 0;}\r\n.vmPanel.vmMe .vmContent .icoVoicePlaying{background: url(\"";
echo MYOA_STATIC_SERVER;
echo "/static/images/voicemsg/me_voice_play.gif\") no-repeat 0 5px;}\r\n\r\n.emotions{vertical-align:middle;}\r\n.imPanel, a.fmPanel, .lmPanel{margin:5px 0;}\r\n\r\na.fmPanel{border-radius: 2px;display: block;width: 182px;height: 40px;line-height: 40px;background: url(";
echo MYOA_STATIC_SERVER;
echo "/static/images/ipanel/download.jpg) no-repeat;text-decoration:none;}\r\na.fmPanel span{display: block;padding-left: 50px;background-position: 4px center;background-repeat: no-repeat;color: #9e9e9e;overflow: hidden;white-space: nowrap;text-overflow: ellipsis;}\r\n\r\n.lmPanel{display:inline-block;height: 18px;padding-left: 20px;line-height: 18px;background: url(";
echo MYOA_STATIC_SERVER;
echo "/static/images/ipanel/location.png) no-repeat;}\r\n</style>\r\n<script src=\"";
echo MYOA_JS_SERVER;
echo "/static/js/ispirit.js\"></script>\r\n<script type=\"text/javascript\">\r\n(function($){\r\n\r\nvar imageMsg = {\r\n  init: function(){\r\n      $(document).delegate(\".imPanel[node-type='tMImage']\", \"click\", function(e)\r\n      {\r\n          var _href = $(this).attr('node-data'); \r\n          e.stopPropagation();\r\n\r\n          if(typeof(window.external.PlayVoiceMsg) == \"undefined\")\r\n          {\r\n              mytop=(screen.availHeight-510)/2;\r\n              myleft=(screen.availWidth-660)/2;\r\n              window.open(_href, \"imageShow\", \"height=510, width=660, top=\"+mytop+\", left=\"+myleft+\",toolbar=no, menubar=no, scrollbars=yes, resizable=no, location=no, status=no\");\r\n          }else{\r\n              if(parent && parent.openURL)\r\n              {\r\n                  parent.openURL(_href);  \r\n              }\r\n          }\r\n          return;\r\n      });\r\n  }\r\n}\r\n\r\nvar voiceMsg = {\r\n  \"init\": function(){\r\n      $(document).delegate(\".vmPanel[action-type='play']\", \"click\", function(e)\r\n      {\r\n          e.stopPropagation();\r\n\r\n          if(typeof ($(this).attr(\"status\")) == \"undefined\")\r\n              var status = \"stop\";\r\n          else\r\n              var status = $(this).attr(\"status\");\r\n\r\n          if(status == \"stop\")\r\n          {\r\n              $(this).attr(\"status\", \"palying\");\r\n              voiceMsg.play($(this));\r\n              $(this).attr(\"title\", \"";
echo _( "���ֹͣ����" );
echo "\");\r\n          }else{\r\n              $(this).attr(\"status\", \"stop\");\r\n              voiceMsg.stop();\r\n              $(this).attr(\"title\", \"";
echo _( "�������" );
echo "\");\r\n          }\r\n          return;\r\n      });\r\n     \r\n      $(document).delegate(\".vmPanel[action-type='download']\", \"click\", function(){voiceMsg.download($(this));});\r\n  },\r\n  \"play\": function(handler)\r\n  {\r\n      var voice_data = handler.attr(\"action-data\");\r\n      this.stop();\r\n      handler.find(\"[un='voiceStatus']\").attr(\"class\", \"icoVoicePlaying\");\r\n      if(typeof(window.external.PlayVoiceMsg) == \"undefined\"){\r\n\r\n      }else{\r\n        window.external.PlayVoiceMsg(voice_data);  \r\n      }\r\n  },\r\n  \"stop\": function()\r\n  {\r\n      if(typeof(window.external.StopVoiceMsg) == \"undefined\"){     \r\n      }else{\r\n        window.external.StopVoiceMsg(\"\");\r\n      }\r\n      StopVoiceMsg();\r\n  },\r\n  \"download\": function(handler){\r\n      var voice_data = handler.attr(\"action-data-url\");\r\n      window.open(voice_data);\r\n  }\r\n}\r\n\r\n$(function(){ replaceVMDom();voiceMsg.init();imageMsg.init();});\r\n\r\n})(jQuery);\r\n\r\nfunction replaceVMDom()\r\n{\r\n\r\n  if(!window.external) return;\r\n  \r\n  if(typeof(window.external.OA_SMS) == \"undefined\")\r\n  {\r\n    //Ĭ�������ز���Ҫ�滻\r\n  }else{\r\n    if(!window.external.OA_SMS(\"\", \"\", \"GET_VERSION\") || window.external.OA_SMS(\"\", \"\", \"GET_VERSION\") < '20121210')\r\n    {\r\n      var vm = jQuery(\".vmPanel\");\r\n      vm.before(\"<span style='color:red'>";
echo _( "ϵͳ��ʾ���ͻ��˰汾���ͣ��������ͻ���" );
echo "</span>\");\r\n      vm.remove();\r\n    }else{\r\n\r\n      //��ͨ����̨��ֵ�жϾ���Ĳ��ֲ��滻\r\n      if(jQuery(\".vmPanel\").size() > 0)\r\n      {\r\n        var defaultaction = jQuery(\".vmPanel\").eq(0).attr(\"action-type\");\r\n        if(defaultaction == \"play\" && typeof(window.external.PlayVoiceMsg)!=\"undefined\") \r\n          return;\r\n\r\n      }else{\r\n        return;\r\n      }\r\n\r\n      jQuery(\".vmPanel\").each(function()\r\n      {\r\n          jQuery(this).attr({\r\n              \"action-type\" : \"play\",\r\n              \"title\" : \"";
echo _( "�������" );
echo "\"\r\n          });\r\n          jQuery(this).find(\"[un='voiceStatus']\").attr(\"class\", \"icoVoice\");\r\n      });\r\n    }\r\n  }\r\n}\r\n\r\nfunction StopVoiceMsg(){\r\n  jQuery(\"[un='voiceStatus']\").attr(\"class\", \"icoVoice\"); \r\n}\r\n\r\ntop.StopVoiceMsg = StopVoiceMsg;\r\n\r\n</script>\r\n";
?>
