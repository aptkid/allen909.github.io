<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class LanguageConv
{

    private $g2312;

    public function Convert( $aTxt, $aFF )
    {
        if ( LANGUAGE_GREEK )
        {
            if ( GREEK_FROM_WINDOWS )
            {
                $unistring = ( $aTxt );
                return $unistring;
            }
            $unistring = ( $aTxt );
            return $unistring;
        }
        if ( LANGUAGE_CYRILLIC )
        {
            if ( CYRILLIC_FROM_WINDOWS && ( !defined( "LANGUAGE_CHARSET" ) || stristr( LANGUAGE_CHARSET, "windows-1251" ) ) )
            {
                $aTxt = convert_cyr_string( $aTxt, "w", "k" );
            }
            if ( !defined( "LANGUAGE_CHARSET" ) || stristr( LANGUAGE_CHARSET, "koi8-r" ) || stristr( LANGUAGE_CHARSET, "windows-1251" ) )
            {
                $isostring = convert_cyr_string( $aTxt, "k", "i" );
                $unistring = ( $isostring );
                return $unistring;
            }
            $unistring = $aTxt;
            return $unistring;
        }
        if ( $aFF === FF_SIMSUN )
        {
            if ( $this->g2312 == NULL )
            {
                include_once( "jpgraph_gb2312.php" );
                $this->g2312 = new GB2312toUTF8( );
            }
            return $this->g2312->gb2utf8( $aTxt );
        }
        if ( $aFF === FF_CHINESE )
        {
            if ( function_exists( "iconv" ) )
            {
                ( 25006 );
            }
            return iconv( "BIG5", "UTF-8", $aTxt );
        }
        if ( ASSUME_EUCJP_ENCODING && ( $aFF == FF_MINCHO || $aFF == FF_GOTHIC || $aFF == FF_PMINCHO || $aFF == FF_PGOTHIC ) )
        {
            if ( function_exists( "mb_convert_encoding" ) )
            {
                ( 25127 );
            }
            return mb_convert_encoding( $aTxt, "UTF-8", "EUC-JP" );
        }
        return $aTxt;
    }

    public static function iso2uni( $isoline )
    {
        $uniline = "";
        $i = 0;
        for ( ; $i < strlen( $isoline ); ++$i )
        {
            $thischar = substr( $isoline, $i, 1 );
            $charcode = ord( $thischar );
            $uniline .= 175 < $charcode ? "&#".( 1040 + ( $charcode - 176 ) ).";" : $thischar;
        }
        return $uniline;
    }

    public static function gr_iso2uni( $isoline )
    {
        $uniline = "";
        $i = 0;
        for ( ; $i < strlen( $isoline ); ++$i )
        {
            $thischar = substr( $isoline, $i, 1 );
            $charcode = ord( $thischar );
            $uniline .= 179 < $charcode && $charcode != 183 && $charcode != 187 && $charcode != 189 ? "&#".( 900 + ( $charcode - 180 ) ).";" : $thischar;
        }
        return $uniline;
    }

    public static function gr_win2uni( $winline )
    {
        $uniline = "";
        $i = 0;
        for ( ; $i < strlen( $winline ); ++$i )
        {
            $thischar = substr( $winline, $i, 1 );
            $charcode = ord( $thischar );
            if ( $charcode == 161 || $charcode == 162 )
            {
                $uniline .= "&#".( 740 + $charcode ).";";
            }
            else
            {
                $uniline .= !( 183 < $charcode ) || !( $charcode != 187 ) || $charcode != 189 || $charcode == 180 ? "&#".( 900 + ( $charcode - 180 ) ).";" : $thischar;
            }
        }
        return $uniline;
    }

}

class JpgTimer
{

    private $start;
    private $idx;

    public function JpgTimer( )
    {
        $this->idx = 0;
    }

    public function Push( )
    {
        list( $ms, $s ) = explode( " ", microtime( ) );
        $this->start[$this->idx++] = floor( $ms * 1000 ) + 1000 * $s;
    }

    public function Pop( )
    {
        assert( 0 < $this->idx );
        $s = explode( " ", microtime( ) )[1];
        $ms = explode( " ", microtime( ) )[0];
        $etime = floor( $ms * 1000 ) + 1000 * $s;
        $this->idx--;
        return $etime - $this->start[$this->idx];
    }

}

class DateLocale
{

    public $iLocale = "C";
    private $iDayAbb;
    private $iShortDay;
    private $iShortMonth;
    private $iMonthName;

    public function DateLocale( )
    {
        settype( &$this->iDayAbb, "array" );
        settype( &$this->iShortDay, "array" );
        settype( &$this->iShortMonth, "array" );
        settype( &$this->iMonthName, "array" );
        $this->Set( "C" );
    }

    public function Set( $aLocale )
    {
        if ( in_array( $aLocale, array_keys( $this->iDayAbb ) ) )
        {
            $this->iLocale = $aLocale;
            return TRUE;
        }
        $pLocale = setlocale( LC_TIME, 0 );
        $res = @setlocale( @LC_TIME, $aLocale );
        if ( $res )
        {
            ( 25007, $aLocale );
            return FALSE;
        }
        $this->iLocale = $aLocale;
        $i = 0;
        $ofs = 0 - strftime( "%w" );
        for ( ; $i < 7; ++$i, ++$ofs )
        {
            $day = strftime( "%a", strtotime( "{$ofs} day" ) );
            $day[0] = strtoupper( $day[0] );
            $this->iDayAbb[$aLocale][] = $day[0];
            $this->iShortDay[$aLocale][] = $day;
        }
        $i = 1;
        for ( ; $i <= 12; ++$i )
        {
            $full = explode( "|", strftime( "%b|%B", strtotime( "2001-".$i."-01" ) ) )[1];
            $short = explode( "|", strftime( "%b|%B", strtotime( "2001-".$i."-01" ) ) )[0];
            $this->iShortMonth[$aLocale][] = ucfirst( $short );
            $this->iMonthName[$aLocale][] = ucfirst( $full );
        }
        setlocale( LC_TIME, $pLocale );
        return TRUE;
    }

    public function GetDayAbb( )
    {
        return $this->iDayAbb[$this->iLocale];
    }

    public function GetShortDay( )
    {
        return $this->iShortDay[$this->iLocale];
    }

    public function GetShortMonth( )
    {
        return $this->iShortMonth[$this->iLocale];
    }

    public function GetShortMonthName( $aNbr )
    {
        return $this->iShortMonth[$this->iLocale][$aNbr];
    }

    public function GetLongMonthName( $aNbr )
    {
        return $this->iMonthName[$this->iLocale][$aNbr];
    }

    public function GetMonth( )
    {
        return $this->iMonthName[$this->iLocale];
    }

}

class Footer
{

    public $iLeftMargin = 3;
    public $iRightMargin = 3;
    public $iBottomMargin = 3;
    public $left;
    public $center;
    public $right;

    public function Footer( )
    {
        $this->left = new Text( );
        $this->left->ParagraphAlign( "left" );
        $this->center = new Text( );
        $this->center->ParagraphAlign( "center" );
        $this->right = new Text( );
        $this->right->ParagraphAlign( "right" );
    }

    public function SetMargin( $aLeft = 3, $aRight = 3, $aBottom = 3 )
    {
        $this->iLeftMargin = $aLeft;
        $this->iRightMargin = $aRight;
        $this->iBottomMargin = $aBottom;
    }

    public function Stroke( $aImg )
    {
        $y = $aImg->height - $this->iBottomMargin;
        $x = $this->iLeftMargin;
        $this->left->Align( "left", "bottom" );
        $this->left->Stroke( $aImg, $x, $y );
        $x = ( $aImg->width - $this->iLeftMargin - $this->iRightMargin ) / 2;
        $this->center->Align( "center", "bottom" );
        $this->center->Stroke( $aImg, $x, $y );
        $x = $aImg->width - $this->iRightMargin;
        $this->right->Align( "right", "bottom" );
        $this->right->Stroke( $aImg, $x, $y );
    }

}

class Graph
{

    public $cache;
    public $img;
    public $plots = array( );
    public $y2plots = array( );
    public $ynplots = array( );
    public $xscale;
    public $yscale;
    public $y2scale;
    public $ynscale = array( );
    public $iIcons = array( );
    public $cache_name;
    public $xgrid;
    public $ygrid;
    public $y2grid;
    public $doframe = TRUE;
    public $frame_color = array( 0, 0, 0 );
    public $frame_weight = 1;
    public $boxed = FALSE;
    public $box_color = array( 0, 0, 0 );
    public $box_weight = 1;
    public $doshadow = FALSE;
    public $shadow_width = 4;
    public $shadow_color = array( 102, 102, 102 );
    public $xaxis;
    public $yaxis;
    public $y2axis;
    public $ynaxis = array( );
    public $margin_color = array( 200, 200, 200 );
    public $plotarea_color = array( 255, 255, 255 );
    public $title;
    public $subtitle;
    public $subsubtitle;
    public $axtype = "linlin";
    public $xtick_factor;
    public $texts;
    public $y2texts;
    public $lines;
    public $y2lines;
    public $bands;
    public $y2bands;
    public $text_scale_off = 0;
    public $text_scale_abscenteroff = -1;
    public $background_image = "";
    public $background_image_type = -1;
    public $background_image_format = "png";
    public $background_image_bright = 0;
    public $background_image_contr = 0;
    public $background_image_sat = 0;
    public $image_bright = 0;
    public $image_contr = 0;
    public $image_sat = 0;
    public $inline;
    public $showcsim = 0;
    public $csimcolor = "red";
    public $grid_depth = DEPTH_BACK;
    public $iAxisStyle = AXSTYLE_SIMPLE;
    public $iCSIMdisplay = FALSE;
    public $iHasStroked = FALSE;
    public $footer;
    public $csimcachename = "";
    public $csimcachetimeout = 0;
    public $iDoClipping = FALSE;
    public $y2orderback = TRUE;
    public $tabtitle;
    public $bkg_gradtype = -1;
    public $bkg_gradstyle = BGRAD_MARGIN;
    public $bkg_gradfrom = "navy";
    public $bkg_gradto = "silver";
    public $titlebackground = FALSE;
    public $titlebackground_color = "lightblue";
    public $titlebackground_style = 1;
    public $titlebackground_framecolor = "blue";
    public $titlebackground_framestyle = 2;
    public $titlebackground_frameweight = 1;
    public $titlebackground_bevelheight = 3;
    public $titlebkg_fillstyle = TITLEBKG_FILLSTYLE_SOLID;
    public $titlebkg_scolor1 = "black";
    public $titlebkg_scolor2 = "white";
    public $framebevel = FALSE;
    public $framebeveldepth = 2;
    public $framebevelborder = FALSE;
    public $framebevelbordercolor = "black";
    public $framebevelcolor1 = "white@0.4";
    public $framebevelcolor2 = "black@0.4";
    public $background_image_mix = 100;
    public $background_cflag = "";
    public $background_cflag_type = BGIMG_FILLPLOT;
    public $background_cflag_mix = 100;
    public $iImgTrans = FALSE;
    public $iImgTransHorizon = 100;
    public $iImgTransSkewDist = 150;
    public $iImgTransDirection = 1;
    public $iImgTransMinSize = TRUE;
    public $iImgTransFillColor = "white";
    public $iImgTransHighQ = FALSE;
    public $iImgTransBorder = FALSE;
    public $iImgTransHorizonPos = 0.5;
    protected $iYAxisDeltaPos = 50;
    protected $iIconDepth = DEPTH_BACK;
    protected $iAxisLblBgType = 0;
    protected $iXAxisLblBgFillColor = "lightgray";
    protected $iXAxisLblBgColor = "black";
    protected $iYAxisLblBgFillColor = "lightgray";
    protected $iYAxisLblBgColor = "black";
    protected $iTables;

    public function Graph( $aWidth = 300, $aHeight = 200, $aCachedName = "", $aTimeOut = 0, $aInline = TRUE )
    {
        global $gJpgBrandTiming;
        if ( $gJpgBrandTiming )
        {
            global $tim;
            $tim = new JpgTimer( );
            $tim->Push( );
        }
        if ( !is_numeric( $aWidth ) || !is_numeric( $aHeight ) )
        {
            ( 25008 );
        }
        if ( $aCachedName == "auto" )
        {
            $aCachedName = genimgname( );
        }
        $this->inline = $aInline;
        $this->img = new RotImage( $aWidth, $aHeight );
        $this->cache = new ImgStreamCache( $this->img );
        $this->cache->SetTimeOut( $aTimeOut );
        $this->title = new Text( );
        $this->title->ParagraphAlign( "center" );
        $this->title->SetFont( FF_FONT2, FS_BOLD );
        $this->title->SetMargin( 3 );
        $this->title->SetAlign( "center" );
        $this->subtitle = new Text( );
        $this->subtitle->ParagraphAlign( "center" );
        $this->subtitle->SetMargin( 2 );
        $this->subtitle->SetAlign( "center" );
        $this->subsubtitle = new Text( );
        $this->subsubtitle->ParagraphAlign( "center" );
        $this->subsubtitle->SetMargin( 2 );
        $this->subsubtitle->SetAlign( "center" );
        $this->legend = new Legend( );
        $this->footer = new Footer( );
        $aCachedName = str_replace( "?", "_", $aCachedName );
        if ( $aCachedName != "" && READ_CACHE && $aInline && $this->cache->GetAndStream( $aCachedName ) )
        {
            exit( );
        }
        $this->cache_name = $aCachedName;
        $this->SetTickDensity( );
        $this->tabtitle = new GraphTabTitle( );
    }

    public function Set3DPerspective( $aDir = 1, $aHorizon = 100, $aSkewDist = 120, $aQuality = FALSE, $aFillColor = "#FFFFFF", $aBorder = FALSE, $aMinSize = TRUE, $aHorizonPos = 0.5 )
    {
        $this->iImgTrans = TRUE;
        $this->iImgTransHorizon = $aHorizon;
        $this->iImgTransSkewDist = $aSkewDist;
        $this->iImgTransDirection = $aDir;
        $this->iImgTransMinSize = $aMinSize;
        $this->iImgTransFillColor = $aFillColor;
        $this->iImgTransHighQ = $aQuality;
        $this->iImgTransBorder = $aBorder;
        $this->iImgTransHorizonPos = $aHorizonPos;
    }

    public function SetImgFormat( $aFormat, $aQuality = 75 )
    {
        $this->img->SetImgFormat( $aFormat, $aQuality );
    }

    public function SetGridDepth( $aDepth )
    {
        $this->grid_depth = $aDepth;
    }

    public function SetIconDepth( $aDepth )
    {
        $this->iIconDepth = $aDepth;
    }

    public function SetAngle( $aAngle )
    {
        $this->img->SetAngle( $aAngle );
    }

    public function SetAlphaBlending( $aFlg = TRUE )
    {
        $this->img->SetAlphaBlending( $aFlg );
    }

    public function SetMargin( $lm, $rm, $tm, $bm )
    {
        $this->img->SetMargin( $lm, $rm, $tm, $bm );
    }

    public function SetY2OrderBack( $aBack = TRUE )
    {
        $this->y2orderback = $aBack;
    }

    public function Set90AndMargin( $lm = 0, $rm = 0, $tm = 0, $bm = 0 )
    {
        $lm = $lm == 0 ? floor( 0.2 * $this->img->width ) : $lm;
        $rm = $rm == 0 ? floor( 0.1 * $this->img->width ) : $rm;
        $tm = $tm == 0 ? floor( 0.2 * $this->img->height ) : $tm;
        $bm = $bm == 0 ? floor( 0.1 * $this->img->height ) : $bm;
        $adj = ( $this->img->height - $this->img->width ) / 2;
        $this->img->SetMargin( $tm - $adj, $bm - $adj, $rm + $adj, $lm + $adj );
        $this->img->height( floor( $this->img->width / 2 ), floor( $this->img->height / 2 ) );
        $this->SetAngle( 90 );
        if ( empty( $this->yaxis ) || empty( $this->xaxis ) )
        {
            ( 25009 );
        }
        $this->xaxis->SetLabelAlign( "right", "center" );
        $this->yaxis->SetLabelAlign( "center", "bottom" );
    }

    public function SetClipping( $aFlg = TRUE )
    {
        $this->iDoClipping = $aFlg;
    }

    public function Add( $aPlot )
    {
        if ( $aPlot == NULL )
        {
            ( 25010 );
        }
        if ( is_array( $aPlot ) && 0 < count( $aPlot ) )
        {
            $cl = $aPlot[0];
        }
        else
        {
            $cl = $aPlot;
        }
        if ( $cl instanceof Text )
        {
            $this->AddText( $aPlot );
        }
        else if ( $cl instanceof PlotLine )
        {
            $this->AddLine( $aPlot );
        }
        else if ( class_exists( "PlotBand", FALSE ) && $cl instanceof PlotBand )
        {
            $this->AddBand( $aPlot );
        }
        else if ( class_exists( "IconPlot", FALSE ) && $cl instanceof IconPlot )
        {
            $this->AddIcon( $aPlot );
        }
        else if ( class_exists( "GTextTable", FALSE ) && $cl instanceof GTextTable )
        {
            $this->AddTable( $aPlot );
        }
        else
        {
            $this->plots[] = $aPlot;
        }
    }

    public function AddTable( $aTable )
    {
        if ( is_array( $aTable ) )
        {
            $i = 0;
            for ( ; $i < count( $aTable ); ++$i )
            {
                $this->iTables[] = $aTable[$i];
            }
        }
        else
        {
            $this->iTables[] = $aTable;
        }
    }

    public function AddIcon( $aIcon )
    {
        if ( is_array( $aIcon ) )
        {
            $i = 0;
            for ( ; $i < count( $aIcon ); ++$i )
            {
                $this->iIcons[] = $aIcon[$i];
            }
        }
        else
        {
            $this->iIcons[] = $aIcon;
        }
    }

    public function AddY2( $aPlot )
    {
        if ( $aPlot == NULL )
        {
            ( 25011 );
        }
        if ( is_array( $aPlot ) && 0 < count( $aPlot ) )
        {
            $cl = $aPlot[0];
        }
        else
        {
            $cl = $aPlot;
        }
        if ( $cl instanceof Text )
        {
            $this->AddText( $aPlot, TRUE );
        }
        else if ( $cl instanceof PlotLine )
        {
            $this->AddLine( $aPlot, TRUE );
        }
        else if ( class_exists( "PlotBand", FALSE ) && $cl instanceof PlotBand )
        {
            $this->AddBand( $aPlot, TRUE );
        }
        else
        {
            $this->y2plots[] = $aPlot;
        }
    }

    public function AddY( $aN, $aPlot )
    {
        if ( $aPlot == NULL )
        {
            ( 25012 );
        }
        if ( is_array( $aPlot ) && 0 < count( $aPlot ) )
        {
            $cl = $aPlot[0];
        }
        else
        {
            $cl = $aPlot;
        }
        if ( $cl instanceof Text || $cl instanceof PlotLine || class_exists( "PlotBand", FALSE ) && $cl instanceof PlotBand )
        {
            ( 25013 );
        }
        else
        {
            $this->ynplots[$aN][] = $aPlot;
        }
    }

    public function AddText( $aTxt, $aToY2 = FALSE )
    {
        if ( $aTxt == NULL )
        {
            ( 25014 );
        }
        if ( $aToY2 )
        {
            if ( is_array( $aTxt ) )
            {
                $i = 0;
                for ( ; $i < count( $aTxt ); ++$i )
                {
                    $this->y2texts[] = $aTxt[$i];
                }
            }
            else
            {
                $this->y2texts[] = $aTxt;
            }
        }
        else
        {
            if ( is_array( $aTxt ) )
            {
                $i = 0;
                for ( ; $i < count( $aTxt ); ++$i )
                {
                    $this->texts[] = $aTxt[$i];
                }
            }
            else
            {
                $this->texts[] = $aTxt;
            }
        }
    }

    public function AddLine( $aLine, $aToY2 = FALSE )
    {
        if ( $aLine == NULL )
        {
            ( 25015 );
        }
        if ( $aToY2 )
        {
            if ( is_array( $aLine ) )
            {
                $i = 0;
                for ( ; $i < count( $aLine ); ++$i )
                {
                    $this->y2lines[] = $aLine[$i];
                }
            }
            else
            {
                $this->y2lines[] = $aLine;
            }
        }
        else
        {
            if ( is_array( $aLine ) )
            {
                $i = 0;
                for ( ; $i < count( $aLine ); ++$i )
                {
                    $this->lines[] = $aLine[$i];
                }
            }
            else
            {
                $this->lines[] = $aLine;
            }
        }
    }

    public function AddBand( $aBand, $aToY2 = FALSE )
    {
        if ( $aBand == NULL )
        {
            ( 25016 );
        }
        if ( $aToY2 )
        {
            if ( is_array( $aBand ) )
            {
                $i = 0;
                for ( ; $i < count( $aBand ); ++$i )
                {
                    $this->y2bands[] = $aBand[$i];
                }
            }
            else
            {
                $this->y2bands[] = $aBand;
            }
        }
        else
        {
            if ( is_array( $aBand ) )
            {
                $i = 0;
                for ( ; $i < count( $aBand ); ++$i )
                {
                    $this->bands[] = $aBand[$i];
                }
            }
            else
            {
                $this->bands[] = $aBand;
            }
        }
    }

    public function SetBackgroundGradient( $aFrom = "navy", $aTo = "silver", $aGradType = 2, $aStyle = BGRAD_FRAME )
    {
        $this->bkg_gradtype = $aGradType;
        $this->bkg_gradstyle = $aStyle;
        $this->bkg_gradfrom = $aFrom;
        $this->bkg_gradto = $aTo;
    }

    public function SetBackgroundCFlag( $aName, $aBgType = BGIMG_FILLPLOT, $aMix = 100 )
    {
        $this->background_cflag = $aName;
        $this->background_cflag_type = $aBgType;
        $this->background_cflag_mix = $aMix;
    }

    public function SetBackgroundCountryFlag( $aName, $aBgType = BGIMG_FILLPLOT, $aMix = 100 )
    {
        $this->background_cflag = $aName;
        $this->background_cflag_type = $aBgType;
        $this->background_cflag_mix = $aMix;
    }

    public function SetBackgroundImage( $aFileName, $aBgType = BGIMG_FILLPLOT, $aImgFormat = "auto" )
    {
        if ( USE_TRUECOLOR )
        {
            ( 25017 );
        }
        if ( $aImgFormat == "auto" )
        {
            $e = explode( ".", $aFileName );
            if ( $e )
            {
                ( 25018, $aFileName );
            }
            $valid_formats = array( "png", "jpg", "gif" );
            $aImgFormat = strtolower( $e[count( $e ) - 1] );
            if ( $aImgFormat == "jpeg" )
            {
                $aImgFormat = "jpg";
            }
            else if ( in_array( $aImgFormat, $valid_formats ) )
            {
                ( 25019, $aImgFormat );
            }
        }
        $this->background_image = $aFileName;
        $this->background_image_type = $aBgType;
        $this->background_image_format = $aImgFormat;
    }

    public function SetBackgroundImageMix( $aMix )
    {
        $this->background_image_mix = $aMix;
    }

    public function AdjBackgroundImage( $aBright, $aContr = 0, $aSat = 0 )
    {
        $this->background_image_bright = $aBright;
        $this->background_image_contr = $aContr;
        $this->background_image_sat = $aSat;
    }

    public function AdjImage( $aBright, $aContr = 0, $aSat = 0 )
    {
        $this->image_bright = $aBright;
        $this->image_contr = $aContr;
        $this->image_sat = $aSat;
    }

    public function SetAxisStyle( $aStyle )
    {
        $this->iAxisStyle = $aStyle;
    }

    public function SetBox( $aDrawPlotFrame = TRUE, $aPlotFrameColor = array( 0, 0, 0 ), $aPlotFrameWeight = 1 )
    {
        $this->boxed = $aDrawPlotFrame;
        $this->box_weight = $aPlotFrameWeight;
        $this->box_color = $aPlotFrameColor;
    }

    public function SetColor( $aColor )
    {
        $this->plotarea_color = $aColor;
    }

    public function SetMarginColor( $aColor )
    {
        $this->margin_color = $aColor;
    }

    public function SetFrame( $aDrawImgFrame = TRUE, $aImgFrameColor = array( 0, 0, 0 ), $aImgFrameWeight = 1 )
    {
        $this->doframe = $aDrawImgFrame;
        $this->frame_color = $aImgFrameColor;
        $this->frame_weight = $aImgFrameWeight;
    }

    public function SetFrameBevel( $aDepth = 3, $aBorder = FALSE, $aBorderColor = "black", $aColor1 = "white@0.4", $aColor2 = "darkgray@0.4", $aFlg = TRUE )
    {
        $this->framebevel = $aFlg;
        $this->framebeveldepth = $aDepth;
        $this->framebevelborder = $aBorder;
        $this->framebevelbordercolor = $aBorderColor;
        $this->framebevelcolor1 = $aColor1;
        $this->framebevelcolor2 = $aColor2;
        $this->doshadow = FALSE;
    }

    public function SetShadow( $aShowShadow = TRUE, $aShadowWidth = 5, $aShadowColor = array( 102, 102, 102 ) )
    {
        $this->doshadow = $aShowShadow;
        $this->shadow_color = $aShadowColor;
        $this->shadow_width = $aShadowWidth;
        $this->footer += "iBottomMargin";
        $this->footer += "iRightMargin";
    }

    public function SetScale( $aAxisType, $aYMin = 1, $aYMax = 1, $aXMin = 1, $aXMax = 1 )
    {
        $this->axtype = $aAxisType;
        if ( $aYMax < $aYMin || $aXMax < $aXMin )
        {
            ( 25020 );
        }
        $yt = substr( $aAxisType, -3, 3 );
        if ( $yt == "lin" )
        {
            $this->yscale = new LinearScale( $aYMin, $aYMax );
        }
        else if ( $yt == "int" )
        {
            $this->yscale = new LinearScale( $aYMin, $aYMax );
            $this->yscale->SetIntScale( );
        }
        else if ( $yt == "log" )
        {
            $this->yscale = new LogScale( $aYMin, $aYMax );
        }
        else
        {
            ( 25021, $aAxisType );
        }
        $xt = substr( $aAxisType, 0, 3 );
        if ( $xt == "lin" || $xt == "tex" )
        {
            $this->xscale = new LinearScale( $aXMin, $aXMax, "x" );
            $this->xscale->textscale = $xt == "tex";
        }
        else if ( $xt == "int" )
        {
            $this->xscale = new LinearScale( $aXMin, $aXMax, "x" );
            $this->xscale->SetIntScale( );
        }
        else if ( $xt == "dat" )
        {
            $this->xscale = new DateScale( $aXMin, $aXMax, "x" );
        }
        else if ( $xt == "log" )
        {
            $this->xscale = new LogScale( $aXMin, $aXMax, "x" );
        }
        else
        {
            ( 25022, $aAxisType );
        }
        $this->xaxis = new Axis( $this->img, $this->xscale );
        $this->yaxis = new Axis( $this->img, $this->yscale );
        $this->xgrid = new Grid( $this->xaxis );
        $this->ygrid = new Grid( $this->yaxis );
        $this->ygrid->Show( );
    }

    public function SetY2Scale( $aAxisType = "lin", $aY2Min = 1, $aY2Max = 1 )
    {
        if ( $aAxisType == "lin" )
        {
            $this->y2scale = new LinearScale( $aY2Min, $aY2Max );
        }
        else if ( $aAxisType == "int" )
        {
            $this->y2scale = new LinearScale( $aY2Min, $aY2Max );
            $this->y2scale->SetIntScale( );
        }
        else if ( $aAxisType == "log" )
        {
            $this->y2scale = new LogScale( $aY2Min, $aY2Max );
        }
        else
        {
            ( 25023, $aAxisType );
        }
        $this->y2axis = new Axis( $this->img, $this->y2scale );
        $this->y2axis->scale->ticks->SetDirection( SIDE_LEFT );
        $this->y2axis->SetLabelSide( SIDE_RIGHT );
        $this->y2axis->SetPos( "max" );
        $this->y2axis->SetTitleSide( SIDE_RIGHT );
        $this->y2grid = new Grid( $this->y2axis );
    }

    public function SetYDeltaDist( $aDist )
    {
        $this->iYAxisDeltaPos = $aDist;
    }

    public function SetYScale( $aN, $aAxisType = "lin", $aYMin = 1, $aYMax = 1 )
    {
        if ( $aAxisType == "lin" )
        {
            $this->ynscale[$aN] = new LinearScale( $aYMin, $aYMax );
        }
        else if ( $aAxisType == "int" )
        {
            $this->ynscale[$aN] = new LinearScale( $aYMin, $aYMax );
            $this->ynscale[$aN]->SetIntScale( );
        }
        else if ( $aAxisType == "log" )
        {
            $this->ynscale[$aN] = new LogScale( $aYMin, $aYMax );
        }
        else
        {
            ( 25024, $aAxisType );
        }
        $this->ynaxis[$aN] = new Axis( $this->img, $this->ynscale[$aN] );
        $this->ynaxis[$aN]->scale->ticks->SetDirection( SIDE_LEFT );
        $this->ynaxis[$aN]->SetLabelSide( SIDE_RIGHT );
    }

    public function SetTickDensity( $aYDensity = TICKD_NORMAL, $aXDensity = TICKD_NORMAL )
    {
        $this->xtick_factor = 30;
        $this->ytick_factor = 25;
        switch ( $aYDensity )
        {
            case TICKD_DENSE :
                $this->ytick_factor = 12;
                break;
            case TICKD_NORMAL :
                $this->ytick_factor = 25;
                break;
            case TICKD_SPARSE :
                $this->ytick_factor = 40;
                break;
            case TICKD_VERYSPARSE :
                $this->ytick_factor = 100;
                break;
            default :
                ( 25025, $densy );
        }
        switch ( $aXDensity )
        {
            case TICKD_DENSE :
                $this->xtick_factor = 15;
                return;
            case TICKD_NORMAL :
                $this->xtick_factor = 30;
                return;
            case TICKD_SPARSE :
                $this->xtick_factor = 45;
                return;
            case TICKD_VERYSPARSE :
                $this->xtick_factor = 60;
                return;
        }
        ( 25025, $densx );
    }

    public function GetCSIMareas( )
    {
        if ( $this->iHasStroked )
        {
            $this->Stroke( _CSIM_SPECIALFILE );
        }
        $csim = $this->title->GetCSIMAreas( );
        $csim .= $this->subtitle->GetCSIMAreas( );
        $csim .= $this->subsubtitle->GetCSIMAreas( );
        $csim .= $this->legend->GetCSIMAreas( );
        if ( $this->y2axis != NULL )
        {
            $csim .= $this->y2axis->title->GetCSIMAreas( );
        }
        if ( $this->texts != NULL )
        {
            $n = count( $this->texts );
            $i = 0;
            for ( ; $i < $n; ++$i )
            {
                $csim .= $this->texts[$i]->GetCSIMAreas( );
            }
        }
        if ( !( $this->y2texts != NULL ) || !( $this->y2scale != NULL ) )
        {
            $n = count( $this->y2texts );
            $i = 0;
            for ( ; $i < $n; ++$i )
            {
                $csim .= $this->y2texts[$i]->GetCSIMAreas( );
            }
        }
        if ( $this->yaxis != NULL && $this->xaxis != NULL )
        {
            $csim .= $this->yaxis->title->GetCSIMAreas( );
            $csim .= $this->xaxis->title->GetCSIMAreas( );
        }
        $n = count( $this->plots );
        $i = 0;
        for ( ; $i < $n; ++$i )
        {
            $csim .= $this->plots[$i]->GetCSIMareas( );
        }
        $n = count( $this->y2plots );
        $i = 0;
        for ( ; $i < $n; ++$i )
        {
            $csim .= $this->y2plots[$i]->GetCSIMareas( );
        }
        $n = count( $this->ynaxis );
        $i = 0;
        for ( ; $i < $n; ++$i )
        {
            $m = count( $this->ynplots[$i] );
            $j = 0;
            for ( ; $j < $m; ++$j )
            {
                $csim .= $this->ynplots[$i][$j]->GetCSIMareas( );
            }
        }
        $n = count( $this->iTables );
        $i = 0;
        for ( ; $i < $n; ++$i )
        {
            $csim .= $this->iTables[$i]->GetCSIMareas( );
        }
        return $csim;
    }

    public function GetHTMLImageMap( $aMapName )
    {
        $im = "<map name=\"".$aMapName."\" id=\"{$aMapName}\" >\n";
        $im .= $this->GetCSIMareas( );
        $im .= "</map>";
        return $im;
    }

    public function CheckCSIMCache( $aCacheName, $aTimeOut = 60 )
    {
        global $_SERVER;
        if ( $aCacheName == "auto" )
        {
            $aCacheName = basename( $_SERVER['PHP_SELF'] );
        }
        $urlarg = $this->GetURLArguments( );
        $this->csimcachename = CSIMCACHE_DIR.$aCacheName.$urlarg;
        $this->csimcachetimeout = $aTimeOut;
        if ( $this->csimcachename != "" )
        {
            $dir = dirname( $this->csimcachename );
            $base = basename( $this->csimcachename );
            $base = strtok( $base, "." );
            $suffix = strtok( "." );
            $basecsim = $dir."/".$base."?".$urlarg."_csim_.html";
            $baseimg = $dir."/".$base."?".$urlarg.".".$this->img->img_format;
            $timedout = FALSE;
            if ( file_exists( $basecsim ) && file_exists( $baseimg ) )
            {
                $diff = time( ) - filemtime( $basecsim );
                if ( 0 < $this->csimcachetimeout && $this->csimcachetimeout * 60 < $diff )
                {
                    $timedout = TRUE;
                    @unlink( $basecsim );
                    @unlink( $baseimg );
                    return FALSE;
                }
                if ( $fh = @fopen( $basecsim, "r" ) )
                {
                    fpassthru( $fh );
                    return TRUE;
                }
                ( 25027, $basecsim );
            }
        }
        return FALSE;
    }

    public function GetURLArguments( )
    {
        $urlarg = _CSIM_DISPLAY."=1";
        reset( &$_GET );
        $value = each( &$_GET )[1];
        $key = each( &$_GET )[0];
        while ( each( &$_GET ) )
        {
            if ( is_array( $value ) )
            {
                $n = count( $value );
                $i = 0;
                for ( ; do
 {
 $i < $n; do
 {
 ++$i, } while ( 1 ) )
                    {
                        $urlarg .= "&".$key."%5B%5D=".urlencode( $value[$i] );
                    } while ( 1 );
                }
                $urlarg .= "&".$key."=".urlencode( $value );
            }
        }
        reset( &$_POST );
        $value = each( &$_POST )[1];
        $key = each( &$_POST )[0];
        while ( each( &$_POST ) )
        {
            if ( is_array( $value ) )
            {
                $n = count( $value );
                $i = 0;
                for ( ; do
 {
 $i < $n; do
 {
 ++$i, } while ( 1 ) )
                    {
                        $urlarg .= "&".$key."%5B%5D=".urlencode( $value[$i] );
                    } while ( 1 );
                }
                $urlarg .= "&".$key."=".urlencode( $value );
            }
        }
        return $urlarg;
    }

    public function StrokeCSIM( $aScriptName = "auto", $aCSIMName = "", $aBorder = 0 )
    {
        if ( $aCSIMName == "" )
        {
            srand( ( double ) * 1000000 );
            $r = rand( 0, 100000 );
            $aCSIMName = "__mapname".$r."__";
        }
        if ( $aScriptName == "auto" )
        {
            $aScriptName = basename( $_SERVER['PHP_SELF'] );
        }
        $urlarg = $this->GetURLArguments( );
        if ( empty( $_GET[_CSIM_DISPLAY] ) )
        {
            if ( $this->csimcachename != "" )
            {
                $dir = dirname( $this->csimcachename );
                $base = basename( $this->csimcachename );
                $base = strtok( $base, "." );
                $suffix = strtok( "." );
                $basecsim = $dir."/".$base."?".$urlarg."_csim_.html";
                $baseimg = $base."?".$urlarg.".".$this->img->img_format;
                if ( file_exists( $dir ) && !is_writeable( $dir ) )
                {
                    ( 25028, $dir );
                }
                $this->cache->MakeDirs( $dir );
                $this->Stroke( CSIMCACHE_DIR.$baseimg );
                $tmp = str_replace( "?", "%3f", $baseimg );
                $htmlwrap = $this->GetHTMLImageMap( $aCSIMName )."\n<img src=\"".CSIMCACHE_HTTP_DIR.$tmp."\" ismap=\"ismap\" usemap=\"#".$aCSIMName."\" border=\"".$aBorder."\" width=\"".$this->img->width."\" height=\"".$this->img->height."\" alt=\"\" />\n";
                if ( $fh = @fopen( $basecsim, "w" ) )
                {
                    fwrite( $fh, $htmlwrap );
                    fclose( $fh );
                    echo $htmlwrap;
                }
                else
                {
                    ( 25029, $basecsim );
                }
            }
            else
            {
                if ( $aScriptName == "" )
                {
                    ( 25030 );
                }
                echo $this->GetHTMLImageMap( $aCSIMName );
                echo "<img src=\"".$aScriptName."?".$urlarg."\" ismap=\"ismap\" usemap=\"#".$aCSIMName."\" border=\"".$aBorder."\" width=\"".$this->img->width."\" height=\"".$this->img->height."\" alt=\"\" />\n";
            }
        }
        else
        {
            $this->Stroke( );
        }
    }

    public function GetTextsYMinMax( $aY2 = FALSE )
    {
        if ( $aY2 )
        {
            $txts = $this->y2texts;
        }
        else
        {
            $txts = $this->texts;
        }
        $n = count( $txts );
        $min = NULL;
        $max = NULL;
        $i = 0;
        for ( ; $i < $n; ++$i )
        {
            if ( !( !( $txts[$i]->iScalePosY !== NULL ) || !( $txts[$i]->iScalePosX !== NULL ) ) )
            {
                continue;
            }
            else if ( $min === NULL )
            {
                $min = $max = $txts[$i]->iScalePosY;
            }
            else
            {
                $min = min( $min, $txts[$i]->iScalePosY );
                $max = max( $max, $txts[$i]->iScalePosY );
            }
        }
        if ( $min !== NULL )
        {
            return array( $min, $max );
        }
    }

    public function GetTextsXMinMax( $aY2 = FALSE )
    {
        if ( $aY2 )
        {
            $txts = $this->y2texts;
        }
        else
        {
            $txts = $this->texts;
        }
        $n = count( $txts );
        $min = NULL;
        $max = NULL;
        $i = 0;
        for ( ; $i < $n; ++$i )
        {
            if ( !( !( $txts[$i]->iScalePosY !== NULL ) || !( $txts[$i]->iScalePosX !== NULL ) ) )
            {
                continue;
            }
            else if ( $min === NULL )
            {
                $min = $max = $txts[$i]->iScalePosX;
            }
            else
            {
                $min = min( $min, $txts[$i]->iScalePosX );
                $max = max( $max, $txts[$i]->iScalePosX );
            }
        }
        if ( $min !== NULL )
        {
            return array( $min, $max );
        }
    }

    public function GetXMinMax( )
    {
        $ymin = $this->plots[0]->Min( )[1];
        $min = $this->plots[0]->Min( )[0];
        $ymax = $this->plots[0]->Max( )[1];
        $max = $this->plots[0]->Max( )[0];
        foreach ( $this->plots as $p )
        {
            $ymin = $p->Min( )[1];
            $xmin = $p->Min( )[0];
            $ymax = $p->Max( )[1];
            $xmax = $p->Max( )[0];
            $min = min( $xmin, $min );
            $max = max( $xmax, $max );
        }
        if ( $this->y2axis != NULL )
        {
            foreach ( $this->y2plots as $p )
            {
                $ymin = $p->Min( )[1];
                $xmin = $p->Min( )[0];
                $ymax = $p->Max( )[1];
                $xmax = $p->Max( )[0];
                $min = min( $xmin, $min );
                $max = max( $xmax, $max );
            }
        }
        $n = count( $this->ynaxis );
        $i = 0;
        for ( ; $i < $n; ++$i )
        {
            if ( $this->ynaxis[$i] != NULL )
            {
                foreach ( $this->ynplots[$i] as $p )
                {
                    $ymin = $p->Min( )[1];
                    $xmin = $p->Min( )[0];
                    $ymax = $p->Max( )[1];
                    $xmax = $p->Max( )[0];
                    $min = min( $xmin, $min );
                    $max = max( $xmax, $max );
                }
            }
        }
        return array( $min, $max );
    }

    public function AdjustMarginsForTitles( )
    {
        $totrequired = ( $this->title->t != "" ? $this->title->GetTextHeight( $this->img ) + $this->title->margin + 5 : 0 ) + ( $this->subtitle->t != "" ? $this->subtitle->GetTextHeight( $this->img ) + $this->subtitle->margin + 5 : 0 ) + ( $this->subsubtitle->t != "" ? $this->subsubtitle->GetTextHeight( $this->img ) + $this->subsubtitle->margin + 5 : 0 );
        $btotrequired = 0;
        if ( $this->xaxis != NULL && !$this->xaxis->hide && !$this->xaxis->hide_labels )
        {
            if ( $this->xaxis->title->t != "" )
            {
                if ( $this->img->a == 90 )
                {
                    $btotrequired = $this->yaxis->title->GetTextHeight( $this->img ) + 5;
                }
                else
                {
                    $btotrequired = $this->xaxis->title->GetTextHeight( $this->img ) + 5;
                }
            }
            else
            {
                $btotrequired = 0;
            }
            if ( $this->img->a == 90 )
            {
                $this->yaxis( $this->yaxis->font_family, $this->yaxis->font_style, $this->yaxis->font_size );
                $lh = $this->yaxis( "Mg", $this->yaxis->label_angle );
            }
            else
            {
                $this->xaxis( $this->xaxis->font_family, $this->xaxis->font_style, $this->xaxis->font_size );
                $lh = $this->xaxis( "Mg", $this->xaxis->label_angle );
            }
            $btotrequired += $lh + 5;
        }
        if ( $this->img->a == 90 )
        {
            if ( $this->img->top_margin < $totrequired )
            {
                $this->img->bottom_margin( $this->img->left_margin, $this->img->right_margin, $totrequired, $this->img->bottom_margin );
            }
            if ( $this->img->bottom_margin < $btotrequired )
            {
                $this->img->top_margin( $this->img->left_margin, $this->img->right_margin, $this->img->top_margin, $btotrequired );
            }
        }
    }

    public function Stroke( $aStrokeFileName = "" )
    {
        if ( empty( $this->yscale ) )
        {
            ( 25031 );
        }
        $this->AdjustMarginsForTitles( );
        if ( $this->yscale )
        {
            $this->yscale->InitConstants( $this->img );
        }
        if ( $this->xscale )
        {
            $this->xscale->InitConstants( $this->img );
        }
        if ( $this->y2scale )
        {
            $this->y2scale->InitConstants( $this->img );
        }
        $n = count( $this->ynscale );
        $i = 0;
        for ( ; $i < $n; ++$i )
        {
            if ( $this->ynscale[$i] )
            {
                $this->ynscale[$i]->InitConstants( $this->img );
            }
        }
        $_csim = $aStrokeFileName === _CSIM_SPECIALFILE;
        $this->iHasStroked = TRUE;
        $i = 0;
        for ( ; $i < count( $this->plots ); ++$i )
        {
            $this->plots[$i]->PreStrokeAdjust( $this );
            $this->plots[$i]->DoLegend( $this );
        }
        if ( $this->y2scale != NULL )
        {
            $i = 0;
            for ( ; $i < count( $this->y2plots ); ++$i )
            {
                $this->y2plots[$i]->PreStrokeAdjust( $this );
                $this->y2plots[$i]->DoLegend( $this );
            }
        }
        $n = count( $this->ynaxis );
        $i = 0;
        for ( ; $i < $n; ++$i )
        {
            if ( $this->ynplots == NULL || $this->ynplots[$i] == NULL )
            {
                ( 25032, $i );
            }
            $m = count( $this->ynplots[$i] );
            $j = 0;
            for ( ; $j < $m; ++$j )
            {
                $this->ynplots[$i][$j]->PreStrokeAdjust( $this );
                $this->ynplots[$i][$j]->DoLegend( $this );
            }
        }
        if ( $this->yscale->IsSpecified( ) || count( $this->plots ) == 0 || $this->y2scale != NULL && !$this->y2scale->IsSpecified( ) && count( $this->y2plots ) == 0 )
        {
            ( 25026 );
        }
        if ( !$this->xscale->IsSpecified( ) && count( $this->plots ) == 0 && count( $this->y2plots ) == 0 )
        {
            ( 25034 );
        }
        if ( !$this->yscale->IsSpecified( ) && 0 < count( $this->plots ) )
        {
            $max = $this->plots( $this->plots )[1];
            $min = $this->plots( $this->plots )[0];
            $lres = $this->lines( $this->lines );
            if ( is_array( $lres ) )
            {
                $linmax = $lres[1];
                $linmin = $lres[0];
                $min = min( $min, $linmin );
                $max = max( $max, $linmax );
            }
            $tres = $this->GetTextsYMinMax( );
            if ( is_array( $tres ) )
            {
                $tmax = $tres[1];
                $tmin = $tres[0];
                $min = min( $min, $tmin );
                $max = max( $max, $tmax );
            }
            $this->img->plotheight( $this->img, $min, $max, $this->img->plotheight / $this->ytick_factor );
        }
        else if ( $this->yscale->IsSpecified( ) && ( $this->yscale->auto_ticks || !$this->yscale->ticks->IsSpecified( ) ) )
        {
            $min = $this->yscale->scale[0];
            $max = $this->yscale->scale[1];
            $this->yscale( $this->img, $min, $max, $this->img->plotheight / $this->ytick_factor, $this->yscale->auto_ticks );
        }
        if ( $this->y2scale != NULL )
        {
            if ( !$this->y2scale->IsSpecified( ) && 0 < count( $this->y2plots ) )
            {
                $max = $this->y2plots( $this->y2plots )[1];
                $min = $this->y2plots( $this->y2plots )[0];
                $lres = $this->y2lines( $this->y2lines );
                if ( is_array( $lres ) )
                {
                    $linmax = $lres[1];
                    $linmin = $lres[0];
                    $min = min( $min, $linmin );
                    $max = max( $max, $linmax );
                }
                $tres = $this->GetTextsYMinMax( TRUE );
                if ( is_array( $tres ) )
                {
                    $tmax = $tres[1];
                    $tmin = $tres[0];
                    $min = min( $min, $tmin );
                    $max = max( $max, $tmax );
                }
                $this->img->plotheight( $this->img, $min, $max, $this->img->plotheight / $this->ytick_factor );
            }
            else if ( $this->y2scale->IsSpecified( ) && ( $this->y2scale->auto_ticks || !$this->y2scale->ticks->IsSpecified( ) ) )
            {
                $min = $this->y2scale->scale[0];
                $max = $this->y2scale->scale[1];
                $this->y2scale( $this->img, $min, $max, $this->img->plotheight / $this->ytick_factor, $this->y2scale->auto_ticks );
            }
        }
        $n = count( $this->ynaxis );
        $i = 0;
        for ( ; $i < $n; ++$i )
        {
            if ( !( $this->ynscale[$i] != NULL ) )
            {
                continue;
            }
            else if ( !$this->ynscale[$i]->IsSpecified( ) && 0 < count( $this->ynplots[$i] ) )
            {
                $max = $this->ynplots[$i]( $this->ynplots[$i] )[1];
                $min = $this->ynplots[$i]( $this->ynplots[$i] )[0];
                $this->img->plotheight( $this->img, $min, $max, $this->img->plotheight / $this->ytick_factor );
            }
            else if ( !$this->ynscale[$i]->IsSpecified( ) || !$this->ynscale[$i]->auto_ticks && $this->ynscale[$i]->ticks->IsSpecified( ) )
            {
                $min = $this->ynscale[$i]->scale[0];
                $max = $this->ynscale[$i]->scale[1];
                $this->ynscale[$i]( $this->img, $min, $max, $this->img->plotheight / $this->ytick_factor, $this->ynscale[$i]->auto_ticks );
            }
        }
        if ( $this->xscale->IsSpecified( ) )
        {
            if ( substr( $this->axtype, 0, 4 ) == "text" )
            {
                $max = 0;
                $n = count( $this->plots );
                $i = 0;
                for ( ; $i < $n; ++$i )
                {
                    $p = $this->plots[$i];
                    if ( class_exists( "BarPlot", FALSE ) )
                    {
                        $cl = strtolower( get_class( $p ) );
                        if ( !class_exists( "BarPlot", FALSE ) || $p instanceof BarPlot || empty( $p->barcenter ) )
                        {
                            $max = max( $max, $p->numpoints - 1 );
                        }
                        else
                        {
                            $max = max( $max, $p->numpoints );
                        }
                    }
                    else if ( empty( $p->barcenter ) )
                    {
                        $max = max( $max, $p->numpoints - 1 );
                    }
                    else
                    {
                        $max = max( $max, $p->numpoints );
                    }
                }
                $min = 0;
                if ( $this->y2axis != NULL )
                {
                    foreach ( $this->y2plots as $p )
                    {
                        $max = max( $max, $p->numpoints - 1 );
                    }
                }
                $n = count( $this->ynaxis );
                $i = 0;
                for ( ; $i < $n; ++$i )
                {
                    if ( $this->ynaxis[$i] != NULL )
                    {
                        foreach ( $this->ynplots[$i] as $p )
                        {
                            $max = max( $max, $p->numpoints - 1 );
                        }
                    }
                }
                $this->xscale->Update( $this->img, $min, $max );
                $this->xaxis( $this->xaxis->tick_step, 1 );
                $this->xscale->ticks->SupressMinorTickMarks( );
            }
            else
            {
                $max = $this->GetXMinMax( )[1];
                $min = $this->GetXMinMax( )[0];
                $lres = $this->lines( $this->lines );
                if ( $lres )
                {
                    $linmax = $lres[1];
                    $linmin = $lres[0];
                    $min = min( $min, $linmin );
                    $max = max( $max, $linmax );
                }
                $lres = $this->y2lines( $this->y2lines );
                if ( $lres )
                {
                    $linmax = $lres[1];
                    $linmin = $lres[0];
                    $min = min( $min, $linmin );
                    $max = max( $max, $linmax );
                }
                $tres = $this->GetTextsXMinMax( );
                if ( $tres )
                {
                    $tmax = $tres[1];
                    $tmin = $tres[0];
                    $min = min( $min, $tmin );
                    $max = max( $max, $tmax );
                }
                $tres = $this->GetTextsXMinMax( TRUE );
                if ( $tres )
                {
                    $tmax = $tres[1];
                    $tmin = $tres[0];
                    $min = min( $min, $tmin );
                    $max = max( $max, $tmax );
                }
                $this->img->plotwidth( $this->img, $min, $max, round( $this->img->plotwidth / $this->xtick_factor ) );
            }
            if ( !is_numeric( $this->yaxis->pos ) && !is_string( $this->yaxis->pos ) )
            {
                $this->yaxis->SetPos( $this->xscale->GetMinVal( ) );
            }
            if ( $this->y2axis != NULL )
            {
                if ( !is_numeric( $this->y2axis->pos ) && !is_string( $this->y2axis->pos ) )
                {
                    $this->y2axis->SetPos( $this->xscale->GetMaxVal( ) );
                }
                $this->y2axis->SetTitleSide( SIDE_RIGHT );
            }
            $n = count( $this->ynaxis );
            $nY2adj = $this->y2axis != NULL ? $this->iYAxisDeltaPos : 0;
            $i = 0;
            for ( ; $i < $n; ++$i )
            {
                if ( $this->ynaxis[$i] != NULL )
                {
                    if ( !is_numeric( $this->ynaxis[$i]->pos ) && !is_string( $this->ynaxis[$i]->pos ) )
                    {
                        $this->ynaxis[$i]->SetPos( $this->xscale->GetMaxVal( ) );
                        $this->ynaxis[$i]->SetPosAbsDelta( $i * $this->iYAxisDeltaPos + $nY2adj );
                    }
                    $this->ynaxis[$i]->SetTitleSide( SIDE_RIGHT );
                }
            }
        }
        else
        {
            if ( !$this->xscale->IsSpecified( ) || !$this->xscale->auto_ticks && $this->xscale->ticks->IsSpecified( ) )
            {
                $min = $this->xscale->scale[0];
                $max = $this->xscale->scale[1];
                $this->img->plotwidth( $this->img, $min, $max, round( $this->img->plotwidth / $this->xtick_factor ), FALSE );
            }
            if ( $this->y2axis != NULL )
            {
                if ( !is_numeric( $this->y2axis->pos ) && !is_string( $this->y2axis->pos ) )
                {
                    $this->y2axis->SetPos( $this->xscale->GetMaxVal( ) );
                }
            }
            $this->y2axis->SetTitleSide( SIDE_RIGHT );
        }
        if ( ( $this->yaxis->pos == $this->xscale->GetMinVal( ) || is_string( $this->yaxis->pos ) && $this->yaxis->pos == "min" ) && !is_numeric( $this->xaxis->pos ) && $this->yscale->GetMinVal( ) < 0 && substr( $this->axtype, 0, 4 ) != "text" && $this->xaxis->pos != "min" )
        {
            $this->xscale->ticks->SupressFirst( );
            if ( $this->y2axis != NULL )
            {
                $this->xscale->ticks->SupressLast( );
            }
        }
        else if ( !is_numeric( $this->yaxis->pos ) && $this->yaxis->pos == "max" )
        {
            $this->xscale->ticks->SupressLast( );
        }
        if ( $_csim )
        {
            $this->StrokePlotArea( );
            if ( $this->iIconDepth == DEPTH_BACK )
            {
                $this->StrokeIcons( );
            }
        }
        $this->StrokeAxis( FALSE );
        if ( !( $this->bands != NULL ) || $_csim )
        {
            $i = 0;
            for ( ; $i < count( $this->bands ); ++$i )
            {
                if ( $this->bands[$i]->depth == DEPTH_BACK )
                {
                    $this->bands[$i]->Stroke( $this->img, $this->xscale, $this->yscale );
                }
            }
        }
        if ( !( $this->y2bands != NULL ) || !( $this->y2scale != NULL ) || $_csim )
        {
            $i = 0;
            for ( ; $i < count( $this->y2bands ); ++$i )
            {
                if ( $this->y2bands[$i]->depth == DEPTH_BACK )
                {
                    $this->y2bands[$i]->Stroke( $this->img, $this->xscale, $this->y2scale );
                }
            }
        }
        if ( $this->grid_depth == DEPTH_BACK && !$_csim )
        {
            $this->ygrid->Stroke( );
            $this->xgrid->Stroke( );
        }
        if ( $this->y2axis != NULL && !$_csim )
        {
            $this->y2axis->Stroke( $this->xscale );
            $this->y2grid->Stroke( );
        }
        $n = count( $this->ynaxis );
        $i = 0;
        for ( ; $i < $n; ++$i )
        {
            $this->ynaxis[$i]->Stroke( $this->xscale );
        }
        $oldoff = $this->xscale->off;
        if ( substr( $this->axtype, 0, 4 ) == "text" )
        {
            if ( -1 < $this->text_scale_abscenteroff )
            {
                $this->xscale += "off";
            }
            else
            {
                $this->xscale += "off";
            }
        }
        if ( $this->iDoClipping )
        {
            $oldimage = $this->img->CloneCanvasH( );
        }
        if ( $this->y2orderback )
        {
            $i = 0;
            for ( ; $i < count( $this->plots ); ++$i )
            {
                $this->plots[$i]->Stroke( $this->img, $this->xscale, $this->yscale );
                $this->plots[$i]->StrokeMargin( $this->img );
            }
        }
        if ( $this->y2scale != NULL )
        {
            $i = 0;
            for ( ; $i < count( $this->y2plots ); ++$i )
            {
                $this->y2plots[$i]->Stroke( $this->img, $this->xscale, $this->y2scale );
            }
        }
        if ( $this->y2orderback )
        {
            $i = 0;
            for ( ; $i < count( $this->plots ); ++$i )
            {
                $this->plots[$i]->Stroke( $this->img, $this->xscale, $this->yscale );
                $this->plots[$i]->StrokeMargin( $this->img );
            }
        }
        $n = count( $this->ynaxis );
        $i = 0;
        for ( ; $i < $n; ++$i )
        {
            $m = count( $this->ynplots[$i] );
            $j = 0;
            for ( ; $j < $m; ++$j )
            {
                $this->ynscale( $this->img, $this->xscale, $this->ynscale[$i] );
                $this->ynplots[$i][$j]->StrokeMargin( $this->img );
            }
        }
        if ( $this->iIconDepth == DEPTH_FRONT )
        {
            $this->StrokeIcons( );
        }
        if ( $this->iDoClipping )
        {
            if ( $this->img->a == 0 )
            {
                $this->img( $oldimage, $this->img->img, $this->img->left_margin, $this->img->top_margin, $this->img->left_margin, $this->img->top_margin, $this->img->plotwidth + 1, $this->img->plotheight );
            }
            else if ( $this->img->a == 90 )
            {
                $adj = ( $this->img->height - $this->img->width ) / 2;
                $this->img( $oldimage, $this->img->img, $this->img->bottom_margin - $adj, $this->img->left_margin + $adj, $this->img->bottom_margin - $adj, $this->img->left_margin + $adj, $this->img->plotheight + 1, $this->img->plotwidth );
            }
            else
            {
                ( 25035, $this->img->a );
            }
            $this->img->Destroy( );
            $this->img->SetCanvasH( $oldimage );
        }
        $this->xscale->off = $oldoff;
        if ( $this->grid_depth == DEPTH_FRONT && !$_csim )
        {
            $this->ygrid->Stroke( );
            $this->xgrid->Stroke( );
        }
        if ( $this->bands != NULL )
        {
            $i = 0;
            for ( ; $i < count( $this->bands ); ++$i )
            {
                if ( $this->bands[$i]->depth == DEPTH_FRONT )
                {
                    $this->bands[$i]->Stroke( $this->img, $this->xscale, $this->yscale );
                }
            }
        }
        if ( !( $this->y2bands != NULL ) || !( $this->y2scale != NULL ) )
        {
            $i = 0;
            for ( ; $i < count( $this->y2bands ); ++$i )
            {
                if ( $this->y2bands[$i]->depth == DEPTH_FRONT )
                {
                    $this->y2bands[$i]->Stroke( $this->img, $this->xscale, $this->y2scale );
                }
            }
        }
        if ( $this->lines != NULL )
        {
            $i = 0;
            for ( ; $i < count( $this->lines ); ++$i )
            {
                $this->lines[$i]->Stroke( $this->img, $this->xscale, $this->yscale );
            }
        }
        if ( !( $this->y2lines != NULL ) || !( $this->y2scale != NULL ) )
        {
            $i = 0;
            for ( ; $i < count( $this->y2lines ); ++$i )
            {
                $this->y2lines[$i]->Stroke( $this->img, $this->xscale, $this->y2scale );
            }
        }
        if ( $_csim )
        {
            $this->StrokeAxis( );
        }
        if ( $this->y2scale != NULL && !$_csim )
        {
            $this->y2axis->Stroke( $this->xscale, FALSE );
        }
        if ( $_csim )
        {
            $this->StrokePlotBox( );
        }
        $aa = $this->img->SetAngle( 0 );
        $this->StrokeTitles( );
        $this->footer->Stroke( $this->img );
        $this->legend->Stroke( $this->img );
        $this->img->SetAngle( $aa );
        $this->StrokeTexts( );
        $this->StrokeTables( );
        if ( $_csim )
        {
            $this->img->SetAngle( $aa );
            if ( _JPG_DEBUG )
            {
                $this->DisplayClientSideaImageMapAreas( );
            }
            $this->AdjustSaturationBrightnessContrast( );
            if ( $this->iImgTrans )
            {
                if ( class_exists( "ImgTrans", FALSE ) )
                {
                    require_once( "jpgraph_imgtrans.php" );
                }
                $tform = new ImgTrans( $this->img->img );
                $this->img->img = $this->iImgTransBorder( $this->iImgTransHorizon, $this->iImgTransSkewDist, $this->iImgTransDirection, $this->iImgTransHighQ, $this->iImgTransMinSize, $this->iImgTransFillColor, $this->iImgTransBorder );
            }
            if ( $aStrokeFileName == _IMG_HANDLER )
            {
                return $this->img->img;
            }
            $this->cache->PutAndStream( $this->img, $this->cache_name, $this->inline, $aStrokeFileName );
        }
    }

    public function SetAxisLabelBackground( $aType, $aXFColor = "lightgray", $aXColor = "black", $aYFColor = "lightgray", $aYColor = "black" )
    {
        $this->iAxisLblBgType = $aType;
        $this->iXAxisLblBgFillColor = $aXFColor;
        $this->iXAxisLblBgColor = $aXColor;
        $this->iYAxisLblBgFillColor = $aYFColor;
        $this->iYAxisLblBgColor = $aYColor;
    }

    public function StrokeAxisLabelBackground( )
    {
        $t = $this->iAxisLblBgType;
        if ( $t < 1 )
        {
        }
        else
        {
            if ( $t == 1 || $t == 3 || $t == 5 || $t == 6 )
            {
                $this->img->PushColor( $this->iXAxisLblBgFillColor );
                if ( $t == 1 || $t == 6 )
                {
                    $xl = $this->img->left_margin;
                    $yu = $this->img->height - $this->img->bottom_margin + 1;
                    $xr = $this->img->width - $this->img->right_margin;
                    $yl = $this->img->height - 1 - $this->frame_weight;
                }
                else
                {
                    $xl = $this->frame_weight;
                    $yu = $this->img->height - $this->img->bottom_margin + 1;
                    $xr = $this->img->width - 1 - $this->frame_weight;
                    $yl = $this->img->height - 1 - $this->frame_weight;
                }
                $this->img->FilledRectangle( $xl, $yu, $xr, $yl );
                $this->img->PopColor( );
                if ( $this->iXAxisLblBgColor !== "" )
                {
                    $this->img->PushColor( $this->iXAxisLblBgColor );
                    if ( $t == 1 || $t == 6 )
                    {
                        $this->img->Line( $xl, $yu, $xl, $yl );
                        $this->img->Line( $xr, $yu, $xr, $yl );
                    }
                    else
                    {
                        $xl = $this->img->width - $this->img->right_margin;
                        $this->img->Line( $xl, $yu - 1, $xr, $yu - 1 );
                    }
                    $this->img->PopColor( );
                }
            }
            if ( $t == 2 || $t == 4 || $t == 5 || $t == 6 )
            {
                $this->img->PushColor( $this->iYAxisLblBgFillColor );
                if ( $t == 2 || $t == 6 )
                {
                    $xl = $this->frame_weight;
                    $yu = $this->frame_weight + $this->img->top_margin;
                    $xr = $this->img->left_margin - 1;
                    $yl = $this->img->height - $this->img->bottom_margin + 1;
                }
                else
                {
                    $xl = $this->frame_weight;
                    $yu = $this->frame_weight;
                    $xr = $this->img->left_margin - 1;
                    $yl = $this->img->height - 1 - $this->frame_weight;
                }
                $this->img->FilledRectangle( $xl, $yu, $xr, $yl );
                $this->img->PopColor( );
                if ( $this->iXAxisLblBgColor !== "" )
                {
                    $this->img->PushColor( $this->iXAxisLblBgColor );
                    if ( $t == 2 || $t == 6 )
                    {
                        $this->img->Line( $xl, $yu - 1, $xr, $yu - 1 );
                        $this->img->Line( $xl, $yl - 1, $xr, $yl - 1 );
                    }
                    else
                    {
                        $this->img( $xr + 1, $yu, $xr + 1, $this->img->top_margin );
                    }
                    $this->img->PopColor( );
                }
            }
        }
    }

    public function StrokeAxis( $aStrokeLabels = TRUE )
    {
        if ( $aStrokeLabels )
        {
            $this->StrokeAxisLabelBackground( );
        }
        if ( $this->iAxisStyle != AXSTYLE_SIMPLE )
        {
            switch ( $this->iAxisStyle )
            {
                case AXSTYLE_BOXIN :
                    $toppos = SIDE_DOWN;
                    $bottompos = SIDE_UP;
                    $leftpos = SIDE_RIGHT;
                    $rightpos = SIDE_LEFT;
                    break;
                case AXSTYLE_BOXOUT :
                    $toppos = SIDE_UP;
                    $bottompos = SIDE_DOWN;
                    $leftpos = SIDE_LEFT;
                    $rightpos = SIDE_RIGHT;
                    break;
                case AXSTYLE_YBOXIN :
                    $toppos = FALSE;
                    $bottompos = SIDE_UP;
                    $leftpos = SIDE_RIGHT;
                    $rightpos = SIDE_LEFT;
                    break;
                case AXSTYLE_YBOXOUT :
                    $toppos = FALSE;
                    $bottompos = SIDE_DOWN;
                    $leftpos = SIDE_LEFT;
                    $rightpos = SIDE_RIGHT;
                    break;
                default :
                    ( 25036, $this->iAxisStyle );
            }
            $this->xscale->ticks->SupressFirst( FALSE );
            $this->xaxis->SetPos( "min" );
            $this->xaxis->SetLabelSide( SIDE_DOWN );
            $this->xaxis->scale->ticks->SetSide( $bottompos );
            $this->xaxis->Stroke( $this->yscale, $aStrokeLabels );
            if ( $toppos !== FALSE )
            {
                $this->xaxis = $this->xaxis;
                $this->xaxis->SetPos( "max" );
                $this->xaxis->SetLabelSide( SIDE_UP );
                $this->title->Set( "" );
                $this->xaxis->scale->ticks->SetSide( $toppos );
                $this->xaxis->Stroke( $this->yscale, $aStrokeLabels );
            }
            $this->yaxis->SetPos( "min" );
            $this->yaxis->SetLabelSide( SIDE_LEFT );
            $this->yaxis->scale->ticks->SetSide( $leftpos );
            $this->yaxis->Stroke( $this->xscale, $aStrokeLabels );
            $this->yaxis->SetPos( "max" );
            $this->title->Set( "" );
            $this->yaxis->SetLabelSide( SIDE_RIGHT );
            $this->yaxis->scale->ticks->SetSide( $rightpos );
            $this->yaxis->Stroke( $this->xscale, $aStrokeLabels );
        }
        else
        {
            $this->xaxis->Stroke( $this->yscale, $aStrokeLabels );
            $this->yaxis->Stroke( $this->xscale, $aStrokeLabels );
        }
    }

    public function LoadBkgImage( $aImgFormat = "", $aFile = "", $aImgStr = "" )
    {
        if ( $aImgStr != "" )
        {
            return ( $aImgStr );
        }
        if ( $aFile == "" )
        {
            $aFile = $this->background_image;
        }
        $e = explode( ".", $aFile );
        $ext = strtolower( $e[count( $e ) - 1] );
        if ( $ext == "jpeg" )
        {
            $ext = "jpg";
        }
        if ( trim( $ext ) == "" )
        {
            $ext = "png";
        }
        if ( $aImgFormat == "" )
        {
            $imgtag = $ext;
        }
        else
        {
            $imgtag = $aImgFormat;
        }
        $supported = imagetypes( );
        if ( !( $ext == "jpg" ) || !( $supported & IMG_JPG ) || !( $ext == "gif" ) || !( $supported & IMG_GIF ) || $ext == "png" && !( $supported & IMG_PNG ) )
        {
            ( 25037, $aFile );
        }
        if ( $imgtag == "jpg" || $imgtag == "jpeg" )
        {
            $f = "imagecreatefromjpeg";
            $imgtag = "jpg";
        }
        else
        {
            $f = "imagecreatefrom".$imgtag;
        }
        if ( $imgtag != $ext )
        {
            ( 25038, $aImgFormat, $aFile );
        }
        $img = @$f( $aFile );
        if ( $img )
        {
            ( 25039, $aFile );
        }
        return $img;
    }

    public function StrokeBackgroundGrad( )
    {
        if ( $this->bkg_gradtype < 0 )
        {
        }
        else
        {
            $grad = new Gradient( $this->img );
            if ( $this->bkg_gradstyle == BGRAD_PLOT )
            {
                $xl = $this->img->left_margin;
                $yt = $this->img->top_margin;
                $xr = $xl + $this->img->plotwidth + 1;
                $yb = $yt + $this->img->plotheight;
                $this->bkg_gradtype( $xl, $yt, $xr, $yb, $this->bkg_gradfrom, $this->bkg_gradto, $this->bkg_gradtype );
            }
            else
            {
                $xl = 0;
                $yt = 0;
                $xr = $xl + $this->img->width - 1;
                $yb = $yt + $this->img->height;
                if ( $this->doshadow )
                {
                    $xr -= $this->shadow_width;
                    $yb -= $this->shadow_width;
                }
                if ( $this->doframe )
                {
                    $yt += $this->frame_weight;
                    $yb -= $this->frame_weight;
                    $xl += $this->frame_weight;
                    $xr -= $this->frame_weight;
                }
                $aa = $this->img->SetAngle( 0 );
                $this->bkg_gradtype( $xl, $yt, $xr, $yb, $this->bkg_gradfrom, $this->bkg_gradto, $this->bkg_gradtype );
                $aa = $this->img->SetAngle( $aa );
            }
        }
    }

    public function StrokeFrameBackground( )
    {
        if ( $this->background_image != "" && $this->background_cflag != "" )
        {
            ( 25040 );
        }
        if ( $this->background_image != "" )
        {
            $bkgimg = $this->background_image_format( $this->background_image_format );
            $this->img->_AdjBrightContrast( $bkgimg, $this->background_image_bright, $this->background_image_contr );
            $this->img->_AdjSat( $bkgimg, $this->background_image_sat );
        }
        else if ( $this->background_cflag != "" )
        {
            if ( class_exists( "FlagImages", FALSE ) )
            {
                ( 25041 );
            }
            $fobj = new FlagImages( FLAGSIZE4 );
            $dummy = "";
            $bkgimg = $this->background_cflag( $this->background_cflag, $dummy );
            $this->background_image_mix = $this->background_cflag_mix;
            $this->background_image_type = $this->background_cflag_type;
        }
        else
        {
            return;
        }
        $bw = imagesx( $bkgimg );
        $bh = imagesy( $bkgimg );
        $aa = $this->img->SetAngle( 0 );
        switch ( $this->background_image_type )
        {
            case BGIMG_FILLPLOT :
                $this->FillMarginArea( );
                $this->StrokeFrame( );
                if ( $aa == 90 )
                {
                    $this->img->SetAngle( 90 );
                    $this->FillPlotArea( );
                    $aa = $this->img->SetAngle( 0 );
                    $adj = ( $this->img->height - $this->img->width ) / 2;
                    $this->img( $bkgimg, $this->img->bottom_margin - $adj, $this->img->left_margin + $adj, 0, 0, $this->img->plotheight + 1, $this->img->plotwidth, $bw, $bh, $this->background_image_mix );
                    break;
                }
                else
                {
                    $this->FillPlotArea( );
                    $this->img( $bkgimg, $this->img->left_margin, $this->img->top_margin, 0, 0, $this->img->plotwidth + 1, $this->img->plotheight, $bw, $bh, $this->background_image_mix );
                    break;
                }
            case BGIMG_FILLFRAME :
                $hadj = 0;
                $vadj = 0;
                if ( $this->doshadow )
                {
                    $hadj = $this->shadow_width;
                    $vadj = $this->shadow_width;
                }
                $this->FillMarginArea( );
                $this->FillPlotArea( );
                $this->img->height( $bkgimg, 0, 0, 0, 0, $this->img->width - $hadj, $this->img->height - $vadj, $bw, $bh, $this->background_image_mix );
                $this->StrokeFrame( );
                break;
            case BGIMG_COPY :
                $this->FillMarginArea( );
                $this->FillPlotArea( );
                $this->img->CopyMerge( $bkgimg, 0, 0, 0, 0, $bw, $bh, $bw, $bh, $this->background_image_mix );
                $this->StrokeFrame( );
                break;
            case BGIMG_CENTER :
                $this->FillMarginArea( );
                $this->FillPlotArea( );
                $centerx = round( $this->img->plotwidth / 2 + $this->img->left_margin - $bw / 2 );
                $centery = round( $this->img->plotheight / 2 + $this->img->top_margin - $bh / 2 );
                $this->img->CopyMerge( $bkgimg, $centerx, $centery, 0, 0, $bw, $bh, $bw, $bh, $this->background_image_mix );
                $this->StrokeFrame( );
                break;
            default :
                ( 25042 );
        }
        $this->img->SetAngle( $aa );
    }

    public function StrokeFrame( )
    {
        if ( $this->doframe )
        {
        }
        else
        {
            if ( $this->background_image_type <= 1 && ( $this->bkg_gradtype < 0 || 0 < $this->bkg_gradtype && $this->bkg_gradstyle == BGRAD_PLOT ) )
            {
                $c = $this->margin_color;
            }
            else
            {
                $c = FALSE;
            }
            if ( $this->doshadow )
            {
                $this->img->SetColor( $this->frame_color );
                $this->img( 0, 0, $this->img->width, $this->img->height, $c, $this->shadow_width, $this->shadow_color );
            }
            else if ( $this->framebevel )
            {
                if ( $c )
                {
                    $this->img->SetColor( $this->margin_color );
                    $this->img->height( 0, 0, $this->img->width - 1, $this->img->height - 1 );
                }
                $this->img->height( 1, 1, $this->img->width - 2, $this->img->height - 2, $this->framebeveldepth, $this->framebevelcolor1, $this->framebevelcolor2 );
                if ( $this->framebevelborder )
                {
                    $this->img->SetColor( $this->framebevelbordercolor );
                    $this->img->height( 0, 0, $this->img->width - 1, $this->img->height - 1 );
                }
            }
            else
            {
                $this->img->SetLineWeight( $this->frame_weight );
                if ( $c )
                {
                    $this->img->SetColor( $this->margin_color );
                    $this->img->height( 0, 0, $this->img->width - 1, $this->img->height - 1 );
                }
                $this->img->SetColor( $this->frame_color );
                $this->img->height( 0, 0, $this->img->width - 1, $this->img->height - 1 );
            }
        }
    }

    public function FillMarginArea( )
    {
        $hadj = 0;
        $vadj = 0;
        if ( $this->doshadow )
        {
            $hadj = $this->shadow_width;
            $vadj = $this->shadow_width;
        }
        $this->img->SetColor( $this->margin_color );
        $this->img( 0, 0, $this->img->width - 1 - $hadj, $this->img->top_margin );
        $this->img( 0, $this->img->top_margin, $this->img->left_margin, $this->img->height - 1 - $hadj );
        $this->img( $this->img->left_margin + 1, $this->img->height - $this->img->bottom_margin, $this->img->width - 1 - $hadj, $this->img->height - 1 - $hadj );
        $this->img( $this->img->width - $this->img->right_margin, $this->img->top_margin + 1, $this->img->width - 1 - $hadj, $this->img->height - $this->img->bottom_margin - 1 );
    }

    public function FillPlotArea( )
    {
        $this->img->PushColor( $this->plotarea_color );
        $this->img->height( $this->img->left_margin, $this->img->top_margin, $this->img->width - $this->img->right_margin, $this->img->height - $this->img->bottom_margin );
        $this->img->PopColor( );
    }

    public function StrokePlotArea( )
    {
        $boxadj = 0;
        $adj = 0;
        if ( $this->background_image != "" || $this->background_cflag != "" )
        {
            $this->StrokeFrameBackground( );
        }
        else
        {
            $aa = $this->img->SetAngle( 0 );
            $this->StrokeFrame( );
            $aa = $this->img->SetAngle( $aa );
            $this->StrokeBackgroundGrad( );
            if ( $this->bkg_gradtype < 0 || 0 < $this->bkg_gradtype && $this->bkg_gradstyle == BGRAD_MARGIN )
            {
                $this->FillPlotArea( );
            }
        }
    }

    public function StrokeIcons( )
    {
        $n = count( $this->iIcons );
        $i = 0;
        for ( ; $i < $n; ++$i )
        {
            $this->iIcons[$i]->StrokeWithScale( $this->img, $this->xscale, $this->yscale );
        }
    }

    public function StrokePlotBox( )
    {
        if ( $this->boxed )
        {
            $this->img->SetLineWeight( 1 );
            $this->img->SetLineStyle( "solid" );
            $this->img->SetColor( $this->box_color );
            $i = 0;
            for ( ; $i < $this->box_weight; ++$i )
            {
                $this->img( $this->img->left_margin - $i, $this->img->top_margin - $i, $this->img->width - $this->img->right_margin + $i, $this->img->height - $this->img->bottom_margin + $i );
            }
        }
    }

    public function SetTitleBackgroundFillStyle( $aStyle, $aColor1 = "black", $aColor2 = "white" )
    {
        $this->titlebkg_fillstyle = $aStyle;
        $this->titlebkg_scolor1 = $aColor1;
        $this->titlebkg_scolor2 = $aColor2;
    }

    public function SetTitleBackground( $aBackColor = "gray", $aStyle = TITLEBKG_STYLE1, $aFrameStyle = TITLEBKG_FRAME_NONE, $aFrameColor = "black", $aFrameWeight = 1, $aBevelHeight = 3, $aEnable = TRUE )
    {
        $this->titlebackground = $aEnable;
        $this->titlebackground_color = $aBackColor;
        $this->titlebackground_style = $aStyle;
        $this->titlebackground_framecolor = $aFrameColor;
        $this->titlebackground_framestyle = $aFrameStyle;
        $this->titlebackground_frameweight = $aFrameWeight;
        $this->titlebackground_bevelheight = $aBevelHeight;
    }

    public function StrokeTitles( )
    {
        $margin = 3;
        if ( $this->titlebackground )
        {
            $this->title += "margin";
            $h = $this->title->GetTextHeight( $this->img ) + $this->title->margin + $margin;
            if ( $this->subtitle->t != "" && !$this->subtitle->hide )
            {
                $h += $this->subtitle->GetTextHeight( $this->img ) + $margin + $this->subtitle->margin;
                $h += 2;
            }
            if ( $this->subsubtitle->t != "" && !$this->subsubtitle->hide )
            {
                $h += $this->subsubtitle->GetTextHeight( $this->img ) + $margin + $this->subsubtitle->margin;
                $h += 2;
            }
            $this->img->PushColor( $this->titlebackground_color );
            if ( $this->titlebackground_style === TITLEBKG_STYLE1 )
            {
                if ( $this->framebevel )
                {
                    $x1 = $y1 = $this->framebeveldepth + 1;
                    $x2 = $this->img->width - $this->framebeveldepth - 2;
                    $this->title += "margin";
                    $h += $y1;
                    $h += 2;
                }
                else
                {
                    $x1 = $y1 = $this->frame_weight;
                    $x2 = $this->img->width - 2 * $x1;
                }
            }
            else if ( $this->titlebackground_style === TITLEBKG_STYLE2 )
            {
                $x1 = $y1 = 0;
                $x2 = $this->img->width - 1;
            }
            else if ( $this->titlebackground_style === TITLEBKG_STYLE3 )
            {
                $x1 = $y1 = 0;
                $x2 = $this->img->width - 1;
                $h += $this->framebeveldepth;
                $this->title += "margin";
            }
            else
            {
                ( 25043 );
            }
            if ( $this->titlebackground_framestyle === 3 )
            {
                $h += $this->titlebackground_bevelheight * 2 + 1;
                $this->title += "margin";
            }
            if ( $this->doshadow )
            {
                $x2 -= $this->shadow_width;
            }
            $indent = 0;
            if ( $this->titlebackground_framestyle == TITLEBKG_FRAME_BEVEL )
            {
                $ind = $this->titlebackground_bevelheight;
            }
            if ( $this->titlebkg_fillstyle == TITLEBKG_FILLSTYLE_HSTRIPED )
            {
                $this->img->FilledRectangle2( $x1 + $ind, $y1 + $ind, $x2 - $ind, $h - $ind, $this->titlebkg_scolor1, $this->titlebkg_scolor2 );
            }
            else if ( $this->titlebkg_fillstyle == TITLEBKG_FILLSTYLE_VSTRIPED )
            {
                $this->img->FilledRectangle2( $x1 + $ind, $y1 + $ind, $x2 - $ind, $h - $ind, $this->titlebkg_scolor1, $this->titlebkg_scolor2, 2 );
            }
            else
            {
                $this->img->FilledRectangle( $x1, $y1, $x2, $h );
            }
            $this->img->PopColor( );
            $this->img->PushColor( $this->titlebackground_framecolor );
            $this->img->SetLineWeight( $this->titlebackground_frameweight );
            if ( $this->titlebackground_framestyle == TITLEBKG_FRAME_FULL )
            {
                $this->img->Rectangle( $x1, $y1, $x2, $h );
            }
            else if ( $this->titlebackground_framestyle == TITLEBKG_FRAME_BOTTOM )
            {
                $this->img->Line( $x1, $h, $x2, $h );
            }
            else if ( $this->titlebackground_framestyle == TITLEBKG_FRAME_BEVEL )
            {
                $this->img->Bevel( $x1, $y1, $x2, $h, $this->titlebackground_bevelheight );
            }
            $this->img->PopColor( );
            if ( $this->framebevel && $this->doframe && $this->titlebackground_style === 3 )
            {
                $this->img->height( 1, 1, $this->img->width - 2, $this->img->height - 2, $this->framebeveldepth, $this->framebevelcolor1, $this->framebevelcolor2 );
                if ( $this->framebevelborder )
                {
                    $this->img->SetColor( $this->framebevelbordercolor );
                    $this->img->height( 0, 0, $this->img->width - 1, $this->img->height - 1 );
                }
            }
        }
        $y = $this->title->margin;
        if ( $this->title->halign == "center" )
        {
            $this->img( 0, $this->img->width, $y );
        }
        else if ( $this->title->halign == "left" )
        {
            $this->title->margin( $this->title->margin + 2, $y );
        }
        else if ( $this->title->halign == "right" )
        {
            $indent = 0;
            if ( $this->doshadow )
            {
                $indent = $this->shadow_width + 2;
            }
            $this->title( $this->img->width - $this->title->margin - $indent, $y, "right" );
        }
        $this->title->Stroke( $this->img );
        $y += $this->title->GetTextHeight( $this->img ) + $margin + $this->subtitle->margin;
        if ( $this->subtitle->halign == "center" )
        {
            $this->img( 0, $this->img->width, $y );
        }
        else if ( $this->subtitle->halign == "left" )
        {
            $this->subtitle->margin( $this->subtitle->margin + 2, $y );
        }
        else if ( $this->subtitle->halign == "right" )
        {
            $indent = 0;
            if ( $this->doshadow )
            {
                $indent = $this->shadow_width + 2;
            }
            $this->subtitle( $this->img->width - $this->subtitle->margin - $indent, $y, "right" );
        }
        $this->subtitle->Stroke( $this->img );
        $y += $this->subtitle->GetTextHeight( $this->img ) + $margin + $this->subsubtitle->margin;
        if ( $this->subsubtitle->halign == "center" )
        {
            $this->img( 0, $this->img->width, $y );
        }
        else if ( $this->subsubtitle->halign == "left" )
        {
            $this->subsubtitle->margin( $this->subsubtitle->margin + 2, $y );
        }
        else if ( $this->subsubtitle->halign == "right" )
        {
            $indent = 0;
            if ( $this->doshadow )
            {
                $indent = $this->shadow_width + 2;
            }
            $this->subsubtitle( $this->img->width - $this->subsubtitle->margin - $indent, $y, "right" );
        }
        $this->subsubtitle->Stroke( $this->img );
        $this->tabtitle->Stroke( $this->img );
    }

    public function StrokeTexts( )
    {
        if ( $this->texts != NULL )
        {
            $i = 0;
            for ( ; $i < count( $this->texts ); ++$i )
            {
                $this->texts[$i]->StrokeWithScale( $this->img, $this->xscale, $this->yscale );
            }
        }
        if ( !( $this->y2texts != NULL ) || !( $this->y2scale != NULL ) )
        {
            $i = 0;
            for ( ; $i < count( $this->y2texts ); ++$i )
            {
                $this->y2texts[$i]->StrokeWithScale( $this->img, $this->xscale, $this->y2scale );
            }
        }
    }

    public function StrokeTables( )
    {
        if ( $this->iTables != NULL )
        {
            $n = count( $this->iTables );
            $i = 0;
            for ( ; $i < $n; ++$i )
            {
                $this->iTables[$i]->StrokeWithScale( $this->img, $this->xscale, $this->yscale );
            }
        }
    }

    public function DisplayClientSideaImageMapAreas( )
    {
        $csim = "";
        foreach ( $this->plots as $p )
        {
            $csim .= $p->GetCSIMareas( );
        }
        $csim .= $this->legend->GetCSIMareas( );
        if ( preg_match_all( "/area shape=\"(\\w+)\" coords=\"([0-9\\, ]+)\"/", $csim, $coords ) )
        {
            $this->img->SetColor( $this->csimcolor );
            $n = count( $coords[0] );
            $i = 0;
            for ( ; $i < $n; ++$i )
            {
                if ( $coords[1][$i] == "poly" )
                {
                    preg_match_all( "/\\s*([0-9]+)\\s*,\\s*([0-9]+)\\s*,*/", $coords[2][$i], $pts );
                    $pts[2]( $pts[1][count( $pts[0] ) - 1], $pts[2][count( $pts[0] ) - 1] );
                    $m = count( $pts[0] );
                    $j = 0;
                    for ( ; $j < $m; ++$j )
                    {
                        $pts[2]( $pts[1][$j], $pts[2][$j] );
                    }
                    else if ( $coords[1][$i] == "rect" )
                    {
                        $pts = preg_split( "/,/", $coords[2][$i] );
                        $this->img->SetStartPoint( $pts[0], $pts[1] );
                        $this->img->LineTo( $pts[2], $pts[1] );
                        $this->img->LineTo( $pts[2], $pts[3] );
                        $this->img->LineTo( $pts[0], $pts[3] );
                        $this->img->LineTo( $pts[0], $pts[1] );
                    }
                }
            }
        }
    }

    public function AdjustSaturationBrightnessContrast( )
    {
        if ( $this->image_contr || $this->image_bright )
        {
            $this->img->AdjBrightContrast( $this->image_bright, $this->image_contr );
        }
        if ( $this->image_sat )
        {
            $this->img->AdjSat( $this->image_sat );
        }
    }

    public function SetTextScaleOff( $aOff )
    {
        $this->text_scale_off = $aOff;
        $this->xscale->text_scale_off = $aOff;
    }

    public function SetTextScaleAbsCenterOff( $aOff )
    {
        $this->text_scale_abscenteroff = $aOff;
    }

    public function GetLinesYMinMax( $aLines )
    {
        $n = count( $aLines );
        if ( $n == 0 )
        {
            return FALSE;
        }
        $min = $aLines[0]->scaleposition;
        $max = $min;
        $flg = FALSE;
        $i = 0;
        for ( ; $i < $n; ++$i )
        {
            if ( $aLines[$i]->direction == HORIZONTAL )
            {
                $flg = TRUE;
                $v = $aLines[$i]->scaleposition;
                if ( $v < $min )
                {
                    $min = $v;
                }
                if ( $max < $v )
                {
                    $max = $v;
                }
            }
        }
        if ( $flg )
        {
            return array( $min, $max );
        }
        return FALSE;
    }

    public function GetLinesXMinMax( $aLines )
    {
        $n = count( $aLines );
        if ( $n == 0 )
        {
            return FALSE;
        }
        $min = $aLines[0]->scaleposition;
        $max = $min;
        $flg = FALSE;
        $i = 0;
        for ( ; $i < $n; ++$i )
        {
            if ( $aLines[$i]->direction == VERTICAL )
            {
                $flg = TRUE;
                $v = $aLines[$i]->scaleposition;
                if ( $v < $min )
                {
                    $min = $v;
                }
                if ( $max < $v )
                {
                    $max = $v;
                }
            }
        }
        if ( $flg )
        {
            return array( $min, $max );
        }
        return FALSE;
    }

    public function GetPlotsYMinMax( $aPlots )
    {
        $n = count( $aPlots );
        $i = 0;
        do
        {
            $max = $aPlots[$i]->Max( )[1];
            $xmax = $aPlots[$i]->Max( )[0];
        } while ( ++$i < $n && !is_numeric( $max ) );
        $i = 0;
        do
        {
            $min = $aPlots[$i]->Min( )[1];
            $xmin = $aPlots[$i]->Min( )[0];
        } while ( ++$i < $n && !is_numeric( $min ) );
        if ( !is_numeric( $min ) || !is_numeric( $max ) )
        {
            ( 25044 );
        }
        $i = 0;
        for ( ; $i < $n; ++$i )
        {
            $ymax = $aPlots[$i]->Max( )[1];
            $xmax = $aPlots[$i]->Max( )[0];
            $ymin = $aPlots[$i]->Min( )[1];
            $xmin = $aPlots[$i]->Min( )[0];
            if ( is_numeric( $ymax ) )
            {
                $max = max( $max, $ymax );
            }
            if ( is_numeric( $ymin ) )
            {
                $min = min( $min, $ymin );
            }
        }
        if ( $min == "" )
        {
            $min = 0;
        }
        if ( $max == "" )
        {
            $max = 0;
        }
        if ( $min == 0 && $max == 0 )
        {
            $min = 0;
            $max = 1;
        }
        return array( $min, $max );
    }

}

class TTF
{

    private $font_files;
    private $style_names;

    public function TTF( )
    {
        $this->style_names = array( "normal", "bold", "italic", "bolditalic" );
        $this->font_files = array( FF_COURIER => array( "cour.ttf", "courbd.ttf", "couri.ttf", "courbi.ttf" ), FF_GEORGIA => array( "georgia.ttf", "georgiab.ttf", "georgiai.ttf", "" ), FF_TREBUCHE => array( "trebuc.ttf", "trebucbd.ttf", "trebucit.ttf", "trebucbi.ttf" ), FF_VERDANA => array( "verdana.ttf", "verdanab.ttf", "verdanai.ttf", "" ), FF_TIMES => array( "times.ttf", "timesbd.ttf", "timesi.ttf", "timesbi.ttf" ), FF_COMIC => array( "comic.ttf", "comicbd.ttf", "", "" ), FF_ARIAL => array( "arial.ttf", "arialbd.ttf", "ariali.ttf", "arialbi.ttf" ), FF_VERA => array( "Vera.ttf", "VeraBd.ttf", "VeraIt.ttf", "VeraBI.ttf" ), FF_VERAMONO => array( "VeraMono.ttf", "VeraMoBd.ttf", "VeraMoIt.ttf", "VeraMoBI.ttf" ), FF_VERASERIF => array( "VeraSe.ttf", "VeraSeBd.ttf", "", "" ), FF_SIMSUN => array( "simsun.ttc", "simhei.ttf", "", "" ), FF_CHINESE => array( FS_NORMAL => CHINESE_TTF_FONT, "", "", "" ), FF_MINCHO => array( FS_NORMAL => MINCHO_TTF_FONT, "", "", "" ), FF_PMINCHO => array( FS_NORMAL => PMINCHO_TTF_FONT, "", "", "" ), FF_GOTHIC => array( FS_NORMAL => GOTHIC_TTF_FONT, "", "", "" ), FF_PGOTHIC => array( FS_NORMAL => PGOTHIC_TTF_FONT, "", "", "" ), FF_MINCHO => array( FS_NORMAL => PMINCHO_TTF_FONT, "", "", "" ) );
    }

    public function File( $family, $style = FS_NORMAL )
    {
        $fam = @$this->font_files[$family];
        if ( $fam )
        {
            ( 25046, $family );
        }
        $f = @$fam[$style];
        if ( $f === "" )
        {
            ( 25047, $this->style_names[$style], $this->font_files[$family][FS_NORMAL] );
        }
        if ( $f )
        {
            ( 25048, $fam );
        }
        if ( FF_MINCHO <= $family && $family <= FF_PGOTHIC )
        {
            $f = MBTTF_DIR.$f;
        }
        else
        {
            $f = TTF_DIR.$f;
        }
        if ( file_exists( $f ) === FALSE || is_readable( $f ) === FALSE )
        {
            ( 25049, $f );
        }
        return $f;
    }

}

class LineProperty
{

    public $iWeight = 1;
    public $iColor = "black";
    public $iStyle = "solid";
    public $iShow = TRUE;

    public function SetColor( $aColor )
    {
        $this->iColor = $aColor;
    }

    public function SetWeight( $aWeight )
    {
        $this->iWeight = $aWeight;
    }

    public function SetStyle( $aStyle )
    {
        $this->iStyle = $aStyle;
    }

    public function Show( $aShow = TRUE )
    {
        $this->iShow = $aShow;
    }

    public function Stroke( $aImg, $aX1, $aY1, $aX2, $aY2 )
    {
        if ( $this->iShow )
        {
            $this->iColor( $this->iColor );
            $oldls = $aImg->line_style;
            $oldlw = $aImg->line_weight;
            $this->iWeight( $this->iWeight );
            $this->iStyle( $this->iStyle );
            $aImg->StyleLine( $aX1, $aY1, $aX2, $aY2 );
            $this->iColor( $this->iColor );
            $aImg->line_style = $oldls;
            $aImg->line_weight = $oldlw;
        }
    }

}

class Text
{

    public $t;
    public $margin = 0;
    public $x = 0;
    public $y = 0;
    public $halign = "left";
    public $valign = "top";
    public $color = array( 0, 0, 0 );
    public $hide = FALSE;
    public $dir = 0;
    public $iScalePosY;
    public $iScalePosX;
    public $iWordwrap = 0;
    protected $font_family = FF_FONT1;
    protected $font_style = FS_NORMAL;
    protected $font_size = 12;
    protected $boxed = FALSE;
    protected $paragraph_align = "left";
    protected $icornerradius = 0;
    protected $ishadowwidth = 3;
    protected $fcolor = "white";
    protected $bcolor = "black";
    protected $shadow = FALSE;
    protected $iCSIMarea = "";
    protected $iCSIMalt = "";
    protected $iCSIMtarget = "";

    public function Text( $aTxt = "", $aXAbsPos = 0, $aYAbsPos = 0 )
    {
        if ( is_string( $aTxt ) )
        {
            ( 25050 );
        }
        $this->t = $aTxt;
        $this->x = round( $aXAbsPos );
        $this->y = round( $aYAbsPos );
        $this->margin = 0;
    }

    public function Set( $aTxt )
    {
        $this->t = $aTxt;
    }

    public function SetPos( $aXAbsPos = 0, $aYAbsPos = 0, $aHAlign = "left", $aVAlign = "top" )
    {
        $this->x = $aXAbsPos;
        $this->y = $aYAbsPos;
        $this->halign = $aHAlign;
        $this->valign = $aVAlign;
    }

    public function SetScalePos( $aX, $aY )
    {
        $this->iScalePosX = $aX;
        $this->iScalePosY = $aY;
    }

    public function Align( $aHAlign, $aVAlign = "top", $aParagraphAlign = "" )
    {
        $this->halign = $aHAlign;
        $this->valign = $aVAlign;
        if ( $aParagraphAlign != "" )
        {
            $this->paragraph_align = $aParagraphAlign;
        }
    }

    public function SetAlign( $aHAlign, $aVAlign = "top", $aParagraphAlign = "" )
    {
        $this->Align( $aHAlign, $aVAlign, $aParagraphAlign );
    }

    public function ParagraphAlign( $aAlign )
    {
        $this->paragraph_align = $aAlign;
    }

    public function SetParagraphAlign( $aAlign )
    {
        $this->paragraph_align = $aAlign;
    }

    public function SetShadow( $aShadowColor = "gray", $aShadowWidth = 3 )
    {
        $this->ishadowwidth = $aShadowWidth;
        $this->shadow = $aShadowColor;
        $this->boxed = TRUE;
    }

    public function SetWordWrap( $aCol )
    {
        $this->iWordwrap = $aCol;
    }

    public function SetBox( $aFrameColor = array( 255, 255, 255 ), $aBorderColor = array( 0, 0, 0 ), $aShadowColor = FALSE, $aCornerRadius = 4, $aShadowWidth = 3 )
    {
        if ( $aFrameColor )
        {
            $this->boxed = FALSE;
        }
        else
        {
            $this->boxed = TRUE;
        }
        $this->fcolor = $aFrameColor;
        $this->bcolor = $aBorderColor;
        if ( $aShadowColor === TRUE )
        {
            $aShadowColor = "gray";
        }
        $this->shadow = $aShadowColor;
        $this->icornerradius = $aCornerRadius;
        $this->ishadowwidth = $aShadowWidth;
    }

    public function Hide( $aHide = TRUE )
    {
        $this->hide = $aHide;
    }

    public function Show( $aShow = TRUE )
    {
        $this->hide = !$aShow;
    }

    public function SetFont( $aFamily, $aStyle = FS_NORMAL, $aSize = 10 )
    {
        $this->font_family = $aFamily;
        $this->font_style = $aStyle;
        $this->font_size = $aSize;
    }

    public function Center( $aLeft, $aRight, $aYAbsPos = FALSE )
    {
        $this->x = $aLeft + ( $aRight - $aLeft ) / 2;
        $this->halign = "center";
        if ( is_numeric( $aYAbsPos ) )
        {
            $this->y = $aYAbsPos;
        }
    }

    public function SetColor( $aColor )
    {
        $this->color = $aColor;
    }

    public function SetAngle( $aAngle )
    {
        $this->SetOrientation( $aAngle );
    }

    public function SetOrientation( $aDirection = 0 )
    {
        if ( is_numeric( $aDirection ) )
        {
            $this->dir = $aDirection;
        }
        else if ( $aDirection == "h" )
        {
            $this->dir = 0;
        }
        else if ( $aDirection == "v" )
        {
            $this->dir = 90;
        }
        else
        {
            ( 25051 );
        }
    }

    public function GetWidth( $aImg )
    {
        $this->font_size( $this->font_family, $this->font_style, $this->font_size );
        $w = $this->dir( $this->t, $this->dir );
        return $w;
    }

    public function GetFontHeight( $aImg )
    {
        $this->font_size( $this->font_family, $this->font_style, $this->font_size );
        $h = $aImg->GetFontHeight( );
        return $h;
    }

    public function GetTextHeight( $aImg )
    {
        $this->font_size( $this->font_family, $this->font_style, $this->font_size );
        $h = $this->dir( $this->t, $this->dir );
        return $h;
    }

    public function GetHeight( $aImg )
    {
        $this->font_size( $this->font_family, $this->font_style, $this->font_size );
        $h = $this->dir( $this->t, $this->dir );
        return $h;
    }

    public function SetMargin( $aMarg )
    {
        $this->margin = $aMarg;
    }

    public function StrokeWithScale( $aImg, $axscale, $ayscale )
    {
        if ( $this->iScalePosX === NULL || $this->iScalePosY === NULL )
        {
            $this->Stroke( $aImg );
        }
        else
        {
            $this->Stroke( $aImg, round( $this->iScalePosX( $this->iScalePosX ) ), round( $this->iScalePosY( $this->iScalePosY ) ) );
        }
    }

    public function SetCSIMTarget( $aTarget, $aAlt = NULL )
    {
        $this->iCSIMtarget = $aTarget;
        $this->iCSIMalt = $aAlt;
    }

    public function GetCSIMareas( )
    {
        if ( $this->iCSIMtarget !== "" )
        {
            return $this->iCSIMarea;
        }
        return "";
    }

    public function Stroke( $aImg, $x = NULL, $y = NULL )
    {
        if ( empty( $x ) )
        {
            $this->x = round( $x );
        }
        if ( empty( $y ) )
        {
            $this->y = round( $y );
        }
        if ( 0 < $this->iWordwrap )
        {
            $this->t = wordwrap( $this->t, $this->iWordwrap, "\n" );
        }
        if ( $this->x < 1 && 0 < $this->x )
        {
            $ && _732938400 *= "x";
        }
        if ( $this->y < 1 && 0 < $this->y )
        {
            $ && _732938520 *= "y";
        }
        $this->color( $this->color );
        $this->font_size( $this->font_family, $this->font_style, $this->font_size );
        $this->valign( $this->halign, $this->valign );
        if ( $this->boxed )
        {
            if ( $this->fcolor == "nofill" )
            {
                $this->fcolor = FALSE;
            }
            $aImg->SetLineWeight( 1 );
            $bbox = $this->ishadowwidth( $this->x, $this->y, $this->t, $this->dir, $this->fcolor, $this->bcolor, $this->shadow, $this->paragraph_align, 5, 5, $this->icornerradius, $this->ishadowwidth );
        }
        else
        {
            $bbox = $this->paragraph_align( $this->x, $this->y, $this->t, $this->dir, $this->paragraph_align );
        }
        $coords = $bbox[0].",".$bbox[1].",".$bbox[2].",".$bbox[3].",".$bbox[4].",".$bbox[5].",".$bbox[6].",".$bbox[7];
        $this->iCSIMarea = "<area shape=\"poly\" coords=\"".$coords."\" href=\"".htmlentities( $this->iCSIMtarget )."\"";
        $ && _732868904 .= "iCSIMarea";
        $this->color( $this->color );
    }

}

class GraphTabTitle extends Text
{

    private $corner = 6;
    private $posx = 7;
    private $posy = 4;
    private $fillcolor = "lightyellow";
    private $bordercolor = "black";
    private $align = "left";
    private $width = TABTITLE_WIDTHFIT;

    public function GraphTabTitle( )
    {
        $this->t = "";
        $this->font_style = FS_BOLD;
        $this->hide = TRUE;
        $this->color = "darkred";
    }

    public function SetColor( $aTxtColor, $aFillColor = "lightyellow", $aBorderColor = "black" )
    {
        $this->color = $aTxtColor;
        $this->fillcolor = $aFillColor;
        $this->bordercolor = $aBorderColor;
    }

    public function SetFillColor( $aFillColor )
    {
        $this->fillcolor = $aFillColor;
    }

    public function SetTabAlign( $aAlign )
    {
        $this->align = $aAlign;
    }

    public function SetWidth( $aWidth )
    {
        $this->width = $aWidth;
    }

    public function Set( $t )
    {
        $this->t = $t;
        $this->hide = FALSE;
    }

    public function SetCorner( $aD )
    {
        $this->corner = $aD;
    }

    public function Stroke( $aImg, $aDummy1 = NULL, $aDummy2 = NULL )
    {
        if ( $this->hide )
        {
        }
        else
        {
            $this->boxed = FALSE;
            $w = $this->GetWidth( $aImg ) + 2 * $this->posx;
            $h = $this->GetTextHeight( $aImg ) + 2 * $this->posy;
            $x = $aImg->left_margin;
            $y = $aImg->top_margin;
            if ( $this->width === TABTITLE_WIDTHFIT )
            {
                if ( $this->align == "left" )
                {
                    $p = array( $x, $y, $x, $y - $h + $this->corner, $x + $this->corner, $y - $h, $x + $w - $this->corner, $y - $h, $x + $w, $y - $h + $this->corner, $x + $w, $y );
                }
                else
                {
                    if ( $this->align == "center" )
                    {
                        $x += round( $aImg->plotwidth / 2 ) - round( $w / 2 );
                        $p = array( $x, $y, $x, $y - $h + $this->corner, $x + $this->corner, $y - $h, $x + $w - $this->corner, $y - $h, $x + $w, $y - $h + $this->corner, $x + $w, $y );
                    }
                    else
                    {
                        $x += $aImg->plotwidth - $w;
                        $p = array( $x, $y, $x, $y - $h + $this->corner, $x + $this->corner, $y - $h, $x + $w - $this->corner, $y - $h, $x + $w, $y - $h + $this->corner, $x + $w, $y );
                    }
                }
            }
            else
            {
                if ( $this->width === TABTITLE_WIDTHFULL )
                {
                    $w = $aImg->plotwidth;
                }
                else
                {
                    $w = $this->width;
                }
                $p = array( $x, $y, $x, $y - $h + $this->corner, $x + $this->corner, $y - $h, $x + $w - $this->corner, $y - $h, $x + $w, $y - $h + $this->corner, $x + $w, $y );
            }
            if ( $this->halign == "left" )
            {
                $aImg->SetTextAlign( "left", "bottom" );
                $x += $this->posx;
                $y -= $this->posy;
            }
            else if ( $this->halign == "center" )
            {
                $aImg->SetTextAlign( "center", "bottom" );
                $x += $w / 2;
                $y -= $this->posy;
            }
            else
            {
                $aImg->SetTextAlign( "right", "bottom" );
                $x += $w - $this->posx;
                $y -= $this->posy;
            }
            $this->fillcolor( $this->fillcolor );
            $aImg->FilledPolygon( $p );
            $this->bordercolor( $this->bordercolor );
            $aImg->Polygon( $p, TRUE );
            $this->color( $this->color );
            $this->font_size( $this->font_family, $this->font_style, $this->font_size );
            $this->t( $x, $y, $this->t, 0, "center" );
        }
    }

}

class SuperScriptText extends Text
{

    private $iSuper = "";
    private $sfont_family = "";
    private $sfont_style = "";
    private $sfont_size = 8;
    private $iSuperMargin = 2;
    private $iVertOverlap = 4;
    private $iSuperScale = 0.65;
    private $iSDir = 0;
    private $iSimple = FALSE;

    public function SuperScriptText( $aTxt = "", $aSuper = "", $aXAbsPos = 0, $aYAbsPos = 0 )
    {
        ( $aTxt, $aXAbsPos, $aYAbsPos );
        $this->iSuper = $aSuper;
    }

    public function FromReal( $aVal, $aPrecision = 2 )
    {
        $neg = 1;
        if ( $aVal < 0 )
        {
            $neg = -1;
            $aVal = 0 - $aVal;
        }
        $l = floor( log10( $aVal ) );
        $a = sprintf( "%0.".$aPrecision."f", round( $aVal / pow( 10, $l ), $aPrecision ) );
        $a *= $neg;
        if ( $this->iSimple && ( $a == 1 || $a == -1 ) )
        {
            $a = "";
        }
        if ( $a != "" )
        {
            $this->t = $a." * 10";
        }
        else if ( $neg == 1 )
        {
            $this->t = "10";
        }
        else
        {
            $this->t = "-10";
        }
        $this->iSuper = $l;
    }

    public function Set( $aTxt, $aSuper = "" )
    {
        $this->t = $aTxt;
        $this->iSuper = $aSuper;
    }

    public function SetSuperFont( $aFontFam, $aFontStyle = FS_NORMAL, $aFontSize = 8 )
    {
        $this->sfont_family = $aFontFam;
        $this->sfont_style = $aFontStyle;
        $this->sfont_size = $aFontSize;
    }

    public function GetWidth( $aImg )
    {
        $this->font_size( $this->font_family, $this->font_style, $this->font_size );
        $w = $this->t( $this->t );
        $this->sfont_size( $this->sfont_family, $this->sfont_style, $this->sfont_size );
        $w += $this->iSuper( $this->iSuper );
        $w += $this->iSuperMargin;
        return $w;
    }

    public function GetFontHeight( $aImg )
    {
        $this->font_size( $this->font_family, $this->font_style, $this->font_size );
        $h = $aImg->GetFontHeight( );
        $this->sfont_size( $this->sfont_family, $this->sfont_style, $this->sfont_size );
        $h += $aImg->GetFontHeight( );
        return $h;
    }

    public function GetTextHeight( $aImg )
    {
        $this->font_size( $this->font_family, $this->font_style, $this->font_size );
        $h = $this->t( $this->t );
        $this->sfont_size( $this->sfont_family, $this->sfont_style, $this->sfont_size );
        $h += $this->iSuper( $this->iSuper );
        return $h;
    }

    public function Stroke( $aImg, $ax = -1, $ay = -1 )
    {
        $w = ( $aImg );
        $h = ( $aImg );
        switch ( $this->valign )
        {
            case "top" :
                $sy = $this->y;
                break;
            case "center" :
                $sy = $this->y - $h / 2;
                break;
            case "bottom" :
                $sy = $this->y - $h;
                break;
            default :
                ( 25052 );
        }
        switch ( $this->halign )
        {
            case "left" :
                $sx = $this->x + $w;
                break;
            case "center" :
                $sx = $this->x + $w / 2;
                break;
            case "right" :
                $sx = $this->x;
                break;
            default :
                ( 25053 );
        }
        $sx += $this->iSuperMargin;
        $sy += $this->iVertOverlap;
        if ( $this->sfont_family == "" )
        {
            if ( $this->font_family <= FF_FONT2 )
            {
                if ( $this->font_family == FF_FONT0 )
                {
                    $sff = FF_FONT0;
                }
                else if ( $this->font_family == FF_FONT1 )
                {
                    if ( $this->font_style == FS_NORMAL )
                    {
                        $sff = FF_FONT0;
                    }
                    else
                    {
                        $sff = FF_FONT1;
                    }
                }
                else
                {
                    $sff = FF_FONT1;
                }
                $sfs = $this->font_style;
                $sfz = $this->font_size;
            }
            else
            {
                $sff = $this->font_family;
                $sfs = $this->font_style;
                $sfz = floor( $this->font_size * $this->iSuperScale );
                if ( $sfz < 8 )
                {
                    $sfz = 8;
                }
            }
            $this->sfont_family = $sff;
            $this->sfont_style = $sfs;
            $this->sfont_size = $sfz;
        }
        else
        {
            $sff = $this->sfont_family;
            $sfs = $this->sfont_style;
            $sfz = $this->sfont_size;
        }
        ( $aImg, $ax, $ay );
        if ( $sff <= FF_FONT2 )
        {
            $sx -= 2;
            $sy += 3;
        }
        $aImg->SetTextAlign( "left", "bottom" );
        $aImg->SetFont( $sff, $sfs, $sfz );
        $this->color( $this->color );
        $this->iSDir( $sx, $sy, $this->iSuper, $this->iSDir, "left" );
        $aImg->PopColor( );
    }

}

class Grid
{

    protected $img;
    protected $scale;
    protected $grid_color = "#DDDDDD";
    protected $grid_mincolor = "#DDDDDD";
    protected $type = "solid";
    protected $show = FALSE;
    protected $showMinor = FALSE;
    protected $weight = 1;
    protected $fill = FALSE;
    protected $fillcolor = array( "#EFEFEF", "#BBCCFF" );

    public function Grid( $aAxis )
    {
        $this->scale = $aAxis->scale;
        $this->img = $aAxis->img;
    }

    public function SetColor( $aMajColor, $aMinColor = FALSE )
    {
        $this->grid_color = $aMajColor;
        if ( $aMinColor === FALSE )
        {
            $aMinColor = $aMajColor;
        }
        $this->grid_mincolor = $aMinColor;
    }

    public function SetWeight( $aWeight )
    {
        $this->weight = $aWeight;
    }

    public function SetLineStyle( $aType )
    {
        $this->type = $aType;
    }

    public function Show( $aShowMajor = TRUE, $aShowMinor = FALSE )
    {
        $this->show = $aShowMajor;
        $this->showMinor = $aShowMinor;
    }

    public function SetFill( $aFlg = TRUE, $aColor1 = "lightgray", $aColor2 = "lightblue" )
    {
        $this->fill = $aFlg;
        $this->fillcolor = array( $aColor1, $aColor2 );
    }

    public function Stroke( )
    {
        if ( $this->showMinor )
        {
            $tmp = $this->grid_color;
            $this->grid_color = $this->grid_mincolor;
            $this->scale->ticks->ticks_pos( $this->scale->ticks->ticks_pos );
            $this->grid_color = $tmp;
            $this->scale->ticks->maj_ticks_pos( $this->scale->ticks->maj_ticks_pos );
        }
        else
        {
            $this->scale->ticks->maj_ticks_pos( $this->scale->ticks->maj_ticks_pos );
        }
    }

    public function DoStroke( $aTicksPos )
    {
        if ( $this->show )
        {
        }
        else
        {
            $nbrgrids = count( $aTicksPos );
            if ( $this->scale->type == "y" )
            {
                $xl = $this->img->left_margin;
                $xr = $this->img->width - $this->img->right_margin;
                if ( $this->fill )
                {
                    $y2 = $aTicksPos[0];
                    $i = 1;
                    while ( $i < $nbrgrids )
                    {
                        $y1 = $y2;
                        $y2 = $aTicksPos[$i++];
                        $this->fillcolor( $this->fillcolor[$i & 1] );
                        $this->img->FilledRectangle( $xl, $y1, $xr, $y2 );
                    }
                }
                $this->img->SetColor( $this->grid_color );
                $this->img->SetLineWeight( $this->weight );
                $i = 0;
                for ( ; $i < $nbrgrids; ++$i )
                {
                    $y = $aTicksPos[$i];
                    if ( $this->type == "solid" )
                    {
                        $this->img->Line( $xl, $y, $xr, $y );
                    }
                    else
                    {
                        if ( $this->type == "dotted" )
                        {
                            $this->img->DashedLine( $xl, $y, $xr, $y, 1, 6 );
                        }
                        else
                        {
                            if ( $this->type == "dashed" )
                            {
                                $this->img->DashedLine( $xl, $y, $xr, $y, 2, 4 );
                            }
                            else
                            {
                                if ( $this->type == "longdashed" )
                                {
                                    $this->img->DashedLine( $xl, $y, $xr, $y, 8, 6 );
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                if ( $this->scale->type == "x" )
                {
                    $yu = $this->img->top_margin;
                    $yl = $this->img->height - $this->img->bottom_margin;
                    $limit = $this->img->width - $this->img->right_margin;
                    if ( $this->fill )
                    {
                        $x2 = $aTicksPos[0];
                        $i = 1;
                        while ( $i < $nbrgrids )
                        {
                            $x1 = $x2;
                            $x2 = min( $aTicksPos[$i++], $limit );
                            $this->fillcolor( $this->fillcolor[$i & 1] );
                            $this->img->FilledRectangle( $x1, $yu, $x2, $yl );
                        }
                    }
                    $this->img->SetColor( $this->grid_color );
                    $this->img->SetLineWeight( $this->weight );
                    $i = 0;
                    $x = $aTicksPos[$i];
                    while ( $i < count( $aTicksPos ) )
                    {
                        if ( ( $x = $aTicksPos[$i] ) <= $limit )
                        {
                            if ( $this->type == "solid" )
                            {
                                $this->img->Line( $x, $yl, $x, $yu );
                            }
                            else if ( $this->type == "dotted" )
                            {
                                $this->img->DashedLine( $x, $yl, $x, $yu, 1, 6 );
                            }
                            else if ( $this->type == "dashed" )
                            {
                                $this->img->DashedLine( $x, $yl, $x, $yu, 2, 4 );
                            }
                            else if ( $this->type == "longdashed" )
                            {
                                $this->img->DashedLine( $x, $yl, $x, $yu, 8, 6 );
                            }
                        }
                        ++$i;
                    }
                }
                ( 25054, $this->scale->type );
            }
            return TRUE;
        }
    }

}

class AxisPrototype
{

    public $scale;
    public $img;
    public $hide = FALSE;
    public $hide_labels = FALSE;
    public $title;
    public $font_family = FF_FONT1;
    public $font_style = FS_NORMAL;
    public $font_size = 12;
    public $label_angle = 0;
    public $tick_step = 1;
    public $pos = FALSE;
    protected $weight = 1;
    protected $color = array( 0, 0, 0 );
    protected $label_color = array( 0, 0, 0 );
    protected $ticks_label = FALSE;
    protected $ticks_label_colors;
    protected $show_first_label = TRUE;
    protected $show_last_label = TRUE;
    protected $label_step = 1;
    protected $labelPos = 0;
    protected $title_adjust;
    protected $title_margin;
    protected $title_side = SIDE_LEFT;
    protected $tick_label_margin = 7;
    protected $label_halign = "";
    protected $label_valign = "";
    protected $label_para_align = "left";
    protected $hide_line = FALSE;
    protected $iDeltaAbsPos = 0;

    public function Axis( $img, $aScale, $color = array( 0, 0, 0 ) )
    {
        $this->img = $img;
        $this->scale = $aScale;
        $this->color = $color;
        $this->title = new Text( "" );
        if ( $aScale->type == "y" )
        {
            $this->title_margin = 25;
            $this->title_adjust = "middle";
            $this->title->SetOrientation( 90 );
            $this->tick_label_margin = 7;
            $this->labelPos = SIDE_LEFT;
        }
        else
        {
            $this->title_margin = 5;
            $this->title_adjust = "high";
            $this->title->SetOrientation( 0 );
            $this->tick_label_margin = 7;
            $this->labelPos = SIDE_DOWN;
            $this->title_side = SIDE_DOWN;
        }
    }

    public function SetLabelFormat( $aFormStr )
    {
        $this->scale->ticks->SetLabelFormat( $aFormStr );
    }

    public function SetLabelFormatString( $aFormStr, $aDate = FALSE )
    {
        $this->scale->ticks->SetLabelFormat( $aFormStr, $aDate );
    }

    public function SetLabelFormatCallback( $aFuncName )
    {
        $this->scale->ticks->SetFormatCallback( $aFuncName );
    }

    public function SetLabelAlign( $aHAlign, $aVAlign = "top", $aParagraphAlign = "left" )
    {
        $this->label_halign = $aHAlign;
        $this->label_valign = $aVAlign;
        $this->label_para_align = $aParagraphAlign;
    }

    public function HideFirstTickLabel( $aShow = FALSE )
    {
        $this->show_first_label = $aShow;
    }

    public function HideLastTickLabel( $aShow = FALSE )
    {
        $this->show_last_label = $aShow;
    }

    public function SetTickPositions( $aMajPos, $aMinPos = NULL, $aLabels = NULL )
    {
        $this->scale->ticks->SetTickPositions( $aMajPos, $aMinPos, $aLabels );
    }

    public function SetMajTickPositions( $aMajPos, $aLabels = NULL )
    {
        $this->scale->ticks->SetTickPositions( $aMajPos, NULL, $aLabels );
    }

    public function HideTicks( $aHideMinor = TRUE, $aHideMajor = TRUE )
    {
        $this->scale->ticks->SupressMinorTickMarks( $aHideMinor );
        $this->scale->ticks->SupressTickMarks( $aHideMajor );
    }

    public function HideZeroLabel( $aFlag = TRUE )
    {
        $this->scale->ticks->SupressZeroLabel( );
    }

    public function HideFirstLastLabel( )
    {
        $this->scale->ticks->SupressLast( );
        $this->scale->ticks->SupressFirst( );
        $this->show_first_label = FALSE;
        $this->show_last_label = FALSE;
    }

    public function Hide( $aHide = TRUE )
    {
        $this->hide = $aHide;
    }

    public function HideLine( $aHide = TRUE )
    {
        $this->hide_line = $aHide;
    }

    public function HideLabels( $aHide = TRUE )
    {
        $this->hide_labels = $aHide;
    }

    public function SetWeight( $aWeight )
    {
        $this->weight = $aWeight;
    }

    public function SetColor( $aColor, $aLabelColor = FALSE )
    {
        $this->color = $aColor;
        if ( $aLabelColor )
        {
            $this->label_color = $aColor;
        }
        else
        {
            $this->label_color = $aLabelColor;
        }
    }

    public function SetTitle( $aTitle, $aAdjustAlign = "high" )
    {
        $this->title->Set( $aTitle );
        $this->title_adjust = $aAdjustAlign;
    }

    public function SetTitleMargin( $aMargin )
    {
        $this->title_margin = $aMargin;
    }

    public function SetTitleSide( $aSideOfAxis )
    {
        $this->title_side = $aSideOfAxis;
    }

    public function SetTickDirection( $aDir )
    {
        if ( ERR_DEPRECATED )
        {
            ( 25055 );
        }
        $this->scale->ticks->SetSide( $aDir );
    }

    public function SetTickSide( $aDir )
    {
        $this->scale->ticks->SetSide( $aDir );
    }

    public function SetTickLabels( $aLabelArray, $aLabelColorArray = NULL )
    {
        $this->ticks_label = $aLabelArray;
        $this->ticks_label_colors = $aLabelColorArray;
    }

    public function SetTickLabelMargin( $aMargin )
    {
        if ( ERR_DEPRECATED )
        {
            ( 25056 );
        }
        $this->tick_label_margin = $aMargin;
    }

    public function SetLabelMargin( $aMargin )
    {
        $this->tick_label_margin = $aMargin;
    }

    public function SetTextTicks( $step, $start = 0 )
    {
        ( 25057 );
    }

    public function SetTextTickInterval( $aStep, $aStart = 0 )
    {
        $this->scale->ticks->SetTextLabelStart( $aStart );
        $this->tick_step = $aStep;
    }

    public function SetTextLabelInterval( $aStep )
    {
        if ( $aStep < 1 )
        {
            ( 25058 );
        }
        $this->label_step = $aStep;
    }

    public function SetLabelPos( $aSidePos )
    {
        if ( ERR_DEPRECATED )
        {
            ( 25059 );
        }
        $this->labelPos = $aSidePos;
    }

    public function SetLabelSide( $aSidePos )
    {
        $this->labelPos = $aSidePos;
    }

    public function SetFont( $aFamily, $aStyle = FS_NORMAL, $aSize = 10 )
    {
        $this->font_family = $aFamily;
        $this->font_style = $aStyle;
        $this->font_size = $aSize;
    }

    public function SetPos( $aPosOnOtherScale )
    {
        $this->pos = $aPosOnOtherScale;
    }

    public function SetPosAbsDelta( $aDelta )
    {
        $this->iDeltaAbsPos = $aDelta;
    }

    public function SetLabelAngle( $aAngle )
    {
        $this->label_angle = $aAngle;
    }

}

class Axis extends AxisPrototype
{

    public function Axis( $img, $aScale, $color = array( 0, 0, 0 ) )
    {
        ( $img, $aScale, $color );
    }

    public function Stroke( $aOtherAxisScale, $aStrokeLabels = TRUE )
    {
        if ( $this->hide )
        {
        }
        else
        {
            if ( is_numeric( $this->pos ) )
            {
                $pos = $this->pos( $this->pos );
            }
            else if ( !( 0 <= $aOtherAxisScale->GetMinVal( ) ) || !$this->pos || $this->pos == "min" )
            {
                $pos = $aOtherAxisScale->scale_abs[0];
            }
            else if ( $this->pos == "max" )
            {
                $pos = $aOtherAxisScale->scale_abs[1];
            }
            else
            {
                $this->pos = 0;
                $pos = $aOtherAxisScale->Translate( 0 );
            }
            $pos += $this->iDeltaAbsPos;
            $this->img->SetLineWeight( $this->weight );
            $this->img->SetColor( $this->color );
            $this->img->SetFont( $this->font_family, $this->font_style, $this->font_size );
            if ( $this->scale->type == "x" )
            {
                if ( $this->hide_line )
                {
                    $this->img->width( $this->img->left_margin, $pos, $this->img->width - $this->img->right_margin, $pos + $this->weight - 1 );
                }
                if ( $this->title_side == SIDE_DOWN )
                {
                    $y = $pos + $this->img->GetFontHeight( ) + $this->title_margin + $this->title->margin;
                    $yalign = "top";
                }
                else
                {
                    $y = $pos - $this->img->GetFontHeight( ) - $this->title_margin - $this->title->margin;
                    $yalign = "bottom";
                }
                if ( $this->title_adjust == "high" )
                {
                    $this->img->width( $this->img->width - $this->img->right_margin, $y, "right", $yalign );
                }
                else
                {
                    if ( $this->title_adjust == "middle" || $this->title_adjust == "center" )
                    {
                        $this->img( ( $this->img->width - $this->img->left_margin - $this->img->right_margin ) / 2 + $this->img->left_margin, $y, "center", $yalign );
                    }
                    else
                    {
                        if ( $this->title_adjust == "low" )
                        {
                            $this->img( $this->img->left_margin, $y, "left", $yalign );
                        }
                        else
                        {
                            ( 25060, $this->title_adjust );
                        }
                    }
                }
            }
            else if ( $this->scale->type == "y" )
            {
                if ( $this->hide_line )
                {
                    $this->img->height( $pos - $this->weight + 1, $this->img->top_margin, $pos, $this->img->height - $this->img->bottom_margin + $this->weight - 1 );
                }
                $x = $pos;
                if ( $this->title_side == SIDE_LEFT )
                {
                    $x -= $this->title_margin;
                    $x -= $this->title->margin;
                    $halign = "right";
                }
                else
                {
                    $x += $this->title_margin;
                    $x += $this->title->margin;
                    $halign = "left";
                }
                if ( $this->title->halign != "left" )
                {
                    $halign = $this->title->halign;
                }
                if ( $this->title_adjust == "high" )
                {
                    $this->img( $x, $this->img->top_margin, $halign, "top" );
                }
                else if ( $this->title_adjust == "middle" || $this->title_adjust == "center" )
                {
                    $this->img( $x, ( $this->img->height - $this->img->top_margin - $this->img->bottom_margin ) / 2 + $this->img->top_margin, $halign, "center" );
                }
                else if ( $this->title_adjust == "low" )
                {
                    $this->img->height( $x, $this->img->height - $this->img->bottom_margin, $halign, "bottom" );
                }
                else
                {
                    ( 25061, $this->title_adjust );
                }
            }
            $this->scale->ticks->Stroke( $this->img, $this->scale, $pos );
            if ( $aStrokeLabels )
            {
                if ( $this->hide_labels )
                {
                    $this->StrokeLabels( $pos );
                }
                $this->title->Stroke( $this->img );
            }
        }
    }

    public function StrokeLabels( $aPos, $aMinor = FALSE, $aAbsLabel = FALSE )
    {
        $this->img->SetColor( $this->label_color );
        $this->img->SetFont( $this->font_family, $this->font_style, $this->font_size );
        $yoff = $this->img->GetFontHeight( ) / 2;
        $nbr = count( $this->scale->ticks->maj_ticks_label );
        $i = $this->show_first_label ? 0 : 1;
        if ( $this->show_last_label )
        {
            --$nbr;
        }
        $ncolor = 0;
        if ( isset( $this->ticks_label_colors ) )
        {
            $ncolor = count( $this->ticks_label_colors );
        }
        while ( $i < $nbr )
        {
            $tpos = $this->scale->ticks->maj_ticklabels_pos[$i];
            if ( $this->scale->type == "x" && $this->img->width - $this->img->right_margin + 1 < $tpos )
            {
            }
            else
            {
                if ( $i % $this->label_step == 0 )
                {
                    if ( 0 < $ncolor )
                    {
                        $this->ticks_label_colors( $this->ticks_label_colors[$i % $ncolor] );
                    }
                    $m = $this->scale->ticks->GetMajor( );
                    if ( isset( $this->ticks_label[$i * $m] ) )
                    {
                        $label = $this->ticks_label[$i * $m];
                    }
                    else
                    {
                        if ( $aAbsLabel )
                        {
                            $label = abs( $this->scale->ticks->maj_ticks_label[$i] );
                        }
                        else
                        {
                            $label = $this->scale->ticks->maj_ticks_label[$i];
                        }
                        if ( $this->scale->textscale && $this->scale->ticks->label_formfunc == "" )
                        {
                            ++$label;
                        }
                    }
                    if ( $this->scale->type == "x" )
                    {
                        if ( $this->labelPos == SIDE_DOWN )
                        {
                            if ( $this->label_angle == 0 || $this->label_angle == 90 )
                            {
                                if ( $this->label_halign == "" && $this->label_valign == "" )
                                {
                                    $this->img->SetTextAlign( "center", "top" );
                                }
                                else
                                {
                                    $this->img->SetTextAlign( $this->label_halign, $this->label_valign );
                                }
                            }
                            else if ( $this->label_halign == "" && $this->label_valign == "" )
                            {
                                $this->img->SetTextAlign( "right", "top" );
                            }
                            else
                            {
                                $this->img->SetTextAlign( $this->label_halign, $this->label_valign );
                            }
                            $this->img->StrokeText( $tpos, $aPos + $this->tick_label_margin + 1, $label, $this->label_angle, $this->label_para_align );
                        }
                        else
                        {
                            if ( $this->label_angle == 0 || $this->label_angle == 90 )
                            {
                                if ( $this->label_halign == "" && $this->label_valign == "" )
                                {
                                    $this->img->SetTextAlign( "center", "bottom" );
                                }
                                else
                                {
                                    $this->img->SetTextAlign( $this->label_halign, $this->label_valign );
                                }
                            }
                            else if ( $this->label_halign == "" && $this->label_valign == "" )
                            {
                                $this->img->SetTextAlign( "right", "bottom" );
                            }
                            else
                            {
                                $this->img->SetTextAlign( $this->label_halign, $this->label_valign );
                            }
                            $this->img->StrokeText( $tpos, $aPos - $this->tick_label_margin - 1, $label, $this->label_angle, $this->label_para_align );
                        }
                    }
                    else
                    {
                        if ( $this->labelPos == SIDE_LEFT )
                        {
                            if ( $this->label_halign == "" && $this->label_valign == "" )
                            {
                                $this->img->SetTextAlign( "right", "center" );
                            }
                            else
                            {
                                $this->img->SetTextAlign( $this->label_halign, $this->label_valign );
                            }
                            $this->tick_label_margin( $aPos - $this->tick_label_margin, $tpos, $label, $this->label_angle, $this->label_para_align );
                        }
                        else
                        {
                            if ( $this->label_halign == "" && $this->label_valign == "" )
                            {
                                $this->img->SetTextAlign( "left", "center" );
                            }
                            else
                            {
                                $this->img->SetTextAlign( $this->label_halign, $this->label_valign );
                            }
                            $this->tick_label_margin( $aPos + $this->tick_label_margin, $tpos, $label, $this->label_angle, $this->label_para_align );
                        }
                    }
                }
                ++$i;
            }
        }
    }

}

class Ticks
{

    public $label_formatstr = "";
    public $label_formfunc = "";
    public $direction = 1;
    public $supress_last = FALSE;
    public $supress_tickmarks = FALSE;
    public $supress_minor_tickmarks = FALSE;
    protected $minor_abs_size = 3;
    protected $major_abs_size = 5;
    protected $scale;
    protected $is_set = FALSE;
    protected $precision;
    protected $supress_zerolabel = FALSE;
    protected $supress_first = FALSE;
    protected $mincolor = "";
    protected $majcolor = "";
    protected $weight = 1;
    protected $label_dateformatstr = "";
    protected $label_usedateformat = FALSE;

    public function Ticks( $aScale )
    {
        $this->scale = $aScale;
        $this->precision = -1;
    }

    public function SetLabelFormat( $aFormatString, $aDate = FALSE )
    {
        $this->label_formatstr = $aFormatString;
        $this->label_usedateformat = $aDate;
    }

    public function SetLabelDateFormat( $aFormatString )
    {
        $this->label_dateformatstr = $aFormatString;
    }

    public function SetFormatCallback( $aCallbackFuncName )
    {
        $this->label_formfunc = $aCallbackFuncName;
    }

    public function SupressZeroLabel( $aFlag = TRUE )
    {
        $this->supress_zerolabel = $aFlag;
    }

    public function SupressMinorTickMarks( $aHide = TRUE )
    {
        $this->supress_minor_tickmarks = $aHide;
    }

    public function SupressTickMarks( $aHide = TRUE )
    {
        $this->supress_tickmarks = $aHide;
    }

    public function SupressFirst( $aHide = TRUE )
    {
        $this->supress_first = $aHide;
    }

    public function SupressLast( $aHide = TRUE )
    {
        $this->supress_last = $aHide;
    }

    public function GetMinTickAbsSize( )
    {
        return $this->minor_abs_size;
    }

    public function GetMajTickAbsSize( )
    {
        return $this->major_abs_size;
    }

    public function SetSize( $aMajSize, $aMinSize = 3 )
    {
        $this->major_abs_size = $aMajSize;
        $this->minor_abs_size = $aMinSize;
    }

    public function IsSpecified( )
    {
        return $this->is_set;
    }

    public function SetPrecision( $aPrecision )
    {
        if ( ERR_DEPRECATED )
        {
            ( 25063 );
        }
        $this->precision = $aPrecision;
    }

    public function SetSide( $aSide )
    {
        $this->direction = $aSide;
    }

    public function SetDirection( $aSide = SIDE_RIGHT )
    {
        $this->direction = $aSide;
    }

    public function SetMarkColor( $aMajorColor, $aMinorColor = "" )
    {
        $this->SetColor( $aMajorColor, $aMinorColor );
    }

    public function SetColor( $aMajorColor, $aMinorColor = "" )
    {
        $this->majcolor = $aMajorColor;
        if ( $aMinorColor == "" )
        {
            $this->mincolor = $aMajorColor;
        }
        else
        {
            $this->mincolor = $aMinorColor;
        }
    }

    public function SetWeight( $aWeight )
    {
        $this->weight = $aWeight;
    }

}

class LinearTicks extends Ticks
{

    public $minor_step = 1;
    public $major_step = 2;
    public $xlabel_offset = 0;
    public $xtick_offset = 0;
    public $maj_ticks_pos = array( );
    public $maj_ticklabels_pos = array( );
    public $ticks_pos = array( );
    public $maj_ticks_label = array( );
    private $label_offset = 0;
    private $text_label_start = 0;
    private $iManualTickPos;
    private $iManualMinTickPos;
    private $iManualTickLabels;

    public function LinearTicks( )
    {
        $this->precision = -1;
    }

    public function GetMajor( )
    {
        return $this->major_step;
    }

    public function GetMinor( )
    {
        return $this->minor_step;
    }

    public function Set( $aMajStep, $aMinStep = FALSE )
    {
        if ( $aMinStep )
        {
            $aMinStep = $aMajStep;
        }
        if ( $aMajStep <= 0 || $aMinStep <= 0 )
        {
            ( 25064 );
        }
        $this->major_step = $aMajStep;
        $this->minor_step = $aMinStep;
        $this->is_set = TRUE;
    }

    public function SetMajTickPositions( $aMajPos, $aLabels = NULL )
    {
        $this->SetTickPositions( $aMajPos, NULL, $aLabels );
    }

    public function SetTickPositions( $aMajPos, $aMinPos = NULL, $aLabels = NULL )
    {
        if ( !is_array( $aMajPos ) || $aMinPos !== NULL && !is_array( $aMinPos ) )
        {
            ( 25065 );
        }
        else
        {
            $n = count( $aMajPos );
            if ( is_array( $aLabels ) && count( $aLabels ) != $n )
            {
                ( 25066 );
            }
            else
            {
                $this->iManualTickPos = $aMajPos;
                $this->iManualMinTickPos = $aMinPos;
                $this->iManualTickLabels = $aLabels;
            }
        }
    }

    public function _doManualTickPos( $aScale )
    {
        $n = count( $this->iManualTickPos );
        $m = count( $this->iManualMinTickPos );
        $doLbl = 0 < count( $this->iManualTickLabels );
        $this->use_manualtickpos = TRUE;
        $this->maj_ticks_pos = array( );
        $this->maj_ticklabels_pos = array( );
        $this->ticks_pos = array( );
        list( $minScale ) = $aScale->scale;
        list( , $maxScale ) = $aScale->scale;
        $j = 0;
        $i = 0;
        for ( ; $i < $n; ++$i )
        {
            if ( isset( $this->iManualTickPos[$i] ) )
            {
                if ( $this->iManualTickPos[$i] < $minScale )
                {
                }
                else
                {
                    continue;
                }
                $this->maj_ticks_pos[$j] = $this->iManualTickPos[$i]( $this->iManualTickPos[$i] );
                $this->maj_ticklabels_pos[$j] = $this->maj_ticks_pos[$j];
                if ( $m <= 0 )
                {
                    $this->ticks_pos[$j] = $this->maj_ticks_pos[$j];
                }
                if ( $doLbl )
                {
                    $this->maj_ticks_label[$j] = $this->iManualTickLabels[$i];
                }
                else
                {
                    $this->maj_ticks_label[$j] = $this->iManualTickPos[$i]( $this->iManualTickPos[$i], $i, $n );
                }
                ++$j;
            }
        }
        if ( count( $this->maj_ticks_pos ) < 2 )
        {
            ( 25067 );
        }
        $j = 0;
        $i = 0;
        for ( ; $i < $m; ++$i )
        {
            if ( empty( $this->iManualMinTickPos[$i] ) || $this->iManualMinTickPos[$i] < $minScale )
            {
            }
            else
            {
                continue;
            }
            $this->ticks_pos[$j] = $this->iManualMinTickPos[$i]( $this->iManualMinTickPos[$i] );
            ++$j;
        }
    }

    public function _doAutoTickPos( $aScale )
    {
        $maj_step_abs = $aScale->scale_factor * $this->major_step;
        $min_step_abs = $aScale->scale_factor * $this->minor_step;
        if ( $min_step_abs == 0 || $maj_step_abs == 0 )
        {
            ( 25068 );
        }
        $limit = ( integer );
        if ( $aScale->textscale )
        {
            $label = ( double ) + $this->text_label_start + $this->label_offset;
            $start_abs = $aScale->scale_factor * $this->text_label_start;
            $nbrmajticks = round( ( $aScale->GetMaxVal( ) - $aScale->GetMinVal( ) - $this->text_label_start ) / $this->major_step ) + 1;
            $x = $aScale->scale_abs[0] + $start_abs + $this->xlabel_offset * $min_step_abs;
            $i = 0;
            for ( ; $label <= $aScale->GetMaxVal( ) + $this->label_offset; ++$i )
            {
                $this->maj_ticks_label[$i] = $this->_doLabelFormat( $label, $i, $nbrmajticks );
                $label += $this->major_step;
                $xtick = $aScale->scale_abs[0] + $start_abs + $this->xtick_offset * $min_step_abs + $i * $maj_step_abs;
                $this->maj_ticks_pos[$i] = $xtick;
                $this->maj_ticklabels_pos[$i] = round( $x );
                $x += $maj_step_abs;
            }
        }
        else
        {
            $label = $aScale->GetMinVal( );
            list( $abs_pos ) = $aScale->scale_abs;
            $j = 0;
            $i = 0;
            $step = round( $maj_step_abs / $min_step_abs );
            if ( $aScale->type == "x" )
            {
                $nbrmajticks = round( ( $aScale->GetMaxVal( ) - $aScale->GetMinVal( ) - $this->text_label_start ) / $this->major_step ) + 1;
                while ( round( $abs_pos ) <= $limit )
                {
                    $this->ticks_pos[] = round( $abs_pos );
                    $this->ticks_label[] = $label;
                    if ( $i % $step == 0 && $j < $nbrmajticks )
                    {
                        $this->maj_ticks_pos[$j] = round( $abs_pos );
                        $this->maj_ticklabels_pos[$j] = round( $abs_pos );
                        $this->maj_ticks_label[$j] = $this->_doLabelFormat( $label, $j, $nbrmajticks );
                        ++$j;
                    }
                    ++$i;
                    $abs_pos += $min_step_abs;
                    $label += $this->minor_step;
                }
            }
            if ( !( $aScale->type == "y" ) )
            {
                break;
            }
            else
            {
                $nbrmajticks = round( ( $aScale->GetMaxVal( ) - $aScale->GetMinVal( ) ) / $this->major_step ) + 1;
            }
            while ( $limit <= round( $abs_pos ) )
            {
                $this->ticks_pos[$i] = round( $abs_pos );
                $this->ticks_label[$i] = $label;
                if ( $i % $step == 0 && $j < $nbrmajticks )
                {
                    $this->maj_ticks_pos[$j] = round( $abs_pos );
                    $this->maj_ticklabels_pos[$j] = round( $abs_pos );
                    $this->maj_ticks_label[$j] = $this->_doLabelFormat( $label, $j, $nbrmajticks );
                    ++$j;
                }
                ++$i;
                $abs_pos += $min_step_abs;
                $label += $this->minor_step;
            }
        }
    }

    public function _doLabelFormat( $aVal, $aIdx, $aNbrTicks )
    {
        if ( $this->precision == -1 )
        {
            $t = log10( $this->minor_step );
            if ( 0 < $t )
            {
                $precision = 0;
            }
            else
            {
                $precision = 0 - floor( $t );
            }
        }
        else
        {
            $precision = $this->precision;
        }
        if ( $this->label_formfunc != "" )
        {
            $f = $this->label_formfunc;
            $l = call_user_func( $f, $aVal );
        }
        else if ( $this->label_formatstr != "" || $this->label_dateformatstr != "" )
        {
            if ( $this->label_usedateformat )
            {
                if ( date( "I", $aVal ) == 1 )
                {
                    $aVal += 3600;
                }
                $l = date( $this->label_formatstr, $aVal );
                if ( $this->label_formatstr == "W" )
                {
                    $l = "w".$l;
                }
            }
            else
            {
                if ( $this->label_dateformatstr !== "" )
                {
                    if ( date( "I", $aVal ) == 1 )
                    {
                        $aVal += 3600;
                    }
                    $l = date( $this->label_dateformatstr, $aVal );
                    if ( $this->label_formatstr == "W" )
                    {
                        $l = "w".$l;
                    }
                }
                else
                {
                    $l = sprintf( $this->label_formatstr, $aVal );
                }
            }
        }
        else
        {
            $l = sprintf( "%01.".$precision."f", round( $aVal, $precision ) );
        }
        if ( !$this->supress_zerolabel || $l == 0 || !$this->supress_first || $aIdx == 0 || $this->supress_last && $aIdx == $aNbrTicks - 1 )
        {
            $l = "";
        }
        return $l;
    }

    public function _StrokeTicks( $aImg, $aScale, $aPos )
    {
        $hor = $aScale->type == "x";
        $this->weight( $this->weight );
        $limit = ( integer );
        if ( $aScale->textscale )
        {
            $yu = $aPos - $this->direction * $this->GetMinTickAbsSize( );
            $xr = $aPos + $this->direction * $this->GetMinTickAbsSize( );
            $n = count( $this->ticks_pos );
            $i = 0;
            for ( ; $i < $n; ++$i )
            {
                if ( $this->supress_tickmarks )
                {
                    if ( $this->supress_minor_tickmarks )
                    {
                        if ( $this->mincolor != "" )
                        {
                            $this->mincolor( $this->mincolor );
                        }
                        if ( $hor )
                        {
                            $this->ticks_pos[$i]( $this->ticks_pos[$i], $aPos, $this->ticks_pos[$i], $yu );
                        }
                        else
                        {
                            $this->ticks_pos[$i]( $aPos, $this->ticks_pos[$i], $xr, $this->ticks_pos[$i] );
                        }
                        if ( $this->mincolor != "" )
                        {
                            $aImg->PopColor( );
                        }
                    }
                }
            }
        }
        $yu = $aPos - $this->direction * $this->GetMajTickAbsSize( );
        $xr = $aPos + $this->direction * $this->GetMajTickAbsSize( );
        $nbrmajticks = round( ( $aScale->GetMaxVal( ) - $aScale->GetMinVal( ) - $this->text_label_start ) / $this->major_step ) + 1;
        $n = count( $this->maj_ticks_pos );
        $i = 0;
        for ( ; $i < $n; ++$i )
        {
            if ( !( 0 < $this->xtick_offset ) || !( $i == $nbrmajticks - 1 ) )
            {
                if ( $this->supress_tickmarks )
                {
                    if ( $this->majcolor != "" )
                    {
                        $this->majcolor( $this->majcolor );
                    }
                    if ( $hor )
                    {
                        $this->maj_ticks_pos[$i]( $this->maj_ticks_pos[$i], $aPos, $this->maj_ticks_pos[$i], $yu );
                    }
                    else
                    {
                        $this->maj_ticks_pos[$i]( $aPos, $this->maj_ticks_pos[$i], $xr, $this->maj_ticks_pos[$i] );
                    }
                    if ( $this->majcolor != "" )
                    {
                        $aImg->PopColor( );
                    }
                }
            }
        }
    }

    public function Stroke( $aImg, $aScale, $aPos )
    {
        if ( $this->iManualTickPos != NULL )
        {
            $this->_doManualTickPos( $aScale );
        }
        else
        {
            $this->_doAutoTickPos( $aScale );
        }
        $this->_StrokeTicks( $aImg, $aScale, $aPos, $aScale->type == "x" );
    }

    public function SetXLabelOffset( $aLabelOff, $aTickOff = -1 )
    {
        $this->xlabel_offset = $aLabelOff;
        if ( $aTickOff == -1 )
        {
            $this->xtick_offset = $aLabelOff;
        }
        else
        {
            $this->xtick_offset = $aTickOff;
        }
        if ( 0 < $aLabelOff )
        {
            $this->SupressLast( );
        }
    }

    public function SetTextLabelStart( $aTextLabelOff )
    {
        $this->text_label_start = $aTextLabelOff;
    }

}

class LinearScale
{

    public $textscale = FALSE;
    public $type;
    public $ticks;
    public $text_scale_off = 0;
    public $scale_abs = array( 0, 0 );
    public $scale_factor;
    public $off;
    public $scale = array( 0, 0 );
    public $name = "lin";
    public $auto_ticks = FALSE;
    public $world_abs_size;
    private $world_size;
    private $autoscale_min = FALSE;
    private $autoscale_max = FALSE;
    private $gracetop = 0;
    private $gracebottom = 0;
    private $intscale = FALSE;

    public function LinearScale( $aMin = 0, $aMax = 0, $aType = "y" )
    {
        assert( $aType == "y" );
        assert( $aMin <= $aMax );
        $this->type = $aType;
        $this->scale = array( $aMin, $aMax );
        $this->world_size = $aMax - $aMin;
        $this->ticks = new LinearTicks( );
    }

    public function IsSpecified( )
    {
        if ( $this->GetMinVal( ) == $this->GetMaxVal( ) )
        {
            return FALSE;
        }
        return TRUE;
    }

    public function SetAutoMin( $aMin )
    {
        $this->autoscale_min = $aMin;
    }

    public function SetAutoMax( $aMax )
    {
        $this->autoscale_max = $aMax;
    }

    public function SetAutoTicks( $aFlag = TRUE )
    {
        $this->auto_ticks = $aFlag;
    }

    public function SetGrace( $aGraceTop, $aGraceBottom = 0 )
    {
        if ( $aGraceTop < 0 || $aGraceBottom < 0 )
        {
            ( 25069 );
        }
        $this->gracetop = $aGraceTop;
        $this->gracebottom = $aGraceBottom;
    }

    public function GetMinVal( )
    {
        return $this->scale[0];
    }

    public function GetMaxVal( )
    {
        return $this->scale[1];
    }

    public function Update( $aImg, $aMin, $aMax )
    {
        $this->scale = array( $aMin, $aMax );
        $this->world_size = $aMax - $aMin;
        $this->InitConstants( $aImg );
    }

    public function Translate( $aCoord )
    {
        if ( is_numeric( $aCoord ) )
        {
            if ( $aCoord != "" && $aCoord != "-" && $aCoord != "x" )
            {
                ( 25070 );
            }
            return 0;
        }
        return $this->off + ( $aCoord - $this->scale[0] ) * $this->scale_factor;
    }

    public function RelTranslate( $aCoord )
    {
        if ( is_numeric( $aCoord ) )
        {
            if ( $aCoord != "" && $aCoord != "-" && $aCoord != "x" )
            {
                ( 25070 );
            }
            return 0;
        }
        return ( $aCoord - $this->scale[0] ) * $this->scale_factor;
    }

    public function SetIntScale( $aIntScale = TRUE )
    {
        $this->intscale = $aIntScale;
    }

    public function IntAutoScale( $img, $min, $max, $maxsteps, $majend = TRUE )
    {
        $min = floor( $min );
        $max = ceil( $max );
        if ( abs( $min - $max ) == 0 )
        {
            --$min;
            ++$max;
        }
        $maxsteps = floor( $maxsteps );
        $gracetop = round( $this->gracetop / 100 * abs( $max - $min ) );
        $gracebottom = round( $this->gracebottom / 100 * abs( $max - $min ) );
        if ( is_numeric( $this->autoscale_min ) )
        {
            $min = ceil( $this->autoscale_min );
            if ( $max <= $min )
            {
                ( 25071 );
            }
        }
        if ( is_numeric( $this->autoscale_max ) )
        {
            $max = ceil( $this->autoscale_max );
            if ( $max <= $min )
            {
                ( 25072 );
            }
        }
        if ( abs( $min - $max ) == 0 )
        {
            ++$max;
            --$min;
        }
        $min -= $gracebottom;
        $max += $gracetop;
        if ( $majend )
        {
            list( $num1steps, $adj1min, $adj1max, $maj1step ) = $this->IntCalcTicks( $maxsteps, $min, $max, 1 );
        }
        else
        {
            $adj1min = $min;
            $adj1max = $max;
            $maj1step = $this->IntCalcTicksFreeze( $maxsteps, $min, $max, 1 )[1];
            $num1steps = $this->IntCalcTicksFreeze( $maxsteps, $min, $max, 1 )[0];
        }
        if ( 2 < abs( $min - $max ) )
        {
            if ( $majend )
            {
                $maj2step = $this->IntCalcTicks( $maxsteps, $min, $max, 5 )[3];
                $adj2max = $this->IntCalcTicks( $maxsteps, $min, $max, 5 )[2];
                $adj2min = $this->IntCalcTicks( $maxsteps, $min, $max, 5 )[1];
                $num2steps = $this->IntCalcTicks( $maxsteps, $min, $max, 5 )[0];
            }
            else
            {
                $adj2min = $min;
                $adj2max = $max;
                $maj2step = $this->IntCalcTicksFreeze( $maxsteps, $min, $max, 5 )[1];
                $num2steps = $this->IntCalcTicksFreeze( $maxsteps, $min, $max, 5 )[0];
            }
        }
        else
        {
            $num2steps = 10000;
        }
        if ( 5 < abs( $min - $max ) )
        {
            if ( $majend )
            {
                $maj5step = $this->IntCalcTicks( $maxsteps, $min, $max, 2 )[3];
                $adj5max = $this->IntCalcTicks( $maxsteps, $min, $max, 2 )[2];
                $adj5min = $this->IntCalcTicks( $maxsteps, $min, $max, 2 )[1];
                $num5steps = $this->IntCalcTicks( $maxsteps, $min, $max, 2 )[0];
            }
            else
            {
                $adj5min = $min;
                $adj5max = $max;
                $maj5step = $this->IntCalcTicksFreeze( $maxsteps, $min, $max, 2 )[1];
                $num5steps = $this->IntCalcTicksFreeze( $maxsteps, $min, $max, 2 )[0];
            }
        }
        else
        {
            $num5steps = 10000;
        }
        $match1 = abs( $num1steps - $maxsteps );
        $match2 = abs( $num2steps - $maxsteps );
        if ( !empty( $maj5step ) && 1 < $maj5step )
        {
            $match5 = abs( $num5steps - $maxsteps );
        }
        else
        {
            $match5 = 10000;
        }
        if ( $match1 < $match2 )
        {
            if ( $match1 < $match5 )
            {
                $r = 1;
            }
            else
            {
                $r = 3;
            }
        }
        else if ( $match2 < $match5 )
        {
            $r = 2;
        }
        else
        {
            $r = 3;
        }
        switch ( $r )
        {
            case 1 :
                $this->ticks->Set( $maj1step, $maj1step );
                $this->Update( $img, $adj1min, $adj1max );
                return;
            case 2 :
                $this->ticks->Set( $maj2step, $maj2step );
                $this->Update( $img, $adj2min, $adj2max );
                return;
            case 3 :
                $this->ticks->Set( $maj5step, $maj5step );
                $this->Update( $img, $adj5min, $adj5max );
                return;
        }
        ( 25073, $r );
    }

    public function AutoScale( $img, $min, $max, $maxsteps, $majend = TRUE )
    {
        if ( $this->intscale )
        {
            $this->IntAutoScale( $img, $min, $max, $maxsteps, $majend );
        }
        else
        {
            if ( abs( $min - $max ) < 1e-005 )
            {
                if ( $min == 0 && $max == 0 )
                {
                    $min = -1;
                    $max = 1;
                }
                else
                {
                    $delta = ( abs( $max ) + abs( $min ) ) * 0.005;
                    $min -= $delta;
                    $max += $delta;
                }
            }
            $gracetop = $this->gracetop / 100 * abs( $max - $min );
            $gracebottom = $this->gracebottom / 100 * abs( $max - $min );
            if ( is_numeric( $this->autoscale_min ) )
            {
                $min = $this->autoscale_min;
                if ( $max <= $min )
                {
                    ( 25071 );
                }
                if ( abs( $min - $max ) < 1e-005 )
                {
                    $max *= 1.2;
                }
            }
            if ( is_numeric( $this->autoscale_max ) )
            {
                $max = $this->autoscale_max;
                if ( $max <= $min )
                {
                    ( 25072 );
                }
                if ( abs( $min - $max ) < 1e-005 )
                {
                    $min *= 0.8;
                }
            }
            $min -= $gracebottom;
            $max += $gracetop;
            if ( $majend )
            {
                $maj1step = $this->CalcTicks( $maxsteps, $min, $max, 1, 2 )[4];
                $min1step = $this->CalcTicks( $maxsteps, $min, $max, 1, 2 )[3];
                $adj1max = $this->CalcTicks( $maxsteps, $min, $max, 1, 2 )[2];
                $adj1min = $this->CalcTicks( $maxsteps, $min, $max, 1, 2 )[1];
                $num1steps = $this->CalcTicks( $maxsteps, $min, $max, 1, 2 )[0];
            }
            else
            {
                $adj1min = $min;
                $adj1max = $max;
                $maj1step = $this->CalcTicksFreeze( $maxsteps, $min, $max, 1, 2, FALSE )[2];
                $min1step = $this->CalcTicksFreeze( $maxsteps, $min, $max, 1, 2, FALSE )[1];
                $num1steps = $this->CalcTicksFreeze( $maxsteps, $min, $max, 1, 2, FALSE )[0];
            }
            if ( $majend )
            {
                $maj2step = $this->CalcTicks( $maxsteps, $min, $max, 5, 2 )[4];
                $min2step = $this->CalcTicks( $maxsteps, $min, $max, 5, 2 )[3];
                $adj2max = $this->CalcTicks( $maxsteps, $min, $max, 5, 2 )[2];
                $adj2min = $this->CalcTicks( $maxsteps, $min, $max, 5, 2 )[1];
                $num2steps = $this->CalcTicks( $maxsteps, $min, $max, 5, 2 )[0];
            }
            else
            {
                $adj2min = $min;
                $adj2max = $max;
                $maj2step = $this->CalcTicksFreeze( $maxsteps, $min, $max, 5, 2, FALSE )[2];
                $min2step = $this->CalcTicksFreeze( $maxsteps, $min, $max, 5, 2, FALSE )[1];
                $num2steps = $this->CalcTicksFreeze( $maxsteps, $min, $max, 5, 2, FALSE )[0];
            }
            if ( $majend )
            {
                $maj5step = $this->CalcTicks( $maxsteps, $min, $max, 2, 5 )[4];
                $min5step = $this->CalcTicks( $maxsteps, $min, $max, 2, 5 )[3];
                $adj5max = $this->CalcTicks( $maxsteps, $min, $max, 2, 5 )[2];
                $adj5min = $this->CalcTicks( $maxsteps, $min, $max, 2, 5 )[1];
                $num5steps = $this->CalcTicks( $maxsteps, $min, $max, 2, 5 )[0];
            }
            else
            {
                $adj5min = $min;
                $adj5max = $max;
                $maj5step = $this->CalcTicksFreeze( $maxsteps, $min, $max, 2, 5, FALSE )[2];
                $min5step = $this->CalcTicksFreeze( $maxsteps, $min, $max, 2, 5, FALSE )[1];
                $num5steps = $this->CalcTicksFreeze( $maxsteps, $min, $max, 2, 5, FALSE )[0];
            }
            $match1 = abs( $num1steps - $maxsteps );
            $match2 = abs( $num2steps - $maxsteps );
            $match5 = abs( $num5steps - $maxsteps );
            $r = $this->MatchMin3( $match1, $match2, $match5, 0.8 );
            switch ( $r )
            {
                case 1 :
                    $this->Update( $img, $adj1min, $adj1max );
                    $this->ticks->Set( $maj1step, $min1step );
                    return;
                case 2 :
                    $this->Update( $img, $adj2min, $adj2max );
                    $this->ticks->Set( $maj2step, $min2step );
                    return;
                case 3 :
                    $this->Update( $img, $adj5min, $adj5max );
                    $this->ticks->Set( $maj5step, $min5step );
            }
        }
    }

    public function InitConstants( $img )
    {
        if ( $this->type == "x" )
        {
            $this->world_abs_size = $img->width - $img->left_margin - $img->right_margin;
            $this->off = $img->left_margin;
            $this->scale_factor = 0;
            if ( 0 < $this->world_size )
            {
                $this->scale_factor = $this->world_abs_size / ( $this->world_size * 1 );
            }
        }
        else
        {
            $this->world_abs_size = $img->height - $img->top_margin - $img->bottom_margin;
            $this->off = $img->top_margin + $this->world_abs_size;
            $this->scale_factor = 0;
            if ( 0 < $this->world_size )
            {
                $this->scale_factor = 0 - $this->world_abs_size / ( $this->world_size * 1 );
            }
        }
        $size = $this->world_size * $this->scale_factor;
        $this->scale_abs = array( $this->off, $this->off + $size );
    }

    public function SetConstants( $aStart, $aLen )
    {
        $this->world_abs_size = $aLen;
        $this->off = $aStart;
        if ( $this->world_size <= 0 )
        {
            ( 25074 );
        }
        $this->scale_factor = $this->world_abs_size / ( $this->world_size * 1 );
        $this->scale_abs = array( $this->off, $this->off + $this->world_size * $this->scale_factor );
    }

    public function CalcTicks( $maxsteps, $min, $max, $a, $b, $majend = TRUE )
    {
        $diff = $max - $min;
        if ( $diff == 0 )
        {
            $ld = 0;
        }
        else
        {
            $ld = floor( log10( $diff ) );
        }
        if ( 0 < $min && $min < pow( 10, $ld ) )
        {
            $min = 0;
        }
        $majstep = pow( 10, $ld ) / $a;
        $minstep = $majstep / $b;
        $adjmax = ceil( $max / $minstep ) * $minstep;
        $adjmin = floor( $min / $minstep ) * $minstep;
        $adjdiff = $adjmax - $adjmin;
        $numsteps = $adjdiff / $majstep;
        while ( $maxsteps < $numsteps )
        {
            $majstep = pow( 10, $ld ) / $a;
            $numsteps = $adjdiff / $majstep;
            ++$ld;
        }
        $minstep = $majstep / $b;
        $adjmin = floor( $min / $minstep ) * $minstep;
        $adjdiff = $adjmax - $adjmin;
        if ( $majend )
        {
            $adjmin = floor( $min / $majstep ) * $majstep;
            $adjdiff = $adjmax - $adjmin;
            $adjmax = ceil( $adjdiff / $majstep ) * $majstep + $adjmin;
        }
        else
        {
            $adjmax = ceil( $max / $minstep ) * $minstep;
        }
        return array( $numsteps, $adjmin, $adjmax, $minstep, $majstep );
    }

    public function CalcTicksFreeze( $maxsteps, $min, $max, $a, $b )
    {
        $diff = $max - $min;
        if ( $diff == 0 )
        {
            $ld = 0;
        }
        else
        {
            $ld = floor( log10( $diff ) );
        }
        $majstep = pow( 10, $ld ) / $a;
        $minstep = $majstep / $b;
        $numsteps = floor( $diff / $majstep );
        while ( $maxsteps < $numsteps )
        {
            $majstep = pow( 10, $ld ) / $a;
            $numsteps = floor( $diff / $majstep );
            ++$ld;
        }
        $minstep = $majstep / $b;
        return array( $numsteps, $minstep, $majstep );
    }

    public function IntCalcTicks( $maxsteps, $min, $max, $a, $majend = TRUE )
    {
        $diff = $max - $min;
        if ( $diff == 0 )
        {
            ( 25075 );
        }
        else
        {
            $ld = floor( log10( $diff ) );
        }
        if ( 0 < $min && $min < pow( 10, $ld ) )
        {
            $min = 0;
        }
        if ( $ld == 0 )
        {
            $ld = 1;
        }
        if ( $a == 1 )
        {
            $majstep = 1;
        }
        else
        {
            $majstep = pow( 10, $ld ) / $a;
        }
        $adjmax = ceil( $max / $majstep ) * $majstep;
        $adjmin = floor( $min / $majstep ) * $majstep;
        $adjdiff = $adjmax - $adjmin;
        $numsteps = $adjdiff / $majstep;
        while ( $maxsteps < $numsteps )
        {
            $majstep = pow( 10, $ld ) / $a;
            $numsteps = $adjdiff / $majstep;
            ++$ld;
        }
        $adjmin = floor( $min / $majstep ) * $majstep;
        $adjdiff = $adjmax - $adjmin;
        if ( $majend )
        {
            $adjmin = floor( $min / $majstep ) * $majstep;
            $adjdiff = $adjmax - $adjmin;
            $adjmax = ceil( $adjdiff / $majstep ) * $majstep + $adjmin;
        }
        else
        {
            $adjmax = ceil( $max / $majstep ) * $majstep;
        }
        return array( $numsteps, $adjmin, $adjmax, $majstep );
    }

    public function IntCalcTicksFreeze( $maxsteps, $min, $max, $a )
    {
        $diff = $max - $min;
        if ( $diff == 0 )
        {
            ( 25075 );
        }
        else
        {
            $ld = floor( log10( $diff ) );
        }
        if ( $ld == 0 )
        {
            $ld = 1;
        }
        if ( $a == 1 )
        {
            $majstep = 1;
        }
        else
        {
            $majstep = pow( 10, $ld ) / $a;
        }
        $numsteps = floor( $diff / $majstep );
        while ( $maxsteps < $numsteps )
        {
            $majstep = pow( 10, $ld ) / $a;
            $numsteps = floor( $diff / $majstep );
            ++$ld;
        }
        return array( $numsteps, $majstep );
    }

    public function MatchMin3( $a, $b, $c, $weight )
    {
        if ( $a < $b )
        {
            if ( $a < $c * $weight )
            {
                return 1;
            }
            return 3;
        }
        if ( $b < $c * $weight )
        {
            return 2;
        }
        return 3;
    }

}

class RGB
{

    public $rgb_table;
    public $img;

    public function RGB( $aImg = NULL )
    {
        $this->img = $aImg;
        $this->rgb_table = array( "aqua" => array( 0, 255, 255 ), "lime" => array( 0, 255, 0 ), "teal" => array( 0, 128, 128 ), "whitesmoke" => array( 245, 245, 245 ), "gainsboro" => array( 220, 220, 220 ), "oldlace" => array( 253, 245, 230 ), "linen" => array( 250, 240, 230 ), "antiquewhite" => array( 250, 235, 215 ), "papayawhip" => array( 255, 239, 213 ), "blanchedalmond" => array( 255, 235, 205 ), "bisque" => array( 255, 228, 196 ), "peachpuff" => array( 255, 218, 185 ), "navajowhite" => array( 255, 222, 173 ), "moccasin" => array( 255, 228, 181 ), "cornsilk" => array( 255, 248, 220 ), "ivory" => array( 255, 255, 240 ), "lemonchiffon" => array( 255, 250, 205 ), "seashell" => array( 255, 245, 238 ), "mintcream" => array( 245, 255, 250 ), "azure" => array( 240, 255, 255 ), "aliceblue" => array( 240, 248, 255 ), "lavender" => array( 230, 230, 250 ), "lavenderblush" => array( 255, 240, 245 ), "mistyrose" => array( 255, 228, 225 ), "white" => array( 255, 255, 255 ), "black" => array( 0, 0, 0 ), "darkslategray" => array( 47, 79, 79 ), "dimgray" => array( 105, 105, 105 ), "slategray" => array( 112, 128, 144 ), "lightslategray" => array( 119, 136, 153 ), "gray" => array( 190, 190, 190 ), "lightgray" => array( 211, 211, 211 ), "midnightblue" => array( 25, 25, 112 ), "navy" => array( 0, 0, 128 ), "cornflowerblue" => array( 100, 149, 237 ), "darkslateblue" => array( 72, 61, 139 ), "slateblue" => array( 106, 90, 205 ), "mediumslateblue" => array( 123, 104, 238 ), "lightslateblue" => array( 132, 112, 255 ), "mediumblue" => array( 0, 0, 205 ), "royalblue" => array( 65, 105, 225 ), "blue" => array( 0, 0, 255 ), "dodgerblue" => array( 30, 144, 255 ), "deepskyblue" => array( 0, 191, 255 ), "skyblue" => array( 135, 206, 235 ), "lightskyblue" => array( 135, 206, 250 ), "steelblue" => array( 70, 130, 180 ), "lightred" => array( 211, 167, 168 ), "lightsteelblue" => array( 176, 196, 222 ), "lightblue" => array( 173, 216, 230 ), "powderblue" => array( 176, 224, 230 ), "paleturquoise" => array( 175, 238, 238 ), "darkturquoise" => array( 0, 206, 209 ), "mediumturquoise" => array( 72, 209, 204 ), "turquoise" => array( 64, 224, 208 ), "cyan" => array( 0, 255, 255 ), "lightcyan" => array( 224, 255, 255 ), "cadetblue" => array( 95, 158, 160 ), "mediumaquamarine" => array( 102, 205, 170 ), "aquamarine" => array( 127, 255, 212 ), "darkgreen" => array( 0, 100, 0 ), "darkolivegreen" => array( 85, 107, 47 ), "darkseagreen" => array( 143, 188, 143 ), "seagreen" => array( 46, 139, 87 ), "mediumseagreen" => array( 60, 179, 113 ), "lightseagreen" => array( 32, 178, 170 ), "palegreen" => array( 152, 251, 152 ), "springgreen" => array( 0, 255, 127 ), "lawngreen" => array( 124, 252, 0 ), "green" => array( 0, 255, 0 ), "chartreuse" => array( 127, 255, 0 ), "mediumspringgreen" => array( 0, 250, 154 ), "greenyellow" => array( 173, 255, 47 ), "limegreen" => array( 50, 205, 50 ), "yellowgreen" => array( 154, 205, 50 ), "forestgreen" => array( 34, 139, 34 ), "olivedrab" => array( 107, 142, 35 ), "darkkhaki" => array( 189, 183, 107 ), "khaki" => array( 240, 230, 140 ), "palegoldenrod" => array( 238, 232, 170 ), "lightgoldenrodyellow" => array( 250, 250, 210 ), "lightyellow" => array( 255, 255, 200 ), "yellow" => array( 255, 255, 0 ), "gold" => array( 255, 215, 0 ), "lightgoldenrod" => array( 238, 221, 130 ), "goldenrod" => array( 218, 165, 32 ), "darkgoldenrod" => array( 184, 134, 11 ), "rosybrown" => array( 188, 143, 143 ), "indianred" => array( 205, 92, 92 ), "saddlebrown" => array( 139, 69, 19 ), "sienna" => array( 160, 82, 45 ), "peru" => array( 205, 133, 63 ), "burlywood" => array( 222, 184, 135 ), "beige" => array( 245, 245, 220 ), "wheat" => array( 245, 222, 179 ), "sandybrown" => array( 244, 164, 96 ), "tan" => array( 210, 180, 140 ), "chocolate" => array( 210, 105, 30 ), "firebrick" => array( 178, 34, 34 ), "brown" => array( 165, 42, 42 ), "darksalmon" => array( 233, 150, 122 ), "salmon" => array( 250, 128, 114 ), "lightsalmon" => array( 255, 160, 122 ), "orange" => array( 255, 165, 0 ), "darkorange" => array( 255, 140, 0 ), "coral" => array( 255, 127, 80 ), "lightcoral" => array( 240, 128, 128 ), "tomato" => array( 255, 99, 71 ), "orangered" => array( 255, 69, 0 ), "red" => array( 255, 0, 0 ), "hotpink" => array( 255, 105, 180 ), "deeppink" => array( 255, 20, 147 ), "pink" => array( 255, 192, 203 ), "lightpink" => array( 255, 182, 193 ), "palevioletred" => array( 219, 112, 147 ), "maroon" => array( 176, 48, 96 ), "mediumvioletred" => array( 199, 21, 133 ), "violetred" => array( 208, 32, 144 ), "magenta" => array( 255, 0, 255 ), "violet" => array( 238, 130, 238 ), "plum" => array( 221, 160, 221 ), "orchid" => array( 218, 112, 214 ), "mediumorchid" => array( 186, 85, 211 ), "darkorchid" => array( 153, 50, 204 ), "darkviolet" => array( 148, 0, 211 ), "blueviolet" => array( 138, 43, 226 ), "purple" => array( 160, 32, 240 ), "mediumpurple" => array( 147, 112, 219 ), "thistle" => array( 216, 191, 216 ), "snow1" => array( 255, 250, 250 ), "snow2" => array( 238, 233, 233 ), "snow3" => array( 205, 201, 201 ), "snow4" => array( 139, 137, 137 ), "seashell1" => array( 255, 245, 238 ), "seashell2" => array( 238, 229, 222 ), "seashell3" => array( 205, 197, 191 ), "seashell4" => array( 139, 134, 130 ), "AntiqueWhite1" => array( 255, 239, 219 ), "AntiqueWhite2" => array( 238, 223, 204 ), "AntiqueWhite3" => array( 205, 192, 176 ), "AntiqueWhite4" => array( 139, 131, 120 ), "bisque1" => array( 255, 228, 196 ), "bisque2" => array( 238, 213, 183 ), "bisque3" => array( 205, 183, 158 ), "bisque4" => array( 139, 125, 107 ), "peachPuff1" => array( 255, 218, 185 ), "peachpuff2" => array( 238, 203, 173 ), "peachpuff3" => array( 205, 175, 149 ), "peachpuff4" => array( 139, 119, 101 ), "navajowhite1" => array( 255, 222, 173 ), "navajowhite2" => array( 238, 207, 161 ), "navajowhite3" => array( 205, 179, 139 ), "navajowhite4" => array( 139, 121, 94 ), "lemonchiffon1" => array( 255, 250, 205 ), "lemonchiffon2" => array( 238, 233, 191 ), "lemonchiffon3" => array( 205, 201, 165 ), "lemonchiffon4" => array( 139, 137, 112 ), "ivory1" => array( 255, 255, 240 ), "ivory2" => array( 238, 238, 224 ), "ivory3" => array( 205, 205, 193 ), "ivory4" => array( 139, 139, 131 ), "honeydew" => array( 193, 205, 193 ), "lavenderblush1" => array( 255, 240, 245 ), "lavenderblush2" => array( 238, 224, 229 ), "lavenderblush3" => array( 205, 193, 197 ), "lavenderblush4" => array( 139, 131, 134 ), "mistyrose1" => array( 255, 228, 225 ), "mistyrose2" => array( 238, 213, 210 ), "mistyrose3" => array( 205, 183, 181 ), "mistyrose4" => array( 139, 125, 123 ), "azure1" => array( 240, 255, 255 ), "azure2" => array( 224, 238, 238 ), "azure3" => array( 193, 205, 205 ), "azure4" => array( 131, 139, 139 ), "slateblue1" => array( 131, 111, 255 ), "slateblue2" => array( 122, 103, 238 ), "slateblue3" => array( 105, 89, 205 ), "slateblue4" => array( 71, 60, 139 ), "royalblue1" => array( 72, 118, 255 ), "royalblue2" => array( 67, 110, 238 ), "royalblue3" => array( 58, 95, 205 ), "royalblue4" => array( 39, 64, 139 ), "dodgerblue1" => array( 30, 144, 255 ), "dodgerblue2" => array( 28, 134, 238 ), "dodgerblue3" => array( 24, 116, 205 ), "dodgerblue4" => array( 16, 78, 139 ), "steelblue1" => array( 99, 184, 255 ), "steelblue2" => array( 92, 172, 238 ), "steelblue3" => array( 79, 148, 205 ), "steelblue4" => array( 54, 100, 139 ), "deepskyblue1" => array( 0, 191, 255 ), "deepskyblue2" => array( 0, 178, 238 ), "deepskyblue3" => array( 0, 154, 205 ), "deepskyblue4" => array( 0, 104, 139 ), "skyblue1" => array( 135, 206, 255 ), "skyblue2" => array( 126, 192, 238 ), "skyblue3" => array( 108, 166, 205 ), "skyblue4" => array( 74, 112, 139 ), "lightskyblue1" => array( 176, 226, 255 ), "lightskyblue2" => array( 164, 211, 238 ), "lightskyblue3" => array( 141, 182, 205 ), "lightskyblue4" => array( 96, 123, 139 ), "slategray1" => array( 198, 226, 255 ), "slategray2" => array( 185, 211, 238 ), "slategray3" => array( 159, 182, 205 ), "slategray4" => array( 108, 123, 139 ), "lightsteelblue1" => array( 202, 225, 255 ), "lightsteelblue2" => array( 188, 210, 238 ), "lightsteelblue3" => array( 162, 181, 205 ), "lightsteelblue4" => array( 110, 123, 139 ), "lightblue1" => array( 191, 239, 255 ), "lightblue2" => array( 178, 223, 238 ), "lightblue3" => array( 154, 192, 205 ), "lightblue4" => array( 104, 131, 139 ), "lightcyan1" => array( 224, 255, 255 ), "lightcyan2" => array( 209, 238, 238 ), "lightcyan3" => array( 180, 205, 205 ), "lightcyan4" => array( 122, 139, 139 ), "paleturquoise1" => array( 187, 255, 255 ), "paleturquoise2" => array( 174, 238, 238 ), "paleturquoise3" => array( 150, 205, 205 ), "paleturquoise4" => array( 102, 139, 139 ), "cadetblue1" => array( 152, 245, 255 ), "cadetblue2" => array( 142, 229, 238 ), "cadetblue3" => array( 122, 197, 205 ), "cadetblue4" => array( 83, 134, 139 ), "turquoise1" => array( 0, 245, 255 ), "turquoise2" => array( 0, 229, 238 ), "turquoise3" => array( 0, 197, 205 ), "turquoise4" => array( 0, 134, 139 ), "cyan1" => array( 0, 255, 255 ), "cyan2" => array( 0, 238, 238 ), "cyan3" => array( 0, 205, 205 ), "cyan4" => array( 0, 139, 139 ), "darkslategray1" => array( 151, 255, 255 ), "darkslategray2" => array( 141, 238, 238 ), "darkslategray3" => array( 121, 205, 205 ), "darkslategray4" => array( 82, 139, 139 ), "aquamarine1" => array( 127, 255, 212 ), "aquamarine2" => array( 118, 238, 198 ), "aquamarine3" => array( 102, 205, 170 ), "aquamarine4" => array( 69, 139, 116 ), "darkseagreen1" => array( 193, 255, 193 ), "darkseagreen2" => array( 180, 238, 180 ), "darkseagreen3" => array( 155, 205, 155 ), "darkseagreen4" => array( 105, 139, 105 ), "seagreen1" => array( 84, 255, 159 ), "seagreen2" => array( 78, 238, 148 ), "seagreen3" => array( 67, 205, 128 ), "seagreen4" => array( 46, 139, 87 ), "palegreen1" => array( 154, 255, 154 ), "palegreen2" => array( 144, 238, 144 ), "palegreen3" => array( 124, 205, 124 ), "palegreen4" => array( 84, 139, 84 ), "springgreen1" => array( 0, 255, 127 ), "springgreen2" => array( 0, 238, 118 ), "springgreen3" => array( 0, 205, 102 ), "springgreen4" => array( 0, 139, 69 ), "chartreuse1" => array( 127, 255, 0 ), "chartreuse2" => array( 118, 238, 0 ), "chartreuse3" => array( 102, 205, 0 ), "chartreuse4" => array( 69, 139, 0 ), "olivedrab1" => array( 192, 255, 62 ), "olivedrab2" => array( 179, 238, 58 ), "olivedrab3" => array( 154, 205, 50 ), "olivedrab4" => array( 105, 139, 34 ), "darkolivegreen1" => array( 202, 255, 112 ), "darkolivegreen2" => array( 188, 238, 104 ), "darkolivegreen3" => array( 162, 205, 90 ), "darkolivegreen4" => array( 110, 139, 61 ), "khaki1" => array( 255, 246, 143 ), "khaki2" => array( 238, 230, 133 ), "khaki3" => array( 205, 198, 115 ), "khaki4" => array( 139, 134, 78 ), "lightgoldenrod1" => array( 255, 236, 139 ), "lightgoldenrod2" => array( 238, 220, 130 ), "lightgoldenrod3" => array( 205, 190, 112 ), "lightgoldenrod4" => array( 139, 129, 76 ), "yellow1" => array( 255, 255, 0 ), "yellow2" => array( 238, 238, 0 ), "yellow3" => array( 205, 205, 0 ), "yellow4" => array( 139, 139, 0 ), "gold1" => array( 255, 215, 0 ), "gold2" => array( 238, 201, 0 ), "gold3" => array( 205, 173, 0 ), "gold4" => array( 139, 117, 0 ), "goldenrod1" => array( 255, 193, 37 ), "goldenrod2" => array( 238, 180, 34 ), "goldenrod3" => array( 205, 155, 29 ), "goldenrod4" => array( 139, 105, 20 ), "darkgoldenrod1" => array( 255, 185, 15 ), "darkgoldenrod2" => array( 238, 173, 14 ), "darkgoldenrod3" => array( 205, 149, 12 ), "darkgoldenrod4" => array( 139, 101, 8 ), "rosybrown1" => array( 255, 193, 193 ), "rosybrown2" => array( 238, 180, 180 ), "rosybrown3" => array( 205, 155, 155 ), "rosybrown4" => array( 139, 105, 105 ), "indianred1" => array( 255, 106, 106 ), "indianred2" => array( 238, 99, 99 ), "indianred3" => array( 205, 85, 85 ), "indianred4" => array( 139, 58, 58 ), "sienna1" => array( 255, 130, 71 ), "sienna2" => array( 238, 121, 66 ), "sienna3" => array( 205, 104, 57 ), "sienna4" => array( 139, 71, 38 ), "burlywood1" => array( 255, 211, 155 ), "burlywood2" => array( 238, 197, 145 ), "burlywood3" => array( 205, 170, 125 ), "burlywood4" => array( 139, 115, 85 ), "wheat1" => array( 255, 231, 186 ), "wheat2" => array( 238, 216, 174 ), "wheat3" => array( 205, 186, 150 ), "wheat4" => array( 139, 126, 102 ), "tan1" => array( 255, 165, 79 ), "tan2" => array( 238, 154, 73 ), "tan3" => array( 205, 133, 63 ), "tan4" => array( 139, 90, 43 ), "chocolate1" => array( 255, 127, 36 ), "chocolate2" => array( 238, 118, 33 ), "chocolate3" => array( 205, 102, 29 ), "chocolate4" => array( 139, 69, 19 ), "firebrick1" => array( 255, 48, 48 ), "firebrick2" => array( 238, 44, 44 ), "firebrick3" => array( 205, 38, 38 ), "firebrick4" => array( 139, 26, 26 ), "brown1" => array( 255, 64, 64 ), "brown2" => array( 238, 59, 59 ), "brown3" => array( 205, 51, 51 ), "brown4" => array( 139, 35, 35 ), "salmon1" => array( 255, 140, 105 ), "salmon2" => array( 238, 130, 98 ), "salmon3" => array( 205, 112, 84 ), "salmon4" => array( 139, 76, 57 ), "lightsalmon1" => array( 255, 160, 122 ), "lightsalmon2" => array( 238, 149, 114 ), "lightsalmon3" => array( 205, 129, 98 ), "lightsalmon4" => array( 139, 87, 66 ), "orange1" => array( 255, 165, 0 ), "orange2" => array( 238, 154, 0 ), "orange3" => array( 205, 133, 0 ), "orange4" => array( 139, 90, 0 ), "darkorange1" => array( 255, 127, 0 ), "darkorange2" => array( 238, 118, 0 ), "darkorange3" => array( 205, 102, 0 ), "darkorange4" => array( 139, 69, 0 ), "coral1" => array( 255, 114, 86 ), "coral2" => array( 238, 106, 80 ), "coral3" => array( 205, 91, 69 ), "coral4" => array( 139, 62, 47 ), "tomato1" => array( 255, 99, 71 ), "tomato2" => array( 238, 92, 66 ), "tomato3" => array( 205, 79, 57 ), "tomato4" => array( 139, 54, 38 ), "orangered1" => array( 255, 69, 0 ), "orangered2" => array( 238, 64, 0 ), "orangered3" => array( 205, 55, 0 ), "orangered4" => array( 139, 37, 0 ), "deeppink1" => array( 255, 20, 147 ), "deeppink2" => array( 238, 18, 137 ), "deeppink3" => array( 205, 16, 118 ), "deeppink4" => array( 139, 10, 80 ), "hotpink1" => array( 255, 110, 180 ), "hotpink2" => array( 238, 106, 167 ), "hotpink3" => array( 205, 96, 144 ), "hotpink4" => array( 139, 58, 98 ), "pink1" => array( 255, 181, 197 ), "pink2" => array( 238, 169, 184 ), "pink3" => array( 205, 145, 158 ), "pink4" => array( 139, 99, 108 ), "lightpink1" => array( 255, 174, 185 ), "lightpink2" => array( 238, 162, 173 ), "lightpink3" => array( 205, 140, 149 ), "lightpink4" => array( 139, 95, 101 ), "palevioletred1" => array( 255, 130, 171 ), "palevioletred2" => array( 238, 121, 159 ), "palevioletred3" => array( 205, 104, 137 ), "palevioletred4" => array( 139, 71, 93 ), "maroon1" => array( 255, 52, 179 ), "maroon2" => array( 238, 48, 167 ), "maroon3" => array( 205, 41, 144 ), "maroon4" => array( 139, 28, 98 ), "violetred1" => array( 255, 62, 150 ), "violetred2" => array( 238, 58, 140 ), "violetred3" => array( 205, 50, 120 ), "violetred4" => array( 139, 34, 82 ), "magenta1" => array( 255, 0, 255 ), "magenta2" => array( 238, 0, 238 ), "magenta3" => array( 205, 0, 205 ), "magenta4" => array( 139, 0, 139 ), "mediumred" => array( 140, 34, 34 ), "orchid1" => array( 255, 131, 250 ), "orchid2" => array( 238, 122, 233 ), "orchid3" => array( 205, 105, 201 ), "orchid4" => array( 139, 71, 137 ), "plum1" => array( 255, 187, 255 ), "plum2" => array( 238, 174, 238 ), "plum3" => array( 205, 150, 205 ), "plum4" => array( 139, 102, 139 ), "mediumorchid1" => array( 224, 102, 255 ), "mediumorchid2" => array( 209, 95, 238 ), "mediumorchid3" => array( 180, 82, 205 ), "mediumorchid4" => array( 122, 55, 139 ), "darkorchid1" => array( 191, 62, 255 ), "darkorchid2" => array( 178, 58, 238 ), "darkorchid3" => array( 154, 50, 205 ), "darkorchid4" => array( 104, 34, 139 ), "purple1" => array( 155, 48, 255 ), "purple2" => array( 145, 44, 238 ), "purple3" => array( 125, 38, 205 ), "purple4" => array( 85, 26, 139 ), "mediumpurple1" => array( 171, 130, 255 ), "mediumpurple2" => array( 159, 121, 238 ), "mediumpurple3" => array( 137, 104, 205 ), "mediumpurple4" => array( 93, 71, 139 ), "thistle1" => array( 255, 225, 255 ), "thistle2" => array( 238, 210, 238 ), "thistle3" => array( 205, 181, 205 ), "thistle4" => array( 139, 123, 139 ), "gray1" => array( 10, 10, 10 ), "gray2" => array( 40, 40, 30 ), "gray3" => array( 70, 70, 70 ), "gray4" => array( 100, 100, 100 ), "gray5" => array( 130, 130, 130 ), "gray6" => array( 160, 160, 160 ), "gray7" => array( 190, 190, 190 ), "gray8" => array( 210, 210, 210 ), "gray9" => array( 240, 240, 240 ), "darkgray" => array( 100, 100, 100 ), "darkblue" => array( 0, 0, 139 ), "darkcyan" => array( 0, 139, 139 ), "darkmagenta" => array( 139, 0, 139 ), "darkred" => array( 139, 0, 0 ), "silver" => array( 192, 192, 192 ), "eggplant" => array( 144, 176, 168 ), "lightgreen" => array( 144, 238, 144 ) );
    }

    public function Color( $aColor )
    {
        if ( is_string( $aColor ) )
        {
            $pos = strpos( $aColor, "@" );
            if ( $pos === FALSE )
            {
                $alpha = 0;
            }
            else
            {
                $pos2 = strpos( $aColor, ":" );
                if ( $pos2 === FALSE )
                {
                    $pos2 = $pos - 1;
                }
                if ( $pos2 < $pos )
                {
                    $alpha = substr( $aColor, $pos + 1 );
                    $aColor = substr( $aColor, 0, $pos );
                }
                else
                {
                    $alpha = substr( $aColor, $pos + 1, $pos2 - $pos - 1 );
                    $aColor = substr( $aColor, 0, $pos ).substr( $aColor, $pos2 );
                }
            }
            $pos = strpos( $aColor, ":" );
            if ( $pos === FALSE )
            {
                $adj = 1;
            }
            else
            {
                $adj = 0 + substr( $aColor, $pos + 1 );
                $aColor = substr( $aColor, 0, $pos );
            }
            if ( $adj < 0 )
            {
                ( 25077 );
            }
            if ( substr( $aColor, 0, 1 ) == "#" )
            {
                $r = hexdec( substr( $aColor, 1, 2 ) );
                $g = hexdec( substr( $aColor, 3, 2 ) );
                $b = hexdec( substr( $aColor, 5, 2 ) );
            }
            else
            {
                if ( isset( $this->rgb_table[$aColor] ) )
                {
                    ( 25078, $aColor );
                }
                $tmp = $this->rgb_table[$aColor];
                $r = $tmp[0];
                $g = $tmp[1];
                $b = $tmp[2];
            }
            if ( 1 < $adj )
            {
                $m = ( $adj - 1 ) * ( 255 - min( 255, min( $r, min( $g, $b ) ) ) );
                return array( min( 255, $r + $m ), min( 255, $g + $m ), min( 255, $b + $m ), $alpha );
            }
            if ( $adj < 1 )
            {
                $m = ( $adj - 1 ) * max( 255, max( $r, max( $g, $b ) ) );
                return array( max( 0, $r + $m ), max( 0, $g + $m ), max( 0, $b + $m ), $alpha );
            }
            return array( $r, $g, $b, $alpha );
        }
        if ( is_array( $aColor ) )
        {
            if ( count( $aColor ) == 3 )
            {
                $aColor[3] = 0;
                return $aColor;
            }
            return $aColor;
        }
        ( 25079, $aColor, count( $aColor ) );
    }

    public function Equal( $aCol1, $aCol2 )
    {
        $c1 = $this->Color( $aCol1 );
        $c2 = $this->Color( $aCol2 );
        if ( $c1[0] == $c2[0] && $c1[1] == $c2[1] && $c1[2] == $c2[2] )
        {
            return TRUE;
        }
        return FALSE;
    }

    public function Allocate( $aColor, $aAlpha = 0 )
    {
        list( $r, $g, $b, $a ) = $this->color( $aColor );
        if ( 0 < $a )
        {
            $aAlpha = $a;
        }
        if ( $aAlpha < 0 || 1 < $aAlpha )
        {
            ( 25080 );
        }
        return imagecolorresolvealpha( $this->img, $r, $g, $b, round( $aAlpha * 127 ) );
    }

}

class Image
{

    public $left_margin = 30;
    public $right_margin = 30;
    public $top_margin = 20;
    public $bottom_margin = 30;
    public $img;
    public $plotwidth = 0;
    public $plotheight = 0;
    public $width = 0;
    public $height = 0;
    public $rgb;
    public $current_color;
    public $current_color_name;
    public $line_weight = 1;
    public $line_style = 1;
    public $img_format;
    protected $expired = TRUE;
    protected $lastx = 0;
    protected $lasty = 0;
    protected $obs_list = array( );
    protected $font_size = 12;
    protected $font_family = FF_FONT1;
    protected $font_style = FS_NORMAL;
    protected $font_file = "";
    protected $text_halign = "left";
    protected $text_valign = "bottom";
    protected $ttf;
    protected $use_anti_aliasing = FALSE;
    protected $quality;
    protected $colorstack = array( );
    protected $colorstackidx = 0;
    protected $canvascolor = "white";
    protected $langconv;
    protected $iInterlace = FALSE;

    public function Image( $aWidth, $aHeight, $aFormat = DEFAULT_GFORMAT )
    {
        $this->CreateImgCanvas( $aWidth, $aHeight );
        $this->SetAutoMargin( );
        if ( $this->SetImgFormat( $aFormat ) )
        {
            ( 25081, $aFormat );
        }
        $this->ttf = new TTF( );
        $this->langconv = new LanguageConv( );
    }

    public function SetInterlace( $aFlg = TRUE )
    {
        $this->iInterlace = $aFlg;
    }

    public function SetAntiAliasing( $aFlg = TRUE )
    {
        $this->use_anti_aliasing = $aFlg;
        imageantialias( $this->img, $aFlg );
    }

    public function CreateRawCanvas( $aWidth = 0, $aHeight = 0 )
    {
        if ( $aWidth <= 1 || $aHeight <= 1 )
        {
            ( 25082, $aWidth, $aHeight );
        }
        if ( USE_TRUECOLOR )
        {
            $this->img = imagecreatetruecolor( $aWidth, $aHeight );
            if ( $this->img < 1 )
            {
                ( 25126 );
            }
            $this->SetAlphaBlending( );
        }
        else
        {
            $this->img = imagecreate( $aWidth, $aHeight );
            if ( $this->img < 1 )
            {
                ( 25126 );
            }
        }
        if ( $this->iInterlace )
        {
            imageinterlace( $this->img, 1 );
        }
        if ( $this->rgb != NULL )
        {
            $this->rgb->img = $this->img;
        }
        else
        {
            $this->rgb = new RGB( $this->img );
        }
    }

    public function CloneCanvasH( )
    {
        $oldimage = $this->img;
        $this->height( $this->width, $this->height );
        imagecopy( $this->img, $oldimage, 0, 0, 0, 0, $this->width, $this->height );
        return $oldimage;
    }

    public function CreateImgCanvas( $aWidth = 0, $aHeight = 0 )
    {
        $old = array( $this->img, $this->width, $this->height );
        $aWidth = round( $aWidth );
        $aHeight = round( $aHeight );
        $this->width = $aWidth;
        $this->height = $aHeight;
        if ( $aWidth == 0 || $aHeight == 0 )
        {
            $this->img = NULL;
            $this->rgb = NULL;
            return $old;
        }
        $this->CreateRawCanvas( $aWidth, $aHeight );
        $this->canvascolor( $this->canvascolor );
        $this->FilledRectangle( 0, 0, $aWidth, $aHeight );
        return $old;
    }

    public function CopyCanvasH( $aToHdl, $aFromHdl, $aToX, $aToY, $aFromX, $aFromY, $aWidth, $aHeight, $aw = -1, $ah = -1 )
    {
        if ( $aw === -1 )
        {
            $aw = $aWidth;
            $ah = $aHeight;
            $f = "imagecopyresized";
        }
        else
        {
            $f = "imagecopyresampled";
        }
        $f( $aToHdl, $aFromHdl, $aToX, $aToY, $aFromX, $aFromY, $aWidth, $aHeight, $aw, $ah );
    }

    public function Copy( $fromImg, $toX, $toY, $fromX, $fromY, $toWidth, $toHeight, $fromWidth = -1, $fromHeight = -1 )
    {
        $this->img( $this->img, $fromImg, $toX, $toY, $fromX, $fromY, $toWidth, $toHeight, $fromWidth, $fromHeight );
    }

    public function CopyMerge( $fromImg, $toX, $toY, $fromX, $fromY, $toWidth, $toHeight, $fromWidth = -1, $fromHeight = -1, $aMix = 100 )
    {
        if ( $aMix == 100 )
        {
            $this->img( $this->img, $fromImg, $toX, $toY, $fromX, $fromY, $toWidth, $toHeight, $fromWidth, $fromHeight );
        }
        else
        {
            if ( !( $fromWidth != -1 ) || $fromWidth != $toWidth || $fromHeight != -1 && $fromHeight != $fromHeight )
            {
                if ( $toWidth <= 1 || $toHeight <= 1 )
                {
                    ( 25083 );
                }
                if ( USE_TRUECOLOR )
                {
                    $tmpimg = @imagecreatetruecolor( $toWidth, $toHeight );
                }
                else
                {
                    $tmpimg = @imagecreate( $toWidth, $toHeight );
                }
                if ( $tmpimg < 1 )
                {
                    ( 25084 );
                }
                $this->CopyCanvasH( $tmpimg, $fromImg, 0, 0, 0, 0, $toWidth, $toHeight, $fromWidth, $fromHeight );
                $fromImg = $tmpimg;
            }
            imagecopymerge( $this->img, $fromImg, $toX, $toY, $fromX, $fromY, $toWidth, $toHeight, $aMix );
        }
    }

    public function GetWidth( $aImg = NULL )
    {
        if ( $aImg === NULL )
        {
            $aImg = $this->img;
        }
        return imagesx( $aImg );
    }

    public function GetHeight( $aImg = NULL )
    {
        if ( $aImg === NULL )
        {
            $aImg = $this->img;
        }
        return imagesy( $aImg );
    }

    public function CreateFromString( $aStr )
    {
        $img = imagecreatefromstring( $aStr );
        if ( $img === FALSE )
        {
            ( 25085 );
        }
        return $img;
    }

    public function SetCanvasH( $aHdl )
    {
        $this->img = $aHdl;
        $this->rgb->img = $aHdl;
    }

    public function SetCanvasColor( $aColor )
    {
        $this->canvascolor = $aColor;
    }

    public function SetAlphaBlending( $aFlg = TRUE )
    {
        imagealphablending( $this->img, $aFlg );
    }

    public function SetAutoMargin( )
    {
        global $gJpgBrandTiming;
        $min_bm = 10;
        $lm = min( 40, $this->width / 7 );
        $rm = min( 20, $this->width / 10 );
        $tm = max( 20, $this->height / 7 );
        $bm = max( $min_bm, $this->height / 7 );
        $this->SetMargin( $lm, $rm, $tm, $bm );
    }

    public function SetFont( $family, $style = FS_NORMAL, $size = 10 )
    {
        $this->font_family = $family;
        $this->font_style = $style;
        $this->font_size = $size;
        $this->font_file = "";
        if ( ( $this->font_family == FF_FONT1 || $this->font_family == FF_FONT2 ) && $this->font_style == FS_BOLD )
        {
            ++$this->font_family;
        }
        if ( FF_FONT2 + 1 < $this->font_family )
        {
            if ( function_exists( "imagettfbbox" ) )
            {
                ( 25087 );
            }
            $this->font_file = $this->ttf->File( $this->font_family, $this->font_style );
        }
    }

    public function GetTextHeight( $txt = "", $angle = 0 )
    {
        $tmp = split( "\n", $txt );
        $n = count( $tmp );
        $m = 0;
        $i = 0;
        for ( ; $i < $n; ++$i )
        {
            $m = max( $m, strlen( $tmp[$i] ) );
        }
        if ( $this->font_family <= FF_FONT2 + 1 )
        {
            if ( $angle == 0 )
            {
                $h = imagefontheight( $this->font_family );
                if ( $h === FALSE )
                {
                    ( 25088 );
                }
                return $n * $h;
            }
            $w = @imagefontwidth( @$this->font_family );
            if ( $w === FALSE )
            {
                ( 25088 );
            }
            return $m * $w;
        }
        $bbox = $this->GetTTFBBox( $txt, $angle );
        return $bbox[1] - $bbox[5];
    }

    public function GetFontHeight( $angle = 0 )
    {
        $txt = "XOMg";
        return $this->GetTextHeight( $txt, $angle );
    }

    public function GetFontWidth( $angle = 0 )
    {
        $txt = "O";
        return $this->GetTextWidth( $txt, $angle );
    }

    public function GetTextWidth( $txt, $angle = 0 )
    {
        $tmp = split( "\n", $txt );
        $n = count( $tmp );
        if ( $this->font_family <= FF_FONT2 + 1 )
        {
            $m = 0;
            $i = 0;
            for ( ; $i < $n; ++$i )
            {
                $l = strlen( $tmp[$i] );
                if ( $m < $l )
                {
                    $m = $l;
                }
            }
            if ( $angle == 0 )
            {
                $w = @imagefontwidth( @$this->font_family );
                if ( $w === FALSE )
                {
                    ( 25088 );
                }
                return $m * $w;
            }
            $h = @imagefontheight( @$this->font_family );
            if ( $h === FALSE )
            {
                ( 25089 );
            }
            return $n * $h;
        }
        $m = 0;
        $i = 0;
        for ( ; $i < $n; ++$i )
        {
            $bbox = $tmp[$i]( $tmp[$i], $angle );
            $mm = $bbox[2] - $bbox[0];
            if ( $m < $mm )
            {
                $m = $mm;
            }
        }
        return $m;
    }

    public function StrokeBoxedText( $x, $y, $txt, $dir = 0, $fcolor = "white", $bcolor = "black", $shadowcolor = FALSE, $paragraph_align = "left", $xmarg = 6, $ymarg = 4, $cornerradius = 0, $dropwidth = 3 )
    {
        if ( is_numeric( $dir ) )
        {
            if ( $dir == "h" )
            {
                $dir = 0;
            }
            else if ( $dir == "v" )
            {
                $dir = 90;
            }
            else
            {
                ( 25090, $dir );
            }
        }
        if ( FF_FONT0 <= $this->font_family && $this->font_family <= FF_FONT2 + 1 )
        {
            $width = $this->GetTextWidth( $txt, $dir );
            $height = $this->GetTextHeight( $txt, $dir );
        }
        else
        {
            $width = $this->GetBBoxWidth( $txt, $dir );
            $height = $this->GetBBoxHeight( $txt, $dir );
        }
        $height += 2 * $ymarg;
        $width += 2 * $xmarg;
        if ( $this->text_halign == "right" )
        {
            $x -= $width;
        }
        else if ( $this->text_halign == "center" )
        {
            $x -= $width / 2;
        }
        if ( $this->text_valign == "bottom" )
        {
            $y -= $height;
        }
        else if ( $this->text_valign == "center" )
        {
            $y -= $height / 2;
        }
        if ( $shadowcolor )
        {
            $this->PushColor( $shadowcolor );
            $this->FilledRoundedRectangle( $x - $xmarg + $dropwidth, $y - $ymarg + $dropwidth, $x + $width + $dropwidth, $y + $height - $ymarg + $dropwidth, $cornerradius );
            $this->PopColor( );
            $this->PushColor( $fcolor );
            $this->FilledRoundedRectangle( $x - $xmarg, $y - $ymarg, $x + $width, $y + $height - $ymarg, $cornerradius );
            $this->PopColor( );
            $this->PushColor( $bcolor );
            $this->RoundedRectangle( $x - $xmarg, $y - $ymarg, $x + $width, $y + $height - $ymarg, $cornerradius );
            $this->PopColor( );
        }
        else
        {
            if ( $fcolor )
            {
                $oc = $this->current_color;
                $this->SetColor( $fcolor );
                $this->FilledRoundedRectangle( $x - $xmarg, $y - $ymarg, $x + $width, $y + $height - $ymarg, $cornerradius );
                $this->current_color = $oc;
            }
            if ( $bcolor )
            {
                $oc = $this->current_color;
                $this->SetColor( $bcolor );
                $this->RoundedRectangle( $x - $xmarg, $y - $ymarg, $x + $width, $y + $height - $ymarg, $cornerradius );
                $this->current_color = $oc;
            }
        }
        $h = $this->text_halign;
        $v = $this->text_valign;
        $this->SetTextAlign( "left", "top" );
        $this->StrokeText( $x, $y, $txt, $dir, $paragraph_align );
        $bb = array( $x - $xmarg, $y + $height - $ymarg, $x + $width, $y + $height - $ymarg, $x + $width, $y - $ymarg, $x - $xmarg, $y - $ymarg );
        $this->SetTextAlign( $h, $v );
        return $bb;
    }

    public function SetTextAlign( $halign, $valign = "bottom" )
    {
        $this->text_halign = $halign;
        $this->text_valign = $valign;
    }

    public function _StrokeBuiltinFont( $x, $y, $txt, $dir = 0, $paragraph_align = "left", &$aBoundingBox, $aDebug = FALSE )
    {
        if ( is_numeric( $dir ) && $dir != 90 && $dir != 0 )
        {
            ( 25091 );
        }
        $h = $this->GetTextHeight( $txt );
        $fh = $this->GetFontHeight( );
        $w = $this->GetTextWidth( $txt );
        if ( $this->text_halign == "right" )
        {
            $x -= $dir == 0 ? $w : $h;
        }
        else
        {
            $x -= $h / 2;
        }
        if ( $this->text_valign == "top" )
        {
            $y += $w;
        }
        else
        {
            $y += $w / 2;
        }
        if ( $dir == 90 )
        {
            imagestringup( $this->img, $this->font_family, $x, $y, $txt, $this->current_color );
            $aBoundingBox = array( round( $x ), round( $y ), round( $x ), round( $y - $w ), round( $x + $h ), round( $y - $w ), round( $x + $h ), round( $y ) );
            if ( $aDebug )
            {
                $this->PushColor( "green" );
                $this->Polygon( $aBoundingBox, TRUE );
                $this->PopColor( );
            }
        }
        else
        {
            if ( ereg( "\n", $txt ) )
            {
                $tmp = split( "\n", $txt );
                $i = 0;
                for ( ; $i < count( $tmp ); ++$i )
                {
                    $w1 = $tmp[$i]( $tmp[$i] );
                    if ( $paragraph_align == "left" )
                    {
                        imagestring( $this->img, $this->font_family, $x, $y - $h + 1 + $i * $fh, $tmp[$i], $this->current_color );
                    }
                    else
                    {
                        if ( $paragraph_align == "right" )
                        {
                            imagestring( $this->img, $this->font_family, $x + ( $w - $w1 ), $y - $h + 1 + $i * $fh, $tmp[$i], $this->current_color );
                        }
                        else
                        {
                            imagestring( $this->img, $this->font_family, $x + $w / 2 - $w1 / 2, $y - $h + 1 + $i * $fh, $tmp[$i], $this->current_color );
                        }
                    }
                }
            }
            else
            {
                imagestring( $this->img, $this->font_family, $x, $y - $h + 1, $txt, $this->current_color );
            }
            if ( $aDebug )
            {
                $p1 = array( round( $x ), round( $y ), round( $x ), round( $y - $h ), round( $x + $w ), round( $y - $h ), round( $x + $w ), round( $y ) );
                $this->PushColor( "green" );
                $this->Polygon( $p1, TRUE );
                $this->PopColor( );
            }
            $aBoundingBox = array( round( $x ), round( $y ), round( $x ), round( $y - $h ), round( $x + $w ), round( $y - $h ), round( $x + $w ), round( $y ) );
        }
    }

    public function AddTxtCR( $aTxt )
    {
        $e = explode( "\n", $aTxt );
        $n = count( $e );
        $i = 0;
        for ( ; $i < $n; ++$i )
        {
            $e[$i] = str_replace( "\r", "", $e[$i] );
        }
        return implode( "\n\r", $e );
    }

    public function GetTTFBBox( $aTxt, $aAngle = 0 )
    {
        $bbox = @imagettfbbox( @$this->font_size, $aAngle, @$this->font_file, $aTxt );
        if ( $bbox === FALSE )
        {
            ( 25092, $this->font_file );
        }
        return $bbox;
    }

    public function GetBBoxTTF( $aTxt, $aAngle = 0 )
    {
        $aTxt = $this->AddTxtCR( $aTxt );
        if ( is_readable( $this->font_file ) )
        {
            ( 25093, $this->font_file );
        }
        $bbox = $this->GetTTFBBox( $aTxt, $aAngle );
        if ( $aAngle == 0 )
        {
            return $bbox;
        }
        if ( 0 <= $aAngle )
        {
            if ( $aAngle <= 90 )
            {
                $bbox = array( $bbox[6], $bbox[1], $bbox[2], $bbox[1], $bbox[2], $bbox[5], $bbox[6], $bbox[5] );
                return $bbox;
            }
            if ( $aAngle <= 180 )
            {
                $bbox = array( $bbox[4], $bbox[7], $bbox[0], $bbox[7], $bbox[0], $bbox[3], $bbox[4], $bbox[3] );
                return $bbox;
            }
            if ( $aAngle <= 270 )
            {
                $bbox = array( $bbox[2], $bbox[5], $bbox[6], $bbox[5], $bbox[6], $bbox[1], $bbox[2], $bbox[1] );
                return $bbox;
            }
            $bbox = array( $bbox[0], $bbox[3], $bbox[4], $bbox[3], $bbox[4], $bbox[7], $bbox[0], $bbox[7] );
            return $bbox;
        }
        if ( $aAngle < 0 )
        {
            if ( $aAngle <= -270 )
            {
                $bbox = array( $bbox[6], $bbox[1], $bbox[2], $bbox[1], $bbox[2], $bbox[5], $bbox[6], $bbox[5] );
                return $bbox;
            }
            if ( $aAngle <= -180 )
            {
                $bbox = array( $bbox[0], $bbox[3], $bbox[4], $bbox[3], $bbox[4], $bbox[7], $bbox[0], $bbox[7] );
                return $bbox;
            }
            if ( $aAngle <= -90 )
            {
                $bbox = array( $bbox[2], $bbox[5], $bbox[6], $bbox[5], $bbox[6], $bbox[1], $bbox[2], $bbox[1] );
                return $bbox;
            }
            $bbox = array( $bbox[0], $bbox[3], $bbox[4], $bbox[3], $bbox[4], $bbox[7], $bbox[0], $bbox[7] );
        }
        return $bbox;
    }

    public function GetBBoxHeight( $aTxt, $aAngle = 0 )
    {
        $box = $this->GetBBoxTTF( $aTxt, $aAngle );
        return $box[1] - $box[7] + 1;
    }

    public function GetBBoxWidth( $aTxt, $aAngle = 0 )
    {
        $box = $this->GetBBoxTTF( $aTxt, $aAngle );
        return $box[2] - $box[0] + 1;
    }

    public function _StrokeTTF( $x, $y, $txt, $dir = 0, $paragraph_align = "left", &$aBoundingBox, $debug = FALSE )
    {
        $ConstLineSpacing = 0.25;
        if ( $debug )
        {
            $ox = $x;
            $oy = $y;
        }
        if ( !ereg( "\n", $txt ) || 0 < $dir && ereg( "\n", $txt ) )
        {
            $txt = $this->AddTxtCR( $txt );
            $bbox = $this->GetBBoxTTF( $txt, $dir );
            $x -= $bbox[0];
            $y -= $bbox[1];
            if ( $this->text_halign == "right" || $this->text_halign == "topanchor" )
            {
                $x -= $bbox[2] - $bbox[0];
            }
            else if ( $this->text_halign == "center" )
            {
                $x -= ( $bbox[2] - $bbox[0] ) / 2;
            }
            if ( $this->text_valign == "top" )
            {
                $y += abs( $bbox[5] ) + $bbox[1];
            }
            else if ( $this->text_valign == "center" )
            {
                $y -= ( $bbox[5] - $bbox[1] ) / 2;
            }
            imagettftext( $this->img, $this->font_size, $dir, $x, $y, $this->current_color, $this->font_file, $txt );
            $box = @imagettfbbox( @$this->font_size, $dir, @$this->font_file, $txt );
            $p1 = array( );
            $i = 0;
            for ( ; $i < 4; ++$i )
            {
                $p1[] = round( $box[$i * 2] + $x );
                $p1[] = round( $box[$i * 2 + 1] + $y );
            }
            $aBoundingBox = $p1;
            if ( $debug )
            {
                $box = @imagettfbbox( @$this->font_size, $dir, @$this->font_file, $txt );
                $p = array( );
                $p1 = array( );
                $i = 0;
                for ( ; $i < 4; ++$i )
                {
                    $p[] = $bbox[$i * 2] + $x;
                    $p[] = $bbox[$i * 2 + 1] + $y;
                    $p1[] = $box[$i * 2] + $x;
                    $p1[] = $box[$i * 2 + 1] + $y;
                }
                $this->PushColor( "green" );
                $this->Polygon( $p1, TRUE );
                $this->PopColor( );
                $this->PushColor( "darkgreen" );
                $this->Polygon( $p, TRUE );
                $this->PopColor( );
                $this->PushColor( "red" );
                $this->Line( $ox - 15, $oy, $ox + 15, $oy );
                $this->Line( $ox, $oy - 15, $ox, $oy + 15 );
                $this->PopColor( );
            }
        }
        else
        {
            $fh = $this->GetFontHeight( );
            $linemargin = round( $fh * $ConstLineSpacing );
            $fh += $linemargin;
            $w = $this->GetTextWidth( $txt );
            $y -= $linemargin / 2;
            $tmp = split( "\n", $txt );
            $nl = count( $tmp );
            $h = $nl * $fh;
            if ( $this->text_halign == "right" )
            {
                $x -= $dir == 0 ? $w : $h;
            }
            else
            {
                $x -= $h / 2;
            }
            if ( $this->text_valign == "top" )
            {
                $y += $w;
            }
            else
            {
                $y += $w / 2;
            }
            $standardbox = $this->GetTTFBBox( "Gg", $dir );
            $yadj = $standardbox[1];
            $xadj = $standardbox[0];
            $aBoundingBox = array( );
            $i = 0;
            for ( ; $i < $nl; ++$i )
            {
                $wl = $tmp[$i]( $tmp[$i] );
                $bbox = $tmp[$i]( $tmp[$i], $dir );
                if ( $paragraph_align == "left" )
                {
                    $xl = $x;
                }
                else if ( $paragraph_align == "right" )
                {
                    $xl = $x + ( $w - $wl );
                }
                else
                {
                    $xl = $x + $w / 2 - $wl / 2;
                }
                $xl -= $bbox[0];
                $yl = $y - $yadj;
                $xl -= $xadj;
                imagettftext( $this->img, $this->font_size, $dir, $xl, $yl - ( $h - $fh ) + $fh * $i, $this->current_color, $this->font_file, $tmp[$i] );
                if ( $debug )
                {
                    $box = @imagettfbbox( @$this->font_size, $dir, @$this->font_file, @$tmp[$i] );
                    $p = array( );
                    $j = 0;
                    for ( ; $j < 4; ++$j )
                    {
                        $p[] = $bbox[$j * 2] + $xl;
                        $p[] = $bbox[$j * 2 + 1] + $yl - ( $h - $fh ) + $fh * $i;
                    }
                    $this->PushColor( "darkgreen" );
                    $this->Polygon( $p, TRUE );
                    $this->PopColor( );
                }
            }
            $bbox = $this->GetBBoxTTF( $txt, $dir );
            $j = 0;
            for ( ; $j < 4; ++$j )
            {
                $bbox += $j * 2;
                $bbox += $j * 2 + 1;
            }
            $aBoundingBox = $bbox;
            if ( $debug )
            {
                $this->PushColor( "red" );
                $this->Line( $ox - 25, $oy, $ox + 25, $oy );
                $this->Line( $ox, $oy - 25, $ox, $oy + 25 );
                $this->PopColor( );
            }
        }
    }

    public function StrokeText( $x, $y, $txt, $dir = 0, $paragraph_align = "left", $debug = FALSE )
    {
        $x = round( $x );
        $y = round( $y );
        $txt = $this->langconv->Convert( $txt, $this->font_family );
        if ( is_numeric( $dir ) )
        {
            ( 25094 );
        }
        if ( FF_FONT0 <= $this->font_family && $this->font_family <= FF_FONT2 + 1 )
        {
            $this->_StrokeBuiltinFont( $x, $y, $txt, $dir, $paragraph_align, $boundingbox, $debug );
            return $boundingbox;
        }
        if ( _FIRST_FONT <= $this->font_family && $this->font_family <= _LAST_FONT )
        {
            $this->_StrokeTTF( $x, $y, $txt, $dir, $paragraph_align, $boundingbox, $debug );
            return $boundingbox;
        }
        ( 25095 );
        return $boundingbox;
    }

    public function SetMargin( $lm, $rm, $tm, $bm )
    {
        $this->left_margin = $lm;
        $this->right_margin = $rm;
        $this->top_margin = $tm;
        $this->bottom_margin = $bm;
        $this->plotwidth = $this->width - $this->left_margin - $this->right_margin;
        $this->plotheight = $this->height - $this->top_margin - $this->bottom_margin;
        if ( 0 < $this->width && 0 < $this->height && ( $this->plotwidth < 0 || $this->plotheight < 0 ) )
        {
            ( "To small plot area. (".$lm.",{$rm},{$tm},{$bm} : {$this->plotwidth} x {$this->plotheight}). With the given image size and margins there is to little space left for the plot. Increase the plot size or reduce the margins." );
        }
    }

    public function SetTransparent( $color )
    {
        imagecolortransparent( $this->img, $this->rgb->allocate( $color ) );
    }

    public function SetColor( $color, $aAlpha = 0 )
    {
        $this->current_color_name = $color;
        $this->current_color = $this->rgb->allocate( $color, $aAlpha );
        if ( $this->current_color == -1 )
        {
            $tc = imagecolorstotal( $this->img );
            ( 25096 );
        }
        return $this->current_color;
    }

    public function PushColor( $color )
    {
        if ( $color != "" )
        {
            $this->colorstack[$this->colorstackidx] = $this->current_color_name;
            $this->colorstack[$this->colorstackidx + 1] = $this->current_color;
            $ && _737211720 += "colorstackidx";
            $this->SetColor( $color );
        }
        else
        {
            ( 25097 );
        }
    }

    public function PopColor( )
    {
        if ( $this->colorstackidx < 1 )
        {
            ( 25098 );
        }
        $this->current_color = $this->colorstack[--$this->colorstackidx];
        $this->current_color_name = $this->colorstack[--$this->colorstackidx];
    }

    public function AdjSat( $sat )
    {
        if ( USE_TRUECOLOR )
        {
        }
        else
        {
            $this->img( $this->img, $sat );
        }
    }

    public function _AdjSat( $img, $sat )
    {
        $nbr = imagecolorstotal( $img );
        $i = 0;
        for ( ; $i < $nbr; ++$i )
        {
            $colarr = imagecolorsforindex( $img, $i );
            $rgb[0] = $colarr['red'];
            $rgb[1] = $colarr['green'];
            $rgb[2] = $colarr['blue'];
            $rgb = $this->AdjRGBSat( $rgb, $sat );
            imagecolorset( $img, $i, $rgb[0], $rgb[1], $rgb[2] );
        }
    }

    public function AdjBrightContrast( $bright, $contr = 0 )
    {
        if ( USE_TRUECOLOR )
        {
        }
        else
        {
            $this->img( $this->img, $bright, $contr );
        }
    }

    public function _AdjBrightContrast( $img, $bright, $contr = 0 )
    {
        if ( $bright < -1 || 1 < $bright || $contr < -1 || 1 < $contr )
        {
            ( 25099 );
        }
        $nbr = imagecolorstotal( $img );
        $i = 0;
        for ( ; $i < $nbr; ++$i )
        {
            $colarr = imagecolorsforindex( $img, $i );
            $r = $colarr['red']( $colarr['red'], $bright, $contr );
            $g = $colarr['green']( $colarr['green'], $bright, $contr );
            $b = $colarr['blue']( $colarr['blue'], $bright, $contr );
            imagecolorset( $img, $i, $r, $g, $b );
        }
    }

    public function AdjRGBSat( $rgb, $sat )
    {
        $v = array( 1, 1, 1 );
        $dot = $rgb[0] * $v[0] + $rgb[1] * $v[1] + $rgb[2] * $v[2];
        $normdot = $dot / 3;
        $i = 0;
        for ( ; $i < 3; ++$i )
        {
            $r[$i] = $rgb[$i] - $normdot * $v[$i];
        }
        if ( 0 < $sat )
        {
            $m = 0;
            $i = 0;
            for ( ; $i < 3; ++$i )
            {
                if ( !( sign( $r[$i] ) == 1 ) || !( 0 < $r[$i] ) )
                {
                    $m = max( $m, ( 255 - $rgb[$i] ) / $r[$i] );
                }
            }
            $tadj = $m;
        }
        else
        {
            $tadj = 1;
        }
        $tadj *= $sat;
        $i = 0;
        for ( ; $i < 3; ++$i )
        {
            $un[$i] = round( $rgb[$i] + $tadj * $r[$i] );
            if ( $un[$i] < 0 )
            {
                $un[$i] = 0;
            }
            if ( 255 < $un[$i] )
            {
                $un[$i] = 255;
            }
        }
        return $un;
    }

    public function AdjRGBBrightContrast( $rgb, $bright, $contr )
    {
        if ( $contr <= 0 )
        {
            $adj = abs( $rgb - 128 ) * ( 0 - $contr );
            if ( $rgb < 128 )
            {
                $rgb += $adj;
            }
            else
            {
                $rgb -= $adj;
            }
        }
        else if ( $rgb < 128 )
        {
            $rgb -= $rgb * $contr;
        }
        else
        {
            $rgb += ( 255 - $rgb ) * $contr;
        }
        $rgb += $bright * 255;
        $rgb = min( $rgb, 255 );
        $rgb = max( $rgb, 0 );
        return $rgb;
    }

    public function SetLineWeight( $weight )
    {
        imagesetthickness( $this->img, $weight );
        $this->line_weight = $weight;
    }

    public function SetStartPoint( $x, $y )
    {
        $this->lastx = round( $x );
        $this->lasty = round( $y );
    }

    public function Arc( $cx, $cy, $w, $h, $s, $e )
    {
        while ( $s < 0 )
        {
            $s += 360;
        }
        while ( $e < 0 )
        {
            $e += 360;
        }
        imagearc( $this->img, round( $cx ), round( $cy ), round( $w ), round( $h ), $s, $e, $this->current_color );
    }

    public function FilledArc( $xc, $yc, $w, $h, $s, $e, $style = "" )
    {
        while ( $s < 0 )
        {
            $s += 360;
        }
        while ( $e < 0 )
        {
            $e += 360;
        }
        if ( $style == "" )
        {
            $style = IMG_ARC_PIE;
        }
        imagefilledarc( $this->img, round( $xc ), round( $yc ), round( $w ), round( $h ), round( $s ), round( $e ), $this->current_color, $style );
    }

    public function FilledCakeSlice( $cx, $cy, $w, $h, $s, $e )
    {
        $this->current_color_name( $cx, $cy, $w, $h, $s, $e, $this->current_color_name );
    }

    public function CakeSlice( $xc, $yc, $w, $h, $s, $e, $fillcolor = "", $arccolor = "" )
    {
        $s = round( $s );
        $e = round( $e );
        $w = round( $w );
        $h = round( $h );
        $xc = round( $xc );
        $yc = round( $yc );
        $this->PushColor( $fillcolor );
        $this->FilledArc( $xc, $yc, 2 * $w, 2 * $h, $s, $e );
        $this->PopColor( );
        if ( $arccolor != "" )
        {
            $this->PushColor( $arccolor );
            imagefilledarc( $this->img, $xc, $yc, 2 * $w, 2 * $h, $s, $e, $this->current_color, IMG_ARC_NOFILL | IMG_ARC_EDGED );
            $this->PopColor( );
        }
    }

    public function Ellipse( $xc, $yc, $w, $h )
    {
        $this->Arc( $xc, $yc, $w, $h, 0, 360 );
    }

    public function Circle( $xc, $yc, $r )
    {
        imageellipse( $this->img, round( $xc ), round( $yc ), $r * 2, $r * 2, $this->current_color );
    }

    public function FilledCircle( $xc, $yc, $r )
    {
        imagefilledellipse( $this->img, round( $xc ), round( $yc ), 2 * $r, 2 * $r, $this->current_color );
    }

    public function lip( $f, $t, $p )
    {
        $p = round( $p, 1 );
        $r = $f[0] + ( $t[0] - $f[0] ) * $p;
        $g = $f[1] + ( $t[1] - $f[1] ) * $p;
        $b = $f[2] + ( $t[2] - $f[2] ) * $p;
        return array( $r, $g, $b );
    }

    public function SetLineStyle( $s )
    {
        if ( is_numeric( $s ) )
        {
            if ( $s < 1 || 4 < $s )
            {
                ( 25101, $s );
            }
        }
        else if ( is_string( $s ) )
        {
            if ( $s == "solid" )
            {
                $s = 1;
            }
            else
            {
                if ( $s == "dotted" )
                {
                    $s = 2;
                }
                else
                {
                    if ( $s == "dashed" )
                    {
                        $s = 3;
                    }
                    else
                    {
                        if ( $s == "longdashed" )
                        {
                            $s = 4;
                        }
                        else
                        {
                            ( 25102, $s );
                        }
                    }
                }
            }
        }
        else
        {
            ( 25103, $s );
        }
        $this->line_style = $s;
    }

    public function StyleLine( $x1, $y1, $x2, $y2 )
    {
        switch ( $this->line_style )
        {
            case 1 :
                $this->Line( $x1, $y1, $x2, $y2 );
                break;
            case 2 :
                $this->DashedLine( $x1, $y1, $x2, $y2, 1, 3 );
                break;
            case 3 :
                $this->DashedLine( $x1, $y1, $x2, $y2, 2, 4 );
                break;
            case 4 :
                $this->DashedLine( $x1, $y1, $x2, $y2, 8, 6 );
                break;
            default :
                ( 25104, $this->line_style );
        }
    }

    public function DashedLine( $x1, $y1, $x2, $y2, $dash_length = 1, $dash_space = 4 )
    {
        $x1 = round( $x1 );
        $x2 = round( $x2 );
        $y1 = round( $y1 );
        $y2 = round( $y2 );
        $style = array_fill( 0, $dash_length, $this->current_color );
        $style = array_pad( $style, $dash_length + $dash_space, IMG_COLOR_TRANSPARENT );
        imagesetstyle( $this->img, $style );
        imageline( $this->img, $x1, $y1, $x2, $y2, IMG_COLOR_STYLED );
        $this->lastx = $x2;
        $this->lasty = $y2;
    }

    public function Line( $x1, $y1, $x2, $y2 )
    {
        $x1 = round( $x1 );
        $x2 = round( $x2 );
        $y1 = round( $y1 );
        $y2 = round( $y2 );
        imageline( $this->img, $x1, $y1, $x2, $y2, $this->current_color );
        $this->lastx = $x2;
        $this->lasty = $y2;
    }

    public function Polygon( $p, $closed = FALSE, $fast = FALSE )
    {
        if ( $this->line_weight == 0 )
        {
        }
        else
        {
            $n = count( $p );
            $oldx = $p[0];
            $oldy = $p[1];
            if ( $fast )
            {
                $i = 2;
                for ( ; $i < $n; $i += 2 )
                {
                    imageline( $this->img, $oldx, $oldy, $p[$i], $p[$i + 1], $this->current_color );
                    $oldx = $p[$i];
                    $oldy = $p[$i + 1];
                }
                if ( $closed )
                {
                    imageline( $this->img, $p[$n * 2 - 2], $p[$n * 2 - 1], $p[0], $p[1], $this->current_color );
                }
            }
            else
            {
                $i = 2;
                for ( ; $i < $n; $i += 2 )
                {
                    $p[$i + 1]( $oldx, $oldy, $p[$i], $p[$i + 1] );
                    $oldx = $p[$i];
                    $oldy = $p[$i + 1];
                }
                if ( $closed )
                {
                    $p[1]( $oldx, $oldy, $p[0], $p[1] );
                }
            }
        }
    }

    public function FilledPolygon( $pts )
    {
        $n = count( $pts );
        if ( $n == 0 )
        {
            ( 25105 );
        }
        $i = 0;
        for ( ; $i < $n; ++$i )
        {
            $pts[$i] = round( $pts[$i] );
        }
        imagefilledpolygon( $this->img, $pts, count( $pts ) / 2, $this->current_color );
    }

    public function Rectangle( $xl, $yu, $xr, $yl )
    {
        $this->Polygon( array( $xl, $yu, $xr, $yu, $xr, $yl, $xl, $yl, $xl, $yu ) );
    }

    public function FilledRectangle( $xl, $yu, $xr, $yl )
    {
        $this->FilledPolygon( array( $xl, $yu, $xr, $yu, $xr, $yl, $xl, $yl ) );
    }

    public function FilledRectangle2( $xl, $yu, $xr, $yl, $color1, $color2, $style = 1 )
    {
        if ( $style === 1 )
        {
            if ( $yl < $yu )
            {
                $t = $yl;
                $yl = $yu;
                $yu = $t;
            }
            $y = $yu;
            for ( ; $y <= $yl; ++$y )
            {
                $this->SetColor( $color1 );
                $this->Line( $xl, $y, $xr, $y );
                ++$y;
                $this->SetColor( $color2 );
                $this->Line( $xl, $y, $xr, $y );
            }
        }
        else
        {
            if ( $xl < $xl )
            {
                $t = $xl;
                $xl = $xr;
                $xr = $t;
            }
            $x = $xl;
            for ( ; $x <= $xr; ++$x )
            {
                $this->SetColor( $color1 );
                $this->Line( $x, $yu, $x, $yl );
                ++$x;
                $this->SetColor( $color2 );
                $this->Line( $x, $yu, $x, $yl );
            }
        }
    }

    public function ShadowRectangle( $xl, $yu, $xr, $yl, $fcolor = FALSE, $shadow_width = 3, $shadow_color = array( 102, 102, 102 ) )
    {
        $this->PushColor( $shadow_color );
        $this->FilledRectangle( $xr - $shadow_width, $yu + $shadow_width, $xr, $yl - $shadow_width - 1 );
        $this->FilledRectangle( $xl + $shadow_width, $yl - $shadow_width, $xr, $yl );
        $this->PopColor( );
        if ( $fcolor )
        {
            $this->Rectangle( $xl, $yu, $xr - $shadow_width - 1, $yl - $shadow_width - 1 );
        }
        else
        {
            $this->PushColor( $fcolor );
            $this->FilledRectangle( $xl, $yu, $xr - $shadow_width - 1, $yl - $shadow_width - 1 );
            $this->PopColor( );
            $this->Rectangle( $xl, $yu, $xr - $shadow_width - 1, $yl - $shadow_width - 1 );
        }
    }

    public function FilledRoundedRectangle( $xt, $yt, $xr, $yl, $r = 5 )
    {
        if ( $r == 0 )
        {
            $this->FilledRectangle( $xt, $yt, $xr, $yl );
        }
        else
        {
            $this->FilledRectangle( $xt + $r, $yt + $r, $xr - $r, $yl - $r );
            $this->FilledRectangle( $xt + $r, $yt, $xr - $r, $yt + $r - 1 );
            $this->FilledRectangle( $xt + $r, $yl - $r + 1, $xr - $r, $yl );
            $this->FilledRectangle( $xt, $yt + $r + 1, $xt + $r - 1, $yl - $r );
            $this->FilledRectangle( $xr - $r + 1, $yt + $r, $xr, $yl - $r );
            $this->FilledArc( $xt + $r, $yt + $r, $r * 2, $r * 2, 180, 270 );
            $this->FilledArc( $xr - $r, $yt + $r, $r * 2, $r * 2, 270, 360 );
            $this->FilledArc( $xt + $r, $yl - $r, $r * 2, $r * 2, 90, 180 );
            $this->FilledArc( $xr - $r, $yl - $r, $r * 2, $r * 2, 0, 90 );
        }
    }

    public function RoundedRectangle( $xt, $yt, $xr, $yl, $r = 5 )
    {
        if ( $r == 0 )
        {
            $this->Rectangle( $xt, $yt, $xr, $yl );
        }
        else
        {
            $this->Line( $xt + $r, $yt, $xr - $r, $yt );
            $this->Line( $xt + $r, $yl, $xr - $r, $yl );
            $this->Line( $xt, $yt + $r, $xt, $yl - $r );
            $this->Line( $xr, $yt + $r, $xr, $yl - $r );
            $this->Arc( $xt + $r, $yt + $r, $r * 2, $r * 2, 180, 270 );
            $this->Arc( $xr - $r, $yt + $r, $r * 2, $r * 2, 270, 360 );
            $this->Arc( $xt + $r, $yl - $r, $r * 2, $r * 2, 90, 180 );
            $this->Arc( $xr - $r, $yl - $r, $r * 2, $r * 2, 0, 90 );
        }
    }

    public function FilledBevel( $x1, $y1, $x2, $y2, $depth = 2, $color1 = "white@0.4", $color2 = "darkgray@0.4" )
    {
        $this->FilledRectangle( $x1, $y1, $x2, $y2 );
        $this->Bevel( $x1, $y1, $x2, $y2, $depth, $color1, $color2 );
    }

    public function Bevel( $x1, $y1, $x2, $y2, $depth = 2, $color1 = "white@0.4", $color2 = "black@0.5" )
    {
        $this->PushColor( $color1 );
        $i = 0;
        for ( ; $i < $depth; ++$i )
        {
            $this->Line( $x1 + $i, $y1 + $i, $x1 + $i, $y2 - $i );
            $this->Line( $x1 + $i, $y1 + $i, $x2 - $i, $y1 + $i );
        }
        $this->PopColor( );
        $this->PushColor( $color2 );
        $i = 0;
        for ( ; $i < $depth; ++$i )
        {
            $this->Line( $x1 + $i, $y2 - $i, $x2 - $i, $y2 - $i );
            $this->Line( $x2 - $i, $y1 + $i, $x2 - $i, $y2 - $i - 1 );
        }
        $this->PopColor( );
    }

    public function StyleLineTo( $x, $y )
    {
        $this->lasty( $this->lastx, $this->lasty, $x, $y );
        $this->lastx = $x;
        $this->lasty = $y;
    }

    public function LineTo( $x, $y )
    {
        $this->lasty( $this->lastx, $this->lasty, $x, $y );
        $this->lastx = $x;
        $this->lasty = $y;
    }

    public function Point( $x, $y )
    {
        imagesetpixel( $this->img, round( $x ), round( $y ), $this->current_color );
    }

    public function Fill( $x, $y )
    {
        imagefill( $this->img, round( $x ), round( $y ), $this->current_color );
    }

    public function FillToBorder( $x, $y, $aBordColor )
    {
        $bc = $this->rgb->allocate( $aBordColor );
        if ( $bc == -1 )
        {
            ( 25106 );
        }
        imagefilltoborder( $this->img, round( $x ), round( $y ), $bc, $this->current_color );
    }

    public function SetExpired( $aFlg = TRUE )
    {
        $this->expired = $aFlg;
    }

    public function Headers( )
    {
        $sapi = php_sapi_name( );
        if ( $sapi == "cli" )
        {
        }
        else
        {
            if ( headers_sent( &$file, &$lineno ) )
            {
                $file = basename( $file );
                $t = new ErrMsgText( );
                $msg = $t->Get( 10, $file, $lineno );
                exit( $msg );
            }
            if ( $this->expired )
            {
                header( "Expires: Mon, 26 Jul 1997 05:00:00 GMT" );
                header( "Last-Modified: ".gmdate( "D, d M Y H:i:s" )."GMT" );
                header( "Cache-Control: no-cache, must-revalidate" );
                header( "Pragma: no-cache" );
            }
            header( "Content-type: image/".$this->img_format );
        }
    }

    public function SetQuality( $q )
    {
        $this->quality = $q;
    }

    public function Stream( $aFile = "" )
    {
        $func = "image".$this->img_format;
        if ( $this->img_format == "jpeg" && $this->quality != NULL )
        {
            $res = @$this->quality( @$this->img, $aFile, @$this->quality );
        }
        else if ( $aFile != "" )
        {
            $res = @$this->img( @$this->img, $aFile );
            if ( $res )
            {
                ( 25107, $aFile );
            }
        }
        else
        {
            $res = @$this->img( @$this->img );
            if ( $res )
            {
                ( 25108 );
            }
        }
    }

    public function Destroy( )
    {
        imagedestroy( $this->img );
    }

    public function SetImgFormat( $aFormat, $aQuality = 75 )
    {
        $this->quality = $aQuality;
        $aFormat = strtolower( $aFormat );
        $tst = TRUE;
        $supported = imagetypes( );
        if ( $aFormat == "auto" )
        {
            if ( $supported & IMG_PNG )
            {
                $this->img_format = "png";
                return TRUE;
            }
            if ( $supported & IMG_JPG )
            {
                $this->img_format = "jpeg";
                return TRUE;
            }
            if ( $supported & IMG_GIF )
            {
                $this->img_format = "gif";
                return TRUE;
            }
            ( 25109 );
            return TRUE;
        }
        if ( $aFormat == "jpeg" || $aFormat == "png" || $aFormat == "gif" )
        {
            if ( $aFormat == "jpeg" && !( $supported & IMG_JPG ) )
            {
                $tst = FALSE;
            }
            else
            {
                if ( $aFormat == "png" && !( $supported & IMG_PNG ) )
                {
                    $tst = FALSE;
                }
                else
                {
                    if ( $aFormat == "gif" && !( $supported & IMG_GIF ) )
                    {
                        $tst = FALSE;
                    }
                    else
                    {
                        $this->img_format = $aFormat;
                        return TRUE;
                    }
                }
            }
        }
        $tst = FALSE;
        if ( $tst )
        {
            ( 25110, $aFormat );
        }
    }

}

class RotImage extends Image
{

    public $a = 0;
    public $dx = 0;
    public $dy = 0;
    public $transx = 0;
    public $transy = 0;
    private $m = array( );

    public function RotImage( $aWidth, $aHeight, $a = 0, $aFormat = DEFAULT_GFORMAT )
    {
        $this->Image( $aWidth, $aHeight, $aFormat );
        $this->dx = $this->left_margin + $this->plotwidth / 2;
        $this->dy = $this->top_margin + $this->plotheight / 2;
        $this->SetAngle( $a );
    }

    public function SetCenter( $dx, $dy )
    {
        $old_dx = $this->dx;
        $old_dy = $this->dy;
        $this->dx = $dx;
        $this->dy = $dy;
        $this->a( $this->a );
        return array( $old_dx, $old_dy );
    }

    public function SetTranslation( $dx, $dy )
    {
        $old = array( $this->transx, $this->transy );
        $this->transx = $dx;
        $this->transy = $dy;
        return $old;
    }

    public function UpdateRotMatrice( )
    {
        $a = $this->a;
        $a *= M_PI / 180;
        $sa = sin( $a );
        $ca = cos( $a );
        $this->m[0][0] = $ca;
        $this->m[0][1] = 0 - $sa;
        $this->m[0][2] = $this->dx * ( 1 - $ca ) + $sa * $this->dy;
        $this->m[1][0] = $sa;
        $this->m[1][1] = $ca;
        $this->m[1][2] = $this->dy * ( 1 - $ca ) - $sa * $this->dx;
    }

    public function SetAngle( $a )
    {
        $tmp = $this->a;
        $this->a = $a;
        $this->UpdateRotMatrice( );
        return $tmp;
    }

    public function Circle( $xc, $yc, $r )
    {
        list( $xc, $yc ) = $this->Rotate( $xc, $yc );
        ( $xc, $yc, $r );
    }

    public function FilledCircle( $xc, $yc, $r )
    {
        list( $xc, $yc ) = $this->Rotate( $xc, $yc );
        ( $xc, $yc, $r );
    }

    public function Arc( $xc, $yc, $w, $h, $s, $e )
    {
        list( $xc, $yc ) = $this->Rotate( $xc, $yc );
        $s += $this->a;
        $e += $this->a;
        ( $xc, $yc, $w, $h, $s, $e );
    }

    public function FilledArc( $xc, $yc, $w, $h, $s, $e, $style = "" )
    {
        list( $xc, $yc ) = $this->Rotate( $xc, $yc );
        $s += $this->a;
        $e += $this->a;
        ( $xc, $yc, $w, $h, $s, $e );
    }

    public function SetMargin( $lm, $rm, $tm, $bm )
    {
        ( $lm, $rm, $tm, $bm );
        $this->dx = $this->left_margin + $this->plotwidth / 2;
        $this->dy = $this->top_margin + $this->plotheight / 2;
        $this->UpdateRotMatrice( );
    }

    public function Rotate( $x, $y )
    {
        if ( $this->a == 0 || $this->a == 360 )
        {
            return array( $x + $this->transx, $y + $this->transy );
        }
        $x1 = round( $this->m[0][0] * $x + $this->m[0][1] * $y, 1 ) + $this->m[0][2] + $this->transx;
        $y1 = round( $this->m[1][0] * $x + $this->m[1][1] * $y, 1 ) + $this->m[1][2] + $this->transy;
        return array( $x1, $y1 );
    }

    public function CopyMerge( $fromImg, $toX, $toY, $fromX, $fromY, $toWidth, $toHeight, $fromWidth = -1, $fromHeight = -1, $aMix = 100 )
    {
        list( $toX, $toY ) = $this->Rotate( $toX, $toY );
        ( $fromImg, $toX, $toY, $fromX, $fromY, $toWidth, $toHeight, $fromWidth, $fromHeight, $aMix );
    }

    public function ArrRotate( $pnts )
    {
        $n = count( $pnts ) - 1;
        $i = 0;
        for ( ; $i < $n; $i += 2 )
        {
            list( $x, $y ) = $pnts[$i + 1]( $pnts[$i], $pnts[$i + 1] );
            $pnts[$i] = $x;
            $pnts[$i + 1] = $y;
        }
        return $pnts;
    }

    public function DashedLine( $x1, $y1, $x2, $y2, $dash_length = 1, $dash_space = 4 )
    {
        list( $x1, $y1 ) = $this->Rotate( $x1, $y1 );
        $y2 = $this->Rotate( $x2, $y2 )[1];
        $x2 = $this->Rotate( $x2, $y2 )[0];
        ( $x1, $y1, $x2, $y2, $dash_length, $dash_space );
    }

    public function Line( $x1, $y1, $x2, $y2 )
    {
        list( $x1, $y1 ) = $this->Rotate( $x1, $y1 );
        $y2 = $this->Rotate( $x2, $y2 )[1];
        $x2 = $this->Rotate( $x2, $y2 )[0];
        ( $x1, $y1, $x2, $y2 );
    }

    public function Rectangle( $x1, $y1, $x2, $y2 )
    {
        ( $x1, $y1, $x2, $y2 );
    }

    public function FilledRectangle( $x1, $y1, $x2, $y2 )
    {
        if ( $y1 == $y2 || $x1 == $x2 )
        {
            $this->Line( $x1, $y1, $x2, $y2 );
        }
        else
        {
            $this->FilledPolygon( array( $x1, $y1, $x2, $y1, $x2, $y2, $x1, $y2 ) );
        }
    }

    public function Polygon( $pnts, $closed = FALSE, $fast = FALSE )
    {
        ( $pnts, $closed, $fast );
    }

    public function FilledPolygon( $pnts )
    {
        ( $this->ArrRotate( $pnts ) );
    }

    public function Point( $x, $y )
    {
        list( $xp, $yp ) = $this->Rotate( $x, $y );
        ( $xp, $yp );
    }

    public function StrokeText( $x, $y, $txt, $dir = 0, $paragraph_align = "left", $debug = FALSE )
    {
        list( $xp, $yp ) = $this->Rotate( $x, $y );
        return ( $xp, $yp, $txt, $dir, $paragraph_align, $debug );
    }

}

class ImgStreamCache
{

    private $cache_dir;
    private $img;
    private $timeout = 0;

    public function ImgStreamCache( $aImg, $aCacheDir = CACHE_DIR )
    {
        $this->img = $aImg;
        $this->cache_dir = $aCacheDir;
    }

    public function SetTimeout( $aTimeout )
    {
        $this->timeout = $aTimeout;
    }

    public function PutAndStream( $aImage, $aCacheFileName, $aInline, $aStrokeFileName )
    {
        global $gJpgBrandTiming;
        if ( $gJpgBrandTiming )
        {
            global $tim;
            $t = $tim->Pop( ) / 1000;
            $c = $aImage->SetColor( "black" );
            $t = sprintf( BRAND_TIME_FORMAT, round( $t, 3 ) );
            imagestring( $this->img->img, 2, 5, $this->img->height - 20, $t, $c );
        }
        if ( _FORCE_IMGTOFILE )
        {
            $aStrokeFileName = _FORCE_IMGDIR.genimgname( );
        }
        if ( $aStrokeFileName != "" )
        {
            if ( $aStrokeFileName == "auto" )
            {
                $aStrokeFileName = genimgname( );
            }
            if ( file_exists( $aStrokeFileName ) && !unlink( $aStrokeFileName ) )
            {
                ( 25111, $aStrokeFileName );
            }
            $aImage->Stream( $aStrokeFileName );
            do
            {
            }
            else if ( $aCacheFileName != "" && USE_CACHE )
            {
                $aCacheFileName = $this->cache_dir.$aCacheFileName;
                if ( file_exists( $aCacheFileName ) )
                {
                    if ( $aInline )
                    {
                        $diff = time( ) - filemtime( $aCacheFileName );
                        if ( $diff < 0 )
                        {
                            ( 25112, $aCacheFileName );
                        }
                        if ( 0 < $this->timeout && $diff <= $this->timeout * 60 )
                        {
                        }
                    }
                    else
                    {
                        if ( @unlink( $aCacheFileName ) )
                        {
                            ( 25113, $aStrokeFileName );
                        }
                        $aImage->Stream( $aCacheFileName );
                    }
                }
                else
                {
                    dirname( $aCacheFileName )( dirname( $aCacheFileName ) );
                    if ( is_writeable( dirname( $aCacheFileName ) ) )
                    {
                        ( 25114, $aCacheFileName );
                    }
                    $aImage->Stream( $aCacheFileName );
                }
                $res = TRUE;
                if ( CACHE_FILE_GROUP != "" )
                {
                    $res = @chgrp( $aCacheFileName, @CACHE_FILE_GROUP );
                }
                if ( CACHE_FILE_MOD != "" )
                {
                    $res = @chmod( $aCacheFileName, @CACHE_FILE_MOD );
                }
                if ( $res )
                {
                    ( 25115, $aStrokeFileName );
                }
                $aImage->Destroy( );
                if ( !$aInline )
                {
                    break;
                }
                else
                {
                    if ( $fh = @fopen( $aCacheFileName, "rb" ) )
                    {
                        $this->img->Headers( );
                        fpassthru( $fh );
                    }
                    else
                    {
                        ( 25116, $aFile );
                    }
                }
            }
            else if ( $aInline )
            {
                $this->img->Headers( );
                $aImage->Stream( );
            } while ( 0 );
        }
        else
        {
        }
    }

    public function GetAndStream( $aCacheFileName )
    {
        $aCacheFileName = $this->cache_dir.$aCacheFileName;
        if ( USE_CACHE && file_exists( $aCacheFileName ) && 0 <= $this->timeout )
        {
            $diff = time( ) - filemtime( $aCacheFileName );
            if ( 0 < $this->timeout && $this->timeout * 60 < $diff )
            {
                return FALSE;
            }
            if ( $fh = @fopen( $aCacheFileName, "rb" ) )
            {
                $this->img->Headers( );
                fpassthru( $fh );
                return TRUE;
            }
            ( 25117, $aCacheFileName );
        }
        return FALSE;
    }

    public function MakeDirs( $aFile )
    {
        $dirs = array( );
        while ( !file_exists( $aFile ) )
        {
            $dirs[] = $aFile;
            $aFile = dirname( $aFile );
        }
        $i = sizeof( $dirs ) - 1;
        for ( ; 0 <= $i; --$i )
        {
            if ( @mkdir( @$dirs[$i], 511 ) )
            {
                ( 25118, $aFile );
            }
            if ( CACHE_FILE_GROUP != "" )
            {
                $res = TRUE;
                $res = @chgrp( @$dirs[$i], @CACHE_FILE_GROUP );
                $res = @chmod( @$dirs[$i], 511 );
                if ( $res )
                {
                    ( 25119, $aFile );
                }
            }
        }
        return TRUE;
    }

}

class Legend
{

    public $txtcol = array( );
    private $color = array( 0, 0, 0 );
    private $fill_color = array( 235, 235, 235 );
    private $shadow = TRUE;
    private $shadow_color = "darkgray@0.5";
    private $mark_abs_hsize = _DEFAULT_LPM_SIZE;
    private $mark_abs_vsize = _DEFAULT_LPM_SIZE;
    private $xmargin = 10;
    private $ymargin = 3;
    private $shadow_width = 2;
    private $xlmargin = 2;
    private $ylmargin = "";
    private $xpos = 0.05;
    private $ypos = 0.15;
    private $xabspos = -1;
    private $yabspos = -1;
    private $halign = "right";
    private $valign = "top";
    private $font_family = FF_FONT1;
    private $font_style = FS_NORMAL;
    private $font_size = 12;
    private $font_color = "black";
    private $hide = FALSE;
    private $layout_n = 1;
    private $weight = 1;
    private $frameweight = 1;
    private $csimareas = "";
    private $reverse = FALSE;

    public function Legend( )
    {
    }

    public function Hide( $aHide = TRUE )
    {
        $this->hide = $aHide;
    }

    public function SetHColMargin( $aXMarg )
    {
        $this->xmargin = $aXMarg;
    }

    public function SetVColMargin( $aSpacing )
    {
        $this->ymargin = $aSpacing;
    }

    public function SetLeftMargin( $aXMarg )
    {
        $this->xlmargin = $aXMarg;
    }

    public function SetLineSpacing( $aSpacing )
    {
        $this->ymargin = $aSpacing;
    }

    public function SetShadow( $aShow = "gray", $aWidth = 2 )
    {
        if ( is_string( $aShow ) )
        {
            $this->shadow_color = $aShow;
            $this->shadow = TRUE;
        }
        else
        {
            $this->shadow = $aShow;
        }
        $this->shadow_width = $aWidth;
    }

    public function SetMarkAbsSize( $aSize )
    {
        $this->mark_abs_vsize = $aSize;
        $this->mark_abs_hsize = $aSize;
    }

    public function SetMarkAbsVSize( $aSize )
    {
        $this->mark_abs_vsize = $aSize;
    }

    public function SetMarkAbsHSize( $aSize )
    {
        $this->mark_abs_hsize = $aSize;
    }

    public function SetLineWeight( $aWeight )
    {
        $this->weight = $aWeight;
    }

    public function SetFrameWeight( $aWeight )
    {
        $this->frameweight = $aWeight;
    }

    public function SetLayout( $aDirection = LEGEND_VERT )
    {
        $this->layout_n = $aDirection == LEGEND_VERT ? 1 : 99;
    }

    public function SetColumns( $aCols )
    {
        $this->layout_n = $aCols;
    }

    public function SetReverse( $f = TRUE )
    {
        $this->reverse = $f;
    }

    public function SetColor( $aFontColor, $aColor = "black" )
    {
        $this->font_color = $aFontColor;
        $this->color = $aColor;
    }

    public function SetFont( $aFamily, $aStyle = FS_NORMAL, $aSize = 10 )
    {
        $this->font_family = $aFamily;
        $this->font_style = $aStyle;
        $this->font_size = $aSize;
    }

    public function SetPos( $aX, $aY, $aHAlign = "right", $aVAlign = "top" )
    {
        $this->Pos( $aX, $aY, $aHAlign, $aVAlign );
    }

    public function SetAbsPos( $aX, $aY, $aHAlign = "right", $aVAlign = "top" )
    {
        $this->xabspos = $aX;
        $this->yabspos = $aY;
        $this->halign = $aHAlign;
        $this->valign = $aVAlign;
    }

    public function Pos( $aX, $aY, $aHAlign = "right", $aVAlign = "top" )
    {
        if ( !( $aX < 1 ) || !( $aY < 1 ) )
        {
            ( 25120 );
        }
        $this->xpos = $aX;
        $this->ypos = $aY;
        $this->halign = $aHAlign;
        $this->valign = $aVAlign;
    }

    public function SetFillColor( $aColor )
    {
        $this->fill_color = $aColor;
    }

    public function Add( $aTxt, $aColor, $aPlotmark = "", $aLinestyle = 0, $csimtarget = "", $csimalt = "" )
    {
        $this->txtcol[] = array( $aTxt, $aColor, $aPlotmark, $aLinestyle, $csimtarget, $csimalt );
    }

    public function GetCSIMAreas( )
    {
        return $this->csimareas;
    }

    public function Stroke( &$aImg )
    {
        $fillBoxFrameWeight = 1;
        if ( $this->hide )
        {
        }
        else
        {
            $this->font_size( $this->font_family, $this->font_style, $this->font_size );
            if ( $this->reverse )
            {
                $this->txtcol = array_reverse( $this->txtcol );
            }
            $n = count( $this->txtcol );
            if ( $n == 0 )
            {
            }
            else
            {
                $numcolumns = $this->layout_n < $n ? $this->layout_n : $n;
                $i = 0;
                for ( ; $i < $numcolumns; ++$i )
                {
                    $colwidth[$i] = $this->txtcol[$i][0]( $this->txtcol[$i][0] ) + 2 * $this->xmargin + 2 * $this->mark_abs_hsize;
                    $colheight[$i] = 0;
                }
                $rows = 0;
                $rowheight[0] = 0;
                $i = 0;
                for ( ; $i < $n; ++$i )
                {
                    $h = max( $this->mark_abs_vsize, $this->txtcol[$i][0]( $this->txtcol[$i][0] ) ) + $this->ymargin;
                    if ( $i % $numcolumns == 0 )
                    {
                        ++$rows;
                        $rowheight[$rows - 1] = 0;
                    }
                    $rowheight[$rows - 1] = max( $rowheight[$rows - 1], $h );
                }
                $abs_height = 0;
                $i = 0;
                for ( ; $i < $rows; ++$i )
                {
                    $abs_height += $rowheight[$i];
                }
                $abs_height = max( $abs_height, $this->mark_abs_vsize );
                $abs_height += $this->ymargin + 3;
                $i = $numcolumns;
                for ( ; $i < $n; ++$i )
                {
                    $colwidth[$i % $numcolumns] = max( $this->txtcol[$i][0]( $this->txtcol[$i][0] ) + 2 * $this->xmargin + 2 * $this->mark_abs_hsize, $colwidth[$i % $numcolumns] );
                }
                $mtw = 0;
                $i = 0;
                for ( ; $i < $numcolumns; ++$i )
                {
                    $mtw += $colwidth[$i];
                }
                $abs_width = $mtw + $this->xlmargin;
                if ( $this->xabspos === -1 && $this->yabspos === -1 )
                {
                    $this->xabspos = $this->xpos * $aImg->width;
                    $this->yabspos = $this->ypos * $aImg->height;
                }
                if ( $this->halign == "left" )
                {
                    $xp = $this->xabspos;
                }
                else if ( $this->halign == "center" )
                {
                    $xp = $this->xabspos - $abs_width / 2;
                }
                else
                {
                    $xp = $aImg->width - $this->xabspos - $abs_width;
                }
                $yp = $this->yabspos;
                if ( $this->valign == "center" )
                {
                    $yp -= $abs_height / 2;
                }
                else if ( $this->valign == "bottom" )
                {
                    $yp -= $abs_height;
                }
                $this->color( $this->color );
                $this->frameweight( $this->frameweight );
                $aImg->SetLineStyle( "solid" );
                if ( $this->shadow )
                {
                    $this->shadow_color( $xp, $yp, $xp + $abs_width + $this->shadow_width, $yp + $abs_height + $this->shadow_width, $this->fill_color, $this->shadow_width, $this->shadow_color );
                }
                else
                {
                    $this->fill_color( $this->fill_color );
                    $aImg->FilledRectangle( $xp, $yp, $xp + $abs_width, $yp + $abs_height );
                    $this->color( $this->color );
                    $aImg->Rectangle( $xp, $yp, $xp + $abs_width, $yp + $abs_height );
                }
                $x1 = $xp + $this->mark_abs_hsize + $this->xlmargin;
                $y1 = $yp + $this->ymargin;
                $f2 = round( $aImg->GetTextHeight( "X" ) / 2 );
                $grad = new Gradient( $aImg );
                $patternFactory = NULL;
                $i = 1;
                $row = 0;
                foreach ( $this->txtcol as $p )
                {
                    if ( _JPG_DEBUG )
                    {
                        $aImg->SetLineWeight( 1 );
                        $aImg->SetColor( "red" );
                        $aImg->SetLineStyle( "solid" );
                        $aImg->Rectangle( $xp, $y1, $xp + $abs_width, $y1 + $rowheight[$row] );
                    }
                    $this->weight( $this->weight );
                    $x1 = round( $x1 );
                    $y1 = round( $y1 );
                    if ( !empty( $p[2] ) && -1 < $p[2]->GetType( ) )
                    {
                        $p[1]( $p[1] );
                        if ( is_string( $p[3] ) || 0 < $p[3] )
                        {
                            $p[3]( $p[3] );
                            $aImg->StyleLine( $x1 - $this->mark_abs_hsize, $y1 + $f2, $x1 + $this->mark_abs_hsize, $y1 + $f2 );
                        }
                        if ( $p[2]->GetType( ) != MARK_IMG )
                        {
                            $p[2]->iFormatCallback = "";
                            if ( $p[2]->GetType( ) == MARK_FILLEDCIRCLE || $p[2]->GetType( ) == MARK_CIRCLE )
                            {
                                min( $this->mark_abs_vsize, $this->mark_abs_hsize )( min( $this->mark_abs_vsize, $this->mark_abs_hsize ) / 2 );
                                $p[2]->Stroke( $aImg, $x1, $y1 + $f2 );
                            }
                            else
                            {
                                $p[2]->SetSize( min( $this->mark_abs_vsize, $this->mark_abs_hsize ) );
                                $p[2]->Stroke( $aImg, $x1, $y1 + $f2 );
                            }
                        }
                    }
                    else if ( !empty( $p[2] ) && ( is_string( $p[3] ) || 0 < $p[3] ) )
                    {
                        $p[1]( $p[1] );
                        $p[3]( $p[3] );
                        $aImg->StyleLine( $x1 - 1, $y1 + $f2, $x1 + $this->mark_abs_hsize, $y1 + $f2 );
                        $aImg->StyleLine( $x1 - 1, $y1 + $f2 + 1, $x1 + $this->mark_abs_hsize, $y1 + $f2 + 1 );
                    }
                    else
                    {
                        $color = $p[1];
                        $boxsize = min( $this->mark_abs_vsize, $this->mark_abs_hsize ) + 2;
                        $ym = round( $y1 + $f2 - $boxsize / 2 );
                        if ( $p[3] < -100 )
                        {
                            if ( $patternFactory == NULL )
                            {
                                $patternFactory = new RectPatternFactory( );
                            }
                            $prect = $p[1][1]( $p[1][0], $p[1][1], 1 );
                            $p[1][3]( $p[1][3] );
                            $p[1]( $p[1][2] + 1 );
                            new Rectangle( $x1, $ym, $boxsize, $boxsize )( new Rectangle( $x1, $ym, $boxsize, $boxsize ) );
                            $prect->Stroke( $aImg );
                            $prect = NULL;
                        }
                        else
                        {
                            if ( is_array( $color ) && count( $color ) == 2 )
                            {
                                $color[1]( $x1, $ym, $x1 + $boxsize, $ym + $boxsize, $color[0], $color[1], 0 - $p[3] );
                            }
                            else
                            {
                                $p[1]( $p[1] );
                                $aImg->FilledRectangle( $x1, $ym, $x1 + $boxsize, $ym + $boxsize );
                            }
                            $this->color( $this->color );
                            $aImg->SetLineWeight( $fillBoxFrameWeight );
                            $aImg->Rectangle( $x1, $ym, $x1 + $boxsize, $ym + $boxsize );
                        }
                    }
                    $this->font_color( $this->font_color );
                    $this->font_size( $this->font_family, $this->font_style, $this->font_size );
                    $aImg->SetTextAlign( "left", "top" );
                    $p[0]( round( $x1 + $this->mark_abs_hsize + $this->xmargin ), $y1, $p[0] );
                    if ( empty( $p[4] ) )
                    {
                        $xe = $x1 + $this->xmargin + $this->mark_abs_hsize + $p[0]( $p[0] );
                        $ye = $y1 + max( $this->mark_abs_vsize, $p[0]( $p[0] ) );
                        $coords = "{$x1},{$y1},{$xe},{$y1},{$xe},{$ye},{$x1},{$ye}";
                        if ( empty( $p[4] ) )
                        {
                            $ && _514764392 .= "csimareas";
                            if ( empty( $p[5] ) )
                            {
                                $tmp = sprintf( $p[5], $p[0] );
                                $ && _514764896 .= "csimareas";
                            }
                            $ && _514764928 .= "csimareas";
                        }
                    }
                    if ( $this->layout_n <= $i )
                    {
                        $x1 = $xp + $this->mark_abs_hsize + $this->xlmargin;
                        $y1 += $rowheight[$row++];
                        $i = 1;
                    }
                    else
                    {
                        $x1 += $colwidth[( $i - 1 ) % $numcolumns];
                        ++$i;
                    }
                }
            }
        }
    }

}

class DisplayValue
{

    public $margin = 5;
    public $show = FALSE;
    public $valign = "";
    public $halign = "center";
    public $format = "%.1f";
    public $negformat = "";
    private $ff = FF_FONT1;
    private $fs = FS_NORMAL;
    private $fsize = 10;
    private $iFormCallback = "";
    private $angle = 0;
    private $color = "navy";
    private $negcolor = "";
    private $iHideZero = FALSE;

    public function Show( $aFlag = TRUE )
    {
        $this->show = $aFlag;
    }

    public function SetColor( $aColor, $aNegcolor = "" )
    {
        $this->color = $aColor;
        $this->negcolor = $aNegcolor;
    }

    public function SetFont( $aFontFamily, $aFontStyle = FS_NORMAL, $aFontSize = 10 )
    {
        $this->ff = $aFontFamily;
        $this->fs = $aFontStyle;
        $this->fsize = $aFontSize;
    }

    public function ApplyFont( $aImg )
    {
        $this->fsize( $this->ff, $this->fs, $this->fsize );
    }

    public function SetMargin( $aMargin )
    {
        $this->margin = $aMargin;
    }

    public function SetAngle( $aAngle )
    {
        $this->angle = $aAngle;
    }

    public function SetAlign( $aHAlign, $aVAlign = "" )
    {
        $this->halign = $aHAlign;
        $this->valign = $aVAlign;
    }

    public function SetFormat( $aFormat, $aNegFormat = "" )
    {
        $this->format = $aFormat;
        $this->negformat = $aNegFormat;
    }

    public function SetFormatCallback( $aFunc )
    {
        $this->iFormCallback = $aFunc;
    }

    public function HideZero( $aFlag = TRUE )
    {
        $this->iHideZero = $aFlag;
    }

    public function Stroke( $img, $aVal, $x, $y )
    {
        if ( $this->show )
        {
            if ( $this->negformat == "" )
            {
                $this->negformat = $this->format;
            }
            if ( $this->negcolor == "" )
            {
                $this->negcolor = $this->color;
            }
            if ( $aVal === NULL || is_string( $aVal ) && ( $aVal == "" || $aVal == "-" || $aVal == "x" ) )
            {
            }
            else
            {
                if ( is_numeric( $aVal ) && $aVal == 0 && $this->iHideZero )
                {
                }
                else
                {
                    if ( $this->iFormCallback != "" )
                    {
                        $f = $this->iFormCallback;
                        $sval = call_user_func( $f, $aVal );
                    }
                    else if ( is_numeric( $aVal ) )
                    {
                        if ( 0 <= $aVal )
                        {
                            $sval = sprintf( $this->format, $aVal );
                        }
                        else
                        {
                            $sval = sprintf( $this->negformat, $aVal );
                        }
                    }
                    else
                    {
                        $sval = $aVal;
                    }
                    $y -= sign( $aVal ) * $this->margin;
                    $txt = new Text( $sval, $x, $y );
                    $this->fsize( $this->ff, $this->fs, $this->fsize );
                    if ( $this->valign == "" )
                    {
                        if ( 0 <= $aVal )
                        {
                            $valign = "bottom";
                        }
                        else
                        {
                            $valign = "top";
                        }
                    }
                    else
                    {
                        $valign = $this->valign;
                    }
                    $this->halign( $this->halign, $valign );
                    $this->angle( $this->angle );
                    if ( 0 < $aVal )
                    {
                        $this->color( $this->color );
                    }
                    else
                    {
                        $this->negcolor( $this->negcolor );
                    }
                    $txt->Stroke( $img );
                }
            }
        }
    }

}

class Plot
{

    public $numpoints = 0;
    public $value;
    public $legend = "";
    public $coords = array( );
    public $color = "black";
    public $hidelegend = FALSE;
    public $line_weight = 1;
    public $csimtargets = array( );
    public $csimareas = "";
    public $csimalts;
    public $legendcsimtarget = "";
    public $legendcsimalt = "";
    protected $weight = 1;
    protected $center = FALSE;

    public function Plot( $aDatay, $aDatax = FALSE )
    {
        $this->numpoints = count( $aDatay );
        if ( $this->numpoints == 0 )
        {
            ( 25121 );
        }
        $this->coords[0] = $aDatay;
        if ( is_array( $aDatax ) )
        {
            $this->coords[1] = $aDatax;
            $n = count( $aDatax );
            $i = 0;
            for ( ; $i < $n; ++$i )
            {
                if ( is_numeric( $aDatax[$i] ) )
                {
                    ( 25070 );
                }
            }
        }
        $this->value = new DisplayValue( );
    }

    public function Stroke( $aImg, $aXScale, $aYScale )
    {
        ( 25122 );
    }

    public function HideLegend( $f = TRUE )
    {
        $this->hidelegend = $f;
    }

    public function DoLegend( $graph )
    {
        if ( $this->hidelegend )
        {
            $this->Legend( $graph );
        }
    }

    public function StrokeDataValue( $img, $aVal, $x, $y )
    {
        $this->value->Stroke( $img, $aVal, $x, $y );
    }

    public function SetCSIMTargets( $aTargets, $aAlts = NULL )
    {
        $this->csimtargets = $aTargets;
        $this->csimalts = $aAlts;
    }

    public function GetCSIMareas( )
    {
        return $this->csimareas;
    }

    public function PreStrokeAdjust( $aGraph )
    {
        if ( substr( $aGraph->axtype, 0, 4 ) == "text" && isset( $this->coords[1] ) )
        {
            ( 25123 );
        }
        return TRUE;
    }

    public function Min( )
    {
        if ( isset( $this->coords[1] ) )
        {
            $x = $this->coords[1];
        }
        else
        {
            $x = "";
        }
        if ( $x != "" && 0 < count( $x ) )
        {
            $xm = min( $x );
        }
        else
        {
            $xm = 0;
        }
        $y = $this->coords[0];
        $cnt = count( $y );
        if ( 0 < $cnt )
        {
            $i = 0;
            while ( !( $i < $cnt ) || is_numeric( $ym = $y[$i] ) )
            {
                ++$i;
            }
            while ( $i < $cnt )
            {
                if ( is_numeric( $y[$i] ) )
                {
                    $ym = min( $ym, $y[$i] );
                }
                ++$i;
            }
        }
        $ym = "";
        return array( $xm, $ym );
    }

    public function Max( )
    {
        if ( isset( $this->coords[1] ) )
        {
            $x = $this->coords[1];
        }
        else
        {
            $x = "";
        }
        if ( $x != "" && 0 < count( $x ) )
        {
            $xm = max( $x );
        }
        else
        {
            $xm = $this->numpoints - 1;
        }
        $y = $this->coords[0];
        if ( 0 < count( $y ) )
        {
            $cnt = count( $y );
            $i = 0;
            while ( !( $i < $cnt ) || is_numeric( $ym = $y[$i] ) )
            {
                ++$i;
            }
            while ( $i < $cnt )
            {
                if ( is_numeric( $y[$i] ) )
                {
                    $ym = max( $ym, $y[$i] );
                }
                ++$i;
            }
        }
        $ym = "";
        return array( $xm, $ym );
    }

    public function SetColor( $aColor )
    {
        $this->color = $aColor;
    }

    public function SetLegend( $aLegend, $aCSIM = "", $aCSIMAlt = "" )
    {
        $this->legend = $aLegend;
        $this->legendcsimtarget = $aCSIM;
        $this->legendcsimalt = $aCSIMAlt;
    }

    public function SetWeight( $aWeight )
    {
        $this->weight = $aWeight;
    }

    public function SetLineWeight( $aWeight = 1 )
    {
        $this->line_weight = $aWeight;
    }

    public function SetCenter( $aCenter = TRUE )
    {
        $this->center = $aCenter;
    }

    public function StrokeMargin( $aImg )
    {
        return TRUE;
    }

    public function Legend( $aGraph )
    {
        if ( $this->legend != "" )
        {
            $aGraph->legend->Add( $this->legend, $this->color, "", 0, $this->legendcsimtarget, $this->legendcsimalt );
        }
    }

}

class PlotLine
{

    public $scaleposition;
    public $direction = -1;
    protected $weight = 1;
    protected $color = "black";

    public function PlotLine( $aDir = HORIZONTAL, $aPos = 0, $aColor = "black", $aWeight = 1 )
    {
        $this->direction = $aDir;
        $this->color = $aColor;
        $this->weight = $aWeight;
        $this->scaleposition = $aPos;
    }

    public function SetPosition( $aScalePosition )
    {
        $this->scaleposition = $aScalePosition;
    }

    public function SetDirection( $aDir )
    {
        $this->direction = $aDir;
    }

    public function SetColor( $aColor )
    {
        $this->color = $aColor;
    }

    public function SetWeight( $aWeight )
    {
        $this->weight = $aWeight;
    }

    public function PreStrokeAdjust( $aGraph )
    {
    }

    public function Stroke( $aImg, $aXScale, $aYScale )
    {
        $this->color( $this->color );
        $this->weight( $this->weight );
        if ( $this->direction == VERTICAL )
        {
            $ymin_abs = $aYScale->Translate( $aYScale->GetMinVal( ) );
            $ymax_abs = $aYScale->Translate( $aYScale->GetMaxVal( ) );
            $xpos_abs = $this->scaleposition( $this->scaleposition );
            $aImg->Line( $xpos_abs, $ymin_abs, $xpos_abs, $ymax_abs );
        }
        else if ( $this->direction == HORIZONTAL )
        {
            $xmin_abs = $aXScale->Translate( $aXScale->GetMinVal( ) );
            $xmax_abs = $aXScale->Translate( $aXScale->GetMaxVal( ) );
            $ypos_abs = $this->scaleposition( $this->scaleposition );
            $aImg->Line( $xmin_abs, $ypos_abs, $xmax_abs, $ypos_abs );
        }
        else
        {
            ( 25125 );
        }
    }

}

function CheckPHPVersion( $aMinVersion )
{
    list( $majorC, $minorC, $editC ) = split( "[/.-]", PHP_VERSION );
    list( $majorR, $minorR, $editR ) = split( "[/.-]", $aMinVersion );
    if ( $majorR < $majorC )
    {
        return TRUE;
    }
    if ( $majorC < $majorR )
    {
        return FALSE;
    }
    if ( $minorR < $minorC )
    {
        return TRUE;
    }
    if ( $minorC < $minorR )
    {
        return FALSE;
    }
    if ( $editR <= $editC )
    {
        return TRUE;
    }
    return TRUE;
}

function _phpErrorHandler( $errno, $errmsg, $filename, $linenum, $vars )
{
    if ( $errno & error_reporting( ) )
    {
        ( 25003, basename( $filename ), $linenum, $errmsg );
    }
}

function sign( $a )
{
    if ( 0 <= $a )
    {
        return 1;
    }
    return -1;
}

function GenImgName( )
{
    $supported = imagetypes( );
    if ( $supported & IMG_PNG )
    {
        $img_format = "png";
    }
    else if ( $supported & IMG_GIF )
    {
        $img_format = "gif";
    }
    else if ( $supported & IMG_JPG )
    {
        $img_format = "jpeg";
    }
    if ( isset( $_SERVER['PHP_SELF'] ) )
    {
        ( 25005 );
    }
    $fname = basename( $_SERVER['PHP_SELF'] );
    if ( empty( $_SERVER['QUERY_STRING'] ) )
    {
        $q = @$_SERVER['QUERY_STRING'];
        $fname .= "_".preg_replace( "/\\W/", "_", $q ).".".$img_format;
        return $fname;
    }
    $fname = substr( $fname, 0, strlen( $fname ) - 4 ).".".$img_format;
    return $fname;
}

require_once( "jpg-config.inc.php" );
require_once( "jpgraph_gradient.php" );
require_once( "jpgraph_errhandler.inc.php" );
define( "JPG_VERSION", "2.1.3" );
define( "MIN_PHPVERSION", "5.1.0" );
define( "USE_TRUECOLOR", TRUE );
if ( USE_CACHE )
{
    if ( defined( "CACHE_DIR" ) )
    {
        if ( strstr( PHP_OS, "WIN" ) )
        {
            if ( empty( $_SERVER['TEMP'] ) )
            {
                $t = new ErrMsgText( );
                $msg = $t->Get( 11, $file, $lineno );
                exit( $msg );
            }
            define( "CACHE_DIR", $_SERVER['TEMP']."/" );
        }
        else
        {
            define( "CACHE_DIR", "/tmp/jpgraph_cache/" );
        }
    }
}
else if ( defined( "CACHE_DIR" ) )
{
    define( "CACHE_DIR", "" );
}
if ( defined( "TTF_DIR" ) )
{
    if ( strstr( PHP_OS, "WIN" ) )
    {
        $sroot = getenv( "SystemRoot" );
        if ( empty( $sroot ) )
        {
            $t = new ErrMsgText( );
            $msg = $t->Get( 12, $file, $lineno );
            exit( $msg );
        }
        define( "TTF_DIR", $sroot."/fonts/" );
    }
    else
    {
        define( "TTF_DIR", "/usr/X11R6/lib/X11/fonts/truetype/" );
    }
}
define( "FF_COURIER", 10 );
define( "FF_VERDANA", 11 );
define( "FF_TIMES", 12 );
define( "FF_COMIC", 14 );
define( "FF_ARIAL", 15 );
define( "FF_GEORGIA", 16 );
define( "FF_TREBUCHE", 17 );
define( "FF_VERA", 18 );
define( "FF_VERAMONO", 19 );
define( "FF_VERASERIF", 20 );
define( "FF_SIMSUN", 30 );
define( "FF_CHINESE", 31 );
define( "FF_BIG5", 31 );
define( "FF_MINCHO", 40 );
define( "FF_PMINCHO", 41 );
define( "FF_GOTHIC", 42 );
define( "FF_PGOTHIC", 43 );
define( "_FIRST_FONT", 10 );
define( "_LAST_FONT", 43 );
define( "FS_NORMAL", 9001 );
define( "FS_BOLD", 9002 );
define( "FS_ITALIC", 9003 );
define( "FS_BOLDIT", 9004 );
define( "FS_BOLDITALIC", 9004 );
define( "FF_FONT0", 1 );
define( "FF_FONT1", 2 );
define( "FF_FONT2", 4 );
define( "TICKD_DENSE", 1 );
define( "TICKD_NORMAL", 2 );
define( "TICKD_SPARSE", 3 );
define( "TICKD_VERYSPARSE", 4 );
define( "SIDE_LEFT", -1 );
define( "SIDE_RIGHT", 1 );
define( "SIDE_DOWN", -1 );
define( "SIDE_BOTTOM", -1 );
define( "SIDE_UP", 1 );
define( "SIDE_TOP", 1 );
define( "LEGEND_VERT", 0 );
define( "LEGEND_HOR", 1 );
define( "MARK_SQUARE", 1 );
define( "MARK_UTRIANGLE", 2 );
define( "MARK_DTRIANGLE", 3 );
define( "MARK_DIAMOND", 4 );
define( "MARK_CIRCLE", 5 );
define( "MARK_FILLEDCIRCLE", 6 );
define( "MARK_CROSS", 7 );
define( "MARK_STAR", 8 );
define( "MARK_X", 9 );
define( "MARK_LEFTTRIANGLE", 10 );
define( "MARK_RIGHTTRIANGLE", 11 );
define( "MARK_FLASH", 12 );
define( "MARK_IMG", 13 );
define( "MARK_FLAG1", 14 );
define( "MARK_FLAG2", 15 );
define( "MARK_FLAG3", 16 );
define( "MARK_FLAG4", 17 );
define( "MARK_IMG_PUSHPIN", 50 );
define( "MARK_IMG_SPUSHPIN", 50 );
define( "MARK_IMG_LPUSHPIN", 51 );
define( "MARK_IMG_DIAMOND", 52 );
define( "MARK_IMG_SQUARE", 53 );
define( "MARK_IMG_STAR", 54 );
define( "MARK_IMG_BALL", 55 );
define( "MARK_IMG_SBALL", 55 );
define( "MARK_IMG_MBALL", 56 );
define( "MARK_IMG_LBALL", 57 );
define( "MARK_IMG_BEVEL", 58 );
define( "INLINE_YES", 1 );
define( "INLINE_NO", 0 );
define( "BGIMG_FILLPLOT", 1 );
define( "BGIMG_FILLFRAME", 2 );
define( "BGIMG_COPY", 3 );
define( "BGIMG_CENTER", 4 );
define( "DEPTH_BACK", 0 );
define( "DEPTH_FRONT", 1 );
define( "VERTICAL", 1 );
define( "HORIZONTAL", 0 );
define( "AXSTYLE_SIMPLE", 1 );
define( "AXSTYLE_BOXIN", 2 );
define( "AXSTYLE_BOXOUT", 3 );
define( "AXSTYLE_YBOXIN", 4 );
define( "AXSTYLE_YBOXOUT", 5 );
define( "TITLEBKG_STYLE1", 1 );
define( "TITLEBKG_STYLE2", 2 );
define( "TITLEBKG_STYLE3", 3 );
define( "TITLEBKG_FRAME_NONE", 0 );
define( "TITLEBKG_FRAME_FULL", 1 );
define( "TITLEBKG_FRAME_BOTTOM", 2 );
define( "TITLEBKG_FRAME_BEVEL", 3 );
define( "TITLEBKG_FILLSTYLE_HSTRIPED", 1 );
define( "TITLEBKG_FILLSTYLE_VSTRIPED", 2 );
define( "TITLEBKG_FILLSTYLE_SOLID", 3 );
define( "BGRAD_FRAME", 1 );
define( "BGRAD_MARGIN", 2 );
define( "BGRAD_PLOT", 3 );
define( "TABTITLE_WIDTHFIT", 0 );
define( "TABTITLE_WIDTHFULL", -1 );
define( "SKEW3D_UP", 0 );
define( "SKEW3D_DOWN", 1 );
define( "SKEW3D_LEFT", 2 );
define( "SKEW3D_RIGHT", 3 );
define( "LINESTYLE_DOTTED", 1 );
define( "LINESTYLE_DASHED", 2 );
define( "LINESTYLE_LONGDASH", 3 );
define( "LINESTYLE_SOLID", 4 );
define( "_JPG_DEBUG", FALSE );
define( "_FORCE_IMGTOFILE", FALSE );
define( "_FORCE_IMGDIR", "/tmp/jpgimg/" );
if ( checkphpversion( MIN_PHPVERSION ) )
{
    ( 13, PHP_VERSION, MIN_PHPVERSION );
}
if ( !function_exists( "imagetypes" ) || !function_exists( "imagecreatefromstring" ) )
{
    ( 25001 );
}
if ( INSTALL_PHP_ERR_HANDLER )
{
    set_error_handler( "_phpErrorHandler" );
}
if ( isset( $GLOBALS['php_errormsg'] ) && CATCH_PHPERRMSG && !preg_match( "|Deprecated|", $GLOBALS['php_errormsg'] ) )
{
    ( 25004, $GLOBALS['php_errormsg'] );
}
$gJpgBrandTiming = BRAND_TIMING;
$gDateLocale = new DateLocale( );
$gJpgDateLocale = new DateLocale( );
define( "_DEFAULT_LPM_SIZE", 8 );
?>
