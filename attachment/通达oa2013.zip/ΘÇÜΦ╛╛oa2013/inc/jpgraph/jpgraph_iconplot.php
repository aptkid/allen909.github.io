<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class IconPlot
{

    public $iX = 0;
    public $iY = 0;
    public $iScale = 1;
    public $iMix = 100;
    private $iHorAnchor = "left";
    private $iVertAnchor = "top";
    private $iFile = "";
    private $iAnchors = array( "left", "right", "top", "bottom", "center" );
    private $iCountryFlag = "";
    private $iCountryStdSize = 3;
    private $iScalePosY;
    private $iScalePosX;
    private $iImgString = "";

    public function IconPlot( $aFile = "", $aX = 0, $aY = 0, $aScale = 1, $aMix = 100 )
    {
        $this->iFile = $aFile;
        $this->iX = $aX;
        $this->iY = $aY;
        $this->iScale = $aScale;
        if ( $aMix < 0 || 100 < $aMix )
        {
            ( 8001 );
        }
        $this->iMix = $aMix;
    }

    public function SetCountryFlag( $aFlag, $aX = 0, $aY = 0, $aScale = 1, $aMix = 100, $aStdSize = 3 )
    {
        $this->iCountryFlag = $aFlag;
        $this->iX = $aX;
        $this->iY = $aY;
        $this->iScale = $aScale;
        if ( $aMix < 0 || 100 < $aMix )
        {
            ( 8001 );
        }
        $this->iMix = $aMix;
        $this->iCountryStdSize = $aStdSize;
    }

    public function SetPos( $aX, $aY )
    {
        $this->iX = $aX;
        $this->iY = $aY;
    }

    public function CreateFromString( $aStr )
    {
        $this->iImgString = $aStr;
    }

    public function SetScalePos( $aX, $aY )
    {
        $this->iScalePosX = $aX;
        $this->iScalePosY = $aY;
    }

    public function SetScale( $aScale )
    {
        $this->iScale = $aScale;
    }

    public function SetMix( $aMix )
    {
        if ( $aMix < 0 || 100 < $aMix )
        {
            ( 8001 );
        }
        $this->iMix = $aMix;
    }

    public function SetAnchor( $aXAnchor = "left", $aYAnchor = "center" )
    {
        if ( !in_array( $aXAnchor, $this->iAnchors ) || !in_array( $aYAnchor, $this->iAnchors ) )
        {
            ( 8002 );
        }
        $this->iHorAnchor = $aXAnchor;
        $this->iVertAnchor = $aYAnchor;
    }

    public function PreStrokeAdjust( $aGraph )
    {
    }

    public function DoLegend( $aGraph )
    {
    }

    public function Max( )
    {
        return array( FALSE, FALSE );
    }

    public function GetMaxDate( )
    {
        return FALSE;
    }

    public function GetMinDate( )
    {
        return FALSE;
    }

    public function GetLineNbr( )
    {
        return 0;
    }

    public function GetAbsHeight( )
    {
        return 0;
    }

    public function Min( )
    {
        return array( FALSE, FALSE );
    }

    public function StrokeMargin( &$aImg )
    {
        return TRUE;
    }

    public function Stroke( $aImg, $axscale, $ayscale )
    {
        $this->StrokeWithScale( $aImg, $axscale, $ayscale );
    }

    public function StrokeWithScale( $aImg, $axscale, $ayscale )
    {
        if ( $this->iScalePosX === NULL || $this->iScalePosY === NULL )
        {
            $this->_Stroke( $aImg );
        }
        else
        {
            $this->_Stroke( $aImg, round( $this->iScalePosX( $this->iScalePosX ) ), round( $this->iScalePosY( $this->iScalePosY ) ) );
        }
    }

    public function GetWidthHeight( )
    {
        $dummy = 0;
        return $this->_Stroke( $dummy, NULL, NULL, TRUE );
    }

    public function _Stroke( $aImg, $x = NULL, $y = NULL, $aReturnWidthHeight = FALSE )
    {
        if ( $this->iFile != "" && $this->iCountryFlag != "" )
        {
            ( 8003 );
        }
        if ( $this->iFile != "" )
        {
            $gdimg = ( "", $this->iFile );
        }
        else
        {
            if ( $this->iImgString != "" )
            {
                $gdimg = ( $this->iImgString );
            }
            else
            {
                if ( class_exists( "FlagImages", FALSE ) )
                {
                    ( 8004 );
                }
                $fobj = new FlagImages( $this->iCountryStdSize );
                $dummy = "";
                $gdimg = $this->iCountryFlag( $this->iCountryFlag, $dummy );
            }
        }
        $iconw = imagesx( $gdimg );
        $iconh = imagesy( $gdimg );
        if ( $aReturnWidthHeight )
        {
            return array( round( $iconw * $this->iScale ), round( $iconh * $this->iScale ) );
        }
        if ( $x !== NULL && $y !== NULL )
        {
            $this->iX = $x;
            $this->iY = $y;
        }
        if ( 0 <= $this->iX && $this->iX <= 1 )
        {
            $w = imagesx( $aImg->img );
            $this->iX = round( $w * $this->iX );
        }
        if ( 0 <= $this->iY && $this->iY <= 1 )
        {
            $h = imagesy( $aImg->img );
            $this->iY = round( $h * $this->iY );
        }
        if ( $this->iHorAnchor == "center" )
        {
            $ && _514987928 -= "iX";
        }
        if ( $this->iHorAnchor == "right" )
        {
            $ && _514778904 -= "iX";
        }
        if ( $this->iVertAnchor == "center" )
        {
            $ && _712031208 -= "iY";
        }
        if ( $this->iVertAnchor == "bottom" )
        {
            $ && _728034608 -= "iY";
        }
        $this->iMix( $gdimg, $this->iX, $this->iY, 0, 0, round( $iconw * $this->iScale ), round( $iconh * $this->iScale ), $iconw, $iconh, $this->iMix );
    }

}

?>
