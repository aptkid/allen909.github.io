<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class Rectangle
{

    public $x;
    public $y;
    public $w;
    public $h;
    public $xe;
    public $ye;

    public function Rectangle( $aX, $aY, $aWidth, $aHeight )
    {
        $this->x = $aX;
        $this->y = $aY;
        $this->w = $aWidth;
        $this->h = $aHeight;
        $this->xe = $aX + $aWidth - 1;
        $this->ye = $aY + $aHeight - 1;
    }

}

class RectPattern
{

    protected $color;
    protected $weight;
    protected $rect;
    protected $doframe = TRUE;
    protected $linespacing;
    protected $iBackgroundColor = -1;

    public function RectPattern( $aColor, $aWeight = 1 )
    {
        $this->color = $aColor;
        $this->weight = $aWeight;
    }

    public function SetBackground( $aBackgroundColor )
    {
        $this->iBackgroundColor = $aBackgroundColor;
    }

    public function SetPos( $aRect )
    {
        $this->rect = $aRect;
    }

    public function ShowFrame( $aShow = TRUE )
    {
        $this->doframe = $aShow;
    }

    public function SetDensity( $aDens )
    {
        if ( $aDens < 1 || 100 < $aDens )
        {
            ( 16001, $aDens );
        }
        $this->linespacing = floor( ( 100 - $aDens ) / 100 * 50 ) + 1;
    }

    public function Stroke( $aImg )
    {
        if ( $this->rect == NULL )
        {
            ( 16002 );
        }
        if ( !is_numeric( $this->iBackgroundColor ) || !( $this->iBackgroundColor == -1 ) )
        {
            $this->iBackgroundColor( $this->iBackgroundColor );
            $this->rect->ye( $this->rect->x, $this->rect->y, $this->rect->xe, $this->rect->ye );
        }
        $this->color( $this->color );
        $this->weight( $this->weight );
        $this->DoPattern( $aImg );
        if ( $this->doframe )
        {
            $this->rect->ye( $this->rect->x, $this->rect->y, $this->rect->xe, $this->rect->ye );
        }
    }

}

class RectPatternSolid extends RectPattern
{

    public function RectPatternSolid( $aColor = "black", $aWeight = 1 )
    {
        ( $aColor, $aWeight );
    }

    public function DoPattern( $aImg )
    {
        $this->color( $this->color );
        $this->rect->ye( $this->rect->x, $this->rect->y, $this->rect->xe, $this->rect->ye );
    }

}

class RectPatternHor extends RectPattern
{

    public function RectPatternHor( $aColor = "black", $aWeight = 1, $aLineSpacing = 7 )
    {
        ( $aColor, $aWeight );
        $this->linespacing = $aLineSpacing;
    }

    public function DoPattern( $aImg )
    {
        $x0 = $this->rect->x;
        $x1 = $this->rect->xe;
        $y = $this->rect->y;
        while ( $y < $this->rect->ye )
        {
            $aImg->Line( $x0, $y, $x1, $y );
            $y += $this->linespacing;
        }
    }

}

class RectPatternVert extends RectPattern
{

    public function RectPatternVert( $aColor = "black", $aWeight = 1, $aLineSpacing = 7 )
    {
        ( $aColor, $aWeight );
        $this->linespacing = $aLineSpacing;
    }

    public function DoPattern( $aImg )
    {
        $x = $this->rect->x;
        $y0 = $this->rect->y;
        $y1 = $this->rect->ye;
        while ( $x < $this->rect->xe )
        {
            $aImg->Line( $x, $y0, $x, $y1 );
            $x += $this->linespacing;
        }
    }

}

class RectPatternRDiag extends RectPattern
{

    public function RectPatternRDiag( $aColor = "black", $aWeight = 1, $aLineSpacing = 12 )
    {
        ( $aColor, $aWeight );
        $this->linespacing = $aLineSpacing;
    }

    public function DoPattern( $aImg )
    {
        $xe = $this->rect->xe;
        $ye = $this->rect->ye;
        $x0 = $this->rect->x + round( $this->linespacing / 2 );
        $y0 = $this->rect->y;
        $x1 = $this->rect->x;
        $y1 = $this->rect->y + round( $this->linespacing / 2 );
        while ( !( $x0 <= $xe ) || !( $y1 <= $ye ) )
        {
            $aImg->Line( $x0, $y0, $x1, $y1 );
            $x0 += $this->linespacing;
            $y1 += $this->linespacing;
        }
        if ( $ye - $y0 < $xe - $x1 )
        {
            $x1 = $this->rect->x + ( $y1 - $ye );
            $y1 = $ye;
            $y0 = $this->rect->y;
            while ( $x0 <= $xe )
            {
                $aImg->Line( $x0, $y0, $x1, $y1 );
                $x0 += $this->linespacing;
                $x1 += $this->linespacing;
            }
            $y0 = $this->rect->y + ( $x0 - $xe );
            $x0 = $xe;
        }
        else
        {
            $diff = $x0 - $xe;
            $y0 = $diff + $this->rect->y;
            $x0 = $xe;
            $x1 = $this->rect->x;
            while ( $y1 <= $ye )
            {
                $aImg->Line( $x0, $y0, $x1, $y1 );
                $y1 += $this->linespacing;
                $y0 += $this->linespacing;
            }
            $diff = $y1 - $ye;
            $y1 = $ye;
            $x1 = $diff + $this->rect->x;
        }
        while ( $y0 <= $ye )
        {
            $aImg->Line( $x0, $y0, $x1, $y1 );
            $y0 += $this->linespacing;
            $x1 += $this->linespacing;
        }
    }

}

class RectPatternLDiag extends RectPattern
{

    public function RectPatternLDiag( $aColor = "black", $aWeight = 1, $aLineSpacing = 12 )
    {
        $this->linespacing = $aLineSpacing;
        ( $aColor, $aWeight );
    }

    public function DoPattern( $aImg )
    {
        $xe = $this->rect->xe;
        $ye = $this->rect->ye;
        $x0 = $this->rect->x + round( $this->linespacing / 2 );
        $y0 = $this->rect->ye;
        $x1 = $this->rect->x;
        $y1 = $this->rect->ye - round( $this->linespacing / 2 );
        while ( !( $x0 <= $xe ) || !( $this->rect->y <= $y1 ) )
        {
            $aImg->Line( $x0, $y0, $x1, $y1 );
            $x0 += $this->linespacing;
            $y1 -= $this->linespacing;
        }
        if ( $ye - $this->rect->y < $xe - $x1 )
        {
            $x1 = $this->rect->x + ( $this->rect->y - $y1 );
            $y0 = $ye;
            $y1 = $this->rect->y;
            while ( $x0 <= $xe )
            {
                $aImg->Line( $x0, $y0, $x1, $y1 );
                $x0 += $this->linespacing;
                $x1 += $this->linespacing;
            }
            $y0 = $this->rect->ye - ( $x0 - $xe );
            $x0 = $xe;
        }
        else
        {
            $diff = $x0 - $xe;
            $y0 = $ye - $diff;
            $x0 = $xe;
            while ( $this->rect->y <= $y1 )
            {
                $aImg->Line( $x0, $y0, $x1, $y1 );
                $y0 -= $this->linespacing;
                $y1 -= $this->linespacing;
            }
            $diff = $this->rect->y - $y1;
            $x1 = $this->rect->x + $diff;
            $y1 = $this->rect->y;
        }
        while ( $this->rect->y <= $y0 )
        {
            $aImg->Line( $x0, $y0, $x1, $y1 );
            $y0 -= $this->linespacing;
            $x1 += $this->linespacing;
        }
    }

}

class RectPattern3DPlane extends RectPattern
{

    private $alpha = 50;

    public function RectPattern3DPlane( $aColor = "black", $aWeight = 1 )
    {
        ( $aColor, $aWeight );
        $this->SetDensity( 10 );
    }

    public function SetHorizon( $aHorizon )
    {
        $this->alpha = $aHorizon;
    }

    public function DoPattern( $aImg )
    {
        $x0 = $this->rect->x + $this->rect->w / 2;
        $y0 = $this->rect->y;
        $x1 = $x0;
        $y1 = $this->rect->ye;
        $x0_right = $x0;
        $x1_right = $x1;
        $apa = $this->rect->h + $this->alpha;
        $middle = $this->rect->x + $this->rect->w / 2;
        $dist = $this->linespacing;
        $factor = $this->alpha / $apa;
        while ( $this->rect->x < $x1 )
        {
            $aImg->Line( $x0, $y0, $x1, $y1 );
            $aImg->Line( $x0_right, $y0, $x1_right, $y1 );
            $x1 = $middle - $dist;
            $x0 = $middle - $dist * $factor;
            $x1_right = $middle + $dist;
            $x0_right = $middle + $dist * $factor;
            $dist += $this->linespacing;
        }
        $dist -= $this->linespacing;
        $d = $this->rect->w / 2;
        $c = $apa - $d * $apa / $dist;
        while ( $this->rect->x < $x0 )
        {
            $this->rect( $x0, $y0, $this->rect->x, $this->rect->ye - $c );
            $this->rect( $x0_right, $y0, $this->rect->xe, $this->rect->ye - $c );
            $dist += $this->linespacing;
            $x0 = $middle - $dist * $factor;
            $x1 = $middle - $dist;
            $x0_right = $middle + $dist * $factor;
            $c = $apa - $d * $apa / $dist;
        }
        $x0 = $this->rect->x;
        $x1 = $this->rect->xe;
        $y = $this->rect->ye;
        $aImg->Line( $x0, $y, $x1, $y );
        $hls = $this->linespacing;
        $vls = $this->linespacing * 0.6;
        $ds = $hls * ( $apa - $vls ) / $apa;
        $y -= $vls;
        $k = ( $this->rect->ye - ( $this->rect->ye - $vls ) ) / ( $middle - ( $middle - $ds ) );
        $dist = $hls;
        while ( $this->rect->y < $y )
        {
            $this->rect->xe( $this->rect->x, $y, $this->rect->xe, $y );
            $adj = $k * $dist / ( 1 + $dist * $k / $apa );
            if ( $adj < 2 )
            {
                $adj = 1;
            }
            $y = $this->rect->ye - round( $adj );
            $dist += $hls;
        }
    }

}

class RectPatternCross extends RectPattern
{

    private $vert;
    private $hor;

    public function RectPatternCross( $aColor = "black", $aWeight = 1 )
    {
        ( $aColor, $aWeight );
        $this->vert = new RectPatternVert( $aColor, $aWeight );
        $this->hor = new RectPatternHor( $aColor, $aWeight );
    }

    public function SetOrder( $aDepth )
    {
        $this->vert->SetOrder( $aDepth );
        $this->hor->SetOrder( $aDepth );
    }

    public function SetPos( $aRect )
    {
        ( $aRect );
        $this->vert->SetPos( $aRect );
        $this->hor->SetPos( $aRect );
    }

    public function SetDensity( $aDens )
    {
        $this->vert->SetDensity( $aDens );
        $this->hor->SetDensity( $aDens );
    }

    public function DoPattern( $aImg )
    {
        $this->vert->DoPattern( $aImg );
        $this->hor->DoPattern( $aImg );
    }

}

class RectPatternDiagCross extends RectPattern
{

    private $left;
    private $right;

    public function RectPatternDiagCross( $aColor = "black", $aWeight = 1 )
    {
        ( $aColor, $aWeight );
        $this->right = new RectPatternRDiag( $aColor, $aWeight );
        $this->left = new RectPatternLDiag( $aColor, $aWeight );
    }

    public function SetOrder( $aDepth )
    {
        $this->left->SetOrder( $aDepth );
        $this->right->SetOrder( $aDepth );
    }

    public function SetPos( $aRect )
    {
        ( $aRect );
        $this->left->SetPos( $aRect );
        $this->right->SetPos( $aRect );
    }

    public function SetDensity( $aDens )
    {
        $this->left->SetDensity( $aDens );
        $this->right->SetDensity( $aDens );
    }

    public function DoPattern( $aImg )
    {
        $this->left->DoPattern( $aImg );
        $this->right->DoPattern( $aImg );
    }

}

class RectPatternFactory
{

    public function RectPatternFactory( )
    {
    }

    public function Create( $aPattern, $aColor, $aWeight = 1 )
    {
        switch ( $aPattern )
        {
            case BAND_RDIAG :
                $obj = new RectPatternRDiag( $aColor, $aWeight );
                return $obj;
            case BAND_LDIAG :
                $obj = new RectPatternLDiag( $aColor, $aWeight );
                return $obj;
            case BAND_SOLID :
                $obj = new RectPatternSolid( $aColor, $aWeight );
                return $obj;
            case BAND_VLINE :
                $obj = new RectPatternVert( $aColor, $aWeight );
                return $obj;
            case BAND_HLINE :
                $obj = new RectPatternHor( $aColor, $aWeight );
                return $obj;
            case BAND_3DPLANE :
                $obj = new RectPattern3DPlane( $aColor, $aWeight );
                return $obj;
            case BAND_HVCROSS :
                $obj = new RectPatternCross( $aColor, $aWeight );
                return $obj;
            case BAND_DIAGCROSS :
                $obj = new RectPatternDiagCross( $aColor, $aWeight );
                return $obj;
        }
        ( 16003, $aPattern );
        return $obj;
    }

}

class PlotBand
{

    public $depth;
    private $prect;
    private $dir;
    private $min;
    private $max;

    public function PlotBand( $aDir, $aPattern, $aMin, $aMax, $aColor = "black", $aWeight = 1, $aDepth = DEPTH_BACK )
    {
        $f = new RectPatternFactory( );
        $this->prect = $f->Create( $aPattern, $aColor, $aWeight );
        if ( is_numeric( $aMin ) && is_numeric( $aMax ) && $aMax < $aMin )
        {
            ( 16004 );
        }
        $this->dir = $aDir;
        $this->min = $aMin;
        $this->max = $aMax;
        $this->depth = $aDepth;
    }

    public function SetPos( $aRect )
    {
        assert( $this->prect != NULL );
        $this->prect->SetPos( $aRect );
    }

    public function ShowFrame( $aFlag = TRUE )
    {
        $this->prect->ShowFrame( $aFlag );
    }

    public function SetOrder( $aDepth )
    {
        $this->depth = $aDepth;
    }

    public function SetDensity( $aDens )
    {
        $this->prect->SetDensity( $aDens );
    }

    public function GetDir( )
    {
        return $this->dir;
    }

    public function GetMin( )
    {
        return $this->min;
    }

    public function GetMax( )
    {
        return $this->max;
    }

    public function PreStrokeAdjust( $aGraph )
    {
    }

    public function Stroke( $aImg, $aXScale, $aYScale )
    {
        assert( $this->prect != NULL );
        if ( $this->dir == HORIZONTAL )
        {
            if ( $this->min === "min" )
            {
                $this->min = $aYScale->GetMinVal( );
            }
            if ( $this->max === "max" )
            {
                $this->max = $aYScale->GetMaxVal( );
            }
            if ( $this->min < $aYScale->GetMaxVal( ) && $aYScale->GetMinVal( ) < $this->max )
            {
                $this->min = max( $this->min, $aYScale->GetMinVal( ) );
                $this->max = min( $this->max, $aYScale->GetMaxVal( ) );
                $x = $aXScale->scale_abs[0];
                $y = $this->max( $this->max );
                $width = $aXScale->scale_abs[1] - $aXScale->scale_abs[0] + 1;
                $height = abs( $y - $this->min( $this->min ) ) + 1;
                $this->prect->SetPos( new Rectangle( $x, $y, $width, $height ) );
                $this->prect->Stroke( $aImg );
            }
        }
        else
        {
            if ( $this->min === "min" )
            {
                $this->min = $aXScale->GetMinVal( );
            }
            if ( $this->max === "max" )
            {
                $this->max = $aXScale->GetMaxVal( );
            }
            if ( $this->min < $aXScale->GetMaxVal( ) && $aXScale->GetMinVal( ) < $this->max )
            {
                $this->min = max( $this->min, $aXScale->GetMinVal( ) );
                $this->max = min( $this->max, $aXScale->GetMaxVal( ) );
                $y = $aYScale->scale_abs[1];
                $x = $this->min( $this->min );
                $height = abs( $aYScale->scale_abs[1] - $aYScale->scale_abs[0] );
                $width = abs( $x - $this->max( $this->max ) );
                $this->prect->SetPos( new Rectangle( $x, $y, $width, $height ) );
                $this->prect->Stroke( $aImg );
            }
        }
    }

}

define( "BAND_RDIAG", 1 );
define( "BAND_LDIAG", 2 );
define( "BAND_SOLID", 3 );
define( "BAND_VLINE", 4 );
define( "BAND_HLINE", 5 );
define( "BAND_3DPLANE", 6 );
define( "BAND_HVCROSS", 7 );
define( "BAND_DIAGCROSS", 8 );
?>
