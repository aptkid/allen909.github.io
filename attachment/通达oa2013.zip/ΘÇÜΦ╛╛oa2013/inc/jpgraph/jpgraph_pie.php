<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class PiePlot
{

    public $posx = 0.5;
    public $posy = 0.5;
    protected $radius = 0.3;
    protected $explode_radius = array( );
    protected $explode_all = FALSE;
    protected $explode_r = 20;
    protected $labels;
    protected $legends;
    protected $csimtargets;
    protected $csimareas = "";
    protected $csimalts;
    protected $data;
    public $title;
    protected $startangle = 0;
    protected $weight = 1;
    protected $color = "black";
    protected $legend_margin = 6;
    protected $show_labels = TRUE;
    protected $themearr = array( 'td' => array( 136, 22, 40, 45, 49, 74, 119, 149, 430, 105, 333, 4, 141, 168, 180, 209, 218, 395, 89 ), 'earth' => array( 136, 34, 40, 45, 46, 62, 63, 134, 74, 10, 120, 136, 141, 168, 180, 77, 209, 218, 346, 395, 89, 430 ), 'pastel' => array( 27, 415, 128, 59, 66, 79, 105, 110, 42, 147, 152, 230, 236, 240, 331, 337, 405, 38 ), 'water' => array( 8, 370, 24, 40, 335, 56, 213, 237, 268, 14, 326, 387, 10, 388 ), 'sand' => array( 27, 168, 34, 170, 19, 50, 65, 72, 131, 209, 46, 393 ) );
    protected $theme = "earth";
    protected $setslicecolors = array( );
    protected $labeltype = 0;
    protected $pie_border = TRUE;
    protected $pie_interior_border = TRUE;
    public $value;
    protected $ishadowcolor = "";
    protected $ishadowdrop = 4;
    protected $ilabelposadj = 1;
    protected $legendcsimtargets = array( );
    protected $legendcsimalts = array( );
    protected $adjusted_data = array( );
    public $guideline;
    protected $guidelinemargin = 10;
    protected $iShowGuideLineForSingle = FALSE;
    protected $iGuideLineCurve = FALSE;
    protected $iGuideVFactor = 1.4;
    protected $iGuideLineRFactor = 0.8;

    public function PiePlot( $data )
    {
        $this->data = array_reverse( $data );
        $this->title = new Text( "" );
        $this->title->SetFont( FF_FONT1, FS_BOLD );
        $this->value = new DisplayValue( );
        $this->value->Show( );
        $this->value->SetFormat( "%.1f%%" );
        $this->guideline = new LineProperty( );
    }

    public function SetCenter( $x, $y = 0.5 )
    {
        $this->posx = $x;
        $this->posy = $y;
    }

    public function SetGuideLines( $aFlg = TRUE, $aCurved = TRUE, $aAlways = FALSE )
    {
        $this->guideline->Show( $aFlg );
        $this->iShowGuideLineForSingle = $aAlways;
        $this->iGuideLineCurve = $aCurved;
    }

    public function SetGuideLinesAdjust( $aVFactor, $aRFactor = 0.8 )
    {
        $this->iGuideVFactor = $aVFactor;
        $this->iGuideLineRFactor = $aRFactor;
    }

    public function SetColor( $aColor )
    {
        $this->color = $aColor;
    }

    public function SetSliceColors( $aColors )
    {
        $this->setslicecolors = $aColors;
    }

    public function SetShadow( $aColor = "darkgray", $aDropWidth = 4 )
    {
        $this->ishadowcolor = $aColor;
        $this->ishadowdrop = $aDropWidth;
    }

    public function SetCSIMTargets( $targets, $alts = NULL )
    {
        $this->csimtargets = array_reverse( $targets );
        if ( is_array( $alts ) )
        {
            $this->csimalts = array_reverse( $alts );
        }
    }

    public function GetCSIMareas( )
    {
        return $this->csimareas;
    }

    public function AddSliceToCSIM( $i, $xc, $yc, $radius, $sa, $ea )
    {
        while ( 2 * M_PI < $sa )
        {
            $sa -= 2 * M_PI;
        }
        while ( 2 * M_PI < $ea )
        {
            $ea -= 2 * M_PI;
        }
        $sa = 2 * M_PI - $sa;
        $ea = 2 * M_PI - $ea;
        if ( abs( $sa - $ea ) < 0.0001 )
        {
            $sa = 2 * M_PI;
            $ea = 0;
        }
        $xc = floor( $xc );
        $yc = floor( $yc );
        $coords = "{$xc}, {$yc}";
        $xp = floor( $radius * cos( $ea ) + $xc );
        $yp = floor( $yc - $radius * sin( $ea ) );
        $coords .= ", ".$xp.", {$yp}";
        $a = $ea + 0.2;
        if ( $sa < $ea )
        {
            while ( $a <= 2 * M_PI )
            {
                $xp = floor( $radius * cos( $a ) + $xc );
                $yp = floor( $yc - $radius * sin( $a ) );
                $coords .= ", ".$xp.", {$yp}";
                $a += 0.2;
            }
            $a -= 2 * M_PI;
        }
        while ( $a < $sa )
        {
            $xp = floor( $radius * cos( $a ) + $xc );
            $yp = floor( $yc - $radius * sin( $a ) );
            $coords .= ", ".$xp.", {$yp}";
            $a += 0.2;
        }
        $xp = floor( $radius * cos( $sa ) + $xc );
        $yp = floor( $yc - $radius * sin( $sa ) );
        $coords .= ", ".$xp.", {$yp}";
        if ( empty( $this->csimtargets[$i] ) )
        {
            $ && _727925656 .= "csimareas";
            $tmp = "";
            if ( empty( $this->csimalts[$i] ) )
            {
                $tmp = sprintf( $this->csimalts[$i], $this->data[$i] );
                $ && _716008408 .= "csimareas";
            }
            $ && _699997592 .= "csimareas";
        }
    }

    public function SetTheme( $aTheme )
    {
        if ( in_array( $aTheme, array_keys( $this->themearr ) ) )
        {
            $this->theme = $aTheme;
        }
        else
        {
            ( 15001, $aTheme );
        }
    }

    public function ExplodeSlice( $e, $radius = 20 )
    {
        if ( is_integer( $e ) )
        {
            ( 15002 );
        }
        $this->explode_radius[$e] = $radius;
    }

    public function ExplodeAll( $radius = 20 )
    {
        $this->explode_all = TRUE;
        $this->explode_r = $radius;
    }

    public function Explode( $aExplodeArr )
    {
        if ( is_array( $aExplodeArr ) )
        {
            ( 15003 );
        }
        $this->explode_radius = $aExplodeArr;
    }

    public function SetStartAngle( $aStart )
    {
        if ( $aStart < 0 || 360 < $aStart )
        {
            ( 15004 );
        }
        $this->startangle = 360 - $aStart;
        $ && _514778744 *= "startangle";
    }

    public function SetFont( $family, $style = FS_NORMAL, $size = 10 )
    {
        ( 15005 );
    }

    public function SetSize( $aSize )
    {
        if ( !( 0 < $aSize ) || $aSize <= 0.5 || 10 < $aSize && $aSize < 1000 )
        {
            $this->radius = $aSize;
        }
        else
        {
            ( 15006 );
        }
    }

    public function SetFontColor( $aColor )
    {
        ( 15007 );
    }

    public function SetLegends( $aLegend )
    {
        $this->legends = $aLegend;
    }

    public function SetLabels( $aLabels, $aLblPosAdj = "auto" )
    {
        $this->labels = array_reverse( $aLabels );
        $this->ilabelposadj = $aLblPosAdj;
    }

    public function SetLabelPos( $aLblPosAdj )
    {
        $this->ilabelposadj = $aLblPosAdj;
    }

    public function SetLabelType( $t )
    {
        if ( $t < 0 || 2 < $t )
        {
            ( 15008, $t );
        }
        $this->labeltype = $t;
    }

    public function SetValueType( $aType )
    {
        $this->SetLabelType( $aType );
    }

    public function ShowBorder( $exterior = TRUE, $interior = TRUE )
    {
        $this->pie_border = $exterior;
        $this->pie_interior_border = $interior;
    }

    public function Legend( $graph )
    {
        $colors = array_keys( $graph->img->rgb->rgb_table );
        sort( &$colors );
        $ta = $this->themearr[$this->theme];
        $n = count( $this->data );
        if ( $this->setslicecolors == NULL )
        {
            $numcolors = count( $ta );
            if ( class_exists( "PiePlot3D", FALSE ) && $this instanceof PiePlot3D )
            {
                $ta = array_reverse( array_slice( $ta, 0, $n ) );
            }
        }
        else
        {
            $this->setslicecolors = array_slice( $this->setslicecolors, 0, $n );
            $numcolors = count( $this->setslicecolors );
            if ( $graph->pieaa && $this instanceof PiePlot )
            {
                $this->setslicecolors = array_reverse( $this->setslicecolors );
            }
        }
        $sum = 0;
        $i = 0;
        for ( ; $i < $n; ++$i )
        {
            $sum += $this->data[$i];
        }
        if ( $sum == 0 )
        {
            ( 15009 );
        }
        $n = min( count( $this->legends ), count( $this->data ) );
        if ( $this->legends != "" )
        {
            $this->legends = array_reverse( array_slice( $this->legends, 0, $n ) );
        }
        $i = $n - 1;
        for ( ; 0 <= $i; --$i )
        {
            $l = $this->legends[$i];
            if ( $i < count( $this->csimalts ) )
            {
                $fmt = $this->csimalts[$i];
            }
            else
            {
                $fmt = "%d";
            }
            if ( $this->labeltype == 0 )
            {
                $l = sprintf( $l, 100 * $this->data[$i] / $sum );
                $alt = sprintf( $fmt, $this->data[$i] );
            }
            else if ( $this->labeltype == 1 )
            {
                $l = sprintf( $l, $this->data[$i] );
                $alt = sprintf( $fmt, $this->data[$i] );
            }
            else
            {
                $l = sprintf( $l, $this->adjusted_data[$i] );
                $alt = sprintf( $fmt, $this->adjusted_data[$i] );
            }
            if ( $this->setslicecolors == NULL )
            {
                $this->csimtargets( $l." ", $colors[$ta[$i % $numcolors]], "", 0, $this->csimtargets[$i], $alt );
            }
            else
            {
                $this->csimtargets( $l, $this->setslicecolors[$i % $numcolors], "", 0, $this->csimtargets[$i], $alt );
            }
        }
    }

    public function AdjPercentage( $aData, $aPrec = 0 )
    {
        $mul = 100;
        if ( 0 < $aPrec && $aPrec < 3 )
        {
            if ( $aPrec == 1 )
            {
                $mul = 1000;
            }
            else
            {
                $mul = 10000;
            }
        }
        $tmp = array( );
        $result = array( );
        $quote_sum = 0;
        $n = count( $aData );
        $i = 0;
        $sum = 0;
        for ( ; $i < $n; ++$i )
        {
            $sum += $aData[$i];
        }
        foreach ( $aData as $index => $value )
        {
            $tmp_percentage = $value / $sum * $mul;
            $result[$index] = floor( $tmp_percentage );
            $tmp[$index] = $tmp_percentage - $result[$index];
            $quote_sum += $result[$index];
        }
        if ( $quote_sum == $mul )
        {
            if ( 100 < $mul )
            {
                $tmp = $mul / 100;
                $i = 0;
                for ( ; $i < $n; ++$i )
                {
                    $result /= $i;
                }
            }
            return $result;
        }
        arsort( &$tmp, SORT_NUMERIC );
        reset( &$tmp );
        $i = 0;
        for ( ; $i < $mul - $quote_sum; ++$i )
        {
            ++$result[key( &$tmp )];
            next( &$tmp );
        }
        if ( 100 < $mul )
        {
            $tmp = $mul / 100;
            $i = 0;
            for ( ; $i < $n; ++$i )
            {
                $result /= $i;
            }
        }
        return $result;
    }

    public function Stroke( $img, $aaoption = 0 )
    {
        $expscale = $aaoption === 1 ? 2 : 1;
        if ( $this->labeltype == 2 )
        {
            $this->adjusted_data = $this->data( $this->data );
        }
        $colors = array_keys( $img->rgb->rgb_table );
        sort( &$colors );
        $ta = $this->themearr[$this->theme];
        $n = count( $this->data );
        if ( $this->setslicecolors == NULL )
        {
            $numcolors = count( $ta );
        }
        else
        {
            $numcolors = count( $this->setslicecolors );
            if ( $numcolors < $n )
            {
                $i = 2 * $numcolors;
                while ( $i < $n )
                {
                    $this->setslicecolors = array_merge( $this->setslicecolors, $this->setslicecolors );
                    $i += $n;
                }
                $tt = array_slice( $this->setslicecolors, 0, $n % $numcolors );
                $this->setslicecolors = array_merge( $this->setslicecolors, $tt );
                $this->setslicecolors = array_reverse( $this->setslicecolors );
            }
        }
        $sum = 0;
        $i = 0;
        for ( ; $i < $n; ++$i )
        {
            $sum += $this->data[$i];
        }
        if ( $sum == 0 )
        {
            ( 15009 );
        }
        if ( $this->radius <= 1 )
        {
            $radius = floor( $this->radius * min( $img->width, $img->height ) );
        }
        else
        {
            $radius = $aaoption === 1 ? $this->radius * 2 : $this->radius;
        }
        if ( $this->posx <= 1 && 0 < $this->posx )
        {
            $xc = round( $this->posx * $img->width );
        }
        else
        {
            $xc = $this->posx;
        }
        if ( $this->posy <= 1 && 0 < $this->posy )
        {
            $yc = round( $this->posy * $img->height );
        }
        else
        {
            $yc = $this->posy;
        }
        $n = count( $this->data );
        if ( $this->explode_all )
        {
            $i = 0;
            for ( ; $i < $n; ++$i )
            {
                $this->explode_radius[$i] = $this->explode_r;
            }
        }
        if ( !( $this->ishadowcolor != "" ) || !( $aaoption !== 2 ) )
        {
            $accsum = 0;
            $angle2 = $this->startangle;
            $this->ishadowcolor( $this->ishadowcolor );
            $i = 0;
            for ( ; 0 < $sum && $i < $n; ++$i )
            {
                $j = $n - $i - 1;
                $d = $this->data[$i];
                $angle1 = $angle2;
                $accsum += $d;
                $angle2 = $this->startangle + 2 * M_PI * $accsum / $sum;
                if ( empty( $this->explode_radius[$j] ) )
                {
                    $this->explode_radius[$j] = 0;
                }
                $la = 2 * M_PI - ( abs( $angle2 - $angle1 ) / 2 + $angle1 );
                $xcm = $xc + $this->explode_radius[$j] * cos( $la ) * $expscale;
                $ycm = $yc - $this->explode_radius[$j] * sin( $la ) * $expscale;
                $xcm += $this->ishadowdrop * $expscale;
                $ycm += $this->ishadowdrop * $expscale;
                $this->ishadowcolor( $xcm, $ycm, $radius, $radius, $angle1 * 180 / M_PI, $angle2 * 180 / M_PI, $this->ishadowcolor );
            }
        }
        $accsum = 0;
        $angle2 = $this->startangle;
        $this->color( $this->color );
        $i = 0;
        for ( ; 0 < $sum && $i < $n; ++$i )
        {
            $j = $n - $i - 1;
            if ( empty( $this->explode_radius[$j] ) )
            {
                $this->explode_radius[$j] = 0;
            }
            $d = $this->data[$i];
            $angle1 = $angle2;
            $accsum += $d;
            $angle2 = $this->startangle + 2 * M_PI * $accsum / $sum;
            $this->la[$i] = 2 * M_PI - ( abs( $angle2 - $angle1 ) / 2 + $angle1 );
            if ( $d == 0 )
            {
                if ( $this->setslicecolors == NULL )
                {
                    $slicecolor = $colors[$ta[$i % $numcolors]];
                }
                else
                {
                    $slicecolor = $this->setslicecolors[$i % $numcolors];
                }
                if ( $this->pie_interior_border && $aaoption === 0 )
                {
                    $this->color( $this->color );
                }
                else
                {
                    $img->SetColor( $slicecolor );
                }
                $arccolor = $this->pie_border && $aaoption === 0 ? $this->color : "";
                $xcm = $xc + $this->explode_radius[$j] * cos( $this->la[$i] ) * $expscale;
                $ycm = $yc - $this->explode_radius[$j] * sin( $this->la[$i] ) * $expscale;
                if ( $aaoption !== 2 )
                {
                    $img->CakeSlice( $xcm, $ycm, $radius - 1, $radius - 1, $angle1 * 180 / M_PI, $angle2 * 180 / M_PI, $slicecolor, $arccolor );
                }
                if ( !$this->csimtargets || !( $aaoption !== 1 ) )
                {
                    $this->AddSliceToCSIM( $i, $xcm, $ycm, $radius, $angle1, $angle2 );
                }
            }
        }
        if ( $aaoption !== 2 )
        {
            $i = 0;
            for ( ; $i < $n; ++$i )
            {
                if ( $this->labeltype == 0 )
                {
                    if ( $sum != 0 )
                    {
                        $l = 100 * $this->data[$i] / $sum;
                    }
                    else
                    {
                        $l = 0;
                    }
                }
                else if ( $this->labeltype == 1 )
                {
                    $l = $this->data[$i] * 1;
                }
                else
                {
                    $l = $this->adjusted_data[$i];
                }
                if ( isset( $this->labels[$i] ) && is_string( $this->labels[$i] ) )
                {
                    $this->labels[$i] = sprintf( $this->labels[$i], $l );
                }
                else
                {
                    $this->labels[$i] = $l;
                }
            }
        }
        if ( $this->value->show && $aaoption !== 1 )
        {
            $this->StrokeAllLabels( $img, $xc, $yc, $radius );
        }
        if ( $aaoption !== 1 )
        {
            $this->title->margin( $xc, $yc - $this->title->GetFontHeight( $img ) - $radius - $this->title->margin, "center", "bottom" );
            $this->title->Stroke( $img );
        }
    }

    public function NormAngle( $a )
    {
        while ( $a < 0 )
        {
            $a += 2 * M_PI;
        }
        while ( 2 * M_PI < $a )
        {
            $a -= 2 * M_PI;
        }
        return $a;
    }

    public function Quadrant( $a )
    {
        $a = $this->NormAngle( $a );
        if ( 0 < $a && $a <= M_PI / 2 )
        {
            return 0;
        }
        if ( M_PI / 2 < $a && $a <= M_PI )
        {
            return 1;
        }
        if ( M_PI < $a && $a <= 1.5 * M_PI )
        {
            return 2;
        }
        if ( 1.5 * M_PI < $a )
        {
            return 3;
        }
    }

    public function StrokeGuideLabels( $img, $xc, $yc, $radius )
    {
        $n = count( $this->labels );
        $tresh_hold = 25 * M_PI / 180;
        $incluster = FALSE;
        $clusters = array( );
        $cidx = -1;
        $i = 0;
        for ( ; $i < $n - 1; ++$i )
        {
            $a1 = $this->la[$i];
            $a2 = $this->la[$i + 1];
            $q1 = $this->Quadrant( $a1 );
            $q2 = $this->Quadrant( $a2 );
            $diff = abs( $a1 - $a2 );
            if ( $diff < $tresh_hold )
            {
                if ( $incluster )
                {
                    ++$clusters[$cidx][1];
                    if ( $q1 != $q2 )
                    {
                        if ( $q1 == 1 && $q2 == 0 && 75 * M_PI / 180 < $a2 )
                        {
                            if ( $i < $n - 2 )
                            {
                                $a3 = $this->la[$i + 2];
                                if ( $tresh_hold <= abs( $a3 - $a2 ) )
                                {
                                    ++$clusters[$cidx][1];
                                    ++$i;
                                }
                            }
                        }
                        else if ( $q1 == 3 && $q2 == 2 && 255 * M_PI / 180 < $a2 && $i < $n - 2 )
                        {
                            $a3 = $this->la[$i + 2];
                            if ( $tresh_hold <= abs( $a3 - $a2 ) )
                            {
                                ++$clusters[$cidx][1];
                                ++$i;
                            }
                        }
                        if ( $q1 == 2 && $q2 == 1 && 165 * M_PI / 180 < $a2 )
                        {
                            ++$clusters[$cidx][1];
                            ++$i;
                        }
                        $incluster = FALSE;
                    }
                }
                else
                {
                    if ( $q1 == $q2 )
                    {
                        $incluster = TRUE;
                        if ( $q1 == 0 && -1 < $cidx && $clusters[$cidx][1] == 1 && $this->la[$clusters[$cidx][0]]( $this->la[$clusters[$cidx][0]] ) == 0 )
                        {
                            ++$clusters[$cidx][1];
                        }
                        else
                        {
                            ++$cidx;
                            $clusters[$cidx][0] = $i;
                            $clusters[$cidx][1] = 1;
                        }
                    }
                    else
                    {
                        ++$cidx;
                        $clusters[$cidx][0] = $i;
                        $clusters[$cidx][1] = 1;
                    }
                }
            }
            else if ( $incluster )
            {
                ++$clusters[$cidx][1];
                $incluster = FALSE;
            }
            else
            {
                ++$cidx;
                $clusters[$cidx][0] = $i;
                $clusters[$cidx][1] = 1;
            }
        }
        if ( $incluster )
        {
            ++$clusters[$cidx][1];
        }
        else
        {
            ++$cidx;
            $clusters[$cidx][0] = $i;
            $clusters[$cidx][1] = 1;
        }
        $this->value->ApplyFont( $img );
        $fh = $img->GetFontHeight( );
        $origvstep = $fh * $this->iGuideVFactor;
        $this->value->SetMargin( 0 );
        $nc = count( $clusters );
        $i = 0;
        for ( ; $i < $nc; ++$i )
        {
            $csize = $clusters[$i][1];
            $a = $this->la[$clusters[$i][0]];
            $q = $this->Quadrant( $a );
            if ( $q == 0 )
            {
                $start = $csize - 1;
                $idx = $start;
                $step = -1;
                $vstep = 0 - $origvstep;
            }
            else if ( $q == 1 )
            {
                $start = 0;
                $idx = $start;
                $step = 1;
                $vstep = 0 - $origvstep;
            }
            else if ( $q == 2 )
            {
                $start = $csize - 1;
                $idx = $start;
                $step = -1;
                $vstep = $origvstep;
            }
            else if ( $q == 3 )
            {
                $start = 0;
                $idx = $start;
                $step = 1;
                $vstep = $origvstep;
            }
            $j = 0;
            for ( ; $j < $csize; ++$j )
            {
                $a = $this->la[$clusters[$i][0] + $idx];
                $r = $radius + $this->explode_radius[$n - 1 - ( $clusters[$i][0] + $idx )];
                $x = round( $r * cos( $a ) + $xc );
                $y = round( $yc - $r * sin( $a ) );
                $r += $fh * $this->iGuideLineRFactor;
                if ( $this->iGuideLineCurve )
                {
                    $xt = round( $r * cos( $a ) + $xc );
                }
                if ( $idx == $start )
                {
                    if ( $this->iGuideLineCurve )
                    {
                        $xt = round( $r * cos( $a ) + $xc );
                    }
                    $yt = round( $yc - $r * sin( $a ) );
                    $prevcluster = ( $i + ( $nc - 1 ) ) % $nc;
                    $previdx = $clusters[$prevcluster][0] + $clusters[$prevcluster][1] - 1;
                    if ( $q == 1 && 160 * M_PI / 180 < $a )
                    {
                        $diff = abs( $a - $this->la[$previdx] );
                        if ( $diff < $tresh_hold )
                        {
                            $yt -= $fh;
                        }
                    }
                    else
                    {
                        if ( $q == 3 && 340 * M_PI / 180 < $a )
                        {
                            $diff = abs( $a - $this->la[$previdx] - 360 * M_PI / 180 );
                            if ( $diff < $tresh_hold )
                            {
                                $yt += $fh;
                            }
                        }
                    }
                }
                else
                {
                    $prev_a = $this->la[$clusters[$i][0] + ( $idx - $step )];
                    $dy = abs( $radius * ( sin( $a ) - sin( $prev_a ) ) * 1.2 );
                    if ( 0 < $vstep )
                    {
                        $yt += max( $vstep, $dy );
                    }
                    else
                    {
                        $yt += min( $vstep, 0 - $dy );
                    }
                }
                $label = $this->labels[$clusters[$i][0] + $idx];
                if ( $csize == 1 )
                {
                    $r = $radius + $this->explode_radius[$n - 1 - ( $clusters[$i][0] + $idx )];
                    $rr = $r + $img->GetFontHeight( ) / 2;
                    $xt = round( $rr * cos( $a ) + $xc );
                    $yt = round( $yc - $rr * sin( $a ) );
                    $this->StrokeLabel( $label, $img, $xc, $yc, $a, $r );
                    if ( $this->iShowGuideLineForSingle )
                    {
                        $this->guideline->Stroke( $img, $x, $y, $xt, $yt );
                    }
                }
                else
                {
                    $this->guideline->Stroke( $img, $x, $y, $xt, $yt );
                    if ( $q == 1 || $q == 2 )
                    {
                        $this->guidelinemargin( $img, $xt, $yt, $xt - $this->guidelinemargin, $yt );
                        $lbladj = 0 - $this->guidelinemargin - 5;
                        $this->value->halign = "right";
                        $this->value->valign = "center";
                    }
                    else
                    {
                        $this->guidelinemargin( $img, $xt, $yt, $xt + $this->guidelinemargin, $yt );
                        $lbladj = $this->guidelinemargin + 5;
                        $this->value->halign = "left";
                        $this->value->valign = "center";
                    }
                    $this->value->Stroke( $img, $label, $xt + $lbladj, $yt );
                }
                $idx += $step;
            }
        }
    }

    public function StrokeAllLabels( $img, $xc, $yc, $radius )
    {
        $n = count( $this->la );
        $i = 0;
        for ( ; $i < $n; ++$i )
        {
            $this->la[$i] = $this->la[$i]( $this->la[$i] );
        }
        if ( $this->guideline->iShow )
        {
            $this->StrokeGuideLabels( $img, $xc, $yc, $radius );
        }
        else
        {
            $n = count( $this->labels );
            $i = 0;
            for ( ; $i < $n; ++$i )
            {
                $this->explode_radius( $this->labels[$i], $img, $xc, $yc, $this->la[$i], $radius + $this->explode_radius[$n - 1 - $i] );
            }
        }
    }

    public function StrokeLabel( $label, $img, $xc, $yc, $a, $r )
    {
        if ( $this->ilabelposadj === "auto" )
        {
            $this->ilabelposadj = 0.65;
        }
        if ( $this->ilabelposadj < 1 )
        {
            $this->value->SetAlign( "center", "center" );
            $this->value->margin = 0;
            $xt = round( $this->ilabelposadj * $r * cos( $a ) + $xc );
            $yt = round( $yc - $this->ilabelposadj * $r * sin( $a ) );
            $this->value->Stroke( $img, $label, $xt, $yt );
        }
        else
        {
            $this->value->halign = "left";
            $this->value->valign = "top";
            $this->value->margin = 0;
            $this->value->ApplyFont( $img );
            $h = $img->GetTextHeight( $label );
            if ( is_numeric( $label ) )
            {
                if ( 0 < $label )
                {
                    $w = sprintf( $this->value->format, $label )( sprintf( $this->value->format, $label ) );
                }
                else
                {
                    $w = sprintf( $this->value->negformat, $label )( sprintf( $this->value->negformat, $label ) );
                }
            }
            else
            {
                $w = $img->GetTextWidth( $label );
            }
            if ( 1 < $this->ilabelposadj && $this->ilabelposadj < 5 )
            {
                $r *= $this->ilabelposadj;
            }
            $r += $img->GetFontHeight( ) / 1.5;
            $xt = round( $r * cos( $a ) + $xc );
            $yt = round( $yc - $r * sin( $a ) );
            while ( $a < 0 )
            {
                $a += 2 * M_PI;
            }
            while ( 2 * M_PI < $a )
            {
                $a -= 2 * M_PI;
            }
            if ( 7 * M_PI / 4 <= $a || $a <= M_PI / 4 )
            {
                $dx = 0;
            }
            if ( M_PI / 4 <= $a && $a <= 3 * M_PI / 4 )
            {
                $dx = ( $a - M_PI / 4 ) * 2 / M_PI;
            }
            if ( 3 * M_PI / 4 <= $a && $a <= 5 * M_PI / 4 )
            {
                $dx = 1;
            }
            if ( 5 * M_PI / 4 <= $a && $a <= 7 * M_PI / 4 )
            {
                $dx = 1 - ( $a - M_PI * 5 / 4 ) * 2 / M_PI;
            }
            if ( 7 * M_PI / 4 <= $a )
            {
                $dy = ( $a - M_PI - 3 * M_PI / 4 ) * 2 / M_PI;
            }
            if ( $a <= M_PI / 4 )
            {
                $dy = 1 - $a * 2 / M_PI;
            }
            if ( M_PI / 4 <= $a && $a <= 3 * M_PI / 4 )
            {
                $dy = 1;
            }
            if ( 3 * M_PI / 4 <= $a && $a <= 5 * M_PI / 4 )
            {
                $dy = 1 - ( $a - 3 * M_PI / 4 ) * 2 / M_PI;
            }
            if ( 5 * M_PI / 4 <= $a && $a <= 7 * M_PI / 4 )
            {
                $dy = 0;
            }
            $this->value->Stroke( $img, $label, $xt - $dx * $w, $yt - $dy * $h );
        }
    }

}

class PiePlotC extends PiePlot
{

    private $imidsize = 0.5;
    private $imidcolor = "white";
    public $midtitle = "";
    private $middlecsimtarget = "";
    private $middlecsimalt = "";

    public function PiePlotC( $data, $aCenterTitle = "" )
    {
        ( $data );
        $this->midtitle = new Text( );
        $this->midtitle->ParagraphAlign( "center" );
    }

    public function SetMid( $aTitle, $aColor = "white", $aSize = 0.5 )
    {
        $this->midtitle->Set( $aTitle );
        $this->imidsize = $aSize;
        $this->imidcolor = $aColor;
    }

    public function SetMidTitle( $aTitle )
    {
        $this->midtitle->Set( $aTitle );
    }

    public function SetMidSize( $aSize )
    {
        $this->imidsize = $aSize;
    }

    public function SetMidColor( $aColor )
    {
        $this->imidcolor = $aColor;
    }

    public function SetMidCSIM( $aTarget, $aAlt )
    {
        $this->middlecsimtarget = $aTarget;
        $this->middlecsimalt = $aAlt;
    }

    public function AddSliceToCSIM( $i, $xc, $yc, $radius, $sa, $ea )
    {
        while ( 2 * M_PI < $sa )
        {
            $sa -= 2 * M_PI;
        }
        while ( 2 * M_PI < $ea )
        {
            $ea -= 2 * M_PI;
        }
        $sa = 2 * M_PI - $sa;
        $ea = 2 * M_PI - $ea;
        if ( abs( $sa - $ea ) < 0.0001 )
        {
            $sa = 2 * M_PI;
            $ea = 0;
        }
        $xp = floor( $this->imidsize * $radius * cos( $ea ) + $xc );
        $yp = floor( $yc - $this->imidsize * $radius * sin( $ea ) );
        $coords = "{$xp}, {$yp}";
        $a = $ea + 0.25;
        if ( $sa < $ea )
        {
            while ( $a <= 2 * M_PI )
            {
                $xp = floor( $radius * cos( $a ) + $xc );
                $yp = floor( $yc - $radius * sin( $a ) );
                $coords .= ", ".$xp.", {$yp}";
                $a += 0.25;
            }
            $a -= 2 * M_PI;
        }
        while ( $a < $sa )
        {
            $xp = floor( $this->imidsize * $radius * cos( $a ) + $xc );
            $yp = floor( $yc - $this->imidsize * $radius * sin( $a ) );
            $coords .= ", ".$xp.", {$yp}";
            $a += 0.25;
        }
        $xp = floor( $this->imidsize * $radius * cos( $sa ) + $xc );
        $yp = floor( $yc - $this->imidsize * $radius * sin( $sa ) );
        $coords .= ", ".$xp.", {$yp}";
        $xp = floor( $radius * cos( $sa ) + $xc );
        $yp = floor( $yc - $radius * sin( $sa ) );
        $coords .= ", ".$xp.", {$yp}";
        $a = $sa - 0.25;
        while ( $ea < $a )
        {
            $xp = floor( $radius * cos( $a ) + $xc );
            $yp = floor( $yc - $radius * sin( $a ) );
            $coords .= ", ".$xp.", {$yp}";
            $a -= 0.25;
        }
        $xp = floor( $radius * cos( $ea ) + $xc );
        $yp = floor( $yc - $radius * sin( $ea ) );
        $coords .= ", ".$xp.", {$yp}";
        $xp = floor( $this->imidsize * $radius * cos( $ea ) + $xc );
        $yp = floor( $yc - $this->imidsize * $radius * sin( $ea ) );
        $coords .= ", ".$xp.", {$yp}";
        if ( empty( $this->csimtargets[$i] ) )
        {
            $ && _514757872 .= "csimareas";
            if ( empty( $this->csimalts[$i] ) )
            {
                $tmp = sprintf( $this->csimalts[$i], $this->data[$i] );
                $ && _514758224 .= "csimareas";
            }
            $ && _514758320 .= "csimareas";
        }
    }

    public function Stroke( $img, $aaoption = 0 )
    {
        $tmp = $this->value->show;
        $this->value->show = FALSE;
        ( $img, $aaoption );
        $this->value->show = $tmp;
        $xc = round( $this->posx * $img->width );
        $yc = round( $this->posy * $img->height );
        $radius = floor( $this->radius * min( $img->width, $img->height ) );
        if ( 0 < $this->imidsize && $aaoption !== 2 )
        {
            if ( $this->ishadowcolor != "" )
            {
                $this->ishadowcolor( $this->ishadowcolor );
                round( $radius * $this->imidsize )( $xc + $this->ishadowdrop, $yc + $this->ishadowdrop, round( $radius * $this->imidsize ) );
            }
            $this->imidcolor( $this->imidcolor );
            round( $radius * $this->imidsize )( $xc, $yc, round( $radius * $this->imidsize ) );
            if ( $this->pie_border && $aaoption === 0 )
            {
                $this->color( $this->color );
                round( $radius * $this->imidsize )( $xc, $yc, round( $radius * $this->imidsize ) );
            }
            if ( empty( $this->middlecsimtarget ) )
            {
                round( $radius * $this->imidsize )( $xc, $yc, round( $radius * $this->imidsize ) );
            }
        }
        if ( $this->value->show && $aaoption !== 1 )
        {
            $this->StrokeAllLabels( $img, $xc, $yc, $radius );
            $this->midtitle->SetPos( $xc, $yc, "center", "center" );
            $this->midtitle->Stroke( $img );
        }
    }

    public function AddMiddleCSIM( $xc, $yc, $r )
    {
        $xc = round( $xc );
        $yc = round( $yc );
        $r = round( $r );
        $ && _514757104 .= "csimareas";
        if ( empty( $this->middlecsimalt ) )
        {
            $tmp = $this->middlecsimalt;
            $ && _514759120 .= "csimareas";
        }
        $ && _514759216 .= "csimareas";
    }

    public function StrokeLabel( $label, $img, $xc, $yc, $a, $r )
    {
        if ( $this->ilabelposadj === "auto" )
        {
            $this->ilabelposadj = ( 1 - $this->imidsize ) / 2 + $this->imidsize;
        }
        ( $label, $img, $xc, $yc, $a, $r );
    }

}

define( "PIE_VALUE_ABS", 1 );
define( "PIE_VALUE_PER", 0 );
define( "PIE_VALUE_PERCENTAGE", 0 );
define( "PIE_VALUE_ADJPERCENTAGE", 2 );
define( "PIE_VALUE_ADJPER", 2 );
class PieGraph extends Graph
{

    private $posx;
    private $posy;
    private $radius;
    private $legends = array( );
    public $plots = array( );
    public $pieaa = FALSE;

    public function PieGraph( $width = 300, $height = 200, $cachedName = "", $timeout = 0, $inline = 1 )
    {
        $this->Graph( $width, $height, $cachedName, $timeout, $inline );
        $this->posx = $width / 2;
        $this->posy = $height / 2;
        $this->SetColor( array( 255, 255, 255 ) );
    }

    public function Add( $aObj )
    {
        if ( is_array( $aObj ) && 0 < count( $aObj ) )
        {
            $cl = $aObj[0];
        }
        else
        {
            $cl = $aObj;
        }
        if ( $cl instanceof Text )
        {
            $this->AddText( $aObj );
        }
        else
        {
            if ( class_exists( "IconPlot", FALSE ) && $cl instanceof IconPlot )
            {
                $this->AddIcon( $aObj );
            }
            else
            {
                if ( is_array( $aObj ) )
                {
                    $n = count( $aObj );
                    $i = 0;
                    for ( ; $i < $n; ++$i )
                    {
                        $this->plots[] = $aObj[$i];
                    }
                }
                else
                {
                    $this->plots[] = $aObj;
                }
            }
        }
    }

    public function SetAntiAliasing( $aFlg = TRUE )
    {
        $this->pieaa = $aFlg;
    }

    public function SetColor( $c )
    {
        $this->SetMarginColor( $c );
    }

    public function DisplayCSIMAreas( )
    {
        $csim = "";
        foreach ( $this->plots as $p )
        {
            $csim .= $p->GetCSIMareas( );
        }
        if ( preg_match_all( "/area shape=\"(\\w+)\" coords=\"([0-9\\, ]+)\"/", $csim, $coords ) )
        {
            $this->img->SetColor( $this->csimcolor );
            $n = count( $coords[0] );
            $i = 0;
            for ( ; $i < $n; ++$i )
            {
                if ( $coords[1][$i] == "poly" )
                {
                    preg_match_all( "/\\s*([0-9]+)\\s*,\\s*([0-9]+)\\s*,*/", $coords[2][$i], $pts );
                    $pts[2]( $pts[1][count( $pts[0] ) - 1], $pts[2][count( $pts[0] ) - 1] );
                    $m = count( $pts[0] );
                    $j = 0;
                    for ( ; $j < $m; ++$j )
                    {
                        $pts[2]( $pts[1][$j], $pts[2][$j] );
                    }
                    else if ( $coords[1][$i] == "rect" )
                    {
                        $pts = preg_split( "/,/", $coords[2][$i] );
                        $this->img->SetStartPoint( $pts[0], $pts[1] );
                        $this->img->LineTo( $pts[2], $pts[1] );
                        $this->img->LineTo( $pts[2], $pts[3] );
                        $this->img->LineTo( $pts[0], $pts[3] );
                        $this->img->LineTo( $pts[0], $pts[1] );
                    }
                }
            }
        }
    }

    public function Stroke( $aStrokeFileName = "" )
    {
        $_csim = $aStrokeFileName === _CSIM_SPECIALFILE;
        $this->iHasStroked = TRUE;
        $n = count( $this->plots );
        if ( $this->pieaa )
        {
            if ( $_csim )
            {
                if ( $this->background_image != "" )
                {
                    $this->StrokeFrameBackground( );
                }
                else
                {
                    $this->StrokeFrame( );
                    $this->StrokeBackgroundGrad( );
                }
            }
            $w = $this->img->width;
            $h = $this->img->height;
            $oldimg = $this->img->img;
            $this->img->CreateImgCanvas( 2 * $w, 2 * $h );
            $this->img->SetColor( $this->margin_color );
            $this->img->FilledRectangle( 0, 0, 2 * $w - 1, 2 * $h - 1 );
            $ni = count( $this->iIcons );
            $i = 0;
            for ( ; $i < $ni; ++$i )
            {
                $this->iIcons[$i] *= "iScale";
                if ( 1 < $this->iIcons[$i]->iX )
                {
                    $this->iIcons[$i] *= "iX";
                }
                if ( 1 < $this->iIcons[$i]->iY )
                {
                    $this->iIcons[$i] *= "iY";
                }
            }
            $this->StrokeIcons( );
            $i = 0;
            for ( ; $i < $n; ++$i )
            {
                if ( 1 < $this->plots[$i]->posx )
                {
                    $this->plots[$i] *= "posx";
                }
                if ( 1 < $this->plots[$i]->posy )
                {
                    $this->plots[$i] *= "posy";
                }
                $this->plots[$i]->Stroke( $this->img, 1 );
                if ( 1 < $this->plots[$i]->posx )
                {
                    $this->plots[$i] /= "posx";
                }
                if ( 1 < $this->plots[$i]->posy )
                {
                    $this->plots[$i] /= "posy";
                }
            }
            $indent = $this->doframe ? $this->frame_weight + ( $this->doshadow ? $this->shadow_width : 0 ) : 0;
            $indent += $this->framebevel ? $this->framebeveldepth + 1 : 0;
            $this->img( $oldimg, $this->img->img, $indent, $indent, $indent, $indent, $w - 2 * $indent, $h - 2 * $indent, 2 * ( $w - $indent ), 2 * ( $h - $indent ) );
            $this->img->img = $oldimg;
            $this->img->width = $w;
            $this->img->height = $h;
            $i = 0;
            for ( ; $i < $n; ++$i )
            {
                $this->plots[$i]->Stroke( $this->img, 2 );
                $this->plots[$i]->Legend( $this );
            }
        }
        else
        {
            if ( $_csim )
            {
                if ( $this->background_image != "" )
                {
                    $this->StrokeFrameBackground( );
                }
                else
                {
                    $this->StrokeFrame( );
                }
            }
            $this->StrokeIcons( );
            $i = 0;
            for ( ; $i < $n; ++$i )
            {
                $this->plots[$i]->Stroke( $this->img );
                $this->plots[$i]->Legend( $this );
            }
        }
        $this->legend->Stroke( $this->img );
        $this->footer->Stroke( $this->img );
        $this->StrokeTitles( );
        if ( $_csim )
        {
            if ( $this->texts != NULL )
            {
                $n = count( $this->texts );
                $i = 0;
                for ( ; $i < $n; ++$i )
                {
                    $this->texts[$i]->Stroke( $this->img );
                }
            }
            if ( _JPG_DEBUG )
            {
                $this->DisplayCSIMAreas( );
            }
            if ( $this->iImgTrans )
            {
                if ( class_exists( "ImgTrans", FALSE ) )
                {
                    require_once( "jpgraph_imgtrans.php" );
                }
                $tform = new ImgTrans( $this->img->img );
                $this->img->img = $this->iImgTransBorder( $this->iImgTransHorizon, $this->iImgTransSkewDist, $this->iImgTransDirection, $this->iImgTransHighQ, $this->iImgTransMinSize, $this->iImgTransFillColor, $this->iImgTransBorder );
            }
            if ( $aStrokeFileName == _IMG_HANDLER )
            {
                return $this->img->img;
            }
            $this->cache->PutAndStream( $this->img, $this->cache_name, $this->inline, $aStrokeFileName );
        }
    }

}

?>
