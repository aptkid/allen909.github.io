<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class PiePlot3D extends PiePlot
{

    private $labelhintcolor = "red";
    private $showlabelhint = TRUE;
    private $angle = 50;
    private $edgecolor = "";
    private $edgeweight = 1;
    private $iThickness = FALSE;

    public function PiePlot3d( $data )
    {
        $this->radius = 0.5;
        $this->data = $data;
        $this->title = new Text( "" );
        $this->title->SetFont( FF_FONT1, FS_BOLD );
        $this->value = new DisplayValue( );
        $this->value->Show( );
        $this->value->SetFormat( "%.0f%%" );
    }

    public function SetLegends( $aLegend )
    {
        $this->legends = array_reverse( array_slice( $aLegend, 0, count( $this->data ) ) );
    }

    public function SetSliceColors( $aColors )
    {
        $this->setslicecolors = $aColors;
    }

    public function Legend( $aGraph )
    {
        ( $aGraph );
        $aGraph->legend->txtcol = array_reverse( $aGraph->legend->txtcol );
    }

    public function SetCSIMTargets( $targets, $alts = NULL )
    {
        $this->csimtargets = $targets;
        $this->csimalts = $alts;
    }

    public function SetEdge( $aColor = "black", $aWeight = 1 )
    {
        $this->edgecolor = $aColor;
        $this->edgeweight = $aWeight;
    }

    public function ShowBorder( $exterior = TRUE, $interior = TRUE )
    {
        ( 14001 );
    }

    public function SetAngle( $a )
    {
        if ( $a < 5 || 90 < $a )
        {
            ( 14002 );
        }
        else
        {
            $this->angle = $a;
        }
    }

    public function Add3DSliceToCSIM( $i, $xc, $yc, $height, $width, $thick, $sa, $ea )
    {
        $sa *= M_PI / 180;
        $ea *= M_PI / 180;
        $coords = "{$xc}, {$yc}";
        $xp = floor( $width * cos( $sa ) / 2 + $xc );
        $yp = floor( $yc - $height * sin( $sa ) / 2 );
        $coords .= ", ".$xp.", {$yp}";
        if ( M_PI <= $sa && $sa <= 2 * M_PI * 1.01 )
        {
            $yp = floor( $yp + $thick );
            $coords .= ", ".$xp.", {$yp}";
        }
        $a = $sa + 0.2;
        while ( $a < $ea )
        {
            $xp = floor( $width * cos( $a ) / 2 + $xc );
            if ( M_PI <= $a && $a <= 2 * M_PI * 1.01 )
            {
                $yp = floor( $yc - $height * sin( $a ) / 2 + $thick );
            }
            else
            {
                $yp = floor( $yc - $height * sin( $a ) / 2 );
            }
            $coords .= ", ".$xp.", {$yp}";
            $a += 0.2;
        }
        $xp = floor( $width * cos( $ea ) / 2 + $xc );
        $yp = floor( $yc - $height * sin( $ea ) / 2 );
        if ( M_PI <= $ea && $ea <= 2 * M_PI * 1.01 )
        {
            $coords .= ", ".$xp.", ".floor( $yp + $thick );
        }
        $coords .= ", ".$xp.", {$yp}";
        $alt = "";
        if ( empty( $this->csimalts[$i] ) )
        {
            $tmp = sprintf( $this->csimalts[$i], $this->data[$i] );
            $alt = "alt=\"".$tmp."\" title=\"{$tmp}\"";
        }
        if ( empty( $this->csimtargets[$i] ) )
        {
            $ && _699987408 .= "csimareas";
        }
    }

    public function SetLabels( $aLabels, $aLblPosAdj = "auto" )
    {
        $this->labels = $aLabels;
        $this->ilabelposadj = $aLblPosAdj;
    }

    public function SetLabelMargin( $m )
    {
        $this->value->SetMargin( $m );
    }

    public function ShowLabelHint( $f = TRUE )
    {
        $this->showlabelhint = $f;
    }

    public function SetLabelHintColor( $c )
    {
        $this->labelhintcolor = $c;
    }

    public function SetHeight( $aHeight )
    {
        $this->iThickness = $aHeight;
    }

    public function NormAngle( $a )
    {
        if ( 0 < $a )
        {
            while ( 360 < $a )
            {
                $a -= 360;
            }
        }
        while ( $a < 0 )
        {
            $a += 360;
        }
        if ( $a < 0 )
        {
            $a += 360;
        }
        if ( $a == 360 )
        {
            $a = 0;
        }
        return $a;
    }

    public function Pie3DSlice( $img, $xc, $yc, $w, $h, $sa, $ea, $z, $fillcolor, $shadow = 0.65 )
    {
        if ( !( $sa < 90 ) || 90 < $ea || 90 < $sa && $sa < 270 && 270 < $ea )
        {
            ( 14003 );
            exit( 1 );
        }
        $p[] = array( );
        $rsa = $sa / 180 * M_PI;
        $rea = $ea / 180 * M_PI;
        $sinsa = sin( $rsa );
        $cossa = cos( $rsa );
        $sinea = sin( $rea );
        $cosea = cos( $rea );
        $step = 0.05;
        if ( 270 <= $sa )
        {
            if ( 360 < $ea || 0 < $ea && $ea <= 90 )
            {
                if ( 0 < $ea && $ea <= 90 )
                {
                    $rea += 2 * M_PI;
                }
                $p = array( $xc, $yc, $xc, $yc + $z, $xc + $w * $cossa, $z + $yc - $h * $sinsa );
                $pt = array( $xc, $yc, $xc + $w * $cossa, $yc - $h * $sinsa );
                $a = $rsa;
                for ( ; $a < 2 * M_PI; $a += $step )
                {
                    $tca = cos( $a );
                    $tsa = sin( $a );
                    $p[] = $xc + $w * $tca;
                    $p[] = $z + $yc - $h * $tsa;
                    $pt[] = $xc + $w * $tca;
                    $pt[] = $yc - $h * $tsa;
                }
                $pt[] = $xc + $w;
                $pt[] = $yc;
                $p[] = $xc + $w;
                $p[] = $z + $yc;
                $p[] = $xc + $w;
                $p[] = $yc;
                $p[] = $xc;
                $p[] = $yc;
                $a = 2 * M_PI + $step;
                for ( ; $a < $rea; $a += $step )
                {
                    $pt[] = $xc + $w * cos( $a );
                    $pt[] = $yc - $h * sin( $a );
                }
                $pt[] = $xc + $w * $cosea;
                $pt[] = $yc - $h * $sinea;
                $pt[] = $xc;
                $pt[] = $yc;
            }
            else
            {
                $p = array( $xc, $yc, $xc, $yc + $z, $xc + $w * $cossa, $z + $yc - $h * $sinsa );
                $pt = array( $xc, $yc, $xc + $w * $cossa, $yc - $h * $sinsa );
                $rea = $rea == 0 ? 2 * M_PI : $rea;
                $a = $rsa;
                for ( ; $a < $rea; $a += $step )
                {
                    $tca = cos( $a );
                    $tsa = sin( $a );
                    $p[] = $xc + $w * $tca;
                    $p[] = $z + $yc - $h * $tsa;
                    $pt[] = $xc + $w * $tca;
                    $pt[] = $yc - $h * $tsa;
                }
                $pt[] = $xc + $w * $cosea;
                $pt[] = $yc - $h * $sinea;
                $pt[] = $xc;
                $pt[] = $yc;
                $p[] = $xc + $w * $cosea;
                $p[] = $z + $yc - $h * $sinea;
                $p[] = $xc + $w * $cosea;
                $p[] = $yc - $h * $sinea;
                $p[] = $xc;
                $p[] = $yc;
            }
        }
        else if ( 180 <= $sa )
        {
            $p = array( $xc, $yc, $xc, $yc + $z, $xc + $w * $cosea, $z + $yc - $h * $sinea );
            $pt = array( $xc, $yc, $xc + $w * $cosea, $yc - $h * $sinea );
            $a = $rea;
            for ( ; $rsa < $a; $a -= $step )
            {
                $tca = cos( $a );
                $tsa = sin( $a );
                $p[] = $xc + $w * $tca;
                $p[] = $z + $yc - $h * $tsa;
                $pt[] = $xc + $w * $tca;
                $pt[] = $yc - $h * $tsa;
            }
            $pt[] = $xc + $w * $cossa;
            $pt[] = $yc - $h * $sinsa;
            $pt[] = $xc;
            $pt[] = $yc;
            $p[] = $xc + $w * $cossa;
            $p[] = $z + $yc - $h * $sinsa;
            $p[] = $xc + $w * $cossa;
            $p[] = $yc - $h * $sinsa;
            $p[] = $xc;
            $p[] = $yc;
        }
        else if ( 90 <= $sa )
        {
            if ( 180 < $ea )
            {
                $p = array( $xc, $yc, $xc, $yc + $z, $xc + $w * $cosea, $z + $yc - $h * $sinea );
                $pt = array( $xc, $yc, $xc + $w * $cosea, $yc - $h * $sinea );
                $a = $rea;
                for ( ; M_PI < $a; $a -= $step )
                {
                    $tca = cos( $a );
                    $tsa = sin( $a );
                    $p[] = $xc + $w * $tca;
                    $p[] = $z + $yc - $h * $tsa;
                    $pt[] = $xc + $w * $tca;
                    $pt[] = $yc - $h * $tsa;
                }
                $p[] = $xc - $w;
                $p[] = $z + $yc;
                $p[] = $xc - $w;
                $p[] = $yc;
                $p[] = $xc;
                $p[] = $yc;
                $pt[] = $xc - $w;
                $pt[] = $z + $yc;
                $pt[] = $xc - $w;
                $pt[] = $yc;
                $a = M_PI - $step;
                for ( ; $rsa < $a; $a -= $step )
                {
                    $pt[] = $xc + $w * cos( $a );
                    $pt[] = $yc - $h * sin( $a );
                }
                $pt[] = $xc + $w * $cossa;
                $pt[] = $yc - $h * $sinsa;
                $pt[] = $xc;
                $pt[] = $yc;
            }
            else
            {
                $p = array( $xc, $yc, $xc, $yc + $z, $xc + $w * $cosea, $z + $yc - $h * $sinea, $xc + $w * $cosea, $yc - $h * $sinea, $xc, $yc );
                $pt = array( $xc, $yc, $xc + $w * $cosea, $yc - $h * $sinea );
                $a = $rea;
                for ( ; $rsa < $a; $a -= $step )
                {
                    $pt[] = $xc + $w * cos( $a );
                    $pt[] = $yc - $h * sin( $a );
                }
                $pt[] = $xc + $w * $cossa;
                $pt[] = $yc - $h * $sinsa;
                $pt[] = $xc;
                $pt[] = $yc;
            }
        }
        else
        {
            $p = array( $xc, $yc, $xc, $yc + $z, $xc + $w * $cossa, $z + $yc - $h * $sinsa, $xc + $w * $cossa, $yc - $h * $sinsa, $xc, $yc );
            $pt = array( $xc, $yc, $xc + $w * $cossa, $yc - $h * $sinsa );
            $a = $rsa;
            for ( ; $a < $rea; $a += $step )
            {
                $pt[] = $xc + $w * cos( $a );
                $pt[] = $yc - $h * sin( $a );
            }
            $pt[] = $xc + $w * $cosea;
            $pt[] = $yc - $h * $sinea;
            $pt[] = $xc;
            $pt[] = $yc;
        }
        $img->PushColor( $fillcolor.":".$shadow );
        $img->FilledPolygon( $p );
        $img->PopColor( );
        $img->PushColor( $fillcolor );
        $img->FilledPolygon( $pt );
        $img->PopColor( );
    }

    public function SetStartAngle( $aStart )
    {
        if ( $aStart < 0 || 360 < $aStart )
        {
            ( 14004 );
        }
        $this->startangle = $aStart;
    }

    public function Pie3D( $aaoption, $img, $data, $colors, $xc, $yc, $d, $angle, $z, $shadow = 0.65, $startangle = 0, $edgecolor = "", $edgeweight = 1 )
    {
        $h = $angle / 90 * $d;
        $sum = 0;
        $i = 0;
        for ( ; $i < count( $data ); ++$i )
        {
            $sum += $data[$i];
        }
        if ( $sum == 0 )
        {
        }
        else
        {
            if ( $this->labeltype == 2 )
            {
                $this->adjusted_data = $this->AdjPercentage( $data );
            }
            $accsum = 0;
            $a = $startangle;
            $a = $this->NormAngle( $a );
            $idx = 0;
            $adjexplode = array( );
            $numcolors = count( $colors );
            $i = 0;
            for ( ; $i < count( $data ); ++$i, ++$idx )
            {
                $da = $data[$i] / $sum * 360;
                if ( empty( $this->explode_radius[$i] ) )
                {
                    $this->explode_radius[$i] = 0;
                }
                $expscale = 1;
                if ( $aaoption == 1 )
                {
                    $expscale = 2;
                }
                $la = $a + $da / 2;
                $explode = array( $xc + $this->explode_radius[$i] * cos( $la * M_PI / 180 ) * $expscale, $yc - $this->explode_radius[$i] * sin( $la * M_PI / 180 ) * ( $h / $d ) * $expscale );
                $adjexplode[$idx] = $explode;
                $labeldata[$i] = array( $la, $explode[0], $explode[1] );
                $originalangles[$i] = array( $a, $a + $da );
                $ne = $this->NormAngle( $a + $da );
                if ( $da <= 180 )
                {
                    $split = -1;
                    if ( !( $da <= 90 ) || !( $a <= 90 ) || 90 < $ne || $da <= 180 && 90 < $da && ( $a < 90 || 270 <= $a ) && 90 < $ne )
                    {
                        $split = 90;
                    }
                    else if ( !( $da <= 90 ) || !( $a <= 270 ) || 270 < $ne || $da <= 180 && 90 < $da && 90 <= $a && $a < 270 && 270 < $a + $da )
                    {
                        $split = 270;
                    }
                    if ( 0 < $split )
                    {
                        $angles[$idx] = array( $a, $split );
                        $adjcolors[$idx] = $colors[$i % $numcolors];
                        $adjexplode[$idx] = $explode;
                        $angles[++$idx] = array( $split, $ne );
                        $adjcolors[$idx] = $colors[$i % $numcolors];
                        $adjexplode[$idx] = $explode;
                    }
                    else
                    {
                        $angles[$idx] = array( $a, $ne );
                        $adjcolors[$idx] = $colors[$i % $numcolors];
                        $adjexplode[$idx] = $explode;
                    }
                }
                else
                {
                    if ( $a < 90 )
                    {
                        $split = 90;
                    }
                    else if ( $a <= 270 )
                    {
                        $split = 270;
                    }
                    else
                    {
                        $split = 90;
                    }
                    $angles[$idx] = array( $a, $split );
                    $adjcolors[$idx] = $colors[$i % $numcolors];
                    $adjexplode[$idx] = $explode;
                    if ( !( $a < 90 ) || 270 < $a + $da || !( 90 < $a ) || !( $a <= 270 ) || 450 < $a + $da || 270 < $a && 270 < $this->NormAngle( $a + $da ) )
                    {
                        $angles[++$idx] = array( $split, 360 - $split );
                        $adjcolors[$idx] = $colors[$i % $numcolors];
                        $adjexplode[$idx] = $explode;
                        $angles[++$idx] = array( 360 - $split, $ne );
                        $adjcolors[$idx] = $colors[$i % $numcolors];
                        $adjexplode[$idx] = $explode;
                    }
                    else
                    {
                        $angles[++$idx] = array( $split, $ne );
                        $adjcolors[$idx] = $colors[$i % $numcolors];
                        $adjexplode[$idx] = $explode;
                    }
                }
                $a += $da;
                $a = $this->NormAngle( $a );
            }
            $n = count( $angles );
            $i = 0;
            for ( ; $i < $n; ++$i )
            {
                $dbge = $angles[$i][1];
                $dbgs = $angles[$i][0];
            }
            $minval = $angles[0][0];
            $min = 0;
            $i = 0;
            for ( ; $i < $n; ++$i )
            {
                if ( $angles[$i][0] < $minval )
                {
                    $minval = $angles[$i][0];
                    $min = $i;
                }
            }
            $j = $min;
            $cnt = 0;
            while ( $angles[$j][1] <= 90 )
            {
                ++$j;
                if ( $n <= $j )
                {
                    $j = 0;
                }
                if ( $n < $cnt )
                {
                    ( 14005 );
                }
                ++$cnt;
            }
            $start = $j;
            $cnt = 0;
            while ( !( $angles[$j][0] < 270 ) || !( $aaoption !== 2 ) )
            {
                $y = $adjexplode[$j][1];
                $x = $adjexplode[$j][0];
                $adjcolors[$j]( $img, $x, $y, $d, $h, $angles[$j][0], $angles[$j][1], $z, $adjcolors[$j], $shadow );
                $last = array( $x, $y, $j );
                ++$j;
                if ( $n <= $j )
                {
                    $j = 0;
                }
                if ( $n < $cnt )
                {
                    ( 14006 );
                }
                ++$cnt;
            }
            $slice_left = $n - $cnt;
            $j = $start - 1;
            if ( $j < 0 )
            {
                $j = $n - 1;
            }
            $cnt = 0;
            while ( !( $cnt < $slice_left ) || !( $aaoption !== 2 ) )
            {
                $y = $adjexplode[$j][1];
                $x = $adjexplode[$j][0];
                $adjcolors[$j]( $img, $x, $y, $d, $h, $angles[$j][0], $angles[$j][1], $z, $adjcolors[$j], $shadow );
                --$j;
                if ( $n < $cnt )
                {
                    ( 14006 );
                }
                if ( $j < 0 )
                {
                    $j = $n - 1;
                }
                ++$cnt;
            }
            if ( $aaoption !== 2 )
            {
                $adjcolors[$last[2]]( $img, $last[0], $last[1], $d, $h, $angles[$last[2]][0], $angles[$last[2]][1], $z, $adjcolors[$last[2]], $shadow );
            }
            if ( $aaoption !== 1 )
            {
                $this->value->ApplyFont( $img );
                $margin = $img->GetFontHeight( ) / 2 + $this->value->margin;
                $i = 0;
                for ( ; $i < count( $data ); ++$i )
                {
                    $la = $labeldata[$i][0];
                    $x = $labeldata[$i][1] + cos( $la * M_PI / 180 ) * ( $d + $margin ) * $this->ilabelposadj;
                    $y = $labeldata[$i][2] - sin( $la * M_PI / 180 ) * ( $h + $margin ) * $this->ilabelposadj;
                    if ( 1 <= $this->ilabelposadj && 180 < $la && $la < 360 )
                    {
                        $y += $z;
                    }
                    if ( $this->labeltype == 0 )
                    {
                        if ( 0 < $sum )
                        {
                            $l = 100 * $data[$i] / $sum;
                        }
                        else
                        {
                            $l = 0;
                        }
                    }
                    else if ( $this->labeltype == 1 )
                    {
                        $l = $data[$i];
                    }
                    else
                    {
                        $l = $this->adjusted_data[$i];
                    }
                    if ( isset( $this->labels[$i] ) && is_string( $this->labels[$i] ) )
                    {
                        $l = sprintf( $this->labels[$i], $l );
                    }
                    $labeldata[$i][0]( $l, $img, $labeldata[$i][0] * M_PI / 180, $x, $y, $z );
                    $originalangles[$i][1]( $i, $labeldata[$i][1], $labeldata[$i][2], $h * 2, $d * 2, $z, $originalangles[$i][0], $originalangles[$i][1] );
                }
            }
            if ( $edgecolor == "" || $aaoption !== 0 )
            {
            }
            else
            {
                $accsum = 0;
                $a = $startangle;
                $a = $this->NormAngle( $a );
                $a *= M_PI / 180;
                $idx = 0;
                $img->PushColor( $edgecolor );
                $img->SetLineWeight( $edgeweight );
                $fulledge = TRUE;
                $i = 0;
                for ( ; $i < count( $data ) && $fulledge; ++$i )
                {
                    if ( empty( $this->explode_radius[$i] ) )
                    {
                        $this->explode_radius[$i] = 0;
                    }
                    if ( 0 < $this->explode_radius[$i] )
                    {
                        $fulledge = FALSE;
                    }
                }
                $i = 0;
                for ( ; $i < count( $data ); ++$i, ++$idx )
                {
                    $da = $data[$i] / $sum * 2 * M_PI;
                    $this->explode_radius[$i]( $img, $xc, $yc, $a, $a + $da, $d, $h, $z, $edgecolor, $this->explode_radius[$i], $fulledge );
                    $a += $da;
                }
                $img->PopColor( );
            }
        }
    }

    public function StrokeFullSliceFrame( $img, $xc, $yc, $sa, $ea, $w, $h, $z, $edgecolor, $exploderadius, $fulledge )
    {
        $step = 0.02;
        if ( 0 < $exploderadius )
        {
            $la = ( $sa + $ea ) / 2;
            $xc += $exploderadius * cos( $la );
            $yc -= $exploderadius * sin( $la ) * ( $h / $w );
        }
        $p = array( $xc, $yc, $xc + $w * cos( $sa ), $yc - $h * sin( $sa ) );
        $a = $sa;
        for ( ; $a < $ea; $a += $step )
        {
            $p[] = $xc + $w * cos( $a );
            $p[] = $yc - $h * sin( $a );
        }
        $p[] = $xc + $w * cos( $ea );
        $p[] = $yc - $h * sin( $ea );
        $p[] = $xc;
        $p[] = $yc;
        $img->SetColor( $edgecolor );
        $img->Polygon( $p );
        if ( $fulledge && ( !( 0 < $sa ) || !( $sa < M_PI ) || !( $ea < M_PI ) ) )
        {
            if ( $sa < M_PI && M_PI < $ea )
            {
                $sa = M_PI;
            }
            if ( $sa < 2 * M_PI && ( 2 * M_PI <= $ea || 0 < $ea && $ea < $sa ) )
            {
                $ea = 2 * M_PI;
            }
            if ( M_PI <= $sa && $ea <= 2 * M_PI )
            {
                $p = array( $xc + $w * cos( $sa ), $yc - $h * sin( $sa ), $xc + $w * cos( $sa ), $z + $yc - $h * sin( $sa ) );
                $a = $sa + $step;
                for ( ; $a < $ea; $a += $step )
                {
                    $p[] = $xc + $w * cos( $a );
                    $p[] = $z + $yc - $h * sin( $a );
                }
                $p[] = $xc + $w * cos( $ea );
                $p[] = $z + $yc - $h * sin( $ea );
                $p[] = $xc + $w * cos( $ea );
                $p[] = $yc - $h * sin( $ea );
                $img->SetColor( $edgecolor );
                $img->Polygon( $p );
            }
        }
    }

    public function Stroke( $img, $aaoption = 0 )
    {
        $n = count( $this->data );
        if ( $this->setslicecolors == NULL )
        {
            $colors = array_keys( $img->rgb->rgb_table );
            sort( &$colors );
            $idx_a = $this->themearr[$this->theme];
            $ca = array( );
            $m = count( $idx_a );
            $i = 0;
            for ( ; $i < $m; ++$i )
            {
                $ca[$i] = $colors[$idx_a[$i]];
            }
            $ca = array_reverse( array_slice( $ca, 0, $n ) );
        }
        else
        {
            $ca = $this->setslicecolors;
        }
        if ( $this->posx <= 1 && 0 < $this->posx )
        {
            $xc = round( $this->posx * $img->width );
        }
        else
        {
            $xc = $this->posx;
        }
        if ( $this->posy <= 1 && 0 < $this->posy )
        {
            $yc = round( $this->posy * $img->height );
        }
        else
        {
            $yc = $this->posy;
        }
        if ( $this->radius <= 1 )
        {
            $width = floor( $this->radius * min( $img->width, $img->height ) );
            $width = min( $width, min( $xc * 0.9, ( $yc * 90 / $this->angle - $width / 4 ) * 0.9 ) );
        }
        else
        {
            $width = $this->radius * ( $aaoption === 1 ? 2 : 1 );
        }
        if ( $width < 1 )
        {
            ( 14007 );
        }
        if ( $this->iThickness )
        {
            $thick = $this->iThickness;
            $thick *= $aaoption === 1 ? 2 : 1;
        }
        else
        {
            $thick = $width / 12;
        }
        $a = $this->angle;
        if ( $a <= 30 )
        {
            $thick *= 1.6;
        }
        else if ( $a <= 40 )
        {
            $thick *= 1.4;
        }
        else if ( $a <= 50 )
        {
            $thick *= 1.2;
        }
        else if ( $a <= 60 )
        {
            $thick *= 1;
        }
        else if ( $a <= 70 )
        {
            $thick *= 0.8;
        }
        else if ( $a <= 80 )
        {
            $thick *= 0.7;
        }
        else
        {
            $thick *= 0.6;
        }
        $thick = floor( $thick );
        if ( $this->explode_all )
        {
            $i = 0;
            for ( ; $i < $n; ++$i )
            {
                $this->explode_radius[$i] = $this->explode_r;
            }
        }
        $this->edgeweight( $aaoption, $img, $this->data, $ca, $xc, $yc, $width, $this->angle, $thick, 0.65, $this->startangle, $this->edgecolor, $this->edgeweight );
        if ( $aaoption != 1 )
        {
            $this->title->margin( $xc, $yc - $this->title->GetFontHeight( $img ) - $width / 2 - $this->title->margin, "center", "bottom" );
            $this->title->Stroke( $img );
        }
    }

    public function StrokeLabels( $label, $img, $a, $xp, $yp, $z )
    {
        $this->value->halign = "left";
        $this->value->valign = "top";
        $this->value->ApplyFont( $img );
        $h = $img->GetTextHeight( $label );
        if ( is_numeric( $label ) )
        {
            if ( 0 <= $label )
            {
                $w = sprintf( $this->value->format, $label )( sprintf( $this->value->format, $label ) );
            }
            else
            {
                $w = sprintf( $this->value->negformat, $label )( sprintf( $this->value->negformat, $label ) );
            }
        }
        else
        {
            $w = $img->GetTextWidth( $label );
        }
        while ( 2 * M_PI < $a )
        {
            $a -= 2 * M_PI;
        }
        if ( 7 * M_PI / 4 <= $a || $a <= M_PI / 4 )
        {
            $dx = 0;
        }
        if ( M_PI / 4 <= $a && $a <= 3 * M_PI / 4 )
        {
            $dx = ( $a - M_PI / 4 ) * 2 / M_PI;
        }
        if ( 3 * M_PI / 4 <= $a && $a <= 5 * M_PI / 4 )
        {
            $dx = 1;
        }
        if ( 5 * M_PI / 4 <= $a && $a <= 7 * M_PI / 4 )
        {
            $dx = 1 - ( $a - M_PI * 5 / 4 ) * 2 / M_PI;
        }
        if ( 7 * M_PI / 4 <= $a )
        {
            $dy = ( $a - M_PI - 3 * M_PI / 4 ) * 2 / M_PI;
        }
        if ( $a <= M_PI / 4 )
        {
            $dy = 1 - $a * 2 / M_PI;
        }
        if ( M_PI / 4 <= $a && $a <= 3 * M_PI / 4 )
        {
            $dy = 1;
        }
        if ( 3 * M_PI / 4 <= $a && $a <= 5 * M_PI / 4 )
        {
            $dy = 1 - ( $a - 3 * M_PI / 4 ) * 2 / M_PI;
        }
        if ( 5 * M_PI / 4 <= $a && $a <= 7 * M_PI / 4 )
        {
            $dy = 0;
        }
        $x = round( $xp - $dx * $w );
        $y = round( $yp - $dy * $h );
        $oldmargin = $this->value->margin;
        $this->value->margin = 0;
        $this->value->Stroke( $img, $label, $x, $y );
        $this->value->margin = $oldmargin;
    }

}

?>
