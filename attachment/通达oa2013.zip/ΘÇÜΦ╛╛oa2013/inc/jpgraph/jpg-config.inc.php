<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
define( "CSIMCACHE_DIR", "csimcache/" );
define( "CSIMCACHE_HTTP_DIR", "csimcache/" );
define( "CHINESE_TTF_FONT", "bkai00mp.ttf" );
define( "LANGUAGE_GREEK", FALSE );
define( "GREEK_FROM_WINDOWS", FALSE );
define( "LANGUAGE_CYRILLIC", FALSE );
define( "CYRILLIC_FROM_WINDOWS", FALSE );
define( "LANGUAGE_CHARSET", NULL );
define( "MINCHO_TTF_FONT", "ipam.ttf" );
define( "PMINCHO_TTF_FONT", "ipamp.ttf" );
define( "GOTHIC_TTF_FONT", "ipag.ttf" );
define( "PGOTHIC_TTF_FONT", "ipagp.ttf" );
define( "ASSUME_EUCJP_ENCODING", FALSE );
define( "DEFAULT_ERR_LOCALE", "en" );
define( "DEFAULT_GFORMAT", "auto" );
define( "USE_CACHE", FALSE );
define( "READ_CACHE", TRUE );
define( "USE_IMAGE_ERROR_HANDLER", TRUE );
define( "CATCH_PHPERRMSG", TRUE );
define( "INSTALL_PHP_ERR_HANDLER", FALSE );
define( "USE_APPROX_COLORS", TRUE );
define( "ERR_DEPRECATED", TRUE );
define( "BRAND_TIMING", FALSE );
define( "BRAND_TIME_FORMAT", "(%01.3fs)" );
define( "CACHE_FILE_GROUP", "wwwadmin" );
define( "CACHE_FILE_MOD", 436 );
define( "USE_BRESENHAM", FALSE );
define( "_CSIM_SPECIALFILE", "_csim_special_" );
define( "_CSIM_DISPLAY", "_jpg_csimd" );
define( "_IMG_HANDLER", "__handle" );
?>
