<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class PlotMark
{

    public $title;
    public $show = TRUE;
    public $type;
    public $weight = 1;
    public $iFormatCallback = "";
    public $iFormatCallback2 = "";
    public $fill_color = "blue";
    public $color = "black";
    public $width = 4;
    private $yvalue;
    private $xvalue = "";
    private $csimtarget;
    private $csimwintarget = "";
    private $csimalt;
    private $csimareas;
    private $markimg = "";
    private $iScale = 1;
    private $oldfilename = "";
    private $iFileName = "";
    private $imgdata_balls;
    private $imgdata_diamonds;
    private $imgdata_squares;
    private $imgdata_bevels;
    private $imgdata_stars;
    private $imgdata_pushpins;

    public function PlotMark( )
    {
        $this->title = new Text( );
        $this->title->Hide( );
        $this->csimareas = "";
        $this->type = -1;
    }

    public function SetType( $aType, $aFileName = "", $aScale = 1 )
    {
        $this->type = $aType;
        if ( $aType == MARK_IMG && $aFileName == "" )
        {
            ( 23003 );
        }
        $this->iFileName = $aFileName;
        $this->iScale = $aScale;
    }

    public function SetCallback( $aFunc )
    {
        $this->iFormatCallback = $aFunc;
    }

    public function SetCallbackYX( $aFunc )
    {
        $this->iFormatCallback2 = $aFunc;
    }

    public function GetType( )
    {
        return $this->type;
    }

    public function SetColor( $aColor )
    {
        $this->color = $aColor;
    }

    public function SetFillColor( $aFillColor )
    {
        $this->fill_color = $aFillColor;
    }

    public function SetWeight( $aWeight )
    {
        $this->weight = $aWeight;
    }

    public function SetSize( $aWidth )
    {
        $this->width = $aWidth;
    }

    public function SetWidth( $aWidth )
    {
        $this->width = $aWidth;
    }

    public function SetDefaultWidth( )
    {
        switch ( $this->type )
        {
            case MARK_CIRCLE :
            case MARK_FILLEDCIRCLE :
                $this->width = 4;
                break;
            default :
                $this->width = 7;
        }
    }

    public function GetWidth( )
    {
        return $this->width;
    }

    public function Hide( $aHide = TRUE )
    {
        $this->show = !$aHide;
    }

    public function Show( $aShow = TRUE )
    {
        $this->show = $aShow;
    }

    public function SetCSIMAltVal( $aY, $aX = "" )
    {
        $this->yvalue = $aY;
        $this->xvalue = $aX;
    }

    public function SetCSIMTarget( $aTarget, $aWinTarget = "" )
    {
        $this->csimtarget = $aTarget;
        $this->csimwintarget = $aWinTarget;
    }

    public function SetCSIMAlt( $aAlt )
    {
        $this->csimalt = $aAlt;
    }

    public function GetCSIMAreas( )
    {
        return $this->csimareas;
    }

    public function AddCSIMPoly( $aPts )
    {
        $coords = round( $aPts[0] ).", ".round( $aPts[1] );
        $n = count( $aPts ) / 2;
        $i = 1;
        for ( ; $i < $n; ++$i )
        {
            $coords .= ", ".round( $aPts[2 * $i] ).", ".round( $aPts[2 * $i + 1] );
        }
        $this->csimareas = "";
        if ( empty( $this->csimtarget ) )
        {
            $ && _112783856 .= "csimareas";
            if ( empty( $this->csimwintarget ) )
            {
                $ && _118205096 .= "csimareas";
            }
            if ( empty( $this->csimalt ) )
            {
                $tmp = sprintf( $this->csimalt, $this->yvalue, $this->xvalue );
                $ && _114082288 .= "csimareas";
            }
            $ && _114082416 .= "csimareas";
        }
    }

    public function AddCSIMCircle( $x, $y, $r )
    {
        $x = round( $x );
        $y = round( $y );
        $r = round( $r );
        $this->csimareas = "";
        if ( empty( $this->csimtarget ) )
        {
            $ && _115997984 .= "csimareas";
            if ( empty( $this->csimwintarget ) )
            {
                $ && _114079592 .= "csimareas";
            }
            if ( empty( $this->csimalt ) )
            {
                $tmp = sprintf( $this->csimalt, $this->yvalue, $this->xvalue );
                $ && _111875096 .= "csimareas";
            }
            $ && _118197440 .= "csimareas";
        }
    }

    public function Stroke( $img, $x, $y )
    {
        if ( $this->show )
        {
        }
        else
        {
            if ( $this->iFormatCallback != "" || $this->iFormatCallback2 != "" )
            {
                if ( $this->iFormatCallback != "" )
                {
                    $f = $this->iFormatCallback;
                    $fcolor = call_user_func( $f, $this->yvalue )[2];
                    $color = call_user_func( $f, $this->yvalue )[1];
                    $width = call_user_func( $f, $this->yvalue )[0];
                    $filename = $this->iFileName;
                    $imgscale = $this->iScale;
                }
                else
                {
                    $f = $this->iFormatCallback2;
                    $imgscale = call_user_func( $f, $this->yvalue, $this->xvalue )[4];
                    $filename = call_user_func( $f, $this->yvalue, $this->xvalue )[3];
                    $fcolor = call_user_func( $f, $this->yvalue, $this->xvalue )[2];
                    $color = call_user_func( $f, $this->yvalue, $this->xvalue )[1];
                    $width = call_user_func( $f, $this->yvalue, $this->xvalue )[0];
                    if ( $filename == "" )
                    {
                        $filename = $this->iFileName;
                    }
                    if ( $imgscale == "" )
                    {
                        $imgscale = $this->iScale;
                    }
                }
                if ( $width == "" )
                {
                    $width = $this->width;
                }
                if ( $color == "" )
                {
                    $color = $this->color;
                }
                if ( $fcolor == "" )
                {
                    $fcolor = $this->fill_color;
                }
            }
            else
            {
                $fcolor = $this->fill_color;
                $color = $this->color;
                $width = $this->width;
                $filename = $this->iFileName;
                $imgscale = $this->iScale;
            }
            if ( $this->type == MARK_IMG || !( MARK_FLAG1 <= $this->type ) || $this->type <= MARK_FLAG4 || MARK_IMG_PUSHPIN <= $this->type )
            {
                $anchor_x = 0.5;
                $anchor_y = 0.5;
                switch ( $this->type )
                {
                    case MARK_FLAG1 :
                    case MARK_FLAG2 :
                    case MARK_FLAG3 :
                    case MARK_FLAG4 :
                        $this->markimg = ( $this->type - MARK_FLAG1 + 1, $filename );
                        break;
                    case MARK_IMG :
                        if ( !( $this->markimg == "" ) && $this->oldfilename === $filename )
                        {
                            $this->markimg = ( "", $filename );
                            $this->oldfilename = $filename;
                            break;
                        }
                    case MARK_IMG_PUSHPIN :
                    case MARK_IMG_SPUSHPIN :
                    case MARK_IMG_LPUSHPIN :
                        if ( $this->imgdata_pushpins == NULL )
                        {
                            require_once( "imgdata_pushpins.inc.php" );
                            $this->imgdata_pushpins = new ImgData_PushPins( );
                        }
                        $this->markimg = $this->imgdata_pushpins->GetImg( $this->type, $filename );
                        $anchor_y = $this->imgdata_pushpins->GetAnchor( )[1];
                        $anchor_x = $this->imgdata_pushpins->GetAnchor( )[0];
                        break;
                    case MARK_IMG_SQUARE :
                        if ( $this->imgdata_squares == NULL )
                        {
                            require_once( "imgdata_squares.inc.php" );
                            $this->imgdata_squares = new ImgData_Squares( );
                        }
                        $this->markimg = $this->imgdata_squares->GetImg( $this->type, $filename );
                        $anchor_y = $this->imgdata_squares->GetAnchor( )[1];
                        $anchor_x = $this->imgdata_squares->GetAnchor( )[0];
                        break;
                    case MARK_IMG_STAR :
                        if ( $this->imgdata_stars == NULL )
                        {
                            require_once( "imgdata_stars.inc.php" );
                            $this->imgdata_stars = new ImgData_Stars( );
                        }
                        $this->markimg = $this->imgdata_stars->GetImg( $this->type, $filename );
                        $anchor_y = $this->imgdata_stars->GetAnchor( )[1];
                        $anchor_x = $this->imgdata_stars->GetAnchor( )[0];
                        break;
                    case MARK_IMG_BEVEL :
                        if ( $this->imgdata_bevels == NULL )
                        {
                            require_once( "imgdata_bevels.inc.php" );
                            $this->imgdata_bevels = new ImgData_Bevels( );
                        }
                        $this->markimg = $this->imgdata_bevels->GetImg( $this->type, $filename );
                        $anchor_y = $this->imgdata_bevels->GetAnchor( )[1];
                        $anchor_x = $this->imgdata_bevels->GetAnchor( )[0];
                        break;
                    case MARK_IMG_DIAMOND :
                        if ( $this->imgdata_diamonds == NULL )
                        {
                            require_once( "imgdata_diamonds.inc.php" );
                            $this->imgdata_diamonds = new ImgData_Diamonds( );
                        }
                        $this->markimg = $this->imgdata_diamonds->GetImg( $this->type, $filename );
                        $anchor_y = $this->imgdata_diamonds->GetAnchor( )[1];
                        $anchor_x = $this->imgdata_diamonds->GetAnchor( )[0];
                        break;
                    case MARK_IMG_BALL :
                    case MARK_IMG_SBALL :
                    case MARK_IMG_MBALL :
                    case MARK_IMG_LBALL :
                        if ( $this->imgdata_balls == NULL )
                        {
                            require_once( "imgdata_balls.inc.php" );
                            $this->imgdata_balls = new ImgData_Balls( );
                        }
                        $this->markimg = $this->imgdata_balls->GetImg( $this->type, $filename );
                        $anchor_y = $this->imgdata_balls->GetAnchor( )[1];
                        $anchor_x = $this->imgdata_balls->GetAnchor( )[0];
                }
                $w = $this->markimg( $this->markimg );
                $h = $this->markimg( $this->markimg );
                $dw = round( $imgscale * $w );
                $dh = round( $imgscale * $h );
                $y = $img->Rotate( $x, $y )[1];
                $x = $img->Rotate( $x, $y )[0];
                $dx = round( $x - $dw * $anchor_x );
                $dy = round( $y - $dh * $anchor_y );
                $this->width = max( $dx, $dy );
                $this->markimg( $this->markimg, $dx, $dy, 0, 0, $dw, $dh, $w, $h );
                if ( empty( $this->csimtarget ) )
                {
                    $this->csimareas = "<area shape=\"rect\" coords=\"".$dx.",".$dy.",".round( $dx + $dw ).",".round( $dy + $dh )."\" href=\"".htmlentities( $this->csimtarget )."\"";
                    if ( empty( $this->csimwintarget ) )
                    {
                        $ && _117853992 .= "csimareas";
                    }
                    if ( empty( $this->csimalt ) )
                    {
                        $tmp = sprintf( $this->csimalt, $this->yvalue, $this->xvalue );
                        $ && _117854192 .= "csimareas";
                    }
                    $ && _117854360 .= "csimareas";
                }
                $this->title->Align( "center", "top" );
                round( $dh / 2 )( $img, $x, $y + round( $dh / 2 ) );
            }
            else
            {
                $weight = $this->weight;
                $dx = round( $width / 2, 0 );
                $dy = round( $width / 2, 0 );
                $pts = 0;
                switch ( $this->type )
                {
                    case MARK_SQUARE :
                        $c[] = $x - $dx;
                        $c[] = $y - $dy;
                        $c[] = $x + $dx;
                        $c[] = $y - $dy;
                        $c[] = $x + $dx;
                        $c[] = $y + $dy;
                        $c[] = $x - $dx;
                        $c[] = $y + $dy;
                        $c[] = $x - $dx;
                        $c[] = $y - $dy;
                        $pts = 5;
                        break;
                    case MARK_UTRIANGLE :
                        ++$dx;
                        ++$dy;
                        $c[] = $x - $dx;
                        $c[] = $y + 0.87 * $dy;
                        $c[] = $x;
                        $c[] = $y - 0.87 * $dy;
                        $c[] = $x + $dx;
                        $c[] = $y + 0.87 * $dy;
                        $c[] = $x - $dx;
                        $c[] = $y + 0.87 * $dy;
                        $pts = 4;
                        break;
                    case MARK_DTRIANGLE :
                        ++$dx;
                        ++$dy;
                        $c[] = $x;
                        $c[] = $y + 0.87 * $dy;
                        $c[] = $x - $dx;
                        $c[] = $y - 0.87 * $dy;
                        $c[] = $x + $dx;
                        $c[] = $y - 0.87 * $dy;
                        $c[] = $x;
                        $c[] = $y + 0.87 * $dy;
                        $pts = 4;
                        break;
                    case MARK_DIAMOND :
                        $c[] = $x;
                        $c[] = $y + $dy;
                        $c[] = $x - $dx;
                        $c[] = $y;
                        $c[] = $x;
                        $c[] = $y - $dy;
                        $c[] = $x + $dx;
                        $c[] = $y;
                        $c[] = $x;
                        $c[] = $y + $dy;
                        $pts = 5;
                        break;
                    case MARK_LEFTTRIANGLE :
                        $c[] = $x;
                        $c[] = $y;
                        $c[] = $x;
                        $c[] = $y + 2 * $dy;
                        $c[] = $x + $dx * 2;
                        $c[] = $y;
                        $c[] = $x;
                        $c[] = $y;
                        $pts = 4;
                        break;
                    case MARK_RIGHTTRIANGLE :
                        $c[] = $x - $dx * 2;
                        $c[] = $y;
                        $c[] = $x;
                        $c[] = $y + 2 * $dy;
                        $c[] = $x;
                        $c[] = $y;
                        $c[] = $x - $dx * 2;
                        $c[] = $y;
                        $pts = 4;
                        break;
                    case MARK_FLASH :
                        $dy *= 2;
                        $c[] = $x + $dx / 2;
                        $c[] = $y - $dy;
                        $c[] = $x - $dx + $dx / 2;
                        $c[] = $y + $dy * 0.7 - $dy;
                        $c[] = $x + $dx / 2;
                        $c[] = $y + $dy * 1.3 - $dy;
                        $c[] = $x - $dx + $dx / 2;
                        $c[] = $y + 2 * $dy - $dy;
                        $img->SetLineWeight( $weight );
                        $img->SetColor( $color );
                        $img->Polygon( $c );
                        $img->SetLineWeight( 1 );
                        $this->AddCSIMPoly( $c );
                }
                if ( 0 < $pts )
                {
                    $this->AddCSIMPoly( $c );
                    $img->SetLineWeight( $weight );
                    $img->SetColor( $fcolor );
                    $img->FilledPolygon( $c );
                    $img->SetColor( $color );
                    $img->Polygon( $c );
                    $img->SetLineWeight( 1 );
                }
                else if ( $this->type == MARK_CIRCLE )
                {
                    $img->SetColor( $color );
                    $img->Circle( $x, $y, $width );
                    $this->AddCSIMCircle( $x, $y, $width );
                }
                else if ( $this->type == MARK_FILLEDCIRCLE )
                {
                    $img->SetColor( $fcolor );
                    $img->FilledCircle( $x, $y, $width );
                    $img->SetColor( $color );
                    $img->Circle( $x, $y, $width );
                    $this->AddCSIMCircle( $x, $y, $width );
                }
                else if ( $this->type == MARK_CROSS )
                {
                    $img->SetColor( $color );
                    $img->SetLineWeight( $weight );
                    $img->Line( $x, $y + $dy + 1, $x, $y - $dy - 1 );
                    $img->Line( $x - $dx - 1, $y, $x + $dx + 1, $y );
                    $this->AddCSIMCircle( $x, $y, $dx );
                }
                else if ( $this->type == MARK_X )
                {
                    $img->SetColor( $color );
                    $img->SetLineWeight( $weight );
                    $img->Line( $x + $dx, $y + $dy, $x - $dx, $y - $dy );
                    $img->Line( $x - $dx, $y + $dy, $x + $dx, $y - $dy );
                    $this->AddCSIMCircle( $x, $y, $dx + $dy );
                }
                else if ( $this->type == MARK_STAR )
                {
                    $img->SetColor( $color );
                    $img->SetLineWeight( $weight );
                    $img->Line( $x + $dx, $y + $dy, $x - $dx, $y - $dy );
                    $img->Line( $x - $dx, $y + $dy, $x + $dx, $y - $dy );
                    $img->Line( $x, $y + $dy + 1, $x, $y - $dy - 1 );
                    $img->Line( $x - $dx - 1, $y, $x + $dx + 1, $y );
                    $this->AddCSIMCircle( $x, $y, $dx + $dy );
                }
                $this->title->Align( "center", "center" );
                $this->title->Stroke( $img, $x, $y );
            }
        }
    }

}

class ImgData
{

    protected $name = "";
    protected $an = array( );
    protected $colors = array( );
    protected $index = array( );
    protected $maxidx = 0;
    protected $anchor_x = 0.5;
    protected $anchor_y = 0.5;

    public function GetImg( $aMark, $aIdx )
    {
        $n = $this->an[$aMark];
        if ( is_string( $aIdx ) )
        {
            if ( in_array( $aIdx, $this->colors ) )
            {
                ( 23001, $this->name, $aIdx );
            }
            $idx = $this->index[$aIdx];
        }
        else if ( !is_integer( $aIdx ) || is_integer( $aIdx ) && $this->maxidx < $aIdx )
        {
            ( 23002, $this->name );
        }
        else
        {
            $idx = $aIdx;
        }
        return ( base64_decode( $this->$n[$idx][1] ) );
    }

    public function GetAnchor( )
    {
        return array( $this->anchor_x, $this->anchor_y );
    }

}

class FlagCache
{

    public static function GetFlagImgByName( $aSize, $aName )
    {
        global $_gFlagCache;
        require_once( "jpgraph_flags.php" );
        if ( $_gFlagCache[$aSize] === NULL )
        {
            $_gFlagCache[$aSize] = new FlagImages( $aSize );
        }
        $f = $_gFlagCache[$aSize];
        $idx = $f->GetIdxByName( $aName, $aFullName );
        return $f->GetImgByIdx( $idx );
    }

}

$_gFlagCache = array( 1 => NULL, 2 => NULL, 3 => NULL, 4 => NULL );
?>
