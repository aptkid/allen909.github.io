<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
require_once( "jpgraph_plotband.php" );
define( "PATTERN_DIAG1", 1 );
define( "PATTERN_DIAG2", 2 );
define( "PATTERN_DIAG3", 3 );
define( "PATTERN_DIAG4", 4 );
define( "PATTERN_CROSS1", 5 );
define( "PATTERN_CROSS2", 6 );
define( "PATTERN_CROSS3", 7 );
define( "PATTERN_CROSS4", 8 );
define( "PATTERN_STRIPE1", 9 );
define( "PATTERN_STRIPE2", 10 );
class BarPlot extends Plot
{

    public $fill = FALSE;
    public $fill_color = "lightblue";
    public $iPattern = -1;
    public $iPatternDensity = 80;
    public $iPatternColor = "black";
    public $valuepos = "top";
    public $grad = FALSE;
    public $grad_style = 1;
    public $grad_fromcolor = array( 50, 50, 200 );
    public $grad_tocolor = array( 255, 255, 255 );
    public $ymin = 0;
    protected $width = 0.4;
    protected $abswidth = -1;
    protected $ybase = 0;
    protected $align = "center";
    protected $bar_shadow = FALSE;
    protected $bar_shadow_color = "black";
    protected $bar_shadow_hsize = 3;
    protected $bar_shadow_vsize = 3;

    public function BarPlot( $datay, $datax = FALSE )
    {
        $this->Plot( $datay, $datax );
        ++$this->numpoints;
    }

    public function SetShadow( $color = "black", $hsize = 3, $vsize = 3, $show = TRUE )
    {
        $this->bar_shadow = $show;
        $this->bar_shadow_color = $color;
        $this->bar_shadow_vsize = $vsize;
        $this->bar_shadow_hsize = $hsize;
        $this->value += "margin";
    }

    public function SetYMin( $aYStartValue )
    {
        $this->ybase = $aYStartValue;
    }

    public function SetYBase( $aYStartValue )
    {
        $this->ybase = $aYStartValue;
    }

    public function Legend( $graph )
    {
        if ( $this->grad && $this->legend != "" && !$this->fill )
        {
            $color = array( $this->grad_fromcolor, $this->grad_tocolor );
            $this->grad_style( $this->legend, $color, "", 0 - $this->grad_style, $this->legendcsimtarget, $this->legendcsimalt, $this->legendcsimwintarget );
        }
        else
        {
            if ( $this->legend != "" && ( -1 < $this->iPattern || is_array( $this->iPattern ) ) )
            {
                if ( is_array( $this->iPattern ) )
                {
                    $p1 = $this->iPattern[0];
                    $p2 = $this->iPatternColor[0];
                    $p3 = $this->iPatternDensity[0];
                }
                else
                {
                    $p1 = $this->iPattern;
                    $p2 = $this->iPatternColor;
                    $p3 = $this->iPatternDensity;
                }
                $color = array( $p1, $p2, $p3, $this->fill_color );
                $graph->legend->Add( $this->legend, $color, "", -101, $this->legendcsimtarget, $this->legendcsimalt, $this->legendcsimwintarget );
            }
            else
            {
                if ( $this->fill_color && $this->legend != "" )
                {
                    if ( is_array( $this->fill_color ) )
                    {
                        $this->fill_color( $this->legend, $this->fill_color[0], "", 0, $this->legendcsimtarget, $this->legendcsimalt, $this->legendcsimwintarget );
                    }
                    else
                    {
                        $graph->legend->Add( $this->legend, $this->fill_color, "", 0, $this->legendcsimtarget, $this->legendcsimalt, $this->legendcsimwintarget );
                    }
                }
            }
        }
    }

    public function PreStrokeAdjust( $graph )
    {
        ( $graph );
        if ( substr( $graph->axtype, -3, 3 ) == "log" && $this->ybase == 0 )
        {
            $this->ybase = $graph->yaxis->scale->GetMinVal( );
        }
        if ( substr( $graph->axtype, 0, 3 ) == "tex" )
        {
            $graph->xaxis->scale->ticks->SetXLabelOffset( 0.5, 0 );
            if ( -1 < $this->abswidth )
            {
                $this->abswidth( $this->abswidth );
            }
            else
            {
                if ( $this->align == "center" )
                {
                    $this->width( 0.5 - $this->width / 2 );
                }
                else
                {
                    if ( $this->align == "right" )
                    {
                        $graph->SetTextScaleOff( 1 - $this->width );
                    }
                }
            }
        }
        else
        {
            if ( ( $this instanceof AccBarPlot || $this instanceof GroupBarPlot ) && $this->abswidth == -1 )
            {
                $this->abswidth = $graph->img->plotwidth / ( 2 * count( $this->coords[0] ) );
            }
        }
    }

    public function Min( )
    {
        $m = ( );
        if ( $this->ybase <= $m[1] )
        {
            $m[1] = $this->ybase;
        }
        return $m;
    }

    public function Max( )
    {
        $m = ( );
        if ( $m[1] <= $this->ybase )
        {
            $m[1] = $this->ybase;
        }
        return $m;
    }

    public function SetWidth( $aWidth )
    {
        if ( 1 < $aWidth )
        {
            $this->abswidth = $aWidth;
        }
        else
        {
            $this->width = $aWidth;
        }
    }

    public function SetAbsWidth( $aWidth )
    {
        $this->abswidth = $aWidth;
    }

    public function SetAlign( $aAlign )
    {
        $this->align = $aAlign;
    }

    public function SetNoFill( )
    {
        $this->grad = FALSE;
        $this->fill_color = FALSE;
        $this->fill = FALSE;
    }

    public function SetFillColor( $aColor )
    {
        $this->fill = TRUE;
        $this->fill_color = $aColor;
    }

    public function SetFillGradient( $aFromColor, $aToColor = NULL, $aStyle = NULL )
    {
        $this->grad = TRUE;
        $this->grad_fromcolor = $aFromColor;
        $this->grad_tocolor = $aToColor;
        $this->grad_style = $aStyle;
    }

    public function SetValuePos( $aPos )
    {
        $this->valuepos = $aPos;
    }

    public function SetPattern( $aPattern, $aColor = "black" )
    {
        if ( is_array( $aPattern ) )
        {
            $n = count( $aPattern );
            $this->iPattern = array( );
            $this->iPatternDensity = array( );
            if ( is_array( $aColor ) )
            {
                $this->iPatternColor = array( );
                if ( count( $aColor ) != $n )
                {
                    ( "NUmber of colors is not the same as the number of patterns in BarPlot::SetPattern()" );
                }
            }
            else
            {
                $this->iPatternColor = $aColor;
            }
            $i = 0;
            for ( ; $i < $n; ++$i )
            {
                $this->iPatternDensity[$i]( $aPattern[$i], $this->iPattern[$i], $this->iPatternDensity[$i] );
                if ( is_array( $aColor ) )
                {
                    $this->iPatternColor[$i] = $aColor[$i];
                }
            }
        }
        else
        {
            $this->iPatternDensity( $aPattern, $this->iPattern, $this->iPatternDensity );
            $this->iPatternColor = $aColor;
        }
    }

    public function _SetPatternHelper( $aPattern, &$aPatternValue, &$aDensity )
    {
        switch ( $aPattern )
        {
            case PATTERN_DIAG1 :
                $aPatternValue = 1;
                $aDensity = 90;
                return;
            case PATTERN_DIAG2 :
                $aPatternValue = 1;
                $aDensity = 75;
                return;
            case PATTERN_DIAG3 :
                $aPatternValue = 2;
                $aDensity = 90;
                return;
            case PATTERN_DIAG4 :
                $aPatternValue = 2;
                $aDensity = 75;
                return;
            case PATTERN_CROSS1 :
                $aPatternValue = 8;
                $aDensity = 90;
                return;
            case PATTERN_CROSS2 :
                $aPatternValue = 8;
                $aDensity = 78;
                return;
            case PATTERN_CROSS3 :
                $aPatternValue = 8;
                $aDensity = 65;
                return;
            case PATTERN_CROSS4 :
                $aPatternValue = 7;
                $aDensity = 90;
                return;
            case PATTERN_STRIPE1 :
                $aPatternValue = 5;
                $aDensity = 90;
                return;
            case PATTERN_STRIPE2 :
                $aPatternValue = 5;
                $aDensity = 75;
                return;
        }
        ( "Unknown pattern specified in call to BarPlot::SetPattern()" );
    }

    public function Stroke( $img, $xscale, $yscale )
    {
        $numpoints = count( $this->coords[0] );
        if ( isset( $this->coords[1] ) )
        {
            if ( count( $this->coords[1] ) != $numpoints )
            {
                ( "Number of X and Y points are not equal. Number of X-points:".count( $this->coords[1] ).( "Number of Y-points:".$numpoints ) );
            }
            else
            {
                $exist_x = TRUE;
            }
        }
        else
        {
            $exist_x = FALSE;
        }
        $numbars = count( $this->coords[0] );
        if ( 0 <= $yscale->GetMinVal( ) )
        {
            $zp = $yscale->scale_abs[0];
        }
        else
        {
            $zp = $yscale->Translate( 0 );
        }
        if ( -1 < $this->abswidth )
        {
            $abswidth = $this->abswidth;
        }
        else
        {
            $abswidth = round( $this->width * $xscale->scale_factor, 0 );
        }
        if ( is_array( $this->iPattern ) )
        {
            $np = count( $this->iPattern );
        }
        $grad = NULL;
        $i = 0;
        for ( ; $i < $numbars; ++$i )
        {
            if ( $this->coords[0][$i] === NULL )
            {
            }
            else
            {
                continue;
            }
            if ( $exist_x )
            {
                $x = $this->coords[1][$i];
            }
            else
            {
                $x = $i;
            }
            $x = $xscale->Translate( $x );
            $pts = array( $x, $zp, $x, $this->coords[0][$i]( $this->coords[0][$i] ), $x + $abswidth, $this->coords[0][$i]( $this->coords[0][$i] ), $x + $abswidth, $zp );
            if ( $this->grad )
            {
                if ( $grad === NULL )
                {
                    $grad = new Gradient( $img );
                }
                if ( is_array( $this->grad_fromcolor ) )
                {
                    $ng = count( $this->grad_fromcolor );
                    if ( $ng === 3 )
                    {
                        if ( is_numeric( $this->grad_fromcolor[0] ) && 0 < $this->grad_fromcolor[0] && $this->grad_fromcolor[0] < 256 )
                        {
                            $fromcolor = $this->grad_fromcolor;
                            $tocolor = $this->grad_tocolor;
                            $style = $this->grad_style;
                        }
                    }
                    else
                    {
                        $fromcolor = $this->grad_fromcolor[$i % $ng][0];
                        $tocolor = $this->grad_fromcolor[$i % $ng][1];
                        $style = $this->grad_fromcolor[$i % $ng][2];
                    }
                    $pts[7]( $pts[2], $pts[3], $pts[6], $pts[7], $fromcolor, $tocolor, $style );
                }
                else
                {
                    $this->grad_style( $pts[2], $pts[3], $pts[6], $pts[7], $this->grad_fromcolor, $this->grad_tocolor, $this->grad_style );
                }
            }
            else if ( empty( $this->fill_color ) )
            {
                if ( is_array( $this->fill_color ) )
                {
                    $this->fill_color[$i % count( $this->fill_color )]( $this->fill_color[$i % count( $this->fill_color )] );
                }
                else
                {
                    $this->fill_color( $this->fill_color );
                }
                $img->FilledPolygon( $pts );
                $img->PopColor( );
            }
            $val = $this->coords[0][$i];
            if ( !empty( $val ) && !is_numeric( $val ) )
            {
                ( "All values for a barplot must be numeric. You have specified value[".$i."] == '".$val."'" );
            }
            if ( $this->bar_shadow && $val != 0 )
            {
                $ssh = $this->bar_shadow_hsize;
                $ssv = $this->bar_shadow_vsize;
                if ( 0 < $val )
                {
                    $sp[0] = $pts[6];
                    $sp[1] = $pts[7];
                    $sp[2] = $pts[4];
                    $sp[3] = $pts[5];
                    $sp[4] = $pts[2];
                    $sp[5] = $pts[3];
                    $sp[6] = $pts[2] + $ssh;
                    $sp[7] = $pts[3] - $ssv;
                    $sp[8] = $pts[4] + $ssh;
                    $sp[9] = $pts[5] - $ssv;
                    $sp[10] = $pts[6] + $ssh;
                    $sp[11] = $pts[7] - $ssv;
                }
                else if ( $val < 0 )
                {
                    $sp[0] = $pts[4];
                    $sp[1] = $pts[5];
                    $sp[2] = $pts[6];
                    $sp[3] = $pts[7];
                    $sp[4] = $pts[0];
                    $sp[5] = $pts[1];
                    $sp[6] = $pts[0] + $ssh;
                    $sp[7] = $pts[1] - $ssv;
                    $sp[8] = $pts[6] + $ssh;
                    $sp[9] = $pts[7] - $ssv;
                    $sp[10] = $pts[4] + $ssh;
                    $sp[11] = $pts[5] - $ssv;
                }
                if ( is_array( $this->bar_shadow_color ) )
                {
                    $numcolors = count( $this->bar_shadow_color );
                    if ( $numcolors == 0 )
                    {
                        ( "You have specified an empty array for shadow colors in the bar plot." );
                    }
                    $this->bar_shadow_color[$i % $numcolors]( $this->bar_shadow_color[$i % $numcolors] );
                }
                else
                {
                    $this->bar_shadow_color( $this->bar_shadow_color );
                }
                $img->FilledPolygon( $sp );
                $img->PopColor( );
            }
            if ( is_array( $this->iPattern ) )
            {
                $f = new RectPatternFactory( );
                if ( is_array( $this->iPatternColor ) )
                {
                    $pcolor = $this->iPatternColor[$i % $np];
                }
                else
                {
                    $pcolor = $this->iPatternColor;
                }
                $prect = $this->iPattern[$i % $np]( $this->iPattern[$i % $np], $pcolor, 1 );
                $this->iPatternDensity[$i % $np]( $this->iPatternDensity[$i % $np] );
                if ( $val < 0 )
                {
                    $rx = $pts[0];
                    $ry = $pts[1];
                }
                else
                {
                    $rx = $pts[2];
                    $ry = $pts[3];
                }
                $width = abs( $pts[4] - $pts[0] ) + 1;
                $height = abs( $pts[1] - $pts[3] ) + 1;
                new Rectangle( $rx, $ry, $width, $height )( new Rectangle( $rx, $ry, $width, $height ) );
                $prect->Stroke( $img );
            }
            else if ( -1 < $this->iPattern )
            {
                $f = new RectPatternFactory( );
                $prect = $this->iPatternColor( $this->iPattern, $this->iPatternColor, 1 );
                $this->iPatternDensity( $this->iPatternDensity );
                if ( $val < 0 )
                {
                    $rx = $pts[0];
                    $ry = $pts[1];
                }
                else
                {
                    $rx = $pts[2];
                    $ry = $pts[3];
                }
                $width = abs( $pts[4] - $pts[0] ) + 1;
                $height = abs( $pts[1] - $pts[3] ) + 1;
                new Rectangle( $rx, $ry, $width, $height )( new Rectangle( $rx, $ry, $width, $height ) );
                $prect->Stroke( $img );
            }
            if ( is_array( $this->color ) )
            {
                $this->color[$i % count( $this->color )]( $this->color[$i % count( $this->color )] );
            }
            else
            {
                $this->color( $this->color );
            }
            $pts[] = $pts[0];
            $pts[] = $pts[1];
            if ( 0 < $this->weight )
            {
                $this->weight( $this->weight );
                $img->Polygon( $pts );
            }
            $x = $pts[2] + ( $pts[4] - $pts[2] ) / 2;
            if ( $this->valuepos == "top" )
            {
                $y = $pts[3];
                if ( $img->a === 90 )
                {
                    if ( $val < 0 )
                    {
                        $this->value->SetAlign( "right", "center" );
                    }
                    else
                    {
                        $this->value->SetAlign( "left", "center" );
                    }
                }
                $this->value->Stroke( $img, $val, $x, $y );
            }
            else if ( $this->valuepos == "max" )
            {
                $y = $pts[3];
                if ( $img->a === 90 )
                {
                    if ( $val < 0 )
                    {
                        $this->value->SetAlign( "left", "center" );
                    }
                    else
                    {
                        $this->value->SetAlign( "right", "center" );
                    }
                }
                else
                {
                    $this->value->SetAlign( "center", "top" );
                }
                $this->value->SetMargin( -3 );
                $this->value->Stroke( $img, $val, $x, $y );
            }
            else if ( $this->valuepos == "center" )
            {
                $y = ( $pts[3] + $pts[1] ) / 2;
                $this->value->SetAlign( "center", "center" );
                $this->value->SetMargin( 0 );
                $this->value->Stroke( $img, $val, $x, $y );
            }
            else if ( $this->valuepos == "bottom" || $this->valuepos == "min" )
            {
                $y = $pts[1];
                if ( $img->a === 90 )
                {
                    if ( $val < 0 )
                    {
                        $this->value->SetAlign( "right", "center" );
                    }
                    else
                    {
                        $this->value->SetAlign( "left", "center" );
                    }
                }
                $this->value->SetMargin( 3 );
                $this->value->Stroke( $img, $val, $x, $y );
            }
            else
            {
                ( "Unknown position for values on bars :".$this->valuepos );
            }
            $rpts = $img->ArrRotate( $pts );
            $csimcoord = round( $rpts[0] ).", ".round( $rpts[1] );
            $j = 1;
            for ( ; $j < 4; ++$j )
            {
                $csimcoord .= ", ".round( $rpts[2 * $j] ).", ".round( $rpts[2 * $j + 1] );
            }
            if ( empty( $this->csimtargets[$i] ) )
            {
                $ && _514987056 .= "csimareas";
                $ && _514987120 .= "csimareas";
                if ( empty( $this->csimwintargets[$i] ) )
                {
                    $ && _514986992 .= "csimareas";
                }
                $sval = "";
                if ( empty( $this->csimalts[$i] ) )
                {
                    $sval = sprintf( $this->csimalts[$i], $this->coords[0][$i] );
                    $ && _514986672 .= "csimareas";
                }
                $ && _723943480 .= "csimareas";
            }
        }
        return TRUE;
    }

}

class GroupBarPlot extends BarPlot
{

    private $plots;
    private $nbrplots = 0;

    public function GroupBarPlot( $plots )
    {
        $this->width = 0.7;
        $this->plots = $plots;
        $this->nbrplots = count( $plots );
        if ( $this->nbrplots < 1 )
        {
            ( "Cannot create GroupBarPlot from empty plot array." );
        }
        $i = 0;
        for ( ; $i < $this->nbrplots; ++$i )
        {
            if ( !empty( $this->plots[$i] ) && isset( $this->plots[$i] ) )
            {
                ( "Group bar plot element nbr ".$i." is undefined or empty." );
            }
        }
        $this->numpoints = $plots[0]->numpoints;
        $this->width = 0.7;
    }

    public function Legend( $graph )
    {
        $n = count( $this->plots );
        $i = 0;
        for ( ; $i < $n; ++$i )
        {
            $c = get_class( $this->plots[$i] );
            if ( $this->plots[$i] instanceof BarPlot )
            {
                ( "One of the objects submitted to GroupBar is not a BarPlot. Make sure that you create the Group Bar plot from an array of BarPlot or AccBarPlot objects. (Class = ".$c.")" );
            }
            $this->plots[$i]->DoLegend( $graph );
        }
    }

    public function Min( )
    {
        $ymin = $this->plots[0]->Min( )[1];
        $xmin = $this->plots[0]->Min( )[0];
        $n = count( $this->plots );
        $i = 0;
        for ( ; $i < $n; ++$i )
        {
            $ym = $this->plots[$i]->Min( )[1];
            $xm = $this->plots[$i]->Min( )[0];
            $xmin = max( $xmin, $xm );
            $ymin = min( $ymin, $ym );
        }
        return array( $xmin, $ymin );
    }

    public function Max( )
    {
        $ymax = $this->plots[0]->Max( )[1];
        $xmax = $this->plots[0]->Max( )[0];
        $n = count( $this->plots );
        $i = 0;
        for ( ; $i < $n; ++$i )
        {
            $ym = $this->plots[$i]->Max( )[1];
            $xm = $this->plots[$i]->Max( )[0];
            $xmax = max( $xmax, $xm );
            $ymax = max( $ymax, $ym );
        }
        return array( $xmax, $ymax );
    }

    public function GetCSIMareas( )
    {
        $n = count( $this->plots );
        $csimareas = "";
        $i = 0;
        for ( ; $i < $n; ++$i )
        {
            $csimareas .= $this->plots[$i]->csimareas;
        }
        return $csimareas;
    }

    public function Stroke( $img, $xscale, $yscale )
    {
        $tmp = $xscale->off;
        $n = count( $this->plots );
        $subwidth = $this->width / $this->nbrplots;
        $i = 0;
        for ( ; $i < $n; ++$i )
        {
            $this->plots[$i]->ymin = $this->ybase;
            $this->plots[$i]->SetWidth( $subwidth );
            $xscale->off = $tmp + $i * round( $xscale->scale_factor * $subwidth );
            $this->plots[$i]->Stroke( $img, $xscale, $yscale );
        }
        $xscale->off = $tmp;
    }

}

class AccBarPlot extends BarPlot
{

    private $plots;
    private $nbrplots = 0;

    public function AccBarPlot( $plots )
    {
        $this->plots = $plots;
        $this->nbrplots = count( $plots );
        if ( $this->nbrplots < 1 )
        {
            ( "Cannot create AccBarPlot from empty plot array." );
        }
        $i = 0;
        for ( ; $i < $this->nbrplots; ++$i )
        {
            if ( !empty( $this->plots[$i] ) && isset( $this->plots[$i] ) )
            {
                ( "Acc bar plot element nbr ".$i." is undefined or empty." );
            }
        }
        $this->numpoints = $plots[0]->numpoints;
        $this->value = new DisplayValue( );
    }

    public function Legend( $graph )
    {
        $n = count( $this->plots );
        $i = $n - 1;
        for ( ; 0 <= $i; --$i )
        {
            $c = get_class( $this->plots[$i] );
            if ( $this->plots[$i] instanceof BarPlot )
            {
                ( "One of the objects submitted to AccBar is not a BarPlot. Make sure that you create the AccBar plot from an array of BarPlot objects.(Class=".$c.")" );
            }
            $this->plots[$i]->DoLegend( $graph );
        }
    }

    public function Max( )
    {
        $xmax = $this->plots[0]->Max( )[0];
        $nmax = 0;
        $i = 0;
        for ( ; $i < count( $this->plots ); ++$i )
        {
            $n = count( $this->plots[$i]->coords[0] );
            $nmax = max( $nmax, $n );
            $x = $this->plots[$i]->Max( )[0];
            $xmax = max( $xmax, $x );
        }
        $i = 0;
        for ( ; $i < $nmax; ++$i )
        {
            $y = 0;
            if ( isset( $this->plots[0]->coords[0][$i] ) )
            {
                ( 2014 );
            }
            if ( 0 < $this->plots[0]->coords[0][$i] )
            {
                $y = $this->plots[0]->coords[0][$i];
            }
            $j = 1;
            for ( ; $j < $this->nbrplots; ++$j )
            {
                if ( isset( $this->plots[$j]->coords[0][$i] ) )
                {
                    ( 2014 );
                }
                if ( 0 < $this->plots[$j]->coords[0][$i] )
                {
                    $y += $this->plots[$j]->coords[0][$i];
                }
            }
            $ymax[$i] = $y;
        }
        $ymax = max( $ymax );
        if ( $ymax <= $this->ybase )
        {
            $ymax = $this->ybase;
        }
        return array( $xmax, $ymax );
    }

    public function Min( )
    {
        $nmax = 0;
        $ysetmin = $this->plots[0]->Min( )[1];
        $xmin = $this->plots[0]->Min( )[0];
        $i = 0;
        for ( ; $i < count( $this->plots ); ++$i )
        {
            $n = count( $this->plots[$i]->coords[0] );
            $nmax = max( $nmax, $n );
            $y = $this->plots[$i]->Min( )[1];
            $x = $this->plots[$i]->Min( )[0];
            $xmin = min( $xmin, $x );
            $ysetmin = min( $y, $ysetmin );
        }
        $i = 0;
        for ( ; $i < $nmax; ++$i )
        {
            $y = 0;
            if ( $this->plots[0]->coords[0][$i] < 0 )
            {
                $y = $this->plots[0]->coords[0][$i];
            }
            $j = 1;
            for ( ; $j < $this->nbrplots; ++$j )
            {
                if ( $this->plots[$j]->coords[0][$i] < 0 )
                {
                    $y += $this->plots[$j]->coords[0][$i];
                }
            }
            $ymin[$i] = $y;
        }
        $ymin = min( $ysetmin, min( $ymin ) );
        if ( $this->ybase <= $ymin )
        {
            $ymin = $this->ybase;
        }
        return array( $xmin, $ymin );
    }

    public function Stroke( $img, $xscale, $yscale )
    {
        $pattern = NULL;
        $this->weight( $this->weight );
        $i = 0;
        for ( ; $i < $this->numpoints - 1; ++$i )
        {
            $accy = 0;
            $accy_neg = 0;
            $j = 0;
            for ( ; $j < $this->nbrplots; ++$j )
            {
                $this->plots[$j]->color( $this->plots[$j]->color );
                if ( 0 <= $this->plots[$j]->coords[0][$i] )
                {
                    $yt = $this->plots[$j]->coords[0]( $this->plots[$j]->coords[0][$i] + $accy );
                    $accyt = $yscale->Translate( $accy );
                    $accy += $this->plots[$j]->coords[0][$i];
                }
                else
                {
                    $yt = $this->plots[$j]->coords[0]( $this->plots[$j]->coords[0][$i] + $accy_neg );
                    $accyt = $yscale->Translate( $accy_neg );
                    $accy_neg += $this->plots[$j]->coords[0][$i];
                }
                $xt = $xscale->Translate( $i );
                if ( -1 < $this->abswidth )
                {
                    $abswidth = $this->abswidth;
                }
                else
                {
                    $abswidth = round( $this->width * $xscale->scale_factor, 0 );
                }
                $pts = array( $xt, $accyt, $xt, $yt, $xt + $abswidth, $yt, $xt + $abswidth, $accyt );
                if ( $this->bar_shadow )
                {
                    $ssh = $this->bar_shadow_hsize;
                    $ssv = $this->bar_shadow_vsize;
                    if ( $j === 0 )
                    {
                        $sp[0] = $pts[6] + 1;
                        $sp[1] = $pts[7];
                        $sp[2] = $pts[6] + $ssh;
                        $sp[3] = $pts[7] - $ssv;
                        $nsp[0] = $pts[0];
                        $nsp[1] = $pts[1];
                        $nsp[2] = $pts[0] + $ssh;
                        $nsp[3] = $pts[1] - $ssv;
                        $nsp[4] = $pts[6] + $ssh;
                        $nsp[5] = $pts[7] - $ssv;
                        $nsp[10] = $pts[6] + 1;
                        $nsp[11] = $pts[7];
                    }
                    if ( $j === $this->nbrplots - 1 )
                    {
                        if ( is_array( $this->bar_shadow_color ) )
                        {
                            $numcolors = count( $this->bar_shadow_color );
                            if ( $numcolors == 0 )
                            {
                                ( "You have specified an empty array for shadow colors in the bar plot." );
                            }
                            $this->bar_shadow_color[$i % $numcolors]( $this->bar_shadow_color[$i % $numcolors] );
                        }
                        else
                        {
                            $this->bar_shadow_color( $this->bar_shadow_color );
                        }
                        if ( 0 < $accy )
                        {
                            $sp[4] = $pts[4] + $ssh;
                            $sp[5] = $pts[5] - $ssv;
                            $sp[6] = $pts[2] + $ssh;
                            $sp[7] = $pts[3] - $ssv;
                            $sp[8] = $pts[2];
                            $sp[9] = $pts[3] - 1;
                            $sp[10] = $pts[4] + 1;
                            $sp[11] = $pts[5];
                            $img->FilledPolygon( $sp, 4 );
                        }
                        else if ( $accy_neg < 0 )
                        {
                            $nsp[6] = $pts[4] + $ssh;
                            $nsp[7] = $pts[5] - $ssv;
                            $nsp[8] = $pts[4] + 1;
                            $nsp[9] = $pts[5];
                            $img->FilledPolygon( $nsp, 4 );
                        }
                        $img->PopColor( );
                    }
                }
                if ( $this->plots[$j]->coords[0][$i] == 0 )
                {
                    if ( $this->plots[$j]->grad )
                    {
                        $grad = new Gradient( $img );
                        $this->plots[$j]->grad_style( $pts[2], $pts[3], $pts[6], $pts[7], $this->plots[$j]->grad_fromcolor, $this->plots[$j]->grad_tocolor, $this->plots[$j]->grad_style );
                    }
                    else
                    {
                        if ( is_array( $this->plots[$j]->fill_color ) )
                        {
                            $numcolors = count( $this->plots[$j]->fill_color );
                            $fillcolor = $this->plots[$j]->fill_color[$i % $numcolors];
                            if ( $fillcolor !== FALSE )
                            {
                                $this->plots[$j]->fill_color[$i % $numcolors]( $this->plots[$j]->fill_color[$i % $numcolors] );
                            }
                        }
                        else
                        {
                            $fillcolor = $this->plots[$j]->fill_color;
                            if ( $fillcolor !== FALSE )
                            {
                                $this->plots[$j]->fill_color( $this->plots[$j]->fill_color );
                            }
                        }
                        if ( $fillcolor !== FALSE )
                        {
                            $img->FilledPolygon( $pts );
                        }
                        $this->plots[$j]->color( $this->plots[$j]->color );
                    }
                    if ( -1 < $this->plots[$j]->iPattern )
                    {
                        if ( $pattern === NULL )
                        {
                            $pattern = new RectPatternFactory( );
                        }
                        $prect = $this->plots[$j]->iPatternColor( $this->plots[$j]->iPattern, $this->plots[$j]->iPatternColor, 1 );
                        $this->plots[$j]->iPatternDensity( $this->plots[$j]->iPatternDensity );
                        if ( $this->plots[$j]->coords[0][$i] < 0 )
                        {
                            $rx = $pts[0];
                            $ry = $pts[1];
                        }
                        else
                        {
                            $rx = $pts[2];
                            $ry = $pts[3];
                        }
                        $width = abs( $pts[4] - $pts[0] ) + 1;
                        $height = abs( $pts[1] - $pts[3] ) + 1;
                        new Rectangle( $rx, $ry, $width, $height )( new Rectangle( $rx, $ry, $width, $height ) );
                        $prect->Stroke( $img );
                    }
                    if ( $i < count( $this->plots[$j]->csimtargets ) )
                    {
                        $rpts = $img->ArrRotate( $pts );
                        $csimcoord = round( $rpts[0] ).", ".round( $rpts[1] );
                        $k = 1;
                        for ( ; $k < 4; ++$k )
                        {
                            $csimcoord .= ", ".round( $rpts[2 * $k] ).", ".round( $rpts[2 * $k + 1] );
                        }
                        if ( empty( $this->plots[$j]->csimtargets[$i] ) )
                        {
                            $ && _737208616 .= "csimareas";
                            $ && _737208680 .= "csimareas";
                            if ( empty( $this->plots[$j]->csimwintargets[$i] ) )
                            {
                                $ && _737208760 .= "csimareas";
                            }
                            $sval = "";
                            if ( empty( $this->plots[$j]->csimalts[$i] ) )
                            {
                                $sval = sprintf( $this->plots[$j]->csimalts[$i], $this->plots[$j]->coords[0][$i] );
                                $ && _737209008 .= "csimareas";
                            }
                            $ && _737209176 .= "csimareas";
                        }
                    }
                    $pts[] = $pts[0];
                    $pts[] = $pts[1];
                    $this->plots[$j]->line_weight( $this->plots[$j]->line_weight );
                    $img->Polygon( $pts );
                    $img->SetLineWeight( 1 );
                }
            }
            $x = $pts[2] + ( $pts[4] - $pts[2] ) / 2;
            if ( $this->bar_shadow )
            {
                $x += $ssh;
            }
            if ( $accy_neg < 0 )
            {
                $y = $yscale->Translate( $accy_neg );
                $this->value->Stroke( $img, $accy_neg, $x, $y );
            }
            else
            {
                $y = $yscale->Translate( $accy );
                $this->value->Stroke( $img, $accy, $x, $y );
            }
            $accy = 0;
            $accy_neg = 0;
            $j = 0;
            for ( ; $j < $this->nbrplots; ++$j )
            {
                if ( $this->plots[$j]->coords[0][$i] == 0 )
                {
                    if ( 0 < $this->plots[$j]->coords[0][$i] )
                    {
                        $yt = $this->plots[$j]->coords[0]( $this->plots[$j]->coords[0][$i] + $accy );
                        $accyt = $yscale->Translate( $accy );
                        if ( $this->plots[$j]->valuepos == "center" )
                        {
                            $y = $accyt - ( $accyt - $yt ) / 2;
                        }
                        else if ( $this->plots[$j]->valuepos == "bottom" )
                        {
                            $y = $accyt;
                        }
                        else
                        {
                            $y = $accyt - ( $accyt - $yt );
                        }
                        $accy += $this->plots[$j]->coords[0][$i];
                        if ( $this->plots[$j]->valuepos == "center" )
                        {
                            $this->plots[$j]->value->SetAlign( "center", "center" );
                            $this->plots[$j]->value->SetMargin( 0 );
                        }
                        else
                        {
                            if ( $this->plots[$j]->valuepos == "bottom" )
                            {
                                $this->plots[$j]->value->SetAlign( "center", "bottom" );
                                $this->plots[$j]->value->SetMargin( 2 );
                            }
                            else
                            {
                                $this->plots[$j]->value->SetAlign( "center", "top" );
                                $this->plots[$j]->value->SetMargin( 1 );
                            }
                        }
                    }
                    else
                    {
                        $yt = $this->plots[$j]->coords[0]( $this->plots[$j]->coords[0][$i] + $accy_neg );
                        $accyt = $yscale->Translate( $accy_neg );
                        $accy_neg += $this->plots[$j]->coords[0][$i];
                        if ( $this->plots[$j]->valuepos == "center" )
                        {
                            $y = $accyt - ( $accyt - $yt ) / 2;
                        }
                        else if ( $this->plots[$j]->valuepos == "bottom" )
                        {
                            $y = $accyt;
                        }
                        else
                        {
                            $y = $accyt - ( $accyt - $yt );
                        }
                        if ( $this->plots[$j]->valuepos == "center" )
                        {
                            $this->plots[$j]->value->SetAlign( "center", "center" );
                            $this->plots[$j]->value->SetMargin( 0 );
                        }
                        else if ( $this->plots[$j]->valuepos == "bottom" )
                        {
                            $this->plots[$j]->value->SetAlign( "center", $j == 0 ? "bottom" : "top" );
                            $this->plots[$j]->value->SetMargin( -2 );
                        }
                        else
                        {
                            $this->plots[$j]->value->SetAlign( "center", "bottom" );
                            $this->plots[$j]->value->SetMargin( -1 );
                        }
                    }
                    $this->plots[$j]->coords[0]( $img, $this->plots[$j]->coords[0][$i], $x, $y );
                }
            }
        }
        return TRUE;
    }

}

?>
