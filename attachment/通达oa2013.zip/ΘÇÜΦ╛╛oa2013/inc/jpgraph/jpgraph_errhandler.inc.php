<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class ErrMsgText
{

    private $lt;

    public function ErrMsgText( )
    {
        global $__jpg_err_locale;
        $file = "lang/".$__jpg_err_locale.".inc.php";
        if ( file_exists( dirname( __FILE__ )."/".$file ) )
        {
            $__jpg_err_locale = "en";
        }
        $file = "lang/".$__jpg_err_locale.".inc.php";
        if ( file_exists( dirname( __FILE__ )."/".$file ) )
        {
            exit( "Internal error: Chosen locale file for error messages does not exist." );
        }
        require_once( $file );
        $this->lt = $_jpg_messages;
    }

    public function Get( $errnbr, $a1 = NULL, $a2 = NULL, $a3 = NULL, $a4 = NULL, $a5 = NULL )
    {
        global $__jpg_err_locale;
        if ( isset( $this->lt[$errnbr] ) )
        {
            return "Internal error: The specified error message (".$errnbr.") does not exist in the chosen locale (".$__jpg_err_locale.")";
        }
        $ea = $this->lt[$errnbr];
        $j = 0;
        if ( $a1 !== NULL )
        {
            $argv[$j++] = $a1;
            if ( $a2 !== NULL )
            {
                $argv[$j++] = $a2;
                if ( $a3 !== NULL )
                {
                    $argv[$j++] = $a3;
                    if ( $a4 !== NULL )
                    {
                        $argv[$j++] = $a4;
                        if ( $a5 !== NULL )
                        {
                            $argv[$j++] = $a5;
                        }
                    }
                }
            }
        }
        $numargs = $j;
        if ( $ea[1] != $numargs )
        {
            return $ea[0];
        }
    case 1 :
        $msg = sprintf( $ea[0], $argv[0] );
        return $msg;
    case 2 :
        $msg = sprintf( $ea[0], $argv[0], $argv[1] );
        return $msg;
    case 3 :
        $msg = sprintf( $ea[0], $argv[0], $argv[1], $argv[2] );
        return $msg;
    case 4 :
        $msg = sprintf( $ea[0], $argv[0], $argv[1], $argv[2], $argv[3] );
        return $msg;
    case 5 :
        $msg = sprintf( $ea[0], $argv[0], $argv[1], $argv[2], $argv[3], $argv[4] );
        return $msg;
        $msg = ( $ea[0] );
        return $msg;
    }

}

class JpGraphError
{

    private static $__jpg_err;

    public static function Install( $aErrObject )
    {
        self::$__jpg_err = new $aErrObject( );
    }

    public static function Raise( $aMsg, $aHalt = TRUE )
    {
        self::$__jpg_err->Raise( $aMsg, $aHalt );
    }

    public static function SetErrLocale( $aLoc )
    {
        global $__jpg_err_locale;
        $__jpg_err_locale = $aLoc;
    }

    public static function RaiseL( $errnbr, $a1 = NULL, $a2 = NULL, $a3 = NULL, $a4 = NULL, $a5 = NULL )
    {
        $t = new ErrMsgText( );
        $msg = $t->Get( $errnbr, $a1, $a2, $a3, $a4, $a5 );
        self::$__jpg_err->Raise( $msg );
    }

}

class JpGraphErrObject
{

    protected $iTitle = "JpGraph Error";
    protected $iDest = FALSE;

    public function JpGraphErrObject( )
    {
    }

    public function SetTitle( $aTitle )
    {
        $this->iTitle = $aTitle;
    }

    public function SetStrokeDest( $aDest )
    {
        $this->iDest = $aDest;
    }

    public function Raise( $aMsg, $aHalt = TRUE )
    {
        $aMsg = $this->iTitle." ".$aMsg;
        if ( $this->iDest )
        {
            $f = @fopen( @$this->iDest, "a" );
            if ( $f )
            {
                @fwrite( $f, $aMsg );
                @fclose( $f );
            }
        }
        else
        {
            echo $aMsg;
        }
        if ( $aHalt )
        {
            exit( );
        }
    }

}

class JpGraphErrObjectImg extends JpGraphErrObject
{

    public function Raise( $aMsg, $aHalt = TRUE )
    {
        $img_iconerror = "iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAMAAAC7IEhfAAAAaVBMVEX//////2Xy8mLl5V/Z2VvMzFi/v1WyslKlpU+ZmUyMjEh/f0VyckJlZT9YWDxMTDjAwMDy8sLl5bnY2K/MzKW/v5yyspKlpYiYmH+MjHY/PzV/f2xycmJlZVlZWU9MTEXY2Ms/PzwyMjLFTjeaAAAAAXRSTlMAQObYZgAAAAFiS0dEAIgFHUgAAAAJcEhZcwAACxIAAAsSAdLdfvwAAAAHdElNRQfTBgISOCqusfs5AAABLUlEQVR42tWV3XKCMBBGWfkranCIVClKLd/7P2Q3QsgCxjDTq+6FE2cPH+xJ0Ogn2lQbsT+Wrs+buAZAV4W5T6Bs0YXBBwpKgEuIu+JERAX6wM2rHjmDdEITmsQEEmWADgZm6rAjhXsoMGY9B/NZBwJzBvn+e3wHntCAJdGu9SviwIwoZVDxPB9+Rc0TSEbQr0j3SA1gwdSn6Db06Tm1KfV6yzWGQO7zdpvyKLKBDmRFjzeB3LYgK7r6A/noDAfjtSIXaIzbJSv6WgUebTMV4EoRB8a2mQiQjgtF91HdKDKZ1gtFtQjkYcWaR5OKOhkYt+ZsTFdJRfPAApOpQYJTNHvCRSJR6SJngQadfcvd69OLMddVOPCGVnmrFD8bVYd3JXfxXPtLR/+mtv59/ALWiiMxqL72fwAAAABJRU5ErkJggg==";
        if ( function_exists( "imagetypes" ) )
        {
            $supported = imagetypes( );
        }
        else
        {
            $supported = 0;
        }
        if ( function_exists( "imagecreatefromstring" ) )
        {
            $supported = 0;
        }
        if ( ob_get_length( ) || headers_sent( ) || !( $supported & IMG_PNG ) )
        {
            exit( $this->iTitle." ".$aMsg );
        }
        $aMsg = wordwrap( $aMsg, 55 );
        $lines = substr_count( $aMsg, "\n" );
        $erricon = ( base64_decode( $img_iconerror ) );
        $w = 400;
        $h = 100 + 15 * max( 0, $lines - 3 );
        $img = new Image( $w, $h );
        $img->SetColor( "gray" );
        $img->FilledRectangle( 5, 5, $w - 1, $h - 1, 10 );
        $img->SetColor( "gray:0.7" );
        $img->FilledRectangle( 5, 5, $w - 3, $h - 3, 10 );
        $img->SetColor( "lightblue" );
        $img->FilledRectangle( 1, 1, $w - 5, $h - 5 );
        $img->img( $img->img, $erricon, 5, 30, 0, 0, 40, 40 );
        $img->SetColor( "black" );
        $img->Rectangle( 1, 1, $w - 5, $h - 5 );
        $img->Rectangle( 0, 0, $w - 4, $h - 4 );
        $img->SetColor( "darkred" );
        $y = 3;
        for ( ; $y < 18; $y += 2 )
        {
            $img->Line( 1, $y, $w - 6, $y );
        }
        $img->SetColor( "white" );
        $img->Line( 2, 2, 2, $h - 5 );
        $img->Line( 2, 2, $w - 6, 2 );
        $img->SetColor( "darkgray" );
        $img->Line( 2, $h - 6, $w - 5, $h - 6 );
        $img->Line( 3, $h - 7, $w - 5, $h - 7 );
        $m = floor( $w / 2 - 5 );
        $l = 100;
        $img->SetColor( "lightgray:1.3" );
        $img->FilledRectangle( $m - $l, 2, $m + $l, 16 );
        $img->SetColor( "darkred" );
        $img->SetFont( FF_FONT2, FS_BOLD );
        $this->iTitle( $m - 50, 15, $this->iTitle );
        $img->SetColor( "black" );
        $img->SetFont( FF_FONT1, FS_NORMAL );
        $txt = new Text( $aMsg, 52, 25 );
        $txt->Align( "left", "top" );
        $txt->Stroke( $img );
        if ( $this->iDest )
        {
            $this->iDest( $this->iDest );
        }
        else
        {
            $img->Headers( );
            $img->Stream( );
        }
        if ( $aHalt )
        {
            exit( );
        }
    }

}

global $__jpg_err_locale;
$__jpg_err_locale = DEFAULT_ERR_LOCALE;
if ( USE_IMAGE_ERROR_HANDLER )
{
    ( "JpGraphErrObjectImg" );
}
else
{
    ( "JpGraphErrObject" );
}
?>
