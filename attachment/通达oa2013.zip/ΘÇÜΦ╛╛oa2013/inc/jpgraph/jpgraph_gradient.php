<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class Gradient
{

    private $img;
    private $numcolors = 100;

    public function Gradient( &$img )
    {
        $this->img = $img;
    }

    public function SetNumColors( $aNum )
    {
        $this->numcolors = $aNum;
    }

    public function FilledRectangle( $xl, $yt, $xr, $yb, $from_color, $to_color, $style = 1 )
    {
    case GRAD_VER :
        switch ( $style )
        {
                $steps = round( abs( $xr - $xl ) );
                $delta = $xl <= $xr ? 1 : -1;
                $this->numcolors( $from_color, $to_color, $steps, $colors, $this->numcolors );
                $i = 0;
                $x = $xl;
                for ( ; $i < $steps; }
 ++$i )
        {
            $this->img->current_color = $colors[$i];
            $this->img->Line( $x, $yt, $x, $yb );
            $x += $delta;
        }
        continue;
        break;
    case GRAD_HOR :
        switch ( $style )
        {
                $steps = round( abs( $yb - $yt ) );
                $delta = $yt <= $yb ? 1 : -1;
                $this->numcolors( $from_color, $to_color, $steps, $colors, $this->numcolors );
                $i = 0;
                $y = $yt;
                for ( ; $i < $steps; }
 ++$i )
        {
            $this->img->current_color = $colors[$i];
            $this->img->Line( $xl, $y, $xr, $y );
            $y += $delta;
        }
        continue;
        break;
        switch ( $style )
        {
            case GRAD_MIDHOR :
                $steps = round( abs( $yb - $yt ) / 2 );
                $delta = $yt <= $yb ? 1 : -1;
                $this->numcolors( $from_color, $to_color, $steps, $colors, $this->numcolors );
                $y = $yt;
                $i = 0;
                for ( ; $i < $steps; ++$i )
                {
                    $this->img->current_color = $colors[$i];
                    $this->img->Line( $xl, $y, $xr, $y );
                    $y += $delta;
                }
                --$i;
                if ( abs( $yb - $yt ) % 2 == 1 )
                {
                    --$steps;
                }
                $j = 0;
                for ( ; $j < $steps; ++$j, --$i )
                {
                    $this->img->current_color = $colors[$i];
                    $this->img->Line( $xl, $y, $xr, $y );
                    $y += $delta;
                }
                $this->img->Line( $xl, $y, $xr, $y );
                return;
            case GRAD_MIDVER :
                $steps = round( abs( $xr - $xl ) / 2 );
                $delta = $xl <= $xr ? 1 : -1;
                $this->numcolors( $from_color, $to_color, $steps, $colors, $this->numcolors );
                $x = $xl;
                $i = 0;
                for ( ; $i < $steps; ++$i )
                {
                    $this->img->current_color = $colors[$i];
                    $this->img->Line( $x, $yb, $x, $yt );
                    $x += $delta;
                }
                --$i;
                if ( abs( $xr - $xl ) % 2 == 1 )
                {
                    --$steps;
                }
                $j = 0;
                for ( ; $j < $steps; ++$j, --$i )
                {
                    $this->img->current_color = $colors[$i];
                    $this->img->Line( $x, $yb, $x, $yt );
                    $x += $delta;
                }
                $this->img->Line( $x, $yb, $x, $yt );
                return;
            case GRAD_WIDE_MIDVER :
                $diff = round( abs( $xr - $xl ) );
                $steps = floor( abs( $diff ) / 3 );
                $firststep = $diff - 2 * $steps;
                $delta = $xl <= $xr ? 1 : -1;
                $this->numcolors( $from_color, $to_color, $firststep, $colors, $this->numcolors );
                $x = $xl;
                $i = 0;
                for ( ; $i < $firststep; ++$i )
                {
                    $this->img->current_color = $colors[$i];
                    $this->img->Line( $x, $yb, $x, $yt );
                    $x += $delta;
                }
                --$i;
                $this->img->current_color = $colors[$i];
                $j = 0;
                for ( ; $j < $steps; ++$j )
                {
                    $this->img->Line( $x, $yb, $x, $yt );
                    $x += $delta;
                }
                $j = 0;
                for ( ; $j < $steps; }
 ++$j, --$i )
        {
            $this->img->current_color = $colors[$i];
            $this->img->Line( $x, $yb, $x, $yt );
            $x += $delta;
        }
        continue;
        break;
    case GRAD_WIDE_MIDHOR :
        switch ( $style )
        {
                $diff = round( abs( $yb - $yt ) );
                $steps = floor( abs( $diff ) / 3 );
                $firststep = $diff - 2 * $steps;
                $delta = $yt <= $yb ? 1 : -1;
                $this->numcolors( $from_color, $to_color, $firststep, $colors, $this->numcolors );
                $y = $yt;
                $i = 0;
                for ( ; $i < $firststep; ++$i )
                {
                    $this->img->current_color = $colors[$i];
                    $this->img->Line( $xl, $y, $xr, $y );
                    $y += $delta;
                }
                --$i;
                $this->img->current_color = $colors[$i];
                $j = 0;
                for ( ; $j < $steps; ++$j )
                {
                    $this->img->Line( $xl, $y, $xr, $y );
                    $y += $delta;
                }
                $j = 0;
                for ( ; $j < $steps; }
 ++$j, --$i )
        {
            $this->img->current_color = $colors[$i];
            $this->img->Line( $xl, $y, $xr, $y );
            $y += $delta;
        }
        continue;
        break;
    case GRAD_LEFT_REFLECTION :
        switch ( $style )
        {
                $steps1 = round( 0.3 * abs( $xr - $xl ) );
                $delta = $xl <= $xr ? 1 : -1;
                $from_color = $this->img->rgb->Color( $from_color );
                $adj = 1.4;
                $m = ( $adj - 1 ) * ( 255 - min( 255, min( $from_color[0], min( $from_color[1], $from_color[2] ) ) ) );
                $from_color2 = array( min( 255, $from_color[0] + $m ), min( 255, $from_color[1] + $m ), min( 255, $from_color[2] + $m ) );
                $this->numcolors( $from_color2, $to_color, $steps1, $colors, $this->numcolors );
                $n = count( $colors );
                $x = $xl;
                $i = 0;
                for ( ; $i < $steps1 && $i < $n; ++$i )
                {
                    $this->img->current_color = $colors[$i];
                    $this->img->Line( $x, $yb, $x, $yt );
                    $x += $delta;
                }
                $steps2 = max( 1, round( 0.08 * abs( $xr - $xl ) ) );
                $this->img->SetColor( $to_color );
                $j = 0;
                for ( ; $j < $steps2; ++$j )
                {
                    $this->img->Line( $x, $yb, $x, $yt );
                    $x += $delta;
                }
                $steps = abs( $xr - $xl ) - $steps1 - $steps2;
                $this->numcolors( $to_color, $from_color, $steps, $colors, $this->numcolors );
                $n = count( $colors );
                $i = 0;
                for ( ; $i < $steps && $i < $n; }
 ++$i )
        {
            $this->img->current_color = $colors[$i];
            $this->img->Line( $x, $yb, $x, $yt );
            $x += $delta;
        }
        continue;
        break;
    case GRAD_RIGHT_REFLECTION :
        switch ( $style )
        {
                $steps1 = round( 0.7 * abs( $xr - $xl ) );
                $delta = $xl <= $xr ? 1 : -1;
                $this->numcolors( $from_color, $to_color, $steps1, $colors, $this->numcolors );
                $n = count( $colors );
                $x = $xl;
                $i = 0;
                for ( ; $i < $steps1 && $i < $n; ++$i )
                {
                    $this->img->current_color = $colors[$i];
                    $this->img->Line( $x, $yb, $x, $yt );
                    $x += $delta;
                }
                $steps2 = max( 1, round( 0.08 * abs( $xr - $xl ) ) );
                $this->img->SetColor( $to_color );
                $j = 0;
                for ( ; $j < $steps2; ++$j )
                {
                    $this->img->Line( $x, $yb, $x, $yt );
                    $x += $delta;
                }
                $from_color = $this->img->rgb->Color( $from_color );
                $adj = 1.4;
                $m = ( $adj - 1 ) * ( 255 - min( 255, min( $from_color[0], min( $from_color[1], $from_color[2] ) ) ) );
                $from_color = array( min( 255, $from_color[0] + $m ), min( 255, $from_color[1] + $m ), min( 255, $from_color[2] + $m ) );
                $steps = abs( $xr - $xl ) - $steps1 - $steps2;
                $this->numcolors( $to_color, $from_color, $steps, $colors, $this->numcolors );
                $n = count( $colors );
                $i = 0;
                for ( ; $i < $steps && $i < $n; }
 ++$i )
        {
            $this->img->current_color = $colors[$i];
            $this->img->Line( $x, $yb, $x, $yt );
            $x += $delta;
        }
        continue;
        break;
        switch ( $style )
        {
            case GRAD_CENTER :
                $steps = ceil( min( $yb - $yt + 1, $xr - $xl + 1 ) / 2 );
                $this->numcolors( $from_color, $to_color, $steps, $colors, $this->numcolors );
                $dx = ( $xr - $xl ) / 2;
                $dy = ( $yb - $yt ) / 2;
                $x = $xl;
                $y = $yt;
                $x2 = $xr;
                $y2 = $yb;
                $n = count( $colors );
                $x = $xl;
                $i = 0;
                for ( ; $x < $xl + $dx && $y < $yt + $dy && $i < $n; ++$x, ++$y, --$x2, --$y2, ++$i )
                {
                    $this->img->current_color = $colors[$i];
                    $this->img->Rectangle( $x, $y, $x2, $y2 );
                }
                $this->img->Line( $x, $y, $x2, $y2 );
                return;
            case GRAD_RAISED_PANEL :
                $steps1 = $xr - $xl;
                $delta = $xl <= $xr ? 1 : -1;
                $this->numcolors( $to_color, $from_color, $steps1, $colors, $this->numcolors );
                $n = count( $colors );
                $x = $xl;
                $i = 0;
                for ( ; $i < $steps1 && $i < $n; ++$i )
                {
                    $this->img->current_color = $colors[$i];
                    $this->img->Line( $x, $yb, $x, $yt );
                    $x += $delta;
                }
                $xr -= 3;
                $xl += 3;
                $yb -= 3;
                $yt += 3;
                $steps2 = $xr - $xl;
                $delta = $xl <= $xr ? 1 : -1;
                $x = $xl;
                $j = $steps2;
                for ( ; 0 <= $j; }
 --$j )
        {
            $this->img->current_color = $colors[$j];
            $this->img->Line( $x, $yb, $x, $yt );
            $x += $delta;
        }
        continue;
        break;
    case GRAD_DIAGONAL :
        switch ( $style )
        {
                if ( $yb - $yt < $xr - $xl )
                {
                    $steps = $xr - $xl;
                    $delta = $xl <= $xr ? 1 : -1;
                    $this->numcolors( $from_color, $to_color, $steps * 2, $colors, $this->numcolors );
                    $n = count( $colors );
                    $x = $xl;
                    $i = 0;
                    for ( ; $i < $steps && $i < $n; ++$i )
                    {
                        $this->img->current_color = $colors[$i];
                        $y = $yt + $i / $steps * ( $yb - $yt ) * $delta;
                        $this->img->Line( $x, $yt, $xl, $y );
                        $x += $delta;
                    }
                    $x = $xl;
                    $i = 0;
                    for ( ; $i < $steps && $i < $n; ++$i )
                    {
                        $this->img->current_color = $colors[$steps + $i];
                        $y = $yt + $i / $steps * ( $yb - $yt ) * $delta;
                        $this->img->Line( $x, $yb, $xr, $y );
                        $x += $delta;
                    }
                }
                else
                {
                    $steps = $yb - $yt;
                    $delta = $yt <= $yb ? 1 : -1;
                    $this->numcolors( $from_color, $to_color, $steps * 2, $colors, $this->numcolors );
                    $n = count( $colors );
                    $y = $yt;
                    $i = 0;
                    for ( ; $i < $steps && $i < $n; ++$i )
                    {
                        $this->img->current_color = $colors[$i];
                        $x = $xl + $i / $steps * ( $xr - $xl ) * $delta;
                        $this->img->Line( $x, $yt, $xl, $y );
                        $y += $delta;
                    }
                    $y = $yt;
                    $i = 0;
                    for ( ; $i < $steps && $i < $n; }
 }
 ++$i )
        {
            $this->img->current_color = $colors[$steps + $i];
            $x = $xl + $i / $steps * ( $xr - $xl ) * $delta;
            $this->img->Line( $x, $yb, $xr, $y );
            $x += $delta;
        }
        continue;
        break;
        ( 7001, $style );
    }

    public function FilledFlatPolygon( $pts, $from_color, $to_color )
    {
        if ( count( $pts ) == 0 )
        {
        }
        else
        {
            $maxy = $pts[1];
            $miny = $pts[1];
            $n = count( $pts );
            $i = 0;
            $idx = 0;
            for ( ; $i < $n; $i += 2 )
            {
                $x = round( $pts[$i] );
                $y = round( $pts[$i + 1] );
                $miny = min( $miny, $y );
                $maxy = max( $maxy, $y );
            }
            $colors = array( );
            $this->numcolors( $from_color, $to_color, abs( $maxy - $miny ) + 1, $colors, $this->numcolors );
            $i = $miny;
            $idx = 0;
            for ( ; $i <= $maxy; ++$i )
            {
                $colmap[$i] = $colors[$idx++];
            }
            $n = count( $pts ) / 2;
            $idx = 0;
            do
            {
                do
                {
                    if ( $idx < $n - 1 )
                    {
                        $p1 = array( round( $pts[$idx * 2] ), round( $pts[$idx * 2 + 1] ) );
                        $p2 = array( round( $pts[++$idx * 2] ), round( $pts[$idx * 2 + 1] ) );
                        $y = max( $p1[1], $p2[1] );
                        $yy = $maxy;
                        for ( ; $y < $yy; --$yy )
                        {
                            $this->img->current_color = $colmap[$yy];
                            $p2[0]( $p1[0], $yy, $p2[0] - 1, $yy );
                        }
                        $slope = ( $p2[0] - $p1[0] ) / ( $p1[1] - $p2[1] );
                        $x1 = $p1[0];
                        $x2 = $p2[0];
                        $start = $y;
                        if ( $p2[1] < $p1[1] )
                        {
                            do
                            {
                                $x1 = $slope * ( $start - $y ) + $p1[0];
                                $this->img->current_color = $colmap[$y];
                                $this->img->Line( $x1, $y, $x2, $y );
                                --$y;
                            } while ( 1 );
                        }
                        do
                        {
                        } while ( !( $p1[1] <= $y ) );
                    } while ( !( $p1[1] <= $y ) );
                    $x2 = $p2[0] + $slope * ( $start - $y );
                    $this->img->current_color = $colmap[$y];
                    $this->img->Line( $x1, $y, $x2, $y );
                    --$y;
                } while ( 1 );
            }
        }
    }

    public function GetColArray( $from_color, $to_color, $arr_size, &$colors, $numcols = 100 )
    {
        if ( $arr_size == 0 )
        {
        }
        else
        {
            $from_color = $this->img->rgb->Color( $from_color );
            $to_color = $this->img->rgb->Color( $to_color );
            $rdelta = ( $to_color[0] - $from_color[0] ) / $numcols;
            $gdelta = ( $to_color[1] - $from_color[1] ) / $numcols;
            $bdelta = ( $to_color[2] - $from_color[2] ) / $numcols;
            $colorsperstep = $numcols / $arr_size;
            $prevcolnum = -1;
            $from_alpha = $from_color[3];
            $to_alpha = $to_color[3];
            $adelta = ( $to_alpha - $from_alpha ) / $numcols;
            $i = 0;
            for ( ; $i < $arr_size; ++$i )
            {
                $colnum = floor( $colorsperstep * $i );
                if ( $colnum == $prevcolnum )
                {
                    $colors[$i] = $colidx;
                }
                else
                {
                    $r = floor( $from_color[0] + $colnum * $rdelta );
                    $g = floor( $from_color[1] + $colnum * $gdelta );
                    $b = floor( $from_color[2] + $colnum * $bdelta );
                    $alpha = $from_alpha + $colnum * $adelta;
                    $colidx = $this->img->rgb->Allocate( sprintf( "#%02x%02x%02x", $r, $g, $b ), $alpha );
                    $colors[$i] = $colidx;
                }
                $prevcolnum = $colnum;
            }
        }
    }

}

define( "GRAD_VER", 1 );
define( "GRAD_VERT", 1 );
define( "GRAD_HOR", 2 );
define( "GRAD_MIDHOR", 3 );
define( "GRAD_MIDVER", 4 );
define( "GRAD_CENTER", 5 );
define( "GRAD_WIDE_MIDVER", 6 );
define( "GRAD_WIDE_MIDHOR", 7 );
define( "GRAD_LEFT_REFLECTION", 8 );
define( "GRAD_RIGHT_REFLECTION", 9 );
define( "GRAD_RAISED_PANEL", 10 );
define( "GRAD_DIAGONAL", 11 );
?>
