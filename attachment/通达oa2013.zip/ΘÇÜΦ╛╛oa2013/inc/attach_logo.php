<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
include_once( "inc/conn.php" );
include_once( "inc/utility_file.php" );
$SYS_INTERFACE = ( "SYS_INTERFACE" );
$ATTACHMENT_ID1 = $SYS_INTERFACE['ATTACHMENT_ID1'];
$ATTACHMENT_NAME1 = $SYS_INTERFACE['ATTACHMENT_NAME1'];
$FILE_PATH = attach_real_path( $ATTACHMENT_ID1, $ATTACHMENT_NAME1 );
if ( file_exists( $FILE_PATH ) )
{
    echo _( "�ļ�������" );
    exit( );
}
ob_end_clean( );
header( "Cache-control: private" );
header( "Content-type: ".mime_type( $ATTACHMENT_NAME1 ) );
header( "Accept-Ranges: bytes" );
header( "Content-Length: ".sprintf( "%u", filesize( $FILE_PATH ) ) );
readfile( $FILE_PATH );
?>
