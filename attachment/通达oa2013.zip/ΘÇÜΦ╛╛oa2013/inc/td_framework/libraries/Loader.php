<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class TD_Loader
{

    public $_td_ob_level;
    public $_td_view_path = "";
    public $_td_is_instance = FALSE;
    public $_td_cached_vars = array( );
    public $_td_classes = array( );
    public $_td_loaded_files = array( );
    public $_td_models = array( );
    public $_td_helpers = array( );
    public $_td_plugins = array( );
    public $_td_varmap = array( 'unit_test' => "unit", 'user_agent' => "agent" );

    public function TD_Loader( )
    {
        $this->_td_view_path = APPPATH."views/";
        $this->_td_ob_level = ob_get_level( );
        log_message( "debug", "Loader Class Initialized" );
    }

    public function library( $library = "", $params = NULL, $object_name = NULL )
    {
        if ( $library == "" )
        {
            return FALSE;
        }
        if ( !is_null( $params ) && !is_array( $params ) )
        {
            $params = NULL;
        }
        if ( is_array( $library ) )
        {
            foreach ( $library as $class )
            {
                $this->_td_load_class( $class, $params, $object_name );
            }
        }
        else
        {
            $this->_td_load_class( $library, $params, $object_name );
        }
        $this->_td_assign_to_models( );
    }

    public function model( $model, $name = "", $db_conn = FALSE )
    {
        if ( is_array( $model ) )
        {
            foreach ( $model as $babe )
            {
                $this->model( $babe );
            }
        }
        else
        {
            if ( $model == "" )
            {
            }
            else
            {
                if ( strpos( $model, "/" ) === FALSE )
                {
                    $path = "";
                }
                else
                {
                    $x = explode( "/", $model );
                    $model = end( &$x );
                    unset( $x[count( $x ) - 1] );
                    $path = implode( "/", $x )."/";
                }
                if ( $name == "" )
                {
                    $name = $model;
                }
                if ( in_array( $name, $this->_td_models, TRUE ) )
                {
                }
                else
                {
                    $TD =& get_instance( );
                    if ( isset( $TD->$name ) )
                    {
                        show_error( "The model name you are loading is the name of a resource that is already being used: ".$name );
                    }
                    $model = strtolower( $model );
                    if ( file_exists( APPPATH."models/".$path.$model.EXT ) )
                    {
                        show_error( "Unable to locate the model you have specified: ".$model );
                    }
                    if ( $db_conn !== FALSE && !class_exists( "TD_DB" ) )
                    {
                        if ( $db_conn === TRUE )
                        {
                            $db_conn = "";
                        }
                        $TD->load->database( $db_conn, FALSE );
                    }
                    if ( class_exists( "Model" ) )
                    {
                        load_class( "Model", FALSE );
                    }
                    require_once( APPPATH."models/".$path.$model.EXT );
                    $model = ucfirst( $model );
                    $TD->$name = new $model( );
                    $TD->$name->_assign_libraries( );
                    $this->_td_models[] = $name;
                }
            }
        }
    }

    public function helper( $helpers = array( ) )
    {
        if ( is_array( $helpers ) )
        {
            $helpers = array( $helpers );
        }
        foreach ( $helpers as $helper )
        {
            $helper = strtolower( str_replace( EXT, "", str_replace( "_helper", "", $helper ) )."_helper" );
            if ( isset( $this->_ci_helpers[$helper] ) )
            {
                $ext_helper = APPPATH."helpers/td_".$helper.EXT;
                if ( file_exists( $ext_helper ) )
                {
                    $base_helper = BASEPATH."helpers/".$helper.EXT;
                    if ( file_exists( $base_helper ) )
                    {
                        show_error( "Unable to load the requested file: helpers/".$helper.EXT );
                    }
                    include_once( $ext_helper );
                    include_once( $base_helper );
                }
                else if ( file_exists( APPPATH."helpers/".$helper.EXT ) )
                {
                    include_once( APPPATH."helpers/".$helper.EXT );
                }
                else if ( file_exists( BASEPATH."helpers/".$helper.EXT ) )
                {
                    include_once( BASEPATH."helpers/".$helper.EXT );
                }
                else
                {
                    show_error( "Unable to load the requested file: helpers/".$helper.EXT );
                }
                $this->_td_helpers[$helper] = TRUE;
                log_message( "debug", "Helper loaded: ".$helper );
            }
        }
    }

    public function database( $params = "", $return = FALSE )
    {
        $TD =& get_instance( );
        if ( class_exists( "TD_Database" ) && !$return && isset( $TD->db ) && is_object( $TD->db ) && $TD->db->hostname == $params[hostname] )
        {
            return FALSE;
        }
        require_once( BASEPATH."libraries/Database".EXT );
        if ( $return === TRUE )
        {
            return new TD_Database( $params );
        }
        $TD->db = "";
        $TD->db = new TD_Database( $params );
        $this->_td_assign_to_models( );
    }

    public function view( $view, $vars = array( ), $return = FALSE )
    {
        return $this->_td_load( array( "_td_view" => $view, "_td_vars" => $this->_td_object_to_array( $vars ), "_td_return" => $return ) );
    }

    public function file( $path, $return = FALSE )
    {
        return $this->_td_load( array( "_td_path" => $path, "_td_return" => $return ) );
    }

    public function vars( $vars = array( ), $val = "" )
    {
        if ( $val != "" && is_string( $vars ) )
        {
            $vars = array( $vars => $val );
        }
        $vars = $this->_td_object_to_array( $vars );
        if ( is_array( $vars ) && 0 < count( $vars ) )
        {
            foreach ( $vars as $key => $val )
            {
                $this->_td_cached_vars[$key] = $val;
            }
        }
    }

    public function _td_load( $_td_data )
    {
        foreach ( array( "_td_view", "_td_vars", "_td_path", "_td_return" ) as $_td_val )
        {
            $$_td_val = !isset( $_td_data[$_td_val] ) ? FALSE : $_td_data[$_td_val];
        }
        if ( $_td_path == "" )
        {
            $_td_ext = pathinfo( $_td_view, PATHINFO_EXTENSION );
            $_td_file = $_td_ext == "" ? $_td_view.EXT : $_td_view;
            $_td_path = $this->_td_view_path.$_td_file;
        }
        else
        {
            $_td_x = explode( "/", $_td_path );
            $_td_file = end( &$_td_x );
        }
        if ( file_exists( $_td_path ) )
        {
            show_error( "Unable to load the requested file: ".$_td_file );
        }
        if ( $this->_td_is_instance( ) )
        {
            $_td_TD =& get_instance( );
            foreach ( get_object_vars( $_td_TD ) as $_td_key => $_td_var )
            {
                if ( isset( $this->$_td_key ) )
                {
                    $this->$_td_key =& $_td_TD->$_td_key;
                }
            }
        }
        if ( is_array( $_td_vars ) )
        {
            $this->_td_cached_vars = array_merge( $this->_td_cached_vars, $_td_vars );
        }
        extract( $this->_td_cached_vars );
        ob_start( );
        if ( @ini_get( "short_open_tag" ) === FALSE || config_item( "rewrite_short_tags" ) )
        {
            echo eval( "?>".preg_replace( "/;*\\s*\\?>/", "; ?>", str_replace( "<?=", "<?php echo ", file_get_contents( $_td_path ) ) ) );
        }
        else
        {
            include( $_td_path );
        }
        log_message( "debug", "File loaded: ".$_td_path );
        if ( $_td_return === TRUE )
        {
            $buffer = ob_get_contents( );
            @ob_end_clean( );
            return $buffer;
        }
        if ( $this->_td_ob_level + 1 < ob_get_level( ) )
        {
            ob_end_flush( );
        }
    }

    public function _td_load_class( $class, $params = NULL, $object_name = NULL )
    {
        $class = str_replace( EXT, "", trim( $class, "/" ) );
        $subdir = "";
        if ( strpos( $class, "/" ) !== FALSE )
        {
            $x = explode( "/", $class );
            $class = end( &$x );
            unset( $x[count( $x ) - 1] );
            $subdir = implode( $x, "/" )."/";
        }
        foreach ( array( ucfirst( $class ), strtolower( $class ) ) as $class )
        {
            $subclass = APPPATH."libraries/td_".$class.EXT;
            if ( file_exists( $subclass ) )
            {
                $baseclass = BASEPATH."libraries/".ucfirst( $class ).EXT;
                if ( file_exists( $baseclass ) )
                {
                    log_message( "error", "Unable to load the requested class: ".$class );
                    show_error( "Unable to load the requested class: ".$class );
                }
                if ( in_array( $subclass, $this->_td_loaded_files ) )
                {
                    if ( is_null( $object_name ) )
                    {
                        $TD =& get_instance( );
                        if ( isset( $TD->$object_name ) )
                        {
                            return config_item( "subclass_prefix" )( $class, config_item( "subclass_prefix" ), $params, $object_name );
                        }
                    }
                    $is_duplicate = TRUE;
                    log_message( "debug", $class." class already loaded. Second attempt ignored." );
                }
                else
                {
                    include_once( $baseclass );
                    include_once( $subclass );
                    $this->_td_loaded_files[] = $subclass;
                    return config_item( "subclass_prefix" )( $class, config_item( "subclass_prefix" ), $params, $object_name );
                }
            }
            $is_duplicate = FALSE;
            $i = 1;
            for ( ; $i < 3; ++$i )
            {
                $path = $i % 2 ? APPPATH : BASEPATH;
                $filepath = $path."libraries/".$subdir.$class.EXT;
                if ( file_exists( $filepath ) )
                {
                }
                else if ( in_array( $filepath, $this->_td_loaded_files ) )
                {
                    if ( is_null( $object_name ) )
                    {
                        $TD =& get_instance( );
                        if ( isset( $TD->$object_name ) )
                        {
                            return $this->_td_init_class( $class, "", $params, $object_name );
                        }
                    }
                    $is_duplicate = TRUE;
                    log_message( "debug", $class." class already loaded. Second attempt ignored." );
                }
                else
                {
                    include_once( $filepath );
                    $this->_td_loaded_files[] = $filepath;
                    return $this->_td_init_class( $class, "", $params, $object_name );
                    break;
                }
            }
        }
        if ( $subdir == "" )
        {
            $path = strtolower( $class )."/".$class;
            return $this->_td_load_class( $path, $params );
        }
        if ( $is_duplicate )
        {
            log_message( "error", "Unable to load the requested class: ".$class );
            show_error( "Unable to load the requested class: ".$class );
        }
    }

    public function _td_init_class( $class, $prefix = "", $config = FALSE, $object_name = NULL )
    {
        if ( $config === NULL )
        {
            if ( file_exists( APPPATH."config/".strtolower( $class ).EXT ) )
            {
                include_once( APPPATH."config/".strtolower( $class ).EXT );
            }
            else if ( file_exists( APPPATH."config/".ucfirst( strtolower( $class ) ).EXT ) )
            {
                include_once( APPPATH."config/".ucfirst( strtolower( $class ) ).EXT );
            }
        }
        if ( $prefix == "" )
        {
            if ( class_exists( "TD_".$class ) )
            {
                $name = "TD_".$class;
            }
            else
            {
                $name = $class;
            }
        }
        else
        {
            $name = $prefix.$class;
        }
        if ( class_exists( $name ) )
        {
            log_message( "error", "Non-existent class: ".$name );
            show_error( "Non-existent class: ".$class );
        }
        $class = strtolower( $class );
        if ( is_null( $object_name ) )
        {
            $classvar = !isset( $this->_td_varmap[$class] ) ? $class : $this->_td_varmap[$class];
        }
        else
        {
            $classvar = $object_name;
        }
        $this->_td_classes[$class] = $classvar;
        $TD =& get_instance( );
        if ( $config !== NULL )
        {
            $TD->$classvar = new $name( $config );
        }
        else
        {
            $TD->$classvar = new $name( );
        }
    }

    public function _td_assign_to_models( )
    {
        if ( count( $this->_td_models ) == 0 )
        {
        }
        else if ( $this->_td_is_instance( ) )
        {
            $TD =& get_instance( );
            foreach ( $this->_td_models as $model )
            {
                $TD->$model->_assign_libraries( );
            }
            else
            {
                foreach ( $this->_td_models as $model )
                {
                    $this->$model->_assign_libraries( );
                    break;
                }
            }
        }
    }

    public function _td_object_to_array( $object )
    {
        if ( is_object( $object ) )
        {
            return get_object_vars( $object );
        }
        return $object;
    }

    public function _td_is_instance( )
    {
        global $TD;
        if ( is_object( $TD ) )
        {
            return TRUE;
        }
        return FALSE;
    }

}

if ( defined( "BASEPATH" ) )
{
    exit( "No direct script access allowed" );
}
?>
