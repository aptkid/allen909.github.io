<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class TD_Base
{

    private static $instance;

    public function TD_Base( )
    {
        self::$instance =& $this;
    }

    public static function &get_instance( )
    {
        return self::$instance;
    }

}

function &get_instance( )
{
    return ( );
}

if ( defined( "BASEPATH" ) )
{
    exit( "No direct script access allowed" );
}
?>
