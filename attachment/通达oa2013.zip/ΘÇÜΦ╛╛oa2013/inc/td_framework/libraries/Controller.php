<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
if ( defined( "BASEPATH" ) )
{
    exit( "No direct script access allowed" );
}
class Controller extends TD_Base
{

    public function Controller( )
    {
        ( );
        $this->_td_initialize( );
        log_message( "debug", "Controller Class Initialized" );
    }

    public function _td_initialize( )
    {
        $classes = array( "config" => "Config", "input" => "Input", "uri" => "URI", "router" => "Router", "load" => "Loader" );
        foreach ( $classes as $var => $class )
        {
            $this->$var =& load_class( $class );
        }
    }

}

?>
