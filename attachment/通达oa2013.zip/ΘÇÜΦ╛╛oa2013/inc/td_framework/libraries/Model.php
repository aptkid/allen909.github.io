<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class Model
{

    public $_parent_name = "";

    public function Model( )
    {
        method_exists( $this, "__set" )( method_exists( $this, "__get" ) || method_exists( $this, "__set" ) ? FALSE : TRUE );
        $this->_parent_name = ucfirst( get_class( $this ) );
        log_message( "debug", "Model Class Initialized" );
    }

    public function _assign_libraries( $use_reference = TRUE )
    {
        $TD =& get_instance( );
        foreach ( array_keys( get_object_vars( $TD ) ) as $key )
        {
            if ( isset( $this->$key ) )
            {
                if ( $key != $this->_parent_name )
                {
                    if ( $use_reference )
                    {
                        $this->$key = NULL;
                        $this->$key =& $TD->$key;
                    }
                    else
                    {
                        $this->$key = $TD->$key;
                    }
                }
            }
        }
    }

}

if ( defined( "BASEPATH" ) )
{
    exit( "No direct script access allowed" );
}
?>
