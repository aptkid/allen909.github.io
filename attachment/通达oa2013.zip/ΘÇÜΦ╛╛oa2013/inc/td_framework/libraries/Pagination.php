<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class TD_Pagination
{

    public $base_url = "";
    public $total_rows = "";
    public $per_page = 10;
    public $num_links = 2;
    public $cur_page = 0;
    public $first_link = "��ҳ";
    public $next_link = "��һҳ";
    public $prev_link = "��һҳ";
    public $last_link = "ĩҳ";
    public $uri_segment = 3;
    public $full_tag_open = "";
    public $full_tag_close = "";
    public $first_tag_open = "";
    public $first_tag_close = "";
    public $last_tag_open = "";
    public $last_tag_close = "";
    public $cur_tag_open = "&nbsp;<strong>";
    public $cur_tag_close = "</strong>";
    public $next_tag_open = "";
    public $next_tag_close = "";
    public $prev_tag_open = "";
    public $prev_tag_close = "";
    public $num_tag_open = "";
    public $num_tag_close = "";
    public $page_query_string = FALSE;
    public $query_string_segment = "per_page";
    public $query_keys = "";

    public function TD_Pagination( $params = array( ) )
    {
        if ( 0 < count( $params ) )
        {
            $this->initialize( $params );
        }
        log_message( "debug", "Pagination Class Initialized" );
    }

    public function initialize( $params = array( ) )
    {
        if ( 0 < count( $params ) )
        {
            foreach ( $params as $key => $val )
            {
                if ( isset( $this->$key ) )
                {
                    $this->$key = $val;
                }
            }
        }
        $this->split_uri( );
    }

    private function split_uri( )
    {
        $arr = split( "\\?", $this->base_url );
        $this->base_url = $arr[0];
        if ( count( $arr ) == 2 )
        {
            $this->query_keys = "?".$arr[1];
        }
    }

    public function create_links( )
    {
        if ( $this->total_rows == 0 || $this->per_page == 0 )
        {
            return "";
        }
        $num_pages = ceil( $this->total_rows / $this->per_page );
        if ( $num_pages == 1 )
        {
            return "";
        }
        $TD =& get_instance( );
        if ( $TD->config->item( "enable_query_strings" ) === TRUE || $this->page_query_string === TRUE )
        {
            if ( $TD->input->get( $this->query_string_segment ) != 0 )
            {
                $this->cur_page = $TD->input->get( $this->query_string_segment );
                $this->cur_page = ( integer );
            }
        }
        else if ( $TD->uri->segment( $this->uri_segment ) != 0 )
        {
            $this->cur_page = $TD->uri->segment( $this->uri_segment );
            $this->cur_page = ( integer );
        }
        $this->num_links = ( integer );
        if ( $this->num_links < 1 )
        {
            show_error( "Your number of links must be a positive number." );
        }
        if ( is_numeric( $this->cur_page ) )
        {
            $this->cur_page = 0;
        }
        if ( $this->total_rows < $this->cur_page )
        {
            $this->cur_page = ( $num_pages - 1 ) * $this->per_page;
        }
        $uri_page_number = $this->cur_page;
        $this->cur_page = floor( $this->cur_page / $this->per_page + 1 );
        if ( $TD->config->item( "enable_query_strings" ) === TRUE || $this->page_query_string === TRUE )
        {
            $this->base_url = rtrim( $this->base_url )."&amp;".$this->query_string_segment."=";
        }
        else
        {
            $this->base_url = rtrim( $this->base_url, "/" )."/";
        }
        $output = "<div id=\"pageArea\" class=\"pageArea\">";
        $output .= sprintf( _( "��%sҳ" ), "<span id=\"pageNumber\" class=\"pageNumber\">".$this->cur_page."/".$num_pages."</span>" );
        if ( $this->cur_page <= 1 )
        {
            $output .= $this->first_tag_open."<a id=\"pageFirst\" class=\"pageFirstDisable\" title=\""._( $this->first_link )."\" href=\"javascript:\"></a><a id=\"pagePrevious\" class=\"pagePreviousDisable\" title=\""._( $this->prev_link )."\" href=\"javascript:\"></a>";
        }
        else
        {
            $output .= $this->first_tag_open."<a id=\"pageFirst\" class=\"pageFirst\" title=\""._( $this->first_link )."\" href=\"".$this->base_url.$this->query_keys."\"></a><a id=\"pagePrevious\" class=\"pagePrevious\" title=\""._( $this->prev_link )."\" href=\"".$this->base_url.( $this->cur_page - 2 ) * $this->per_page.$this->query_keys."\"></a>";
        }
        if ( $num_pages <= $this->cur_page )
        {
            $output .= $this->next_tag_open."<a id=\"pageNext\" class=\"pageNextDisable\" title=\""._( $this->next_link )."\" href=\"javascript:\"></a><a id=\"pageLast\" class=\"pageLastDisable\" title=\""._( $this->last_link )."\" href=\"javascript:\"></a>";
        }
        else
        {
            $output .= $this->next_tag_open."<a id=\"pageNext\" class=\"pageNext\" title=\""._( $this->next_link )."\" href=\"".$this->base_url.$this->cur_page * $this->per_page.$this->query_keys."\"></a><a id=\"pageLast\" class=\"pageLast\" title=\""._( $this->last_link )."\" href=\"".$this->base_url.( $num_pages - 1 ) * $this->per_page.$this->query_keys."\"></a>";
        }
        $output = preg_replace( "#([^:])//+#", "\\1/", $output );
        $output = $this->full_tag_open.$output.$this->full_tag_close;
        $output .= sprintf( _( "ת�� �� %s ҳ" ), "<input type=\"text\" size=\"3\" class=\"SmallInput\" name=\"page_no\" id=\"page_no\" onkeypress=\"input_page_no()\" style=\"text-align:center;\">" )." <a href=\"javascript:goto_page();\" id=\"pageGoto\" class=\"pageGoto\" title="._( "\"ת��\")" )."></a>";
        $output .= "</div>";
        $output .= "<script>function goto_page(){var page_no=parseInt(document.getElementById('page_no').value);if(isNaN(page_no)||page_no<1||page_no>".$num_pages."){alert(\"".sprintf( _( "ҳ������Ϊ1-%s" ), $num_pages )."\");return;}window.location=\"".$this->base_url."\"+(page_no-1)*".$this->per_page."+\"".$this->query_keys."\";} function input_page_no(){if(event.keyCode==13) goto_page();if(event.keyCode<47||event.keyCode>57) event.returnValue=false;}</script>";
        return $output;
    }

}

if ( defined( "BASEPATH" ) )
{
    exit( "No direct script access allowed" );
}
?>
