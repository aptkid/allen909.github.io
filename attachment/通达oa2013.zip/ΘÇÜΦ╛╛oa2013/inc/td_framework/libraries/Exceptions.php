<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class TD_Exceptions
{

    public $action;
    public $severity;
    public $message;
    public $filename;
    public $line;
    public $ob_level;
    public $levels = array( 'E_ERROR' => ?id #20917448, 'E_WARNING' => ?id #20917544, 'E_PARSE' => ?id #20917640, 'E_NOTICE' => ?id #20917744, 'E_CORE_ERROR' => ?id #20917840, 'E_CORE_WARNING' => ?id #20917944, 'E_COMPILE_ERROR' => ?id #20918064, 'E_COMPILE_WARNING' => ?id #20918176, 'E_USER_ERROR' => ?id #20918312, 'E_USER_WARNING' => ?id #20918488, 'E_USER_NOTICE' => ?id #20918600, 'E_STRICT' => ?id #20918712 );

    public function TD_Exceptions( )
    {
        $this->ob_level = ob_get_level( );
    }

    public function log_exception( $severity, $message, $filepath, $line )
    {
        $severity = !isset( $this->levels[$severity] ) ? $severity : $this->levels[$severity];
        log_message( "error", "Severity: ".$severity."  --> ".$message." ".$filepath." ".$line, TRUE );
    }

    public function show_404( $page = "" )
    {
        $heading = "404 Page Not Found";
        $message = _( "�������ҳ���ַ������." );
        log_message( "error", "404 Page Not Found --> ".$page );
        echo $this->show_error( $heading, $message, "error_404", 404 );
        exit( );
    }

    public function show_error( $heading, $message, $template = "error_general", $status_code = 500 )
    {
        set_status_header( $status_code );
        $message = "<p>".implode( "</p><p>", !is_array( $message ) ? array( $message ) : $message )."</p>";
        if ( $this->ob_level + 1 < ob_get_level( ) )
        {
            ob_end_flush( );
        }
        ob_start( );
        include( BASEPATH."errors/".$template.EXT );
        $buffer = ob_get_contents( );
        ob_end_clean( );
        return $buffer;
    }

    public function show_php_error( $severity, $message, $filepath, $line )
    {
        $severity = !isset( $this->levels[$severity] ) ? $severity : $this->levels[$severity];
        $filepath = str_replace( "\\", "/", $filepath );
        if ( FALSE !== strpos( $filepath, "/" ) )
        {
            $x = explode( "/", $filepath );
            $filepath = $x[count( $x ) - 2]."/".end( &$x );
        }
        if ( $this->ob_level + 1 < ob_get_level( ) )
        {
            ob_end_flush( );
        }
        ob_start( );
        include( BASEPATH."errors/error_php".EXT );
        $buffer = ob_get_contents( );
        ob_end_clean( );
        echo $buffer;
    }

}

if ( defined( "BASEPATH" ) )
{
    exit( "No direct script access allowed" );
}
?>
