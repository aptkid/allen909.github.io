<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class TD_Router
{

    public $config;
    public $routes = array( );
    public $error_routes = array( );
    public $class = "";
    public $method = "index";
    public $directory = "";
    public $uri_protocol = "auto";
    public $default_controller;
    public $scaffolding_request = FALSE;

    public function TD_Router( )
    {
        $this->config =& load_class( "Config" );
        $this->uri =& load_class( "URI" );
        $this->_set_routing( );
        log_message( "debug", "Router Class Initialized" );
    }

    public function _set_routing( )
    {
        if ( $this->config->item( "enable_query_strings" ) === TRUE && isset( $_GET[$this->config->item( "controller_trigger" )] ) )
        {
            trim( $this->config->item( "controller_trigger" )( $_GET[$this->config->item( "controller_trigger" )] ) )( trim( $this->config->item( "controller_trigger" )( $_GET[$this->config->item( "controller_trigger" )] ) ) );
            if ( isset( $_GET[$this->config->item( "function_trigger" )] ) )
            {
                trim( $this->config->item( "function_trigger" )( $_GET[$this->config->item( "function_trigger" )] ) )( trim( $this->config->item( "function_trigger" )( $_GET[$this->config->item( "function_trigger" )] ) ) );
            }
        }
        else
        {
            @include( APPPATH."config/routes".@EXT );
            $this->routes = !!isset( $route ) || !is_array( $route ) ? array( ) : $route;
            unset( $route );
            $this->default_controller = !isset( $this->routes['default_controller'] ) || $this->routes['default_controller'] == "" ? FALSE : strtolower( $this->routes['default_controller'] );
            $this->uri->_fetch_uri_string( );
            if ( $this->uri->uri_string == "" )
            {
                if ( $this->default_controller === FALSE )
                {
                    show_error( "Unable to determine what should be displayed. A default route has not been specified in the routing file." );
                }
                if ( strpos( $this->default_controller, "/" ) !== FALSE )
                {
                    $x = explode( "/", $this->default_controller );
                    end( &$x )( end( &$x ) );
                    $this->set_method( "index" );
                    $this->_set_request( $x );
                }
                else
                {
                    $this->default_controller( $this->default_controller );
                    $this->set_method( "index" );
                    $this->_set_request( array( $this->default_controller, "index" ) );
                }
                $this->uri->_reindex_segments( );
                log_message( "debug", "No URI present. Default controller set." );
            }
            else
            {
                unset( $this->uri['default_controller'] );
                $this->uri->_remove_url_suffix( );
                $this->uri->_explode_segments( );
                $this->_parse_routes( );
                $this->uri->_reindex_segments( );
            }
        }
    }

    public function _set_request( $segments = array( ) )
    {
        $segments = $this->_validate_request( $segments );
        if ( count( $segments ) == 0 )
        {
        }
        else
        {
            $segments[0]( $segments[0] );
            if ( isset( $segments[1] ) )
            {
                $segments[1]( $segments[1] );
            }
            else
            {
                $segments[1] = "index";
            }
            $this->uri->rsegments = $segments;
        }
    }

    public function _validate_request( $segments )
    {
        if ( file_exists( APPPATH."controllers/".$segments[0].EXT ) )
        {
            return $segments;
        }
        if ( is_dir( APPPATH."controllers/".$segments[0] ) )
        {
            $segments[0]( $segments[0] );
            $segments = array_slice( $segments, 1 );
            if ( 0 < count( $segments ) )
            {
                if ( file_exists( APPPATH."controllers/".$this->fetch_directory( ).$segments[0].EXT ) )
                {
                    show_404( $this->fetch_directory( ).$segments[0] );
                    return $segments;
                }
            }
            $this->default_controller( $this->default_controller );
            $this->set_method( "index" );
            if ( file_exists( APPPATH."controllers/".$this->fetch_directory( ).$this->default_controller.EXT ) )
            {
                $this->directory = "";
                return array( );
            }
            return $segments;
        }
        show_404( $segments[0] );
    }

    public function _parse_routes( )
    {
        if ( count( $this->routes ) == 1 )
        {
            $this->uri->segments( $this->uri->segments );
        }
        else
        {
            $uri = implode( "/", $this->uri->segments );
            if ( isset( $this->routes[$uri] ) )
            {
                explode( "/", $this->routes[$uri] )( explode( "/", $this->routes[$uri] ) );
            }
            else
            {
                foreach ( $this->routes as $key => $val )
                {
                    $key = str_replace( ":any", ".+", str_replace( ":num", "[0-9]+", $key ) );
                    if ( preg_match( "#^".$key."$#", $uri ) )
                    {
                        if ( strpos( $val, "\$" ) !== FALSE && strpos( $key, "(" ) !== FALSE )
                        {
                            $val = preg_replace( "#^".$key."$#", $val, $uri );
                        }
                        explode( "/", $val )( explode( "/", $val ) );
                        return;
                        break;
                    }
                }
                $this->uri->segments( $this->uri->segments );
            }
        }
    }

    public function set_class( $class )
    {
        $this->class = $class;
    }

    public function fetch_class( )
    {
        return $this->class;
    }

    public function set_method( $method )
    {
        $this->method = $method;
    }

    public function fetch_method( )
    {
        if ( $this->method == $this->fetch_class( ) )
        {
            return "index";
        }
        return $this->method;
    }

    public function set_directory( $dir )
    {
        $this->directory = $dir."/";
    }

    public function fetch_directory( )
    {
        return $this->directory;
    }

}

if ( defined( "BASEPATH" ) )
{
    exit( "No direct script access allowed" );
}
?>
