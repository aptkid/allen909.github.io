<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class TD_Database
{

    public $username;
    public $password;
    public $hostname;
    public $database;
    public $dbdriver = "mysql";
    public $dbprefix = "";
    public $char_set = "gbk";
    public $dbcollat = "gbk_chinese_ci";
    public $autoinit = TRUE;
    public $swap_pre = "";
    public $port = "";
    public $pconnect = TRUE;
    public $conn_id = FALSE;
    public $master_conn_id = FALSE;
    public $slave_conn_id = FALSE;
    public $result_id = FALSE;
    public $db_debug = FALSE;
    public $benchmark = 0;
    public $query_count = 0;
    public $bind_marker = "?";
    public $save_queries = TRUE;
    public $queries = array( );
    public $query_times = array( );
    public $_escape_char = "`";
    public $_like_escape_str = "";
    public $_like_escape_chr = "";
    public $delete_hack = TRUE;
    public $_count_string = "SELECT COUNT(*) AS ";
    public $_random_keyword = " RAND()";

    public function TD_Database( $params )
    {
        $this->char_set = MYOA_CHARSET;
        if ( $this->char_set == "utf-8" )
        {
            $this->char_set = "utf8";
        }
        else if ( $this->char_set == "gb2312" )
        {
            $this->char_set = "gbk";
        }
        if ( $this->char_set == "gbk" )
        {
            $this->dbcollat = "gbk_chinese_ci";
        }
        else if ( $this->char_set == "utf8" )
        {
            $this->dbcollat = "utf8_general_ci";
        }
        else
        {
            $this->dbcollat = "latin1_bin";
        }
        if ( is_array( $params ) )
        {
            foreach ( $params as $key => $val )
            {
                $this->$key = $val;
            }
        }
        $this->_initialize( );
        log_message( "debug", _( "��ʼ�����ݿ�" ) );
    }

    public function _initialize( )
    {
        if ( ( is_resource( $this->conn_id ) || is_object( $this->conn_id ) ) && ( is_resource( $this->master_conn_id ) || is_object( $this->master_conn_id ) ) )
        {
            return TRUE;
        }
        if ( function_exists( "mysql_pconnect" ) )
        {
            log_message( "error", _( "PHP�������󣬲��ܵ���Mysql�����⣬�����й����ã�" ) );
            return FALSE;
        }
        $this->conn_id = !$this->pconnect ? $this->db_connect( ) : $this->db_pconnect( );
        if ( $this->conn_id )
        {
            log_message( "error", _( "�������ӵ�MySQL���ݿ⣬���飺1��MySQL�����Ƿ�������2��MySQL������ǽ��ֹ��3������MySQL���û����������Ƿ���ȷ��" ) );
            return FALSE;
        }
        if ( $this->database != "" )
        {
            if ( $this->db_select( ) )
            {
                log_message( "error", sprintf( _( "���ݿ�: %s ������" ), $this->database ) );
                return FALSE;
            }
            if ( $this->dbcollat( $this->char_set, $this->dbcollat ) )
            {
                return FALSE;
            }
            return TRUE;
        }
        return TRUE;
    }

    public function db_set_charset( $charset, $collation )
    {
        if ( @db_query( @"SET NAMES '".@$this->escape_str( $charset )."' COLLATE '".@$this->escape_str( $collation )."'", @$this->conn_id ) )
        {
            log_message( "error", _( "�޷��������ݿ��ַ���: " ).$this->char_set );
            return FALSE;
        }
        return TRUE;
    }

    public function db_connect( )
    {
        if ( $this->port != "" )
        {
            $ && _33700248 .= "hostname";
        }
        return mysql_connect( @$this->hostname, @$this->username, @$this->password, TRUE );
    }

    public function db_pconnect( )
    {
        if ( $this->port != "" )
        {
            $ && _72152704 .= "hostname";
        }
        return mysql_pconnect( @$this->hostname, @$this->username, @$this->password );
    }

    public function reconnect( )
    {
        if ( mysql_ping( $this->conn_id ) === FALSE )
        {
            $this->conn_id = FALSE;
        }
    }

    public function db_select( )
    {
        return mysql_select_db( @$this->database, @$this->conn_id );
    }

    public function _version( )
    {
        return "SELECT version() AS ver";
    }

    public function tomasterdb( )
    {
        global $db_config;
        $this->username = $db_config['username'];
        $this->hostname = $db_config['hostname'];
        $this->password = $db_config['password'];
        $this->database = $db_config['database'];
        $this->char_set = $db_config['char_set'];
        $this->slave_conn_id = $this->conn_id;
        $this->_initialize( );
        $this->master_conn_id = $this->conn_id;
    }

    public function query( $sql, $binds = FALSE, $return_object = TRUE, $QUERY_MASTER = FALSE )
    {
        if ( MYOA_DB_USE_REPLICATION && ( $QUERY_MASTER || strtolower( substr( ltrim( $sql ), 0, 6 ) ) != "select" && strtolower( substr( ltrim( $sql ), 0, 3 ) ) != "set" ) )
        {
            if ( is_resource( $this->master_conn_id ) )
            {
                $this->tomasterdb( );
            }
            $this->conn_id = $this->master_conn_id;
        }
        else if ( is_resource( $this->slave_conn_id ) )
        {
            $this->conn_id = $this->slave_conn_id;
        }
        if ( $binds !== FALSE )
        {
            $sql = $this->compile_binds( $sql, $binds );
        }
        if ( $this->save_queries )
        {
            $this->queries[] = $sql;
        }
        list( $sm, $ss ) = explode( " ", microtime( ) );
        $time_start = explode( " ", microtime( ) );
        if ( FALSE === $this->result_id = $this->_execute( $sql ) )
        {
            if ( $this->save_queries )
            {
                $this->query_times[] = 0;
            }
            $this->display_error( );
            return FALSE;
        }
        $es = explode( " ", microtime( ) )[1];
        $em = explode( " ", microtime( ) )[0];
        $time_end = explode( " ", microtime( ) );
        $ && _33590264 += "benchmark";
        if ( $this->save_queries )
        {
            $this->query_times[] = $em + $es - ( $sm + $ss );
        }
        $this->query_count++;
        if ( $return_object !== TRUE )
        {
            return TRUE;
        }
        $RES = new TD_Database_result( );
        $RES->conn_id = $this->conn_id;
        $RES->result_id = $this->result_id;
        return $RES;
    }

    public function compile_binds( $sql, $binds )
    {
        if ( strpos( $sql, $this->bind_marker ) === FALSE )
        {
            return $sql;
        }
        if ( is_array( $binds ) )
        {
            $binds = array( $binds );
        }
        $segments = explode( $this->bind_marker, $sql );
        if ( count( $segments ) <= count( $binds ) )
        {
            $binds = array_slice( $binds, 0, count( $segments ) - 1 );
        }
        $result = $segments[0];
        $i = 0;
        foreach ( $binds as $bind )
        {
            $result .= $this->escape( $bind );
            $result .= $segments[++$i];
        }
        return $result;
    }

    public function _execute( $sql )
    {
        $sql = $this->_prep_query( $sql );
        return db_query( $sql, $this->conn_id );
    }

    public function _prep_query( $sql )
    {
        if ( $this->delete_hack === TRUE && preg_match( "/^\\s*DELETE\\s+FROM\\s+(\\S+)\\s*$/i", $sql ) )
        {
            $sql = preg_replace( "/^\\s*DELETE\\s+FROM\\s+(\\S+)\\s*$/", "DELETE FROM \\1 WHERE 1=1", $sql );
        }
        return $sql;
    }

    public function trans_begin( $test_mode = FALSE )
    {
        if ( $this->trans_enabled )
        {
            return TRUE;
        }
        if ( 0 < $this->_trans_depth )
        {
            return TRUE;
        }
        $this->_trans_failure = $test_mode === TRUE ? TRUE : FALSE;
        $this->simple_query( "SET AUTOCOMMIT=0" );
        $this->simple_query( "START TRANSACTION" );
        return TRUE;
    }

    public function trans_commit( )
    {
        if ( $this->trans_enabled )
        {
            return TRUE;
        }
        if ( 0 < $this->_trans_depth )
        {
            return TRUE;
        }
        $this->simple_query( "COMMIT" );
        $this->simple_query( "SET AUTOCOMMIT=1" );
        return TRUE;
    }

    public function trans_rollback( )
    {
        if ( $this->trans_enabled )
        {
            return TRUE;
        }
        if ( 0 < $this->_trans_depth )
        {
            return TRUE;
        }
        $this->simple_query( "ROLLBACK" );
        $this->simple_query( "SET AUTOCOMMIT=1" );
        return TRUE;
    }

    public function escape_str( $str, $like = FALSE )
    {
        if ( is_array( $str ) )
        {
            foreach ( $str as $key => $val )
            {
                $str[$key] = $this->escape_str( $val, $like );
            }
            return $str;
        }
        if ( function_exists( "mysql_real_escape_string" ) && is_resource( $this->conn_id ) )
        {
            $str = mysql_real_escape_string( $str, $this->conn_id );
        }
        else if ( function_exists( "mysql_escape_string" ) )
        {
            $str = mysql_escape_string( $str );
        }
        else
        {
            $str = addslashes( $str );
        }
        if ( $like === TRUE )
        {
            $str = str_replace( array( "%", "_" ), array( "\\%", "\\_" ), $str );
        }
        return $str;
    }

    public function affected_rows( )
    {
        return mysql_affected_rows( @$this->conn_id );
    }

    public function insert_id( )
    {
        return mysql_insert_id( @$this->conn_id );
    }

    public function count_all( $table = "" )
    {
        if ( $table == "" )
        {
            return 0;
        }
        $query = $this->_count_string( $this->_count_string.$this->_protect_identifiers( "numrows" )." FROM ".$this->_protect_identifiers( $table, TRUE, NULL, FALSE ) );
        if ( $query->num_rows( ) == 0 )
        {
            return 0;
        }
        $row = $query->row( );
        return ( integer );
    }

    public function _list_tables( $prefix_limit = FALSE )
    {
        $sql = "SHOW TABLES FROM ".$this->_escape_char.$this->database.$this->_escape_char;
        if ( $prefix_limit !== FALSE && $this->dbprefix != "" )
        {
            $sql .= " LIKE '".$this->dbprefix( $this->dbprefix )."%'";
        }
        return $sql;
    }

    public function _list_columns( $table = "" )
    {
        return "SHOW COLUMNS FROM ".$table;
    }

    public function _field_data( $table )
    {
        return "SELECT * FROM ".$table." LIMIT 1";
    }

    public function _error_message( )
    {
        return mysql_error( $this->conn_id );
    }

    public function _error_number( )
    {
        return mysql_errno( $this->conn_id );
    }

    public function _escape_identifiers( $item )
    {
        if ( $this->_escape_char == "" )
        {
            return $item;
        }
        foreach ( $this->_reserved_identifiers as $id )
        {
            if ( strpos( $item, ".".$id ) !== FALSE )
            {
                $str = $this->_escape_char.str_replace( ".", $this->_escape_char.".", $item );
                return preg_replace( "/[".$this->_escape_char."]+/", $this->_escape_char, $str );
                break;
            }
        }
        if ( strpos( $item, "." ) !== FALSE )
        {
            $str = $this->_escape_char.str_replace( ".", $this->_escape_char.".".$this->_escape_char, $item ).$this->_escape_char;
        }
        else
        {
            $str = $this->_escape_char.$item.$this->_escape_char;
        }
        return preg_replace( "/[".$this->_escape_char."]+/", $this->_escape_char, $str );
    }

    public function _from_tables( $tables )
    {
        if ( is_array( $tables ) )
        {
            $tables = array( $tables );
        }
        return "(".implode( ", ", $tables ).")";
    }

    public function _insert( $table, $keys, $values )
    {
        return "INSERT INTO ".$table." (".implode( ", ", $keys ).") VALUES (".implode( ", ", $values ).")";
    }

    public function _update( $table, $values, $where, $orderby = array( ), $limit = FALSE )
    {
        foreach ( $values as $key => $val )
        {
            $valstr[] = $key." = ".$val;
        }
        $limit = !$limit ? "" : " LIMIT ".$limit;
        $orderby = 1 <= count( $orderby ) ? " ORDER BY ".implode( ", ", $orderby ) : "";
        $sql = "UPDATE ".$table." SET ".implode( ", ", $valstr );
        $sql .= $where != "" || 1 <= count( $where ) ? " WHERE ".implode( " ", $where ) : "";
        $sql .= $orderby.$limit;
        return $sql;
    }

    public function _truncate( $table )
    {
        return "TRUNCATE ".$table;
    }

    public function _delete( $table, $where = array( ), $like = array( ), $limit = FALSE )
    {
        $conditions = "";
        if ( 0 < count( $where ) || 0 < count( $like ) )
        {
            $conditions = "\nWHERE ";
            $conditions .= implode( "\n", $this->ar_where );
            if ( 0 < count( $where ) && 0 < count( $like ) )
            {
                $conditions .= " AND ";
            }
            $conditions .= implode( "\n", $like );
        }
        $limit = !$limit ? "" : " LIMIT ".$limit;
        return "DELETE FROM ".$table.$conditions.$limit;
    }

    public function _limit( $sql, $limit, $offset )
    {
        if ( $offset == 0 )
        {
            $offset = "";
        }
        else
        {
            $offset .= ", ";
        }
        return $sql."LIMIT ".$offset.$limit;
    }

    public function display_error( )
    {
        $message = "<b>#".$this->_error_number( ).":</b> ".$this->_error_message( )."<br>";
        if ( mysql_errno( ) == 1030 )
        {
            $message .= "<br>"._( "����ϵ����Ա�� ϵͳ����-���ݿ���� ���޸����ݿ�����" );
        }
        $error =& load_class( "Exceptions" );
        echo _( "SQL���ִ�д���" )( _( "SQL���ִ�д���" ), $message, "error_db" );
        exit( );
    }

    public function _close( $conn_id )
    {
        @mysql_close( $conn_id );
    }

}

class TD_Database_result
{

    public $conn_id;
    public $result_id;
    public $result_array = array( );
    public $result_object = array( );
    public $current_row = 0;
    public $num_rows = 0;
    public $row_data;

    public function result( $type = "object" )
    {
        if ( $type == "object" )
        {
            return $this->result_object( );
        }
        return $this->result_array( );
    }

    public function result_object( )
    {
        if ( 0 < count( $this->result_object ) )
        {
            return $this->result_object;
        }
        if ( $this->result_id === FALSE || $this->num_rows( ) == 0 )
        {
            return array( );
        }
        $this->_data_seek( 0 );
        while ( $row = $this->_fetch_object( ) )
        {
            $this->result_object[] = $row;
        }
        return $this->result_object;
    }

    public function result_array( )
    {
        if ( 0 < count( $this->result_array ) )
        {
            return $this->result_array;
        }
        if ( $this->result_id === FALSE || $this->num_rows( ) == 0 )
        {
            return array( );
        }
        $this->_data_seek( 0 );
        while ( $row = $this->_fetch_assoc( ) )
        {
            $this->result_array[] = $row;
        }
        return $this->result_array;
    }

    public function row( $n = 0, $type = "object" )
    {
        if ( is_numeric( $n ) )
        {
            if ( is_array( $this->row_data ) )
            {
                $this->row_data = $this->row_array( 0 );
            }
            if ( array_key_exists( $n, $this->row_data ) )
            {
                return $this->row_data[$n];
            }
            $n = 0;
        }
        if ( $type == "object" )
        {
            return $this->row_object( $n );
        }
        return $this->row_array( $n );
    }

    public function set_row( $key, $value = NULL )
    {
        if ( is_array( $this->row_data ) )
        {
            $this->row_data = $this->row_array( 0 );
        }
        if ( is_array( $key ) )
        {
            foreach ( $key as $k => $v )
            {
                $this->row_data[$k] = $v;
            }
        }
        else
        {
            if ( $key != "" && !is_null( $value ) )
            {
                $this->row_data[$key] = $value;
            }
        }
    }

    public function row_object( $n = 0 )
    {
        $result = $this->result_object( );
        if ( count( $result ) == 0 )
        {
            return $result;
        }
        if ( $n != $this->current_row && isset( $result[$n] ) )
        {
            $this->current_row = $n;
        }
        return $result[$this->current_row];
    }

    public function row_array( $n = 0 )
    {
        $result = $this->result_array( );
        if ( count( $result ) == 0 )
        {
            return $result;
        }
        if ( $n != $this->current_row && isset( $result[$n] ) )
        {
            $this->current_row = $n;
        }
        return $result[$this->current_row];
    }

    public function first_row( $type = "object" )
    {
        $result = $this->result( $type );
        if ( count( $result ) == 0 )
        {
            return $result;
        }
        return $result[0];
    }

    public function last_row( $type = "object" )
    {
        $result = $this->result( $type );
        if ( count( $result ) == 0 )
        {
            return $result;
        }
        return $result[count( $result ) - 1];
    }

    public function next_row( $type = "object" )
    {
        $result = $this->result( $type );
        if ( count( $result ) == 0 )
        {
            return $result;
        }
        if ( isset( $result[$this->current_row + 1] ) )
        {
            ++$this->current_row;
        }
        return $result[$this->current_row];
    }

    public function previous_row( $type = "object" )
    {
        $result = $this->result( $type );
        if ( count( $result ) == 0 )
        {
            return $result;
        }
        if ( isset( $result[$this->current_row - 1] ) )
        {
            --$this->current_row;
        }
        return $result[$this->current_row];
    }

    public function num_rows( )
    {
        return mysql_num_rows( @$this->result_id );
    }

    public function num_fields( )
    {
        return mysql_num_fields( @$this->result_id );
    }

    public function list_fields( )
    {
        $field_names = array( );
        while ( $field = mysql_fetch_field( $this->result_id ) )
        {
            $field_names[] = $field->name;
        }
        return $field_names;
    }

    public function field_data( )
    {
        $retval = array( );
        while ( $field = mysql_fetch_field( $this->result_id ) )
        {
            $F = new stdClass( );
            $F->name = $field->name;
            $F->type = $field->type;
            $F->default = $field->def;
            $F->max_length = $field->max_length;
            $F->primary_key = $field->primary_key;
            $retval[] = $F;
        }
        return $retval;
    }

    public function free_result( )
    {
        if ( is_resource( $this->result_id ) )
        {
            mysql_free_result( $this->result_id );
            $this->result_id = FALSE;
        }
    }

    public function _data_seek( $n = 0 )
    {
        return mysql_data_seek( $this->result_id, $n );
    }

    public function _fetch_assoc( )
    {
        return mysql_fetch_assoc( $this->result_id );
    }

    public function _fetch_object( )
    {
        return mysql_fetch_object( $this->result_id );
    }

}

if ( defined( "BASEPATH" ) )
{
    exit( "No direct script access allowed" );
}
include_once( "inc/conn.php" );
?>
