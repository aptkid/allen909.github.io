<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
if ( defined( "BASEPATH" ) )
{
    exit( "No direct script access allowed" );
}
define( "TD_VERSION", "0.0.1" );
require( BASEPATH."core/Common".EXT );
$CFG =& load_class( "Config" );
$URI =& load_class( "URI" );
$RTR =& load_class( "Router" );
$IN =& load_class( "Input" );
load_class( "Base", FALSE );
load_class( "Controller", FALSE );
if ( file_exists( APPPATH."controllers/".$RTR->fetch_directory( ).$RTR->fetch_class( ).EXT ) )
{
    show_error( "����Ŀ����������ڣ�" );
}
include( APPPATH."controllers/".$RTR->fetch_directory( ).$RTR->fetch_class( ).EXT );
$class = $RTR->fetch_class( );
$method = $RTR->fetch_method( );
if ( !class_exists( $class ) || $method == "controller" || strncmp( $method, "_", 1 ) == 0 || in_array( strtolower( $method ), array_map( "strtolower", get_class_methods( "Controller" ) ) ) )
{
    show_404( "{$class}/{$method}" );
}
$TD = new $class( );
if ( in_array( strtolower( $method ), array_map( "strtolower", get_class_methods( $TD ) ) ) )
{
    show_404( "{$class}/{$method}" );
}
$db_config['hostname'] = $MYOA_MASTER_DB['host'];
$db_config['username'] = $MYOA_MASTER_DB['user'];
$db_config['password'] = $MYOA_MASTER_DB['pwd'];
$db_config['database'] = $MYOA_MASTER_DB['db'];
$db_config['char_set'] = MYOA_DB_CHARSET;
$slave_db_config['hostname'] = MYOA_DB_USE_REPLICATION ? $MYOA_SLAVE_DB[0]['host'] : $MYOA_MASTER_DB['host'];
$slave_db_config['username'] = MYOA_DB_USE_REPLICATION ? $MYOA_SLAVE_DB[0]['user'] : $MYOA_MASTER_DB['user'];
$slave_db_config['password'] = MYOA_DB_USE_REPLICATION ? $MYOA_SLAVE_DB[0]['pwd'] : $MYOA_MASTER_DB['pwd'];
$slave_db_config['database'] = MYOA_DB_USE_REPLICATION ? $MYOA_SLAVE_DB[0]['db'] : $MYOA_MASTER_DB['db'];
$slave_db_config['char_set'] = MYOA_DB_CHARSET;
$TD->load->database( $slave_db_config );
include_once( "inc/session.php" );
ob_end_clean( );
session_start( );
if ( 0 < MYOA_OFFLINE_TIME_MIN )
{
    $LAST_OPERATION_TIME = $_COOKIE['LAST_OPERATION_TIME'];
    if ( $LAST_OPERATION_TIME != "" && MYOA_OFFLINE_TIME_MIN * 60 < time( ) - $LAST_OPERATION_TIME )
    {
        $query = "delete from USER_ONLINE where SID='".session_id( )."'";
        exequery( ( ), $query );
        clear_online_status( );
        session_unset( );
        session_destroy( );
    }
}
session_write_close( );
$SCRIPT_NAME = $_SERVER['REQUEST_URI'];
$SAFE_CHECK_OK = 0;
if ( stristr( $SCRIPT_NAME, "/general" ) )
{
    $SAFE_CHECK_OK = 1;
}
else
{
    $SCRIPT_NAME = substr( $SCRIPT_NAME, 9 );
    $SCRIPT_NAME = ltrim( $SCRIPT_NAME, "/" );
    $FUNCTION_ARRAY = ( "SYS_FUNCTION_".bin2hex( MYOA_LANG_COOKIE ) );
    do
    {
        $FUNC_CODE = each( &$FUNCTION_ARRAY )[1];
        $FUNC_ID = each( &$FUNCTION_ARRAY )[0];
        if ( each( &$FUNCTION_ARRAY ) )
        {
        }
    } while ( !( substr( $SCRIPT_NAME, 0, strlen( $FUNC_CODE ) ) == $FUNC_CODE ) || !in_array( $FUNC_ID, explode( ",", $_SESSION['LOGIN_FUNC_STR'] ) ) );
    $SAFE_CHECK_OK = 1;
}
if ( $SAFE_CHECK_OK == 0 )
{
    show_error( _( "�޸�ģ��ʹ��Ȩ�ޣ�����ʹ�ø�ģ�飬����ϵ����Ա�������ñ���ɫȨ�ޣ�" ) );
}
call_user_func_array( array( $TD, $method ), array_slice( $URI->rsegments, 2 ) );
?>
