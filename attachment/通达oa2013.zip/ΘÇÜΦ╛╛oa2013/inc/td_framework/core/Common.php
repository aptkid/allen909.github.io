<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
function &load_class( $class, $instantiate = TRUE )
{
    static $objects = array( );
    if ( isset( $objects[$class] ) )
    {
        return $objects[$class];
    }
    if ( file_exists( APPPATH."libraries/".$class.EXT ) )
    {
        require( APPPATH."libraries/".$class.EXT );
        $is_subclass = FALSE;
    }
    else
    {
        require( BASEPATH."libraries/".$class.EXT );
        $is_subclass = FALSE;
    }
    if ( $instantiate )
    {
        $objects[$class] = TRUE;
        return $objects[$class];
    }
    $name = $class != "Controller" ? "TD_".$class : $class;
    $objects[$class] =& instantiate_class( new $name( ) );
    return $objects[$class];
}

function &instantiate_class( &$class_object )
{
    return $class_object;
}

function &get_config( )
{
    static $main_conf = NULL;
    if ( isset( $main_conf ) )
    {
        if ( file_exists( APPPATH."config/config".EXT ) )
        {
            exit( "�����ļ�������!" );
        }
        require( APPPATH."config/config".EXT );
        if ( !isset( $config ) || !is_array( $config ) )
        {
            exit( "�����ļ���ʽ����!" );
        }
        $main_conf[0] =& $config;
    }
    return $main_conf[0];
}

function set_status_header( $code = 200, $text = "" )
{
    $stati = array( 200 => "OK", 201 => "Created", 202 => "Accepted", 203 => "Non-Authoritative Information", 204 => "No Content", 205 => "Reset Content", 206 => "Partial Content", 300 => "Multiple Choices", 301 => "Moved Permanently", 302 => "Found", 304 => "Not Modified", 305 => "Use Proxy", 307 => "Temporary Redirect", 400 => "Bad Request", 401 => "Unauthorized", 403 => "Forbidden", 404 => "Not Found", 405 => "Method Not Allowed", 406 => "Not Acceptable", 407 => "Proxy Authentication Required", 408 => "Request Timeout", 409 => "Conflict", 410 => "Gone", 411 => "Length Required", 412 => "Precondition Failed", 413 => "Request Entity Too Large", 414 => "Request-URI Too Long", 415 => "Unsupported Media Type", 416 => "Requested Range Not Satisfiable", 417 => "Expectation Failed", 500 => "Internal Server Error", 501 => "Not Implemented", 502 => "Bad Gateway", 503 => "Service Unavailable", 504 => "Gateway Timeout", 505 => "HTTP Version Not Supported" );
    if ( $code == "" || !is_numeric( $code ) )
    {
        show_error( "Status codes must be numeric", 500 );
    }
    if ( isset( $stati[$code] ) && $text == "" )
    {
        $text = $stati[$code];
    }
    if ( $text == "" )
    {
        show_error( "No status text available.  Please check your status code number or supply your own message text.", 500 );
    }
    $server_protocol = isset( $_SERVER['SERVER_PROTOCOL'] ) ? $_SERVER['SERVER_PROTOCOL'] : FALSE;
    if ( substr( php_sapi_name( ), 0, 3 ) == "cgi" )
    {
        header( "Status: ".$code." {$text}", TRUE );
    }
    else if ( $server_protocol == "HTTP/1.1" || $server_protocol == "HTTP/1.0" )
    {
        header( $server_protocol.( " ".$code." {$text}" ), TRUE, $code );
    }
    else
    {
        header( "HTTP/1.1 ".$code." {$text}", TRUE, $code );
    }
}

function show_error( $message, $status_code = 500 )
{
    $error =& load_class( "Exceptions" );
    echo $error->show_error( "An Error Was Encountered", $message, "error_general", $status_code );
    exit( );
}

function show_404( $page = "" )
{
    $error =& load_class( "Exceptions" );
    $error->show_404( $page );
    exit( );
}

function log_message( $level = "error", $message, $php_error = FALSE )
{
    static $LOG = NULL;
    $config =& get_config( );
    if ( $config['log_threshold'] == 0 )
    {
    }
    else
    {
        $LOG =& load_class( "Log" );
        $LOG->write_log( $level, $message, $php_error );
    }
}

if ( defined( "BASEPATH" ) )
{
    exit( "No direct script access allowed" );
}
?>
