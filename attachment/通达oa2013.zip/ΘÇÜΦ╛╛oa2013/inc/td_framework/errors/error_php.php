<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
echo "<div style=\"border:1px solid #990000;padding-left:20px;margin:0 0 10px 0;\">\n\n<h4>A PHP Error was encountered</h4>\n\n<p>Severity: ";
echo $severity;
echo "</p>\n<p>Message:  ";
echo $message;
echo "</p>\n<p>Filename: ";
echo $filepath;
echo "</p>\n<p>Line Number: ";
echo $line;
echo "</p>\n\n</div>";
?>
