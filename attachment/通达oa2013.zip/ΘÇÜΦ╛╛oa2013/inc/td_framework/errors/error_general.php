<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
include_once( "inc/header.inc.php" );
echo "<title>Error</title>\n<style type=\"text/css\">\n\nbody {\nbackground-color:\t#fff;\nmargin:\t\t\t\t40px;\nfont-family:\t\tLucida Grande, Verdana, Sans-serif;\nfont-size:\t\t\t12px;\ncolor:\t\t\t\t#000;\n}\n\n#content  {\nborder:\t\t\t\t#999 1px solid;\nbackground-color:\t#fff;\npadding:\t\t\t20px 20px 12px 20px;\n}\n\nh1 {\nfont-weight:\t\tnormal;\nfont-size:\t\t\t14px;\ncolor:\t\t\t\t#990000;\nmargin: \t\t\t0 0 4px 0;\n}\n</style>\n</head>\n<body>\n\t<div id=\"content\">\n\t\t<h1>";
echo $heading;
echo "</h1>\n\t\t";
echo $message;
echo "\t</div>\n</body>\n</html>";
?>
