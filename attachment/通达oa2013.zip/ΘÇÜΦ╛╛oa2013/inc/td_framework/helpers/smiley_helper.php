<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
if ( defined( "BASEPATH" ) )
{
    exit( "No direct script access allowed" );
}
if ( function_exists( "smiley_js" ) )
{
    function smiley_js( $alias = "", $field_id = "" )
    {
        static $do_setup = TRUE;
        $r = "";
        if ( $alias != "" && !is_array( $alias ) )
        {
            $alias = array( $alias => $field_id );
        }
        if ( $do_setup === TRUE )
        {
            $do_setup = FALSE;
            $m = array( );
            if ( is_array( $alias ) )
            {
                foreach ( $alias as $name => $id )
                {
                    $m[] = "\"".$name."\" : \"".$id."\"";
                }
            }
            $m = "{".implode( ",", $m )."}";
            $r .= "\t\t\t\n\t\t\t\tvar smiley_map = ".$m.";\n\n\t\t\t\tfunction insert_smiley(smiley, field_id) {\n\t\t\t\t\tvar el = document.getElementById(field_id), newStart;\n\t\t\t\t\n\t\t\t\t\tif ( ! el && smiley_map[field_id]) {\n\t\t\t\t\t\tel = document.getElementById(smiley_map[field_id]);\n\t\t\t\t\t\n\t\t\t\t\t\tif ( ! el)\n\t\t\t\t\t\t\treturn false;\n\t\t\t\t\t}\n\t\t\t\t\n\t\t\t\t\tel.focus();\n\t\t\t\t\tsmiley = \" \" + smiley;\n\n\t\t\t\t\tif ('selectionStart' in el) {\n\t\t\t\t\t\tnewStart = el.selectionStart + smiley.length;\n\n\t\t\t\t\t\tel.value = el.value.substr(0, el.selectionStart) +\n\t\t\t\t\t\t\t\t\t\tsmiley +\n\t\t\t\t\t\t\t\t\t\tel.value.substr(el.selectionEnd, el.value.length);\n\t\t\t\t\t\tel.setSelectionRange(newStart, newStart);\n\t\t\t\t\t}\n\t\t\t\t\telse if (document.selection) {\n\t\t\t\t\t\tdocument.selection.createRange().text = text;\n\t\t\t\t\t}\n\t\t\t\t}";
        }
        else if ( is_array( $alias ) )
        {
            foreach ( $alias as $name => $id )
            {
                $r .= "smiley_map[\"".$name."\"] = \"".$id."\";\n";
            }
        }
        return "<script type=\"text/javascript\" charset=\"utf-8\">".$r."</script>";
    }
}
if ( function_exists( "get_clickable_smileys" ) )
{
    function get_clickable_smileys( $image_url, $alias = "", $smileys = NULL )
    {
        if ( is_array( $alias ) )
        {
            $smileys = $alias;
        }
        if ( !is_array( $smileys ) && FALSE === ( $smileys = _get_smiley_array( ) ) )
        {
            return $smileys;
        }
        $image_url = rtrim( $image_url, "/" )."/";
        $used = array( );
        foreach ( $smileys as $key => $val )
        {
            if ( isset( $used[$smileys[$key][0]] ) )
            {
                $link[] = "<a href=\"javascript:void(0);\" onClick=\"insert_smiley('".$key."', '".$alias."')\"><img src=\"".$image_url.$smileys[$key][0]."\" width=\"".$smileys[$key][1]."\" height=\"".$smileys[$key][2]."\" alt=\"".$smileys[$key][3]."\" style=\"border:0;\" /></a>";
                $used[$smileys[$key][0]] = TRUE;
            }
        }
        return $link;
    }
}
if ( function_exists( "parse_smileys" ) )
{
    function parse_smileys( $str = "", $image_url = "", $smileys = NULL )
    {
        if ( $image_url == "" )
        {
            return $str;
        }
        if ( !is_array( $smileys ) && FALSE === ( $smileys = _get_smiley_array( ) ) )
        {
            return $str;
        }
        $image_url = preg_replace( "/(.+?)\\/*$/", "\\1/", $image_url );
        foreach ( $smileys as $key => $val )
        {
            $str = str_replace( $key, "<img src=\"".$image_url.$smileys[$key][0]."\" width=\"".$smileys[$key][1]."\" height=\"".$smileys[$key][2]."\" alt=\"".$smileys[$key][3]."\" style=\"border:0;\" />", $str );
        }
        return $str;
    }
}
if ( function_exists( "_get_smiley_array" ) )
{
    function _get_smiley_array( )
    {
        if ( file_exists( APPPATH."config/smileys".EXT ) )
        {
            return FALSE;
        }
        include( APPPATH."config/smileys".EXT );
        if ( !isset( $smileys ) || !is_array( $smileys ) )
        {
            return FALSE;
        }
        return $smileys;
    }
}
if ( function_exists( "js_insert_smiley" ) )
{
    function js_insert_smiley( $form_name = "", $form_field = "" )
    {
        return "<script type=\"text/javascript\">\n\tfunction insert_smiley(smiley)\n\t{\n\t\tdocument.".$form_name.".{$form_field}.value += \" \" + smiley;\n\t}\n</script>";
    }
}
?>
