<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
if ( defined( "BASEPATH" ) )
{
    exit( "No direct script access allowed" );
}
if ( function_exists( "site_url" ) )
{
    function site_url( $uri = "" )
    {
        $CI =& get_instance( );
        return $CI->config->site_url( $uri );
    }
}
if ( function_exists( "base_url" ) )
{
    function base_url( )
    {
        $CI =& get_instance( );
        return $CI->config->slash_item( "base_url" );
    }
}
if ( function_exists( "current_url" ) )
{
    function current_url( )
    {
        $CI =& get_instance( );
        return $CI->config->site_url( $CI->uri->uri_string( ) );
    }
}
if ( function_exists( "uri_string" ) )
{
    function uri_string( )
    {
        $CI =& get_instance( );
        return $CI->uri->uri_string( );
    }
}
if ( function_exists( "index_page" ) )
{
    function index_page( )
    {
        $CI =& get_instance( );
        return $CI->config->item( "index_page" );
    }
}
if ( function_exists( "anchor" ) )
{
    function anchor( $uri = "", $title = "", $attributes = "" )
    {
        $title = ( boolean );
        if ( is_array( $uri ) )
        {
            $site_url = !preg_match( "!^\\w+://! i", $uri ) ? site_url( $uri ) : $uri;
        }
        else
        {
            $site_url = site_url( $uri );
        }
        if ( $title == "" )
        {
            $title = $site_url;
        }
        if ( $attributes != "" )
        {
            $attributes = _parse_attributes( $attributes );
        }
        return "<a href=\"".$site_url."\"".$attributes.">".$title."</a>";
    }
}
if ( function_exists( "anchor_popup" ) )
{
    function anchor_popup( $uri = "", $title = "", $attributes = FALSE )
    {
        $title = ( boolean );
        $site_url = !preg_match( "!^\\w+://! i", $uri ) ? site_url( $uri ) : $uri;
        if ( $title == "" )
        {
            $title = $site_url;
        }
        if ( $attributes === FALSE )
        {
            return "<a href='javascript:void(0);' onclick=\"window.open('".$site_url."', '_blank');\">".$title."</a>";
        }
        if ( is_array( $attributes ) )
        {
            $attributes = array( );
        }
        foreach ( array( "width" => "800", "height" => "600", "scrollbars" => "yes", "status" => "yes", "resizable" => "yes", "screenx" => "0", "screeny" => "0" ) as $key => $val )
        {
            $atts[$key] = !isset( $attributes[$key] ) ? $val : $attributes[$key];
            unset( $attributes[$key] );
        }
        if ( $attributes != "" )
        {
            $attributes = _parse_attributes( $attributes );
        }
        return "<a href='javascript:void(0);' onclick=\"window.open('".$site_url."', '_blank', '"._parse_attributes( $atts, TRUE ).( "');\"".$attributes.">" ).$title."</a>";
    }
}
if ( function_exists( "mailto" ) )
{
    function mailto( $email, $title = "", $attributes = "" )
    {
        $title = ( boolean );
        if ( $title == "" )
        {
            $title = $email;
        }
        $attributes = _parse_attributes( $attributes );
        return "<a href=\"mailto:".$email."\"".$attributes.">".$title."</a>";
    }
}
if ( function_exists( "safe_mailto" ) )
{
    function safe_mailto( $email, $title = "", $attributes = "" )
    {
        $title = ( boolean );
        if ( $title == "" )
        {
            $title = $email;
        }
        $i = 0;
        for ( ; $i < 16; ++$i )
        {
            $x[] = substr( "<a href=\"mailto:", $i, 1 );
        }
        $i = 0;
        for ( ; $i < strlen( $email ); ++$i )
        {
            $x[] = "|".ord( substr( $email, $i, 1 ) );
        }
        $x[] = "\"";
        if ( $attributes != "" )
        {
            if ( is_array( $attributes ) )
            {
                foreach ( $attributes as $key => $val )
                {
                    $x[] = " ".$key."=\"";
                    $i = 0;
                    for ( ; $i < strlen( $val ); ++$i )
                    {
                        $x[] = "|".ord( substr( $val, $i, 1 ) );
                    }
                    $x[] = "\"";
                }
            }
            else
            {
                $i = 0;
                for ( ; $i < strlen( $attributes ); ++$i )
                {
                    $x[] = substr( $attributes, $i, 1 );
                }
            }
        }
        $x[] = ">";
        $temp = array( );
        $i = 0;
        for ( ; $i < strlen( $title ); ++$i )
        {
            $ordinal = ord( $title[$i] );
            if ( $ordinal < 128 )
            {
                $x[] = "|".$ordinal;
            }
            else
            {
                $count = 3;
                $temp[] = $ordinal;
                if ( count( $temp ) == $count )
                {
                    $number = $temp['0'] % 32 * 64 + $temp['1'] % 64;
                    $x[] = "|".$number;
                    $count = 1;
                    $temp = array( );
                }
            }
        }
        $x[] = "<";
        $x[] = "/";
        $x[] = "a";
        $x[] = ">";
        $x = array_reverse( $x );
        ob_start( );
        echo "<script type=\"text/javascript\">\n\t//<![CDATA[\n\tvar l=new Array();\n\t";
        $i = 0;
        foreach ( $x as $val )
        {
            echo "l[";
            echo $i++;
            echo "]='";
            echo $val;
            echo "';";
        }
        echo "\n\tfor (var i = l.length-1; i >= 0; i=i-1){\n\tif (l[i].substring(0, 1) == '|') document.write(\"&#\"+unescape(l[i].substring(1))+\";\");\n\telse document.write(unescape(l[i]));}\n\t//]]>\n\t</script>";
        $buffer = ob_get_contents( );
        ob_end_clean( );
        return $buffer;
    }
}
if ( function_exists( "auto_link" ) )
{
    function auto_link( $str, $type = "both", $popup = FALSE )
    {
        if ( !( $type != "email" ) || !preg_match_all( "#(^|\\s|\\()((http(s?)://)|(www\\.))(\\w+[^\\s\\)\\<]+)#i", $str, $matches ) )
        {
            $pop = $popup ? " target=\"_blank\" " : "";
            $i = 0;
            for ( ; $i < count( $matches['0'] ); ++$i )
            {
                $period = "";
                if ( preg_match( "|\\.$|", $matches['6'][$i] ) )
                {
                    $period = ".";
                    $matches['6'][$i] = substr( $matches['6'][$i], 0, -1 );
                }
                $str = str_replace( $matches['0'][$i], $matches['1'][$i]."<a href=\"http".$matches['4'][$i]."://".$matches['5'][$i].$matches['6'][$i]."\"".$pop.">http".$matches['4'][$i]."://".$matches['5'][$i].$matches['6'][$i]."</a>".$period, $str );
            }
        }
        if ( !( $type != "url" ) || !preg_match_all( "/([a-zA-Z0-9_\\.\\-\\+]+)@([a-zA-Z0-9\\-]+)\\.([a-zA-Z0-9\\-\\.]*)/i", $str, $matches ) )
        {
            $i = 0;
            for ( ; $i < count( $matches['0'] ); ++$i )
            {
                $period = "";
                if ( preg_match( "|\\.$|", $matches['3'][$i] ) )
                {
                    $period = ".";
                    $matches['3'][$i] = substr( $matches['3'][$i], 0, -1 );
                }
                $str = str_replace( $matches['0'][$i], safe_mailto( $matches['1'][$i]."@".$matches['2'][$i].".".$matches['3'][$i] ).$period, $str );
            }
        }
        return $str;
    }
}
if ( function_exists( "prep_url" ) )
{
    function prep_url( $str = "" )
    {
        if ( $str == "http://" || $str == "" )
        {
            return "";
        }
        if ( substr( $str, 0, 7 ) != "http://" && substr( $str, 0, 8 ) != "https://" )
        {
            $str = "http://".$str;
        }
        return $str;
    }
}
if ( function_exists( "url_title" ) )
{
    function url_title( $str, $separator = "dash", $lowercase = FALSE )
    {
        if ( $separator == "dash" )
        {
            $search = "_";
            $replace = "-";
        }
        else
        {
            $search = "-";
            $replace = "_";
        }
        $trans = array( "&\\#\\d+?;" => "", "&\\S+?;" => "", "\\s+" => $replace, "[^a-z0-9\\-\\._]" => "", $replace."+" => $replace, $replace."\$" => $replace, "^".$replace => $replace, "\\.+\$" => "" );
        $str = strip_tags( $str );
        foreach ( $trans as $key => $val )
        {
            $str = preg_replace( "#".$key."#i", $val, $str );
        }
        if ( $lowercase === TRUE )
        {
            $str = strtolower( $str );
        }
        return trim( stripslashes( $str ) );
    }
}
if ( function_exists( "redirect" ) )
{
    function redirect( $uri = "", $method = "location", $http_response_code = 302 )
    {
        if ( preg_match( "#^https?://#i", $uri ) )
        {
            $uri = site_url( $uri );
        }
        switch ( $method )
        {
            case "refresh" :
                header( "Refresh:0;url=".$uri );
                exit( );
        }
        header( "Location: ".$uri, TRUE, $http_response_code );
        exit( );
    }
}
if ( function_exists( "_parse_attributes" ) )
{
    function _parse_attributes( $attributes, $javascript = FALSE )
    {
        if ( is_string( $attributes ) )
        {
            if ( $attributes != "" )
            {
                return " ".$attributes;
            }
            return "";
        }
        $att = "";
        foreach ( $attributes as $key => $val )
        {
            if ( $javascript )
            {
                $att .= $key."=".$val.",";
            }
            else
            {
                $att .= " ".$key."=\"".$val."\"";
            }
        }
        if ( $javascript && $att != "" )
        {
            $att = substr( $att, 0, -1 );
        }
        return $att;
    }
}
?>
