<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
if ( defined( "BASEPATH" ) )
{
    exit( "No direct script access allowed" );
}
if ( function_exists( "word_limiter" ) )
{
    function word_limiter( $str, $limit = 100, $end_char = "&#8230;" )
    {
        if ( trim( $str ) == "" )
        {
            return $str;
        }
        preg_match( "/^\\s*+(?:\\S++\\s*+){1,".( integer )."}/", $str, $matches );
        if ( strlen( $str ) == strlen( $matches[0] ) )
        {
            $end_char = "";
        }
        return rtrim( $matches[0] ).$end_char;
    }
}
if ( function_exists( "character_limiter" ) )
{
    function character_limiter( $str, $n = 500, $end_char = "&#8230;" )
    {
        if ( strlen( $str ) < $n )
        {
            return $str;
        }
        $str = preg_replace( "/\\s+/", " ", str_replace( array( "\r\n", "\r", "\n" ), " ", $str ) );
        if ( strlen( $str ) <= $n )
        {
            return $str;
        }
        $out = "";
        foreach ( explode( " ", trim( $str ) ) as $val )
        {
            $out .= $val." ";
            if ( $n <= strlen( $out ) )
            {
                $out = trim( $out );
                return strlen( $out ) == strlen( $str ) ? $out : $out.$end_char;
                break;
            }
        }
    }
}
if ( function_exists( "ascii_to_entities" ) )
{
    function ascii_to_entities( $str )
    {
        $count = 1;
        $out = "";
        $temp = array( );
        $i = 0;
        $s = strlen( $str );
        for ( ; $i < $s; ++$i )
        {
            $ordinal = ord( $str[$i] );
            if ( $ordinal < 128 )
            {
                if ( count( $temp ) == 1 )
                {
                    $out .= "&#".array_shift( &$temp ).";";
                    $count = 1;
                }
                $out .= $str[$i];
            }
            else
            {
                $count = 3;
                $temp[] = $ordinal;
                if ( count( $temp ) == $count )
                {
                    $number = $temp['0'] % 32 * 64 + $temp['1'] % 64;
                    $out .= "&#".$number.";";
                    $count = 1;
                    $temp = array( );
                }
            }
        }
        return $out;
    }
}
if ( function_exists( "entities_to_ascii" ) )
{
    function entities_to_ascii( $str, $all = TRUE )
    {
        if ( preg_match_all( "/\\&#(\\d+)\\;/", $str, $matches ) )
        {
            $i = 0;
            $s = count( $matches['0'] );
            for ( ; $i < $s; ++$i )
            {
                $digits = $matches['1'][$i];
                $out = "";
                if ( $digits < 128 )
                {
                    $out .= chr( $digits );
                }
                else if ( $digits < 2048 )
                {
                    $out .= chr( 192 + ( $digits - $digits % 64 ) / 64 );
                    $out .= chr( 128 + $digits % 64 );
                }
                else
                {
                    $out .= chr( 224 + ( $digits - $digits % 4096 ) / 4096 );
                    $out .= chr( 128 + ( $digits % 4096 - $digits % 64 ) / 64 );
                    $out .= chr( 128 + $digits % 64 );
                }
                $str = str_replace( $matches['0'][$i], $out, $str );
            }
        }
        if ( $all )
        {
            $str = str_replace( array( "&amp;", "&lt;", "&gt;", "&quot;", "&apos;", "&#45;" ), array( "&", "<", ">", "\"", "'", "-" ), $str );
        }
        return $str;
    }
}
if ( function_exists( "word_censor" ) )
{
    function word_censor( $str, $censored, $replacement = "" )
    {
        if ( is_array( $censored ) )
        {
            return $str;
        }
        $str = " ".$str." ";
        $delim = "[-_'\\\"`(){}<>\\[\\]|!?@#%&,.:;^~*+=\\/ 0-9\\n\\r\\t]";
        foreach ( $censored as $badword )
        {
            if ( $replacement != "" )
            {
                $str = preg_replace( "/(".$delim.")(".str_replace( "\\*", "\\w*?", preg_quote( $badword, "/" ) ).( ")(".$delim.")/i" ), "\\1".$replacement."\\3", $str );
            }
            else
            {
                $str = preg_replace( "/(".$delim.")(".str_replace( "\\*", "\\w*?", preg_quote( $badword, "/" ) ).( ")(".$delim.")/ie" ), "'\\1'.str_repeat('#', strlen('\\2')).'\\3'", $str );
            }
        }
        return trim( $str );
    }
}
if ( function_exists( "highlight_code" ) )
{
    function highlight_code( $str )
    {
        $str = str_replace( array( "&lt;", "&gt;" ), array( "<", ">" ), $str );
        $str = str_replace( array( "<?", "?>", "<%", "%>", "\\", "</script>" ), array( "phptagopen", "phptagclose", "asptagopen", "asptagclose", "backslashtmp", "scriptclose" ), $str );
        $str = "<?php ".$str." ?>";
        $str = highlight_string( $str, TRUE );
        if ( abs( PHP_VERSION ) < 5 )
        {
            $str = str_replace( array( "<font ", "</font>" ), array( "<span ", "</span>" ), $str );
            $str = preg_replace( "#color=\"(.*?)\"#", "style=\"color: \\1\"", $str );
        }
        $str = preg_replace( "/<span style=\"color: #([A-Z0-9]+)\">&lt;\\?php(&nbsp;| )/i", "<span style=\"color: #$1\">", $str );
        $str = preg_replace( "/(<span style=\"color: #[A-Z0-9]+\">.*?)\\?&gt;<\\/span>\\n<\\/span>\\n<\\/code>/is", "$1</span>\n</span>\n</code>", $str );
        $str = preg_replace( "/<span style=\"color: #[A-Z0-9]+\"\\><\\/span>/i", "", $str );
        $str = str_replace( array( "phptagopen", "phptagclose", "asptagopen", "asptagclose", "backslashtmp", "scriptclose" ), array( "&lt;?", "?&gt;", "&lt;%", "%&gt;", "\\", "&lt;/script&gt;" ), $str );
        return $str;
    }
}
if ( function_exists( "highlight_phrase" ) )
{
    function highlight_phrase( $str, $phrase, $tag_open = "<strong>", $tag_close = "</strong>" )
    {
        if ( $str == "" )
        {
            return "";
        }
        if ( $phrase != "" )
        {
            return preg_replace( "/(".preg_quote( $phrase, "/" ).")/i", $tag_open."\\1".$tag_close, $str );
        }
        return $str;
    }
}
if ( function_exists( "word_wrap" ) )
{
    function word_wrap( $str, $charlim = "76" )
    {
        if ( is_numeric( $charlim ) )
        {
            $charlim = 76;
        }
        $str = preg_replace( "| +|", " ", $str );
        if ( strpos( $str, "\r" ) !== FALSE )
        {
            $str = str_replace( array( "\r\n", "\r" ), "\n", $str );
        }
        $unwrap = array( );
        if ( preg_match_all( "|(\\{unwrap\\}.+?\\{/unwrap\\})|s", $str, $matches ) )
        {
            $i = 0;
            for ( ; $i < count( $matches['0'] ); ++$i )
            {
                $unwrap[] = $matches['1'][$i];
                $str = str_replace( $matches['1'][$i], "{{unwrapped".$i."}}", $str );
            }
        }
        $str = wordwrap( $str, $charlim, "\n", FALSE );
        $output = "";
        foreach ( explode( "\n", $str ) as $line )
        {
            if ( strlen( $line ) <= $charlim )
            {
                $output .= $line."\n";
            }
            else
            {
                $temp = "";
                while ( !( $charlim < strlen( $line ) ) || preg_match( "!\\[url.+\\]|://|wwww.!", $line ) )
                {
                    $temp .= substr( $line, 0, $charlim - 1 );
                    $line = substr( $line, $charlim - 1 );
                }
                if ( $temp != "" )
                {
                    $output .= $temp."\n".$line;
                }
                else
                {
                    $output .= $line;
                }
                $output .= "\n";
            }
        }
        if ( 0 < count( $unwrap ) )
        {
            foreach ( $unwrap as $key => $val )
            {
                $output = str_replace( "{{unwrapped".$key."}}", $val, $output );
            }
        }
        $output = str_replace( array( "{unwrap}", "{/unwrap}" ), "", $output );
        return $output;
    }
}
?>
