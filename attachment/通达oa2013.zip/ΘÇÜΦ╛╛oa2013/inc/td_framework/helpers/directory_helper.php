<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
if ( defined( "BASEPATH" ) )
{
    exit( "No direct script access allowed" );
}
if ( function_exists( "directory_map" ) )
{
    function directory_map( $source_dir, $top_level_only = FALSE, $hidden = FALSE )
    {
        if ( $fp = @opendir( $source_dir ) )
        {
            $source_dir = rtrim( $source_dir, DIRECTORY_SEPARATOR ).DIRECTORY_SEPARATOR;
            $filedata = array( );
            while ( FALSE !== ( $file = readdir( $fp ) ) )
            {
                if ( !$hidden && strncmp( $file, ".", 1 ) == 0 || $file == "." )
                {
                }
                else
                {
                    continue;
                }
                if ( !$top_level_only && is_dir( @$source_dir.$file ) )
                {
                    $temp_array = array( );
                    $temp_array = directory_map( $source_dir.$file.DIRECTORY_SEPARATOR, $top_level_only, $hidden );
                    $filedata[$file] = $temp_array;
                }
                else
                {
                    $filedata[] = $file;
                }
            }
            closedir( $fp );
            return $filedata;
        }
        return FALSE;
    }
}
?>
