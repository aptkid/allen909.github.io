<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
if ( defined( "BASEPATH" ) )
{
    exit( "No direct script access allowed" );
}
if ( function_exists( "byte_format" ) )
{
    function byte_format( $num )
    {
        $CI =& get_instance( );
        $CI->lang->load( "number" );
        if ( 1e+012 <= $num )
        {
            $num = round( $num / 1.09951e+012, 1 );
            $unit = $CI->lang->line( "terabyte_abbr" );
        }
        else if ( 1000000000 <= $num )
        {
            $num = round( $num / 1073741824, 1 );
            $unit = $CI->lang->line( "gigabyte_abbr" );
        }
        else if ( 1000000 <= $num )
        {
            $num = round( $num / 1048576, 1 );
            $unit = $CI->lang->line( "megabyte_abbr" );
        }
        else if ( 1000 <= $num )
        {
            $num = round( $num / 1024, 1 );
            $unit = $CI->lang->line( "kilobyte_abbr" );
        }
        else
        {
            $unit = $CI->lang->line( "bytes" );
            return number_format( $num )." ".$unit;
        }
        return number_format( $num, 1 )." ".$unit;
    }
}
?>
