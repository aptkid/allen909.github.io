<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
if ( defined( "BASEPATH" ) )
{
    exit( "No direct script access allowed" );
}
if ( function_exists( "trim_slashes" ) )
{
    function trim_slashes( $str )
    {
        return trim( $str, "/" );
    }
}
if ( function_exists( "strip_slashes" ) )
{
    function strip_slashes( $str )
    {
        if ( is_array( $str ) )
        {
            foreach ( $str as $key => $val )
            {
                $str[$key] = strip_slashes( $val );
            }
            return $str;
        }
        $str = stripslashes( $str );
        return $str;
    }
}
if ( function_exists( "strip_quotes" ) )
{
    function strip_quotes( $str )
    {
        return str_replace( array( "\"", "'" ), "", $str );
    }
}
if ( function_exists( "quotes_to_entities" ) )
{
    function quotes_to_entities( $str )
    {
        return str_replace( array( "\\'", "\"", "'", "\"" ), array( "&#39;", "&quot;", "&#39;", "&quot;" ), $str );
    }
}
if ( function_exists( "reduce_double_slashes" ) )
{
    function reduce_double_slashes( $str )
    {
        return preg_replace( "#([^:])//+#", "\\1/", $str );
    }
}
if ( function_exists( "reduce_multiples" ) )
{
    function reduce_multiples( $str, $character = ",", $trim = FALSE )
    {
        $str = preg_replace( "#".preg_quote( $character, "#" )."{2,}#", $character, $str );
        if ( $trim === TRUE )
        {
            $str = trim( $str, $character );
        }
        return $str;
    }
}
if ( function_exists( "random_string" ) )
{
    function random_string( $type = "alnum", $len = 8 )
    {
        switch ( $type )
        {
            case "alnum" :
            case "numeric" :
            case "nozero" :
            case "alnum" :
                $pool = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
                break;
            case "numeric" :
                $pool = "0123456789";
                break;
            case "nozero" :
                $pool = "123456789";
        }
        $str = "";
        $i = 0;
        for ( ; $i < $len; ++$i )
        {
            $str .= substr( $pool, mt_rand( 0, strlen( $pool ) - 1 ), 1 );
        }
        return $str;
        switch ( $type )
        {
            case "unique" :
                return md5( uniqid( mt_rand( ) ) );
        }
    }
}
if ( function_exists( "alternator" ) )
{
    function alternator( )
    {
        static $i = NULL;
        if ( func_num_args( ) == 0 )
        {
            $i = 0;
            return "";
        }
        $args = func_get_args( );
        return $args[$i++ % count( $args )];
    }
}
if ( function_exists( "repeater" ) )
{
    function repeater( $data, $num = 1 )
    {
        if ( 0 < $num )
        {
            return str_repeat( $data, $num );
        }
        return "";
    }
}
?>
