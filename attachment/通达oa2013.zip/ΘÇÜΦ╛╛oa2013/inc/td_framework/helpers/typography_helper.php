<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
if ( defined( "BASEPATH" ) )
{
    exit( "No direct script access allowed" );
}
if ( function_exists( "nl2br_except_pre" ) )
{
    function nl2br_except_pre( $str )
    {
        $CI =& get_instance( );
        $CI->load->library( "typography" );
        return $CI->typography->nl2br_except_pre( $str );
    }
}
if ( function_exists( "auto_typography" ) )
{
    function auto_typography( $str, $reduce_linebreaks = FALSE )
    {
        $CI =& get_instance( );
        $CI->load->library( "typography" );
        return $CI->typography->auto_typography( $str, $reduce_linebreaks );
    }
}
?>
