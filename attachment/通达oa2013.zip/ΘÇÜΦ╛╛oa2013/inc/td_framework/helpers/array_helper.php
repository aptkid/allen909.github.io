<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
if ( defined( "BASEPATH" ) )
{
    exit( "No direct script access allowed" );
}
if ( function_exists( "element" ) )
{
    function element( $item, $array, $default = FALSE )
    {
        if ( !isset( $array[$item] ) || $array[$item] == "" )
        {
            return $default;
        }
        return $array[$item];
    }
}
if ( function_exists( "random_element" ) )
{
    function random_element( $array )
    {
        if ( is_array( $array ) )
        {
            return $array;
        }
        return $array[array_rand( $array )];
    }
}
?>
