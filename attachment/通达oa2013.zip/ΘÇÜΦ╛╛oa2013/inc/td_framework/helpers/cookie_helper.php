<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
if ( defined( "BASEPATH" ) )
{
    exit( "No direct script access allowed" );
}
if ( function_exists( "set_cookie" ) )
{
    function set_cookie( $name = "", $value = "", $expire = "", $domain = "", $path = "/", $prefix = "" )
    {
        if ( is_array( $name ) )
        {
            foreach ( array( "value", "expire", "domain", "path", "prefix", "name" ) as $item )
            {
                if ( isset( $name[$item] ) )
                {
                    $$item = $name[$item];
                }
            }
        }
        $CI =& get_instance( );
        if ( $prefix == "" && $CI->config->item( "cookie_prefix" ) != "" )
        {
            $prefix = $CI->config->item( "cookie_prefix" );
        }
        if ( $domain == "" && $CI->config->item( "cookie_domain" ) != "" )
        {
            $domain = $CI->config->item( "cookie_domain" );
        }
        if ( $path == "/" && $CI->config->item( "cookie_path" ) != "/" )
        {
            $path = $CI->config->item( "cookie_path" );
        }
        if ( is_numeric( $expire ) )
        {
            $expire = time( ) - 86500;
        }
        else if ( 0 < $expire )
        {
            $expire = time( ) + $expire;
        }
        else
        {
            $expire = 0;
        }
        setcookie( $prefix.$name, $value, $expire, $path, $domain, 0 );
    }
}
if ( function_exists( "get_cookie" ) )
{
    function get_cookie( $index = "", $xss_clean = FALSE )
    {
        $CI =& get_instance( );
        $prefix = "";
        if ( !isset( $_COOKIE[$index] ) && config_item( "cookie_prefix" ) != "" )
        {
            $prefix = config_item( "cookie_prefix" );
        }
        return $CI->input->cookie( $prefix.$index, $xss_clean );
    }
}
if ( function_exists( "delete_cookie" ) )
{
    function delete_cookie( $name = "", $domain = "", $path = "/", $prefix = "" )
    {
        set_cookie( $name, "", "", $domain, $path, $prefix );
    }
}
?>
