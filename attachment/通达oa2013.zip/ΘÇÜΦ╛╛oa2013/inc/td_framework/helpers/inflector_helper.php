<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
if ( defined( "BASEPATH" ) )
{
    exit( "No direct script access allowed" );
}
if ( function_exists( "singular" ) )
{
    function singular( $str )
    {
        $str = strtolower( trim( $str ) );
        $end = substr( $str, -3 );
        if ( $end == "ies" )
        {
            $str = substr( $str, 0, strlen( $str ) - 3 )."y";
            return $str;
        }
        if ( $end == "ses" )
        {
            $str = substr( $str, 0, strlen( $str ) - 2 );
            return $str;
        }
        $end = substr( $str, -1 );
        if ( $end == "s" )
        {
            $str = substr( $str, 0, strlen( $str ) - 1 );
        }
        return $str;
    }
}
if ( function_exists( "plural" ) )
{
    function plural( $str, $force = FALSE )
    {
        $str = strtolower( trim( $str ) );
        $end = substr( $str, -1 );
        if ( $end == "y" )
        {
            $vowels = array( "a", "e", "i", "o", "u" );
            $str = in_array( substr( $str, -2, 1 ), $vowels ) ? $str."s" : substr( $str, 0, -1 )."ies";
            return $str;
        }
        if ( $end == "s" )
        {
            if ( $force )
            {
                $str .= "es";
                return $str;
            }
        }
        $str .= "s";
        return $str;
    }
}
if ( function_exists( "camelize" ) )
{
    function camelize( $str )
    {
        $str = "x".strtolower( trim( $str ) );
        $str = ucwords( preg_replace( "/[\\s_]+/", " ", $str ) );
        return substr( str_replace( " ", "", $str ), 1 );
    }
}
if ( function_exists( "underscore" ) )
{
    function underscore( $str )
    {
        return preg_replace( "/[\\s]+/", "_", strtolower( trim( $str ) ) );
    }
}
if ( function_exists( "humanize" ) )
{
    function humanize( $str )
    {
        return ucwords( preg_replace( "/[_]+/", " ", strtolower( trim( $str ) ) ) );
    }
}
?>
