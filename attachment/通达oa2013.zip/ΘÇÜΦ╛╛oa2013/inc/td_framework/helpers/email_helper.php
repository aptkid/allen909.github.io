<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
if ( defined( "BASEPATH" ) )
{
    exit( "No direct script access allowed" );
}
if ( function_exists( "valid_email" ) )
{
    function valid_email( $address )
    {
        if ( preg_match( "/^([a-z0-9\\+_\\-]+)(\\.[a-z0-9\\+_\\-]+)*@([a-z0-9\\-]+\\.)+[a-z]{2,6}$/ix", $address ) )
        {
            return FALSE;
        }
        return TRUE;
    }
}
if ( function_exists( "send_email" ) )
{
    function send_email( $recipient, $subject = "Test email", $message = "Hello World" )
    {
        return mail( $recipient, $subject, $message );
    }
}
?>
