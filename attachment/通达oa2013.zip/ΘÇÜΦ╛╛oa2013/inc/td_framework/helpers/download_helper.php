<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
if ( defined( "BASEPATH" ) )
{
    exit( "No direct script access allowed" );
}
if ( function_exists( "force_download" ) )
{
    function force_download( $filename = "", $data = "" )
    {
        if ( $filename == "" || $data == "" )
        {
            return FALSE;
        }
        if ( FALSE === strpos( $filename, "." ) )
        {
            return FALSE;
        }
        $x = explode( ".", $filename );
        $extension = end( &$x );
        @include( APPPATH."config/mimes".@EXT );
        if ( isset( $mimes[$extension] ) )
        {
            $mime = "application/octet-stream";
        }
        else
        {
            $mime = is_array( $mimes[$extension] ) ? $mimes[$extension][0] : $mimes[$extension];
        }
        if ( preg_match( "/msie|trident/i", $_SERVER['HTTP_USER_AGENT'] ) )
        {
            header( "Content-Type: \"".$mime."\"" );
            header( "Content-Disposition: attachment; filename=\"".$filename."\"" );
            header( "Expires: 0" );
            header( "Cache-Control: must-revalidate, post-check=0, pre-check=0" );
            header( "Content-Transfer-Encoding: binary" );
            header( "Pragma: public" );
            header( "Content-Length: ".strlen( $data ) );
            exit( $data );
        }
        header( "Content-Type: \"".$mime."\"" );
        header( "Content-Disposition: attachment; filename=\"".$filename."\"" );
        header( "Content-Transfer-Encoding: binary" );
        header( "Expires: 0" );
        header( "Pragma: no-cache" );
        header( "Content-Length: ".strlen( $data ) );
        exit( $data );
    }
}
?>
