<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
if ( defined( "BASEPATH" ) )
{
    exit( "No direct script access allowed" );
}
if ( function_exists( "xml_convert" ) )
{
    function xml_convert( $str )
    {
        $temp = "__TEMP_AMPERSANDS__";
        $str = preg_replace( "/&#(\\d+);/", "{$temp}\\1;", $str );
        $str = preg_replace( "/&(\\w+);/", "{$temp}\\1;", $str );
        $str = str_replace( array( "&", "<", ">", "\"", "'", "-" ), array( "&amp;", "&lt;", "&gt;", "&quot;", "&#39;", "&#45;" ), $str );
        $str = preg_replace( "/".$temp."(\\d+);/", "&#\\1;", $str );
        $str = preg_replace( "/".$temp."(\\w+);/", "&\\1;", $str );
        return $str;
    }
}
?>
