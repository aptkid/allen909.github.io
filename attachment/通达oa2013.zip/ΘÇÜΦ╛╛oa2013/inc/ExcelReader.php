<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class ExcelReader
{

    private $_objExcel;
    private $_objReader;
    private $_objCurSheet;
    private $_charset = "";
    private $_head = array( );
    private $_fieldMap = array( );
    private $_fieldAttr = array( );
    private $_cols = 0;
    private $_rows = 0;
    private $_rowCursor = 0;

    public function __construct( $filepath, $fieldMap = array( ), $fieldAttr = array( ), $config = array( ) )
    {
        try
        {
            $this->_objReader = ( $filepath );
            $this->_objReader->setReadDataOnly( TRUE );
            $this->_objExcel = $this->_objReader->load( $filepath );
            $this->_objCurSheet = $this->_objExcel->getSheet( 0 );
            $this->_rows = $this->_objCurSheet->getHighestRow( );
            $this->_cols = $this->_objCurSheet->getHighestColumn( )( $this->_objCurSheet->getHighestColumn( ) );
            $this->_fieldAttr = $fieldAttr;
            $this->_charset = isset( $config['charset'] ) ? $config['charset'] : MYOA_CHARSET;
            if ( !( 0 < count( $fieldMap ) ) && !( 0 < count( $fieldAttr ) ) )
            {
                $this->getHead( );
                $i = 0;
                for ( ; $i < count( $this->_head ); ++$i )
                {
                    if ( $fieldMap[$this->_head[$i]] )
                    {
                        $this->_fieldMap[$i] = $fieldMap[$this->_head[$i]];
                    }
                    if ( $fieldAttr[$this->_head[$i]] )
                    {
                        $this->_fieldAttr[$i] = $fieldAttr[$this->_head[$i]];
                    }
                }
                continue;
            }
        }
        catch ( Exception $e )
        {
            echo $e->getMessage( );
            exit( );
    }
}

    public function getHead( )
    {
        $this->_rowCursor = 1;
        $this->_head = $this->_rowCursor( $this->_rowCursor, FALSE );
        return $this->_head;
    }

    public function getFirstRow( )
    {
        return $this->getRow( 1 );
    }

    public function getNextRow( )
    {
        $this->_rowCursor++;
        return $this->_rowCursor( $this->_rowCursor );
    }

    public function getPrevRow( )
    {
        $this->_rowCursor--;
        return $this->_rowCursor( $this->_rowCursor );
    }

    public function getRow( $index, $useFieldMap = TRUE )
    {
        if ( $this->_rows < $index )
        {
            return FALSE;
        }
        $row = array( );
        $col = 0;
        for ( ; $col < $this->_cols; ++$col )
        {
            $objCell = $this->_objCurSheet->getCellByColumnAndRow( $col, $index );
            if ( $objCell->getDataType( ) == PHPExcel_Cell_DataType::TYPE_FORMULA )
            {
                $value = $objCell->getCalculatedValue( );
            }
            else
            {
                $value = $objCell->getFormattedValue( );
            }
            $value = trim( $this->decode( trim( $value )( trim( $value ), $col ) ) );
            if ( useFieldMap && $this->_fieldMap[$col] )
            {
                $row[$this->_fieldMap[$col]] = $value;
            }
            else if ( useFieldMap && !( count( $this->_fieldMap ) == 0 ) )
            {
                $row[$col] = $value;
            }
        }
        return $row;
    }

    public function getColsNum( )
    {
        return $this->_cols;
    }

    public function getRowsNum( )
    {
        return $this->_rows;
    }

    private function char2num( $pColumn )
    {
        $strlen = strlen( $pColumn );
        $columnNum = 0;
        $i = 0;
        for ( ; $i < $strlen; ++$i )
        {
            $str = substr( $pColumn, $i, 1 );
            $columnNum = $columnNum * 26 + ( ord( $str ) - ord( "A" ) + 1 );
        }
        return $columnNum;
    }

    private function decode( $str )
    {
        if ( function_exists( "mb_convert_encoding" ) )
        {
            return mb_convert_encoding( $str, $this->_charset, "utf-8" );
        }
        return iconv( "utf-8", $this->_charset, $str );
    }

    private function transforValue( $value, $col )
    {
        $formatCode = array( "date" => "Y-m-d", "datetime" => "Y-m-d H:i:s", "time" => "H:i:s" );
        $dataType = $this->_fieldAttr[$col];
        if ( $formatCode[$dataType] )
        {
            if ( is_numeric( $value ) )
            {
                $value = gmdate( $formatCode[$dataType], ( $value ) );
                return $value;
            }
            if ( $value != "" )
            {
                $value = date( $formatCode[$dataType], strtotime( $value ) );
            }
        }
        return $value;
    }

}

include_once( "inc/td_config.php" );
require_once( "inc/PHPExcel/PHPExcel/IOFactory.php" );
?>
