<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class Editor
{

    public $InstanceName;
    public $BasePath;
    public $Width;
    public $Height;
    public $ToolbarSet;
    public $Value;
    public $Config = array( );
    public $Events = array( );
    public $GlobalEvents = array( );
    public $OpenWXEmotions;
    public $basePath;
    public $config = array( );
    public $initialized = FALSE;
    public $returnOutput = TRUE;
    public $textareaAttributes = array( 'rows' => 8, 'cols' => 60 );
    public $timestamp = "D5AC";
    private $events = array( );
    private $globalEvents = array( );

    const version = "4.1.2";
    const timestamp = "D5AC";

    public function Editor( $instanceName )
    {
        $this->InstanceName = "TD_HTML_EDITOR_".$instanceName;
        $this->BasePath = MYOA_JS_SERVER."/module/editor/";
        $this->Width = "100%";
        $this->Height = "200";
        $this->ToolbarSet = "Default";
        $this->Value = "";
        $this->Config = array( );
        $this->OpenWXEmotions = "";
    }

    public function initSettings( )
    {
        $this->basePath = $this->BasePath;
        $this->config = $this->Config;
        $this->config['width'] = $this->Width;
        $this->config['height'] = $this->Height;
        $this->config['toolbar'] = $this->ToolbarSet;
        $this->config['language'] = MYOA_LANG_COOKIE;
        $this->config['allowedContent'] = TRUE;
        $this->OpenWXEmotions = $this->OpenWXEmotions === TRUE ? "qq" : $this->OpenWXEmotions;
        if ( $this->OpenWXEmotions != "" )
        {
            require_once( "inc/emotions_config.php" );
            require_once( "inc/utility_msg.php" );
            $this->G_EMOTIONS = $G_EMOTIONS;
            if ( $this->Value != "" )
            {
                $this->Value = format_msg_content( $this->Value, "output" );
            }
        }
    }

    public function Create( )
    {
        echo $this->CreateHtml( );
    }

    public function CreateHtml( )
    {
        $this->initSettings( );
        return $this->Events( $this->InstanceName, $this->Value, $this->config, $this->Events );
    }

    public function CreateEditor( $name, $value = "", $config = array( ), $events = array( ) )
    {
        $attr = "";
        foreach ( $this->textareaAttributes as $key => $val )
        {
            $attr .= " ".$key."=\"".str_replace( "\"", "&quot;", $val )."\"";
        }
        if ( empty( $this->config['title'] ) )
        {
            $attr .= " title=\"".$this->Config['title']."\"";
        }
        $out = "<textarea name=\"".$name."\"".$attr.">".htmlspecialchars( $value )."</textarea>\n";
        if ( $this->initialized )
        {
            $out .= $this->init( );
        }
        $_config = $this->configSettings( $config, $events );
        $js = $this->returnGlobalEvents( );
        if ( empty( $_config ) )
        {
            $js .= "CKEDITOR.replace('".$name."', ".$this->jsEncode( $_config ).");";
        }
        else
        {
            $js .= "CKEDITOR.replace('".$name."');";
        }
        if ( $this->OpenWXEmotions != "" )
        {
            $js .= $this->outputEmotions( );
        }
        $out .= $this->script( $js );
        if ( $this->returnOutput )
        {
            echo $out;
            $out = "";
        }
        return $out;
    }

    private function script( $js )
    {
        $out = "<script type=\"text/javascript\">";
        $out .= "//<![CDATA[\n";
        $out .= $js;
        $out .= "\n//]]>";
        $out .= "</script>\n";
        return $out;
    }

    private function configSettings( $config = array( ), $events = array( ) )
    {
        $_config = $this->config;
        $_events = $this->events;
        if ( is_array( $config ) && !empty( $config ) )
        {
            $_config = array_merge( $_config, $config );
        }
        if ( is_array( $events ) && !empty( $events ) )
        {
            foreach ( $events as $eventName => $code )
            {
                if ( isset( $_events[$eventName] ) )
                {
                    $_events[$eventName] = array( );
                }
                if ( in_array( $code, $_events[$eventName] ) )
                {
                    $_events[$eventName][] = $code;
                }
            }
        }
        if ( empty( $_events ) )
        {
            foreach ( $_events as $eventName => $handlers )
            {
                if ( empty( $handlers ) )
                {
                    continue;
                }
                else if ( count( $handlers ) == 1 )
                {
                    $_config['on'][$eventName] = "@@".$handlers[0];
                }
                else
                {
                    $_config['on'][$eventName] = "@@function (ev){";
                    foreach ( $handlers as $handler => $code )
                    {
                        $_config['on'] .= $eventName;
                    }
                    $_config['on'] .= $eventName;
                }
            }
        }
        return $_config;
    }

    private function returnGlobalEvents( )
    {
        static $returnedEvents = NULL;
        $out = "";
        if ( isset( $returnedEvents ) )
        {
            $returnedEvents = array( );
        }
        if ( empty( $this->globalEvents ) )
        {
            foreach ( $this->globalEvents as $eventName => $handlers )
            {
                foreach ( $handlers as $handler => $code )
                {
                    if ( isset( $returnedEvents[$eventName] ) )
                    {
                        $returnedEvents[$eventName] = array( );
                    }
                    if ( in_array( $code, $returnedEvents[$eventName] ) )
                    {
                        $out .= ( $code ? "\n" : "" )."CKEDITOR.on('".$eventName.( "', ".$code.");" );
                        $returnedEvents[$eventName][] = $code;
                    }
                }
            }
        }
        return $out;
    }

    private function init( )
    {
        static $initComplete = NULL;
        $out = "";
        if ( empty( $initComplete ) )
        {
            return "";
        }
        if ( $this->initialized )
        {
            $initComplete = TRUE;
            return "";
        }
        $args = "";
        $ckeditorPath = $this->ckeditorPath( );
        if ( !empty( $this->timestamp ) && $this->timestamp != "%TIMESTAMP%" )
        {
            $args = "?t=".$this->timestamp;
        }
        if ( strpos( $ckeditorPath, ".." ) !== 0 )
        {
            $out .= $this->script( "window.CKEDITOR_BASEPATH='".$ckeditorPath."';" );
            $out .= $this->Config['model_type']( "window.HTML_MODEL_TYPE='".$this->Config['model_type']."';" );
        }
        $out .= "<script type=\"text/javascript\" src=\"".$ckeditorPath."ckeditor.js".( MYOA_SUPPORT_GZIP ? ".gz" : "" ).$args."\"></script>\n";
        $extraCode = "";
        if ( $this->timestamp != self::timestamp )
        {
            $extraCode .= ( $extraCode ? "\n" : "" )."CKEDITOR.timestamp = '".$this->timestamp."';";
        }
        if ( $extraCode )
        {
            $out .= $this->script( $extraCode );
        }
        $initComplete = $this->initialized = TRUE;
        return $out;
    }

    private function ckeditorPath( )
    {
        if ( empty( $this->basePath ) )
        {
            return $this->basePath;
        }
        if ( isset( $_SERVER['SCRIPT_FILENAME'] ) )
        {
            $realPath = dirname( $_SERVER['SCRIPT_FILENAME'] );
        }
        else
        {
            $realPath = realpath( "./" );
        }
        $selfPath = dirname( $_SERVER['PHP_SELF'] );
        $file = str_replace( "\\", "/", __FILE__ );
        if ( !$selfPath || !$realPath || !$file )
        {
            return "/ckeditor/";
        }
        $documentRoot = substr( $realPath, 0, strlen( $realPath ) - strlen( $selfPath ) );
        $fileUrl = substr( $file, strlen( $documentRoot ) );
        $ckeditorUrl = str_replace( "ckeditor_php5.php", "", $fileUrl );
        return $ckeditorUrl;
    }

    private function jsEncode( $val )
    {
        if ( is_null( $val ) )
        {
            return "null";
        }
        if ( is_bool( $val ) )
        {
            if ( $val )
            {
                return "true";
            }
            return "false";
        }
        if ( is_int( $val ) )
        {
            return $val;
        }
        if ( is_float( $val ) )
        {
            return str_replace( ",", ".", $val );
        }
        if ( is_array( $val ) || is_object( $val ) )
        {
            if ( is_array( $val ) && array_keys( $val ) === range( 0, count( $val ) - 1 ) )
            {
                return "[".implode( ",", array_map( array( $this, "jsEncode" ), $val ) )."]";
            }
            $temp = array( );
            foreach ( $val as $k => $v )
            {
                $temp[] = $this->jsEncode( "{$k}" ).":".$this->jsEncode( $v );
            }
            return "{".implode( ",", $temp )."}";
        }
        if ( strpos( $val, "@@" ) === 0 )
        {
            return substr( $val, 2 );
        }
        if ( strtoupper( substr( $val, 0, 9 ) ) == "CKEDITOR." )
        {
            return $val;
        }
        return "\"".str_replace( array( "\\", "/", "\n", "\t", "\r", "\x08", "\x0C", "\"" ), array( "\\\\", "\\/", "\\n", "\\t", "\\r", "\\b", "\\f", "\\\"" ), $val )."\"";
    }

    private function outputEmotions( )
    {
        $emotion_array = $this->G_EMOTIONS['data'];
        $arr_id = $arr_name = array( );
        foreach ( $emotion_array as $key => $value )
        {
            foreach ( $value as $k => $v )
            {
                $arr_id[$key][] = $v['id'].".gif";
                $arr_name[$key][] = $v['name'];
            }
        }
        $js = "\r\nCKEDITOR.config.default_smiley = '".$this->G_EMOTIONS['default']."';\r\n";
        $js .= "CKEDITOR.config.mutismiley_type_desc = ".json_encode( td_iconv( $this->G_EMOTIONS['type'], MYOA_CHARSET, "utf-8" ) ).";\r\n";
        $js .= "CKEDITOR.config.mutismiley_path = '".MYOA_STATIC_SERVER."/static/images/face/';\r\n";
        $js .= "CKEDITOR.config.mutismiley_images = ".json_encode( $arr_id ).";\r\n";
        $js .= "CKEDITOR.config.mutismiley_descriptions = ".json_encode( td_iconv( $arr_name, MYOA_CHARSET, "utf-8" ) ).";\r\n";
        return $js;
    }

}

?>
