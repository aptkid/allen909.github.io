<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class ExcelWriter
{

    private $_objExcel;
    private $_objActSheet;
    private $_charset = "";
    private $_head = array( );
    private $_rows = 0;
    private $_excelClass = "Excel5";
    private $_excelPostfix = ".xls";

    public function __construct( $config = array( ) )
    {
        $this->_objExcel = new PHPExcel( );
        $this->_objActSheet = $this->setActiveSheetIndex( 0 );
        $this->_charset = isset( $config['charset'] ) ? $config['charset'] : MYOA_CHARSET;
    }

    public function setActiveSheetIndex( $index )
    {
        return $this->_objExcel->setActiveSheetIndex( $index );
    }

    public function setFileName( $filename )
    {
        $this->_filename = $this->encode( $filename );
        $this->_objActSheet->setTitle( $this->encode( $filename ) );
    }

    public function setTitle( $title )
    {
        $this->_objActSheet->setTitle( $this->encode( $title ) );
    }

    public function addHead( $row )
    {
        $this->_rows++;
        $row = $this->row2array( $row );
        $this->_head = $row;
        $col = 0;
        for ( ; $col < count( $row ); ++$col )
        {
            $data = $row[$col]( $row[$col] );
            $width = ceil( strlen( $data ) * 1.2 );
            $style = $this->_objActSheet->getStyleByColumnAndRow( $col, "1" );
            $align = $style->getAlignment( );
            $align->setHorizontal( PHPExcel_Style_Alignment::VERTICAL_CENTER );
            $align->setVertical( PHPExcel_Style_Alignment::VERTICAL_CENTER );
            $this->_objActSheet->getColumnDimensionByColumn( $col )->setWidth( $width );
            $this->_objActSheet->setCellValueExplicitByColumnAndRow( $col, $this->_rows, $data, PHPExcel_Cell_DataType::TYPE_STRING );
        }
    }

    public function addRow( $row )
    {
        $this->_rows++;
        $row = $this->row2array( $row );
        $col = 0;
        for ( ; $col < count( $row ); ++$col )
        {
            $data = $row[$col];
            if ( substr( $data, 0, 1 ) == "\"" && substr( $data, -1 ) == "\"" )
            {
                $data = substr( $data, 1, -1 );
            }
            $data = $this->encode( $data );
            $this->_objActSheet->setCellValueExplicitByColumnAndRow( $col, $this->_rows, $data, PHPExcel_Cell_DataType::TYPE_STRING );
        }
    }

    public function Save( )
    {
        ob_end_clean( );
        header( "Cache-control: private" );
        header( "Content-type: application/vnd.ms-excel" );
        header( "Accept-Ranges: bytes" );
        header( "Accept-Length: ".ob_get_length( ) );
        header( "Content-Disposition: attachment; ".$this->get_filename( $this->_filename.$this->_excelPostfix ) );
        $objWriter = ( $this->_objExcel, $this->_excelClass );
        $objWriter->save( "php://output" );
    }

    private function encode( $str )
    {
        if ( function_exists( "mb_convert_encoding" ) )
        {
            return mb_convert_encoding( $str, "utf-8", $this->_charset );
        }
        return iconv( $this->_charset, "utf-8", $str );
    }

    private function row2array( $row )
    {
        if ( is_array( $row ) )
        {
            return $row;
        }
        $delimiter = ",";
        $enclosure = "\"";
        $expr_field = "/".$delimiter."(?=(?:[^".$enclosure."]*".$enclosure."[^".$enclosure."]*".$enclosure.")*(?![^".$enclosure."]*".$enclosure."))/";
        $row = preg_split( $expr_field, trim( $row ) );
        $row = preg_replace( array( "/\"(.*)\"$/s", "/\"\"/s", "/\\<\\?/s" ), array( "$1", "\"", "&lt;?_(" ), $row );
        return $row;
    }

    private function get_filename( $filename )
    {
        $filename_encoded = str_replace( "+", "%20", urlencode( $filename ) );
        if ( preg_match( "/msie|trident/i", $_SERVER['HTTP_USER_AGENT'] ) )
        {
            return "filename=\"".$filename_encoded."\"";
        }
        if ( preg_match( "/Firefox/", $_SERVER['HTTP_USER_AGENT'] ) )
        {
            return "filename*=\"utf8''".$filename."\"";
        }
        return "filename=\"".$filename."\"";
    }

}

include_once( "inc/td_config.php" );
require_once( "inc/PHPExcel/PHPExcel/IOFactory.php" );
?>
