<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
include_once( "inc/auth.inc.php" );
if ( strstr( $PHOTO, "/" ) || strstr( $PHOTO, "\\" ) )
{
    exit( );
}
$URL = MYOA_ATTACH_PATH.( "product_pic/".$PHOTO );
if ( file_exists( $URL ) )
{
    echo _( "�Ҳ����ļ�" );
    exit( );
}
$file_ext = strtolower( substr( $PHOTO, strrpos( $PHOTO, "." ) + 1 ) );
switch ( $file_ext )
{
    case ".jpg" :
    case ".bmp" :
    case ".gif" :
    case ".png" :
    case ".wmv" :
    case ".html" :
    case ".htm" :
    case ".wav" :
    case ".mid" :
        $COTENT_TYPE = 0;
        $COTENT_TYPE_DESC = "application/octet-stream";
        break;
    case ".pdf" :
        $COTENT_TYPE = 0;
        $COTENT_TYPE_DESC = "application/pdf";
        break;
    case ".swf" :
        $COTENT_TYPE = 0;
        $COTENT_TYPE_DESC = "application/x-shockwave-flash";
        break;
    default :
        $COTENT_TYPE = 1;
        $COTENT_TYPE_DESC = "application/octet-stream";
}
ob_end_clean( );
header( "Cache-control: private" );
header( "Content-type: ".$COTENT_TYPE_DESC );
header( "Accept-Ranges: bytes" );
header( "Accept-Length: ".sprintf( "%u", filesize( $URL ) ) );
if ( $COTENT_TYPE == 1 )
{
    header( "Content-Disposition: attachment; ".get_attachment_filename( $PHOTO ) );
}
else
{
    header( "Content-Disposition: ".get_attachment_filename( $PHOTO ) );
}
readfile( $URL );
?>
