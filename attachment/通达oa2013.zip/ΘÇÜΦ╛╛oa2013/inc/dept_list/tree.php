<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
function deptListTree( $PARENT_ID )
{
    global $PARA_URL;
    global $PARA_TARGET;
    global $PARA_ID;
    global $PARA_VALUE;
    global $showButton;
    global $DEPT_PRIV;
    global $DEPT_ID_STR;
    global $MODULE_ID;
    global $USER_SELECT_FLAG;
    global $MANAGE_FLAG;
    $query = "SELECT * from DEPARTMENT where DEPT_PARENT='".$PARENT_ID."'  order by DEPT_NO";
    $cursor1 = exequery( ( ), $query );
    while ( $ROW = mysql_fetch_array( $cursor1 ) )
    {
        $DEPT_ID1 = $ROW['DEPT_ID'];
        $DEPT_NAME1 = $ROW['DEPT_NAME'];
        $DEPT_NAME1 = htmlspecialchars( $DEPT_NAME1 );
        $DEPT_NAME1 = stripslashes( $DEPT_NAME1 );
        $IS_ORG = $ROW['IS_ORG'];
        if ( $DEPT_PRIV == 4 )
        {
            if ( $DEPT_ID1 == $_SESSION['LOGIN_DEPT_ID'] )
            {
                $DEPT_PRIV1 = 1;
            }
            else
            {
                $DEPT_PRIV1 = 0;
            }
        }
        else
        {
            $DEPT_PRIV1 = is_dept_priv( $DEPT_ID1, $DEPT_PRIV, $DEPT_ID_STR, $USER_SELECT_FLAG );
        }
        do
        {
            if ( !( $DEPT_PRIV1 == 0 ) )
            {
                break;
            }
            else
            {
                if ( $DEPT_PRIV == "" )
                {
                    $DEPT_PRIV = getpostprivbyuserid( $_SESSION['LOGIN_USER_ID'] );
                }
            }
            if ( $DEPT_PRIV == 6 )
            {
            }
        } while ( 0 );
        $TITLE = $DEPT_PRIV1 == 1 ? "{$DEPT_NAME1}" : $DEPT_NAME1;
        $URL = $TARGET = $JSON = "";
        if ( $PARA_URL != "" && $DEPT_PRIV1 == 1 )
        {
            if ( $PARA_ID == "" )
            {
                $URL = "{$PARA_URL}?DEPT_ID={$DEPT_ID1}&MODULE_ID={$MODULE_ID}";
            }
            else
            {
                $URL = "{$PARA_URL}?DEPT_ID={$DEPT_ID1}&MANAGE_FLAG={$MANAGE_FLAG}&MODULE_ID={$MODULE_ID}&{$PARA_ID}=".str_replace( ".", "&", $PARA_VALUE );
            }
            $TARGET = $PARA_TARGET;
        }
        $CHILD_COUNT = 0;
        $query = "SELECT 1 from DEPARTMENT where DEPT_PARENT='".$DEPT_ID1."'";
        $cursor2 = exequery( ( ), $query );
        if ( $ROW1 = mysql_fetch_array( $cursor2 ) )
        {
            ++$CHILD_COUNT;
        }
        $IS_LAZY = FALSE;
        if ( 0 < $CHILD_COUNT )
        {
            $JSON = "/inc/dept_list/tree.php?DEPT_ID=".$DEPT_ID1."&MANAGE_FLAG={$MANAGE_FLAG}&PARA_URL={$PARA_URL}&PARA_TARGET={$PARA_TARGET}&PARA_ID={$PARA_ID}&PARA_VALUE={$PARA_VALUE}&showButton={$showButton}&MODULE_ID={$MODULE_ID}&DEPT_PRIV={$DEPT_PRIV}&USER_SELECT_FLAG={$USER_SELECT_FLAG}";
            $IS_LAZY = TRUE;
        }
        $ONCHECK = $showButton && $DEPT_PRIV1 == "1" ? "click_node" : "";
        $DEPT_ARRAY[] = array( "title" => td_iconv( $TITLE, MYOA_CHARSET, "utf-8" ), "isFolder" => TRUE, "isLazy" => $IS_LAZY, "key" => "dept_".$DEPT_ID1, "dept_id" => $DEPT_ID1, "icon" => $IS_ORG == 1 ? "org.png" : FALSE, "url" => td_iconv( $URL, MYOA_CHARSET, "utf-8" ), "tooltip" => td_iconv( $DEPT_NAME1, MYOA_CHARSET, "utf-8" ), "json" => td_iconv( $JSON, MYOA_CHARSET, "utf-8" ), "target" => $TARGET, "onCheck" => td_iconv( $ONCHECK, MYOA_CHARSET, "utf-8" ) );
    }
    return $DEPT_ARRAY;
}

include_once( "inc/auth.inc.php" );
include_once( "inc/utility_all.php" );
include_once( "inc/utility_org.php" );
ob_end_clean( );
$PARENT_ID = $DEPT_ID;
if ( $MODULE_ID != "" )
{
    if ( $DEPT_PRIV == "2" )
    {
        $query1 = "SELECT DEPT_ID from MODULE_PRIV where UID='".$_SESSION['LOGIN_UID'].( "' and MODULE_ID='".$MODULE_ID."'" );
        $cursor1 = exequery( ( ), $query1 );
        if ( $ROW = mysql_fetch_array( $cursor1 ) )
        {
            $DEPT_ID_STR = $ROW['DEPT_ID'];
        }
    }
}
else if ( $MODULE_ID == "" && $DEPT_PRIV == "2" )
{
    $query = "SELECT POST_DEPT from USER where UID='".$_SESSION['LOGIN_UID']."'";
    $cursor = exequery( ( ), $query );
    if ( $ROW = mysql_fetch_array( $cursor ) )
    {
        $DEPT_ID_STR = $ROW['POST_DEPT'];
    }
}
if ( $PARENT_ID == 0 )
{
    $UNIT_NAME = ( "SYS_UNIT" );
    $ONCHECK = $showButton && $DEPT_PRIV == "1" ? "click_node" : "";
    $DEPT_ARRAY = deptlisttree( $PARENT_ID );
    $ORG_ARRAY = array( "title" => td_iconv( $UNIT_NAME, MYOA_CHARSET, "utf-8" ), "isFolder" => TRUE, "isLazy" => FALSE, "expand" => TRUE, "key" => "dept_0", "dept_id" => "0", "icon" => "root.png", "tooltip" => td_iconv( $UNIT_NAME, MYOA_CHARSET, "utf-8" ), "children" => $DEPT_ARRAY, "onCheck" => td_iconv( $ONCHECK, MYOA_CHARSET, "utf-8" ) );
}
else
{
    $ORG_ARRAY = deptlisttree( $PARENT_ID );
}
echo json_encode( $ORG_ARRAY );
?>
