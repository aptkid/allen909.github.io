<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
$ROOT_PATH = $_SERVER['DOCUMENT_ROOT'];
if ( $ROOT_PATH == "" )
{
    $ROOT_PATH = "d:/myoa/webroot/";
}
if ( substr( $ROOT_PATH, -1 ) != "/" )
{
    $ROOT_PATH .= "/";
}
$ATTACH_PATH = $ROOT_PATH."attachment/";
$ATTACH_PATH2 = realpath( $ROOT_PATH."../" )."/attach/";
$ATTACH_BACKUP_PATH = $ATTACH_PATH2."bak/";
$MYOA_CACHE_PATH = $ATTACH_PATH2."cache/";
$MYOA_RECYCLE_PATH = $ATTACH_PATH2."recycle/";
$SMS_REF_SEC = 30;
$ONLINE_REF_SEC = 120;
$ATTACH_LOCK_REF_SEC = 180;
$OFFLINE_TIME_MIN = 0;
$SMS_REF_MAX = 3;
$SMS_CALLSOUND_INTERVAL = 3;
$UPLOAD_FORBIDDEN_TYPE = "php,php3,php4,php5,phpt,jsp,asp,aspx,";
$UPLOAD_LIMIT = 1;
$UPLOAD_LIMIT_TYPE = "php,php3,php4,php5,";
$EDIT_LIMIT_TYPE = "php,php3,php4,php5,phpt,inc,jsp,asp,aspx,js,cgi,pl,";
$CORRECT_BUTTON = 1;
$ATTACH_OFFICE_OPEN_IN_IE = 0;
$SMS_DELAY_PER_ROWS = 60;
$SMS_DELAY_SECONDS = 60;
$MYOA_LOGIN_TIME_RANGE = "00:00:00 ~ 23:59:59";
$MYOA_GAME_TIME_RANGE = "00:00:00 ~ 23:59:59";
$MYOA_IS_RECYCLE = 1;
$MYOA_IS_DEMO = 0;
$MYOA_INDEX_TOP_KEYS = 20;
$MYOA_IM_REMIND_ROWS = 60;
$MYOA_USE_OS_BROWSER = 0;
$MYOA_MOBILE_FUNC_ID_STR = "1,3,4,5,8,9,10,15,16,24,42,80,105,130,131,132,147,182,183,194,196,229,256,550,551,552,553,554,555,556,557,558,637,";
$MYOA_MEMCACHED_SERVERS = array( array( "host" => "127.0.0.1", "port" => 11211, "persistent" => FALSE, "weight" => 1 ) );
$MYOA_SESS_SAVE_HANDLER = "files";
$MYOA_CACHE_DRIVER = "apc";
$MYOA_CACHE_CONFIG = array( "prefix" => "", "cache_path" => $MYOA_CACHE_PATH, "memcached_servers" => $MYOA_MEMCACHED_SERVERS );
$MYOA_C_USER_GROUP_BY = 10;
$MYOA_ATTACH_SERVER_HTTP = "";
$MYOA_FASHION_THEME = "10,13,";
$MYSQL_SERVER = "localhost:3336";
$MYSQL_USER = "root";
$MYSQL_DB = "TD_OA";
$MYSQL_DB_ARCHIVE = "TD_OA_ARCHIVE";
$MYSQL_DB_CRSCELL = "crscell";
$MYSQL_PASS = "myoa888";
$MYOA_IS_UN = 0;
$MYOA_ATTACH_NAME_FORMAT = $MYOA_IS_UN ? 1 : 0;
$MYOA_ATTACH_ENCRYPT_DEFAULT_LEN = 256;
$MYOA_CHARSET = $MYOA_IS_UN ? "utf-8" : "gbk";
$MYOA_DB_CHARSET = $MYOA_IS_UN ? "utf8" : "gbk";
$MYOA_OS_CHARSET = "GBK";
$MYOA_MB_CHAR_LEN = $MYOA_IS_UN ? 3 : 2;
$MYOA_DEFAULT_LANG = "zh-CN";
$LANG_COOKIE = $MYOA_IS_UN && $_COOKIE['LANG_COOKIE'] != "" ? $_COOKIE['LANG_COOKIE'] : $MYOA_DEFAULT_LANG;
$MYOA_SUPPORT_GZIP = 1;
$MYOA_SYS_VERSION = "140815";
include( "inc/oa_config.php" );
include( "inc/cluster_config.php" );
if ( $MYOA_C_USER_GROUP_BY <= 0 )
{
    $MYOA_C_USER_GROUP_BY = 10;
}
$UPLOAD_FORBIDDEN_TYPE = strtolower( $UPLOAD_FORBIDDEN_TYPE );
$UPLOAD_LIMIT_TYPE = strtolower( $UPLOAD_LIMIT_TYPE );
$EDIT_LIMIT_TYPE = strtolower( $EDIT_LIMIT_TYPE );
if ( extension_loaded( "gettext" ) )
{
    if ( function_exists( "_" ) )
    {
        function _( $msg )
        {
            return $msg;
        }
    }
}
else
{
    putenv( "LANG=".$LANG_COOKIE );
    setlocale( LC_ALL, $LANG_COOKIE );
    $LANG_DOMAIN = $LANG_COOKIE;
    bindtextdomain( $LANG_DOMAIN, $ROOT_PATH."lang" );
    bind_textdomain_codeset( $LANG_DOMAIN, "UTF-8" );
    textdomain( $LANG_DOMAIN );
}
$MYOA_SUPPORT_GZIP = $MYOA_SUPPORT_GZIP && stristr( $_SERVER['SERVER_SOFTWARE'], "apache" );
if ( $MYOA_SUPPORT_GZIP )
{
    $TRIDENT_POS = stripos( $_SERVER['HTTP_USER_AGENT'], "Trident" );
    if ( $TRIDENT_POS !== FALSE )
    {
        $TRIDENT_VER = intval( substr( $_SERVER['HTTP_USER_AGENT'], $TRIDENT_POS + 8 ) );
        if ( 7 <= $TRIDENT_VER )
        {
            $MYOA_SUPPORT_GZIP = 0;
        }
        unset( $TRIDENT_VER );
    }
    unset( $TRIDENT_POS );
}
define( "MYOA_ROOT_PATH", $ROOT_PATH );
define( "MYOA_ATTACH_PATH", $ATTACH_PATH );
define( "MYOA_ATTACH_PATH2", $ATTACH_PATH2 );
define( "MYOA_ATTACH_BACKUP_PATH", $ATTACH_BACKUP_PATH );
define( "MYOA_IS_RECYCLE", $MYOA_IS_RECYCLE );
define( "MYOA_RECYCLE_PATH", $MYOA_RECYCLE_PATH );
define( "MYOA_CACHE_PATH", $MYOA_CACHE_PATH );
define( "MYOA_CACHE_DRIVER", strtolower( $MYOA_CACHE_DRIVER ) );
define( "MYOA_C_USER_GROUP_BY", $MYOA_C_USER_GROUP_BY );
define( "MYOA_SMS_REF_SEC", $SMS_REF_SEC );
define( "MYOA_SMS_REF_MAX", $SMS_REF_MAX );
define( "MYOA_SMS_CALLSOUND_INTERVAL", $SMS_CALLSOUND_INTERVAL );
define( "MYOA_SMS_DELAY_PER_ROWS", $SMS_DELAY_PER_ROWS );
define( "MYOA_SMS_DELAY_SECONDS", $SMS_DELAY_SECONDS );
define( "MYOA_IM_REMIND_ROWS", $MYOA_IM_REMIND_ROWS );
define( "MYOA_ONLINE_REF_SEC", $ONLINE_REF_SEC );
define( "MYOA_OFFLINE_TIME_MIN", $OFFLINE_TIME_MIN );
define( "MYOA_LOGIN_TIME_RANGE", $MYOA_LOGIN_TIME_RANGE );
define( "MYOA_UPLOAD_LIMIT", $UPLOAD_LIMIT );
define( "MYOA_UPLOAD_LIMIT_TYPE", $UPLOAD_LIMIT_TYPE );
define( "MYOA_UPLOAD_FORBIDDEN_TYPE", $UPLOAD_FORBIDDEN_TYPE );
define( "MYOA_EDIT_LIMIT_TYPE", $EDIT_LIMIT_TYPE );
define( "MYOA_IS_DEMO", $MYOA_IS_DEMO );
define( "MYOA_IS_UN", $MYOA_IS_UN );
define( "MYOA_CHARSET", $MYOA_CHARSET );
define( "MYOA_DB_CHARSET", $MYOA_DB_CHARSET );
define( "MYOA_OS_CHARSET", $MYOA_OS_CHARSET );
define( "MYOA_MB_CHAR_LEN", $MYOA_MB_CHAR_LEN );
define( "MYOA_DEFAULT_LANG", $MYOA_DEFAULT_LANG );
define( "MYOA_LANG_COOKIE", $LANG_COOKIE );
define( "MYOA_ATTACH_LOCK_REF_SEC", $ATTACH_LOCK_REF_SEC );
define( "MYOA_ATTACH_OFFICE_OPEN_IN_IE", $ATTACH_OFFICE_OPEN_IN_IE );
define( "MYOA_ATTACH_SERVER_HTTP", $MYOA_ATTACH_SERVER_HTTP );
define( "MYOA_ATTACH_NAME_FORMAT", $MYOA_ATTACH_NAME_FORMAT );
define( "MYOA_ATTACH_ENCRYPT_DEFAULT_LEN", $MYOA_ATTACH_ENCRYPT_DEFAULT_LEN );
define( "MYOA_USE_OS_BROWSER", $MYOA_USE_OS_BROWSER );
define( "MYOA_SESS_SAVE_HANDLER", $MYOA_SESS_SAVE_HANDLER );
define( "MYOA_SUPPORT_GZIP", $MYOA_SUPPORT_GZIP );
define( "MYOA_FASHION_THEME", $MYOA_FASHION_THEME );
define( "MYOA_JS_SERVER", $MYOA_JS_SERVER );
define( "MYOA_STATIC_SERVER", $MYOA_STATIC_SERVER );
define( "MYOA_DB_USE_REPLICATION", $MYOA_DB_USE_REPLICATION );
define( "MYOA_MOBILE_FUNC_ID_STR", $MYOA_MOBILE_FUNC_ID_STR );
define( "MYOA_SYS_VERSION", $MYOA_SYS_VERSION );
include_once( "inc/td.class.php" );
( $MYOA_MASTER_DB, $MYOA_SLAVE_DB );
( $MYOA_CACHE_CONFIG );
?>
