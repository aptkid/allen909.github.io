<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
function deptListTree( $PARENT_ID )
{
    global $PARA_URL;
    global $PARA_TARGET;
    global $PARA_ID;
    global $PARA_VALUE;
    global $showButton;
    global $DEPT_PRIV;
    global $DEPT_ID_STR;
    global $MODULE_ID;
    global $STATE_FLAG;
    $query = "SELECT DEPT_ID,DEPT_NAME,SYNC_STATE from EXT_DEPT where DEPT_PARENT = '".$PARENT_ID."' order by DEPT_NO";
    $cursor1 = exequery( ( ), $query );
    while ( $ROW = mysql_fetch_array( $cursor1 ) )
    {
        $DEPT_ID1 = $ROW['DEPT_ID'];
        $DEPT_NAME = $ROW['DEPT_NAME'];
        $SYNC_STATE = $ROW['SYNC_STATE'];
        $DEPT_NAME = htmlspecialchars( $DEPT_NAME );
        $DEPT_NAME = stripslashes( $DEPT_NAME );
        $URL = $TARGET = $JSON = $ICON = "";
        if ( $PARA_URL != "" )
        {
            if ( $PARA_ID == "" )
            {
                $URL = "{$PARA_URL}?DEPT_ID={$DEPT_ID1}&MODULE_ID={$MODULE_ID}";
            }
            else
            {
                $URL = "{$PARA_URL}?DEPT_ID={$DEPT_ID1}&MANAGE_FLAG={$MANAGE_FLAG}&MODULE_ID={$MODULE_ID}&{$PARA_ID}=".str_replace( ".", "&", $PARA_VALUE );
            }
            $TARGET = $PARA_TARGET;
        }
        $ICON = "org.png";
        $CHILD_COUNT = 0;
        $query = "SELECT 1 from EXT_DEPT where DEPT_PARENT='".$DEPT_ID1."'";
        $cursor2 = exequery( ( ), $query );
        if ( $ROW1 = mysql_fetch_array( $cursor2 ) )
        {
            ++$CHILD_COUNT;
        }
        $IS_LAZY = FALSE;
        if ( 0 < $CHILD_COUNT )
        {
            $JSON = "/inc/ext_dept_list/tree.php?DEPT_ID=".$DEPT_ID1."&MANAGE_FLAG={$MANAGE_FLAG}&PARA_URL={$PARA_URL}&PARA_TARGET={$PARA_TARGET}&PARA_ID={$PARA_ID}&PARA_VALUE={$PARA_VALUE}&showButton={$showButton}&MODULE_ID={$MODULE_ID}&STATE_FLAG={$STATE_FLAG}";
            $IS_LAZY = TRUE;
        }
        $ONCHECK = $showButton ? "click_node" : "";
        $DEPT_ARRAY[] = array( "title" => td_iconv( $DEPT_NAME, MYOA_CHARSET, "utf-8" ), "isFolder" => TRUE, "isLazy" => $IS_LAZY, "key" => "dept_".$DEPT_ID1, "dept_id" => $DEPT_ID1, "icon" => $ICON, "url" => td_iconv( $URL, MYOA_CHARSET, "utf-8" ), "tooltip" => td_iconv( $DEPT_NAME, MYOA_CHARSET, "utf-8" ), "json" => td_iconv( $JSON, MYOA_CHARSET, "utf-8" ), "target" => $TARGET, "onCheck" => $ONCHECK );
    }
    return $DEPT_ARRAY;
}

include_once( "inc/auth.inc.php" );
include_once( "inc/utility_org.php" );
include_once( "inc/utility_all.php" );
ob_end_clean( );
header( "Content-type: text/x-json; charset=".MYOA_CHARSET );
$PARENT_ID = $DEPT_ID;
$ORG_ARRAY = array( );
if ( $PARENT_ID == 0 )
{
    $ROOT_NAME = _( "�ⲿ��֯����" );
    $DEPT_ARRAY = deptlisttree( $PARENT_ID );
    $ORG_ARRAY = array( "title" => td_iconv( $ROOT_NAME, MYOA_CHARSET, "utf-8" ), "isFolder" => TRUE, "isLazy" => FALSE, "expand" => TRUE, "key" => "dept_0", "dept_id" => "0", "icon" => "root.png", "tooltip" => td_iconv( $ROOT_NAME, MYOA_CHARSET, "utf-8" ), "children" => $DEPT_ARRAY, "onCheck" => "" );
}
else
{
    $ORG_ARRAY = deptlisttree( $PARENT_ID );
}
echo json_encode( $ORG_ARRAY );
?>
