<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
include_once( "inc/auth.inc.php" );
include_once( "inc/header.inc.php" );
if ( !isset( $xtree_id ) || $xtree_id == "" )
{
    $xtree_id = "tree";
}
if ( !isset( $xtree ) || $xtree == "" )
{
    $xtree = "/inc/ext_dept_list/tree.php";
}
$xtree .= "?DEPT_ID=0&PARA_URL=".$PARA_URL."&e={$e}&PARA_TARGET={$PARA_TARGET}&PARA_ID={$PARA_ID}&PARA_VALUE={$PARA_VALUE}&showButton={$showButton}&MODULE_ID={$MODULE_ID}&STATE_FLAG={$STATE_FLAG}";
echo "<div id=\"";
echo $xtree_id;
echo "\"></div>\r\n<link rel=\"stylesheet\" type=\"text/css\" href=\"";
echo MYOA_STATIC_SERVER;
echo "/static/images/org/ui.dynatree.css";
echo $GZIP_POSTFIX;
echo "\">\r\n<script type=\"text/javascript\" src=\"/inc/js_lang.php\"></script>\r\n<script type=\"text/javascript\" src=\"";
echo MYOA_JS_SERVER;
echo "/static/js/tree.js";
echo $GZIP_POSTFIX;
echo "\"></script>\r\n<script type=\"text/javascript\">\r\n   var tree = new Tree(\"";
echo $xtree_id;
echo "\", \"";
echo $xtree;
echo "\", '";
echo MYOA_STATIC_SERVER;
echo "/static/images/ext_org/', ";
echo $showButton ? "true" : "false";
echo ", 3);\r\n   tree.BuildTree();\r\n</script>";
?>
