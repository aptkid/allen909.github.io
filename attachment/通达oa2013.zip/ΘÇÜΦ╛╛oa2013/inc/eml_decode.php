<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class eml_decode
{

    public $emlPath;
    public $Data;
    public $Mail;
    public $Charset;
    public $MailInfo = array( );

    public function __construct( $emlPath )
    {
        $this->Charset = MYOA_CHARSET;
        if ( !empty( $emlPath ) && file_exists( $emlPath ) )
        {
            $this->emlPath = $emlPath;
            $this->Data = file_get_contents( $emlPath );
        }
    }

    public function ParseData( )
    {
        require_once( "inc/PEAR/mimeDecode.php" );
        $Decoder = new Mail_mimeDecode( $this->Data );
        $params = array( "include_bodies" => TRUE, "decode_bodies" => TRUE, "decode_headers" => TRUE );
        $this->Mail = $Decoder->decode( $params );
        $this->Mail( $this->Mail );
    }

    public function ParseCharset( $Mail )
    {
        if ( empty( $Mail->parts ) )
        {
            $i = 0;
            for ( ; $i < count( $Mail->parts ); ++$i )
            {
            }
            else
            {
                $charset = $Mail->ctype_parameters['charset'];
                if ( !isset( $Mail->body ) || !( $Mail->ctype_primary == "text" ) || !( $Mail->ctype_secondary == "plain" ) && !( $Mail->ctype_secondary == "html" ) || !isset( $Mail->ctype_parameters['charset'] ) )
                {
                    $this->Charset = $Mail->ctype_parameters['charset'];
                }
            }
        }
        return FALSE;
    }

    public function ParseHeader( $headers )
    {
        foreach ( $headers as $key => $value )
        {
            if ( is_array( $value ) )
            {
                $i = 0;
                for ( ; $i < count( $value ); ++$i )
                {
                    $this->MailInfo[$key."_".$i] = iconv( $this->Charset, MYOA_CHARSET, $value[$i] );
                }
                else
                {
                    $this->MailInfo[$key] = iconv( $this->Charset, MYOA_CHARSET, $value );
                }
            }
        }
    }

    public function ParseBody( $Mail )
    {
        if ( empty( $Mail->parts ) )
        {
            $i = 0;
            for ( ; $i < count( $Mail->parts ); ++$i )
            {
                $Mail->parts[$i]( $Mail->parts[$i] );
            }
        }
        else
        {
            $charset = isset( $Mail->ctype_parameters['charset'] ) ? $Mail->ctype_parameters['charset'] : $this->Charset;
            if ( $Mail->disposition == "attachment" || $Mail->ctype_primary == "application" && $Mail->ctype_secondary == "octet-stream" )
            {
                $Mail->ctype_parameters['name'] = iconv( $charset, MYOA_CHARSET, $Mail->ctype_parameters['name'] );
                $this->MailInfo['attachments'][] = array( "name" => $Mail->ctype_parameters['name'], "body" => $Mail->body );
            }
            else
            {
                if ( !isset( $Mail->body ) || !( $Mail->ctype_primary == "text" ) || !( $Mail->ctype_secondary == "plain" ) && !( $Mail->ctype_secondary == "html" ) )
                {
                    $Mail->body = iconv( $charset, MYOA_CHARSET, $Mail->body );
                    $this->MailInfo['body'][$Mail->ctype_secondary] = $Mail->body;
                }
            }
        }
    }

    public function ParseMail( $data = "" )
    {
        if ( empty( $this->Data ) )
        {
            $this->Data = $data;
        }
        $this->ParseData( );
        $this->Mail->headers( $this->Mail->headers );
        $this->Mail( $this->Mail );
        return $this->MailInfo;
    }

}

include_once( "inc/td_config.php" );
?>
