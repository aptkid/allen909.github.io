<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
function random( $length, $numeric = 0 )
{
    if ( PHP_VERSION < "4.2.0" )
    {
    }
    if ( $numeric )
    {
        $hash = sprintf( "%0".$length."d", mt_rand( 1, pow( 10, $length ) - 1 ) );
        return $hash;
    }
    $hash = "";
    $chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";
    $max = strlen( $chars ) - 1;
    $i = 0;
    for ( ; $i < $length; ++$i )
    {
        $hash .= $chars[mt_rand( 0, $max )];
    }
    return $hash;
}

$SESSION_WRITE_CLOSE = 0;
include_once( "inc/auth.inc.php" );
include_once( "inc/header.inc.php" );
ob_clean( );
error_reporting( 0 );
if ( !$seccode || $update )
{
    $seccode = random( 4, 1 );
    $_SESSION['seccode'] = $seccode;
}
$width = "62";
$height = "24";
@header( "Expires: -1" );
@header( "Cache-Control: no-store, private, post-check=0, pre-check=0, max-age=0", FALSE );
@header( "Pragma: no-cache" );
if ( function_exists( "imagecreate" ) && function_exists( "imagecolorset" ) && function_exists( "imagecopyresized" ) && function_exists( "imagecolorallocate" ) && function_exists( "imagesetpixel" ) && function_exists( "imagechar" ) && function_exists( "imagecreatefromgif" ) && function_exists( "imagepng" ) )
{
    $im = imagecreate( $width, $height );
    $back = imagecolorallocate( $im, 255, 255, 255 );
    $border = imagecolorallocate( $im, 0, 0, 0 );
    imagefilledrectangle( $im, 0, 0, $width - 1, $height - 1, $back );
    imagerectangle( $im, 0, 0, $width - 1, $height - 1, $border );
    $i = 1;
    for ( ; $i <= 20; ++$i )
    {
        $dot = imagecolorallocate( $im, mt_rand( 50, 255 ), mt_rand( 50, 255 ), mt_rand( 50, 255 ) );
        imagesetpixel( $im, mt_rand( 2, $width - 2 ), mt_rand( 2, $height - 2 ), $dot );
    }
    $i = 1;
    for ( ; $i <= 10; ++$i )
    {
        imagestring( $im, 1, $i * $width / 12 + mt_rand( 1, 3 ), mt_rand( 1, 13 ), "*", imagecolorallocate( $im, mt_rand( 150, 255 ), mt_rand( 150, 255 ), mt_rand( 150, 255 ) ) );
    }
    $i = 0;
    for ( ; $i < strlen( $seccode ); ++$i )
    {
        imagestring( $im, mt_rand( 2, 5 ), $i * $width / 4 + mt_rand( 1, 5 ), mt_rand( 1, 6 ), $seccode[$i], imagecolorallocate( $im, mt_rand( 50, 255 ), mt_rand( 0, 120 ), mt_rand( 50, 255 ) ) );
    }
    header( "Pragma:no-cache" );
    header( "Cache-control:no-cache" );
    header( "Content-type: image/png" );
    imagepng( $im );
    imagedestroy( $im );
}
else
{
    $numbers = array( 0 => array( "3c", "66", "66", "66", "66", "66", "66", "66", "66", "3c" ), 1 => array( "1c", "0c", "0c", "0c", "0c", "0c", "0c", "0c", "1c", "0c" ), 2 => array( "7e", "60", "60", "30", "18", "0c", "06", "06", "66", "3c" ), 3 => array( "3c", "66", "06", "06", "06", "1c", "06", "06", "66", "3c" ), 4 => array( "1e", "0c", "7e", "4c", "2c", "2c", "1c", "1c", "0c", "0c" ), 5 => array( "3c", "66", "06", "06", "06", "7c", "60", "60", "60", "7e" ), 6 => array( "3c", "66", "66", "66", "66", "7c", "60", "60", "30", "1c" ), 7 => array( "30", "30", "18", "18", "0c", "0c", "06", "06", "66", "7e" ), 8 => array( "3c", "66", "66", "66", "66", "3c", "66", "66", "66", "3c" ), 9 => array( "38", "0c", "06", "06", "3e", "66", "66", "66", "66", "3c" ) );
    $i = 0;
    for ( ; $i < 10; ++$i )
    {
        $j = 0;
        for ( ; $j < 6; ++$j )
        {
            $a1 = substr( "012", mt_rand( 0, 2 ), 1 ).substr( "012345", mt_rand( 0, 5 ), 1 );
            $a2 = substr( "012345", mt_rand( 0, 5 ), 1 ).substr( "0123", mt_rand( 0, 3 ), 1 );
            mt_rand( 0, 1 ) == 1 ? array_push( &$numbers[$i], $a1 ) : array_unshift( &$numbers[$i], $a1 );
            mt_rand( 0, 1 ) == 0 ? array_push( &$numbers[$i], $a1 ) : array_unshift( &$numbers[$i], $a2 );
        }
    }
    $bitmap = array( );
    $i = 0;
    for ( ; $i < 20; ++$i )
    {
        $j = 0;
        for ( ; $j < 4; ++$j )
        {
            $n = substr( $seccode, $j, 1 );
            $bytes = $numbers[$n][$i];
            $a = mt_rand( 0, 14 );
            switch ( $a )
            {
                case 1 :
                    str_replace( "9", "8", $bytes );
                    break;
                case 3 :
                    str_replace( "c", "e", $bytes );
                    break;
                case 6 :
                    str_replace( "3", "b", $bytes );
                    break;
                case 8 :
                    str_replace( "8", "9", $bytes );
                    break;
                case 0 :
                    str_replace( "e", "f", $bytes );
            }
            array_push( &$bitmap, $bytes );
        }
    }
    $i = 0;
    for ( ; $i < 8; ++$i )
    {
        $a = substr( "012", mt_rand( 0, 2 ), 1 ).substr( "012345", mt_rand( 0, 5 ), 1 );
        array_unshift( &$bitmap, $a );
        array_push( &$bitmap, $a );
    }
    $image = pack( "H*", "424d9e000000000000003e0000002800000020000000180000000100010000000000600000000000000000000000000000000000000000000000FFFFFF00".implode( "", $bitmap ) );
    header( "Content-Type: image/bmp" );
    echo $image;
}
?>
