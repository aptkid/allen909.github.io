<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
function sess_open( $save_path, $session_name )
{
    return TRUE;
}

function sess_close( )
{
    return TRUE;
}

function sess_read( $id )
{
    $query = "select SESS_DATA from SESSION where SESS_ID='".$id."' and SESS_EXPIRES>='".time( )."'";
    $cursor = exequery( ( ), $query, TRUE );
    if ( $ROW = mysql_fetch_array( $cursor ) )
    {
        return $ROW['SESS_DATA'];
    }
    return "";
}

function sess_write( $id, $sess_data )
{
    $maxlifetime = intval( ini_get( "session.gc_maxlifetime" ) );
    $maxlifetime = 0 < $maxlifetime ? $maxlifetime : 36000;
    $sess_data = mysql_escape_string( $sess_data );
    $sess_data_size = strlen( $sess_data );
    if ( 5000 < $sess_data_size )
    {
        $sess_data_max_size = strtolower( MYOA_DB_CHARSET ) == "utf8" ? 21800 : 32700;
        if ( $sess_data_max_size < $sess_data_size )
        {
            $sess_data_size = $sess_data_max_size;
        }
        $query = "select SESS_DATA from SESSION limit 0,1";
        $cursor = exequery( ( ), $query, TRUE );
        $field_size = mysql_field_len( $cursor, 0 );
        $field_size = strtolower( MYOA_DB_CHARSET ) == "utf8" ? floor( $field_size / 3 ) : floor( $field_size / 2 );
        if ( $field_size < $sess_data_size )
        {
            $query = "alter table SESSION change SESS_DATA SESS_DATA varchar(".$sess_data_size.") not null;";
            exequery( ( ), $query, TRUE );
        }
    }
    $query = "select 1 from SESSION where SESS_ID='".$id."'";
    $cursor = exequery( ( ), $query, TRUE );
    if ( $ROW = mysql_fetch_array( $cursor ) )
    {
        $query = "update SESSION set SESS_EXPIRES='".( time( ) + $maxlifetime ).( "',SESS_DATA='".$sess_data."' where SESS_ID='{$id}';" );
        return exequery( ( ), $query, TRUE );
    }
    $query = "insert into SESSION (SESS_ID,SESS_EXPIRES,SESS_DATA) values ('".$id."','".( time( ) + $maxlifetime ).( "','".$sess_data."');" );
    return exequery( ( ), $query, TRUE );
}

function sess_destroy( $id )
{
    $query = "delete from SESSION where SESS_ID='".$id."'";
    return exequery( ( ), $query, TRUE );
}

function sess_gc( $maxlifetime )
{
    $query = "delete from SESSION where SESS_EXPIRES<'".time( )."'";
    return exequery( ( ), $query, TRUE );
}

include_once( "inc/conn.php" );
if ( MYOA_SESS_SAVE_HANDLER == "user" && session_module_name( ) != "user" )
{
    session_module_name( "user" );
    session_set_save_handler( "sess_open", "sess_close", "sess_read", "sess_write", "sess_destroy", "sess_gc" );
}
else
{
    if ( MYOA_SESS_SAVE_HANDLER == "memcache" && session_module_name( ) != "memcache" )
    {
        $SESS_SAVE_PATH = "";
        $I = 0;
        for ( ; $I < count( $MYOA_MEMCACHED_SERVERS ); ++$I )
        {
            $SESS_SAVE_PATH .= ",tcp://".$MYOA_MEMCACHED_SERVERS[$I]['host'].":".$MYOA_MEMCACHED_SERVERS[$I]['port']."?persistent=".( $MYOA_MEMCACHED_SERVERS[$I]['persistent'] ? "1" : "0" );
            if ( isset( $MYOA_MEMCACHED_SERVERS[$I]['weight'] ) )
            {
                $SESS_SAVE_PATH .= "&weight=".$MYOA_MEMCACHED_SERVERS[$I]['weight'];
            }
        }
        $SESS_SAVE_PATH = substr( $SESS_SAVE_PATH, 1 );
        session_module_name( "memcache" );
        session_save_path( $SESS_SAVE_PATH );
    }
}
?>
