<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class stringchange
{

    public function shr32( $x, $bits )
    {
        if ( $bits <= 0 )
        {
            return $x;
        }
        if ( 32 <= $bits )
        {
            return 0;
        }
        $bin = decbin( $x );
        $l = strlen( $bin );
        if ( 32 < $l )
        {
            $bin = substr( $bin, $l - 32, 32 );
        }
        else if ( $l < 32 )
        {
            $bin = str_pad( $bin, 32, "0", STR_PAD_LEFT );
        }
        return bindec( str_pad( substr( $bin, 0, 32 - $bits ), 32, "0", STR_PAD_LEFT ) );
    }

    public function byteArrayToShort( $b )
    {
        return ( $b[0] << 8 ) + ( $b[1] & 255 );
    }

    public function byteArrayToInt( $b )
    {
        return int32( $b[0] << 24 ) + ( ( $b[1] & 255 ) << 16 ) + ( ( $b[2] & 255 ) << 8 ) + ( $b[3] & 255 );
    }

    public function shortToByteArray( $s )
    {
        $shortBuf = array( 0, 0 );
        $i = 0;
        for ( ; $i < 2; ++$i )
        {
            $offset = ( 1 - $i ) * 8;
            $shortBuf[$i] = $this->shr32( $s, $offset ) & 255;
        }
        return $shortBuf;
    }

    public function intToByteArray( $value )
    {
        $b = array( 0, 0, 0, 0 );
        $i = 0;
        for ( ; $i < 4; ++$i )
        {
            $offset = ( 3 - $i ) * 8;
            $b[$i] = $this->shr32( $value, $offset ) & 255;
        }
        return $b;
    }

    public function toByte( $c )
    {
        $str = "0123456789ABCDEF";
        $i = 0;
        for ( ; $i < 16; ++$i )
        {
            if ( $str[$i] == $c )
            {
                return $i;
            }
        }
        return 0;
    }

    public function toByte2( $c )
    {
        $str = "0123456789ABCDEF";
        $i = 0;
        for ( ; $i < 16; ++$i )
        {
            if ( substr( $str, $i, 1 ) == $c )
            {
                return $i;
            }
        }
        return 0;
    }

    public function hexStringToByte( $hex )
    {
        $len = strlen( $hex );
        $result = array( );
        $achar = array( );
        $i = 0;
        for ( ; $i < $len; ++$i )
        {
            $achar[$i] = $hex[$i];
        }
        $i = 0;
        for ( ; $i < $len; ++$i )
        {
            $pos = $i * 2;
            $result[$i] = $achar[$pos]( $achar[$pos] ) << 4 | $achar[$pos + 1]( $achar[$pos + 1] );
        }
        return $result;
    }

    public function hexStringToByte2( $hex )
    {
        $len = strlen( $hex );
        $result = array( );
        $achar = array( );
        $i = 0;
        for ( ; $i < $len; ++$i )
        {
            $achar[$i] = substr( $hex, $i, 1 );
        }
        $i = 0;
        for ( ; $i < $len / 2; ++$i )
        {
            $pos = $i * 2;
            $result[$i] = $achar[$pos]( $achar[$pos] ) * 16 + $achar[$pos + 1]( $achar[$pos + 1] );
        }
        return $result;
    }

    public function bytesToHexString( $bArray )
    {
        $sb = "";
        $i = 0;
        for ( ; $i < count( $bArray ); ++$i )
        {
            $sTemp = dechex( $bArray[$i] );
            if ( strlen( $sTemp ) < 2 )
            {
                $sTemp = "0".$sTemp;
            }
            $sb .= $sTemp;
        }
        return strtoupper( $sb );
    }

}

class tea
{

    public function shr32( $x, $bits )
    {
        if ( $bits <= 0 )
        {
            return $x;
        }
        if ( 32 <= $bits )
        {
            return 0;
        }
        $bin = decbin( $x );
        $l = strlen( $bin );
        if ( 32 < $l )
        {
            $bin = substr( $bin, $l - 32, 32 );
        }
        else if ( $l < 32 )
        {
            $bin = str_pad( $bin, 32, "0", STR_PAD_LEFT );
        }
        return bindec( str_pad( substr( $bin, 0, 32 - $bits ), 32, "0", STR_PAD_LEFT ) );
    }

    public function encrypt( $content, $offset, $key, $times )
    {
        $a1 = array( 0, 0, 0, 0 );
        $a2 = array( 0, 0, 0, 0 );
        $a = 0;
        for ( ; $a < 4; ++$a )
        {
            $a1[$a] = $content[$a + $offset];
        }
        $a = 0;
        for ( ; $a < 4; ++$a )
        {
            $a2[$a] = $content[$a + 4 + $offset];
        }
        $tempInt = array( 0, 0 );
        $sg = new stringchange( );
        $tempInt[0] = $sg->byteArrayToInt( $a1 );
        $tempInt[1] = $sg->byteArrayToInt( $a2 );
        $y = int32( $tempInt[0] );
        $z = int32( $tempInt[1] );
        $sum = 0;
        $delta = 2.65444e+009;
        $a = $key[0];
        $b = $key[1];
        $c = $key[2];
        $d = $key[3];
        if ( $delta < 0 )
        {
            $delta += 4.29497e+009;
        }
        $templong = 0;
        $tempz = 0;
        $tempz2 = 0;
        $i = 0;
        for ( ; $i < $times; ++$i )
        {
            $sum += $delta;
            if ( $sum < 0 )
            {
                $sum += 4.29497e+009;
            }
            if ( 4.29497e+009 < $sum )
            {
                $sum -= 4.29497e+009;
            }
            $z1 = int32( $z1 );
            $z2 = int32( $z2 );
            $z3 = int32( $z3 );
            $y1 = int32( $y1 );
            $y2 = int32( $y2 );
            $y3 = int32( $y3 );
            $y4 = int32( $y4 );
            $y1 = $z << 4;
            if ( $y1 < 0 )
            {
                $templong = $y1 + 4.29497e+009;
            }
            else
            {
                $templong = $y1;
            }
            $y1 = int32( $templong + $a );
            $templong = $z + $sum;
            $y2 = int32( $templong );
            $y3 = $this->shr32( $z, 5 );
            if ( $y3 < 0 )
            {
                $templong = $y3 + 4.29497e+009;
            }
            else
            {
                $templong = $y3;
            }
            $tempz = $templong + $b;
            if ( 4.29497e+009 < $tempz )
            {
                $tempz -= 4.29497e+009;
            }
            $y3 = int32( $tempz );
            $y4 = $y1 ^ $y2 ^ $y3;
            if ( $y4 < 0 )
            {
                $tempz2 = $y4 + 4.29497e+009;
            }
            else
            {
                $tempz2 = $y4;
            }
            if ( $y < 0 )
            {
                $templong = $y + 4.29497e+009;
            }
            else
            {
                $templong = $y;
            }
            $templong += $tempz2;
            if ( 4.29497e+009 < $templong )
            {
                $templong -= 4.29497e+009;
            }
            $y = int32( $templong );
            $z1 = $y << 4;
            if ( $z1 < 0 )
            {
                $templong = $z1 + 4.29497e+009;
            }
            else
            {
                $templong = $z1;
            }
            $templong += $c;
            if ( 4.29497e+009 < $templong )
            {
                $templong -= 4.29497e+009;
            }
            $z1 = int32( $templong );
            $templong = $y;
            if ( $templong < 0 )
            {
                $templong += 4.29497e+009;
            }
            $templong += $sum;
            if ( $templong < 0 )
            {
                $templong += 4.29497e+009;
            }
            if ( 4.29497e+009 < templong )
            {
                $templong -= 4.29497e+009;
            }
            $z2 = int32( $templong );
            $z3 = $this->shr32( $y, 5 );
            if ( $z3 < 0 )
            {
                $templong = $z3 + 4.29497e+009;
            }
            else
            {
                $templong = $z3;
            }
            $templong += $d;
            if ( 4.29497e+009 < $templong )
            {
                $templong -= 4.29497e+009;
            }
            $z3 = int32( $templong );
            $tempz = $z;
            if ( $tempz < 0 )
            {
                $tempz += 4.29497e+009;
            }
            if ( 4.29497e+009 < $tempz )
            {
                $tempz -= 4.29497e+009;
            }
            $z4 = 0;
            $z4 = $z1 ^ $z2 ^ $z3;
            if ( $z4 < 0 )
            {
                $templong = $z4 + 4.29497e+009;
            }
            else
            {
                $templong = $z4;
            }
            $tempz += $templong;
            if ( 4.29497e+009 < $tempz )
            {
                $tempz -= 4.29497e+009;
            }
            $z = int32( $tempz );
        }
        if ( $y < 0 )
        {
            $templong = $y + 4.29497e+009;
        }
        else
        {
            $templong = $y;
        }
        $tempInt[0] = int32( $this->TEA_ntoh( $templong, TRUE ) );
        if ( $z < 0 )
        {
            $templong = $z + 4.29497e+009;
        }
        else
        {
            $templong = $z;
        }
        $tempInt[1] = int32( $this->TEA_ntoh( $templong, TRUE ) );
        return $this->ByteToByte( $this->intToByte( $tempInt, 0 ) );
    }

    public function decrypt( $encryptContent, $offset, $key, $times )
    {
        $a1 = array( 0, 0, 0, 0 );
        $a2 = array( 0, 0, 0, 0 );
        $a = 0;
        for ( ; $a < 4; ++$a )
        {
            $a1[$a] = $encryptContent[$a + $offset];
        }
        $a = 0;
        for ( ; $a < 4; ++$a )
        {
            $a2[$a] = $encryptContent[$a + 4 + $offset];
        }
        $tempInt = array( 0, 0 );
        $sg = new stringchange( );
        $tempInt[0] = $sg->byteArrayToInt( $a1 );
        $tempInt[1] = $sg->byteArrayToInt( $a2 );
        $y = int32( $tempInt[0] );
        $z = int32( $tempInt[1] );
        $sum = 3.81627e+009;
        $delta = 2.65444e+009;
        $a = $key[0];
        $b = $key[1];
        $c = $key[2];
        $d = $key[3];
        if ( $sum < 0 )
        {
            $sum += 4.29497e+009;
        }
        if ( $delta < 0 )
        {
            $delta += 4.29497e+009;
        }
        $templong = 0;
        $tempz = 0;
        $tempz2 = 0;
        $z1 = 0;
        $z2 = 0;
        $z3 = 0;
        $y1 = 0;
        $y2 = 0;
        $y3 = 0;
        $y4 = 0;
        $i = 0;
        for ( ; $i < $times; ++$i )
        {
            $z1 = int32( $z1 );
            $z2 = int32( $z2 );
            $z3 = int32( $z3 );
            $z1 = $y << 4;
            if ( $z1 < 0 )
            {
                $templong = $z1 + 4.29497e+009;
            }
            else
            {
                $templong = $z1;
            }
            $z1 = int32( $templong + $c );
            $templong = $y;
            if ( $templong < 0 )
            {
                $templong += 4.29497e+009;
            }
            $templong += $sum;
            if ( $templong < 0 )
            {
                $templong += 4.29497e+009;
            }
            $z2 = int32( $templong );
            $z3 = $this->shr32( $y, 5 );
            if ( $z3 < 0 )
            {
                $templong = $z3 + 4.29497e+009;
            }
            else
            {
                $templong = $z3;
            }
            $z3 = int32( $templong + $d );
            $tempz = $z;
            if ( $tempz < 0 )
            {
                $tempz += 4.29497e+009;
            }
            $z4 = 0;
            $z4 = $z1 ^ $z2 ^ $z3;
            if ( $z4 < 0 )
            {
                $templong = $z4 + 4.29497e+009;
            }
            else
            {
                $templong = $z4;
            }
            $tempz -= $templong;
            $z = int32( $tempz );
            $y1 = int32( $y1 );
            $y2 = int32( $y2 );
            $y3 = int32( $y3 );
            $y4 = int32( $y4 );
            $y1 = $z << 4;
            if ( $y1 < 0 )
            {
                $templong = $y1 + 4.29497e+009;
            }
            else
            {
                $templong = $y1;
            }
            $y1 = int32( $templong + $a );
            $templong = $z + $sum;
            $y2 = int32( $templong );
            $y3 = $this->shr32( $z, 5 );
            if ( $y3 < 0 )
            {
                $templong = $y3 + 4.29497e+009;
            }
            else
            {
                $templong = $y3;
            }
            $tempz = $templong + $b;
            $y3 = int32( $tempz );
            $y4 = $y1 ^ $y2 ^ $y3;
            if ( $y4 < 0 )
            {
                $tempz2 = $y4 + 4.29497e+009;
            }
            else
            {
                $tempz2 = $y4;
            }
            if ( $y < 0 )
            {
                $templong = $y + 4.29497e+009;
            }
            else
            {
                $templong = $y;
            }
            $y = int32( $templong - $tempz2 );
            $sum -= $delta;
            if ( $sum < 0 )
            {
                $sum += 4.29497e+009;
            }
        }
        if ( $y < 0 )
        {
            $templong = $y + 4.29497e+009;
        }
        else
        {
            $templong = $y;
        }
        $tempInt[0] = int32( $this->TEA_ntoh( $templong, TRUE ) );
        if ( $z < 0 )
        {
            $templong = $z + 4.29497e+009;
        }
        else
        {
            $templong = $z;
        }
        $tempInt[1] = int32( $this->TEA_ntoh( $templong, TRUE ) );
        return $this->ByteToByte( $this->intToByte( $tempInt, 0 ) );
    }

    public function TEA_ntoh( $netlong, $_isNetByte )
    {
        $x = ( $netlong & 255 ) << 24;
        $x |= ( $netlong & 65280 ) << 8;
        $x |= $this->shr32( $netlong & 16711680, 8 );
        $x |= $this->shr32( $netlong & 4.27819e+009, 24 );
        if ( $_isNetByte )
        {
            return $x;
        }
        return $netlong;
    }

    public function byteToInt( $content, $offset )
    {
        $result = array( );
        $i = 0;
        $j = $offset;
        for ( ; $j < count( content ); ++$i, $j += 4 )
        {
            $result[$i] = transform( $content[$j + 3] ) | transform( $content[$j + 2] ) << 8 | transform( $content[$j + 1] ) << 16 | int32( $content[j] << 24 );
        }
        return $result;
    }

    public function ByteToByte( $b )
    {
        $i = count( $b );
        if ( $i % 4 != 0 )
        {
            return $b;
        }
        $re = array( );
        $j = 0;
        while ( $j < count( $b ) )
        {
            $re[$j] = $b[$j + 3];
            $re[$j + 1] = $b[$j + 2];
            $re[$j + 2] = $b[$j + 1];
            $re[$j + 3] = $b[$j];
            $j += 4;
        }
        return $re;
    }

    public function intToByte( $content, $offset )
    {
        $result = array( );
        $i = 0;
        $j = $offset;
        for ( ; $j < count( $content ) << 2; ++$i, $j += 4 )
        {
            $result[$j + 3] = $content[$i] & 255;
            $result[$j + 2] = $content[$i] >> 8 & 255;
            $result[$j + 1] = $content[$i] >> 16 & 255;
            $result[$j] = $content[$i] >> 24 & 255;
        }
        return $result;
    }

    public function transform( $temp )
    {
        $tempInt = int32( $temp );
        if ( $tempInt < 0 )
        {
            $tempInt += 256;
        }
        return $tempInt;
    }

    public function encryptByTea( $info )
    {
        $KEY = array( 1952801070, 778923887, 1848520307, 1700867630 );
        $result = array( );
        $offset = 0;
        for ( ; $offset < count( $info ); $offset += 8 )
        {
            $tempEncrpt = $this->encrypt( $info, $offset, $KEY, 16 );
            $j = 0;
            for ( ; $j < 8; ++$j )
            {
                $result[$offset + $j] = $tempEncrpt[$j];
            }
        }
        return $result;
    }

    public function decryptByTea( $secretInfo )
    {
        $result = array( );
        $KEY = array( 1952801070, 778923887, 1848520307, 1700867630 );
        $offset = 0;
        for ( ; $offset < count( $secretInfo ); $offset += 8 )
        {
            $decryptStr = $this->decrypt( $secretInfo, $offset, $KEY, 16 );
            $j = 0;
            for ( ; $j < 8; ++$j )
            {
                $result[$offset + $j] = $decryptStr[$j];
            }
        }
        return $result;
    }

}

class otpdatetime
{

    public $year;
    public $month;
    public $day;
    public $hour;
    public $minute;
    public $second;

    public function __construct( )
    {
        $this->year = 2009;
        $this->month = 1;
        $this->day = 1;
        $this->hour = 0;
        $this->minute = 0;
        $this->second = 0;
    }

    public function getdatetimeString( )
    {
        return $this->year."-".$this->month."-".$this->day." ".$this->hour.":".$this->minute.":".$this->second;
    }

}

class tokeninfo
{

    public $KeyLen;
    public $Key;
    public $InitTimeYear;
    public $InitTimeMonth;
    public $InitTimeDay;
    public $InitTimeHour;
    public $InitTimeMinute;
    public $InitTimeSecond;
    public $LastLoginTotalMovingValue;
    public $LastLoginSecond;
    public $TokenTimeOffsetMinute;
    public $TokenTimeOffsetSecond;
    public $OTPType;
    public $OTPChangeTime;
    public $OTPCheckPassType;
    public $othersByte;

    public function __construct( )
    {
        $this->KeyLen = 0;
        $this->Key = array( 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 );
        $this->InitTimeYear = 0;
        $this->InitTimeMonth = 0;
        $this->InitTimeDay = 0;
        $this->InitTimeHour = 0;
        $this->InitTimeMinute = 0;
        $this->InitTimeSecond = 0;
        $this->LastLoginTotalMovingValue = 0;
        $this->LastLoginSecond = 0;
        $this->TokenTimeOffsetMinute = 0;
        $this->TokenTimeOffsetSecond = 0;
        $this->OTPType = 0;
        $this->OTPChangeTime = 0;
        $this->OTPCheckPassType = 0;
        $this->othersByte = array( 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 );
    }

    public function settokeninfo( $info )
    {
        $sg = new stringchange( );
        $k = array( 0, 0 );
        $k[0] = $info[1];
        $k[1] = $info[0];
        $this->KeyLen = $sg->byteArrayToShort( $k );
        $i = 0;
        $i = 0;
        for ( ; $i < $this->KeyLen; ++$i )
        {
            $this->Key[$i] = $info[$i + 2];
        }
        $k[0] = $info[53];
        $k[1] = $info[52];
        $this->InitTimeYear = $sg->byteArrayToShort( $k );
        $this->InitTimeMonth = $info[54];
        $this->InitTimeDay = $info[55];
        $this->InitTimeHour = $info[56];
        $this->InitTimeMinute = $info[57];
        $this->InitTimeSecond = $info[58];
        $k1 = array( 0, 0, 0, 0 );
        $k1[0] = $info[62];
        $k1[1] = $info[61];
        $k1[2] = $info[60];
        $k1[3] = $info[59];
        $this->LastLoginTotalMovingValue = $sg->byteArrayToInt( $k1 );
        $this->LastLoginSecond = $info[63];
        $k1[0] = $info[67];
        $k1[1] = $info[66];
        $k1[2] = $info[65];
        $k1[3] = $info[64];
        $this->TokenTimeOffsetMinute = $sg->byteArrayToInt( $k1 );
        $this->TokenTimeOffsetSecond = $info[68];
        $this->OTPType = $info[69];
        $this->OTPChangeTime = $info[70];
        $this->OTPCheckPassType = $info[71];
        $i = 0;
        for ( ; $i < 48; ++$i )
        {
            $this->othersByte[$i] = $info[$i + 72];
        }
        return $this;
    }

    public function gettokeninfo( $stinfo )
    {
        $sg = new stringchange( );
        $info[] = array( 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 );
        $k = array( 0, 0, 0, 0 );
        $sk = array( 0, 0 );
        $sk = $stinfo->KeyLen( $stinfo->KeyLen );
        $info[0] = $sk[1];
        $info[1] = $sk[0];
        $i = 0;
        for ( ; $i < 50; ++$i )
        {
            $info[$i + 2] = $stinfo->Key[$i];
        }
        $sk = $stinfo->InitTimeYear( $stinfo->InitTimeYear );
        $info[52] = $sk[1];
        $info[53] = $sk[0];
        $info[54] = $stinfo->InitTimeMonth;
        $info[55] = $stinfo->InitTimeDay;
        $info[56] = $stinfo->InitTimeHour;
        $info[57] = $stinfo->InitTimeMinute;
        $info[58] = InitTimeSecond < stinfo;
        $k = $stinfo->LastLoginTotalMovingValue( $stinfo->LastLoginTotalMovingValue );
        $info[59] = $k[3];
        $info[60] = $k[2];
        $info[61] = $k[1];
        $info[62] = $k[0];
        $info[63] = $stinfo->LastLoginSecond;
        $k = $stinfo->TokenTimeOffsetMinute( $stinfo->TokenTimeOffsetMinute );
        $info[64] = $k[3];
        $info[65] = $k[2];
        $info[66] = $k[1];
        $info[67] = $k[0];
        $info[68] = $stinfo->TokenTimeOffsetSecond;
        $info[69] = $stinfo->OTPType;
        $info[70] = $stinfo->OTPChangeTime;
        $info[71] = $stinfo->OTPCheckPassType;
        $i = 0;
        for ( ; $i < 48; ++$i )
        {
            $info[$i + 72] = $stinfo->othersByte[$i];
        }
        return $info;
    }

}

class seamoonapi
{

    public function ConvertHex2Bin( $hexdata )
    {
        $bindata = "";
        $i = 0;
        for ( ; $i < strlen( $hexdata ); $i += 2 )
        {
            $bindata .= chr( hexdec( substr( $hexdata, $i, 2 ) ) );
        }
        return $bindata;
    }

    public function HashHmac( $algo, $data, $key, $raw_output = FALSE )
    {
        $algo = strtolower( $algo );
        $pack = "H".strlen( $algo( "test" ) );
        $size = 64;
        $opad = str_repeat( chr( 92 ), $size );
        $ipad = str_repeat( chr( 54 ), $size );
        if ( $size < strlen( $key ) )
        {
            $key = str_pad( pack( $pack, $algo( $key ) ), $size, chr( 0 ) );
        }
        else
        {
            $key = str_pad( $key, $size, chr( 0 ) );
        }
        $i = 0;
        for ( ; $i < strlen( $key ) - 1; ++$i )
        {
            $opad[$i] = $opad[$i] ^ $key[$i];
            $ipad[$i] = $ipad[$i] ^ $key[$i];
        }
        $output = $algo( $opad.pack( $pack, $algo( $ipad.$data ) ) );
        if ( $raw_output )
        {
            return pack( $pack, $output );
        }
        return $output;
    }

    public function ComputeOathTruncate( $hash, $length = 6 )
    {
        foreach ( str_split( $hash, 2 ) as $hex )
        {
            $hmac_result[] = hexdec( $hex );
        }
        $offset = $hmac_result[19] & 15;
        return substr( str_repeat( "0", $length ).( ( $hmac_result[$offset + 0] & 127 ) << 24 | ( $hmac_result[$offset + 1] & 255 ) << 16 | ( $hmac_result[$offset + 2] & 255 ) << 8 | $hmac_result[$offset + 3] & 255 ) % pow( 10, $length ), 0 - $length );
    }

    public function ComputeOathTOTP( $key, $counter )
    {
        $cur_counter = array( 0, 0, 0, 0, 0, 0, 0, 0 );
        $i = 7;
        for ( ; 0 <= $i; --$i )
        {
            $cur_counter[$i] = pack( "C*", $counter );
            $counter >>= 8;
        }
        $bin_counter = implode( $cur_counter );
        if ( strlen( $bin_counter ) < 8 )
        {
            $bin_counter = str_repeat( chr( 0 ), 8 - strlen( $bin_counter ) ).$bin_counter;
        }
        $hash = $this->HashHmac( "sha1", $bin_counter, $key );
        return $hash;
    }

    public function GetOTPPassword( $key, $timesecond, $interval, $passwordlen )
    {
        $i = 0;
        for ( ; $i < count( $key ); ++$i )
        {
            $seed_bin .= chr( $key[$i] );
        }
        $password_len = $passwordlen;
        $timer = intval( $timesecond / $interval );
        return $this->ComputeOathTruncate( $this->ComputeOathTOTP( $seed_bin, $timer ), $password_len );
    }

    public function getOTPpassword2( $key, $interval, $passwordlen, $itimes )
    {
        $i = 0;
        for ( ; $i < count( $key ); ++$i )
        {
            $seed_bin .= chr( $key[$i] );
        }
        $password_len = $passwordlen;
        return $this->ComputeOathTruncate( $this->ComputeOathTOTP( $seed_bin, $itimes ), $password_len );
    }

    public function CheckOTPpassword( $key, $interval, $passwordlen, $password, $itimes )
    {
        $timesecond = time( );
        if ( $password == $this->GetOTPPassword( $key, $timesecond + $itimes * $interval, $interval, $passwordlen ) )
        {
            return 1;
        }
        return 0;
    }

    public function ITSecurity_CheckCB_v6( $pCB )
    {
        $strSeamoon = "KingKey20050328.88888888889999999999";
        $iCBLen = strlen( $pCB );
        $j = 0;
        $cTmpCB = trim( $pCB );
        $pCB = $cTmpCB;
        $iCBLen = strlen( $pCB );
        if ( substr( $pCB, 6, 1 ) == "6" )
        {
            if ( $iCBLen != 291 )
            {
                return -1;
            }
            $cMd5InputStr = $strSeamoon;
            $totoa_md5StrLen = strlen( $strSeamoon );
            $cMd5InputStr .= substr( $pCB, 0, 17 );
            $totoa_md5StrLen += 17;
            $cMd5InputStr .= substr( $pCB, 49, strlen( $pCB ) );
            $totoa_md5StrLen += 242;
            $cMd5ResultStr = strtoupper( md5( $cMd5InputStr ) );
            if ( substr( $pCB, 17, 32 ) == $cMd5ResultStr )
            {
                return 1;
            }
            return -1;
        }
        return -1;
    }

    public function KingKey_HOTP_GetInfoFromCB( $pInitCB )
    {
        if ( strlen( $pInitCB ) != 291 )
        {
            return 0;
        }
        $tmpByteInit = array( 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 );
        $tmpByteResult = array( 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 );
        $tmpStr = substr( $pInitCB, 49, 289 );
        $t = new tea( );
        $cg = new stringchange( );
        $tmpByteInit = $cg->hexStringToByte( $tmpStr );
        $tmpByteResult = $t->decryptByTea( $tmpByteInit );
        $tinfo = new tokeninfo( );
        $tinfo = $tinfo->settokeninfo( $tmpByteResult );
        return $tinfo;
    }

    public function KingKey_HOTP_GetNewCB( $pcInitCB, $stTokenInfo )
    {
        $pcResultCB = $pcInitCB;
        $tmpByteInit = array( 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 );
        $tmpByteResult = array( 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 );
        $tmpByteInit = $stTokenInfo->gettokeninfo( $stTokenInfo );
        $i = 0;
        while ( $i < count( $tmpByteInit ) )
        {
            ++$i;
        }
        $t = new tea( );
        $tmpByteResult = $t->encryptByTea( $tmpByteInit );
        $cg = new stringchange( );
        $tmpStr = $cg->bytesToHexString( $tmpByteResult );
        $pcResultCB = substr( $pcInitCB, 0, 49 ).$tmpStr."==";
        $strSNStringKey = "KingKey20050328.88888888889999999999";
        $cMd5InputStr = $strSNStringKey;
        $cMd5InputStr .= substr( $pcInitCB, 0, 17 );
        $cMd5InputStr .= substr( $pcResultCB, 49, 289 );
        $cMd5ResultStr = strtoupper( md5( $cMd5InputStr ) );
        $pcResultCB = substr( $pcResultCB, 0, 17 ).$cMd5ResultStr.substr( $pcResultCB, 49, 291 );
        return $pcResultCB;
    }

    public function KingKey_HOTP_GetSpaceDayBetweenLastTime( $SpaceMovingValue, $IntervalInSecond )
    {
        if ( $SpaceMovingValue <= 0 )
        {
            return 0;
        }
        if ( $IntervalInSecond != 60 && $IntervalInSecond != 30 && $IntervalInSecond != 20 )
        {
            return 0;
        }
        $lTotalSeconds = $SpaceMovingValue * $IntervalInSecond;
        $TotalDays = ( integer )( $lTotalSeconds / 86400 );
        return $TotalDays;
    }

    public function GetTotalMovingValueOfNow( $IntervalInSecond )
    {
        $TotalMovingValue = 0;
        $iTotalSeconds = 0;
        if ( $IntervalInSecond != 60 && $IntervalInSecond != 30 && $IntervalInSecond != 20 )
        {
            return 0;
        }
        $TotalMovingValue = ( integer )( time( ) / $IntervalInSecond );
        return $TotalMovingValue;
    }

    public function checkpassword( $pInitCB, $pPassword )
    {
        $stHotpInfo = new tokeninfo( );
        $OTPCompareResul = 1;
        $sg = new stringchange( );
        if ( $pInitCB == "" || $pPassword == "" )
        {
            return "-1";
        }
        if ( strlen( $pInitCB ) < 200 )
        {
            return "-1";
        }
        if ( substr( $pInitCB, 6, 1 ) == "7" )
        {
            $seaotp = new seamoonsea( );
            return $seaotp->checkpasswordsea( $pInitCB, $pPassword );
        }
        $checkInitCBResult = $this->ITSecurity_CheckCB_v6( $pInitCB );
        $pResultCB = $pInitCB;
        if ( $checkInitCBResult != 1 )
        {
            return "-1";
        }
        if ( $pInitCB[6] != "6" )
        {
            return "-1";
        }
        if ( strlen( $pPassword ) != 6 && strlen( $pPassword ) != 8 )
        {
            return "300";
        }
        $stHotpInfo = $this->KingKey_HOTP_GetInfoFromCB( $pInitCB );
        if ( $stHotpInfo == "" )
        {
            return "-1";
        }
        $lTotalMovingValue = $stHotpInfo->OTPChangeTime( $stHotpInfo->OTPChangeTime );
        $iLastTimebettwenDays = $stHotpInfo->OTPChangeTime( $lTotalMovingValue - $stHotpInfo->LastLoginTotalMovingValue, $stHotpInfo->OTPChangeTime );
        if ( $iLastTimebettwenDays <= 30 )
        {
            $iTimeWindow = 5;
        }
        else if ( 30 < $iLastTimebettwenDays && $iLastTimebettwenDays <= 90 )
        {
            $iTimeWindow = 10;
        }
        else if ( 90 < $iLastTimebettwenDays && $iLastTimebettwenDays <= 180 )
        {
            $iTimeWindow = 15;
        }
        else if ( 180 < $iLastTimebettwenDays && $iLastTimebettwenDays <= 360 )
        {
            $iTimeWindow = 30;
        }
        else
        {
            $iTimeWindow = 45;
        }
        if ( $stHotpInfo->OTPChangeTime == 30 )
        {
            $iTimeWindow *= 2;
        }
        else if ( $stHotpInfo->OTPChangeTime == 20 )
        {
            $iTimeWindow *= 3;
        }
        else if ( $stHotpInfo->OTPChangeTime == 60 )
        {
            $iTimeWindow = $iTimeWindow;
        }
        else
        {
            return "300";
        }
        if ( $stHotpInfo->OTPType == 1 )
        {
            $OTPLen = 6;
        }
        else
        {
            $OTPLen = 8;
        }
        $i = 0 - 1 * $iTimeWindow;
        for ( ; $i < $iTimeWindow; ++$i )
        {
            if ( $lTotalMovingValue + $i <= $stHotpInfo->LastLoginTotalMovingValue || !( $stHotpInfo->OTPChangeTime( $stHotpInfo->Key, $stHotpInfo->OTPChangeTime, $OTPLen, $pPassword, $stHotpInfo->TokenTimeOffsetMinute + $i ) == 1 ) )
            {
                $stHotpInfo->TokenTimeOffsetMinute = $stHotpInfo->TokenTimeOffsetMinute + $i;
                $stHotpInfo->LastLoginTotalMovingValue = $lTotalMovingValue;
                $pResultCB = $this->KingKey_HOTP_GetNewCB( $pInitCB, $stHotpInfo );
                return $pResultCB;
            }
        }
        return 0;
    }

    public function passwordsyn( $pInitCB, $pPassword )
    {
        $stHotpInfo = new tokeninfo( );
        $OTPCompareResul = 1;
        $sg = new stringchange( );
        if ( $pInitCB == "" || $pPassword == "" )
        {
            return "-1";
        }
        if ( substr( $pInitCB, 6, 1 ) == "7" )
        {
            $seaotp = new seamoonsea( );
            return $seaotp->passwordsynsea( $pInitCB, $pPassword );
        }
        $checkInitCBResult = $this->ITSecurity_CheckCB_v6( $pInitCB );
        $pResultCB = $pInitCB;
        if ( $checkInitCBResult != 1 )
        {
            return "-1";
        }
        if ( $pInitCB[6] != "6" )
        {
            return "-1";
        }
        if ( strlen( $pPassword ) != 6 && strlen( $pPassword ) != 8 )
        {
            return "300";
        }
        $stHotpInfo = $this->KingKey_HOTP_GetInfoFromCB( $pInitCB );
        if ( $stHotpInfo == "" )
        {
            return "-1";
        }
        $lTotalMovingValue = $stHotpInfo->OTPChangeTime( $stHotpInfo->OTPChangeTime );
        $iLastTimebettwenDays = $stHotpInfo->OTPChangeTime( $lTotalMovingValue - $stHotpInfo->LastLoginTotalMovingValue, $stHotpInfo->OTPChangeTime );
        if ( $iLastTimebettwenDays <= 540 )
        {
            $iTimeWindow = 60;
        }
        else
        {
            $iTimeWindow = 90;
        }
        if ( $stHotpInfo->OTPChangeTime == 30 )
        {
            $iTimeWindow *= 2;
        }
        else if ( $stHotpInfo->OTPChangeTime == 20 )
        {
            $iTimeWindow *= 3;
        }
        else if ( $stHotpInfo->OTPChangeTime == 60 )
        {
            $iTimeWindow = $iTimeWindow;
        }
        else
        {
            return "300";
        }
        if ( $stHotpInfo->OTPType == 1 )
        {
            $OTPLen = 6;
        }
        else
        {
            $OTPLen = 8;
        }
        $i = 0 - 1 * $iTimeWindow;
        for ( ; $i < $iTimeWindow; ++$i )
        {
            if ( $lTotalMovingValue + $i <= $stHotpInfo->LastLoginTotalMovingValue || !( $stHotpInfo->OTPChangeTime( $stHotpInfo->Key, $stHotpInfo->OTPChangeTime, $OTPLen, $pPassword, $stHotpInfo->TokenTimeOffsetMinute + $i ) == 1 ) )
            {
                $stHotpInfo->TokenTimeOffsetMinute = $stHotpInfo->TokenTimeOffsetMinute + $i;
                $stHotpInfo->LastLoginTotalMovingValue = $lTotalMovingValue;
                $pResultCB = $this->KingKey_HOTP_GetNewCB( $pInitCB, $stHotpInfo );
                return $pResultCB;
            }
        }
        return 0;
    }

}

class seamoonsea
{

    public function checkcb( $pcb )
    {
        if ( strlen( $pcb ) != 400 )
        {
            return -1;
        }
        $cMd5InputStr = "ShenzhenSeamoonCommunicationTechnologyCo,Ltd,20050328.88888888889999999999";
        $cMd5InputStr = $cMd5InputStr.substr( $pcb, 0, 49 ).substr( $pcb, 81, strlen( $pcb ) );
        if ( substr( $pcb, 49, 32 ) == strtoupper( md5( $cMd5InputStr ) ) )
        {
            return 1;
        }
        return -1;
    }

    public function checkpasswordsea( $pcb, $password )
    {
        if ( $this->checkcb( $pcb ) != 1 )
        {
            reutrn - 1;
        }
        $pResultCB = array( );
        $tempk = 0;
        for ( ; $tempk < strlen( $pcb ); ++$tempk )
        {
            $pResultCB[$tempk] = substr( $pcb, $tempk, 1 );
        }
        $InitDayTime = new otpdatetime( );
        $LastDayTime = new otpdatetime( );
        $stNow = new otpdatetime( );
        $iKeyLen = ( ord( substr( $pcb, 91, 1 ) ) - 48 ) * 100 + ( ord( substr( $pcb, 92, 1 ) ) - 48 ) * 10 + ( ord( substr( $pcb, 93, 1 ) ) - 48 );
        $i = 0;
        for ( ; $i < 5; ++$i )
        {
            $pucKey[$i] = substr( $pcb, 94 + $i, 1 );
        }
        $i = 0;
        for ( ; $i < $iKeyLen - 5; ++$i )
        {
            $pucKey[$i + 5] = substr( $pcb, 124 + $i, 1 );
        }
        $stNow->year = date( "Y" );
        $stNow->month = date( "m" );
        $stNow->day = date( "d" );
        $stNow->hour = date( "H" );
        $stNow->minute = date( "i" );
        $InitDayTime->year = ( ord( substr( $pcb, 81, 1 ) ) - 48 ) * 1000 + ( ord( substr( $pcb, 82, 1 ) ) - 48 ) * 100 + ( ord( substr( $pcb, 89, 1 ) ) - 48 ) * 10 + ( ord( substr( $pcb, 90, 1 ) ) - 48 );
        $InitDayTime->month = ( ord( substr( $pcb, 112, 1 ) ) - 48 ) * 10 + ( ord( substr( $pcb, 113, 1 ) ) - 48 );
        $InitDayTime->day = ( ord( substr( $pcb, 116, 1 ) ) - 48 ) * 10 + ( ord( substr( $pcb, 117, 1 ) ) - 48 );
        $InitDayTime->hour = ( ord( substr( $pcb, 85, 1 ) ) - 48 ) * 10 + ( ord( substr( $pcb, 86, 1 ) ) - 48 );
        $InitDayTime->minute = ( ord( substr( $pcb, 108, 1 ) ) - 48 ) * 10 + ( ord( substr( $pcb, 109, 1 ) ) - 48 );
        $InitDayTime->second = ( ord( substr( $pcb, 120, 1 ) ) - 48 ) * 10 + ( ord( substr( $pcb, 121, 1 ) ) - 48 );
        $LastDayTime->year = ( ord( substr( $pcb, 110, 1 ) ) - 48 ) * 1000 + ( ord( substr( $pcb, 111, 1 ) ) - 48 ) * 100 + ( ord( substr( $pcb, 114, 1 ) ) - 48 ) * 10 + ( ord( substr( $pcb, 115, 1 ) ) - 48 );
        $LastDayTime->month = ( ord( substr( $pcb, 118, 1 ) ) - 48 ) * 10 + ( ord( substr( $pcb, 119, 1 ) ) - 48 );
        $LastDayTime->day = ( ord( substr( $pcb, 87, 1 ) ) - 48 ) * 10 + ( ord( substr( $pcb, 88, 1 ) ) - 48 );
        $LastDayTime->hour = ( ord( substr( $pcb, 106, 1 ) ) - 48 ) * 10 + ( ord( substr( $pcb, 107, 1 ) ) - 48 );
        $LastDayTime->minute = ( ord( substr( $pcb, 83, 1 ) ) - 48 ) * 10 + ( ord( substr( $pcb, 84, 1 ) ) - 48 );
        $LastDayTime->second = ( ord( substr( $pcb, 122, 1 ) ) - 48 ) * 10 + ( ord( substr( $pcb, 123, 1 ) ) - 48 );
        $iMinuteOffSet = ( ord( substr( $pcb, 100, 1 ) ) - 48 ) * 10 + ( ord( substr( $pcb, 101, 1 ) ) - 48 ) * 10 + ( ord( substr( $pcb, 102, 1 ) ) - 48 );
        if ( substr( $pcb, 99, 1 ) == "2" )
        {
            $iMinuteOffSet *= -1;
        }
        $iSecondOffSet = ( ord( substr( $pcb, 104, 1 ) ) - 48 ) * 10 + ( ord( substr( $pcb, 105, 1 ) ) - 48 );
        if ( substr( $pcb, 99, 1 ) == "2" )
        {
            $iSecondOffSet *= -1;
        }
        $ucPswType = ord( substr( $pcb, 224, 1 ) ) - 48;
        $ucLastLoninState = ord( substr( $pcb, 386, 1 ) ) - 48;
        $ucLastPsw[0] = ord( substr( $pcb, 225, 1 ) );
        $ucLastPsw[1] = ord( substr( $pcb, 226, 1 ) );
        $ucLastPsw[2] = ord( substr( $pcb, 393, 1 ) );
        $ucLastPsw[3] = ord( substr( $pcb, 394, 1 ) );
        $ucLastPsw[4] = ord( substr( $pcb, 395, 1 ) );
        $ucLastPsw[5] = ord( substr( $pcb, 396, 1 ) );
        $ucLastPsw[6] = 0;
        $iPswChangeTime = ( ord( substr( $pcb, 387, 1 ) ) - 48 ) * 1000 + ( ord( substr( $pcb, 388, 1 ) ) - 48 ) * 100 + ( ord( substr( $pcb, 389, 1 ) ) - 48 ) * 10 + ( ord( substr( $pcb, 390, 1 ) ) - 48 );
        $iPswActiveTime = ( ord( substr( $pcb, 391, 1 ) ) - 48 ) * 10 + ( ord( substr( $pcb, 392, 1 ) ) - 48 );
        $ucPswActiveType = ord( substr( $pcb, 397, 1 ) ) - 48;
        $nowtimecount = ( integer )( ( time( ) - mktime( $InitDayTime->hour, $InitDayTime->minute, $InitDayTime->second, $InitDayTime->month, $InitDayTime->day, $InitDayTime->year ) ) / 60 );
        $lasttimecount = ( integer )( mktime( $LastDayTime->hour, $LastDayTime->minute, $LastDayTime->second, $LastDayTime->month, $LastDayTime->day, $LastDayTime->year ) / 60 - mktime( $InitDayTime->hour, $InitDayTime->minute, $InitDayTime->second, $InitDayTime->month, $InitDayTime->day, $InitDayTime->year ) / 60 );
        $iTimeWindow = ( integer )( $lasttimecount / 1440 );
        if ( $iTimeWindow < 60 )
        {
            $iTimeWindow = 5;
        }
        else if ( 60 <= $iTimeWindow && $iTimeWindow < 360 )
        {
            $iTimeWindow = 30;
        }
        else
        {
            $iTimeWindow = 60;
        }
        if ( $iPswChangeTime != 60 )
        {
            return -1;
        }
        $i = 0 - 1 * $iTimeWindow;
        for ( ; $i <= $iTimeWindow; ++$i )
        {
            if ( $nowtimecount + $iMinuteOffSet + $i <= $lasttimecount + $iMinuteOffSet || !( $this->SMGetPsw( $pucKey, $nowtimecount + $iMinuteOffSet + $i ) == $password ) )
            {
                $pResultCB[110] = ( integer )( $stNow->year / 1000 );
                $pResultCB[111] = ( integer )( $stNow->year % 1000 / 100 );
                $pResultCB[114] = ( integer )( $stNow->year % 100 / 10 );
                $pResultCB[115] = ( integer )( $stNow->year % 10 );
                $pResultCB[118] = ( integer )( $stNow->month / 10 );
                $pResultCB[119] = ( integer )( $stNow->month % 10 );
                $pResultCB[87] = ( integer )( $stNow->day / 10 );
                $pResultCB[88] = ( integer )( $stNow->day % 10 );
                $pResultCB[106] = ( integer )( $stNow->hour / 10 );
                $pResultCB[107] = ( integer )( $stNow->hour % 10 );
                $pResultCB[83] = ( integer )( $stNow->minute / 10 );
                $pResultCB[84] = ( integer )( $stNow->minute % 10 );
                $pResultCB[122] = "0";
                $pResultCB[123] = "0";
                $pResultCB[100] = ( integer )( ( $i + $iMinuteOffSet ) / 100 );
                $pResultCB[101] = ( integer )( ( $i + $iMinuteOffSet ) % 100 / 10 );
                $pResultCB[102] = ( integer )( ( $i + $iMinuteOffSet ) % 10 );
                if ( 0 < $i + $iMinuteOffSet )
                {
                    $pResultCB[99] = "1";
                }
                else
                {
                    $pResultCB[99] = "2";
                }
                $i = 103;
                for ( ; $i < 106; ++$i )
                {
                    $pResultCB[$i] = "0";
                }
                $pResultCB[386] = "1";
                $strSeamoon = "ShenzhenSeamoonCommunicationTechnologyCo,Ltd,20050328.88888888889999999999";
                $cMd5InputStr = $strSeamoon;
                $i = 0;
                for ( ; $i < 49; ++$i )
                {
                    $cMd5InputStr .= $pResultCB[$i];
                }
                $i = 0;
                for ( ; $i < 319; ++$i )
                {
                    $cMd5InputStr .= $pResultCB[81 + $i];
                }
                $cMd5ResultStr = strtoupper( md5( $cMd5InputStr ) );
                $i = 0;
                for ( ; $i < 32; ++$i )
                {
                    $pResultCB[49 + $i] = substr( $cMd5ResultStr, $i, 1 );
                }
                $returnstr = "";
                $i = 0;
                for ( ; $i < 400; ++$i )
                {
                    $returnstr .= $pResultCB[$i];
                }
                return $returnstr;
            }
        }
        return "0";
    }

    public function passwordsynsea( $pcb, $password )
    {
        if ( $this->checkcb( $pcb ) != 1 )
        {
            reutrn - 1;
        }
        $pResultCB = array( );
        $tempk = 0;
        for ( ; $tempk < strlen( $pcb ); ++$tempk )
        {
            $pResultCB[$tempk] = substr( $pcb, $tempk, 1 );
        }
        $InitDayTime = new otpdatetime( );
        $LastDayTime = new otpdatetime( );
        $stNow = new otpdatetime( );
        $iKeyLen = ( ord( substr( $pcb, 91, 1 ) ) - 48 ) * 100 + ( ord( substr( $pcb, 92, 1 ) ) - 48 ) * 10 + ( ord( substr( $pcb, 93, 1 ) ) - 48 );
        $i = 0;
        for ( ; $i < 5; ++$i )
        {
            $pucKey[$i] = substr( $pcb, 94 + $i, 1 );
        }
        $i = 0;
        for ( ; $i < $iKeyLen - 5; ++$i )
        {
            $pucKey[$i + 5] = substr( $pcb, 124 + $i, 1 );
        }
        $stNow->year = date( "Y" );
        $stNow->month = date( "m" );
        $stNow->day = date( "d" );
        $stNow->hour = date( "H" );
        $stNow->minute = date( "i" );
        $InitDayTime->year = ( ord( substr( $pcb, 81, 1 ) ) - 48 ) * 1000 + ( ord( substr( $pcb, 82, 1 ) ) - 48 ) * 100 + ( ord( substr( $pcb, 89, 1 ) ) - 48 ) * 10 + ( ord( substr( $pcb, 90, 1 ) ) - 48 );
        $InitDayTime->month = ( ord( substr( $pcb, 112, 1 ) ) - 48 ) * 10 + ( ord( substr( $pcb, 113, 1 ) ) - 48 );
        $InitDayTime->day = ( ord( substr( $pcb, 116, 1 ) ) - 48 ) * 10 + ( ord( substr( $pcb, 117, 1 ) ) - 48 );
        $InitDayTime->hour = ( ord( substr( $pcb, 85, 1 ) ) - 48 ) * 10 + ( ord( substr( $pcb, 86, 1 ) ) - 48 );
        $InitDayTime->minute = ( ord( substr( $pcb, 108, 1 ) ) - 48 ) * 10 + ( ord( substr( $pcb, 109, 1 ) ) - 48 );
        $InitDayTime->second = ( ord( substr( $pcb, 120, 1 ) ) - 48 ) * 10 + ( ord( substr( $pcb, 121, 1 ) ) - 48 );
        $LastDayTime->year = ( ord( substr( $pcb, 110, 1 ) ) - 48 ) * 1000 + ( ord( substr( $pcb, 111, 1 ) ) - 48 ) * 100 + ( ord( substr( $pcb, 114, 1 ) ) - 48 ) * 10 + ( ord( substr( $pcb, 115, 1 ) ) - 48 );
        $LastDayTime->month = ( ord( substr( $pcb, 118, 1 ) ) - 48 ) * 10 + ( ord( substr( $pcb, 119, 1 ) ) - 48 );
        $LastDayTime->day = ( ord( substr( $pcb, 87, 1 ) ) - 48 ) * 10 + ( ord( substr( $pcb, 88, 1 ) ) - 48 );
        $LastDayTime->hour = ( ord( substr( $pcb, 106, 1 ) ) - 48 ) * 10 + ( ord( substr( $pcb, 107, 1 ) ) - 48 );
        $LastDayTime->minute = ( ord( substr( $pcb, 83, 1 ) ) - 48 ) * 10 + ( ord( substr( $pcb, 84, 1 ) ) - 48 );
        $LastDayTime->second = ( ord( substr( $pcb, 122, 1 ) ) - 48 ) * 10 + ( ord( substr( $pcb, 123, 1 ) ) - 48 );
        $iMinuteOffSet = ( ord( substr( $pcb, 100, 1 ) ) - 48 ) * 10 + ( ord( substr( $pcb, 101, 1 ) ) - 48 ) * 10 + ( ord( substr( $pcb, 102, 1 ) ) - 48 );
        if ( substr( $pcb, 99, 1 ) == "2" )
        {
            $iMinuteOffSet *= -1;
        }
        $iSecondOffSet = ( ord( substr( $pcb, 104, 1 ) ) - 48 ) * 10 + ( ord( substr( $pcb, 105, 1 ) ) - 48 );
        if ( substr( $pcb, 99, 1 ) == "2" )
        {
            $iSecondOffSet *= -1;
        }
        $ucPswType = ord( substr( $pcb, 224, 1 ) ) - 48;
        $ucLastLoninState = ord( substr( $pcb, 386, 1 ) ) - 48;
        $ucLastPsw[0] = ord( substr( $pcb, 225, 1 ) );
        $ucLastPsw[1] = ord( substr( $pcb, 226, 1 ) );
        $ucLastPsw[2] = ord( substr( $pcb, 393, 1 ) );
        $ucLastPsw[3] = ord( substr( $pcb, 394, 1 ) );
        $ucLastPsw[4] = ord( substr( $pcb, 395, 1 ) );
        $ucLastPsw[5] = ord( substr( $pcb, 396, 1 ) );
        $ucLastPsw[6] = 0;
        $iPswChangeTime = ( ord( substr( $pcb, 387, 1 ) ) - 48 ) * 1000 + ( ord( substr( $pcb, 388, 1 ) ) - 48 ) * 100 + ( ord( substr( $pcb, 389, 1 ) ) - 48 ) * 10 + ( ord( substr( $pcb, 390, 1 ) ) - 48 );
        $iPswActiveTime = ( ord( substr( $pcb, 391, 1 ) ) - 48 ) * 10 + ( ord( substr( $pcb, 392, 1 ) ) - 48 );
        $ucPswActiveType = ord( substr( $pcb, 397, 1 ) ) - 48;
        $nowtimecount = ( integer )( ( time( ) - mktime( $InitDayTime->hour, $InitDayTime->minute, $InitDayTime->second, $InitDayTime->month, $InitDayTime->day, $InitDayTime->year ) ) / 60 );
        $lasttimecount = ( integer )( mktime( $LastDayTime->hour, $LastDayTime->minute, $LastDayTime->second, $LastDayTime->month, $LastDayTime->day, $LastDayTime->year ) / 60 - mktime( $InitDayTime->hour, $InitDayTime->minute, $InitDayTime->second, $InitDayTime->month, $InitDayTime->day, $InitDayTime->year ) / 60 );
        $iTimeWindow = 90;
        if ( $iPswChangeTime != 60 )
        {
            return -1;
        }
        $i = 0 - 1 * $iTimeWindow;
        for ( ; $i <= $iTimeWindow; ++$i )
        {
            if ( $nowtimecount + $iMinuteOffSet + $i <= $lasttimecount + $iMinuteOffSet || !( $this->SMGetPsw( $pucKey, $nowtimecount + $iMinuteOffSet + $i ) == $password ) )
            {
                $pResultCB[110] = ( integer )( $stNow->year / 1000 );
                $pResultCB[111] = ( integer )( $stNow->year % 1000 / 100 );
                $pResultCB[114] = ( integer )( $stNow->year % 100 / 10 );
                $pResultCB[115] = ( integer )( $stNow->year % 10 );
                $pResultCB[118] = ( integer )( $stNow->month / 10 );
                $pResultCB[119] = ( integer )( $stNow->month % 10 );
                $pResultCB[87] = ( integer )( $stNow->day / 10 );
                $pResultCB[88] = ( integer )( $stNow->day % 10 );
                $pResultCB[106] = ( integer )( $stNow->hour / 10 );
                $pResultCB[107] = ( integer )( $stNow->hour % 10 );
                $pResultCB[83] = ( integer )( $stNow->minute / 10 );
                $pResultCB[84] = ( integer )( $stNow->minute % 10 );
                $pResultCB[122] = "0";
                $pResultCB[123] = "0";
                $pResultCB[100] = ( integer )( ( $i + $iMinuteOffSet ) / 100 );
                $pResultCB[101] = ( integer )( ( $i + $iMinuteOffSet ) % 100 / 10 );
                $pResultCB[102] = ( integer )( ( $i + $iMinuteOffSet ) % 10 );
                if ( 0 < $i + $iMinuteOffSet )
                {
                    $pResultCB[99] = "1";
                }
                else
                {
                    $pResultCB[99] = "2";
                }
                $i = 103;
                for ( ; $i < 106; ++$i )
                {
                    $pResultCB[$i] = "0";
                }
                $pResultCB[386] = "1";
                $strSeamoon = "ShenzhenSeamoonCommunicationTechnologyCo,Ltd,20050328.88888888889999999999";
                $cMd5InputStr = $strSeamoon;
                $i = 0;
                for ( ; $i < 49; ++$i )
                {
                    $cMd5InputStr .= $pResultCB[$i];
                }
                $i = 0;
                for ( ; $i < 319; ++$i )
                {
                    $cMd5InputStr .= $pResultCB[81 + $i];
                }
                $cMd5ResultStr = strtoupper( md5( $cMd5InputStr ) );
                $i = 0;
                for ( ; $i < 32; ++$i )
                {
                    $pResultCB[49 + $i] = substr( $cMd5ResultStr, $i, 1 );
                }
                $returnstr = "";
                $i = 0;
                for ( ; $i < 400; ++$i )
                {
                    $returnstr .= $pResultCB[$i];
                }
                return $returnstr;
            }
        }
        return "0";
    }

    public function SMGetPsw( $key, $iMinutes )
    {
        $i = 0;
        $i = 0;
        for ( ; $i < count( $key ); ++$i )
        {
            $shain[$i] = ord( $key[$i] );
        }
        $strSeamoon = "ShenzhenSeamoon20050328";
        $j = 0;
        for ( ; $j < strlen( $strSeamoon ); ++$j )
        {
            $shain[$i] = ord( substr( $strSeamoon, $j, 1 ) );
            ++$i;
        }
        $shain[$i] = ( integer )( ( $iMinutes & 4.27819e+009 ) >> 24 );
        $shain[$i + 1] = ( integer )( ( $iMinutes & 16711680 ) >> 16 );
        $shain[$i + 2] = ( integer )( ( $iMinutes & 65280 ) >> 8 );
        $shain[$i + 3] = ( integer )( $iMinutes & 255 );
        $i += 4;
        $shain[$i] = 0;
        $shain2 = "";
        $j = 0;
        for ( ; $j <= $i; ++$j )
        {
            $shain2 .= chr( $shain[$j] );
        }
        $re = sha1( $shain2 );
        $re = strtoupper( $re );
        $sg = new stringchange( );
        $bytere = $sg->hexStringToByte2( $re );
        return $this->SMGetpPswFromSha( "SEAMOON20050328", 1, $bytere );
    }

    public function SMGetpPswFromSha( $pSecret, $ucKeyType, $ucMessage_Digest )
    {
        $i = 0;
        $ch = "1";
        $ulTmpSum = array( );
        $ulTmpSumLen = 0;
        $Message_Digest = array( );
        $ucMessage_Digest2 = array( );
        $kk = 0;
        for ( ; $kk < 20; ++$kk )
        {
            $ucMessage_Digest2[$kk] = $ucMessage_Digest[$kk] & 255;
        }
        $i = 0;
        for ( ; $i < 20; ++$i )
        {
            $Message_Digest[$i] = $ucMessage_Digest2[$i];
        }
        switch ( $ucKeyType )
        {
            case 0 :
                $i = 0;
                for ( ; $i < 4; ++$i )
                {
                    $ulTmpSum[$i] = $Message_Digest[$i] + $Message_Digest[4 + $i] + $Message_Digest[8 + $i] + $Message_Digest[12 + $i] + $Message_Digest[16 + $i];
                }
                $ulTmpSumLen = 4;
                break;
            case 1 :
            case 2 :
                $i = 0;
                for ( ; $i < 4; ++$i )
                {
                    $ulTmpSum[$i] = $Message_Digest[$i] + $Message_Digest[6 + $i] + $Message_Digest[12 + $i];
                }
                $ulTmpSum[4] = $Message_Digest[16] + $Message_Digest[17];
                $ulTmpSum[5] = $Message_Digest[18] + $Message_Digest[19];
                $ulTmpSumLen = 6;
                break;
            case 3 :
            case 4 :
                $i = 0;
                for ( ; $i < 8; ++$i )
                {
                    $ulTmpSum[$i] = $Message_Digest[$i] + $Message_Digest[8 + $i] + $Message_Digest[16] + $Message_Digest[17] + $Message_Digest[18] + $Message_Digest[19];
                }
                $ulTmpSumLen = 8;
                break;
            default :
                return "";
        }
        $i = 0;
        for ( ; $i < $ulTmpSumLen; ++$i )
        {
            switch ( $ucKeyType )
            {
                case 1 :
                case 3 :
                    switch ( ( integer )( $ulTmpSum[$i] % 10 ) )
                    {
                        case 0 :
                            $ch = "0";
                            break;
                        case 1 :
                            $ch = "1";
                            break;
                        case 2 :
                            $ch = "2";
                            break;
                        case 3 :
                            $ch = "3";
                            break;
                        case 4 :
                            $ch = "4";
                            break;
                        case 5 :
                            $ch = "5";
                            break;
                        case 6 :
                            $ch = "6";
                            break;
                        case 7 :
                            $ch = "7";
                            break;
                        case 8 :
                            $ch = "8";
                            break;
                        case 9 :
                            $ch = "9";
                            break;
                        default :
                            $ch = "Z";
                    }
                    break;
                default :
                    switch ( ( integer )( $ulTmpSum[$i] % 28 ) )
                    {
                        case 0 :
                            $ch = "A";
                            break;
                        case 1 :
                            $ch = "B";
                            break;
                        case 2 :
                            $ch = "C";
                            break;
                        case 3 :
                            $ch = "D";
                            break;
                        case 4 :
                            $ch = "E";
                            break;
                        case 5 :
                            $ch = "F";
                            break;
                        case 6 :
                            $ch = "G";
                            break;
                        case 7 :
                            $ch = "H";
                            break;
                        case 8 :
                            $ch = "J";
                            break;
                        case 9 :
                            $ch = "K";
                            break;
                        case 10 :
                            $ch = "L";
                            break;
                        case 11 :
                            $ch = "M";
                            break;
                        case 12 :
                            $ch = "N";
                            break;
                        case 13 :
                            $ch = "P";
                            break;
                        case 14 :
                            $ch = "Q";
                            break;
                        case 15 :
                            $ch = "R";
                            break;
                        case 16 :
                            $ch = "S";
                            break;
                        case 17 :
                            $ch = "T";
                            break;
                        case 18 :
                            $ch = "W";
                            break;
                        case 19 :
                            $ch = "X";
                            break;
                        case 20 :
                            $ch = "Y";
                            break;
                        case 21 :
                            $ch = "3";
                            break;
                        case 22 :
                            $ch = "4";
                            break;
                        case 23 :
                            $ch = "5";
                            break;
                        case 24 :
                            $ch = "6";
                            break;
                        case 25 :
                            $ch = "7";
                            break;
                        case 26 :
                            $ch = "8";
                            break;
                        case 27 :
                            $ch = "9";
                            break;
                        default :
                            $ch = "Z";
                    }
            }
            $psw .= $ch;
        }
        return $psw;
    }

}

function int32( $n )
{
    while ( 2.14748e+009 <= $n )
    {
        $n -= 4.29497e+009;
    }
    while ( $n <= -2.14748e+009 )
    {
        $n += 4.29497e+009;
    }
    return ( integer );
}

echo "\r\n";
?>
