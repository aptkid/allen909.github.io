<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
interface alg_interface
{

    public abstract function encrypt( );
$data )
    {

    public abstract function decrypt( );
$data )
    {

    public abstract function getVersion( );

}

class TDEncryptor
{

    private $_available_algorithms = array( );
    private $_cipher = "";
    public $encryptor;
    private $_key = "";
    private $_cipher_key = "";
    private $_err_no = 0;
    private $_size = 0;
    private $_header_ver = "1.1.130509";
    private $_mcrypt_algorithms = array( "DES-64", "RC2-128", "RC2-256", "BLOWFISH-128", "BLOWFISH-256" );
    private $_attach_encrypt_pkey = "";
    private $_file_src = "";
    private $_handle_src;

    public function __construct( $file_src )
    {
        if ( trim( $file_src ) == "" )
        {
            $this->_setError( -100 );
            return FALSE;
        }
        if ( !file_exists( $file_src ) || !is_file( $file_src ) )
        {
            $this->_setError( -101 );
            return FALSE;
        }
        $this->_file_src = $file_src;
        $PARA_ARRAY = get_sys_para( "ATTACH_ENCRYPT_PKEY" );
        $ATTACH_ENCRYPT_PKEY_ARRAY = unserialize( $PARA_ARRAY['ATTACH_ENCRYPT_PKEY'] );
        $this->_attach_encrypt_pkey = $ATTACH_ENCRYPT_PKEY_ARRAY['PKEY_1'];
    }

    public function __destruct( )
    {
        $this->closeFile( );
    }

    public function closeFile( )
    {
        if ( is_resource( $this->_handle_src ) )
        {
            fclose( $this->_handle_src );
        }
    }

    public static function getAlgorithms( )
    {
        $ini_file = ALGORITHM_LIB.DS."algorithms.ini";
        if ( file_exists( $ini_file ) )
        {
            return FALSE;
        }
        $available_algorithms = parse_ini_file( $ini_file, TRUE );
        return $available_algorithms;
    }

    public static function genKey( $length = 128 )
    {
        $source = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        $key = "";
        $i = 0;
        for ( ; $i < $length; ++$i )
        {
            $key .= $source[mt_rand( 0, strlen( $source ) - 1 )];
        }
        return $key;
    }

    private function _authcode( $string, $operation = "", $expiry = 0 )
    {
        if ( $this->_attach_encrypt_pkey == "" )
        {
            return $string;
        }
        $ckey_length = 4;
        $key = md5( $this->_attach_encrypt_pkey );
        $keya = md5( substr( $key, 0, 16 ) );
        $keyb = md5( substr( $key, 16, 16 ) );
        $keyc = $ckey_length ? $operation == "DECODE" ? substr( $string, 0, $ckey_length ) : substr( md5( microtime( ) ), 0 - $ckey_length ) : "";
        $cryptkey = $keya.md5( $keya.$keyc );
        $key_length = strlen( $cryptkey );
        $string = $operation == "DECODE" ? base64_decode( substr( $string, $ckey_length ) ) : sprintf( "%010d", $expiry ? $expiry + time( ) : 0 ).substr( md5( $string.$keyb ), 0, 16 ).$string;
        $string_length = strlen( $string );
        $result = "";
        $box = range( 0, 255 );
        $rndkey = array( );
        $i = 0;
        for ( ; $i <= 255; ++$i )
        {
            $rndkey[$i] = ord( $cryptkey[$i % $key_length] );
        }
        $j = $i = 0;
        for ( ; $i < 256; ++$i )
        {
            $j = ( $j + $box[$i] + $rndkey[$i] ) % 256;
            $tmp = $box[$i];
            $box[$i] = $box[$j];
            $box[$j] = $tmp;
        }
        $a = $j = $i = 0;
        for ( ; $i < $string_length; ++$i )
        {
            $a = ( $a + 1 ) % 256;
            $j = ( $j + $box[$a] ) % 256;
            $tmp = $box[$a];
            $box[$a] = $box[$j];
            $box[$j] = $tmp;
            $result .= chr( ord( $string[$i] ) ^ $box[( $box[$a] + $box[$j] ) % 256] );
        }
        if ( $operation == "DECODE" )
        {
            if ( ( substr( $result, 0, 10 ) == 0 || 0 < substr( $result, 0, 10 ) - time( ) ) && substr( $result, 10, 16 ) == substr( md5( substr( $result, 26 ).$keyb ), 0, 16 ) )
            {
                return substr( $result, 26 );
            }
            return "";
        }
        return $keyc.str_replace( "=", "", base64_encode( $result ) );
    }

    private function _getChunkSize( )
    {
        $i = 0;
        $data = NULL;
        while ( $i++ * 16 < PLAINTEXT_CHUNK_SIZE )
        {
            $data .= md5( mt_rand( ), TRUE );
        }
        $encrypted_data = $this->encryptor->encrypt( $data );
        return strlen( $encrypted_data );
    }

    private function _initCipher( )
    {
        $this->_available_algorithms = ( );
        if ( array_key_exists( $this->_cipher, $this->_available_algorithms ) )
        {
            $this->_setError( -102 );
            $this->_cipher = DEFAULT_ALGORITHM;
        }
        if ( in_array( $this->_cipher, $this->_mcrypt_algorithms ) )
        {
            $class = "alg_standard";
        }
        else if ( substr( strtolower( $this->_cipher ), 0, 5 ) == "xxtea" )
        {
            $class = "alg_xxtea";
        }
        $class_file = ALGORITHM_LIB.DS.$class.EXT;
        if ( file_exists( $class_file ) )
        {
            require_once( $class_file );
        }
        $this->encryptor = new $class( @$this->_cipher );
    }

    public function encryptFile( $file_des, $cipher = DEFAULT_ALGORITHM, $whole = FALSE, $overwrite = TRUE )
    {
        $header_src = $this->getHeaderHead( );
        if ( $header_head['header_identifier'] == HEADER_IDENTIFIER )
        {
        }
        else
        {
            $this->_cipher = strtoupper( $cipher );
            if ( $whole )
            {
                $this->_size = MYOA_ATTACH_ENCRYPT_DEFAULT_LEN * 1024;
            }
            $this->_initCipher( );
            if ( is_object( $this->encryptor ) )
            {
                $this->_setError( -103 );
                return FALSE;
            }
            $this->_key = ( );
            $this->encryptor->setKey( $this->_key );
            $this->_cipher_key = $this->_key( $this->_key );
            $file_size = sprintf( "%u", filesize( $this->_file_src ) );
            $size = $this->_size == 0 || $file_size < $this->_size ? $file_size : $this->_size;
            if ( is_resource( $this->_handle_src ) )
            {
                $this->_handle_src = fopen( $this->_file_src, "rb" );
            }
            $handle_des = fopen( $file_des, "wb" );
            $header = $this->_packHeader( );
            $pos_des_begin = strlen( $header );
            rewind( $this->_handle_src );
            fseek( $handle_des, $pos_des_begin );
            $pos_src = 0;
            $pos_des = $pos_des_begin;
            for ( ; $pos_src < $size; $pos_src += $chunk )
            {
                $chunk = PLAINTEXT_CHUNK_SIZE < $size - $pos_src ? PLAINTEXT_CHUNK_SIZE : $size - $pos_src;
                $data = $this->_handle_src( $this->_handle_src, $chunk );
                if ( strlen( $data ) != $chunk )
                {
                    $this->_setError( -200 );
                    $this->_writeLog( "encrypt" );
                    return FALSE;
                }
                $encrypt_data = $this->encryptor->encrypt( $data );
                if ( strlen( $encrypt_data )( $handle_des, $encrypt_data, strlen( $encrypt_data ) ) )
                {
                    fclose( $handle_des );
                    @unlink( $file_des );
                    $this->_setError( -201 );
                    $this->_writeLog( "encrypt" );
                    return FALSE;
                }
                $pos_des += strlen( $encrypt_data );
            }
            do
            {
                if ( $size < $file_size && !feof( $this->_handle_src ) )
                {
                    $surplus_data = $this->_handle_src( $this->_handle_src, PLAINTEXT_CHUNK_SIZE );
                }
            } while ( strlen( $surplus_data )( $handle_des, $surplus_data, strlen( $surplus_data ) ) );
            fclose( $handle_des );
            @unlink( $file_des );
            $this->_setError( -201 );
            $this->_writeLog( "encrypt" );
            return FALSE;
            rewind( $handle_des );
            strlen( $header )( $handle_des, $header, strlen( $header ) );
            fseek( $handle_des, HEADER_HEAD_LEN - 4 - 4 );
            pack( "L", sprintf( "%u", $pos_des - $pos_des_begin ) )( $handle_des, pack( "L", sprintf( "%u", $pos_des - $pos_des_begin ) ), 4 );
            fclose( $handle_des );
            if ( $this->_err_no != 0 )
            {
                $this->_writeLog( "encrypt" );
            }
            return TRUE;
        }
    }

    public function decryptFile( $file_des = "" )
    {
        if ( is_resource( $this->_handle_src ) )
        {
            $this->_handle_src = fopen( $this->_file_src, "rb" );
        }
        $header = $this->_unpackHeader( );
        $this->_cipher = strtoupper( $header['algorithm_name'] );
        $this->_initCipher( );
        if ( is_object( $this->encryptor ) )
        {
            $this->_setError( -103 );
            return FALSE;
        }
        $header_size = HEADER_HEAD_LEN + $header['header_size'];
        $file_size = sprintf( "%u", filesize( $this->_file_src ) );
        $size = $header['whole'] == 1 ? $file_size : $header['data_size'] + $header_size;
        if ( $header )
        {
            $key = $header['key']( $header['key'], "DECODE" );
            $this->encryptor->setKey( $key );
            if ( $file_des != "" )
            {
                $handle_des = fopen( $file_des, "wb" );
            }
            $chunk = $header['chunk_size'];
            $pos_src = $header_size;
            $pos_des = 0;
            for ( ; $pos_src < $size; $pos_src += $chunk )
            {
                $chunk = $chunk < $size - $pos_src ? $chunk : $size - $pos_src;
                $data = $this->_handle_src( $this->_handle_src, $chunk );
                if ( strlen( $data ) != $chunk )
                {
                    $this->_setError( -200 );
                    $this->_writeLog( "dncrypt" );
                    return FALSE;
                }
                $decrypt_data = $this->encryptor->decrypt( $data );
                if ( is_resource( $handle_des ) )
                {
                    if ( strlen( $decrypt_data )( $handle_des, $decrypt_data, strlen( $decrypt_data ) ) )
                    {
                        fclose( $handle_des );
                        @unlink( $file_des );
                        $this->_setError( -201 );
                        $this->_writeLog( "dncrypt" );
                        return FALSE;
                    }
                }
                echo $decrypt_data;
                $pos_des += strlen( $decrypt_data );
            }
            while ( !( $size < $file_size ) || feof( $this->_handle_src ) )
            {
                $surplus_data = fread( $this->_handle_src, PLAINTEXT_CHUNK_SIZE );
                if ( is_resource( $handle_des ) )
                {
                    if ( strlen( $surplus_data )( $handle_des, $surplus_data, strlen( $surplus_data ) ) )
                    {
                        fclose( $handle_des );
                        @unlink( $file_des );
                        $this->_setError( -201 );
                        $this->_writeLog( "dncrypt" );
                        return FALSE;
                    }
                }
                echo $surplus_data;
            }
            if ( is_resource( $handle_des ) )
            {
                fclose( $handle_des );
            }
        }
        if ( $this->_err_no != 0 )
        {
            $this->_writeLog( "decrypt" );
        }
        return TRUE;
    }

    private function _packHeader( )
    {
        $SYS_VERSION = ( "SYS_VERSION" );
        $header .= pack( "a".HEADER_ALGORITHM_NAME_LEN, $this->_cipher );
        $version = $this->encryptor->getVersion( );
        $header .= pack( "a".HEADER_ALGORITHM_VER_LEN, $version );
        $header .= pack( "a".HEADER_OA_VERSION_LEN_NEW, $SYS_VERSION['VER'] );
        $whole = 0;
        if ( $this->_size == 0 )
        {
            $whole = 1;
        }
        $header .= pack( "C1", $whole );
        $chunk_size = $this->_getChunkSize( );
        $header .= pack( "L", $chunk_size );
        $header .= pack( "a".strlen( $this->_cipher_key ), $this->_cipher_key );
        $ext_info = array( );
        if ( is_image( $this->_file_src ) )
        {
            $ext_info['image_size'] = getimagesize( @$this->_file_src );
        }
        $ext_str = serialize( $ext_info );
        $header = pack( "a".strlen( $ext_str ), $ext_str ).$header;
        $header_body_size = strlen( $header );
        $header = pack( "L", strlen( $ext_str ) ).$header;
        $header = pack( "L", 0 ).$header;
        $header = pack( "L", sprintf( "%u", filesize( $this->_file_src ) ) ).$header;
        $header = pack( "L", $header_body_size ).$header;
        $header = pack( "a".HEADER_VERSION_LEN, $this->_header_ver ).$header;
        $header = pack( "a".HEADER_IDENTIFIER_LEN, HEADER_IDENTIFIER ).$header;
        return $header;
    }

    public function getHeaderHead( )
    {
        $header_head = array( );
        if ( file_exists( $this->_file_src ) )
        {
            return $header_head;
        }
        $file_size = filesize( $this->_file_src );
        if ( $file_size <= HEADER_HEAD_LEN )
        {
            return $header_head;
        }
        if ( is_resource( $this->_handle_src ) )
        {
            $this->_handle_src = fopen( $this->_file_src, "rb" );
        }
        $data = $this->_handle_src( $this->_handle_src, HEADER_HEAD_LEN );
        $header_head = @unpack( @HEADER_HEAD, $data );
        if ( $header_head['header_identifier'] == HEADER_IDENTIFIER )
        {
            if ( 0 < $header_head['ext_size'] && $header_head['ext_size'] < PLAINTEXT_CHUNK_SIZE )
            {
                $data = $header_head['ext_size']( $this->_handle_src, $header_head['ext_size'] );
                $ext_info = @unpack( @HEADER_EXT, $data );
                if ( $ext_info['ext_info'] != "" )
                {
                    $header_head['ext_info'] = unserialize( $ext_info['ext_info'] );
                }
            }
            return $header_head;
        }
        return array( );
    }

    private function _unpackHeader( )
    {
        global $head_version_array;
        $header = array( );
        rewind( $this->_handle_src );
        $header_head = $this->getHeaderHead( );
        if ( $header_head['header_identifier'] == HEADER_IDENTIFIER )
        {
            fseek( $this->_handle_src, HEADER_HEAD_LEN + $header_head['ext_size'] );
            $data = fread( $this->_handle_src, $header_head['header_size'] - $header_head['ext_size'] );
            $header_version = $header_head['header_version'];
            if ( array_key_exists( $header_version, $head_version_array ) )
            {
                $header_body = unpack( $head_version_array[$header_version], $data );
                $header = array_merge( $header_head, $header_body );
            }
        }
        return $header;
    }

    private function _setError( $err_no )
    {
        $this->_err_no = $err_no;
    }

    public function getErrorMsg( )
    {
        if ( 0 <= $this->_err_no )
        {
        }
        else
        {
            $rtMsg = "";
            switch ( $this->_err_no )
            {
                case -100 :
                    $rtMsg = _( "��ʼ��ʧ�ܣ�Դ�ļ���ַ����Ϊ�ա�" );
                    break;
                case -101 :
                    $rtMsg = _( "��ʼ��ʧ�ܣ�Դ�ļ������ڡ�" );
                    break;
                case -102 :
                    $rtMsg = _( "δ֪�ļ����㷨��" );
                    break;
                case -103 :
                    $rtMsg = _( "��ʼ���㷨ʧ�ܡ�" );
                    break;
                case -200 :
                    $rtMsg = _( "��ȡ�ļ�����ʧ�ܡ�" );
                    break;
                case -201 :
                    $rtMsg = _( "д���ļ�����ʧ�ܡ�" );
            }
            return $rtMsg;
        }
    }

    private function _writeLog( $methord )
    {
        $log_file = "tdcrypt.err";
        $php_log_file = ini_get( "error_log" );
        if ( $php_log_file )
        {
            $log_path = pathinfo( $php_log_file, PATHINFO_DIRNAME );
        }
        else
        {
            $log_path = realpath( MYOA_ROOT_PATH."../" )."/logs";
        }
        if ( is_dir( $log_path ) )
        {
            mkdir( $log_path, 448 );
        }
        $log_file = $log_path."/".$log_file;
        $handle = fopen( $log_file, "ab" );
        $log_msg = "[".date( "Y-m-d H:i:s" )."] [".$methord."] ".$this->getErrorMsg( )." ".$this->_file_src."\r\n";
        fwrite( $handle, $log_msg );
        fclose( $handle );
    }

    private function _fread( $handle, $len )
    {
        $ret = "";
        $ret_len = 0;
        $retry = 0;
        while ( !( $ret_len < $len ) || feof( $handle ) || !( $retry < MAX_IO_RETRY ) )
        {
            $data = fread( $handle, $len - $ret_len );
            $ret .= $data;
            $ret_len += strlen( $data );
            ++$retry;
        }
        return $ret;
    }

    private function _fwrite( $handle, $data, $len )
    {
        $ret_len = 0;
        $retry = 0;
        while ( !( $ret_len < $len ) || !( $retry < MAX_IO_RETRY ) )
        {
            $data = substr( $data, $ret_len, $len - $ret_len );
            $data_len = fwrite( $handle, $data, $len - $ret_len );
            $ret_len += $data_len;
            ++$retry;
        }
        return $ret_len === $len;
    }

}

include_once( "inc/td_config.php" );
include_once( "inc/utility_file.php" );
define( "DS", DIRECTORY_SEPARATOR );
define( "EXT", ".php" );
define( "ALGORITHM_LIB", realpath( dirname( __FILE__ ) ).DS."algorithms" );
define( "MAX_IO_RETRY", 50 );
define( "DEFAULT_ALGORITHM", "XXTEA-128" );
define( "PLAINTEXT_CHUNK_SIZE", 4096 );
define( "HEADER_IDENTIFIER_LEN", 9 );
define( "HEADER_VERSION_LEN", 10 );
define( "HEADER_OA_VERSION_LEN", 10 );
define( "HEADER_OA_VERSION_LEN_NEW", 20 );
define( "HEADER_ALGORITHM_NAME_LEN", 20 );
define( "HEADER_ALGORITHM_VER_LEN", 10 );
define( "HEADER_IDENTIFIER", "TDENCRYPT" );
define( "HEADER_HEAD_LEN", HEADER_IDENTIFIER_LEN + HEADER_VERSION_LEN + 4 + 4 + 4 + 4 );
define( "HEADER_HEAD", "a".HEADER_IDENTIFIER_LEN."header_identifier/a".HEADER_VERSION_LEN."header_version/Lheader_size/Loriginal_size/Ldata_size/Lext_size" );
define( "HEADER_EXT", "a*ext_info" );
global $head_version_array;
$head_version_array = array( "1.0.120424" => "a".HEADER_ALGORITHM_NAME_LEN."algorithm_name/a".HEADER_ALGORITHM_VER_LEN."algorithm_ver/a".HEADER_OA_VERSION_LEN."oa_version/C1whole/Lchunk_size/a*key", "1.1.130509" => "a".HEADER_ALGORITHM_NAME_LEN."algorithm_name/a".HEADER_ALGORITHM_VER_LEN."algorithm_ver/a".HEADER_OA_VERSION_LEN_NEW."oa_version/C1whole/Lchunk_size/a*key" );
?>
