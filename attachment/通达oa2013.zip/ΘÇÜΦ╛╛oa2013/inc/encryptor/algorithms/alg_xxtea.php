<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class alg_xxtea implements alg_interface
{

    private $_ver = "1.0.120424";
    private $_key = "";
    private $_key_size;

    public function __construct( $cipher )
    {
        switch ( $cipher )
        {
            case "DES-64" :
                $this->_key_size = 128;
                break;
            case "BLOWFISH-128" :
                $this->_key_size = 256;
                break;
            default :
                $this->_key_size = 128;
        }
        $this->_td = mcrypt_module_open( "blowfish", "", "ecb", "" );
    }

    public function setKey( $key )
    {
        $this->_key = $key;
    }

    public function encrypt( $data )
    {
        if ( $data == "" )
        {
            return "";
        }
        if ( extension_loaded( "tdcrypt" ) )
        {
            $encrypted_data = td_encrypt( $data, $this->_key );
            if ( $encrypted_data )
            {
                return $encrypted_data;
            }
            return $data;
        }
        $v = $this->_str2long( $data, TRUE );
        $k = $this->_key( $this->_key, FALSE );
        if ( count( $k ) < 4 )
        {
            $i = count( $k );
            for ( ; $i < 4; ++$i )
            {
                $k[$i] = 0;
            }
        }
        $n = count( $v ) - 1;
        $z = $v[$n];
        $y = $v[0];
        $delta = 2.65444e+009;
        $q = floor( 6 + 52 / ( $n + 1 ) );
        $sum = 0;
        while ( 0 < $q-- )
        {
            $sum = $this->_int32( $sum + $delta );
            $e = $sum >> 2 & 3;
            $p = 0;
            for ( ; $p < $n; ++$p )
            {
                $y = $v[$p + 1];
                $mx = $this->_int32( ( $z >> 5 & 134217727 ^ $y << 2 ) + ( $y >> 3 & 536870911 ^ $z << 4 ) ) ^ $k[$p & 3 ^ $e]( ( $sum ^ $y ) + ( $k[$p & 3 ^ $e] ^ $z ) );
                $z = $v[$p] = $this->_int32( $v[$p] + $mx );
            }
            $y = $v[0];
            $mx = $this->_int32( ( $z >> 5 & 134217727 ^ $y << 2 ) + ( $y >> 3 & 536870911 ^ $z << 4 ) ) ^ $k[$p & 3 ^ $e]( ( $sum ^ $y ) + ( $k[$p & 3 ^ $e] ^ $z ) );
            $z = $v[$n] = $this->_int32( $v[$n] + $mx );
        }
        return $this->_long2str( $v, FALSE );
    }

    public function decrypt( $data )
    {
        if ( $data == "" )
        {
            return "";
        }
        if ( extension_loaded( "tdcrypt" ) )
        {
            $decrypted_data = td_decrypt( $data, $this->_key );
            if ( $decrypted_data )
            {
                return $decrypted_data;
            }
            return $data;
        }
        $v = $this->_str2long( $data, FALSE );
        $k = $this->_key( $this->_key, FALSE );
        if ( count( $k ) < 4 )
        {
            $i = count( $k );
            for ( ; $i < 4; ++$i )
            {
                $k[$i] = 0;
            }
        }
        $n = count( $v ) - 1;
        $z = $v[$n];
        $y = $v[0];
        $delta = 2.65444e+009;
        $q = floor( 6 + 52 / ( $n + 1 ) );
        $sum = $this->_int32( $q * $delta );
        while ( $sum != 0 )
        {
            $e = $sum >> 2 & 3;
            $p = $n;
            for ( ; 0 < $p; --$p )
            {
                $z = $v[$p - 1];
                $mx = $this->_int32( ( $z >> 5 & 134217727 ^ $y << 2 ) + ( $y >> 3 & 536870911 ^ $z << 4 ) ) ^ $k[$p & 3 ^ $e]( ( $sum ^ $y ) + ( $k[$p & 3 ^ $e] ^ $z ) );
                $y = $v[$p] = $this->_int32( $v[$p] - $mx );
            }
            $z = $v[$n];
            $mx = $this->_int32( ( $z >> 5 & 134217727 ^ $y << 2 ) + ( $y >> 3 & 536870911 ^ $z << 4 ) ) ^ $k[$p & 3 ^ $e]( ( $sum ^ $y ) + ( $k[$p & 3 ^ $e] ^ $z ) );
            $y = $v[0] = $this->_int32( $v[0] - $mx );
            $sum = $this->_int32( $sum - $delta );
        }
        return $this->_long2str( $v, TRUE );
    }

    public function getVersion( )
    {
        return $this->_ver;
    }

    private function _long2str( $v, $w )
    {
        $len = count( $v );
        $n = $len - 1 << 2;
        if ( $w )
        {
            $m = $v[$len - 1];
            if ( $m < $n - 3 || $n < $m )
            {
                return FALSE;
            }
            $n = $m;
        }
        $s = array( );
        $i = 0;
        for ( ; $i < $len; ++$i )
        {
            $s[$i] = pack( "V", $v[$i] );
        }
        if ( $w )
        {
            return substr( join( "", $s ), 0, $n );
        }
        return join( "", $s );
    }

    private function _str2long( $s, $w )
    {
        $v = unpack( "V*", $s.str_repeat( "\x00", 4 - strlen( $s ) % 4 & 3 ) );
        $v = array_values( $v );
        if ( $w )
        {
            $v[count( $v )] = strlen( $s );
        }
        return $v;
    }

    private function _int32( $n )
    {
        while ( 2.14748e+009 <= $n )
        {
            $n -= 4.29497e+009;
        }
        while ( $n <= -2.14748e+009 )
        {
            $n += 4.29497e+009;
        }
        return ( integer );
    }

}

?>
