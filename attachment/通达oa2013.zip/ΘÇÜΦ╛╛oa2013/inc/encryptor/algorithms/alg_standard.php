<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class alg_standard implements alg_interface
{

    private $_ver = "1.0.120424";
    private $_td;
    private $_iv;
    private $_key_size;

    public function __construct( $cipher )
    {
        switch ( $cipher )
        {
            case "DES-64" :
                $this->_key_size = 64;
                $this->_td = mcrypt_module_open( "des", "", "ecb", "" );
                break;
            case "BLOWFISH-128" :
                $this->_key_size = 128;
                $this->_td = mcrypt_module_open( "blowfish", "", "ecb", "" );
                break;
            case "BLOWFISH-256" :
                $this->_key_size = 256;
                $this->_td = mcrypt_module_open( "blowfish", "", "ecb", "" );
                break;
            case "RC2-128" :
                $this->_key_size = 128;
                $this->_td = mcrypt_module_open( "rc2", "", "ecb", "" );
                break;
            case "RC2-256" :
                $this->_key_size = 256;
                $this->_td = mcrypt_module_open( "rc2", "", "ecb", "" );
        }
        $key_size = $this->_key_size && $this->_key_size < mcrypt_enc_get_iv_size( $this->_td ) ? $this->_key_size : mcrypt_enc_get_iv_size( $this->_td );
        $this->_iv = mcrypt_create_iv( $key_size, MCRYPT_RAND );
    }

    public function setKey( $key )
    {
        $key = substr( $key, 0, mcrypt_enc_get_key_size( $this->_td ) );
        mcrypt_generic_init( $this->_td, $key, $this->_iv );
    }

    public function encrypt( $data )
    {
        $encrypted_data = mcrypt_generic( $this->_td, $data );
        return $encrypted_data;
    }

    public function decrypt( $data )
    {
        $decrypted_data = mdecrypt_generic( $this->_td, $data );
        return $decrypted_data;
    }

    public function getVersion( )
    {
        return $this->_ver;
    }

}

?>
