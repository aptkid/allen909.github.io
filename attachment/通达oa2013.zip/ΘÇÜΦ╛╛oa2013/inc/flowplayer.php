<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
if ( is_array( $arr_videos ) && 0 < count( $arr_videos ) )
{
    echo "    <link rel=\"stylesheet\" type=\"text/css\" href=\"/static/js/flowplayer/skin/minimalist.css\">\n    <script type=\"text/javascript\" src=\"/static/js/flowplayer/flowplayer.min.js\"></script>\n    <style>\n    .flowplayer  {\n       width:960px;\n       margin:10px;\n    }\n    .fp-playlist {\n       position: absolute;\n       bottom: -40px;\n       width:90%;\n       margin-bottom:10px;\n    }\n    .fp-playlist a {\n       display: block;\n       padding-left:25px;\n       background:url('/static/portal/group/style/images/video.jpg') left center no-repeat;\n    }\n    </style>\n    <div class=\"flowplayer\" data-swf=\"/static/js/flowplayer/flowplayer.swf\" data-ratio=\"0.4167\">\n        <video>\n            <source type=\"video/mp4\" src=\"";
    echo $arr_videos[0]['url'];
    echo "\">\n        </video>\n        <div class=\"fp-playlist\">\n            ";
    foreach ( $arr_videos as $video )
    {
        echo "        <a href=\"".$video['url']."\">".htmlspecialchars( $video['name'] )."</a>";
    }
    echo "        </div>\n    </div>\n";
}
?>
