<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
function encodeDataURL( $strDataURL, $addNoCacheStr = FALSE )
{
    if ( $addNoCacheStr )
    {
        if ( strpos( $strDataURL, "?" ) != 0 )
        {
            $strDataURL .= "&FCCurrTime=".date( "H_i_s" );
        }
        else
        {
            $strDataURL .= "?FCCurrTime=".date( "H_i_s" );
        }
    }
    return urlencode( $strDataURL );
}

function datePart( $mask, $dateTimeStr )
{
    @$timePt = @explode( " ", $dateTimeStr )[1];
    @$datePt = @explode( " ", $dateTimeStr )[0];
    $arDatePt = explode( "-", $datePt );
    $dataStr = "";
    if ( count( $arDatePt ) == 3 )
    {
        $day = $arDatePt[2];
        $month = $arDatePt[1];
        $year = $arDatePt[0];
        switch ( $mask )
        {
            case "m" :
                return $month;
            case "d" :
                return $day;
            case "y" :
                return $year;
            default :
                return trim( $month."/".$day."/".$year );
            }
            else
            {
                return $dataStr;
        }
    }
}

function renderChart( $chartSWF, $strURL, $strXML, $chartId, $chartWidth, $chartHeight, $debugMode = FALSE, $registerWithJS = FALSE, $setTransparent = "" )
{
    if ( $strXML == "" )
    {
        $tempData = "//Set the dataURL of the chart\n\t\tchart_".$chartId.".setDataURL(\"{$strURL}\")";
    }
    else
    {
        $tempData = "//Provide entire XML data using dataXML method\n\t\tchart_".$chartId.".setDataXML(\"{$strXML}\")";
    }
    $chartIdDiv = $chartId."Div";
    $ndebugMode = booltonum( $debugMode );
    $nregisterWithJS = booltonum( $registerWithJS );
    $nsetTransparent = $setTransparent ? "true" : "false";
    $render_chart = "\r\n\t<!-- START Script Block for Chart ".$chartId." -->\r\n\t<div id=\"{$chartIdDiv}\" align=\"center\">\r\n\t\tChart.\r\n\t</div>\r\n\t<script type=\"text/javascript\">\t\r\n\t\t//Instantiate the Chart\t\r\n\t\tvar chart_{$chartId} = new FusionCharts(\"{$chartSWF}\", \"{$chartId}\", \"{$chartWidth}\", \"{$chartHeight}\", \"{$ndebugMode}\", \"{$nregisterWithJS}\");\r\n      chart_{$chartId}.setTransparent(\"{$nsetTransparent}\");\r\n    \r\n\t\t{$tempData}\r\n\t\t//Finally, render the chart.\r\n\t\tchart_{$chartId}.render(\"{$chartIdDiv}\");\r\n\t</script>\t\r\n\t<!-- END Script Block for Chart {$chartId} -->";
    return $render_chart;
}

function renderChartHTML( $chartSWF, $strURL, $strXML, $chartId, $chartWidth, $chartHeight, $debugMode = FALSE, $registerWithJS = FALSE, $setTransparent = "" )
{
    $strFlashVars = "&chartWidth=".$chartWidth."&chartHeight=".$chartHeight."&debugMode=".booltonum( $debugMode );
    if ( $strXML == "" )
    {
        $strFlashVars .= "&dataURL=".$strURL;
    }
    else
    {
        $strFlashVars .= "&dataXML=".$strXML;
    }
    $nregisterWithJS = booltonum( $registerWithJS );
    if ( $setTransparent != "" )
    {
        $nsetTransparent = !$setTransparent ? "opaque" : "transparent";
    }
    else
    {
        $nsetTransparent = "window";
    }
    $HTML_chart = "\t<!-- START Code Block for Chart ".$chartId." -->\r\n\t<object classid=\"clsid:d27cdb6e-ae6d-11cf-96b8-444553540000\" codebase=\"http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0\" width=\"{$chartWidth}\" height=\"{$chartHeight}\" id=\"{$chartId}\">\r\n\t\t<param name=\"allowScriptAccess\" value=\"always\" />\r\n\t\t<param name=\"movie\" value=\"{$chartSWF}\"/>\t\t\r\n\t\t<param name=\"FlashVars\" value=\"{$strFlashVars}&registerWithJS={$nregisterWithJS}\" />\r\n\t\t<param name=\"quality\" value=\"high\" />\r\n\t\t<param name=\"wmode\" value=\"{$nsetTransparent}\" />\r\n\t\t<embed src=\"{$chartSWF}\" FlashVars=\"{$strFlashVars}&registerWithJS={$nregisterWithJS}\" quality=\"high\" width=\"{$chartWidth}\" height=\"{$chartHeight}\" name=\"{$chartId}\" allowScriptAccess=\"always\" type=\"application/x-shockwave-flash\" pluginspage=\"http://www.macromedia.com/go/getflashplayer\" wmode=\"{$nsetTransparent}\" />\r\n\t</object>\r\n\t<!-- END Code Block for Chart {$chartId} -->";
    return $HTML_chart;
}

function boolToNum( $bVal )
{
    if ( $bVal )
    {
        return 1;
    }
    return 0;
}

?>
