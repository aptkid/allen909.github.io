<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
function td_copy( $source, $dest )
{
    if ( is_uploadable( $dest ) )
    {
        message( _( "��ֹ" ), _( "��ֹ�����������ļ�" ) );
        button_back( );
        exit( );
    }
    return copy( $source, $dest );
}

function td_rename( $oldname, $newname )
{
    if ( is_uploadable( $newname ) )
    {
        message( _( "��ֹ" ), _( "��ֹ�����������ļ�" ) );
        button_back( );
        exit( );
    }
    return rename( $oldname, $newname );
}

function td_move_uploaded_file( $filename, $destination )
{
    if ( is_uploadable( $destination ) )
    {
        message( _( "��ֹ" ), _( "��ֹ�����������ļ�" ) );
        button_back( );
        exit( );
    }
    return move_uploaded_file( $filename, $destination );
}

function td_file_put_contents( $filename, $data, $flag = FALSE )
{
    if ( is_uploadable( $filename ) )
    {
        message( _( "��ֹ" ), _( "��ֹ�����������ļ�" ) );
        button_back( );
        exit( );
    }
    if ( $flag === FALSE )
    {
        return file_put_contents( $filename, $data );
    }
    return file_put_contents( $filename, $data, $flag );
}

function td_fopen( $filename, $mode, $use_include_path = FALSE, $zcontext = FALSE )
{
    if ( is_uploadable( $filename ) )
    {
        message( _( "��ֹ" ), _( "��ֹ�����������ļ�" ) );
        button_back( );
        exit( );
    }
    if ( $zcontext === FALSE )
    {
        return fopen( $filename, $mode, $use_include_path );
    }
    return fopen( $filename, $mode, $use_include_path, $zcontext );
}

function attach_sub_dir( )
{
    $SCRIPT_NAME = strtolower( $_SERVER['SCRIPT_NAME'] );
    if ( substr( $SCRIPT_NAME, 0, 16 ) == "/general/system/" )
    {
        $SCRIPT = substr( $SCRIPT_NAME, 16 );
    }
    else if ( substr( $SCRIPT_NAME, 0, 9 ) == "/general/" )
    {
        $SCRIPT = substr( $SCRIPT_NAME, 9 );
    }
    else if ( substr( $SCRIPT_NAME, 0, 9 ) == "/pda/pad/" )
    {
        $SCRIPT = substr( $SCRIPT_NAME, 9 );
    }
    else if ( substr( $SCRIPT_NAME, 0, 5 ) == "/pda/" )
    {
        $SCRIPT = substr( $SCRIPT_NAME, 5 );
    }
    else if ( substr( $SCRIPT_NAME, 0, 8 ) == "/mobile/" )
    {
        $SCRIPT = substr( $SCRIPT_NAME, 8 );
    }
    else
    {
        $SCRIPT = "unknown";
    }
    return substr( $SCRIPT, 0, strpos( $SCRIPT, "/" ) );
}

function attach_id_explode( $ATTACHMENT_ID )
{
    $AID = 0;
    $POS = strpos( $ATTACHMENT_ID, "@" );
    if ( $POS !== FALSE )
    {
        $AID = intval( substr( $ATTACHMENT_ID, 0, $POS ) );
        $ATTACHMENT_ID = substr( $ATTACHMENT_ID, $POS + 1 );
    }
    $YM = "";
    $POS = strpos( $ATTACHMENT_ID, "_" );
    if ( $POS !== FALSE )
    {
        $YM_TMP = substr( $ATTACHMENT_ID, 0, $POS );
        $ATTACHMENT_ID_TMP = substr( $ATTACHMENT_ID, $POS + 1 );
        if ( strlen( $YM_TMP ) == 4 && is_numeric( $YM_TMP ) )
        {
            $YM = $YM_TMP;
            $ATTACHMENT_ID = $ATTACHMENT_ID_TMP;
        }
    }
    $SIGN_KEY = "";
    $POS = strpos( $ATTACHMENT_ID, "." );
    if ( $POS !== FALSE )
    {
        $SIGN_KEY_TMP = substr( $ATTACHMENT_ID, $POS + 1 );
        $ATTACHMENT_ID_TMP = substr( $ATTACHMENT_ID, 0, $POS );
        if ( is_numeric( $SIGN_KEY_TMP ) && is_numeric( $ATTACHMENT_ID_TMP ) )
        {
            $SIGN_KEY = $SIGN_KEY_TMP;
            $ATTACHMENT_ID = $ATTACHMENT_ID_TMP;
        }
    }
    return array( "AID" => $AID, "ATTACHMENT_ID" => $ATTACHMENT_ID, "YM" => $YM, "SIGN_KEY" => $SIGN_KEY );
}

function attach_id_implode( $AID, $YM, $ATTACHMENT_ID, $SIGN_KEY = 0 )
{
    $AID = intval( $AID );
    if ( 0 < $AID )
    {
        $ATTACHMENT_ID_LONG = $AID."@".$YM."_".$ATTACHMENT_ID;
    }
    else if ( $YM != "" )
    {
        $ATTACHMENT_ID_LONG = $YM."_".$ATTACHMENT_ID;
    }
    else
    {
        $ATTACHMENT_ID_LONG = $ATTACHMENT_ID;
    }
    if ( $SIGN_KEY )
    {
        return $ATTACHMENT_ID_LONG.".".$SIGN_KEY;
    }
    return $ATTACHMENT_ID_LONG;
}

function add_attach_module( $MODULE, $MODULE_NAME = "" )
{
    $MODULE = strtolower( $MODULE );
    $query = "SELECT MODULE_ID from ATTACHMENT_MODULE where MODULE_CODE='".$MODULE."'";
    $cursor = exequery( ( ), $query );
    if ( $cursor && mysql_num_rows( $cursor ) <= 0 )
    {
        $query = "SELECT max(MODULE_ID) from ATTACHMENT_MODULE";
        $cursor = exequery( ( ), $query, TRUE );
        if ( $ROW = mysql_fetch_array( $cursor ) )
        {
            $MODULE_ID = $ROW[0] + 1;
        }
        $MAX_MODULE_ID = 200 < $MODULE_ID ? $MODULE_ID : 200;
        if ( $MODULE_NAME == "" )
        {
            $MODULE_NAME = $MODULE;
        }
        $query = "insert into ATTACHMENT_MODULE (MODULE_ID, MODULE_NAME, MODULE_CODE) values ('".$MAX_MODULE_ID."', '{$MODULE_NAME}', '{$MODULE}');";
        exequery( ( ), $query );
    }
    cache_attach_para( );
}

function attach_module_id( $MODULE )
{
    $ATTACH_PARA_ARRAY = ( "SYS_ATTACH_PARA" );
    $ATTACH_MODULE_ARRAY = $ATTACH_PARA_ARRAY['SYS_ATTACH_MODULE'];
    if ( $ATTACH_MODULE_ARRAY[$MODULE] == "" )
    {
        add_attach_module( $MODULE );
        $ATTACH_PARA_ARRAY = ( "SYS_ATTACH_PARA" );
        $ATTACH_MODULE_ARRAY = $ATTACH_PARA_ARRAY['SYS_ATTACH_MODULE'];
    }
    return $ATTACH_MODULE_ARRAY[$MODULE];
}

function attach_sign_key( $ATTACHMENT_ID, $ATTACHMENT_NAME, $ID_IS_REAL = FALSE )
{
    if ( is_office( $ATTACHMENT_NAME ) )
    {
        return 0;
    }
    $ARRAY = attach_id_explode( $ATTACHMENT_ID );
    $AID = $ARRAY['AID'];
    $ATTACHMENT_ID = $ID_IS_REAL ? attach_id_encode( $ATTACHMENT_ID, $ATTACHMENT_NAME ) : $ARRAY['ATTACHMENT_ID'];
    $YM = $ARRAY['YM'];
    $SIGN_KEY = $ARRAY['SIGN_KEY'];
    if ( $SIGN_KEY != "" )
    {
        return $SIGN_KEY;
    }
    if ( 0 < $AID )
    {
        $SIGN_KEY = $ATTACHMENT_ID * 3 + 2;
        return $SIGN_KEY;
    }
    if ( $YM != "" )
    {
        $SIGN_KEY = $ATTACHMENT_ID;
        return $SIGN_KEY;
    }
    $SIGN_KEY = attach_id_decode( $ATTACHMENT_ID, $ATTACHMENT_NAME ) * 3 + 2;
    return $SIGN_KEY;
}

function attach_sign_key_netdisk( $FILE_PATH )
{
    if ( is_office( $FILE_PATH ) )
    {
        return abs( crc32( $FILE_PATH ) );
    }
    return 0;
}

function attach_real_path( $ATTACHMENT_ID, $ATTACHMENT_NAME, $MODULE = "" )
{
    if ( $ATTACHMENT_ID == "" || $ATTACHMENT_NAME == "" || stristr( $ATTACHMENT_ID, "/" ) || stristr( $ATTACHMENT_ID, "\\" ) || stristr( $ATTACHMENT_NAME, "/" ) || stristr( $ATTACHMENT_NAME, "\\" ) )
    {
        return FALSE;
    }
    $ATTACH_PARA_ARRAY = ( "SYS_ATTACH_PARA" );
    $ATTACH_MODULE_ARRAY = $ATTACH_PARA_ARRAY['SYS_ATTACH_MODULE'];
    $ATTACH_POSITION_ARRAY = $ATTACH_PARA_ARRAY['SYS_ATTACH_POSITION'];
    $ARRAY = attach_id_explode( $ATTACHMENT_ID );
    $AID = $ARRAY['AID'];
    $ATTACHMENT_ID = $ARRAY['ATTACHMENT_ID'];
    $YM = $ARRAY['YM'];
    if ( $AID )
    {
        $query = "select * from ATTACHMENT where AID='".$AID."'";
        $cursor = exequery( ( ), $query );
        if ( $ROW = mysql_fetch_array( $cursor ) )
        {
            $POSITION = $ROW['POSITION'];
            $MODULE = $ROW['MODULE'];
            $ATTACH_ID = $ROW['ATTACH_ID'];
            $ATTACH_FILE = $ROW['ATTACH_FILE'];
            if ( $ATTACHMENT_ID != $ATTACH_ID && attach_id_decode( $ATTACHMENT_ID, $ATTACHMENT_NAME ) != $ATTACH_ID )
            {
                return FALSE;
            }
        }
        $MODULE_NAME = array_search( $MODULE, $ATTACH_MODULE_ARRAY );
        if ( !$POSITION || !$MODULE || !array_key_exists( $POSITION, $ATTACH_POSITION_ARRAY ) || $MODULE_NAME === FALSE )
        {
            return FALSE;
        }
        $FILENAME = $ATTACH_POSITION_ARRAY[$POSITION].$MODULE_NAME."/".$YM."/".$ATTACH_ID.".".$ATTACH_FILE;
        if ( file_exists( iconv2os( $FILENAME ) ) )
        {
            return FALSE;
        }
    }
    if ( $YM )
    {
        if ( $MODULE == "" )
        {
            $MODULE = attach_sub_dir( );
        }
        $PATH = MYOA_ATTACH_PATH2.$MODULE."/".$YM."/";
        $FILENAME = $PATH.$ATTACHMENT_ID.".".$ATTACHMENT_NAME;
        if ( file_exists( iconv2os( $FILENAME ) ) )
        {
            $FILENAME = $PATH.attach_id_decode( $ATTACHMENT_ID, $ATTACHMENT_NAME ).".".$ATTACHMENT_NAME;
            if ( file_exists( iconv2os( $FILENAME ) ) )
            {
                $POS1 = strrpos( $ATTACHMENT_NAME, "." );
                if ( $POS1 !== FALSE )
                {
                    $FILENAME = $PATH.$ATTACHMENT_ID.".".md5( iconv( MYOA_CHARSET, "UTF-8", substr( $ATTACHMENT_NAME, 0, $POS1 ) ) ).substr( $ATTACHMENT_NAME, $POS1 );
                }
                else
                {
                    $FILENAME = $PATH.$ATTACHMENT_ID.".".md5( iconv( MYOA_CHARSET, "UTF-8", $ATTACHMENT_NAME ) );
                }
                if ( file_exists( $FILENAME ) )
                {
                    $EXT_NAME = strtolower( substr( $ATTACHMENT_NAME, strrpos( $ATTACHMENT_NAME, "." ) + 1 ) );
                    $FILENAME = $PATH.$ATTACHMENT_ID.".".$EXT_NAME;
                    if ( file_exists( $FILENAME ) )
                    {
                        return FALSE;
                    }
                }
            }
        }
    }
    $PATH = MYOA_ATTACH_PATH;
    $FILENAME = $PATH.$ATTACHMENT_ID."/".$ATTACHMENT_NAME;
    if ( file_exists( iconv2os( $FILENAME ) ) )
    {
        $FILENAME = $PATH.attach_id_decode( $ATTACHMENT_ID, $ATTACHMENT_NAME )."/".$ATTACHMENT_NAME;
        if ( file_exists( $FILENAME ) )
        {
            $POS1 = strrpos( $ATTACHMENT_NAME, "." );
            if ( $POS1 !== FALSE )
            {
                $FILENAME = $PATH.$ATTACHMENT_ID."/".md5( iconv( MYOA_CHARSET, "UTF-8", substr( $ATTACHMENT_NAME, 0, $POS1 ) ) ).substr( $ATTACHMENT_NAME, $POS1 );
            }
            else
            {
                $FILENAME = $PATH.$ATTACHMENT_ID."/".md5( iconv( MYOA_CHARSET, "UTF-8", $ATTACHMENT_NAME ) );
            }
            if ( file_exists( $FILENAME ) )
            {
                $FILENAME = $PATH.( $ATTACHMENT_ID - 2 ) / 3."/".$ATTACHMENT_NAME;
                if ( file_exists( $FILENAME ) )
                {
                    return FALSE;
                }
            }
        }
    }
    return realpath( $FILENAME );
}

function attach_real_path_netdisk( $DISK_ID, $ATTACH_DIR, $ATTACH_NAME = "" )
{
    if ( !is_numeric( $DISK_ID ) || stristr( $ATTACH_DIR, ".." ) || stristr( $ATTACH_NAME, "/" ) || stristr( $ATTACH_NAME, "\\" ) )
    {
        message( _( "����" ), _( "�������зǷ��ַ���" ) );
        exit( );
    }
    $query = "SELECT DISK_PATH from NETDISK where DISK_ID='".$DISK_ID."'";
    $cursor = exequery( ( ), $query );
    if ( $ROW = mysql_fetch_array( $cursor ) )
    {
        $DISK_PATH = $ROW['DISK_PATH'];
    }
    else
    {
        return FALSE;
    }
    if ( $ATTACH_NAME == "" )
    {
        $FILENAME = $DISK_PATH."/".$ATTACH_DIR;
    }
    else
    {
        $FILENAME = $DISK_PATH."/".$ATTACH_DIR."/".$ATTACH_NAME;
    }
    $FILENAME = str_replace( "//", "/", $FILENAME );
    if ( file_exists( iconv2os( $FILENAME ) ) )
    {
        return FALSE;
    }
    return realpath( iconv2os( $FILENAME ) );
}

function attach_id_encode( $ATTACHMENT_ID, $ATTACHMENT_NAME )
{
    $ARRAY = attach_id_explode( $ATTACHMENT_ID );
    $ATTACHMENT_ID = $ARRAY['ATTACHMENT_ID'];
    return $ATTACHMENT_ID ^ crc32( $ATTACHMENT_NAME );
}

function attach_id_decode( $ATTACHMENT_ID, $ATTACHMENT_NAME )
{
    $ARRAY = attach_id_explode( $ATTACHMENT_ID );
    $ATTACHMENT_ID = $ARRAY['ATTACHMENT_ID'];
    return $ATTACHMENT_ID ^ crc32( $ATTACHMENT_NAME );
}

function cache_attach_para( )
{
    $SYS_ATTACH_MODULE = array( );
    $query = "SELECT * from ATTACHMENT_MODULE order by MODULE_ID";
    $cursor = exequery( ( ), $query );
    while ( $ROW = mysql_fetch_array( $cursor ) )
    {
        $SYS_ATTACH_MODULE[$ROW['MODULE_CODE']] = $ROW['MODULE_ID'];
    }
    $SYS_ATTACH_POS_ACTIVE = 2;
    $SYS_ATTACH_PATH_ACTIVE = MYOA_ATTACH_PATH2;
    $SYS_ATTACH_POSITION = array( 1 => MYOA_ATTACH_PATH, 2 => MYOA_ATTACH_PATH2 );
    $query = "SELECT * from ATTACHMENT_POSITION order by POS_ID";
    $cursor = exequery( ( ), $query );
    while ( $ROW = mysql_fetch_array( $cursor ) )
    {
        $POS_PATH = str_replace( "\\", "/", $ROW['POS_PATH'] );
        if ( substr( $POS_PATH, -1 ) != "/" )
        {
            $POS_PATH .= "/";
        }
        $SYS_ATTACH_POSITION[$ROW['POS_ID']] = $POS_PATH;
        if ( $ROW['IS_ACTIVE'] == "1" )
        {
            $SYS_ATTACH_POS_ACTIVE = $ROW['POS_ID'];
            $SYS_ATTACH_PATH_ACTIVE = $POS_PATH;
        }
    }
    $SYS_ATTACH_PARA = array( "SYS_ATTACH_MODULE" => $SYS_ATTACH_MODULE, "SYS_ATTACH_POSITION" => $SYS_ATTACH_POSITION, "SYS_ATTACH_POS_ACTIVE" => $SYS_ATTACH_POS_ACTIVE, "SYS_ATTACH_PATH_ACTIVE" => $SYS_ATTACH_PATH_ACTIVE );
    ( "SYS_ATTACH_PARA", $SYS_ATTACH_PARA, 0 );
}

function attach_url( $ATTACHMENT_ID, $ATTACHMENT_NAME, $MODULE = "", $OTHER = array( ) )
{
    if ( $MODULE == "" )
    {
        $MODULE = attach_sub_dir( );
    }
    $ATTACHMENT_ID_SRC = $ATTACHMENT_ID;
    if ( substr( $ATTACHMENT_NAME, 0, 1 ) == "*" )
    {
        $ATTACHMENT_NAME = iconv( "utf-8", MYOA_CHARSET, substr( $ATTACHMENT_NAME, 1 ) );
    }
    if ( substr( $ATTACHMENT_NAME, -1 ) == "*" )
    {
        $ATTACHMENT_NAME = iconv( "utf-8", MYOA_CHARSET, substr( $ATTACHMENT_NAME, 0, -1 ) );
    }
    $ARRAY = attach_id_explode( $ATTACHMENT_ID );
    $AID = $ARRAY['AID'];
    $ATTACHMENT_ID = $ARRAY['ATTACHMENT_ID'];
    $YM = $ARRAY['YM'];
    $SIGN_KEY = $ARRAY['SIGN_KEY'];
    if ( $SIGN_KEY == "" && is_office( $ATTACHMENT_NAME ) )
    {
        $SIGN_KEY = attach_sign_key( $ATTACHMENT_ID_SRC, $ATTACHMENT_NAME, TRUE );
    }
    $ATTACHMENT_ID_ENCODED = attach_id_encode( $ATTACHMENT_ID, $ATTACHMENT_NAME );
    $ATTACHMENT_ID_SAVE = attach_id_implode( $AID, $YM, $ATTACHMENT_ID_ENCODED, $SIGN_KEY );
    $INDEX_FILE_STYLE = get_sys_para( "INDEX_FILE_STYLE" );
    $INDEX_FILE_STYLE = $INDEX_FILE_STYLE['INDEX_FILE_STYLE'];
    $MD5_CODE = md5( $ATTACHMENT_NAME );
    $OFFICE_OP_CODE = urlencode( td_authcode( $OTHER['OFFICE']['OP'].":".$OTHER['OFFICE']['PRINT'], "ENCODE", $MD5_CODE ) );
    $OFFICE_EDIT_CODE = urlencode( td_authcode( "4", "ENCODE", $MD5_CODE ) );
    $OFFICE_PREVIEW_CODE = urlencode( td_authcode( $OTHER['OFFICE']['OP_PREVIEW'], "ENCODE", $MD5_CODE ) );
    $URL_ARRAY = array( );
    if ( $AID )
    {
        $URL_ARRAY['down'] = MYOA_ATTACH_SERVER_HTTP."/inc/attach.php?AID=".$AID."&MODULE=".$MODULE."&YM=".$YM."&ATTACHMENT_ID=".$ATTACHMENT_ID_ENCODED."&ATTACHMENT_NAME=".urlencode( $ATTACHMENT_NAME );
        $URL_ARRAY['rename'] = "ReNameFile('".$ATTACHMENT_ID_SRC."','".urlencode( $ATTACHMENT_NAME )."');";
        $URL_ARRAY['delete'] = "delete_attach('".$ATTACHMENT_ID_SRC."','".str_replace( "'", "\\'", $ATTACHMENT_NAME )."');";
        if ( is_office( $ATTACHMENT_NAME ) )
        {
            $URL_ARRAY['office_read'] = MYOA_ATTACH_SERVER_HTTP."/module/OC/?AID=".$AID."&MODULE=".$MODULE."&YM=".$YM."&ATTACHMENT_ID=".$ATTACHMENT_ID_ENCODED."&ATTACHMENT_NAME=".urlencode( $ATTACHMENT_NAME )."&SIGN_KEY=".$SIGN_KEY."&OP_CODE=".$OFFICE_OP_CODE;
            $URL_ARRAY['office_edit'] = MYOA_ATTACH_SERVER_HTTP."/module/OC/?AID=".$AID."&MODULE=".$MODULE."&YM=".$YM."&ATTACHMENT_ID=".$ATTACHMENT_ID_ENCODED."&ATTACHMENT_NAME=".urlencode( $ATTACHMENT_NAME )."&SIGN_KEY=".$SIGN_KEY."&OP_CODE=".$OFFICE_EDIT_CODE;
            $URL_ARRAY['office_preview'] = MYOA_ATTACH_SERVER_HTTP."/module/xls_preview/?AID=".$AID."&MODULE=".$MODULE."&YM=".$YM."&ATTACHMENT_ID=".$ATTACHMENT_ID_ENCODED."&ATTACHMENT_NAME=".urlencode( $ATTACHMENT_NAME )."&OP_CODE=".$OFFICE_PREVIEW_CODE;
        }
        else if ( is_ntko_pdf( $ATTACHMENT_NAME ) )
        {
            $URL_ARRAY['office_read'] = MYOA_ATTACH_SERVER_HTTP."/module/OC/?AID=".$AID."&MODULE=".$MODULE."&YM=".$YM."&ATTACHMENT_ID=".$ATTACHMENT_ID_ENCODED."&ATTACHMENT_NAME=".urlencode( $ATTACHMENT_NAME )."&OP_CODE=".$OFFICE_OP_CODE;
        }
        if ( MYOA_IS_UN == 0 && find_id( $INDEX_FILE_STYLE, strtolower( substr( $ATTACHMENT_NAME, strrpos( $ATTACHMENT_NAME, "." ) + 1 ) ) ) )
        {
            $URL_ARRAY['quick_preview'] = MYOA_ATTACH_SERVER_HTTP."/module/quick_preview/?AID=".$AID."&MODULE=".$MODULE."&YM=".$YM."&ATTACHMENT_ID=".$ATTACHMENT_ID_ENCODED."&ATTACHMENT_NAME=".urlencode( $ATTACHMENT_NAME )."&OP_CODE=".$OFFICE_PREVIEW_CODE;
        }
        if ( is_aip( $ATTACHMENT_NAME ) )
        {
            $URL_ARRAY['office_read'] = MYOA_ATTACH_SERVER_HTTP."/module/AIP/?AID=".$AID."&MODULE=".$MODULE."&YM=".$YM."&ATTACHMENT_ID=".$ATTACHMENT_ID_ENCODED."&ATTACHMENT_NAME=".urlencode( $ATTACHMENT_NAME );
            $URL_ARRAY['office_edit'] = MYOA_ATTACH_SERVER_HTTP."/module/AIP/?AID=".$AID."&MODULE=".$MODULE."&YM=".$YM."&ATTACHMENT_ID=".$ATTACHMENT_ID_ENCODED."&ATTACHMENT_NAME=".urlencode( $ATTACHMENT_NAME )."&OP=4";
        }
        if ( is_viewable( $ATTACHMENT_NAME ) || is_text( $ATTACHMENT_NAME ) )
        {
            $URL_ARRAY['view'] = MYOA_ATTACH_SERVER_HTTP."/inc/attach.php?AID=".$AID."&MODULE=".$MODULE."&YM=".$YM."&ATTACHMENT_ID=".$ATTACHMENT_ID_ENCODED."&ATTACHMENT_NAME=".urlencode( $ATTACHMENT_NAME )."&DIRECT_VIEW=1";
            if ( $OTHER['VIEW']['THUMB'] == "1" )
            {
                $URL_ARRAY['thumb'] = $URL_ARRAY['view']."&THUMB=".$OTHER['VIEW']['THUMB'];
            }
        }
        $URL_ARRAY['save'] = "SaveFile('".$MODULE.",".$ATTACHMENT_ID_SAVE."','".urlencode( $ATTACHMENT_NAME )."');";
        return $URL_ARRAY;
    }
    $URL_ARRAY['down'] = MYOA_ATTACH_SERVER_HTTP."/inc/attach.php?MODULE=".$MODULE."&YM=".$YM."&ATTACHMENT_ID=".$ATTACHMENT_ID_ENCODED."&ATTACHMENT_NAME=".urlencode( $ATTACHMENT_NAME );
    $URL_ARRAY['rename'] = "ReNameFile('".$ATTACHMENT_ID_SRC."','".urlencode( $ATTACHMENT_NAME )."');";
    $URL_ARRAY['delete'] = "delete_attach('".$ATTACHMENT_ID_SRC."','".str_replace( "'", "\\'", $ATTACHMENT_NAME )."');";
    if ( is_office( $ATTACHMENT_NAME ) )
    {
        $URL_ARRAY['office_read'] = MYOA_ATTACH_SERVER_HTTP."/module/OC/?MODULE=".$MODULE."&YM=".$YM."&ATTACHMENT_ID=".$ATTACHMENT_ID_ENCODED."&ATTACHMENT_NAME=".urlencode( $ATTACHMENT_NAME )."&SIGN_KEY=".$SIGN_KEY."&OP_CODE=".$OFFICE_OP_CODE;
        $URL_ARRAY['office_edit'] = MYOA_ATTACH_SERVER_HTTP."/module/OC/?MODULE=".$MODULE."&YM=".$YM."&ATTACHMENT_ID=".$ATTACHMENT_ID_ENCODED."&ATTACHMENT_NAME=".urlencode( $ATTACHMENT_NAME )."&SIGN_KEY=".$SIGN_KEY."&OP_CODE=".$OFFICE_EDIT_CODE;
        $URL_ARRAY['office_preview'] = MYOA_ATTACH_SERVER_HTTP."/module/xls_preview/?MODULE=".$MODULE."&YM=".$YM."&ATTACHMENT_ID=".$ATTACHMENT_ID_ENCODED."&ATTACHMENT_NAME=".urlencode( $ATTACHMENT_NAME )."&OP_CODE=".$OFFICE_PREVIEW_CODE;
    }
    else if ( is_ntko_pdf( $ATTACHMENT_NAME ) )
    {
        $URL_ARRAY['office_read'] = MYOA_ATTACH_SERVER_HTTP."/module/OC/?MODULE=".$MODULE."&YM=".$YM."&ATTACHMENT_ID=".$ATTACHMENT_ID_ENCODED."&ATTACHMENT_NAME=".urlencode( $ATTACHMENT_NAME )."&OP_CODE=".$OFFICE_OP_CODE;
    }
    if ( MYOA_IS_UN == 0 && find_id( $INDEX_FILE_STYLE, strtolower( substr( $ATTACHMENT_NAME, strrpos( $ATTACHMENT_NAME, "." ) + 1 ) ) ) )
    {
        $URL_ARRAY['quick_preview'] = MYOA_ATTACH_SERVER_HTTP."/module/quick_preview/?MODULE=".$MODULE."&YM=".$YM."&ATTACHMENT_ID=".$ATTACHMENT_ID_ENCODED."&ATTACHMENT_NAME=".urlencode( $ATTACHMENT_NAME )."&OP_CODE=".$OFFICE_PREVIEW_CODE;
    }
    if ( is_aip( $ATTACHMENT_NAME ) )
    {
        $URL_ARRAY['office_read'] = MYOA_ATTACH_SERVER_HTTP."/module/AIP/?AID=".$AID."&MODULE=".$MODULE."&YM=".$YM."&ATTACHMENT_ID=".$ATTACHMENT_ID_ENCODED."&ATTACHMENT_NAME=".urlencode( $ATTACHMENT_NAME );
        $URL_ARRAY['office_edit'] = MYOA_ATTACH_SERVER_HTTP."/module/AIP/?AID=".$AID."&MODULE=".$MODULE."&YM=".$YM."&ATTACHMENT_ID=".$ATTACHMENT_ID_ENCODED."&ATTACHMENT_NAME=".urlencode( $ATTACHMENT_NAME )."&OP=4";
    }
    if ( is_viewable( $ATTACHMENT_NAME ) || is_text( $ATTACHMENT_NAME ) )
    {
        $URL_ARRAY['view'] = MYOA_ATTACH_SERVER_HTTP."/inc/attach.php?MODULE=".$MODULE."&YM=".$YM."&ATTACHMENT_ID=".$ATTACHMENT_ID_ENCODED."&ATTACHMENT_NAME=".urlencode( $ATTACHMENT_NAME )."&DIRECT_VIEW=1";
        if ( $OTHER['VIEW']['THUMB'] == "1" )
        {
            $URL_ARRAY['thumb'] = $URL_ARRAY['view']."&THUMB=".$OTHER['VIEW']['THUMB'];
        }
    }
    $URL_ARRAY['save'] = "SaveFile('".$MODULE.",".$ATTACHMENT_ID_SAVE."','".urlencode( $ATTACHMENT_NAME )."');";
    return $URL_ARRAY;
}

function attach_url_netdisk( $DISK_ID, $ATTACH_DIR, $ATTACH_NAME = "", $OTHER = array( ) )
{
    if ( !is_numeric( $DISK_ID ) || stristr( $ATTACH_DIR, ".." ) || stristr( $ATTACH_NAME, "/" ) || stristr( $ATTACH_NAME, "\\" ) )
    {
        message( _( "����" ), _( "�������зǷ��ַ���" ) );
        exit( );
    }
    $ATTACH_DIR = str_replace( "\\", "/", $ATTACH_DIR );
    if ( $ATTACH_NAME == "" )
    {
        $POS = strrpos( $ATTACH_DIR, "/" );
        if ( $POS !== FALSE )
        {
            $ATTACH_NAME = substr( $ATTACH_DIR, $POS + 1 );
            $ATTACH_DIR = substr( $ATTACH_DIR, 0, $POS + 1 );
        }
        else
        {
            $ATTACH_NAME = $ATTACH_DIR;
            $ATTACH_DIR = "";
        }
    }
    if ( substr( $ATTACH_DIR, -1 ) != "/" )
    {
        $ATTACH_DIR .= "/";
    }
    $MD5_CODE = md5( $ATTACH_DIR.$ATTACH_NAME );
    $OFFICE_OP_CODE = urlencode( td_authcode( $OTHER['OFFICE']['OP'].":".$OTHER['OFFICE']['PRINT'], "ENCODE", $MD5_CODE ) );
    $OFFICE_EDIT_CODE = urlencode( td_authcode( "4", "ENCODE", $MD5_CODE ) );
    $OFFICE_PREVIEW_CODE = urlencode( td_authcode( $OTHER['OFFICE']['OP_PREVIEW'], "ENCODE", $MD5_CODE ) );
    $URL_ARRAY = array( );
    $URL_ARRAY['down'] = MYOA_ATTACH_SERVER_HTTP."/general/netdisk/down.php?DISK_ID=".$DISK_ID."&URL=".urlencode( $ATTACH_DIR )."&FILE_NAME=".urlencode( $ATTACH_NAME );
    if ( is_office( $ATTACH_NAME ) )
    {
        $URL_ARRAY['office_read'] = MYOA_ATTACH_SERVER_HTTP."/module/OC_NETDISK/?DISK_ID=".$DISK_ID."&fichier=".urlencode( $ATTACH_DIR.$ATTACH_NAME )."&OP_CODE=".$OFFICE_OP_CODE;
        $URL_ARRAY['office_edit'] = MYOA_ATTACH_SERVER_HTTP."/module/OC_NETDISK/?DISK_ID=".$DISK_ID."&fichier=".urlencode( $ATTACH_DIR.$ATTACH_NAME )."&OP_CODE=".$OFFICE_EDIT_CODE;
        $URL_ARRAY['office_preview'] = MYOA_ATTACH_SERVER_HTTP."/module/xls_preview/?DISK_ID=".$DISK_ID."&DISKTYPE=1&fichier=".urlencode( $ATTACH_DIR.$ATTACH_NAME )."&OP_CODE=".$OFFICE_PREVIEW_CODE;
    }
    else if ( is_ntko_pdf( $ATTACH_NAME ) )
    {
        $URL_ARRAY['office_read'] = MYOA_ATTACH_SERVER_HTTP."/module/OC_NETDISK/?DISK_ID=".$DISK_ID."&fichier=".urlencode( $ATTACH_DIR.$ATTACH_NAME )."&OP_CODE=".$OFFICE_OP_CODE;
    }
    $INDEX_FILE_STYLE = get_sys_para( "INDEX_FILE_STYLE" );
    $INDEX_FILE_STYLE = $INDEX_FILE_STYLE['INDEX_FILE_STYLE'];
    if ( MYOA_IS_UN == 0 && find_id( $INDEX_FILE_STYLE, strtolower( substr( $ATTACH_NAME, strrpos( $ATTACH_NAME, "." ) + 1 ) ) ) )
    {
        $URL_ARRAY['office_quickview'] = MYOA_ATTACH_SERVER_HTTP."/module/quick_preview/?DISK_ID=".$DISK_ID."&DISKTYPE=1&fichier=".urlencode( $ATTACH_DIR.$ATTACH_NAME )."&OP_CODE=".$OFFICE_PREVIEW_CODE;
    }
    if ( is_viewable( $ATTACH_NAME ) || is_text( $ATTACH_NAME ) )
    {
        $URL_ARRAY['view'] = MYOA_ATTACH_SERVER_HTTP."/general/netdisk/down.php?DISK_ID=".$DISK_ID."&URL=".urlencode( $ATTACH_DIR )."&FILE_NAME=".urlencode( $ATTACH_NAME )."&DIRECT_VIEW=1";
    }
    return $URL_ARRAY;
}

function attach_url_pda( $ATTACHMENT_ID, $ATTACHMENT_NAME, $P, $MODULE, $ACCESS_PRIV = 0 )
{
    global $P_VER;
    $ATTACHMENT_ID_SRC = $ATTACHMENT_ID;
    $ARRAY = attach_id_explode( $ATTACHMENT_ID );
    $AID = $ARRAY['AID'];
    $ATTACHMENT_ID = $ARRAY['ATTACHMENT_ID'];
    $YM = $ARRAY['YM'];
    $ATTACHMENT_ID_ENCODED = attach_id_encode( $ATTACHMENT_ID, $ATTACHMENT_NAME );
    $URL_ARRAY = array( );
    if ( $P_VER == 6 )
    {
        $url = "attach_show.php";
    }
    else
    {
        $url = "attach_show.php";
    }
    if ( $AID )
    {
        $URL_ARRAY['down'] = MYOA_ATTACH_SERVER_HTTP."/pda/".$url."?P=".$P."&AID=".$AID."&MODULE=".$MODULE."&ACCESS_PRIV=".$ACCESS_PRIV."&YM=".$YM."&ATTACHMENT_ID=".$ATTACHMENT_ID_ENCODED."&ATTACHMENT_NAME=".bin2hex( $ATTACHMENT_NAME );
        return $URL_ARRAY;
    }
    $URL_ARRAY['down'] = MYOA_ATTACH_SERVER_HTTP."/pda/".$url."?P=".$P."&MODULE=".$MODULE."&ACCESS_PRIV=".$ACCESS_PRIV."&YM=".$YM."&ATTACHMENT_ID=".$ATTACHMENT_ID_ENCODED."&ATTACHMENT_NAME=".bin2hex( $ATTACHMENT_NAME );
    return $URL_ARRAY;
}

function attach_url_mobile( $ATTACHMENT_ID, $ATTACHMENT_NAME, $P, $MODULE )
{
    $ATTACHMENT_ID_SRC = $ATTACHMENT_ID;
    $OA_URL = "http://".$_SERVER['HTTP_HOST'];
    $ARRAY = attach_id_explode( $ATTACHMENT_ID );
    $AID = $ARRAY['AID'];
    $ATTACHMENT_ID = $ARRAY['ATTACHMENT_ID'];
    $YM = $ARRAY['YM'];
    $ATTACHMENT_ID_ENCODED = attach_id_encode( $ATTACHMENT_ID, $ATTACHMENT_NAME );
    $URL_ARRAY = array( );
    if ( $AID )
    {
        $URL_ARRAY['down'] = $OA_URL."/mobile/attach_show.php?P=".$P."&AID=".$AID."&MODULE=".$MODULE."&YM=".$YM."&ATTACHMENT_ID=".$ATTACHMENT_ID_ENCODED."&ATTACHMENT_NAME=".bin2hex( $ATTACHMENT_NAME );
        return $URL_ARRAY;
    }
    $URL_ARRAY['down'] = $OA_URL."/mobile/attach_show.php?P=".$P."&MODULE=".$MODULE."&YM=".$YM."&ATTACHMENT_ID=".$ATTACHMENT_ID_ENCODED."&ATTACHMENT_NAME=".bin2hex( $ATTACHMENT_NAME );
    return $URL_ARRAY;
}

function attach_link( $ATTACHMENT_ID, $ATTACHMENT_NAME, $SHOW_SIZE = 0, $DOWN_PRIV = 1, $DOWN_PRIV_OFFICE = 1, $EDIT_PRIV = 0, $DELETE_PRIV = 0, $NEW_LINE = 1, $SAVE_FILE = 1, $CREATE_IMAGE = 0, $MODULE = "", $IS_UTF8 = FALSE, $FORMAT = 0 )
{
    if ( $ATTACHMENT_ID == "" )
    {
        return "";
    }
    if ( $MODULE == "" )
    {
        $MODULE = attach_sub_dir( );
    }
    $LANG_ARRAY = array( "down" => _( "����" ), "read" => _( "�Ķ�" ), "edit" => _( "�༭" ), "view" => _( "�鿴" ), "rename" => _( "������" ), "delete" => _( "ɾ��" ), "save" => _( "ת��" ), "play" => _( "����" ), "preview" => _( "����Ԥ��" ), "insert" => _( "��������" ), "quick_preview" => _( "�����Ķ�" ) );
    $INDEX_FILE_STYLE = get_sys_para( "INDEX_FILE_STYLE" );
    $INDEX_FILE_STYLE = $INDEX_FILE_STYLE['INDEX_FILE_STYLE'];
    if ( $IS_UTF8 )
    {
        foreach ( $LANG_ARRAY as $KEY => $VALUE )
        {
            $LANG_ARRAY[$KEY] = iconv( MYOA_CHARSET, "utf-8", $VALUE );
        }
    }
    $ATTACHMENT_ID_ARRAY = explode( ",", $ATTACHMENT_ID );
    $ATTACHMENT_NAME_ARRAY = explode( "*", $ATTACHMENT_NAME );
    $ATTACHMENT_NAME_SHOW_ARRAY = explode( "*", $ATTACHMENT_NAME );
    $I = 0;
    for ( ; $I < count( $ATTACHMENT_ID_ARRAY ); ++$I )
    {
        if ( $ATTACHMENT_ID_ARRAY[$I] == "" )
        {
        }
        else
        {
            continue;
        }
        $PRINT_PRIV_OFFICE = substr( $DOWN_PRIV_OFFICE, 1, 1 ) == "1" ? 1 : 0;
        $DOWN_PRIV_OFFICE_I = substr( $DOWN_PRIV_OFFICE, 0, 1 ) == "1" ? 1 : 0;
        $PRINT_PRIV_OFFICE = $PRINT_PRIV_OFFICE || $DOWN_PRIV_OFFICE_I;
        $OTHER = array( "OFFICE" => array( "OP" => $DOWN_PRIV_OFFICE_I || $EDIT_PRIV ? "7" : "5", "PRINT" => $PRINT_PRIV_OFFICE, "OP_PREVIEW" => $DOWN_PRIV_OFFICE_I || $EDIT_PRIV ) );
        $ATTACH_NAME_ZX_ARRAY = explode( ".", $ATTACHMENT_NAME_SHOW_ARRAY[$I] );
        $ATTACHMENT_NAME_I = $ATTACHMENT_NAME_ARRAY[$I];
        $URL_ARRAY = attach_url( $ATTACHMENT_ID_ARRAY[$I], $ATTACHMENT_NAME_ARRAY[$I], $MODULE, $OTHER );
        $ATTACH_IMAGE = image_mimetype( $ATTACHMENT_NAME_ARRAY[$I] );
        $ATTACHMENT_ID_ENCODED = attach_id_encode( $ATTACHMENT_ID_ARRAY[$I], $ATTACHMENT_NAME_ARRAY[$I] );
        $HEX_ID = dechex( $ATTACHMENT_ID_ENCODED );
        $ATTACH_LINK_CLASS = "attach_link";
        if ( $NEW_LINE )
        {
            $ATTACH_LINK_CLASS .= " attach_link_block";
        }
        $ATTACH_LINK .= "<span class='".$ATTACH_LINK_CLASS."' onmouseover='showMenu(this.id);' id=\"attach_{$HEX_ID}\" style='white-space: inherit;'><img src=\"".MYOA_STATIC_SERVER."/static/images/file_type/".$ATTACH_IMAGE."\" align=\"absmiddle\"> ";
        if ( $SHOW_SIZE )
        {
            $ATTACH_SIZE = sprintf( "%u", attach_size( $ATTACHMENT_ID_ARRAY[$I], $ATTACHMENT_NAME_ARRAY[$I], $MODULE ) );
            if ( 0 < floor( $ATTACH_SIZE / 1024 / 1024 ) )
            {
                $ATTACH_SIZE = round( $ATTACH_SIZE / 1024 / 1024, 2 )."MB";
            }
            else if ( 0 < floor( $ATTACH_SIZE / 1024 ) )
            {
                $ATTACH_SIZE = round( $ATTACH_SIZE / 1024, 2 )."KB";
            }
            else
            {
                $ATTACH_SIZE .= "B";
            }
        }
        if ( $DOWN_PRIV )
        {
            if ( $DOWN_PRIV_OFFICE_I || !is_ntko_office( $ATTACHMENT_NAME_ARRAY[$I] ) )
            {
                $ATTACH_LINK .= "<a class=\"attach_name\" href=\"".$URL_ARRAY['down']."\"".( MYOA_ATTACH_OFFICE_OPEN_IN_IE ? " target=\"_blank\"" : "" ).">".td_htmlspecialchars( $ATTACHMENT_NAME_SHOW_ARRAY[$I], "<>" )."</a>";
                if ( $SHOW_SIZE )
                {
                    $ATTACH_LINK .= "(".$ATTACH_SIZE.")";
                }
                $ATTACH_LINK .= "</span>\n";
                $ATTACH_LINK .= "<div id=\"attach_".$HEX_ID."_menu\" class=\"attach_div\" title=\"".$ATTACHMENT_NAME_ARRAY[$I]."\">";
                $ATTACH_LINK .= "<a href=\"".$URL_ARRAY['down']."\"".( MYOA_ATTACH_OFFICE_OPEN_IN_IE ? " target=\"_blank\"" : "" ).">".$LANG_ARRAY['down']."</a>\n";
                if ( is_media( $ATTACHMENT_NAME_ARRAY[$I] ) )
                {
                    if ( is_image( $ATTACHMENT_NAME_ARRAY[$I] ) )
                    {
                        if ( $DATA_GROUP )
                        {
                            $DATA_GROUP = $HEX_ID;
                        }
                        $ATTACH_LINK .= "<a href=\"javascript:;\" data-group=\"".$DATA_GROUP."\" data-url=\"".urlencode( $URL_ARRAY['down'] )."\" onClick=\"ShowImageGallery(this)\">".$LANG_ARRAY['play']."</a>\n";
                    }
                    else
                    {
                        $ATTACH_LINK .= "<a href=\"javascript:;\" onClick=\"window.open('/module/mediaplayer/index.php?MEDIA_NAME=".urlencode( $ATTACHMENT_NAME_ARRAY[$I] )."&MEDIA_URL=".urlencode( $URL_ARRAY['down'] )."','media".abs( $ATTACHMENT_ID_ENCODED )."','menubar=0,toolbar=0,status=1,scrollbars=1,resizable=1,width=800,height=600');\">".$LANG_ARRAY['play']."</a>\n";
                    }
                }
                if ( $SAVE_FILE && !$IS_UTF8 )
                {
                    $ATTACH_LINK .= "<a href=\"javascript:;\" onClick=\"".$URL_ARRAY['save']."\">".$LANG_ARRAY['save']."</a>\n";
                }
            }
            else
            {
                $ATTACH_LINK .= td_htmlspecialchars( $ATTACHMENT_NAME_ARRAY[$I], "<>" );
                if ( $SHOW_SIZE )
                {
                    $ATTACH_LINK .= "(".$ATTACH_SIZE.")";
                }
                $ATTACH_LINK .= "</span>\n";
                $ATTACH_LINK .= "<div id=\"attach_".$HEX_ID."_menu\" class=\"attach_div\" title=\"".$ATTACHMENT_NAME_ARRAY[$I]."\">";
            }
            if ( is_office( $ATTACHMENT_NAME_ARRAY[$I] ) )
            {
                if ( strtolower( substr( $ATTACHMENT_NAME_ARRAY[$I], -4 ) ) == ".xls" )
                {
                    $ATTACH_LINK .= "<a href=\"javascript:;\" onClick=\"window.open('".$URL_ARRAY['office_preview']."','preview".abs( $ATTACHMENT_ID_ENCODED )."','menubar=0,toolbar=0,status=0,scrollbars=0,resizable=1');\">".$LANG_ARRAY['preview']."</a>\n";
                }
                $ATTACH_LINK .= "<a href=\"javascript:;\" onClick=\"window.open('".$URL_ARRAY['office_read']."','read".abs( $ATTACHMENT_ID_ENCODED )."','menubar=0,toolbar=0,status=1,scrollbars=1,resizable=1');\">".$LANG_ARRAY['read']."</a>\n";
                if ( $EDIT_PRIV )
                {
                    $ATTACH_LINK .= "<a href=\"javascript:;\" onClick=\"window.open('".$URL_ARRAY['office_edit']."','edit".abs( $ATTACHMENT_ID_ENCODED )."','menubar=0,toolbar=0,status=1,scrollbars=1,resizable=1');\">".$LANG_ARRAY['edit']."</a>\n";
                }
            }
            else if ( is_ntko_pdf( $ATTACHMENT_NAME_ARRAY[$I] ) )
            {
                $ATTACH_LINK .= "<a href=\"javascript:;\" onClick=\"window.open('".$URL_ARRAY['office_read']."','read".abs( $ATTACHMENT_ID_ENCODED )."','menubar=0,toolbar=0,status=1,scrollbars=1,resizable=1');\">".$LANG_ARRAY['read']."</a>\n";
            }
            if ( MYOA_IS_UN == 0 && find_id( $INDEX_FILE_STYLE, strtolower( substr( $ATTACHMENT_NAME_ARRAY[$I], strrpos( $ATTACHMENT_NAME_ARRAY[$I], "." ) + 1 ) ) ) )
            {
                $ATTACH_LINK .= "<a href=\"javascript:;\" onClick=\"window.open('".$URL_ARRAY['quick_preview']."','quick_preview".abs( $ATTACHMENT_ID_ENCODED )."','menubar=0,toolbar=0,status=0,scrollbars=1,resizable=1');\">".$LANG_ARRAY['quick_preview']."</a>\n";
            }
            if ( is_aip( $ATTACHMENT_NAME_ARRAY[$I] ) )
            {
                $ATTACH_LINK .= "<a href=\"javascript:;\" onClick=\"window.open('".$URL_ARRAY['office_read']."','read".abs( $ATTACHMENT_ID_ENCODED )."','menubar=0,toolbar=0,status=1,scrollbars=1,resizable=1');\">".$LANG_ARRAY['read']."</a>\n";
                if ( $EDIT_PRIV )
                {
                    $ATTACH_LINK .= "<a href=\"javascript:;\" onClick=\"window.open('".$URL_ARRAY['office_edit']."','edit".abs( $ATTACHMENT_ID_ENCODED )."','menubar=0,toolbar=0,status=1,scrollbars=1,resizable=1');\">".$LANG_ARRAY['edit']."</a>\n";
                }
            }
            if ( $DELETE_PRIV )
            {
                $ATTACH_LINK .= "<a href=\"javascript:".$URL_ARRAY['delete']."\">".$LANG_ARRAY['delete']."</a>\n";
                if ( $MODULE == "file_folder" )
                {
                    $ATTACH_LINK .= "<a href=\"javascript:;\" onClick=\"".$URL_ARRAY['rename']."\">".$LANG_ARRAY['rename']."</a>\n";
                }
            }
            if ( $CREATE_IMAGE && is_image( $ATTACHMENT_NAME_ARRAY[$I] ) )
            {
                $ATTACH_LINK .= "<a id=\"insert_image_link_".$HEX_ID."\" href=\"javascript:InsertImage('".urlencode( $URL_ARRAY['down'] )."');\" title=\"".$ATTACHMENT_NAME_ARRAY[$I]."\">".$LANG_ARRAY['insert']."</a>\n";
            }
            $EXT_NAME = strtolower( substr( strrchr( $ATTACHMENT_NAME_ARRAY[$I], "." ), 1 ) );
            if ( $FORMAT && ( $EXT_NAME == "mht" || $EXT_NAME == "htm" || $EXT_NAME == "html" ) && !$DELETE_PRIV )
            {
                $ATTACH_LINK .= "<a href=\"javascript:;\" onClick=\"mhtFrame.location='".$URL_ARRAY['view']."';\">".$LANG_ARRAY['view']."</a>\n";
            }
            $ATTACH_LINK .= "</div>";
        }
        else
        {
            $ATTACH_LINK .= td_htmlspecialchars( $ATTACHMENT_NAME_ARRAY[$I], "<>" );
            if ( $SHOW_SIZE )
            {
                $ATTACH_LINK .= "(".$ATTACH_SIZE.")";
            }
            $ATTACH_LINK .= "</span>\n";
        }
    }
    return $ATTACH_LINK;
}

function attach_link_utf8( $ATTACHMENT_ID, $ATTACHMENT_NAME, $SHOW_SIZE = 0, $DOWN_PRIV = 1, $DOWN_PRIV_OFFICE = 1, $EDIT_PRIV = 0, $DELETE_PRIV = 0, $NEW_LINE = 1, $SAVE_FILE = 1, $CREATE_IMAGE = 0, $MODULE = "" )
{
    return attach_link( $ATTACHMENT_ID, $ATTACHMENT_NAME, $SHOW_SIZE, $DOWN_PRIV, $DOWN_PRIV_OFFICE, $EDIT_PRIV, $DELETE_PRIV, $NEW_LINE, $SAVE_FILE, $CREATE_IMAGE, $MODULE, TRUE );
}

function attach_link_pda( $ATTACHMENT_ID, $ATTACHMENT_NAME, $P, $MODULE = "", $SHOW_SIZE = 1, $DOWN_PRIV = 1, $NEW_LINE = 0, $ACCESS_PRIV = 0 )
{
    global $P_VER;
    if ( $ATTACHMENT_ID == "" )
    {
        return _( "��" );
    }
    if ( $MODULE == "" )
    {
        $MODULE = attach_sub_dir( );
    }
    $ATTACHMENT_ID_ARRAY = explode( ",", $ATTACHMENT_ID );
    $ATTACHMENT_NAME_ARRAY = explode( "*", $ATTACHMENT_NAME );
    $I = 0;
    for ( ; $I < count( $ATTACHMENT_ID_ARRAY ); ++$I )
    {
        if ( $ATTACHMENT_ID_ARRAY[$I] == "" )
        {
        }
        else
        {
            continue;
        }
        $URL_ARRAY = attach_url_pda( $ATTACHMENT_ID_ARRAY[$I], $ATTACHMENT_NAME_ARRAY[$I], $P, $MODULE, $ACCESS_PRIV );
        if ( $SHOW_SIZE )
        {
            $ATTACH_SIZE = sprintf( "%u", attach_size( $ATTACHMENT_ID_ARRAY[$I], $ATTACHMENT_NAME_ARRAY[$I], $MODULE ) );
            if ( 0 < floor( $ATTACH_SIZE / 1024 / 1024 ) )
            {
                $ATTACH_SIZE = round( $ATTACH_SIZE / 1024 / 1024, 2 )."MB";
            }
            else if ( 0 < floor( $ATTACH_SIZE / 1024 ) )
            {
                $ATTACH_SIZE = round( $ATTACH_SIZE / 1024, 2 )."KB";
            }
            else
            {
                $ATTACH_SIZE .= _( "�ֽ�" );
            }
        }
        if ( $DOWN_PRIV )
        {
            $attach_mimetype = image_mimetype( $ATTACHMENT_NAME_ARRAY[$I] );
            if ( is_image( $ATTACHMENT_NAME_ARRAY[$I] ) )
            {
                $is_image = 1;
            }
            else
            {
                $is_image = 0;
            }
            if ( $P_VER == 5 || strpos( strtolower( $_SERVER['HTTP_USER_AGENT'] ), "iphone" ) || strpos( strtolower( $_SERVER['HTTP_USER_AGENT'] ), "ipad" ) )
            {
                $ATTACH_LINK .= "<a href=\"javascript:void(0);\" is_image = \"".$is_image."\" _href=\"".$URL_ARRAY['down']."\" class=\"pda_attach\" style=\"background-image:url('".MYOA_STATIC_SERVER."/static/images/file_type/".$attach_mimetype."')\"><span>".td_htmlspecialchars( $ATTACHMENT_NAME_ARRAY[$I], "<>" )."</span><em>".$ATTACH_SIZE."</em><div class=\"ui-icon-rarrow\"></div></a>\n";
            }
            else
            {
                $ATTACH_LINK .= "<a href=\"".$URL_ARRAY['down']."\" is_image = \"".$is_image."\" class=\"pda_attach\" target=\"_blank\" style=\"background-image:url('".MYOA_STATIC_SERVER."/static/images/file_type/".$attach_mimetype."')\"><span>".td_htmlspecialchars( $ATTACHMENT_NAME_ARRAY[$I], "<>" )."<span><em>".$ATTACH_SIZE."</em><div class=\"ui-icon-rarrow\"></div></a>\n";
            }
        }
        else
        {
            $ATTACH_LINK .= td_htmlspecialchars( $ATTACHMENT_NAME_ARRAY[$I], "<>" );
        }
    }
    return $ATTACH_LINK;
}

function attach_link_mobile( $ATTACHMENT_ID, $ATTACHMENT_NAME, $P, $MODULE = "", $SHOW_SIZE = 1, $DOWN_PRIV = 1, $NEW_LINE = 0 )
{
    $OA_URL = "http://".$_SERVER['HTTP_HOST'];
    if ( $ATTACHMENT_ID == "" )
    {
        return _( "��" );
    }
    if ( $MODULE == "" )
    {
        $MODULE = attach_sub_dir( );
    }
    $ATTACHMENT_ID_ARRAY = explode( ",", $ATTACHMENT_ID );
    $ATTACHMENT_NAME_ARRAY = explode( "*", $ATTACHMENT_NAME );
    $I = 0;
    for ( ; $I < count( $ATTACHMENT_ID_ARRAY ); ++$I )
    {
        if ( $ATTACHMENT_ID_ARRAY[$I] == "" )
        {
        }
        else
        {
            continue;
        }
        $URL_ARRAY = attach_url_mobile( $ATTACHMENT_ID_ARRAY[$I], $ATTACHMENT_NAME_ARRAY[$I], $P, $MODULE );
        if ( $SHOW_SIZE )
        {
            $ATTACH_SIZE = sprintf( "%u", attach_size( $ATTACHMENT_ID_ARRAY[$I], $ATTACHMENT_NAME_ARRAY[$I], $MODULE ) );
            if ( 0 < floor( $ATTACH_SIZE / 1024 / 1024 ) )
            {
                $ATTACH_SIZE = round( $ATTACH_SIZE / 1024 / 1024, 2 )."MB";
            }
            else if ( 0 < floor( $ATTACH_SIZE / 1024 ) )
            {
                $ATTACH_SIZE = round( $ATTACH_SIZE / 1024, 2 )."KB";
            }
            else
            {
                $ATTACH_SIZE .= _( "�ֽ�" );
            }
        }
        if ( $DOWN_PRIV )
        {
            $attach_mimetype = image_mimetype( $ATTACHMENT_NAME_ARRAY[$I] );
            if ( is_image( $ATTACHMENT_NAME_ARRAY[$I] ) )
            {
                $is_image = 1;
            }
            else
            {
                $is_image = 0;
            }
            $ATTACH_LINK .= "<a href=\"".$URL_ARRAY['down']."\" is_image = \"".$is_image."\" class=\"pda_attach\" target=\"_blank\" style=\"background-image:url('".$OA_URL."/static/images/file_type/".$attach_mimetype."')\"><span>".td_htmlspecialchars( $ATTACHMENT_NAME_ARRAY[$I], "<>" )."<span><em>".$ATTACH_SIZE."</em><div class=\"ui-icon-rarrow\"></div></a>\n";
        }
        else
        {
            $ATTACH_LINK .= td_htmlspecialchars( $ATTACHMENT_NAME_ARRAY[$I], "<>" );
        }
    }
    return $ATTACH_LINK;
}

function attach_reportshop_mobile( $ATTACHMENT_ID, $ATTACHMENT_NAME, $P, $Q = 1, $DOWN_PRIV = 1, $temp_name = "" )
{
    global $P_VER;
    $OA_URL = "http://".$_SERVER['HTTP_HOST'];
    $URL_ARRAY = array( );
    $URL_ARRAY['down'] = $OA_URL."/mobile/reportshop/attach_show.php?P=".$P."&Q=".$Q."&ATTACHMENT_ID=".urlencode( $ATTACHMENT_ID )."&ATTACHMENT_NAME=".bin2hex( $ATTACHMENT_NAME )."&temp_name=".urlencode( $temp_name );
    if ( $DOWN_PRIV )
    {
        $attach_mimetype = image_mimetype( $ATTACHMENT_NAME );
        if ( is_image( $ATTACHMENT_NAME ) )
        {
            $is_image = 1;
        }
        else
        {
            $is_image = 0;
        }
        if ( $P_VER == 5 || strpos( strtolower( $_SERVER['HTTP_USER_AGENT'] ), "iphone" ) || strpos( strtolower( $_SERVER['HTTP_USER_AGENT'] ), "ipad" ) )
        {
            if ( $temp_name != "" && $Q == 0 )
            {
                $is_image = 1;
                $ATTACH_LINK .= "<a href=\"javascript:void(0);\" is_image = \"".$is_image."\"   _href=\"".$URL_ARRAY['down']."\" class=\"pda_attach_img\"    )\"><img src='/static/images/sms_type67.gif' /></a>\n";
                return $ATTACH_LINK;
            }
            $ATTACH_LINK .= "<a href=\"javascript:void(0);\"  is_image = \"".$is_image."\"   _href=\"".$URL_ARRAY['down']."\"  class=\"pda_attach_rp\" ><span><img src='".$OA_URL."/static/images/file_type/".$attach_mimetype."'>".td_htmlspecialchars( $ATTACHMENT_NAME, "<>" )."</span></a>\n";
            return $ATTACH_LINK;
        }
        if ( $temp_name != "" && $Q == 0 )
        {
            $is_image = 1;
            $ATTACH_LINK .= "<a href=\"".$URL_ARRAY['down']."\" is_image = \"".$is_image."\" class=\"pda_attach_img\"   target=\"_blank\" )\"><img src='/static/images/sms_type67.gif' /></a>\n";
            return $ATTACH_LINK;
        }
        $ATTACH_LINK .= "<a href=\"".$URL_ARRAY['down']."\" is_image = \"".$is_image."\" class=\"pda_attach_rp\" target=\"_blank\" ><span><img src='".$OA_URL."/static/images/file_type/".$attach_mimetype."'>".td_htmlspecialchars( $ATTACHMENT_NAME, "<>" )."</span></a>\n";
        return $ATTACH_LINK;
    }
    $ATTACH_LINK .= td_htmlspecialchars( $ATTACHMENT_NAME, "<>" );
    return $ATTACH_LINK;
}

function attach_url_old( $ATTACHMENT_ID, $ATTACHMENT_NAME )
{
    $rand = rand( );
    $URL_ARRAY = array( );
    $URL_ARRAY['down'] = "/inc/attach_old.php?ATTACHMENT_ID=".urlencode( $ATTACHMENT_ID )."&ATTACHMENT_NAME=".urlencode( $ATTACHMENT_NAME );
    $URL_ARRAY['view'] = "/inc/attach_old.php?ATTACHMENT_ID=".urlencode( $ATTACHMENT_ID )."&ATTACHMENT_NAME=".urlencode( $ATTACHMENT_NAME ).( "&DIRECT_VIEW=1?".$rand );
    return $URL_ARRAY;
}

function upload_old( $ATTACHMENT, $ATTACHMENT_NAME )
{
    if ( strstr( $ATTACHMENT_NAME, "/" ) || strstr( $ATTACHMENT_NAME, "\\" ) )
    {
        message( _( "����" ), _( "��ֹ�ϴ����ļ����͡�" ) );
        button_back( );
        exit( );
    }
    $UPLOAD_MAX_FILESIZE = get_cfg_var( "upload_max_filesize" );
    if ( file_exists( $ATTACHMENT ) )
    {
        message( _( "�����ϴ�ʧ��" ), _( "ԭ�򣺸����ļ�Ϊ�ջ��ļ���̫�����򸽼����� ".$UPLOAD_MAX_FILESIZE." �ֽڣ����ļ�·�������ڣ�" ) );
        button_back( );
        exit( );
    }
    if ( $_FILES['ATTACHMENT']['size'] == 0 && $_FILES['ATTACHMENT1']['size'] == 0 )
    {
        @unlink( $ATTACHMENT );
        message( _( "����" ), _( "�����ϴ����ļ������������ť��ѡ��һ����ȷ���ļ���" ) );
        button_back( );
        exit( );
    }
    if ( strstr( $ATTACHMENT_NAME, "'" ) )
    {
        @unlink( $ATTACHMENT );
        message( _( "�����ϴ�ʧ��" ), _( "ԭ�򣺸����ļ������ܺ���'�ţ�" ) );
        button_back( );
        exit( );
    }
    $ATTACHMENT_ID = mt_rand( );
    $RESULT = add_attach_old( $ATTACHMENT, $ATTACHMENT_ID, $ATTACHMENT_NAME );
    @unlink( $ATTACHMENT );
    if ( $RESULT )
    {
        message( _( "�����ϴ�ʧ��" ), _( "ԭ�򣺸����ļ�Ϊ�ջ��ļ���̫�����򸽼����� ".$UPLOAD_MAX_FILESIZE." �ֽڣ����ļ�·�������ڣ�" ) );
        button_back( );
        exit( );
    }
    return $ATTACHMENT_ID;
}

function add_attach_old( $SOURCE_FILE, $ATTACHMENT_ID, $ATTACHMENT_NAME )
{
    if ( stristr( $ATTACHMENT_ID, ".." ) )
    {
        return FALSE;
    }
    $PATH = MYOA_ATTACH_PATH;
    $ATTACHMENT_ID_ARRAY = explode( "/", str_replace( "\\", "/", $ATTACHMENT_ID ) );
    $I = 0;
    for ( ; $I < count( $ATTACHMENT_ID_ARRAY ); ++$I )
    {
        if ( $ATTACHMENT_ID_ARRAY[$I] == "" )
        {
            $PATH .= "/".$ATTACHMENT_ID_ARRAY[$I];
            if ( file_exists( $PATH ) )
            {
                mkdir( $PATH, 448 );
            }
        }
    }
    $FILENAME = $PATH."/".$ATTACHMENT_NAME;
    return td_copy( $SOURCE_FILE, $FILENAME );
}

function delete_attach_old( $ATTACHMENT_ID, $ATTACHMENT_NAME )
{
    if ( stristr( $ATTACHMENT_ID, ".." ) )
    {
        return FALSE;
    }
    $ATTACHMENT_ID_ARRAY = explode( ",", $ATTACHMENT_ID );
    $ATTACHMENT_NAME_ARRAY = explode( "*", $ATTACHMENT_NAME );
    $I = 0;
    for ( ; $I < count( $ATTACHMENT_ID_ARRAY ); ++$I )
    {
        if ( $ATTACHMENT_ID_ARRAY[$I] == "" )
        {
            $ATTACHMENT_ID = $ATTACHMENT_ID_ARRAY[$I];
            $PATH = MYOA_ATTACH_PATH.$ATTACHMENT_ID;
            $FILENAME = $PATH."/".$ATTACHMENT_NAME_ARRAY[$I];
            if ( file_exists( $FILENAME ) )
            {
                $ATTACHMENT_ID = ( $ATTACHMENT_ID_ARRAY[$I] - 2 ) / 3;
                $PATH = MYOA_ATTACH_PATH.$ATTACHMENT_ID;
                $FILENAME = $PATH."/".$ATTACHMENT_NAME_ARRAY[$I];
            }
            if ( file_exists( $FILENAME ) )
            {
                @unlink( $FILENAME );
                @rmdir( $PATH );
            }
            $ATTACHMENT_ID = $ATTACHMENT_ID * 3 + 2;
            $query = "delete from ATTACHMENT_EDIT where ATTACHMENT_ID='".$ATTACHMENT_ID."'";
            exequery( ( ), $query );
        }
    }
}

function upload( $PREFIX = "ATTACHMENT", $MODULE = "", $OUTPUT = TRUE )
{
    if ( strstr( $MODULE, "/" ) || strstr( $MODULE, "\\" ) )
    {
        if ( $OUTPUT )
        {
            return _( "�������зǷ��ַ���" );
        }
        message( _( "����" ), _( "�������зǷ��ַ���" ) );
        exit( );
    }
    $ATTACHMENTS = array( "ID" => "", "NAME" => "" );
    reset( &$_FILES );
    foreach ( $_FILES as $KEY => $ATTACHMENT )
    {
        if ( $ATTACHMENT['error'] == 4 )
        {
        }
        else
        {
            continue;
        }
        $data_charset = isset( $_GET['data_charset'] ) ? $_GET['data_charset'] : isset( $_POST['data_charset'] ) ? $_POST['data_charset'] : "";
        $ATTACH_NAME = $data_charset != "" ? td_iconv( $ATTACHMENT['name'], $data_charset, MYOA_CHARSET ) : $ATTACHMENT['name'];
        $ATTACH_SIZE = $ATTACHMENT['size'];
        $ATTACH_ERROR = $ATTACHMENT['error'];
        $ATTACH_FILE = $ATTACHMENT['tmp_name'];
        $ERROR_DESC = "";
        if ( $ATTACH_ERROR == UPLOAD_ERR_OK )
        {
            if ( is_uploadable( $ATTACH_NAME ) )
            {
                $ERROR_DESC = sprintf( _( "��ֹ�ϴ���׺��Ϊ[%s]���ļ�" ), substr( $ATTACH_NAME, strrpos( $ATTACH_NAME, "." ) + 1 ) );
            }
            if ( find_id( "/", $ATTACH_NAME ) || find_id( "\\", $ATTACH_NAME ) || find_id( "'", $ATTACH_NAME ) || find_id( "\"", $ATTACH_NAME ) || find_id( ":", $ATTACH_NAME ) || find_id( "*", $ATTACH_NAME ) || find_id( "?", $ATTACH_NAME ) || find_id( "<", $ATTACH_NAME ) || find_id( ">", $ATTACH_NAME ) || find_id( "|", $ATTACH_NAME ) )
            {
                $ERROR_DESC = sprintf( _( "�ļ���[%s]����[/\\'\":*?<>|]�ȷǷ��ַ�" ), $ATTACH_NAME );
            }
            if ( $ATTACH_SIZE == 0 )
            {
                $ERROR_DESC = sprintf( _( "�ļ�[%s]��СΪ0�ֽ�" ), $ATTACH_NAME );
            }
            if ( $ERROR_DESC == "" )
            {
                $ATTACH_ID = add_attach( $ATTACH_FILE, $ATTACH_NAME, $MODULE );
                if ( $ATTACH_ID === FALSE )
                {
                    $ERROR_DESC = sprintf( _( "�ļ�[%s]�ϴ�ʧ��" ), $ATTACH_NAME );
                }
                else
                {
                    $ATTACHMENTS .= "ID";
                    $ATTACHMENTS .= "NAME";
                }
            }
            @unlink( $ATTACH_FILE );
        }
        else if ( $ATTACH_ERROR == UPLOAD_ERR_INI_SIZE )
        {
            $ERROR_DESC = sprintf( _( "�ļ�[%s]�Ĵ�С������ϵͳ���ƣ�%s��" ), $ATTACH_NAME, ini_get( "upload_max_filesize" ) );
        }
        else if ( $ATTACH_ERROR == UPLOAD_ERR_FORM_SIZE )
        {
            $ERROR_DESC = sprintf( _( "�ļ�[%s]�Ĵ�С�����˱�������" ), $ATTACH_NAME );
        }
        else if ( $ATTACH_ERROR == UPLOAD_ERR_PARTIAL )
        {
            $ERROR_DESC = sprintf( _( "�ļ�[%s]�ϴ�������" ), $ATTACH_NAME );
        }
        else if ( $ATTACH_ERROR == UPLOAD_ERR_NO_TMP_DIR )
        {
            $ERROR_DESC = sprintf( _( "�ļ�[%s]�ϴ�ʧ�ܣ��Ҳ�����ʱ�ļ���" ), $ATTACH_NAME );
        }
        else if ( $ATTACH_ERROR == UPLOAD_ERR_CANT_WRITE )
        {
            $ERROR_DESC = sprintf( _( "�ļ�[%s]д��ʧ��" ), $ATTACH_NAME );
        }
        else
        {
            $ERROR_DESC = sprintf( _( "δ֪����[���룺%s]" ), $ATTACH_ERROR );
        }
        if ( !( $ERROR_DESC != "" ) )
        {
            continue;
        }
        else if ( $OUTPUT )
        {
            delete_attach( $ATTACHMENTS['ID'], $ATTACHMENTS['NAME'], $MODULE );
            return $ERROR_DESC;
        }
        else
        {
            message( _( "����" ), $ERROR_DESC );
        }
    }
    return $ATTACHMENTS;
}

function add_attach( $SOURCE_FILE, $ATTACH_NAME, $MODULE = "", $YM = "", $ATTACH_SIGN = 0, $ATTACH_ID = "" )
{
    $ATTACH_PARA_ARRAY = ( "SYS_ATTACH_PARA" );
    $ATTACH_POS_ACTIVE = $ATTACH_PARA_ARRAY['SYS_ATTACH_POS_ACTIVE'];
    $ATTACH_PATH_ACTIVE = $ATTACH_PARA_ARRAY['SYS_ATTACH_PATH_ACTIVE'];
    if ( file_exists( $SOURCE_FILE ) )
    {
        return FALSE;
    }
    if ( $MODULE == "" )
    {
        $MODULE = attach_sub_dir( );
    }
    if ( $YM == "" )
    {
        $YM = date( "ym" );
    }
    $PATH = $ATTACH_PATH_ACTIVE.$MODULE;
    if ( !file_exists( $PATH ) || !is_dir( $PATH ) )
    {
        mkdir( $PATH, 448 );
    }
    $PATH = $PATH."/".$YM;
    if ( !file_exists( $PATH ) || !is_dir( $PATH ) )
    {
        mkdir( $PATH, 448 );
    }
    $ATTACH_FILE = MYOA_ATTACH_NAME_FORMAT ? md5( $ATTACH_NAME ).".td" : $ATTACH_NAME;
    $ATTACH_ID = mt_rand( );
    $FILENAME = $PATH."/".$ATTACH_ID.".".$ATTACH_FILE;
    if ( file_exists( $FILENAME ) )
    {
        $ATTACH_ID = mt_rand( );
        $FILENAME = $PATH."/".$ATTACH_ID.".".$ATTACH_FILE;
    }
    $ATTACHMENT_TYPE = strtolower( substr( $ATTACH_NAME, strrpos( $ATTACH_NAME, "." ) ) );
    $PARA_VALUE = get_sys_para( "ATTACH_ENCRYPT", FALSE );
    $ATTACH_ENCRYPT = unserialize( $PARA_VALUE['ATTACH_ENCRYPT'] );
    if ( is_array( $ATTACH_ENCRYPT ) && $ATTACH_ENCRYPT['ENABLE'] == 1 && find_id( strtolower( $ATTACH_ENCRYPT['MODULES'] ), strtolower( $MODULE ) ) && find_id( strtolower( $ATTACH_ENCRYPT['TYPES'] ), ltrim( $ATTACHMENT_TYPE, "." ) ) && ( $ATTACH_ENCRYPT['COMPLETE'] == "0" || $ATTACH_ENCRYPT['COMPLETE'] == "1" && ( $ATTACH_ENCRYPT['MAX_SIZE'] == 0 || filesize( $SOURCE_FILE ) <= $ATTACH_ENCRYPT['MAX_SIZE'] * 1024 ) ) )
    {
        include_once( "inc/encryptor/encryptor.php" );
        $encryptor = new TDEncryptor( $SOURCE_FILE );
        $HEADER = $encryptor->getHeaderHead( );
        if ( $HEADER['header_identifier'] != HEADER_IDENTIFIER )
        {
            return FALSE;
        }
        return FALSE;
    }
    if ( !$ATTACH_ENCRYPT['METHOD']( $FILENAME, $ATTACH_ENCRYPT['METHOD'], $ATTACH_ENCRYPT['COMPLETE'] == "1" ) && @!td_copy( @$SOURCE_FILE, $FILENAME ) && !td_copy( @$SOURCE_FILE, $FILENAME ) )
    {
        return FALSE;
    }
    $ATTACH_SIGN = is_office( $ATTACH_NAME ) ? $ATTACH_SIGN : 0;
    $query = "insert into ATTACHMENT (POSITION, MODULE, YM, ATTACH_ID, ATTACH_FILE, ATTACH_NAME, ATTACH_SIGN) values ('".$ATTACH_POS_ACTIVE."', '".attach_module_id( $MODULE ).( "', '".$YM."', '{$ATTACH_ID}', '{$ATTACH_FILE}', '{$ATTACH_NAME}', '{$ATTACH_SIGN}');" );
    exequery( ( ), $query );
    $AID = mysql_insert_id( );
    if ( $AID <= 0 )
    {
        return FALSE;
    }
    $ATTACH_ID_NEW = $AID."@".$YM."_".$ATTACH_ID;
    if ( is_office( $ATTACH_NAME ) && $ATTACH_SIGN != 0 )
    {
        $ATTACH_ID_NEW .= ".".$ATTACH_SIGN;
    }
    return $ATTACH_ID_NEW;
}

function decrypt_attach( $FILE_SRC, $FILE_DEST )
{
    $bSuccess = FALSE;
    include_once( "inc/encryptor/encryptor.php" );
    $encryptor = new TDEncryptor( $FILE_SRC );
    $HEADER = $encryptor->getHeaderHead( );
    if ( $HEADER['header_identifier'] == HEADER_IDENTIFIER )
    {
        $bSuccess = $encryptor->decryptFile( $FILE_DEST );
    }
    $encryptor->closeFile( );
    return $bSuccess;
}

function delete_attach( $ATTACHMENT_ID, $ATTACHMENT_NAME, $MODULE = "" )
{
    if ( stristr( $ATTACHMENT_ID, ".." ) || stristr( $ATTACHMENT_ID, "/" ) || stristr( $ATTACHMENT_ID, "\\" ) || stristr( $ATTACHMENT_NAME, ".." ) || stristr( $ATTACHMENT_NAME, "/" ) || stristr( $ATTACHMENT_NAME, "\\" ) || stristr( $MODULE, ".." ) || stristr( $MODULE, "/" ) || stristr( $MODULE, "\\" ) )
    {
        return FALSE;
    }
    if ( $MODULE == "" )
    {
        $MODULE = attach_sub_dir( );
    }
    $ATTACHMENT_ID_ARRAY = explode( ",", $ATTACHMENT_ID );
    $ATTACHMENT_NAME_ARRAY = explode( "*", $ATTACHMENT_NAME );
    $I = 0;
    for ( ; $I < count( $ATTACHMENT_ID_ARRAY ); ++$I )
    {
        if ( $ATTACHMENT_ID_ARRAY[$I] == "" )
        {
            $FILENAME = attach_real_path( $ATTACHMENT_ID_ARRAY[$I], $ATTACHMENT_NAME_ARRAY[$I], $MODULE );
            if ( $FILENAME )
            {
                if ( MYOA_IS_RECYCLE && $MODULE == "file_folder" )
                {
                    if ( recycle_file( $FILENAME, "file_folder" ) )
                    {
                        @unlink( $FILENAME );
                    }
                }
                else if ( MYOA_IS_RECYCLE && $MODULE == "email" )
                {
                    if ( recycle_file( $FILENAME, "email" ) )
                    {
                        @unlink( $FILENAME );
                    }
                }
                else if ( MYOA_IS_RECYCLE && $MODULE == "workflow" )
                {
                    if ( recycle_file( $FILENAME, "workflow" ) )
                    {
                        @unlink( $FILENAME );
                    }
                }
                else
                {
                    @unlink( $FILENAME );
                }
                if ( strstr( $ATTACHMENT_ID_ARRAY[$I], "_" ) )
                {
                    @rmdir( @dirname( $FILENAME ) );
                }
            }
            $ARRAY = attach_id_explode( $ATTACHMENT_ID_ARRAY[$I] );
            if ( $MODULE == "news" && is_image( $ATTACHMENT_NAME_ARRAY[$I] ) )
            {
                $ATTACHMENT_TYPE = substr( $ATTACHMENT_NAME_ARRAY[$I], strrpos( $ATTACHMENT_NAME_ARRAY[$I], "." ) );
                delete_attach_old( "pic_news", $ARRAY['ATTACHMENT_ID'].$ATTACHMENT_TYPE );
            }
            $ATTACHMENT_ID = attach_id_encode( $ATTACHMENT_ID_ARRAY[$I], $ATTACHMENT_NAME_ARRAY[$I] );
            $query = "delete from ATTACHMENT_EDIT where ATTACHMENT_ID='".$ATTACHMENT_ID."'";
            exequery( ( ), $query );
            $AID = $ARRAY['AID'];
            if ( $AID )
            {
                $query = "update ATTACHMENT set DEL_FLAG=1 where AID='".$AID."'";
                exequery( ( ), $query );
            }
        }
    }
}

function rename_attach( $ATTACHMENT_ID, $ATTACHMENT_NAME_OLD, $ATTACHMENT_NAME_NEW, $MODULE = "" )
{
    $ATTACH_PARA_ARRAY = ( "SYS_ATTACH_PARA" );
    $ATTACH_MODULE_ARRAY = $ATTACH_PARA_ARRAY['SYS_ATTACH_MODULE'];
    $ATTACH_POSITION_ARRAY = $ATTACH_PARA_ARRAY['SYS_ATTACH_POSITION'];
    $ARRAY = attach_id_explode( $ATTACHMENT_ID );
    $AID = $ARRAY['AID'];
    $ATTACHMENT_ID = $ARRAY['ATTACHMENT_ID'];
    $YM = $ARRAY['YM'];
    if ( $AID )
    {
        $query = "select * from ATTACHMENT where AID='".$AID."'";
        $cursor = exequery( ( ), $query );
        if ( $ROW = mysql_fetch_array( $cursor ) )
        {
            $POSITION = $ROW['POSITION'];
            $MODULE = $ROW['MODULE'];
            $ATTACH_ID = $ROW['ATTACH_ID'];
            $ATTACH_FILE = $ROW['ATTACH_FILE'];
            if ( $ATTACHMENT_ID != $ATTACH_ID && attach_id_decode( $ATTACHMENT_ID, $ATTACHMENT_NAME ) != $ATTACH_ID )
            {
                return FALSE;
            }
        }
        $MODULE_NAME = array_search( $MODULE, $ATTACH_MODULE_ARRAY );
        if ( !$POSITION || !$MODULE || !array_key_exists( $POSITION, $ATTACH_POSITION_ARRAY ) || $MODULE_NAME === FALSE )
        {
            return FALSE;
        }
        $ATTACH_FILE_NEW = MYOA_ATTACH_NAME_FORMAT ? md5( $ATTACHMENT_NAME_NEW ).".td" : $ATTACHMENT_NAME_NEW;
        $FILENAME = $ATTACH_POSITION_ARRAY[$POSITION].$MODULE_NAME."/".$YM."/".$ATTACH_ID.".".$ATTACH_FILE;
        $FILENAME_NEW = $ATTACH_POSITION_ARRAY[$POSITION].$MODULE_NAME."/".$YM."/".$ATTACH_ID.".".$ATTACH_FILE_NEW;
        if ( file_exists( iconv2os( $FILENAME ) ) )
        {
            message( _( "��ʾ" ), _( "ԭ�ļ������ڣ�" ) );
            exit( );
        }
        td_rename( $FILENAME, $FILENAME_NEW );
        $query = "update ATTACHMENT set  ATTACH_FILE='".$ATTACH_FILE_NEW."', ATTACH_NAME='{$ATTACHMENT_NAME_NEW}' where AID='{$AID}'";
        exequery( ( ), $query );
        $FILENAME_NEW = $ATTACHMENT_NAME_NEW;
        return $FILENAME_NEW;
    }
    if ( $YM )
    {
        if ( $MODULE == "" )
        {
            $MODULE = attach_sub_dir( );
        }
        $PATH = MYOA_ATTACH_PATH2.$MODULE."/".$YM."/";
        $FILENAME = $PATH.$ATTACHMENT_ID.".".$ATTACHMENT_NAME_OLD;
        $FILENAME_NEW = $PATH.$ATTACHMENT_ID.".".$ATTACHMENT_NAME_NEW;
        if ( file_exists( iconv2os( $FILENAME ) ) )
        {
            $FILENAME = $PATH.attach_id_decode( $ATTACHMENT_ID, $ATTACHMENT_NAME_OLD ).".".$ATTACHMENT_NAME_OLD;
            $FILENAME_NEW = $PATH.attach_id_decode( $ATTACHMENT_ID, $ATTACHMENT_NAME_NEW ).".".$ATTACHMENT_NAME_NEW;
            if ( file_exists( iconv2os( $FILENAME ) ) )
            {
                $POS1 = strrpos( $ATTACHMENT_NAME_OLD, "." );
                if ( $POS1 !== FALSE )
                {
                    $FILENAME = $PATH.$ATTACHMENT_ID.".".md5( iconv( MYOA_CHARSET, "UTF-8", substr( $ATTACHMENT_NAME_OLD, 0, $POS1 ) ) ).substr( $ATTACHMENT_NAME_OLD, $POS1 );
                    $FILENAME_NEW = $PATH.$ATTACHMENT_ID.".".md5( iconv( MYOA_CHARSET, "UTF-8", substr( $ATTACHMENT_NAME_OLD, 0, $POS1 ) ) ).substr( $ATTACHMENT_NAME_NEW, $POS1 );
                }
                else
                {
                    $FILENAME = $PATH.$ATTACHMENT_ID.".".md5( iconv( MYOA_CHARSET, "UTF-8", $ATTACHMENT_NAME_OLD ) );
                    $FILENAME_NEW = $PATH.$ATTACHMENT_ID.".".md5( iconv( MYOA_CHARSET, "UTF-8", $ATTACHMENT_NAME_NEW ) );
                }
                if ( file_exists( $FILENAME ) )
                {
                    message( _( "��ʾ" ), _( "ԭ�ļ������ڣ�" ) );
                    exit( );
                }
            }
        }
        td_rename( $FILENAME, $FILENAME_NEW );
        $FILENAME_NEW = $ATTACHMENT_NAME_NEW;
        return $FILENAME_NEW;
    }
    $PATH = MYOA_ATTACH_PATH;
    $FILENAME = $PATH.$ATTACHMENT_ID."/".$ATTACHMENT_NAME_OLD;
    if ( file_exists( iconv2os( $FILENAME ) ) )
    {
        $FILENAME = $PATH.attach_id_decode( $ATTACHMENT_ID, $ATTACHMENT_NAME_OLD )."/".$ATTACHMENT_NAME_OLD;
        if ( file_exists( iconv2os( $FILENAME_OLD ) ) )
        {
            $POS1 = strrpos( $ATTACHMENT_NAME_OLD, "." );
            if ( $POS1 !== FALSE )
            {
                $FILENAME = $PATH.$ATTACHMENT_ID."/".md5( iconv( MYOA_CHARSET, "UTF-8", substr( $ATTACHMENT_NAME_OLD, 0, $POS1 ) ) ).substr( $ATTACHMENT_NAME_OLD, $POS1 );
                $FILENAME_NEW = $PATH.$ATTACHMENT_ID."/".md5( iconv( MYOA_CHARSET, "UTF-8", substr( $ATTACHMENT_NAME_NEW, 0, $POS1 ) ) ).substr( $ATTACHMENT_NAME_NEW, $POS1 );
            }
            else
            {
                $FILENAME = $PATH.$ATTACHMENT_ID."/".md5( iconv( MYOA_CHARSET, "UTF-8", $ATTACHMENT_NAME_OLD ) );
                $FILENAME_NEW = $PATH.$ATTACHMENT_ID."/".md5( iconv( MYOA_CHARSET, "UTF-8", $ATTACHMENT_NAME_NEW ) );
            }
            if ( file_exists( $FILENAME ) )
            {
                $FILENAME = $PATH.( $ATTACHMENT_ID - 2 ) / 3."/".$ATTACHMENT_NAME_OLD;
                $FILENAME_NEW = $PATH.( $ATTACHMENT_ID - 2 ) / 3."/".$ATTACHMENT_NAME_NEW;
                if ( file_exists( $FILENAME ) )
                {
                    message( _( "��ʾ" ), _( "ԭ�ļ������ڣ�" ) );
                    exit( );
                }
            }
        }
    }
    td_rename( $FILENAME, $FILENAME_NEW );
    $FILENAME_NEW = $ATTACHMENT_NAME_NEW;
    return $FILENAME_NEW;
}

function attach_size( $ATTACHMENT_ID, $ATTACHMENT_NAME, $MODULE = "" )
{
    $FILENAME = attach_real_path( $ATTACHMENT_ID, $ATTACHMENT_NAME, $MODULE );
    if ( file_exists( $FILENAME ) )
    {
        return 0;
    }
    include_once( "inc/encryptor/encryptor.php" );
    $encryptor = new TDEncryptor( $FILENAME );
    $HEADER = $encryptor->getHeaderHead( );
    if ( $HEADER['header_identifier'] == HEADER_IDENTIFIER )
    {
        return $HEADER['original_size'];
    }
    return filesize( $FILENAME );
}

function copy_attach( $ATTACHMENT_ID, $ATTACHMENT_NAME, $MODULE_SRC = "", $MODULE_DESC = "", $ID_IS_REAL = TRUE )
{
    if ( stristr( $ATTACHMENT_ID, "/" ) || stristr( $ATTACHMENT_ID, "\\" ) || stristr( $ATTACHMENT_NAME, "/" ) || stristr( $ATTACHMENT_NAME, "\\" ) || stristr( $MODULE_SRC, "/" ) || stristr( $MODULE_SRC, "\\" ) || stristr( $MODULE_DESC, "/" ) || stristr( $MODULE_DESC, "\\" ) )
    {
        message( _( "����" ), _( "�������зǷ��ַ���" ) );
        exit( );
    }
    $ATTACHMENT_ID_ARRAY = explode( ",", $ATTACHMENT_ID );
    $ATTACHMENT_NAME_ARRAY = explode( "*", $ATTACHMENT_NAME );
    $I = 0;
    for ( ; $I < count( $ATTACHMENT_ID_ARRAY ); ++$I )
    {
        if ( $ATTACHMENT_ID_ARRAY[$I] == "" )
        {
            $SOURCE_FILE = attach_real_path( $ATTACHMENT_ID_ARRAY[$I], $ATTACHMENT_NAME_ARRAY[$I], $MODULE_SRC );
            if ( $SOURCE_FILE === FALSE )
            {
                $SIGN_KEY = attach_sign_key( $ATTACHMENT_ID_ARRAY[$I], $ATTACHMENT_NAME_ARRAY[$I], $ID_IS_REAL );
                $ATTACH_ID_NEW = add_attach( $SOURCE_FILE, $ATTACHMENT_NAME_ARRAY[$I], $MODULE_DESC, "", $SIGN_KEY );
                if ( $ATTACH_ID_NEW === FALSE )
                {
                    $ATTACHMENT_ID_STR .= $ATTACH_ID_NEW.",";
                }
            }
        }
    }
    return substr( $ATTACHMENT_ID_STR, 0, -1 );
}

function copy_attach_netdisk( $ATTACH_DIR, $ATTACH_NAME, $DISK_ID, $MODULE = "" )
{
    if ( stristr( $MODULE, "/" ) || stristr( $MODULE, "\\" ) )
    {
        message( _( "����" ), _( "�������зǷ��ַ���" ) );
        exit( );
    }
    $ATTACH_NAME_ARRAY = explode( "*", $ATTACH_NAME );
    $ATTACH_DIR_ARRAY = explode( "*", $ATTACH_DIR );
    $DISK_ID_ARRAY = explode( "*", $DISK_ID );
    $I = 0;
    for ( ; $I < count( $ATTACH_NAME_ARRAY ); ++$I )
    {
        if ( $ATTACH_NAME_ARRAY[$I] == "" )
        {
        }
        else
        {
            continue;
        }
        $SOURCE_FILE = attach_real_path_netdisk( $DISK_ID_ARRAY[$I], $ATTACH_DIR_ARRAY[$I], $ATTACH_NAME_ARRAY[$I] );
        $SIGN_KEY = attach_sign_key_netdisk( $SOURCE_FILE );
        $ATTACH_ID_NEW = add_attach( $SOURCE_FILE, $ATTACH_NAME_ARRAY[$I], $MODULE, "", $SIGN_KEY );
        if ( $ATTACH_ID_NEW === FALSE )
        {
            return FALSE;
        }
        $ATTACHMENT_ID_STR .= $ATTACH_ID_NEW.",";
    }
    return $ATTACHMENT_ID_STR;
}

function copy_sel_attach( $ATTACH_NAME, $ATTACH_DIR, $DISK_ID )
{
    if ( $ATTACH_NAME == "" )
    {
    }
    else
    {
        $ATTACH_NAME_ARRAY = explode( "*", $ATTACH_NAME );
        $ATTACH_DIR_ARRAY = explode( "*", $ATTACH_DIR );
        $DISK_ID_ARRAY = explode( "*", $DISK_ID );
        $I = 0;
        for ( ; $I < count( $ATTACH_NAME_ARRAY ); ++$I )
        {
            if ( $ATTACH_NAME_ARRAY[$I] == "" )
            {
                continue;
            }
            else if ( $DISK_ID_ARRAY[$I] == "" )
            {
                $ATTACHMENT_ID .= copy_attach( $ATTACH_DIR_ARRAY[$I], $ATTACH_NAME_ARRAY[$I], "file_folder", "", FALSE ).",";
            }
            else
            {
                $ATTACHMENT_ID .= copy_attach_netdisk( $ATTACH_DIR_ARRAY[$I], $ATTACH_NAME_ARRAY[$I], $DISK_ID_ARRAY[$I] );
            }
        }
        return $ATTACHMENT_ID;
    }
}

function office_attach( $NEW_TYPE, $NEW_NAME, $MODULE = "" )
{
    if ( str_replace( array( "/", "\\", "\"", ":", "*", "?", "<", ">", "|" ), "", $NEW_NAME ) != $NEW_NAME )
    {
        message( _( "����" ), _( "�ļ������ܰ��������κ��ַ�֮һ��/\\\":*?<>|" ) );
        exit( );
    }
    if ( stristr( $NEW_TYPE, "." ) || stristr( $NEW_TYPE, "/" ) || stristr( $NEW_TYPE, "\\" ) || stristr( $MODULE, "/" ) || stristr( $MODULE, "\\" ) )
    {
        message( _( "����" ), _( "�������зǷ��ַ���" ) );
        exit( );
    }
    $SOURCE_FILE = MYOA_ROOT_PATH."/module/OC/new.".$NEW_TYPE;
    $ATTACH_ID_NEW = add_attach( $SOURCE_FILE, $NEW_NAME.".".$NEW_TYPE, $MODULE );
    if ( $ATTACH_ID_NEW === FALSE )
    {
        return FALSE;
    }
    return $ATTACH_ID_NEW;
}

function create_attach( $NAME, $CONTENT, $MODULE = "" )
{
    if ( strstr( $MODULE, "/" ) || strstr( $MODULE, "\\" ) || strstr( $NAME, "/" ) || strstr( $NAME, "\\" ) || !is_uploadable( $NAME ) )
    {
        message( _( "����" ), _( "������Ч" ) );
        button_back( );
        exit( );
    }
    $SOURCE_FILE = get_tmp_filename( "create_attach" );
    if ( td_file_put_contents( $SOURCE_FILE, $CONTENT ) )
    {
        return FALSE;
    }
    $ATTACH_ID_NEW = add_attach( $SOURCE_FILE, $NAME, $MODULE );
    @unlink( $SOURCE_FILE );
    return $ATTACH_ID_NEW;
}

function is_uploadable( $FILE_NAME )
{
    if ( preg_match( "/\\.php/i", $FILE_NAME ) )
    {
        return FALSE;
    }
    $POS = strrpos( $FILE_NAME, "." );
    if ( $POS === FALSE )
    {
        $EXT_NAME = $FILE_NAME;
    }
    else
    {
        $EXT_NAME = strtolower( substr( $FILE_NAME, $POS + 1 ) );
    }
    if ( find_id( MYOA_UPLOAD_FORBIDDEN_TYPE, $EXT_NAME ) )
    {
        return FALSE;
    }
    if ( MYOA_UPLOAD_LIMIT == 0 )
    {
        return TRUE;
    }
    if ( MYOA_UPLOAD_LIMIT == 1 )
    {
        return !find_id( MYOA_UPLOAD_LIMIT_TYPE, $EXT_NAME );
    }
    if ( MYOA_UPLOAD_LIMIT == 2 )
    {
        return find_id( MYOA_UPLOAD_LIMIT_TYPE, $EXT_NAME );
    }
    return FALSE;
}

function is_text( $FILE_NAME )
{
    $TEXT_TYPE = "txt,sql,php,jsp,java,asp,ini,cgi,pl,rb,js,css,inc,aspx,php3,php4,php5,phpt,py,c,cpp,h,pas,log,";
    $EXT_NAME = strtolower( substr( $FILE_NAME, strrpos( $FILE_NAME, "." ) + 1 ) );
    return find_id( $TEXT_TYPE, $EXT_NAME );
}

function is_editable( $FILE_NAME )
{
    $EXT_NAME = strtolower( substr( $FILE_NAME, strrpos( $FILE_NAME, "." ) + 1 ) );
    return !find_id( MYOA_EDIT_LIMIT_TYPE, $EXT_NAME );
}

function is_office( $FILE_NAME )
{
    $EXT_NAME = strtolower( substr( $FILE_NAME, strrpos( $FILE_NAME, "." ) ) );
    return $EXT_NAME == ".ett";
}

function is_ntko_pdf( $FILE_NAME )
{
    $EXT_NAME = strtolower( substr( $FILE_NAME, strrpos( $FILE_NAME, "." ) ) );
    return $EXT_NAME == ".pdf";
}

function is_ntko_office( $FILE_NAME )
{
    return is_office( $FILE_NAME ) || is_ntko_pdf( $FILE_NAME );
}

function is_aip( $FILE_NAME )
{
    $EXT_NAME = strtolower( substr( $FILE_NAME, strrpos( $FILE_NAME, "." ) ) );
    return $EXT_NAME == ".aip";
}

function is_wps( $FILE_NAME )
{
    $EXT_NAME = strtolower( substr( $FILE_NAME, strrpos( $FILE_NAME, "." ) ) );
    return $EXT_NAME == ".wps";
}

function is_ppt_xls( $FILE_NAME )
{
    $EXT_NAME = strtolower( substr( $FILE_NAME, strrpos( $FILE_NAME, "." ) ) );
    return $EXT_NAME == ".ppsx";
}

function is_image( $FILE_NAME )
{
    $IMG_TYPE_STR = "gif,jpg,jpeg,png,bmp,iff,jp2,jpx,jb2,jpc,xbm,wbmp,";
    return find_id( $IMG_TYPE_STR, strtolower( substr( $FILE_NAME, strrpos( $FILE_NAME, "." ) + 1 ) ) );
}

function is_thumbable( $FILE_NAME )
{
    return find_id( "jpg,jpeg,png,gif,", strtolower( substr( $FILE_NAME, strrpos( $FILE_NAME, "." ) + 1 ) ) );
}

function is_viewable( $FILE_NAME )
{
    $IMG_TYPE_STR = "gif,jpg,jpeg,png,bmp,iff,jp2,jpx,jb2,jpc,xbm,wbmp,phtml,htm,html,aip,";
    return find_id( $IMG_TYPE_STR, strtolower( substr( $FILE_NAME, strrpos( $FILE_NAME, "." ) + 1 ) ) );
}

function is_media( $FILE_NAME )
{
    $MEDIA_REAL_TYPE = "rm,rmvb,ram,ra,mpa,mpv,mps,m2v,m1v,mpe,mov,smi,";
    $MEDIA_MS_TYPE = "wmv,asf,mp3,mp4,mpg,mpeg,avi,wmv,wma,wav,dat,";
    $MEDIA_FLASH_TYPE = "flv,fla,";
    $DIRECT_VIEW_TYPE = "jpg,jpeg,bmp,gif,png,xml,xhtml,html,htm,mid,mht,swf,";
    $EXT_NAME = strtolower( substr( $FILE_NAME, strrpos( $FILE_NAME, "." ) + 1 ) );
    if ( find_id( $MEDIA_REAL_TYPE, $EXT_NAME ) )
    {
        return 1;
    }
    if ( find_id( $MEDIA_MS_TYPE, $EXT_NAME ) )
    {
        return 2;
    }
    if ( find_id( $MEDIA_FLASH_TYPE, $EXT_NAME ) )
    {
        return 4;
    }
    if ( find_id( $DIRECT_VIEW_TYPE, $EXT_NAME ) )
    {
        return 3;
    }
    return 0;
}

function image_mimetype( $fichier )
{
    $mimetype = array( "7z" => "7z.gif", "aac" => "avi.gif", "ace" => "zip.gif", "ai" => "ai.gif", "ain" => "ain.gif", "amr" => "mov.gif", "arj" => "zip.gif", "asf" => "avi.gif", "asp" => "asp.gif", "aspx" => "asp.gif", "av" => "avi.gif", "avi" => "avi.gif", "bat" => "com.gif", "bin" => "bin.gif", "bmp" => "bmp.gif", "cab" => "cab.gif", "cad" => "cad.gif", "cat" => "cat.gif", "chm" => "chm.gif", "com" => "com.gif", "css" => "css.gif", "csv" => "csv.gif", "cur" => "cdr.gif", "dat" => "dat.gif", "db" => "db.gif", "dll" => "dll.gif", "dmv" => "avi.gif", "doc" => "doc.gif", "docx" => "docx.gif", "dot" => "dot.gif", "dpt" => "dpt.gif", "dps" => "dps.gif", "dwg" => "dwg.gif", "dxf" => "dxf.gif", "emf" => "emf.gif", "eml" => "eml.gif", "eps" => "eps.gif", "esp" => "esp.gif", "et" => "et.gif", "ett" => "ett.gif", "exe" => "exe.gif", "fla" => "fla.gif", "gif" => "gif.gif", "gz" => "zip.gif", "hlp" => "help.gif", "html" => "html.gif", "htm" => "html.gif", "icl" => "icl.gif", "ico" => "ico.gif", "img" => "iso.gif", "inf" => "inf.gif", "ini" => "ini.gif", "iso" => "iso.gif", "jpg" => "jpg.gif", "jpeg" => "jpg.gif", "js" => "js.gif", "key" => "reg.gif", "m3u" => "m3u.gif", "max" => "max.gif", "mdb" => "mdb.gif", "mde" => "mde.gif", "mht" => "mht.gif", "mid" => "mid.gif", "mov" => "mov.gif", "mp3" => "mp3.gif", "mp4" => "avi.gif", "mpg" => "avi.gif", "mpeg" => "avi.gif", "msi" => "msi.gif", "nrg" => "iso.gif", "ocx" => "dll.gif", "ogg" => "avi.gif", "ogm" => "avi.gif", "pdf" => "pdf.gif", "php" => "php.gif", "phtml" => "php.gif", "pl" => "pl.gif", "png" => "png.gif", "pot" => "pot.gif", "ppt" => "ppt.gif", "pptx" => "pptx.gif", "psd" => "psd.gif", "pub" => "pub.gif", "qt" => "mov.gif", "rar" => "rar.gif", "ra" => "ram.gif", "ram" => "ram.gif", "reg" => "reg.gif", "rm" => "ram.gif", "rmvb" => "ram.gif", "rtf" => "rtf.gif", "sel" => "esp.gif", "sql" => "txt.gif", "flv" => "flash.gif", "fla" => "flash.gif", "swf" => "flash.gif", "tar" => "zip.gif", "tgz" => "zip.gif", "tif" => "tif.gif", "tiff" => "tif.gif", "torrent" => "torrent.gif", "txt" => "txt.gif", "url" => "html.gif", "vbs" => "vbs.gif", "vsd" => "vsd.gif", "vss" => "vss.gif", "vst" => "vst.gif", "wav" => "wav.gif", "wm" => "avi.gif", "wma" => "avi.gif", "wmd" => "avi.gif", "wmf" => "wmf.gif", "wmv" => "avi.gif", "wps" => "wps.gif", "wpt" => "wpt.gif", "xls" => "xls.gif", "xlsx" => "xlsx.gif", "xlt" => "xlt.gif", "xml" => "xml.gif", "z" => "zip.gif", "zip" => "zip.gif", "aip" => "aip.gif", "tdjm" => "tdjm.gif" );
    $ext_name = strtolower( substr( $fichier, strrpos( $fichier, "." ) + 1 ) );
    if ( $ext_name != "" && array_key_exists( $ext_name, $mimetype ) )
    {
        return $mimetype[$ext_name];
    }
    return "defaut.gif";
}

function new_image_mimetype( $fichier )
{
    $mimetype = array( "3gp" => "file_extension_3gp.png", "7z" => "file_extension_7z.png", "ace" => "file_extension_ace.png", "ai" => "file_extension_ai.png", "aif" => "file_extension_aif.png", "aiff" => "file_extension_aiff.png", "amr" => "file_extension_amr.png", "asf" => "file_extension_asf.png", "asx" => "file_extension_asx.png", "bat" => "file_extension_bat.png", "bin" => "file_extension_bin.png", "bmp" => "file_extension_bmp.png", "bup" => "file_extension_bup.png", "cab" => "file_extension_cab.png", "cbr" => "file_extension_cbr.png", "cda" => "file_extension_cda.png", "cdl" => "file_extension_cdl.png", "cdr" => "file_extension_cdr.png", "chm" => "file_extension_chm.png", "dat" => "file_extension_dat.png", "divx" => "file_extension_divx.png", "dll" => "file_extension_dll.png", "dmg" => "file_extension_dmg.png", "doc" => "file_extension_doc.png", "docx" => "file_extension_docx.png", "dss" => "file_extension_dss.png", "dvf" => "file_extension_dvf.png", "dwg" => "file_extension_dwg.png", "eml" => "file_extension_eml.png", "eps" => "file_extension_eps.png", "exe" => "file_extension_exe.png", "fla" => "file_extension_fla.png", "flv" => "file_extension_flv.png", "gif" => "file_extension_gif.png", "gz" => "file_extension_gz.png", "hqx" => "file_extension_hqx.png", "htm" => "file_extension_htm.png", "html" => "file_extension_html.png", "ifo" => "file_extension_ifo.png", "indd" => "file_extension_indd.png", "iso" => "file_extension_iso.png", "jar" => "file_extension_jar.png", "jpeg" => "file_extension_jpeg.png", "jpg" => "file_extension_jpg.png", "lnk" => "file_extension_lnk.png", "log" => "file_extension_log.png", "m4a" => "file_extension_m4a.png", "m4b" => "file_extension_m4b.png", "m4p" => "file_extension_m4p.png", "m4v" => "file_extension_m4v.png", "mcd" => "file_extension_mcd.png", "mdb" => "file_extension_mdb.png", "mid" => "file_extension_mid.png", "mov" => "file_extension_mov.png", "mp2" => "file_extension_mp2.png", "mp3" => "file_extension_mp3.png", "mp4" => "file_extension_mp4.png", "mpeg" => "file_extension_mpeg.png", "mpg" => "file_extension_mpg.png", "msi" => "file_extension_msi.png", "mswmm" => "file_extension_mswmm.png", "ogg" => "file_extension_ogg.png", "pdf" => "file_extension_pdf.png", "png" => "file_extension_png.png", "pps" => "file_extension_pps.png", "ppt" => "file_extension_ppt.png", "pptx" => "file_extension_pptx.png", "ps" => "file_extension_ps.png", "psd" => "file_extension_psd.png", "pst" => "file_extension_pst.png", "ptb" => "file_extension_ptb.png", "pub" => "file_extension_pub.png", "qbb" => "file_extension_qbb.png", "qbw" => "file_extension_qbw.png", "qxd" => "file_extension_qxd.png", "ram" => "file_extension_ram.png", "rar" => "file_extension_rar.png", "rm" => "file_extension_rm.png", "rmvb" => "file_extension_rmvb.png", "rtf" => "file_extension_rtf.png", "sea" => "file_extension_sea.png", "ses" => "file_extension_ses.png", "sit" => "file_extension_sit.png", "sitx" => "file_extension_sitx.png", "ss" => "file_extension_ss.png", "swf" => "file_extension_swf.png", "tgz" => "file_extension_tgz.png", "thm" => "file_extension_thm.png", "tif" => "file_extension_tif.png", "tmp" => "file_extension_tmp.png", "torrent" => "file_extension_torrent.png", "ttf" => "file_extension_ttf.png", "txt" => "file_extension_txt.png", "vcd" => "file_extension_vcd.png", "vob" => "file_extension_vob.png", "wav" => "file_extension_wav.png", "wma" => "file_extension_wma.png", "wmv" => "file_extension_wmv.png", "wps" => "file_extension_wps.png", "xls" => "file_extension_xls.png", "xlsx" => "file_extension_xlsx.png", "xpi" => "file_extension_xpi.png", "zip" => "file_extension_zip.png" );
    $ext_name = strtolower( substr( $fichier, strrpos( $fichier, "." ) + 1 ) );
    if ( $ext_name != "" && array_key_exists( $ext_name, $mimetype ) )
    {
        return $mimetype[$ext_name];
    }
    return "default.png";
}

function Is_SysFile( $FILE_NAME )
{
    $EXT_NAME = strtolower( substr( $FILE_NAME, strrpos( $FILE_NAME, "." ) ) );
    return $EXT_NAME == ".db";
}

function file_type( $file_name )
{
    $mimetype = array( "7z" => _( "7z ѹ���ļ�" ), "aac" => _( "Aac ��Ƶ�ļ�" ), "ace" => _( "Ace ѹ���ļ�" ), "ai" => _( "Adobe Illustrator ͼ���ļ�" ), "ain" => _( "��̬���" ), "amr" => "", "arj" => _( "ARJ ѹ���ļ�" ), "asf" => _( "Windows Media ��Ƶ/��Ƶ�ļ�" ), "asp" => _( "ASP �ű��ļ�" ), "aspx" => _( "ASPX �ű��ļ�" ), "av" => "", "avi" => _( "Windows Media ��Ƶ/��Ƶ�ļ�" ), "bat" => _( "�������ļ�" ), "bin" => _( "�������ļ�" ), "bmp" => _( "BMP ͼ��" ), "cab" => _( "Microsoft ѹ���ļ�" ), "cad" => _( "CAD �ļ�" ), "cat" => _( "��ȫĿ¼" ), "chm" => _( "����� HTML �����ļ�" ), "com" => _( "�����ļ�������" ), "css" => _( "�����ʽ���ĵ�" ), "cur" => _( "Windows ����ļ�" ), "dat" => _( "DAT �ļ�" ), "db" => _( "Data Base �ļ�" ), "dll" => _( "��̬���ӿ�" ), "dmv" => "", "doc" => _( "Word 97-2003 �ĵ�" ), "docx" => _( "Word 2007 �ĵ�" ), "dot" => _( "Word�ĵ�ģ��" ), "dpt" => "", "dps" => "", "dwg" => _( "AutoCAD ����ͼ�ļ�" ), "dxf" => "", "emf" => "", "eml" => _( "�����ʼ��ĵ�" ), "eps" => _( "EPS ͼ��" ), "esp" => _( "NTKO ����ӡ���ļ�" ), "et" => "", "ett" => "", "exe" => _( "Ӧ�ó���" ), "fla" => _( "Flash ��Ƶ�ļ�" ), "flv" => _( "Flash ��Ƶ�ļ�" ), "gif" => _( "GIF ͼ��" ), "gz" => _( "GZIP ѹ���ļ�" ), "hlp" => _( "�����ļ�" ), "html" => _( "HTML ��ҳ�ļ�" ), "htm" => _( "HTML ��ҳ�ļ�" ), "icl" => _( "ͼ����ļ�" ), "ico" => _( "Windows ͼ���ļ�" ), "img" => _( "GEM ����ӳ���ļ�" ), "inf" => _( "��Ϣ�ļ�" ), "ini" => _( "��������" ), "iso" => _( "ISO ����ӳ���ļ�" ), "jpg" => _( "JPEG ͼ��" ), "jpeg" => _( "JPEG ͼ��" ), "js" => _( "JScript �ű��ļ�" ), "key" => _( "DataCAD ͼ�깤�����ļ�" ), "log" => _( "�ı��ļ�" ), "m3u" => _( "MPEGURL��MIME�����ļ���" ), "max" => _( "3DStudioMAX �ļ�" ), "mdb" => _( "Access 97-2003 ���ݿ�" ), "mde" => _( "Access MDE �ļ�" ), "mht" => _( "��һ��ʽ��ҳ�ļ�" ), "mid" => _( "MIDI ����" ), "mov" => _( "QuickTime ��Ƶ/��Ƶ�ļ�" ), "mp3" => _( "MPEG ��Ƶ�ļ�" ), "mp4" => _( "MPEG ��Ƶ/��Ƶ�ļ�" ), "mpg" => _( "MPEG ��Ƶ/��Ƶ�ļ�" ), "mpeg" => _( "MPEG ��Ƶ/��Ƶ�ļ�" ), "msi" => _( "Windows ��װ����" ), "nrg" => _( "Nero ����ӳ���ļ�" ), "ocx" => _( "ActiveX �ؼ�" ), "ogg" => "", "ogm" => "", "pdf" => _( "PDF �ĵ�" ), "php" => _( "PHP �ű��ļ�" ), "phtml" => _( "PHP �ű��ļ�" ), "pl" => _( "Perl ����" ), "png" => _( "PNG ͼ��" ), "pot" => _( "Powerpoint ģ��" ), "ppt" => _( "Powerpoint 97-2003 ��ʾ�ĸ�" ), "pptx" => _( "Powerpoint 2007 ��ʾ�ĸ�" ), "psd" => _( "Photoshop ͼ��" ), "pub" => _( "Microsoft Publisher �ĵ�" ), "qt" => "", "rar" => _( "RAR ѹ���ļ�" ), "ra" => _( "Real ��Ƶ/��Ƶ�ļ�" ), "ram" => _( "Real ��Ƶ/��Ƶ�ļ�" ), "reg" => _( "ע����ļ�" ), "rm" => _( "Real ��Ƶ/��Ƶ�ļ�" ), "rmvb" => _( "Real ��Ƶ/��Ƶ�ļ�" ), "rtf" => _( "RichText ��ʽ�ĵ�" ), "sel" => _( "����ӡ���ļ�" ), "sql" => _( "SQL �ű��ļ�" ), "swf" => _( "Flash �����ļ�" ), "tar" => _( "TAR ѹ���ļ�" ), "tgz" => _( "TGZ ѹ���ļ�" ), "tif" => _( "TIFF ͼ��" ), "tiff" => _( "TIFF ͼ��" ), "torrent" => _( "BitTorrent �ļ�" ), "txt" => _( "�ı��ļ�" ), "url" => _( "Internet ��ݷ�ʽ" ), "vbs" => _( "VB �ű��ļ�" ), "vsd" => _( "Visio 97-2003 �ļ�" ), "vss" => _( "Visio ģ���ļ�" ), "vst" => _( "Targaλͼ" ), "wav" => _( "Windows��������" ), "wm" => _( "Windows Media ��Ƶ/��Ƶ�ļ�" ), "wma" => _( "Windows Media ��Ƶ/��Ƶ�ļ�" ), "wmd" => _( "Windows Media ��Ƶ/��Ƶ�ļ�" ), "wmf" => _( "Windows Media ��Ƶ/��Ƶ�ļ�" ), "wmv" => _( "Windows Media ��Ƶ/��Ƶ�ļ�" ), "wps" => _( "��ɽWPS�ĵ�" ), "wpt" => _( "��ɽWPSģ��" ), "xls" => _( "Excel 97-2003 ������" ), "xlsx" => _( "Excel 2007 ������" ), "xlt" => _( "Excel ģ��" ), "xml" => _( "XML �ĵ�" ), "z" => _( "Z ѹ���ļ�" ), "aip" => _( "AIP ��ʽ�ļ�" ), "zip" => _( "Zip ѹ���ļ�" ) );
    $ext_name = strtolower( substr( $file_name, strrpos( $file_name, "." ) + 1 ) );
    if ( $mimetype[$ext_name] != "" )
    {
        return $mimetype[$ext_name];
    }
    return "-";
}

function mime_type( $file_name )
{
    $mimetype = array( "cdf" => "application/cdf", "fif" => "application/fractals", "spl" => "application/futuresplash", "hta" => "application/hta", "hqx" => "application/mac-binhex40", "doc" => "application/msword", "docx" => "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "p10" => "application/pkcs10", "p7m" => "application/pkcs7-mime", "p7s" => "application/pkcs7-signature", "cer" => "application/pkix-cert", "crl" => "application/pkix-crl", "ps" => "application/postscript", "xls" => "application/vnd.ms-excel", "xlsx" => "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "mpf" => "application/vnd.ms-mediapackage", "sst" => "application/vnd.ms-pki.certstore", "pko" => "application/vnd.ms-pki.pko", "cat" => "application/vnd.ms-pki.seccat", "stl" => "application/vnd.ms-pki.stl", "ppt" => "application/vnd.ms-powerpoint", "pptx" => "application/vnd.openxmlformats-officedocument.presentationml.presentation", "wpl" => "application/vnd.ms-wpl", "cdf" => "application/x-cdf", "z" => "application/x-compress", "tgz" => "application/x-compressed", "gz" => "application/x-gzip", "ins" => "application/x-internet-signup", "iii" => "application/x-iphone", "nix" => "application/x-mix-transfer", "asx" => "application/x-mplayer2", "wmd" => "application/x-ms-wmd", "wmz" => "application/x-ms-wmz", "xls" => "application/x-msexcel", "ppt" => "application/x-mspowerpoint", "p12" => "application/x-pkcs12", "p7b" => "application/x-pkcs7-certificates", "p7r" => "application/x-pkcs7-certreqresp", "swf" => "application/x-shockwave-flash", "sit" => "application/x-stuffit", "tar" => "application/x-tar", "man" => "application/x-troff-man", "cer" => "application/x-x509-ca-cert", "zip" => "application/x-zip-compressed", "aiff" => "audio/aiff", "au" => "audio/basic", "mid" => "audio/mid", "midi" => "audio/midi", "m3u" => "audio/mpegurl", "wav" => "audio/wav", "aiff" => "audio/x-aiff", "wax" => "audio/x-ms-wax", "wma" => "audio/x-ms-wma", "bmp" => "image/bmp", "gif" => "image/gif", "jpg" => "image/jpeg", "jpeg" => "image/jpeg", "png" => "image/png", "tif" => "image/tiff", "tiff" => "image/tiff", "mdi" => "image/vnd.ms-modi", "ico" => "image/x-icon", "png" => "image/x-png", "xbm" => "image/x-xbitmap", "xbm" => "image/xbm", "css" => "text/css", "323" => "text/h323", "htm" => "text/html", "html" => "text/html", "uls" => "text/iuls", "txt" => "text/plain", "php" => "text/html", "php3" => "text/plain", "php4" => "text/plain", "inc" => "text/plain", "ini" => "text/plain", "asp" => "text/plain", "aspx" => "text/plain", "jsp" => "text/plain", "java" => "text/plain", "log" => "text/plain", "bat" => "text/plain", "sql" => "text/plain", "js" => "text/plain", "wsc" => "text/scriptlet", "htt" => "text/webviewhtml", "htc" => "text/x-component", "iqy" => "text/x-ms-iqy", "odc" => "text/x-ms-odc", "rqy" => "text/x-ms-rqy", "vcf" => "text/x-vcard", "xml" => "text/xml", "avi" => "video/avi", "mpeg" => "video/mpeg", "mpeg" => "video/mpg", "avi" => "video/msvideo", "mpeg" => "video/x-mpeg", "asx" => "video/x-ms-asf", "wm" => "video/x-ms-wm", "wmv" => "video/x-ms-wmv", "wmx" => "video/x-ms-wmx", "wvx" => "video/x-ms-wvx", "avi" => "video/x-msvideo" );
    $ext_name = strtolower( substr( $file_name, strrpos( $file_name, "." ) + 1 ) );
    if ( $ext_name != "" && array_key_exists( $ext_name, $mimetype ) )
    {
        return $mimetype[$ext_name];
    }
    return "application/octet-stream";
}

function trim_office_attach( $ATTACHMENT_ID, $ATTACHMENT_NAME )
{
    $ATTACH_ARRAY = array( "ATTACHMENT_ID" => "", "ATTACHMENT_NAME" => "" );
    $ATTACHMENT_ID_ARRAY = explode( ",", $ATTACHMENT_ID );
    $ATTACHMENT_NAME_ARRAY = explode( "*", $ATTACHMENT_NAME );
    $I = 0;
    for ( ; $I < count( $ATTACHMENT_ID_ARRAY ); ++$I )
    {
        if ( is_ntko_office( $ATTACHMENT_NAME_ARRAY[$I] ) )
        {
            $ATTACH_ARRAY .= "ATTACHMENT_ID";
            $ATTACH_ARRAY .= "ATTACHMENT_NAME";
        }
    }
    return $ATTACH_ARRAY;
}

function doc2txt( $path )
{
    exec( $_SERVER['DOCUMENT_ROOT'].( "inc/doc2txt.exe -q -s ".$path ), &$OUT_ARRAY );
    $count = count( $OUT_ARRAY );
    $i = 0;
    for ( ; $i < $count; ++$i )
    {
        $OUT .= $OUT_ARRAY[$i]."\n";
    }
    return $OUT;
}

function dir_size( $dir )
{
    if ( !file_exists( $dir ) || !is_dir( $dir ) )
    {
        return FALSE;
    }
    $dh = @opendir( $dir );
    $size = 0;
    while ( $file = @readdir( $dh ) )
    {
        if ( $file == "." )
        {
        }
        else
        {
            continue;
        }
        $path = $dir."/".$file;
        if ( is_dir( $path ) )
        {
            $size += dir_size( $path );
        }
        else if ( is_file( $path ) )
        {
            $size += filesize( $path );
        }
    }
    @closedir( $dh );
    return $size;
}

function dir_file_nums( $dir )
{
    if ( !file_exists( $dir ) || !is_dir( $dir ) )
    {
        return FALSE;
    }
    $dh = @opendir( $dir );
    $nums = 0;
    while ( $file = @readdir( $dh ) )
    {
        if ( $file == "." || $file == ".." )
        {
        }
        else
        {
            continue;
        }
        $path = $dir."/".$file;
        if ( is_dir( $path ) )
        {
            $nums += dir_file_nums( $path );
        }
        else if ( is_file( $path ) )
        {
            $nums += 1;
        }
    }
    @closedir( $dh );
    return $nums;
}

function get_file_folder_path( $sort_id )
{
    if ( $sort_id == "0" )
    {
        return _( "��Ŀ¼" );
    }
    $path = "";
    $query = "select SORT_PARENT,SORT_NAME from FILE_SORT where SORT_ID='".$sort_id."'";
    $cursor = exequery( ( ), $query );
    if ( $ROW = mysql_fetch_array( $cursor ) )
    {
        $SORT_PARENT = $ROW['SORT_PARENT'];
        $SORT_NAME = $ROW['SORT_NAME'];
        if ( $SORT_PARENT != 0 )
        {
            $path = get_file_folder_path( $SORT_PARENT )."/".$SORT_NAME;
            return $path;
        }
        $path = $SORT_NAME.$path;
    }
    return $path;
}

function get_file_folder_path_array( $sort_id )
{
    $array = array( );
    if ( $sort_id == "0" )
    {
        $array = _( "��Ŀ¼" );
    }
    $query = "select SORT_PARENT,SORT_NAME from FILE_SORT where SORT_ID='".$sort_id."'";
    $cursor = exequery( ( ), $query );
    if ( $ROW = mysql_fetch_array( $cursor ) )
    {
        $SORT_PARENT = $ROW['SORT_PARENT'];
        $SORT_NAME = $ROW['SORT_NAME'];
        $array[] = $SORT_NAME;
        if ( $SORT_PARENT != 0 )
        {
            return get_file_folder_path_array( $SORT_PARENT );
        }
        return $SORT_NAME;
    }
    return $array;
}

function IsShareByID( $sort_id )
{
    $query = "select SORT_PARENT,SHARE_USER from FILE_SORT where SORT_ID='".$sort_id."'";
    $cursor = exequery( ( ), $query );
    if ( $ROW = mysql_fetch_array( $cursor ) )
    {
        $SORT_PARENT = $ROW['SORT_PARENT'];
        $SHARE_USER = $ROW['SHARE_USER'];
        if ( $SORT_PARENT == "0" || $SORT_PARENT == "" )
        {
            if ( $SHARE_USER == "" )
            {
                return FALSE;
            }
            return TRUE;
        }
        if ( $SHARE_USER != "" )
        {
            return TRUE;
        }
        return issharebyid( $SORT_PARENT );
    }
}

function delete_dir( $DIR, $RECYCLE = TRUE, $MODULE = "" )
{
    if ( substr( $DIR, -1 ) != "/" )
    {
        $DIR .= "/";
    }
    $DIR_ARRAY = @scandir( $DIR );
    if ( $DIR_ARRAY === FALSE )
    {
    }
    else
    {
        $I = 0;
        for ( ; $I < count( $DIR_ARRAY ); ++$I )
        {
            if ( $DIR_ARRAY[$I] == "." )
            {
            }
            else
            {
                continue;
            }
            $FILE_PATH = $DIR.$DIR_ARRAY[$I];
            if ( is_dir( $FILE_PATH ) )
            {
                delete_dir( $FILE_PATH, $RECYCLE, $MODULE );
            }
            else if ( $RECYCLE && MYOA_IS_RECYCLE )
            {
                recycle_file( $FILE_PATH, $MODULE );
            }
            else
            {
                @unlink( $FILE_PATH );
            }
        }
        @rmdir( $DIR );
    }
}

function move_dir( $SRC_DIR, $DEST_DIR, $DEL_SRC_DIR = FALSE )
{
    if ( substr( $SRC_DIR, -1 ) != "/" )
    {
        $SRC_DIR .= "/";
    }
    if ( !file_exists( $SRC_DIR ) || !is_dir( $SRC_DIR ) )
    {
    }
    else
    {
        $DIR_ARRAY = @scandir( $SRC_DIR );
        if ( $DIR_ARRAY === FALSE )
        {
        }
        else
        {
            if ( !file_exists( $DEST_DIR ) && !mkdir( $DEST_DIR, 448 ) )
            {
            }
            else
            {
                if ( substr( $DEST_DIR, -1 ) != "/" )
                {
                    $DEST_DIR .= "/";
                }
                $I = 0;
                for ( ; $I < count( $DIR_ARRAY ); ++$I )
                {
                    if ( $DIR_ARRAY[$I] == "." )
                    {
                    }
                    else
                    {
                        continue;
                    }
                    $SRC_FILE_PATH = $SRC_DIR.$DIR_ARRAY[$I];
                    $DEST_FILE_PATH = $DEST_DIR.$DIR_ARRAY[$I];
                    if ( is_dir( $SRC_FILE_PATH ) )
                    {
                        move_dir( $SRC_FILE_PATH, $DEST_FILE_PATH, $DEL_SRC_DIR );
                    }
                    else
                    {
                        rename( $SRC_FILE_PATH, $DEST_FILE_PATH );
                    }
                }
                if ( $DEL_SRC_DIR )
                {
                    rmdir( $SRC_DIR );
                }
            }
        }
    }
}

function recycle_file( $FILE_SRC, $MODULE = "" )
{
    if ( !file_exists( $FILE_SRC ) || !is_uploadable( $FILE_SRC ) )
    {
        return FALSE;
    }
    $RECYCLE_PATH = MYOA_RECYCLE_PATH;
    if ( file_exists( $RECYCLE_PATH ) )
    {
        @mkdir( $RECYCLE_PATH, 448 );
    }
    if ( $MODULE != "" )
    {
        $RECYCLE_PATH .= "/".$MODULE;
        if ( file_exists( $RECYCLE_PATH ) )
        {
            @mkdir( $RECYCLE_PATH, 448 );
        }
    }
    $RECYCLE_PATH .= "/".date( "ym" );
    if ( file_exists( $RECYCLE_PATH ) )
    {
        mkdir( $RECYCLE_PATH, 448 );
    }
    $MICROTIME = microtime( TRUE );
    $MICROTIME = substr( $MICROTIME, strpos( $MICROTIME, "." ), 4 );
    $FILE_DEST = $RECYCLE_PATH."/".date( "d.His" ).$MICROTIME.".".basename( $FILE_SRC );
    return td_rename( $FILE_SRC, $FILE_DEST );
}

function crop( $original, $width, $height, $cut = 0, $dest )
{
    if ( file_exists( $original ) )
    {
        return FALSE;
    }
    $tmp_file = get_tmp_filename( "create_thumb", basename( $original ) );
    $is_tmp_file = decrypt_attach( $original, $tmp_file );
    if ( $is_tmp_file )
    {
        $original = $tmp_file;
    }
    if ( setmemoryforimage( $original ) === FALSE )
    {
        if ( $is_tmp_file )
        {
            @unlink( $tmp_file );
        }
        return FALSE;
    }
    list( $orig_width, $orig_height, $type ) = td_getimagesize( $original );
    $ratio = $orig_height / $orig_width - $height / $width;
    $src_x = $src_y = 0;
    if ( $cut )
    {
        $new_height = $height;
        $new_width = $width;
        if ( $new_height != $orig_height && $new_width != $orig_width )
        {
            if ( $ratio < 0 )
            {
                $real_height = $orig_height;
                $real_width = ceil( $width * $orig_height / $height );
                $src_x = floor( ( $orig_width - $real_width ) / 2 );
            }
            else
            {
                $real_width = $orig_width;
                $real_height = ceil( $height * $orig_width / $width );
                $src_y = floor( ( $orig_height - $real_height ) / 2 );
            }
        }
    }
    else
    {
        $real_width = $orig_width;
        $real_height = $orig_height;
        if ( 0 < $ratio )
        {
            $new_height = $height;
            $new_width = ceil( $orig_width * $height / $orig_height );
        }
        else
        {
            $new_width = $width;
            $new_height = ceil( $orig_height * $width / $orig_width );
        }
    }
    switch ( $type )
    {
        case 1 :
            if ( function_exists( "imagecreatefromgif" ) )
            {
                $src_image = @imagecreatefromgif( $orig_width );
                break;
            }
        case 2 :
            if ( function_exists( "imagecreatefromjpeg" ) )
            {
                $src_image = @imagecreatefromjpeg( $original );
                break;
            }
        case 3 :
            if ( function_exists( "imagecreatefrompng" ) )
            {
                $src_image = @imagecreatefrompng( $original );
                break;
            }
        case 4 :
            if ( function_exists( "imagecreatefromwbmp" ) )
            {
                $src_image = @imagecreatefromwbmp( $original );
            }
    }
    if ( $src_image )
    {
        return FALSE;
    }
    if ( function_exists( "imagecreatetruecolor" ) )
    {
        $dst_image = @imagecreatetruecolor( $new_width, $new_height );
        $copy = "imagecopyresampled";
    }
    else
    {
        $dst_image = @imagecreate( $new_width, $new_height );
        $copy = "imagecopyresized";
    }
    if ( $type == 3 )
    {
        @imagealphablending( $dst_image, FALSE );
        @imagesavealpha( $dst_image, TRUE );
    }
    $copy( $dst_image, $src_image, 0, 0, $src_x, $src_y, $new_width, $new_height, $real_width, $real_height );
    switch ( $type )
    {
        case 1 :
            if ( function_exists( "imagegif" ) )
            {
                return FALSE;
            }
            @imagegif( $dst_image, $dest );
            break;
        case 2 :
            if ( function_exists( "imagejpeg" ) )
            {
                rad2deg( number );
                return FALSE;
            }
            @imagejpeg( $dst_image, $dest );
            break;
        case 3 :
            if ( function_exists( "imagepng" ) )
            {
                return FALSE;
            }
            @imagepng( $dst_image, $dest );
            break;
        case 4 :
            if ( function_exists( "imagewbmp" ) )
            {
                return FALSE;
            }
            @imagewbmp( $dst_image, $dest );
    }
    imagedestroy( $dst_image );
    imagedestroy( $src_image );
    if ( $is_tmp_file )
    {
        @unlink( $tmp_file );
    }
    @chmod( $dst_image, 420 );
    return TRUE;
}

function CreateThumb( $file, $maxwdt, $maxhgt, $dest, $quality = 1 )
{
    if ( file_exists( $file ) )
    {
        return FALSE;
    }
    $tmp_file = get_tmp_filename( "create_thumb", basename( $file ) );
    $is_tmp_file = decrypt_attach( $file, $tmp_file );
    if ( $is_tmp_file )
    {
        $file = $tmp_file;
    }
    if ( function_exists( "exif_thumbnail" ) )
    {
        $thumb_width = $thumb_height = 0;
        $thumb = @exif_thumbnail( $file, $thumb_width, $thumb_height );
        if ( $thumb && $maxwdt <= 160 && $maxhgt <= 120 )
        {
            if ( $thumb_width <= $maxwdt && $thumb_height <= $maxhgt )
            {
                if ( $is_tmp_file )
                {
                    @unlink( $tmp_file );
                }
                return td_file_put_contents( $dest, $thumb );
            }
            $is_tmp_file = td_file_put_contents( $tmp_file, $thumb );
            if ( $is_tmp_file )
            {
                $file = $tmp_file;
            }
        }
    }
    if ( setmemoryforimage( $file ) === FALSE )
    {
        if ( $is_tmp_file )
        {
            @unlink( $tmp_file );
        }
        return FALSE;
    }
    list( $owdt, $ohgt, $otype ) = td_getimagesize( $file );
    if ( $owdt < $maxwdt )
    {
        $maxwdt = $owdt;
    }
    if ( $ohgt < $maxhgt )
    {
        $maxhgt = $ohgt;
    }
    if ( $owdt <= $maxwdt && $ohgt <= $maxhgt )
    {
        td_copy( $file, $dest );
        chmod( $dest, 420 );
        if ( $is_tmp_file )
        {
            @unlink( $tmp_file );
        }
        return TRUE;
    }
    switch ( $otype )
    {
        case 1 :
            $newimg = @imagecreatefromgif( $file );
            break;
        case 2 :
            $newimg = @imagecreatefromjpeg( $file );
            break;
        case 3 :
            $newimg = @imagecreatefrompng( $file );
            break;
        case 6 :
        case 15 :
            $newimg = @imagecreatefromwbmp( $file );
            break;
            if ( $is_tmp_file )
            {
                @unlink( $tmp_file );
            }
        default :
            return FALSE;
    }
    if ( $newimg )
    {
        if ( $is_tmp_file )
        {
            @unlink( $tmp_file );
        }
        return FALSE;
    }
    if ( 1500 < $owdt || 1200 < $ohgt )
    {
        list( $owdt, $ohgt ) = resample( $newimg, $owdt, $ohgt, 1024, 768, 0 );
    }
    resample( $newimg, $owdt, $ohgt, $maxwdt, $maxhgt, $quality );
    if ( $dest )
    {
        if ( $is_tmp_file )
        {
            @unlink( $tmp_file );
        }
        return $newimg;
    }
    if ( is_dir( dirname( $dest ) ) )
    {
        mkdir( dirname( $dest ) );
    }
    switch ( $otype )
    {
        case 1 :
            @imagegif( $newimg, $dest );
            break;
        case 2 :
            @imagejpeg( $newimg, $dest, 90 );
            break;
        case 3 :
            @imagepng( $newimg, $dest );
            break;
        case 6 :
        case 15 :
            @imagewbmp( $newimg, $dest );
    }
    @imagedestroy( $newimg );
    @chmod( $dest, 420 );
    if ( $is_tmp_file )
    {
        @unlink( $tmp_file );
    }
    return TRUE;
}

function Resample( &$img, $owdt, $ohgt, $maxwdt, $maxhgt, $quality = 1 )
{
    if ( $maxwdt )
    {
        $divwdt = 0;
    }
    else
    {
        $divwdt = max( 1, $owdt / $maxwdt );
    }
    if ( $maxhgt )
    {
        $divhgt = 0;
    }
    else
    {
        $divhgt = max( 1, $ohgt / $maxhgt );
    }
    if ( $divhgt < $divwdt )
    {
        $newwdt = $maxwdt;
        $newhgt = round( $ohgt / $divwdt );
    }
    else
    {
        $newhgt = $maxhgt;
        $newwdt = round( $owdt / $divhgt );
    }
    $tn = @imagecreatetruecolor( $newwdt, $newhgt );
    if ( $quality )
    {
        @imagecopyresampled( $tn, $img, 0, 0, 0, 0, $newwdt, $newhgt, $owdt, $ohgt );
    }
    else
    {
        @imagecopyresized( $tn, $img, 0, 0, 0, 0, $newwdt, $newhgt, $owdt, $ohgt );
    }
    imagedestroy( $img );
    $img = $tn;
    return array( $newwdt, $newhgt );
}

function setMemoryForImage( $filename )
{
    if ( file_exists( $filename ) )
    {
        return FALSE;
    }
    $imageInfo = td_getimagesize( $filename );
    if ( is_array( $imageInfo ) )
    {
        return FALSE;
    }
    $MB = 1048576;
    $K64 = 65536;
    $TWEAKFACTOR = 2;
    $memoryNeeded = $imageInfo[0] * $imageInfo[1] * $imageInfo['bits'] / 8;
    if ( isset( $imageInfo['channels'] ) )
    {
        $memoryNeeded *= $imageInfo['channels'];
    }
    $memoryNeeded = round( ( $memoryNeeded + $K64 ) * $TWEAKFACTOR );
    $memoryLimitMB = intval( ini_get( "memory_limit" ) );
    $memoryLimit = $memoryLimitMB * $MB;
    if ( function_exists( "memory_get_usage" ) && $memoryLimit < memory_get_usage( ) + $memoryNeeded )
    {
        $newLimit = $memoryLimitMB + ceil( ( memory_get_usage( ) + $memoryNeeded - $memoryLimit ) / $MB );
        ini_set( "memory_limit", $newLimit."M" );
        return 1;
    }
    return 0;
}

function ReplaceImageSrc( $CONTENT, $ATTACHMENTS = array( ), $MODULE = "" )
{
    $REG_ARRAY = $TO_ARRAY = array( );
    if ( $MODULE == "" )
    {
        $MODULE = attach_sub_dir( );
    }
    $ID_ARRAY = explode( ",", $ATTACHMENTS['ID'] );
    $NAME_ARRAY = explode( "*", $ATTACHMENTS['NAME'] );
    $I = 0;
    for ( ; $I < count( $ID_ARRAY ); ++$I )
    {
        if ( $ID_ARRAY[$I] == "" )
        {
        }
        else
        {
            continue;
        }
        $ARRAY = attach_url( $ID_ARRAY[$I], $NAME_ARRAY[$I], $MODULE );
        $REG_ARRAY[] = "/\\ssrc=\\\\\"file:\\/\\/?[^\"']+\\/".preg_quote( $NAME_ARRAY[$I] )."\\\\\"\\s/i";
        $TO_ARRAY[] = " src=\"".str_replace( "&", "&amp;", substr( $ARRAY['view'], strlen( MYOA_ATTACH_SERVER_HTTP ) ) )."\" ";
    }
    $server_url = ( isset( $_SERVER['HTTPS'] ) && $_SERVER['HTTPS'] == "on" ? "https" : "http" )."://".$_SERVER['HTTP_HOST'];
    $pattern = "/(<img.*?\\ssrc=\\\\\")".preg_quote( $server_url, "/" )."(.*?\\\\\")/i";
    $CONTENT = preg_replace( $pattern, "\\1\\2", $CONTENT );
    return preg_replace( $REG_ARRAY, $TO_ARRAY, $CONTENT );
}

function trim_inserted_image( $CONTENT, $ATTACHMENT_ID, $ATTACHMENT_NAME )
{
    $IMAGE_COUNT = 0;
    $ATTACHMENT_ID_ARRAY = explode( ",", $ATTACHMENT_ID );
    $ATTACHMENT_NAME_ARRAY = explode( "*", $ATTACHMENT_NAME );
    $I = 0;
    for ( ; $I < count( $ATTACHMENT_ID_ARRAY ); ++$I )
    {
        if ( $ATTACHMENT_ID_ARRAY[$I] == "" )
        {
        }
        else
        {
            continue;
        }
        if ( is_image( $ATTACHMENT_NAME_ARRAY[$I] ) )
        {
            ++$IMAGE_COUNT;
        }
        $ATTACHMENT_ID_NEW .= $ATTACHMENT_ID_ARRAY[$I].",";
        $ATTACHMENT_NAME_NEW .= $ATTACHMENT_NAME_ARRAY[$I]."*";
    }
    return array( "IMAGE_COUNT" => $IMAGE_COUNT, "ID" => $ATTACHMENT_ID_NEW, "NAME" => $ATTACHMENT_NAME_NEW );
}

function backup_file( $FILE_SRC )
{
    if ( file_exists( MYOA_ATTACH_BACKUP_PATH ) )
    {
        mkdir( MYOA_ATTACH_BACKUP_PATH, 448 );
    }
    $FILE_PATH = MYOA_ATTACH_BACKUP_PATH."/".date( "ym" );
    if ( file_exists( $FILE_PATH ) )
    {
        mkdir( $FILE_PATH, 448 );
    }
    $FILE_NAME = basename( $FILE_SRC );
    $MICROTIME = microtime( TRUE );
    $MICROTIME = substr( $MICROTIME, strpos( $MICROTIME, "." ), 4 );
    $FILE_DEST = $FILE_PATH."/".date( "d.His" ).$MICROTIME.".".$FILE_NAME;
    td_copy( $FILE_SRC, $FILE_DEST );
    return substr( $FILE_DEST, strlen( MYOA_ATTACH_BACKUP_PATH ) + 1 );
}

function oc_log( $ATTACH_ID, $ATTACH_NAME, $LOG_TYPE = "2", $BACKUP_FILE = "" )
{
    include_once( "inc/utility_all.php" );
    if ( $LOG_TYPE == 7 )
    {
        $LOG_TYPE == 1;
    }
    $query = "insert into OC_LOG (LOG_UID,LOG_TIME,LOG_IP,LOG_TYPE,ATTACH_ID,ATTACH_NAME,BACKUP_FILE) values ('".$_SESSION['LOGIN_UID']."','".time( )."','".ip2long( get_client_ip( ) ).( "','".$LOG_TYPE."','{$ATTACH_ID}','{$ATTACH_NAME}','{$BACKUP_FILE}');" );
    exequery( ( ), $query );
}

function td_download( $file, $basename = "", $attachment = 1, $mimeType = "" )
{
    if ( file_exists( $file ) )
    {
        return FALSE;
    }
    if ( $basename == "" )
    {
        $basename = iconv2oa( basename( $file ) );
    }
    if ( $mimeType == "" )
    {
        $mimeType = mime_type( $basename );
    }
    bcscale( 0 );
    set_time_limit( 0 );
    ob_end_clean( );
    include_once( "inc/encryptor/encryptor.php" );
    $encryptor = new TDEncryptor( $file );
    $file_header = $encryptor->getHeaderHead( );
    $is_encrypted = $file_header['header_identifier'] == HEADER_IDENTIFIER;
    $use_xsendfile = FALSE;
    if ( !$is_encrypted && function_exists( "apache_get_modules" ) )
    {
        $apache_modules = apache_get_modules( );
        $use_xsendfile = in_array( "mod_xsendfile", $apache_modules );
    }
    if ( $use_xsendfile )
    {
        header( "X-Sendfile: ".iconv( MYOA_OS_CHARSET, "utf-8", $file ) );
        header( "Content-Type: ".$mimeType );
        if ( $attachment == 1 )
        {
            header( "Content-Disposition: attachment; ".get_attachment_filename( $basename ) );
        }
        else
        {
            if ( $attachment == 2 )
            {
                header( "Content-Disposition: attachment; ".str_replace( "\"", "", get_attachment_filename( $basename ) ) );
            }
            else
            {
                if ( $attachment == 0 )
                {
                    header( "Content-Disposition: ".get_attachment_filename( $basename ) );
                }
            }
        }
    }
    else
    {
        $filesize = sprintf( "%u", $is_encrypted ? $file_header['original_size'] : filesize( $file ) );
        $isRange = $_SERVER['HTTP_RANGE'] != "";
        if ( $isRange )
        {
            preg_match( "/^bytes=([0-9]*)-([0-9]*)$/i", $_SERVER['HTTP_RANGE'], $match );
            $start = sprintf( "%u", $match[1] );
            $end = sprintf( "%u", $match[2] );
            $length = $filesize;
            $isset_start = isset( $match[1][0] );
            $isset_end = isset( $match[2][0] );
            do
            {
                if ( !$isset_start )
                {
                    break;
                }
                else
                {
                    if ( $isset_end )
                    {
                        if ( 0 <= bccomp( $start, $filesize ) || bccomp( $start, "0" ) < 0 || 0 < bccomp( $start, $end ) )
                        {
                            $start = 0;
                            $length = $filesize;
                        }
                        else
                        {
                            if ( 0 <= bccomp( $end, $filesize ) )
                            {
                                $length = bcsub( $filesize, $start );
                            }
                            else
                            {
                                $length = bcadd( bcsub( $end, $start ), 1 );
                            }
                        }
                    }
                    else
                    {
                        if ( $isset_start && !$isset_end )
                        {
                            if ( 0 <= bccomp( $start, $filesize ) || bccomp( $start, "0" ) < 0 )
                            {
                                $start = 0;
                                $length = $filesize;
                            }
                            else
                            {
                                $length = bcsub( $filesize, $start );
                            }
                        }
                    }
                }
            } while ( 0 );
            if ( !$isset_start && $isset_end )
            {
                $length = 0 < bccomp( $end, $filesize ) ? $filesize : $end;
                $start = bcsub( $filesize, $end );
            }
            else
            {
                $start = 0;
                $length = $filesize;
            }
        }
        else
        {
            $start = 0;
            $length = $filesize;
        }
        $lastModified = gmdate( "D, d M Y H:i:s", filemtime( $file ) )." GMT";
        $etag = sprintf( "w/\"%s:%s\"", md5( $lastModified ), $filesize );
        header( "Cache-control: public" );
        header( "Pragma: public" );
        header( "Accept-Ranges: bytes" );
        if ( $isRange )
        {
            header( "HTTP/1.1 206 Partial Content" );
        }
        header( "Last-Modified: ".$lastModified );
        header( "ETag: ".$etag );
        if ( bccomp( $length, "2147483647" ) <= 0 )
        {
            header( "Content-Length: ".$length );
        }
        header( "Content-Range: bytes ".$start."-".bcsub( bcadd( $start, $length ), 1 )."/".$filesize );
        header( "Content-Type: ".$mimeType );
        if ( $attachment == 1 )
        {
            header( "Content-Disposition: attachment; ".get_attachment_filename( $basename ) );
        }
        else if ( $attachment == 2 )
        {
            header( "Content-Disposition: attachment; ".str_replace( "\"", "", get_attachment_filename( $basename ) ) );
        }
        else if ( $attachment == 0 )
        {
            header( "Content-Disposition: ".get_attachment_filename( $basename ) );
        }
        if ( $is_encrypted )
        {
            $encryptor->closeFile( );
            $handle = fopen( $file, "rb" );
            fseek( $handle, $start );
            while ( !( 0 < bccomp( $length, "0" ) ) || feof( $handle ) )
            {
                $read_bytes = bccomp( $length, "8192" ) < 0 ? $length : 8192;
                echo fread( $handle, $read_bytes );
                $length = bcsub( $length, $read_bytes );
            }
            fclose( $handle );
        }
        else
        {
            $encryptor->decryptFile( );
        }
    }
}

function td_getimagesize( $file )
{
    if ( file_exists( $file ) )
    {
        return FALSE;
    }
    $array = @getimagesize( @$file );
    if ( $array === FALSE )
    {
        include_once( "inc/encryptor/encryptor.php" );
        $encryptor = new TDEncryptor( $file );
        $file_header = $encryptor->getHeaderHead( );
        if ( $file_header['header_identifier'] == HEADER_IDENTIFIER )
        {
            if ( is_array( $file_header['ext_info'] ) && is_array( $file_header['ext_info']['image_size'] ) )
            {
                $array = $file_header['ext_info']['image_size'];
            }
            $encryptor->closeFile( );
        }
    }
    return $array;
}

function get_tmp_filename( $prefix, $basename = "" )
{
    $tmp_dir = ini_get( "upload_tmp_dir" );
    if ( !$tmp_dir || !is_dir( $tmp_dir ) )
    {
        $tmp_dir = realpath( MYOA_ROOT_PATH."../tmp" );
    }
    if ( $basename == "" )
    {
        $basename = mt_rand( ).".td";
    }
    return $tmp_dir."/".$prefix."_".date( "YmdHis" )."_".mt_rand( ).".".$basename;
}

function imagecreatefrombmp( $file )
{
    global $CurrentBit;
    global $echoMode;
    $f = td_fopen( $file, "r" );
    $Header = fread( $f, 2 );
    if ( $Header == "BM" )
    {
        $Size = freaddword( $f );
        $Reserved1 = freadword( $f );
        $Reserved2 = freadword( $f );
        $FirstByteOfImage = freaddword( $f );
        $SizeBITMAPINFOHEADER = freaddword( $f );
        $Width = freaddword( $f );
        $Height = freaddword( $f );
        $biPlanes = freadword( $f );
        $biBitCount = freadword( $f );
        $RLECompression = freaddword( $f );
        $WidthxHeight = freaddword( $f );
        $biXPelsPerMeter = freaddword( $f );
        $biYPelsPerMeter = freaddword( $f );
        $NumberOfPalettesUsed = freaddword( $f );
        $NumberOfImportantColors = freaddword( $f );
        if ( 24 < $biBitCount )
        {
            return FALSE;
        }
        if ( $biBitCount < 24 )
        {
            $img = imagecreate( $Width, $Height );
            $Colors = pow( 2, $biBitCount );
            $p = 0;
            for ( ; $p < $Colors; ++$p )
            {
                $B = freadbyte( $f );
                $G = freadbyte( $f );
                $R = freadbyte( $f );
                $Reserved = freadbyte( $f );
                $Palette[] = imagecolorallocate( $img, $R, $G, $B );
            }
            if ( $RLECompression == 0 )
            {
                $Zbytek = ( 4 - ceil( $Width / ( 8 / $biBitCount ) ) % 4 ) % 4;
                $y = $Height - 1;
                for ( ; 0 <= $y; --$y )
                {
                    $CurrentBit = 0;
                    $x = 0;
                    for ( ; $x < $Width; ++$x )
                    {
                        $C = freadbits( $f, $biBitCount );
                        imagesetpixel( $img, $x, $y, $Palette[$C] );
                    }
                    if ( $CurrentBit != 0 )
                    {
                        freadbyte( $f );
                    }
                    $g = 0;
                    for ( ; $g < $Zbytek; ++$g )
                    {
                        freadbyte( $f );
                    }
                }
            }
        }
        if ( $RLECompression == 1 )
        {
            $y = $Height;
            $pocetb = 0;
            do
            {
                --$y;
                $prefix = freadbyte( $f );
                $suffix = freadbyte( $f );
                $pocetb += 2;
                $echoit = FALSE;
                if ( $echoit )
                {
                    echo "Prefix: ";
                    echo $prefix;
                    echo " Suffix: ";
                    echo $suffix;
                    echo "<BR>";
                }
                if ( $prefix == 0 && $suffix == 1 || feof( $f ) )
                {
                }
                else if ( $prefix == 0 && $suffix == 0 )
                {
                    while ( $Tmp_0 )
                    {
                        if ( $prefix == 0 )
                        {
                            $pocet = $suffix;
                            $Data .= fread( $f, $pocet );
                            $pocetb += $pocet;
                            if ( $pocetb % 2 == 1 )
                            {
                                freadbyte( $f );
                                ++$pocetb;
                            }
                        }
                        if ( 0 < $prefix )
                        {
                            $pocet = $prefix;
                            $r = 0;
                            for ( ; $r < $pocet; ++$r )
                            {
                                $Data .= chr( $suffix );
                            }
                        }
                        $prefix = freadbyte( $f );
                        $suffix = freadbyte( $f );
                        $pocetb += 2;
                        if ( $echoit )
                        {
                            echo "Prefix: ";
                            echo $prefix;
                            echo " Suffix: ";
                            echo $suffix;
                            echo "<BR>";
                        }
                    }
                }
                else
                {
                    $x = 0;
                    for ( ; $x < strlen( $Data ); ++$x )
                    {
                        imagesetpixel( $img, $x, $y, $Palette[ord( $Data[$x] )] );
                    }
                    $Data = "";
                }
            } while ( 1 );
        }
        if ( $RLECompression == 2 )
        {
            $y = $Height;
            $pocetb = 0;
            do
            {
                --$y;
                $prefix = freadbyte( $f );
                $suffix = freadbyte( $f );
                $pocetb += 2;
                $echoit = FALSE;
                if ( $echoit )
                {
                    echo "Prefix: ";
                    echo $prefix;
                    echo " Suffix: ";
                    echo $suffix;
                    echo "<BR>";
                }
                if ( $prefix == 0 && $suffix == 1 || feof( $f ) )
                {
                }
                else if ( $prefix == 0 && $suffix == 0 )
                {
                    while ( $Tmp_0 )
                    {
                        if ( $prefix == 0 )
                        {
                            $pocet = $suffix;
                            $CurrentBit = 0;
                            $h = 0;
                            for ( ; $h < $pocet; ++$h )
                            {
                                $Data .= chr( freadbits( $f, 4 ) );
                            }
                            if ( $CurrentBit != 0 )
                            {
                                freadbits( $f, 4 );
                            }
                            $pocetb += ceil( $pocet / 2 );
                            if ( $pocetb % 2 == 1 )
                            {
                                freadbyte( $f );
                                ++$pocetb;
                            }
                        }
                        if ( 0 < $prefix )
                        {
                            $pocet = $prefix;
                            $i = 0;
                            $r = 0;
                            for ( ; $r < $pocet; ++$r )
                            {
                                if ( $i % 2 == 0 )
                                {
                                    $Data .= chr( $suffix % 16 );
                                }
                                else
                                {
                                    $Data .= chr( floor( $suffix / 16 ) );
                                }
                                ++$i;
                            }
                        }
                        $prefix = freadbyte( $f );
                        $suffix = freadbyte( $f );
                        $pocetb += 2;
                        if ( $echoit )
                        {
                            echo "Prefix: ";
                            echo $prefix;
                            echo " Suffix: ";
                            echo $suffix;
                            echo "<BR>";
                        }
                    }
                }
                else
                {
                    $x = 0;
                    for ( ; $x < strlen( $Data ); ++$x )
                    {
                        imagesetpixel( $img, $x, $y, $Palette[ord( $Data[$x] )] );
                    }
                    $Data = "";
                }
            } while ( 1 );
        }
        if ( $biBitCount == 24 )
        {
            $img = imagecreatetruecolor( $Width, $Height );
            $Zbytek = $Width % 4;
            $y = $Height - 1;
            for ( ; 0 <= $y; --$y )
            {
                $x = 0;
                for ( ; $x < $Width; ++$x )
                {
                    $B = freadbyte( $f );
                    $G = freadbyte( $f );
                    $R = freadbyte( $f );
                    $color = imagecolorexact( $img, $R, $G, $B );
                    if ( $color == -1 )
                    {
                        $color = imagecolorallocate( $img, $R, $G, $B );
                    }
                    imagesetpixel( $img, $x, $y, $color );
                }
                $z = 0;
                for ( ; $z < $Zbytek; ++$z )
                {
                    freadbyte( $f );
                }
            }
        }
        return $img;
    }
    fclose( $f );
}

function freadbyte( $f )
{
    return ord( fread( $f, 1 ) );
}

function freadword( $f )
{
    $b1 = freadbyte( $f );
    $b2 = freadbyte( $f );
    return $b2 * 256 + $b1;
}

function freaddword( $f )
{
    $b1 = freadword( $f );
    $b2 = freadword( $f );
    return $b2 * 65536 + $b1;
}

function freadbits( $f, $count )
{
    global $currentbit;
    global $smode;
    $byte = freadbyte( $f );
    $lastcbit = $currentbit;
    $currentbit += $count;
    if ( $currentbit == 8 )
    {
        $currentbit = 0;
    }
    else
    {
        fseek( $f, ftell( $f ) - 1 );
    }
    return retbits( $byte, $lastcbit, $count );
}

function retbits( $byte, $start, $len )
{
    $bin = decbin8( $byte );
    $r = bindec( substr( $bin, $start, $len ) );
    return $r;
}

function decbin8( $d )
{
    return decbinx( $d, 8 );
}

function decbinx( $d, $n )
{
    $bin = decbin( $d );
    $sbin = strlen( $bin );
    $j = 0;
    for ( ; $j < $n - $sbin; ++$j )
    {
        $bin = "0".$bin;
    }
    return $bin;
}

function replace_attach_url( $CONTENT, $MODULE = "" )
{
    if ( $MODULE == "" )
    {
        $MODULE = attach_sub_dir( );
    }
    if ( preg_match( "/<img.*?\\ssrc=\\\\\"(.*)\\/inc\\/attach.php\\?(.*)MODULE=upload_temp/i", $CONTENT ) )
    {
        $CONTENT = str_replace( "upload_temp", $MODULE, $CONTENT );
    }
    return $CONTENT;
}

function move_attach( $ATTACHMENT_ID, $ATTACHMENT_NAME, $MODULE_SRC = "", $MODULE_DESC = "" )
{
    if ( stristr( $ATTACHMENT_ID, "/" ) || stristr( $ATTACHMENT_ID, "\\" ) || stristr( $ATTACHMENT_NAME, "/" ) || stristr( $ATTACHMENT_NAME, "\\" ) || stristr( $MODULE_SRC, "/" ) || stristr( $MODULE_SRC, "\\" ) || stristr( $MODULE_DESC, "/" ) || stristr( $MODULE_DESC, "\\" ) )
    {
        message( _( "����" ), _( "�������зǷ��ַ���" ) );
        exit( );
    }
    $ATTACH_PARA_ARRAY = ( "SYS_ATTACH_PARA" );
    $ATTACH_POS_ACTIVE = $ATTACH_PARA_ARRAY['SYS_ATTACH_POS_ACTIVE'];
    $ATTACH_PATH_ACTIVE = $ATTACH_PARA_ARRAY['SYS_ATTACH_PATH_ACTIVE'];
    $ATTACHMENT_ID_ARRAY = explode( ",", $ATTACHMENT_ID );
    $ATTACHMENT_NAME_ARRAY = explode( "*", $ATTACHMENT_NAME );
    $I = 0;
    for ( ; $I < count( $ATTACHMENT_ID_ARRAY ); ++$I )
    {
        if ( $ATTACHMENT_ID_ARRAY[$I] == "" )
        {
            $SOURCE_FILE = attach_real_path( $ATTACHMENT_ID_ARRAY[$I], $ATTACHMENT_NAME_ARRAY[$I], $MODULE_SRC );
            if ( $SOURCE_FILE === FALSE )
            {
                return FALSE;
            }
            if ( $MODULE == "" )
            {
                $MODULE = attach_sub_dir( );
            }
            $ARRAY = attach_id_explode( $ATTACHMENT_ID_ARRAY[$I] );
            $AID = $ARRAY['AID'];
            $ATTACH_ID = $ARRAY['ATTACHMENT_ID'];
            $YM = $ARRAY['YM'];
            $PATH = $ATTACH_PATH_ACTIVE.$MODULE;
            if ( !file_exists( $PATH ) || !is_dir( $PATH ) )
            {
                mkdir( $PATH, 448 );
            }
            $PATH = $PATH."/".$YM;
            if ( !file_exists( $PATH ) || !is_dir( $PATH ) )
            {
                mkdir( $PATH, 448 );
            }
            $ATTACH_FILE = MYOA_ATTACH_NAME_FORMAT ? md5( $ATTACHMENT_NAME_ARRAY[$I] ).".td" : $ATTACHMENT_NAME_ARRAY[$I];
            $FILENAME = $PATH."/".$ATTACH_ID.".".$ATTACH_FILE;
            if ( file_exists( $FILENAME ) )
            {
                $ATTACH_ID = mt_rand( );
                $FILENAME = $PATH."/".$ATTACH_ID.".".$ATTACH_FILE;
            }
            $ATTACHMENT_TYPE = strtolower( substr( $ATTACHMENT_NAME_ARRAY[$I], strrpos( $ATTACHMENT_NAME_ARRAY[$I], "." ) ) );
            $PARA_VALUE = get_sys_para( "ATTACH_ENCRYPT", FALSE );
            $ATTACH_ENCRYPT = unserialize( $PARA_VALUE['ATTACH_ENCRYPT'] );
            if ( is_array( $ATTACH_ENCRYPT ) && $ATTACH_ENCRYPT['ENABLE'] == 1 && find_id( strtolower( $ATTACH_ENCRYPT['MODULES'] ), strtolower( $MODULE ) ) && find_id( strtolower( $ATTACH_ENCRYPT['TYPES'] ), ltrim( $ATTACHMENT_TYPE, "." ) ) && ( $ATTACH_ENCRYPT['COMPLETE'] == "0" || $ATTACH_ENCRYPT['COMPLETE'] == "1" && ( $ATTACH_ENCRYPT['MAX_SIZE'] == 0 || filesize( $SOURCE_FILE ) <= $ATTACH_ENCRYPT['MAX_SIZE'] * 1024 ) ) )
            {
                include_once( "inc/encryptor/encryptor.php" );
                $encryptor = new TDEncryptor( $SOURCE_FILE );
                $HEADER = $encryptor->getHeaderHead( );
                if ( $HEADER['header_identifier'] != HEADER_IDENTIFIER )
                {
                    return FALSE;
                }
                return FALSE;
            }
            if ( !$ATTACH_ENCRYPT['METHOD']( $FILENAME, $ATTACH_ENCRYPT['METHOD'], $ATTACH_ENCRYPT['COMPLETE'] == "1" ) && @!td_rename( @$SOURCE_FILE, $FILENAME ) && !td_rename( @$SOURCE_FILE, $FILENAME ) )
            {
                return FALSE;
            }
            $ATTACH_SIGN = is_office( $ATTACH_NAME ) ? $ATTACH_SIGN : 0;
            $query = "update ATTACHMENT set MODULE='".attach_module_id( $MODULE ).( "',ATTACH_ID='".$ATTACH_ID."' where AID='{$AID}'" );
            exequery( ( ), $query );
            $ATTACH_ID_NEW = $AID."@".$YM."_".$ATTACH_ID;
            if ( is_office( $ATTACH_NAME ) && $ATTACH_SIGN != 0 )
            {
                $ATTACH_ID_NEW .= ".".$ATTACH_SIGN;
            }
            $ATTACHMENT_ID_STR .= $ATTACH_ID_NEW.",";
        }
    }
    return substr( $ATTACHMENT_ID_STR, 0, -1 );
}

include_once( "inc/utility_all.php" );
?>
