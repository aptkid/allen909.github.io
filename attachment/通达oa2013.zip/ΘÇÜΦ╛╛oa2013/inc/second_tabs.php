<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
include_once( "inc/auth.inc.php" );
include_once( "inc/utility_all.php" );
ob_end_clean( );
if ( preg_match( "/[^a-zA-Z0-9_\\/]+/", $FUNC_CODE ) )
{
    echo _( "��Ч�Ĳ���" );
    exit( );
}
$FUNC_CODE = unescape( $FUNC_CODE );
$FUNC_CODE = ltrim( $FUNC_CODE, "/" );
$MENU_TOP = MYOA_ROOT_PATH.$FUNC_CODE."/menu_top.php";
$dataType = "javascript";
if ( file_exists( $MENU_TOP ) )
{
    include_once( $FUNC_CODE."/menu_top.php" );
}
else
{
    echo json_encode( "0" );
}
?>
