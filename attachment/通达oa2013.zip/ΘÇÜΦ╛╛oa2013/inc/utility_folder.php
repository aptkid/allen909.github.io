<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
function my_sort_tree( $SORT_ID_CHOOSE, $FILE_SORT, $PARENT_ID, $IS_SORT )
{
    global $DEEP_COUNT;
    if ( $PARENT_ID == 0 )
    {
        if ( $FILE_SORT == 1 )
        {
            $query = "SELECT SORT_ID,USER_ID,NEW_USER,SORT_NAME from FILE_SORT where SORT_TYPE!='4' and SORT_PARENT=0 order by SORT_NO,SORT_NAME";
        }
        else
        {
            $query = "SELECT SORT_ID,USER_ID,NEW_USER,SORT_NAME from FILE_SORT where SORT_TYPE='4' and USER_ID='".$_SESSION['LOGIN_USER_ID']."' and SORT_PARENT=0 order by SORT_NO,SORT_NAME";
        }
    }
    else
    {
        $query = "SELECT SORT_ID,USER_ID,NEW_USER,SORT_NAME from FILE_SORT where SORT_PARENT='".$PARENT_ID."' order by SORT_NO,SORT_NAME";
    }
    $cursor = exequery( ( ), $query );
    $OPTION_TEXT = "";
    if ( $FILE_SORT == 2 && $PARENT_ID == 0 )
    {
        $OPTION_TEXT = "<option value=0>"._( "��Ŀ¼" )."</option>\n";
    }
    $DEEP_COUNT1 = $DEEP_COUNT;
    $DEEP_COUNT .= "��";
    $COUNT = 0;
    $XML_TEXT = "";
    while ( $ROW = mysql_fetch_array( $cursor ) )
    {
        ++$COUNT;
        $SORT_ID = $ROW['SORT_ID'];
        $USER_ID = $ROW['USER_ID'];
        $NEW_USER = $ROW['NEW_USER'];
        $SORT_NAME = $ROW['SORT_NAME'];
        if ( $IS_SORT == 1 && $SORT_ID == $SORT_ID_CHOOSE )
        {
            $USER_ARRAY = explode( "|", $USER_ID );
            if ( $USER_ID != $_SESSION['LOGIN_USER_ID'] && $USER_ARRAY[0] != "ALL_DEPT" && !find_id( $USER_ARRAY[0], $_SESSION['LOGIN_DEPT_ID'] ) && !find_id( $USER_ARRAY[1], $_SESSION['LOGIN_USER_PRIV'] ) && !find_id( $USER_ARRAY[2], $_SESSION['LOGIN_USER_ID'] ) )
            {
            }
            else
            {
                $POSTFIX = _( "��" );
                if ( $COUNT == mysql_num_rows( $cursor ) )
                {
                    $DEEP_COUNT = substr( $DEEP_COUNT, 0, 0 - strlen( $POSTFIX ) ).$POSTFIX;
                }
                $NEW_PRIV = 0;
                $NEW_ARRAY = explode( "|", $NEW_USER );
                if ( $USER_ID == $_SESSION['LOGIN_USER_ID'] || $NEW_ARRAY[0] == "ALL_DEPT" || find_id( $NEW_ARRAY[0], $_SESSION['LOGIN_DEPT_ID'] ) || find_id( $NEW_ARRAY[1], $_SESSION['LOGIN_USER_PRIV'] ) || find_id( $NEW_ARRAY[2], $_SESSION['LOGIN_USER_ID'] ) )
                {
                    $NEW_PRIV = 1;
                }
                $SORT_NAME = htmlspecialchars( $SORT_NAME );
                $OPTION_TEXT .= "<option value=".$SORT_ID;
                if ( $FILE_SORT == 1 && !$NEW_PRIV )
                {
                    $OPTION_TEXT .= " style='color:gray;'";
                }
                if ( !( $IS_SORT != 1 ) || $SORT_ID == $SORT_ID_CHOOSE || $IS_SORT == 1 && $PARENT_ID == $SORT_ID_CHOOSE )
                {
                    $OPTION_TEXT .= " selected";
                }
                if ( $COUNT == mysql_num_rows( $cursor ) )
                {
                    $OPTION_TEXT .= ">".$DEEP_COUNT1."��".$SORT_NAME."</option>\n";
                }
                else
                {
                    $OPTION_TEXT .= ">".$DEEP_COUNT1."��".$SORT_NAME."</option>\n";
                }
                $OPTION_TEXT_CHILD = my_sort_tree( $SORT_ID_CHOOSE, $FILE_SORT, $SORT_ID, $IS_SORT );
                if ( $OPTION_TEXT_CHILD != "" )
                {
                    $OPTION_TEXT .= $OPTION_TEXT_CHILD;
                }
            }
        }
    }
    $DEEP_COUNT = $DEEP_COUNT1;
    return $OPTION_TEXT;
}

function access_priv( $SORT_PARENT )
{
    if ( $SORT_PARENT == 0 )
    {
    }
    else
    {
        $query = "SELECT USER_ID from FILE_SORT where SORT_ID='".$SORT_PARENT."'";
        $cursor = exequery( ( ), $query );
        if ( $ROW = mysql_fetch_array( $cursor ) )
        {
            $USER_ID = $ROW['USER_ID'];
            $ACCESS_PRIV = explode( "|", $USER_ID );
        }
        $ACCESS_PRIV[0] = td_trim( $ACCESS_PRIV[0] );
        $ACCESS_PRIV[1] = td_trim( $ACCESS_PRIV[1] );
        $query = "SELECT USER_ID from USER where NOT_LOGIN='0' or NOT_MOBILE_LOGIN='0'";
        if ( $ACCESS_PRIV[0] != "ALL_DEPT" )
        {
            $query .= " and (find_in_set(USER_ID,'".$ACCESS_PRIV[2]."')";
            if ( $ACCESS_PRIV[0] != "" )
            {
                $query .= " or DEPT_ID in (".$ACCESS_PRIV[0].")";
            }
            if ( $ACCESS_PRIV[1] != "" )
            {
                $query .= " or USER_PRIV in (".$ACCESS_PRIV[1].")";
            }
            $query .= ")";
        }
        $cursor = exequery( ( ), $query );
        while ( $ROW = mysql_fetch_array( $cursor ) )
        {
            $USER_ID_STR .= $ROW['USER_ID'].",";
        }
        return $USER_ID_STR;
    }
}

function sort_attrib( $SORT_ID, $ATTRIB )
{
    $query = "SELECT SORT_PARENT,".$ATTRIB." from FILE_SORT where SORT_ID='{$SORT_ID}'";
    $cursor = exequery( ( ), $query );
    if ( $ROW = mysql_fetch_array( $cursor ) )
    {
        $SORT_PARENT = $ROW['SORT_PARENT'];
    }
    if ( $SORT_PARENT == 0 || $SORT_PARENT == $SORT_ID )
    {
        return $ROW[$ATTRIB];
    }
    return sort_attrib( $SORT_PARENT, $ATTRIB );
}

function full_path( $SORT_ID )
{
    if ( $SORT_ID == 0 )
    {
    }
    else
    {
        $query = "SELECT SORT_PARENT,SORT_NAME from FILE_SORT where SORT_ID='".$SORT_ID."'";
        $cursor = exequery( ( ), $query );
        if ( $ROW = mysql_fetch_array( $cursor ) )
        {
            $SORT_PARENT = $ROW['SORT_PARENT'];
            $SORT_NAME = $ROW['SORT_NAME'];
        }
        return full_path( $SORT_PARENT )."/".$SORT_NAME;
    }
}

function delete_reader( $CONTENT_ID )
{
    $query = "delete from APP_LOG where OPP_ID='".$CONTENT_ID."' and MODULE=15";
    exequery( ( ), $query );
}

?>
