<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
if ( !defined( "IN_UC" ) )
{
    exit( "Access Denied" );
}
define( "PMLIMIT1DAY_ERROR", -1 );
define( "PMFLOODCTRL_ERROR", -2 );
define( "PMMSGTONOTFRIEND", -3 );
define( "PMSENDREGDAYS", -4 );
define( "PMUSERLIMIT1DAY_ERROR", -5 );
class pmcontrol extends base
{

    public function __construct( )
    {
        $this->pmcontrol( );
    }

    public function pmcontrol( )
    {
        ( );
        $this->load( "user" );
        $this->load( "pm" );
    }

    public function oncheck_newpm( )
    {
        $this->init_input( );
        $this->user['uid'] = intval( $this->input( "uid" ) );
        $more = $this->input( "more" );
        $result = $this->user( $this->user['uid'], $more );
        if ( $more == 3 )
        {
            require_once( UC_ROOT."lib/uccode.class.php" );
            $this->uccode = new uccode( );
            $result['lastmsg'] = $this->uccode->complie( $result['lastmsg'] );
        }
        return $result;
    }

    public function onsendpm( )
    {
        $this->init_input( );
        $fromuid = $this->input( "fromuid" );
        $msgto = $this->input( "msgto" );
        $subject = $this->input( "subject" );
        $message = $this->input( "message" );
        $replypmid = $this->input( "replypmid" );
        $isusername = $this->input( "isusername" );
        if ( $fromuid )
        {
            $user = $_ENV['user']->get_user_by_uid( $fromuid );
            $user = daddslashes( $user, 1 );
            if ( $user )
            {
                return 0;
            }
            $this->user['uid'] = $user['uid'];
            $this->user['username'] = $user['username'];
        }
        else
        {
            $this->user['uid'] = 0;
            $this->user['username'] = "";
        }
        if ( $replypmid )
        {
            $isusername = 1;
            $pms = $this->user( $this->user['uid'], $replypmid );
            if ( $pms[0]['msgfromid'] == $this->user['uid'] )
            {
                $user = $pms[0]( $pms[0]['msgtoid'] );
                $msgto = $user['username'];
            }
            else
            {
                $msgto = $pms[0]['msgfrom'];
            }
        }
        $msgto = array_unique( explode( ",", $msgto ) );
        if ( $isusername )
        {
        }
        $blackls = $this->user( $this->user['uid'], $msgto );
        if ( $fromuid )
        {
            if ( $this->settings['pmsendregdays'] && $this->time - $this->settings['pmsendregdays'] * 86400 < $user['regdate'] )
            {
                return PMSENDREGDAYS;
            }
            $this->load( "friend" );
            if ( 1 < count( $msgto ) && !( $is_friend = $_ENV['friend']->is_friend( $fromuid, $msgto, 3 ) ) )
            {
                return PMMSGTONOTFRIEND;
            }
            $pmlimit1day = $this->settings['pmlimit1day'] < $this->user( $this->user['uid'], 86400 );
            if ( ( $pmlimit1day || $this->settings['pmfloodctrl'] && $this->settings( $this->user['uid'], $this->settings['pmfloodctrl'] ) ) && !$_ENV['friend']->is_friend( $fromuid, $msgto, 3 ) && !$_ENV['pm']->is_reply_pm( $fromuid, $msgto ) )
            {
                if ( $pmlimit1day )
                {
                    return PMLIMIT1DAY_ERROR;
                }
                return PMFLOODCTRL_ERROR;
            }
            if ( 0 < ( $pmuserlimit1day = $this->settings['pmuserlimit1day'] ) )
            {
                $num = count( $msgto );
                if ( $num == 1 )
                {
                    return PMUSERLIMIT1DAY_ERROR;
                }
                if ( !$this->user( $this->user['uid'], $msgto[0], 86400 ) && $pmuserlimit1day < $this->user( $this->user['uid'], 86400 ) + 1 && $pmuserlimit1day < $this->user( $this->user['uid'], 86400 ) + $num )
                {
                    return PMUSERLIMIT1DAY_ERROR;
                }
            }
        }
        $lastpmid = 0;
        foreach ( $msgto as $uid )
        {
            if ( $fromuid && in_array( "{ALL}", $blackls[$uid] ) )
            {
                $blackls[$uid] = $_ENV['user']->name2id( $blackls[$uid] );
                if ( $fromuid && ( !isset( $blackls[$uid] ) || in_array( $this->user['uid'], $blackls[$uid] ) ) )
                {
                    $lastpmid = $_ENV['pm']->sendpm( $subject, $message, $this->user, $uid, $replypmid );
                }
            }
        }
        return $lastpmid;
    }

    public function ondelete( )
    {
        $this->init_input( );
        $this->user['uid'] = intval( $this->input( "uid" ) );
        $id = $this->user( $this->user['uid'], $this->input( "pmids" ) );
        return $id;
    }

    public function ondeleteuser( )
    {
        $this->init_input( );
        $this->user['uid'] = intval( $this->input( "uid" ) );
        $id = $this->user( $this->user['uid'], $this->input( "touids" ) );
        return $id;
    }

    public function onreadstatus( )
    {
        $this->init_input( );
        $this->user['uid'] = intval( $this->input( "uid" ) );
        $this->user( $this->user['uid'], $this->input( "uids" ), $this->input( "pmids" ), $this->input( "status" ) );
    }

    public function onignore( )
    {
        $this->init_input( );
        $this->user['uid'] = intval( $this->input( "uid" ) );
        return $this->user( $this->user['uid'] );
    }

    public function onls( )
    {
        $this->init_input( );
        $pagesize = $this->input( "pagesize" );
        $folder = $this->input( "folder" );
        $filter = $this->input( "filter" );
        $page = $this->input( "page" );
        $folder = in_array( $folder, array( "newbox", "inbox", "outbox", "searchbox" ) ) ? $folder : "inbox";
        $filter = "";
        $msglen = $this->input( "msglen" );
        $this->user['uid'] = intval( $this->input( "uid" ) );
        if ( $folder != "searchbox" )
        {
            $pmnum = $this->user( $this->user['uid'], $folder, $filter );
            $start = $this->page_get_start( $page, $pagesize, $pmnum );
        }
        else
        {
            $pmnum = $pagesize;
            $start = ( $page - 1 ) * $pagesize;
        }
        if ( 0 < $pagesize )
        {
            $pms = $this->user( $this->user['uid'], $pmnum, $folder, $filter, $start, $pagesize );
            if ( empty( $pms ) )
            {
                foreach ( $pms as $key => $pm )
                {
                    if ( $msglen )
                    {
                        $pms[$key]['message'] = htmlspecialchars( $pms[$key]( $pms[$key]['message'], $msglen ) );
                    }
                    else
                    {
                        unset( $pms[$key]['message'] );
                    }
                    unset( $pms[$key]['folder'] );
                }
            }
            $result['data'] = $pms;
        }
        $result['count'] = $pmnum;
        return $result;
    }

    public function onviewnode( )
    {
        $this->init_input( );
        $this->user['uid'] = intval( $this->input( "uid" ) );
        $pmid = $_ENV['pm']->pmintval( $this->input( "pmid" ) );
        $type = $this->input( "type" );
        $pm = $this->user( $this->user['uid'], $pmid, $type );
        if ( $pm )
        {
            require_once( UC_ROOT."lib/uccode.class.php" );
            $this->uccode = new uccode( );
            $pm['message'] = $this->uccode->complie( $pm['message'] );
            return $pm;
        }
    }

    public function onview( )
    {
        $this->init_input( );
        $this->user['uid'] = intval( $this->input( "uid" ) );
        $touid = $this->input( "touid" );
        $pmid = $_ENV['pm']->pmintval( $this->input( "pmid" ) );
        $daterange = $this->input( "daterange" );
        if ( empty( $pmid ) )
        {
            $daterange = empty( $daterange ) ? 1 : $daterange;
            $today = $this->time - ( $this->time + $this->settings['timeoffset'] ) % 86400;
            if ( $daterange == 1 )
            {
                $starttime = $today;
            }
            else if ( $daterange == 2 )
            {
                $starttime = $today - 86400;
            }
            else if ( $daterange == 3 )
            {
                $starttime = $today - 172800;
            }
            else if ( $daterange == 4 )
            {
                $starttime = $today - 604800;
            }
            else if ( $daterange == 5 )
            {
                $starttime = 0;
            }
            $endtime = $this->time;
            $pms = $this->user( $this->user['uid'], $touid, $starttime, $endtime );
        }
        else
        {
            $pms = $this->user( $this->user['uid'], $pmid );
        }
        require_once( UC_ROOT."lib/uccode.class.php" );
        $this->uccode = new uccode( );
        $status = FALSE;
        foreach ( $pms as $key => $pm )
        {
            $pms[$key]['message'] = $pms[$key]( $pms[$key]['message'] );
            if ( !$status )
            {
            }
        }
        if ( $status )
        {
        }
        return $pms;
    }

    public function onblackls_get( )
    {
        $this->init_input( );
        $this->user['uid'] = intval( $this->input( "uid" ) );
        return $this->user( $this->user['uid'] );
    }

    public function onblackls_set( )
    {
        $this->init_input( );
        $this->user['uid'] = intval( $this->input( "uid" ) );
        $blackls = $this->input( "blackls" );
        return $this->user( $this->user['uid'], $blackls );
    }

    public function onblackls_add( )
    {
        $this->init_input( );
        $this->user['uid'] = intval( $this->input( "uid" ) );
        $username = $this->input( "username" );
        return $this->user( $this->user['uid'], $username, 1 );
    }

    public function onblackls_delete( $arr )
    {
        $this->init_input( );
        $this->user['uid'] = intval( $this->input( "uid" ) );
        $username = $this->input( "username" );
        return $this->user( $this->user['uid'], $username, 2 );
    }

}

?>
