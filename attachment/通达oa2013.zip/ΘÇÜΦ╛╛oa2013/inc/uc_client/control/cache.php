<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
if ( !defined( "IN_UC" ) )
{
    exit( "Access Denied" );
}
class cachecontrol extends base
{

    public function __construct( )
    {
        $this->cachecontrol( );
    }

    public function cachecontrol( )
    {
        ( );
    }

    public function onupdate( $arr )
    {
        $this->load( "cache" );
        $_ENV['cache']->updatedata( );
    }

}

?>
