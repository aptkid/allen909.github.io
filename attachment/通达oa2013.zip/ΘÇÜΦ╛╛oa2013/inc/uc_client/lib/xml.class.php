<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class XML
{

    public $parser;
    public $document;
    public $stack;
    public $data;
    public $last_opened_tag;
    public $isnormal;
    public $attrs = array( );
    public $failed = FALSE;

    public function __construct( $isnormal )
    {
        $this->XML( $isnormal );
    }

    public function XML( $isnormal )
    {
        $this->isnormal = $isnormal;
        $this->parser = xml_parser_create( "ISO-8859-1" );
        xml_parser_set_option( $this->parser, XML_OPTION_CASE_FOLDING, FALSE );
        xml_set_object( $this->parser, $this );
        xml_set_element_handler( $this->parser, "open", "close" );
        xml_set_character_data_handler( $this->parser, "data" );
    }

    public function destruct( )
    {
        xml_parser_free( $this->parser );
    }

    public function parse( &$data )
    {
        $this->document = array( );
        $this->stack = array( );
        if ( xml_parse( $this->parser, $data, TRUE ) && !$this->failed )
        {
            return $this->document;
        }
        return "";
    }

    public function open( &$parser, $tag, $attributes )
    {
        $this->data = "";
        $this->failed = FALSE;
        if ( $this->isnormal )
        {
            if ( isset( $attributes['id'] ) && !is_string( $this->document[$attributes['id']] ) )
            {
                $this->document =& $this->document[$attributes['id']];
            }
            else
            {
                $this->failed = TRUE;
            }
        }
        else if ( !isset( $this->document[$tag] ) || !is_string( $this->document[$tag] ) )
        {
            $this->document =& $this->document[$tag];
        }
        else
        {
            $this->failed = TRUE;
        }
        $this->stack[] =& $this->document;
        $this->last_opened_tag = $tag;
        $this->attrs = $attributes;
    }

    public function data( &$parser, $data )
    {
        if ( $this->last_opened_tag != NULL )
        {
            $ && _845772600 .= "data";
        }
    }

    public function close( &$parser, $tag )
    {
        if ( $this->last_opened_tag == $tag )
        {
            $this->document = $this->data;
            $this->last_opened_tag = NULL;
        }
        array_pop( &$this->stack );
        if ( $this->stack )
        {
            $this->document =& $this->stack[count( $this->stack ) - 1];
        }
    }

}

function xml_unserialize( &$xml, $isnormal = FALSE )
{
    $xml_parser = new XML( $isnormal );
    $data = $xml_parser->parse( $xml );
    $xml_parser->destruct( );
    return $data;
}

function xml_serialize( $arr, $htmlon = FALSE, $isnormal = FALSE, $level = 1 )
{
    $s = $level == 1 ? "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>\r\n<root>\r\n" : "";
    $space = str_repeat( "\t", $level );
    foreach ( $arr as $k => $v )
    {
        if ( is_array( $v ) )
        {
            $s .= $space.( "<item id=\"".$k."\">" ).( $htmlon ? "<![CDATA[" : "" ).$v.( $htmlon ? "]]>" : "" )."</item>\r\n";
        }
        else
        {
            $s .= $space.( "<item id=\"".$k."\">\r\n" ).xml_serialize( $v, $htmlon, $isnormal, $level + 1 ).$space."</item>\r\n";
        }
    }
    $s = preg_replace( "/([\x01-\x08\x0B-\x0C\x0E-\x1F])+/", " ", $s );
    if ( $level == 1 )
    {
        return $s."</root>";
    }
    return $s;
}

?>
