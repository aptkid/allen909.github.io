<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class appmodel
{

    public $db;
    public $base;

    public function __construct( &$base )
    {
        $this->appmodel( $base );
    }

    public function appmodel( &$base )
    {
        $this->base = $base;
        $this->db = $base->db;
    }

    public function get_apps( $col = "*", $where = "" )
    {
        $arr = $this->db->fetch_all( "SELECT ".$col." FROM ".UC_DBTABLEPRE."applications".( $where ? " WHERE ".$where : "" ), "appid" );
        foreach ( $arr as $k => $v )
        {
            if ( isset( $v['extra'] ) )
            {
                if ( isset( $v['extra'] ) && !empty( $v['extra'] ) )
                {
                }
            }
            unset( $v['authkey'] );
            $arr[$k] = $v;
        }
        return $arr;
    }

}

if ( !defined( "IN_UC" ) )
{
    exit( "Access Denied" );
}
?>
