<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
include_once( "inc/auth.inc.php" );
include_once( "inc/td_core.php" );
$WEATHER_CITY = iconv( "UTF-8", MYOA_CHARSET, $WEATHER_CITY );
if ( $UPDATE == "1" )
{
    $query = "update USER set WEATHER_CITY='".$WEATHER_CITY."' where UID='".$_SESSION['LOGIN_UID']."'";
    exequery( ( ), $query );
    include_once( "inc/utility_cache.php" );
    updateusercache( $_SESSION['LOGIN_UID'] );
}
ob_end_clean( );
echo tdoa_weather( $WEATHER_CITY, $VIEW );
?>
