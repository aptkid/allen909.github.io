<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class WorkFormListDB
{

    private static $OBJ_SQL_SYNTAX;
    private $_form_sort = 0;
    private $_dept_id = 0;
    private $_ext_dept_ids;
    private $_order_pattern = 0;
    private $_search_name = "";

    const TABLE_NAME = "flow_form_type";
    const ORDER_PATTERN_CREATE_TIME_DESC = 0;
    const ORDER_PATTERN_CREATE_TIME_ASC = 1;
    const ORDER_PATTERN_NAME_DESC = 2;
    const ORDER_PATTERN_NAME_ASC = 3;

    public function __construct( $form_sort = 0, $dept_id = 0 )
    {
        $this->_form_sort = $form_sort;
        $this->_dept_id = $dept_id;
        $this->_order_pattern = self::ORDER_PATTERN_CREATE_TIME_DESC;
        self::$OBJ_SQL_SYNTAX = ( MYOA_DBMS );
    }

    public function setFormSort( $form_sort )
    {
        $this->_form_sort = $form_sort;
    }

    public function getFormSort( )
    {
        return $this->_form_sort;
    }

    public function setDeptID( $dept_id )
    {
        $this->_dept_id = $dept_id;
    }

    public function getDeptID( )
    {
        return $this->_dept_id;
    }

    public function setOrderPattern( $order_pattern )
    {
        $this->_order_pattern = $order_pattern;
    }

    public function getOrderPattern( )
    {
        return $this->_order_pattern;
    }

    public function getSearchName( )
    {
        return $this->_search_name;
    }

    public function setSearchName( $name )
    {
        $this->_search_name = $name;
    }

    public function setExtDeptIds( $ext_dept_ids )
    {
        $this->_ext_dept_ids = $ext_dept_ids;
    }

    public function getExtDeptIds( )
    {
        return $this->_ext_dept_ids;
    }

    public function fetch( $fields = NULL, $isCurDir = TRUE, $r_connection = NULL )
    {
        if ( $r_connection == NULL )
        {
            $r_connection = ( );
        }
        $select_exprs = self::$OBJ_SQL_SYNTAX->getSelectExprs( $fields );
        $conditions = array( );
        if ( 0 < $dept_id )
        {
            if ( isset( $this->_ext_dept_ids ) && trim( $this->_ext_dept_ids ) != "" )
            {
                $s_dept_ids = td_trim( $this->_ext_dept_ids ).",".$this->_dept_id;
                array_push( &$conditions, self::$OBJ_SQL_SYNTAX->getConditionExpr( "DEPT_ID", EXPR_OP_IN, $s_dept_ids, FIELD_TYPE_INT ) );
            }
            else
            {
                array_push( &$conditions, self::$OBJ_SQL_SYNTAX->getConditionExpr( "DEPT_ID", EXPR_OP_IS, $this->_dept_id, FIELD_TYPE_INT ) );
            }
        }
        if ( $isCurDir )
        {
            array_push( &$conditions, self::$OBJ_SQL_SYNTAX->getConditionExpr( "FORM_SORT", EXPR_OP_IS, $this->_form_sort, FIELD_TYPE_INT ) );
        }
        if ( isset( $this->_search_name ) && trim( $this->_search_name ) != "" )
        {
            array_push( &$conditions, $this->getQueryCondition( ) );
        }
        if ( 0 < count( $conditions ) )
        {
            $where_definition = self::$OBJ_SQL_SYNTAX->getWhereDefinition( $conditions, CONDITION_LOGIC_OP_AND );
        }
        $order_by_definition = $this->getOrderDefinition( );
        $sql = self::$OBJ_SQL_SYNTAX->getQuerySQL( 0, 0, $select_exprs, self::TABLE_NAME, $where_definition, $order_by_definition );
        $r_cursor = exequery( $r_connection, $sql );
        return $r_cursor;
    }

    private function getOrderDefinition( )
    {
        if ( $this->_order_pattern == self::ORDER_PATTERN_CREATE_TIME_DESC )
        {
            return self::$OBJ_SQL_SYNTAX->getOrderByDefinition( "FORM_ID", "DESC" );
        }
        if ( $this->_order_pattern == self::ORDER_PATTERN_CREATE_TIME_ASC )
        {
            return self::$OBJ_SQL_SYNTAX->getOrderByDefinition( "FORM_ID", "ASC" );
        }
        if ( $this->_order_pattern == self::ORDER_PATTERN_NAME_DESC )
        {
            return self::$OBJ_SQL_SYNTAX->getOrderByDefinition( "FORM_NAME", "DESC" );
        }
        if ( $this->_order_pattern == self::ORDER_PATTERN_NAME_ASC )
        {
            return self::$OBJ_SQL_SYNTAX->getOrderByDefinition( "FORM_NAME", "ASC" );
        }
        return "";
    }

    private function getQueryCondition( )
    {
        return self::$OBJ_SQL_SYNTAX->getConditionExpr( "FORM_NAME", EXPR_OP_CTS, $this->_search_name, FIELD_TYPE_CHAR );
    }

}

?>
