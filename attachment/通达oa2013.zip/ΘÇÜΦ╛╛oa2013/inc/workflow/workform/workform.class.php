<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class WorkForm
{

    private $form_id = 0;
    private $form_name = "";
    private $print_model = "";
    private $print_model_short = "";
    private $obj_form_print_model;
    private $dept_id = 0;
    private $script = "";
    private $css = "";
    private $item_max = 0;
    private $form_sort = 0;
    private $obj_form_type;

    public function _set( $property_name, $property_value )
    {
        $property_name = strtolower( $property_name );
        $this->$property_name = $property_value;
    }

    public function _get( $property_name )
    {
        $property_name = strtolower( $property_name );
        if ( isset( $this->$property_name ) )
        {
            return $this->$property_name;
        }
    }

    private function set_obj_form_sort( )
    {
        $this->_obj_form_type = new FormSort( $this->_form_type );
    }

    private function get_obj_form_sort( )
    {
        return $this->_obj_form_type;
    }

    private function set_form_print_model( )
    {
        $this->obj_form_print_model = new FormPrintModel( $this->_print_model, $this->_print_model_short );
    }

    private function get_form_print_model( )
    {
        return $this->obj_form_print_model;
    }

}

?>
