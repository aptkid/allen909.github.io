<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class WorkFormCategoryListDB
{

    private static $OBJ_SQL_SYNTAX;
    private $_sort_parent = 0;
    private $_dept_id = 0;
    private $_ext_dept_ids;
    private $_order_pattern = 0;
    private $_search_name = "";

    const TABLE_NAME = "form_sort";
    const ORDER_PATTERN_SORT_NO_ASC = 0;
    const ORDER_PATTERN_SORT_NO_DESC = 1;
    const ORDER_PATTERN_CREATE_TIME_ASC = 2;
    const ORDER_PATTERN_CREATE_TIME_DESC = 3;
    const ORDER_PATTERN_NAME_ASC = 4;
    const ORDER_PATTERN_NAME_DESC = 5;

    public function __construct( $sort_parent = 0, $dept_id = -1 )
    {
        $this->_sort_parent = $sort_parent;
        $this->_dept_id = $dept_id;
        self::$OBJ_SQL_SYNTAX = ( MYOA_DBMS );
    }

    public function setSortParent( $sort_parent )
    {
        $this->_sort_parent = $sort_parent;
    }

    public function SortParent( )
    {
        return $this->_sort_parent;
    }

    public function setDeptID( $dept_id )
    {
        $this->_dept_id = $dept_id;
    }

    public function getDeptID( )
    {
        return $this->_dept_id;
    }

    public function setOrderPattern( $order_pattern )
    {
        $this->_order_pattern = $order_pattern;
    }

    public function getOrderPattern( )
    {
        return $this->_order_pattern;
    }

    public function getSearchName( )
    {
        return $this->_search_name;
    }

    public function setSearchName( $name )
    {
        $this->_search_name = $name;
    }

    public function setExtDeptIds( $ext_dept_ids )
    {
        $this->_ext_dept_ids = $ext_dept_ids;
    }

    public function getExtDeptIds( )
    {
        return $this->_ext_dept_ids;
    }

    public function getPartentIdBySortId( $sort_id, $r_connection = NULL )
    {
        if ( $r_connection == NULL )
        {
            $r_connection = ( );
        }
        $sql = "select * from ".self::TABLE_NAME.( " where SORT_ID='".$sort_id."'" );
        $r_cursor = exequery( $r_connection, $sql );
        $arr = array( );
        while ( $row = mysql_fetch_array( $r_cursor ) )
        {
            array_push( &$arr, $sort_id );
            if ( $row['SORT_PARENT'] != 0 )
            {
                $arr = array_merge( $arr, $row['SORT_PARENT']( $row['SORT_PARENT'], $r_connection ) );
            }
        }
        return $arr;
    }

    public function getPartentsID( $dept_id_str, $r_connection = NULL )
    {
        if ( $r_connection == NULL )
        {
            $r_connection = ( );
        }
        $sql = "select * from ".self::TABLE_NAME.( " where DEPT_ID in(".$dept_id_str.")" );
        $r_cursor = exequery( $r_connection, $sql );
        $arr = array( );
        while ( $row = mysql_fetch_array( $r_cursor ) )
        {
            $arr = array_merge( $arr, $row['SORT_ID']( $row['SORT_ID'], $r_connection ) );
        }
        return $arr;
    }

    public function fetch( $fields = NULL, $isCurDir = TRUE, $r_connection = NULL )
    {
        if ( $r_connection == NULL )
        {
            $r_connection = ( );
        }
        $select_exprs = self::$OBJ_SQL_SYNTAX->getSelectExprs( $fields );
        $conditions = array( );
        if ( 0 < $this->_dept_id )
        {
            $dept_conditions = array( );
            if ( isset( $this->_ext_dept_ids ) && trim( $this->_ext_dept_ids ) != "" )
            {
                $s_dept_ids = td_trim( $this->_ext_dept_ids ).",".$this->_dept_id;
                $dept_conditions[] = self::$OBJ_SQL_SYNTAX->getConditionExpr( "DEPT_ID", EXPR_OP_IS, 0, FIELD_TYPE_INT );
                $dept_conditions[] = self::$OBJ_SQL_SYNTAX->getConditionExpr( "DEPT_ID", EXPR_OP_IN, $s_dept_ids, FIELD_TYPE_INT );
                $dept_where = self::$OBJ_SQL_SYNTAX->getWhereDefinition( $dept_conditions, CONDITION_LOGIC_OP_OR );
                array_push( &$conditions, $dept_where );
            }
            else
            {
                $dept_conditions[] = self::$OBJ_SQL_SYNTAX->getConditionExpr( "DEPT_ID", EXPR_OP_IS, 0, FIELD_TYPE_INT );
                $dept_conditions[] = self::$OBJ_SQL_SYNTAX->getConditionExpr( "DEPT_ID", EXPR_OP_IS, $this->_dept_id, FIELD_TYPE_INT );
                $sort_arr = $this->getPartentsID( $this->_dept_id.",0" );
                foreach ( $sort_arr as $sort_id )
                {
                    $dept_conditions[] = self::$OBJ_SQL_SYNTAX->getConditionExpr( "SORT_ID", EXPR_OP_IS, $sort_id, FIELD_TYPE_INT );
                }
                $dept_where = self::$OBJ_SQL_SYNTAX->getWhereDefinition( $dept_conditions, CONDITION_LOGIC_OP_OR );
                array_push( &$conditions, $dept_where );
            }
        }
        if ( $isCurDir )
        {
            array_push( &$conditions, self::$OBJ_SQL_SYNTAX->getConditionExpr( "SORT_PARENT", EXPR_OP_IS, $this->_sort_parent, FIELD_TYPE_INT ) );
        }
        if ( isset( $this->_search_name ) && trim( $this->_search_name ) != "" )
        {
            array_push( &$conditions, $this->getQueryCondition( ) );
        }
        if ( 0 < count( $conditions ) )
        {
            $where_definition = self::$OBJ_SQL_SYNTAX->getWhereDefinition( $conditions, CONDITION_LOGIC_OP_AND );
        }
        $order_by_definition = $this->getOrderDefinition( );
        $sql = self::$OBJ_SQL_SYNTAX->getQuerySQL( 0, 0, $select_exprs, self::TABLE_NAME, $where_definition, $order_by_definition );
        $r_cursor = exequery( $r_connection, $sql );
        return $r_cursor;
    }

    public function getFormNumberOfCategory( $category_ids = NULL, $r_connection = NULL )
    {
        $array_count = array( );
        if ( $r_connection == NULL )
        {
            $r_connection = ( );
        }
        $select_exprs = self::$OBJ_SQL_SYNTAX->getSelectExprs( "FORM_SORT, count(FORM_ID) as form_count" );
        if ( isset( $category_ids ) && trim( $category_ids ) != "" )
        {
            $having_definition = self::$OBJ_SQL_SYNTAX->getConditionExpr( "FORM_SORT", EXPR_OP_IN, $category_ids, FIELD_TYPE_INT );
        }
        $group_definition = self::$OBJ_SQL_SYNTAX->getGroupByDefinition( "FORM_SORT" );
        $sql = self::$OBJ_SQL_SYNTAX->getQuerySQL( 0, 0, $select_exprs, "flow_form_type", NULL, NULL, $having_definition, $group_definition );
        $r_cursor = exequery( $r_connection, $sql );
        while ( $row = mysql_fetch_array( $r_cursor ) )
        {
            $array_count[$row['FORM_SORT']] = $row['form_count'];
        }
        return $array_count;
    }

    private function getOrderDefinition( )
    {
        if ( $this->_order_pattern == self::ORDER_PATTERN_SORT_NO_ASC )
        {
            return self::$OBJ_SQL_SYNTAX->getOrderByDefinition( "SORT_NO", "ASC" );
        }
        if ( $this->_order_pattern == self::ORDER_PATTERN_SORT_NO_DESC )
        {
            return self::$OBJ_SQL_SYNTAX->getOrderByDefinition( "SORT_NO", "DESC" );
        }
        if ( $this->_order_pattern == self::ORDER_PATTERN_CREATE_TIME_ASC )
        {
            return self::$OBJ_SQL_SYNTAX->getOrderByDefinition( "SORT_ID", "ASC" );
        }
        if ( $this->_order_pattern == self::ORDER_PATTERN_CREATE_TIME_DESC )
        {
            return self::$OBJ_SQL_SYNTAX->getOrderByDefinition( "SORT_ID", "DESC" );
        }
        if ( $this->_order_pattern == self::ORDER_PATTERN_NAME_ASC )
        {
            return self::$OBJ_SQL_SYNTAX->getOrderByDefinition( "SORT_NAME", "ASC" );
        }
        if ( $this->_order_pattern == self::ORDER_PATTERN_NAME_DESC )
        {
            return self::$OBJ_SQL_SYNTAX->getOrderByDefinition( "SORT_NAME", "DESC" );
        }
        return "";
    }

    private function getQueryCondition( )
    {
        return self::$OBJ_SQL_SYNTAX->getConditionExpr( "SORT_NAME", EXPR_OP_CTS, $this->_search_name, FIELD_TYPE_CHAR );
    }

}

?>
