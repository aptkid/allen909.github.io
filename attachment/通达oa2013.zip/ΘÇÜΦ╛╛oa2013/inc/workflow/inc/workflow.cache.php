<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
function cache_flow_type( )
{
    $r_connection = ( );
    $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
    $select_exprs = $OBJ_SQL_SYNTAX->getSelectExprs( " FLOW_ID,\r\n                                                        FLOW_NAME, \r\n                                                        FLOW_DOC, \r\n                                                        FLOW_TYPE,\r\n                                                        FLOW_SORT,\r\n                                                        FORM_ID,\r\n                                                        AUTO_NAME,\r\n                                                        AUTO_NUM,\r\n                                                        AUTO_LEN,\r\n                                                        AUTO_EDIT,\r\n                                                        IS_VERSION,\r\n                                                        FORCE_PRE_SET,\r\n                                                        FREE_OTHER,\r\n                                                        VIEW_PRIV,\r\n                                                        VIEW_USER,\r\n                                                        VIEW_DEPT,\r\n                                                        VIEW_ROLE,\r\n                                                        NEW_USER" );
    $table_references = $OBJ_SQL_SYNTAX->getTableReferences( "flow_type" );
    $sql = $OBJ_SQL_SYNTAX->getQuerySQL( 0, 0, $select_exprs, $table_references );
    $flow_array = array( );
    $r_cursor = exequery( $r_connection, $sql, TRUE );
    while ( $row = mysql_fetch_array( $r_cursor ) )
    {
        $flow_id = $row['FLOW_ID'];
        $flow_array[$flow_id] = array( );
        $flow_array[$flow_id]['FLOW_NAME'] = $row['FLOW_NAME'];
        $flow_array[$flow_id]['FLOW_DOC'] = $row['FLOW_DOC'];
        $flow_array[$flow_id]['FLOW_TYPE'] = $row['FLOW_TYPE'];
        $flow_array[$flow_id]['FLOW_SORT'] = $row['FLOW_SORT'];
        $flow_array[$flow_id]['FORM_ID'] = $row['FORM_ID'];
        $flow_array[$flow_id]['AUTO_NAME'] = $row['AUTO_NAME'];
        $flow_array[$flow_id]['AUTO_NUM'] = $row['AUTO_NUM'];
        $flow_array[$flow_id]['AUTO_LEN'] = $row['AUTO_LEN'];
        $flow_array[$flow_id]['AUTO_EDIT'] = $row['AUTO_EDIT'];
        $flow_array[$flow_id]['IS_VERSION'] = $row['IS_VERSION'];
        $flow_array[$flow_id]['FORCE_PRE_SET'] = $row['FORCE_PRE_SET'];
        $flow_array[$flow_id]['FREE_OTHER'] = $row['FREE_OTHER'];
        $flow_array[$flow_id]['VIEW_PRIV'] = $row['VIEW_PRIV'];
        $flow_array[$flow_id]['VIEW_USER'] = $row['VIEW_USER'];
        $flow_array[$flow_id]['VIEW_DEPT'] = $row['VIEW_DEPT'];
        $flow_array[$flow_id]['VIEW_ROLE'] = $row['VIEW_ROLE'];
        $flow_array[$flow_id]['PRIV'] = get_flow_priv_cache( $flow_id );
        $flow_array[$flow_id]['MAX_PRCS_ID'] = get_max_prcs_id_cache( $flow_id );
        $new_user = $row['NEW_USER'];
        if ( isset( $new_user ) && trim( $new_user ) != "" )
        {
            $temp = explode( "|", $new_user );
            $flow_array[$flow_id]['FREE_FLOW_NEW_USER'] = $temp[0];
            $flow_array[$flow_id]['FREE_FLOW_NEW_DEPT'] = $temp[1];
            $flow_array[$flow_id]['FREE_FLOW_NEW_PRIV'] = $temp[2];
        }
        else
        {
            $flow_array[$flow_id]['FREE_FLOW_NEW_USER'] = "";
            $flow_array[$flow_id]['FREE_FLOW_NEW_DEPT'] = "";
            $flow_array[$flow_id]['FREE_FLOW_NEW_PRIV'] = "";
        }
    }
    $key = "W_FLOW";
    ( $key, $flow_array );
}

function get_max_prcs_id_cache( $flow_id )
{
    $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
    $select_exprs = "MAX(PRCS_ID) AS M_PRCS_ID";
    $table_references = "FLOW_PROCESS";
    $where_definition = $OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_ID", EXPR_OP_IS, $flow_id, FIELD_TYPE_INT );
    $sql = $OBJ_SQL_SYNTAX->getQuerySQL( 0, 0, $select_exprs, $table_references, $where_definition );
    $r_cursor = exequery( ( ), $sql, TRUE );
    if ( $row = mysql_fetch_array( $r_cursor ) )
    {
        return $row['M_PRCS_ID'];
    }
    return 0;
}

function get_flow_priv_cache( $flow_id )
{
    $r_connection = ( );
    $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
    $arr_priv = array( );
    $select_exprs = $OBJ_SQL_SYNTAX->getSelectExprs( "PRIV_TYPE, PRIV_SCOPE, USER, DEPT, ROLE" );
    $where_definition = $OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_ID", EXPR_OP_IS, $flow_id, FIELD_TYPE_INT );
    $order_definition = $OBJ_SQL_SYNTAX->getOrderByDefinition( "PRIV_TYPE", "ASC" );
    $sql = $OBJ_SQL_SYNTAX->getQuerySQL( 0, 0, $select_exprs, "flow_priv", $where_definition, $order_definition );
    $r_cursor = exequery( $r_connection, $sql, TRUE );
    while ( $row = mysql_fetch_array( $r_cursor ) )
    {
        $priv_type = $row['PRIV_TYPE'];
        $priv_scope = $row['PRIV_SCOPE'];
        $user = td_trim( getuseridbyuid( $row['USER'] ) );
        $dept = td_trim( $row['DEPT'] );
        $role = td_trim( $row['ROLE'] );
        if ( !isset( $arr_priv[$priv_type] ) || $arr_priv[$priv_type] == NULL )
        {
            $arr_priv[$priv_type] = array( );
        }
        if ( !isset( $arr_priv[$priv_type][$priv_scope] ) || $arr_priv[$priv_type][$priv_scope] == NULL )
        {
            if ( $user != "" )
            {
                $arr_priv[$priv_type][$priv_scope]['USER'] = $user;
            }
            if ( $dept != "" )
            {
                $arr_priv[$priv_type][$priv_scope]['DEPT'] = $dept;
            }
            if ( $role != "" )
            {
                $arr_priv[$priv_type][$priv_scope]['ROLE'] = $role;
            }
        }
        else
        {
            if ( $user != "" )
            {
                $str_user = $arr_priv[$priv_type][$priv_scope]['USER'];
                if ( $str_user != NULL && $str_user != "" )
                {
                    $str_user = $str_user.",".$user;
                    $str_user = implode( ",", array_unique( explode( ",", $str_user ) ) );
                }
                else
                {
                    $str_user = $user;
                }
                $arr_priv[$priv_type][$priv_scope]['USER'] = $str_user;
            }
            if ( $dept != "" )
            {
                $str_dept = $arr_priv[$priv_type][$priv_scope]['DEPT'];
                if ( $str_dept != NULL && $str_dept != "" )
                {
                    $str_dept = $str_dept.",".$dept;
                    $str_dept = implode( ",", array_unique( explode( ",", $str_dept ) ) );
                }
                else
                {
                    $str_dept = $dept;
                }
                $arr_priv[$priv_type][$priv_scope]['DEPT'] = $str_dept;
            }
            if ( $role != "" )
            {
                $str_role = $arr_priv[$priv_type][$priv_scope]['ROLE'];
                if ( $str_role != NULL && $str_role != "" )
                {
                    $str_role = $str_role.",".$role;
                    $str_role = implode( ",", array_unique( explode( ",", $str_role ) ) );
                }
                else
                {
                    $str_role = $role;
                }
                $arr_priv[$priv_type][$priv_scope]['ROLE'] = $str_role;
            }
        }
    }
    return $arr_priv;
}

function cache_flow_prcs( $flow_id )
{
    $r_connection = ( );
    $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
    $select_exprs = $OBJ_SQL_SYNTAX->getSelectExprs( " ID,\r\n                                                        FLOW_ID,\r\n                                                        PRCS_ID,\r\n                                                        PRCS_TYPE,\r\n                                                        PRCS_NAME,\r\n                                                        PRCS_TO,\r\n                                                        PRCS_IN,\r\n                                                        PRCS_OUT,\r\n                                                        PRCS_IN_SET,\r\n                                                        PRCS_OUT_SET,\r\n                                                        PRCS_USER,\r\n                                                        PRCS_DEPT,\r\n                                                        PRCS_PRIV,\r\n                                                        PRCS_ITEM,\r\n                                                        HIDDEN_ITEM,\r\n                                                        CONDITION_DESC,\r\n                                                        FEEDBACK,\r\n                                                        AUTO_TYPE,\r\n                                                        AUTO_USER_OP,\r\n                                                        AUTO_USER,\r\n                                                        AUTO_BASE_USER,\r\n                                                        USER_FILTER,\r\n                                                        TIME_OUT,\r\n                                                        TIME_OUT_MODIFY,            \r\n                                                        TIME_OUT_ATTEND,\r\n                                                        TIME_OUT_TYPE,\r\n                                                        SIGNLOOK,\r\n                                                        TOP_DEFAULT,\r\n                                                        USER_LOCK,\r\n                                                        MAIL_TO,\r\n                                                        SYNC_DEAL,\r\n                                                        TURN_PRIV,\r\n                                                        GATHER_NODE,\r\n                                                        ALLOW_BACK,\r\n                                                        ATTACH_PRIV,\r\n                                                        CONTROL_MODE,\r\n                                                        VIEW_PRIV,\r\n                                                        CHILD_FLOW,\r\n                                                        RELATION_IN,\r\n                                                        RELATION_OUT,\r\n                                                        SET_LEFT,\r\n                                                        SET_TOP,\r\n    \t\t\t\t\t\t\t\t\t\t\t\t\tSIGN_TYPE,\r\n                                                        REMIND_FLAG,\r\n                                                        FILEUPLOAD_PRIV,\r\n                                                        ATTACH_MACRO_MARK,\r\n                                                        PRCS_ITEM_AUTO" );
    $table_references = $OBJ_SQL_SYNTAX->getTableReferences( "flow_process" );
    $where_definition = $OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_ID", EXPR_OP_IS, $flow_id, FIELD_TYPE_INT );
    $sql = $OBJ_SQL_SYNTAX->getQuerySQL( 0, 0, $select_exprs, $table_references, $where_definition );
    $r_cursor = exequery( $r_connection, $sql, TRUE );
    $flow_prcs_array = array( );
    while ( $row = mysql_fetch_array( $r_cursor ) )
    {
        $flow_id = $row['FLOW_ID'];
        $prcs_id = $row['PRCS_ID'];
        if ( $flow_prcs_array[$prcs_id] == NULL )
        {
            $flow_prcs_array[$prcs_id] = array( );
            $flow_prcs_array[$prcs_id]['ID'] = $row['ID'];
            $flow_prcs_array[$prcs_id]['PRCS_TYPE'] = $row['PRCS_TYPE'];
            $flow_prcs_array[$prcs_id]['PRCS_NAME'] = $row['PRCS_NAME'];
            $flow_prcs_array[$prcs_id]['PRCS_TO'] = $row['PRCS_TO'];
            $flow_prcs_array[$prcs_id]['PRCS_IN'] = $row['PRCS_IN'];
            $flow_prcs_array[$prcs_id]['PRCS_OUT'] = $row['PRCS_OUT'];
            $flow_prcs_array[$prcs_id]['PRCS_IN_SET'] = $row['PRCS_IN_SET'];
            $flow_prcs_array[$prcs_id]['PRCS_OUT_SET'] = $row['PRCS_OUT_SET'];
            $flow_prcs_array[$prcs_id]['CONDITION_DESC'] = $row['CONDITION_DESC'];
            $flow_prcs_array[$prcs_id]['PRCS_ITEM'] = $row['PRCS_ITEM'];
            $flow_prcs_array[$prcs_id]['HIDDEN_ITEM'] = $row['HIDDEN_ITEM'];
            $flow_prcs_array[$prcs_id]['PRCS_USER'] = $row['PRCS_USER'];
            $flow_prcs_array[$prcs_id]['PRCS_DEPT'] = $row['PRCS_DEPT'];
            $flow_prcs_array[$prcs_id]['PRCS_PRIV'] = $row['PRCS_PRIV'];
            $flow_prcs_array[$prcs_id]['FEEDBACK'] = $row['FEEDBACK'];
            $flow_prcs_array[$prcs_id]['AUTO_TYPE'] = $row['AUTO_TYPE'];
            $flow_prcs_array[$prcs_id]['AUTO_USER_OP'] = $row['AUTO_USER_OP'];
            $flow_prcs_array[$prcs_id]['AUTO_USER'] = $row['AUTO_USER'];
            $flow_prcs_array[$prcs_id]['AUTO_BASE_USER'] = $row['AUTO_BASE_USER'];
            $flow_prcs_array[$prcs_id]['USER_FILTER'] = $row['USER_FILTER'];
            $flow_prcs_array[$prcs_id]['TIME_OUT'] = $row['TIME_OUT'];
            $flow_prcs_array[$prcs_id]['TIME_OUT_MODIFY'] = $row['TIME_OUT_MODIFY'];
            $flow_prcs_array[$prcs_id]['TIME_OUT_ATTEND'] = $row['TIME_OUT_ATTEND'];
            $flow_prcs_array[$prcs_id]['TIME_OUT_TYPE'] = $row['TIME_OUT_TYPE'];
            $flow_prcs_array[$prcs_id]['SIGNLOOK'] = $row['SIGNLOOK'];
            $flow_prcs_array[$prcs_id]['TOP_DEFAULT'] = $row['TOP_DEFAULT'];
            $flow_prcs_array[$prcs_id]['USER_LOCK'] = $row['USER_LOCK'];
            $flow_prcs_array[$prcs_id]['MAIL_TO'] = $row['MAIL_TO'];
            $flow_prcs_array[$prcs_id]['SYNC_DEAL'] = $row['SYNC_DEAL'];
            $flow_prcs_array[$prcs_id]['TURN_PRIV'] = $row['TURN_PRIV'];
            $flow_prcs_array[$prcs_id]['GATHER_NODE'] = $row['GATHER_NODE'];
            $flow_prcs_array[$prcs_id]['ALLOW_BACK'] = $row['ALLOW_BACK'];
            $flow_prcs_array[$prcs_id]['ATTACH_PRIV'] = $row['ATTACH_PRIV'];
            $flow_prcs_array[$prcs_id]['GATHER_NODE'] = $row['GATHER_NODE'];
            $flow_prcs_array[$prcs_id]['ALLOW_BACK'] = $row['ALLOW_BACK'];
            $flow_prcs_array[$prcs_id]['ATTACH_PRIV'] = $row['ATTACH_PRIV'];
            $flow_prcs_array[$prcs_id]['CONTROL_MODE'] = $row['CONTROL_MODE'];
            $flow_prcs_array[$prcs_id]['VIEW_PRIV'] = $row['VIEW_PRIV'];
            $flow_prcs_array[$prcs_id]['CHILD_FLOW'] = $row['CHILD_FLOW'];
            $flow_prcs_array[$prcs_id]['RELATION_IN'] = $row['RELATION_IN'];
            $flow_prcs_array[$prcs_id]['RELATION_OUT'] = $row['RELATION_OUT'];
            $flow_prcs_array[$prcs_id]['SET_LEFT'] = $row['SET_LEFT'];
            $flow_prcs_array[$prcs_id]['SET_TOP'] = $row['SET_TOP'];
            $flow_prcs_array[$prcs_id]['SIGN_TYPE'] = $row['SIGN_TYPE'];
            $flow_prcs_array[$prcs_id]['REMIND_FLAG'] = $row['REMIND_FLAG'];
            $flow_prcs_array[$prcs_id]['FILEUPLOAD_PRIV'] = $row['FILEUPLOAD_PRIV'];
            $flow_prcs_array[$prcs_id]['ATTACH_MACRO_MARK'] = $row['ATTACH_MACRO_MARK'];
            $flow_prcs_array[$prcs_id]['PRCS_ITEM_AUTO'] = $row['PRCS_ITEM_AUTO'];
        }
    }
    $key = "W_PROCESS_".$flow_id;
    ( $key, $flow_prcs_array );
}

function cache_flow_type_list( $category_id )
{
    $r_connection = ( );
    $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
    $select_exprs = "FLOW_ID,FLOW_NAME,FLOW_TYPE,NEW_USER,FREE_OTHER, DEPT_ID";
    $where_definition = $OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_SORT", EXPR_OP_IS, $category_id, FIELD_TYPE_INT );
    $order_definition = $OBJ_SQL_SYNTAX->getOrderByDefinition( "FLOW_NO", "ASC" );
    $sql = $OBJ_SQL_SYNTAX->getQuerySQL( 0, 0, $select_exprs, "flow_type", $where_definition, $order_definition );
    $r_cursor = exequery( $r_connection, $sql, TRUE );
    $arr_list = array( );
    while ( $row = mysql_fetch_array( $r_cursor ) )
    {
        $id = $row['FLOW_ID'];
        $arr_list[$id]['FLOW_NAME'] = $row['FLOW_NAME'];
        $arr_list[$id]['FLOW_TYPE'] = $row['FLOW_TYPE'];
        $arr_list[$id]['NEW_USER'] = $row['NEW_USER'];
        $arr_list[$id]['FREE_OTHER'] = $row['FREE_OTHER'];
        $arr_list[$id]['DEPT_ID'] = $row['DEPT_ID'];
    }
    $key = "W_WORK_LIST_".$category_id;
    ( $key, $arr_list );
}

function cache_flow_category( )
{
    $arr_categorys = getcategorylist( );
    ( "W_CATEGORY_LIST", $arr_categorys );
}

function getCategoryList( $parent_id = 0, $level = 1, $arr_category = NULL )
{
    if ( !isset( $arr_category ) || $arr_category == NULL )
    {
        $arr_category = array( );
    }
    $r_connection = ( );
    $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
    $select_exprs = "SORT_ID, SORT_NAME, DEPT_ID, SORT_PARENT, HAVE_CHILD ";
    $where_definition = $OBJ_SQL_SYNTAX->getConditionExpr( "SORT_PARENT", EXPR_OP_IS, $parent_id, FIELD_TYPE_INT );
    $order_definition = $OBJ_SQL_SYNTAX->getOrderByDefinition( "SORT_NO", "ASC" );
    $sql = $OBJ_SQL_SYNTAX->getQuerySQL( 0, 0, $select_exprs, "flow_sort", $where_definition, $order_definition );
    $r_cursor = exequery( $r_connection, $sql, TRUE );
    while ( $row = mysql_fetch_array( $r_cursor ) )
    {
        $id = $row['SORT_ID'];
        $arr_category[$id]['NAME'] = $row['SORT_NAME'];
        $arr_category[$id]['DEPT_ID'] = $row['DEPT_ID'];
        $arr_category[$id]['SORT_PARENT'] = $row['SORT_PARENT'];
        $arr_category[$id]['HAVE_CHILD'] = $row['HAVE_CHILD'];
        $arr_category[$id]['LEVEL'] = $level;
        if ( $row['HAVE_CHILD'] == "1" )
        {
            $arr_category = getcategorylist( $id, $level + 1, $arr_category );
        }
    }
    return $arr_category;
}

function cache_work_form( $form_id )
{
    $r_connection = ( );
    $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
    $select_exprs = $OBJ_SQL_SYNTAX->getSelectExprs( "FORM_ID,PRINT_MODEL,ITEM_MAX" );
    if ( isset( $form_id ) && $form_id != NULL && $form_id != "" )
    {
        $where_definition = $OBJ_SQL_SYNTAX->getConditionExpr( "FORM)ID", EXPR_OP_IS, $form_id, FIELD_TYPE_INT );
    }
    $sql = $OBJ_SQL_SYNTAX->getQuerySQL( 0, 0, $select_exprs, "flow_form_type", $where_definition );
    $r_cursor = exequery( $r_connection, $sql, TRUE );
    while ( $row = mysql_fetch_array( $r_cursor ) )
    {
        $form_id = $ROW['FORM_ID'];
        $print_model = $ROW['PRINT_MODEL'];
        $item_max = $ROW['ITEM_MAX'];
    }
}

include_once( "inc/db/dbms.php" );
?>
