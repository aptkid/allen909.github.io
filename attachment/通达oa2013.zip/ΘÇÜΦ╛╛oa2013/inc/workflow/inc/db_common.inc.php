<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
function getFieldValue( $table_name, $field_name, $where_definition = NULL )
{
    $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
    $select_exprs = $field_name;
    $table_references = $table_name;
    if ( $where_definition != NULL && trim( $where_definition ) != "" )
    {
        $sql = $OBJ_SQL_SYNTAX->getQuerySQL( 0, 0, $select_exprs, $table_references, $where_definition );
    }
    else
    {
        $sql = $OBJ_SQL_SYNTAX->getQuerySQL( 0, 0, $select_exprs, $table_references );
    }
    $result = "";
    $r_cursor = exequery( ( ), $sql );
    if ( $row = mysql_fetch_array( $r_cursor ) )
    {
        $result = $row[$field_name];
    }
    return $result;
}

function getCountValue( $table_name, $key, $where_definition = NULL )
{
    $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
    $select_exprs = "COUNT(".$key.") as count_number";
    $table_references = $table_name;
    if ( $where_definition != NULL && trim( $where_definition ) != "" )
    {
        $sql = $OBJ_SQL_SYNTAX->getQuerySQL( 0, 0, $select_exprs, $table_references, $where_definition );
    }
    else
    {
        $sql = $OBJ_SQL_SYNTAX->getQuerySQL( 0, 0, $select_exprs, $table_references );
    }
    $result = 0;
    $r_cursor = exequery( ( ), $sql );
    if ( $row = mysql_fetch_array( $r_cursor ) )
    {
        $result = $row['count_number'];
    }
    return $result;
}

function getMaxValue( $table_name, $key, $where_definition = NULL )
{
    $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
    $select_exprs = "MAX(".$key.") as max_number";
    $table_references = $table_name;
    if ( $where_definition != NULL && trim( $where_definition ) != "" )
    {
        $sql = $OBJ_SQL_SYNTAX->getQuerySQL( 0, 0, $select_exprs, $table_references, $where_definition );
    }
    else
    {
        $sql = $OBJ_SQL_SYNTAX->getQuerySQL( 0, 0, $select_exprs, $table_references );
    }
    $result = 0;
    $r_cursor = exequery( ( ), $sql );
    if ( $row = mysql_fetch_array( $r_cursor ) )
    {
        $result = $row['max_number'];
    }
    if ( $result == NULL || $result == "" )
    {
        $result = 0;
    }
    return $result;
}

?>
