<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class WorkSysPara
{

    private $flow_remind_before_time;
    private $flow_remind_before_unit;
    private $flow_remind_after_time;
    private $flow_remind_after_unit;
    private $seal_from;
    private $flow_action_notify = 0;
    private $flow_action_email = 0;
    private $flow_action_save_as = 0;
    private $flow_action_save = 0;
    private $user_sys_email = 0;
    private $sys_email;
    private $smtp_server;
    private $smtp_port;
    private $smtp_ssl = 0;
    private $email_user;
    private $email_pass;
    private $smtp_pass;

    public function _get( $property_name )
    {
        $property_name = strtolower( $property_name );
        if ( isset( $this->$property_name ) )
        {
            return $this->$property_name;
        }
    }

    public function _set( $property_name, $value )
    {
        $property_name = strtolower( $property_name );
        $this->$property_name = $value;
    }

    public function update( )
    {
        $arr_sys_email = array( );
        $arr_sys_email['USE_SYS_EMAIL'] = $this->user_sys_email;
        $arr_sys_email['SYS_EMAIL'] = $this->sys_email;
        $arr_sys_email['SMTP_SERVER'] = $this->smtp_server;
        $arr_sys_email['SMTP_PORT'] = $this->smtp_port;
        $arr_sys_email['EMAIL_USER'] = $this->email_user;
        $arr_sys_email['EMAIL_PASS'] = $this->email_pass;
        if ( $this->smtp_ssl == 1 )
        {
            $arr_sys_email['SMTP_SSL'] = "ssl";
        }
        else
        {
            $arr_sys_email['SMTP_SSL'] = "";
        }
        if ( $this->smtp_pass == 1 )
        {
            $arr_sys_email['SMTP_PASS'] = "yes";
        }
        else
        {
            $arr_sys_email['SMTP_PASS'] = "no";
        }
        $flow_action = "";
        if ( $this->flow_action_notify == 1 )
        {
            $flow_action .= "1,";
        }
        if ( $this->flow_action_email == 1 )
        {
            $flow_action .= "2,";
        }
        if ( $this->flow_action_save_as == 1 )
        {
            $flow_action .= "3,";
        }
        if ( $this->flow_action_save == 1 )
        {
            $flow_action .= "4,";
        }
        $arr_para = array( "FLOW_REMIND_BEFORE" => $this->flow_remind_before_time.$this->flow_remind_before_unit, "FLOW_REMIND_AFTER" => $this->flow_remind_after_time.$this->flow_remind_after_unit, "FLOW_ACTION" => $flow_action, "SYS_EMAIL" => base64_encode( serialize( $arr_sys_email ) ), "SEAL_FROM" => $this->seal_from );
        set_sys_para( $arr_para );
    }

    public function fetch( )
    {
        $arr_para = get_sys_para( "FLOW_REMIND_BEFORE,FLOW_REMIND_AFTER,SEAL_FROM,FLOW_ACTION,SYS_EMAIL" );
        while ( list( $para_name, $para_value ) = each( &$arr_para ) )
        {
            $$para_name = $para_value;
        }
        if ( isset( $FLOW_REMIND_BEFORE ) && $FLOW_REMIND_BEFORE != "" )
        {
            $this->flow_remind_before_time = substr( $FLOW_REMIND_BEFORE, 0, -1 );
            $this->flow_remind_before_unit = substr( $FLOW_REMIND_BEFORE, -1, 1 );
        }
        else
        {
            $this->flow_remind_before_time = "";
            $this->flow_remind_before_unit = "";
        }
        if ( isset( $FLOW_REMIND_AFTER ) && $FLOW_REMIND_AFTER != "" )
        {
            $this->flow_remind_after_time = substr( $FLOW_REMIND_AFTER, 0, -1 );
            $this->flow_remind_after_unit = substr( $FLOW_REMIND_AFTER, -1, 1 );
        }
        else
        {
            $this->flow_remind_after_time = "";
            $this->flow_remind_after_unit = "";
        }
        $this->seal_from = $SEAL_FROM;
        if ( find_id( $FLOW_ACTION, "1" ) )
        {
            $this->flow_action_notify = 1;
        }
        else
        {
            $this->flow_action_notify = 0;
        }
        if ( find_id( $FLOW_ACTION, "2" ) )
        {
            $this->flow_action_email = 1;
        }
        else
        {
            $this->flow_action_email = 0;
        }
        if ( find_id( $FLOW_ACTION, "3" ) )
        {
            $this->flow_action_save_as = 1;
        }
        else
        {
            $this->flow_action_save_as = 0;
        }
        if ( find_id( $FLOW_ACTION, "4" ) )
        {
            $this->flow_action_save = 1;
        }
        else
        {
            $this->flow_action_save = 0;
        }
        $arr_sys_email = unserialize( base64_decode( $SYS_EMAIL ) );
        if ( $arr_sys_email['USE_SYS_EMAIL'] == "1" )
        {
            $this->user_sys_email = 1;
        }
        else
        {
            $this->user_sys_email = 0;
        }
        $this->sys_email = $arr_sys_email['SYS_EMAIL'];
        $this->smtp_server = $arr_sys_email['SMTP_SERVER'];
        $this->smtp_port = $arr_sys_email['SMTP_PORT'];
        $this->email_user = $arr_sys_email['EMAIL_USER'];
        $this->email_pass = $arr_sys_email['EMAIL_PASS'];
        if ( $arr_sys_email['SMTP_SSL'] == "ssl" )
        {
            $this->smtp_ssl = 1;
        }
        else
        {
            $this->smtp_ssl = 0;
        }
        if ( $arr_sys_email['SMTP_PASS'] == "yes" )
        {
            $this->smtp_pass = 1;
        }
        else
        {
            $this->smtp_pass = 0;
        }
    }

}

?>
