<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
function format_date_to_king_str( $timestamp, $has_timer = TRUE )
{
    $days = ( strtotime( date( "Y-m-d", time( ) ) ) - strtotime( date( "Y-m-d", $timestamp ) ) ) / 86400;
    if ( $days == 0 )
    {
        $date_str = "���� ";
    }
    else if ( $days == 1 )
    {
        $date_str = "���� ";
    }
    else if ( $days == 2 )
    {
        $date_str = "ǰ�� ";
    }
    else if ( date( "Y-m", $timestamp ) == date( "Y-m", time( ) ) )
    {
        $date_str = "���� ".date( "d�� ", $timestamp );
    }
    else if ( date( "Y", $timestamp ) == date( "Y", time( ) ) )
    {
        $date_str = "���� ".date( "m-d ", $timestamp );
    }
    else
    {
        $date_str = date( "Y-m-d ", $timestamp );
    }
    if ( $has_timer )
    {
        $time_str = date( "H:i:s", $timestamp );
    }
    else
    {
        $time_str = "";
    }
    return $date_str.$time_str;
}

function format_interval_to_king_str( $interval )
{
    $str = "";
    if ( $interval <= 0 )
    {
        return $str;
    }
    if ( 86400 < $interval )
    {
        $str .= floor( $interval / 86400 )."��";
        $other = $interval % 86400;
        if ( 3600 <= $other )
        {
            $str .= floor( $other / 3600 )."Сʱ";
            return $str;
        }
    }
    $str .= floor( $interval / 3600 )."Сʱ";
    $other = $interval % 3600;
    if ( 60 <= $other )
    {
        $str .= floor( $other / 60 )."��";
        return $str;
    }
    if ( 0 < $other && $other < 60 )
    {
        $str .= floor( $other )."��";
    }
    return $str;
}

function getWorkSchedule( $user_id )
{
    $select_exprs = ( "attend_config.GENERAL,\r\n\t\t\t\t\t\t\t\t\t\t\t\t attend_config.DUTY_TIME1,\r\n\t\t\t\t\t\t\t\t\t\t\t\t attend_config.DUTY_TYPE1,\r\n\t\t\t\t\t\t\t\t\t\t\t\t attend_config.DUTY_TIME2,\r\n\t\t\t\t\t\t\t\t\t\t\t\t attend_config.DUTY_TYPE2,\r\n\t\t\t\t\t\t\t\t\t\t\t\t attend_config.DUTY_TIME3,\r\n\t\t\t\t\t\t\t\t\t\t\t\t attend_config.DUTY_TYPE3,\r\n\t\t\t\t\t\t\t\t\t\t\t\t attend_config.DUTY_TIME4,\r\n\t\t\t\t\t\t\t\t\t\t\t\t attend_config.DUTY_TYPE4,\r\n\t\t\t\t\t\t\t\t\t\t\t\t attend_config.DUTY_TIME5,\r\n\t\t\t\t\t\t\t\t\t\t\t\t attend_config.DUTY_TYPE5,\r\n\t\t\t\t\t\t\t\t\t\t\t\t attend_config.DUTY_TIME6,\r\n\t\t\t\t\t\t\t\t\t\t\t\t attend_config.DUTY_TYPE6" );
    $sub_sql = ( 0, 0, ( "DUTY_TYPE" ), "USER_EXT", ( "USER_ID", EXPR_OP_IS, $user_id, FIELD_TYPE_CHAR ) );
    $sql = ( 0, 0, $select_exprs, "attend_config", ( "DUTY_TYPE", EXPR_OP_IS, "(".$sub_sql.")", FIELD_TYPE_EXPR ) );
    $count = 0;
    $work_schedule[$count]['from'] = "00:00:00";
    $work_schedule[$count]['to'] = NULL;
    $r_cursor = exequery( ( ), $sql, TRUE );
    if ( $row = mysql_fetch_array( $r_cursor ) )
    {
        $schedule['holiday'] = $row['GENERAL'];
        if ( $row['DUTY_TIME1'] != "" )
        {
            $work_schedule[$count]['from'] = $row['DUTY_TIME1'];
        }
        if ( $row['DUTY_TIME2'] != "" )
        {
            $work_schedule[$count]['to'] = $row['DUTY_TIME2'];
        }
        if ( $row['DUTY_TIME3'] != "" )
        {
            if ( $work_schedule[$count]['to'] != NULL )
            {
                ++$count;
            }
            if ( $work_schedule[$count]['from'] == NULL )
            {
                $work_schedule[$count]['from'] = $row['DUTY_TIME3'];
            }
        }
        if ( $row['DUTY_TIME4'] != "" )
        {
            $work_schedule[$count]['to'] = $row['DUTY_TIME4'];
        }
        if ( $row['DUTY_TIME5'] != "" )
        {
            if ( $work_schedule[$count]['to'] != NULL )
            {
                ++$count;
            }
            if ( $work_schedule[$count]['from'] == NULL )
            {
                $work_schedule[$count]['from'] = $row['DUTY_TIME5'];
            }
        }
        if ( $row['DUTY_TIME6'] != "" )
        {
            $work_schedule[$count]['to'] = $row['DUTY_TIME6'];
        }
    }
    if ( $work_schedule[$count] == NULL )
    {
        $work_schedule[$count]['to'] = "24:00:00";
    }
    $schedule['work'] = $work_schedule;
    return $schedule;
}

function calWorkTime( $from, $to, $schedule )
{
    $from_date = date( "Y-m-d", $from );
    $from_time = date( "H:i:s", $from );
    $from_w = date( "w", $from );
    $to_date = date( "Y-m-d", $to );
    $to_time = date( "H:i:s", $to );
    $to_w = date( "w", $to );
    if ( $from_date == $to_date )
    {
        if ( strpos( $schedule['holiday'], $from_w ) !== FALSE )
        {
            return 0;
        }
        return getoverworktime( $from_time, $schedule['work'] ) - getoverworktime( $to_time, $schedule['work'] );
    }
    $diff = 0;
    if ( strpos( $schedule['holiday'], $from_w ) === FALSE )
    {
        $diff += getoverworktime( $from_time, $schedule['work'] );
    }
    if ( strpos( $schedule['holiday'], $to_w ) === FALSE )
    {
        $diff += getpassworktime( $to_time, $schedule['work'] );
    }
    $next_day = date( "Y-m-d", strtotime( "+1 day", strtotime( $from_date ) ) );
    $prev_day = date( "Y-m-d", strtotime( "-1 day", strtotime( $to_date ) ) );
    $work_days = getworkdays( $next_day, $prev_day, $schedule['holiday'] );
    $work_time_of_every_days = getoverworktime( "00:00:00", $schedule['work'] );
    $diff += $work_days * $work_time_of_every_days;
    return $diff;
}

function getOverWorkTime( $cur_time, $work_schedule )
{
    $cur_time = strtotime( $cur_time );
    $count = count( $work_schedule );
    $diff = 0;
    $i = 0;
    for ( ; $i < $count; ++$i )
    {
        $from_time = strtotime( $work_schedule[$i]['from'] );
        if ( $work_schedule[$i]['to'] != "24:00:00" )
        {
            $to_time = strtotime( $work_schedule[$i]['to'] );
        }
        else
        {
            $to_time = strtotime( "23:59:59" ) + 1;
        }
        if ( $cur_time < $from_time )
        {
            $diff += $to_time - $from_time;
        }
        else if ( $cur_time <= $to_time )
        {
            $diff += $to_time - $cur_time;
        }
    }
    return $diff;
}

function getPassWorkTime( $cur_time, $work_schedule )
{
    $cur_time = strtotime( $cur_time );
    $count = count( $work_schedule );
    $diff = 0;
    $i = 0;
    for ( ; $i < $count; ++$i )
    {
        $from_time = strtotime( $work_schedule[$i]['from'] );
        if ( $work_schedule[$i]['to'] != "24:00:00" )
        {
            $to_time = strtotime( $work_schedule[$i]['to'] );
        }
        else
        {
            $to_time = strtotime( "23:59:59" ) + 1;
        }
        if ( $to_time < $cur_time )
        {
            $diff += $to_time - $from_time;
        }
        else if ( $from_time <= $cur_time )
        {
            $diff += $cur_time - $from_time;
        }
    }
    return $diff;
}

function getWorkDays( $from_date, $to_date, $holidays )
{
    if ( isset( $holidays ) && $holidays != "" )
    {
        $arr_holiday = explode( ",", $holidays );
        $work_day_of_week = 7 - count( $arr_holiday );
    }
    else
    {
        $work_day_of_week = 7;
    }
    $start_date_time = strtotime( $from_date );
    $end_date_time = strtotime( $to_date );
    $total_day = ( $end_date_time - $start_date_time ) / 86400 + 1;
    $count_week = floor( $total_day / 7 );
    $over_days = $total_day % 7;
    $total_work_day = $count_week * $work_day_of_week;
    $i = 0;
    for ( ; $i < $over_days; ++$i )
    {
        if ( strpos( $holidays, date( "w", $start_date_time ) ) === FALSE )
        {
            ++$total_work_day;
        }
        $start_date_time += 86400;
    }
    return $total_work_day;
}

function str_remove_dup( $str, $separator = "," )
{
    return td_trim( implode( $separator, array_unique( explode( $separator, td_trim( $str ) ) ) ) );
}

function str_merge( $str1, $str2, $is_unique = TRUE, $separator = "," )
{
    $str1 = td_trim( $str1, $separator." \t\n\r\x00\x0B" );
    $str2 = td_trim( $str2, $separator." \t\n\r\x00\x0B" );
    if ( $str1 == "" || $str2 == "" )
    {
        return $str1.$str2;
    }
    if ( $is_unique )
    {
        return $str1.$separator.$str2;
    }
    $str = $str1.$separator.$str2;
    return implode( $separator, array_unique( explode( $separator, $str ) ) );
}

function strremove( $str, $str1, $separator = "," )
{
    $str_arr = explode( $separator, $str );
    $str1_arr = explode( $separator, $str1 );
    $result = array( );
    foreach ( $str_arr as $str_unit )
    {
        if ( in_array( $str_unit, $str1_arr ) )
        {
            $result[] = $str_unit;
        }
    }
    return implode( $separator, $result );
}

function getSelfDept( $parent_dept_id, $is_self = 1 )
{
    if ( $parent_dept_id == 0 )
    {
        return $parent_dept_id;
    }
    $arr_dept = ( "SYS_DEPARTMENT" );
    $dept_str = "";
    $level = 0;
    foreach ( $arr_dept as $dept_id => $dept_info )
    {
        if ( $level == 0 )
        {
            if ( $parent_dept_id == $dept_id )
            {
                $level = $dept_info['DEPT_LEVEL'];
                if ( $is_self == 1 )
                {
                    $dept_str .= $dept_id.",";
                }
            }
        }
        else if ( $level < $dept_info['DEPT_LEVEL'] )
        {
            $dept_str .= $dept_id.",";
        }
    }
    if ( $dept_str != "" )
    {
        $dept_str = substr( $dept_str, 0, -1 );
        return $dept_str;
    }
    $dept_str = 0;
    return $dept_str;
}

function get_user_ids_by_select( $select_type, $select_ids, $is_array = FALSE )
{
    $user_ids = "";
    if ( $select_type == "user" )
    {
        $select_ids0 = explode( ",", trim( $select_ids ) );
        $user_ids = implode( $select_ids0, "','" );
    }
    else
    {
        do
        {
            if ( $select_type == "role" )
            {
                $select_ids = td_trim( $select_ids );
                if ( $select_ids != "" )
                {
                    $sql = "SELECT USER_ID FROM USER WHERE USER_PRIV IN (".$select_ids.") OR USER_PRIV_OTHER IN (".$select_ids.") ";
                    $cursor = exequery( ( ), $sql );
                    while ( $row = mysql_fetch_array( $cursor ) )
                    {
                        $user_ids .= $row['USER_ID']."','";
                    }
                }
            }
            if ( $select_type == "dept" )
            {
                $select_ids = td_trim( $select_ids );
                if ( $select_ids != "" )
                {
                    $sql = "SELECT USER_ID FROM USER WHERE DEPT_ID IN (".$select_ids.") OR DEPT_ID_OTHER IN (".$select_ids.") ";
                    $cursor = exequery( ( ), $sql );
                }
            }
        } while ( 0 );
        while ( $row = mysql_fetch_array( $cursor ) )
        {
            $user_ids .= $row['USER_ID']."','";
            break;
        }
    }
    $user_ids = td_trim( $user_ids );
    $user_ids = substr( $user_ids, 0, strlen( $user_ids ) - 3 );
    return $user_ids;
}

function get_first_user_ids_by_select( $select_type, $select_ids )
{
    $user_ids = "";
    if ( $select_type == "user" )
    {
        $user_ids = td_trim( $select_ids );
        if ( $user_ids != "" )
        {
            $users_info = explode( ",", $user_ids );
            return $users_info[0];
        }
    }
    if ( $select_type == "role" )
    {
        $select_ids = td_trim( $select_ids );
        if ( $select_ids != "" )
        {
            $sql = "SELECT USER_ID FROM USER WHERE USER_PRIV IN (".$select_ids.") ";
            $cursor = exequery( ( ), $sql );
            return $row['USER_ID'];
        }
    }
    if ( ( $row = mysql_fetch_array( $cursor ) ) && $select_type == "dept" )
    {
        $select_ids = td_trim( $select_ids );
        if ( $select_ids != "" )
        {
            if ( $select_ids == "ALL_DEPT" )
            {
                $sql = "SELECT USER_ID FROM USER ";
            }
            else
            {
                $sql = "SELECT USER_ID FROM USER WHERE DEPT_ID IN (".$select_ids.") ";
            }
            $cursor = exequery( ( ), $sql );
            if ( $row = mysql_fetch_array( $cursor ) )
            {
                return $row['USER_ID'];
            }
        }
    }
    return "";
}

function getPrivName( $priv_ids )
{
    $cache_priv = ( "C_PRIV" );
    $priv_ids = td_trim( $priv_ids );
    $priv_name = "";
    if ( $priv_ids != "" )
    {
        $arr_priv = explode( ",", $priv_ids );
        foreach ( $arr_priv as $priv_id )
        {
            $priv_name .= $cache_priv[$priv_id]['PRIV_NAME'].",";
        }
    }
    return td_trim( $priv_name );
}

function getDeptName( $dept_id, $is_long = FALSE )
{
    $cache_dept = ( "SYS_DEPARTMENT" );
    $dept_name = "";
    if ( $is_long )
    {
        $dept_name = $cache_dept[$dept_id]['DEPT_NAME'];
    }
    return $dept_name;
}

?>
