<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
function getFlowDesignTreeArray( $parent_id, $isAdmin, $priv_dept, $json_url, $base_url, $target, $folder_pic, $flow_pic )
{
    $arr_category = ( "W_CATEGORY_LIST" );
    $arr_list = array( );
    $level = 0;
    if ( $parent_id == 0 )
    {
        $start_flag = TRUE;
    }
    else
    {
        $start_flag = FALSE;
    }
    foreach ( $arr_category as $key => $value )
    {
        if ( !$start_flag && $key != $parent_id )
        {
            continue;
        }
        else if ( !$start_flag && $key == $parent_id )
        {
            if ( $value['HAVE_CHILD'] != "1" )
            {
                $start_flag = TRUE;
                $level = $value['LEVEL'];
            }
        }
        else if ( $start_flag )
        {
            if ( $value['LEVEL'] == $level + 1 )
            {
                $dept_id = $value['DEPT_ID'];
                if ( !$isAdmin && $dept_id != 0 && $dept_id != $priv_dept && !is_dept_parent( $priv_dept, $dept_id ) )
                {
                }
                else
                {
                    $isLazy = haschildofcategory( $key, $isAdmin, $priv_dept );
                    $json = $json_url."?SORT_ID=".$key."&rand=".mt_rand( );
                    $arr_list[] = array( "title" => td_iconv( htmlspecialchars( $value['NAME'] ), MYOA_CHARSET, "utf-8" ), "isFolder" => TRUE, "isLazy" => $isLazy, "key" => "SORT_".$key, "icon" => $folder_pic, "json" => td_iconv( $json, MYOA_CHARSET, "utf-8" ), "url" => "", "target" => $target );
                }
            }
            if ( $start_flag && $level + 1 < $value['LEVEL'] )
            {
                break;
            }
        }
    }
    $work_list = ( "W_WORK_LIST_".$parent_id );
    if ( $work_list != NULL )
    {
        foreach ( $work_list as $key => $value )
        {
            $dept_id = $value['DEPT_ID'];
            if ( !$isAdmin && $dept_id != $priv_dept && !is_dept_parent( $priv_dept, $dept_id ) )
            {
            }
            else
            {
                $url = $base_url."?FLOW_ID=".$key."&SORT_ID=".$parent_id;
                $arr_list[] = array( "title" => td_iconv( htmlspecialchars( $value['FLOW_NAME'] ), MYOA_CHARSET, "utf-8" ), "isFolder" => FALSE, "isLazy" => FALSE, "key" => "FLOW_".$key, "url" => td_iconv( $url, MYOA_CHARSET, "utf-8" ), "icon" => $flow_pic, "target" => $target );
            }
        }
    }
    return $arr_list;
}

function hasChildOfCategory( $sort_id, $isAdmin, $priv_dept )
{
    if ( hasflowchildofcategory( $sort_id, $isAdmin, $priv_dept ) )
    {
        return TRUE;
    }
    return hascategorychildofcategory( $sort_id, $isAdmin, $priv_dept );
}

function hasCategoryChildOfCategory( $sort_id, $isAdmin, $priv_dept )
{
    $arr_category = ( "W_CATEGORY_LIST" );
    if ( $isAdmin )
    {
        if ( $arr_category[$sort_id]['HAVE_CHILD'] == "1" )
        {
            return TRUE;
        }
        return FALSE;
    }
    $level = 0;
    if ( $sort_id == 0 )
    {
        $start_flag = TRUE;
    }
    else
    {
        $start_flag = FALSE;
    }
    foreach ( $arr_category as $key => $value )
    {
        if ( !$start_flag && $key != $sort_id )
        {
            if ( !$start_flag && $key == $sort_id )
            {
                if ( $value['HAVE_CHILD'] != "1" )
                {
                    return FALSE;
                }
                $start_flag = TRUE;
                $level = $value['LEVEL'];
            }
            if ( $start_flag )
            {
                if ( $value['LEVEL'] == $level + 1 )
                {
                    $dept_id = $value['DEPT_ID'];
                    if ( $dept_id != 0 && $dept_id != $priv_dept && !is_dept_parent( $priv_dept, $dept_id ) )
                    {
                        return TRUE;
                    }
                    if ( !$start_flag || !( $value['LEVEL'] != $level + 1 ) || $parent_id == 0 )
                    {
                        return FALSE;
                        break;
                    }
                }
            }
        }
        return FALSE;
    }

function hasFlowChildOfCategory( $sort_id, $isAdmin, $priv_dept )
{
    $work_list = ( "W_WORK_LIST_".$sort_id );
    if ( $work_list == NULL )
    {
        return FALSE;
    }
    if ( $isAdmin )
    {
        return TRUE;
    }
    foreach ( $work_list as $key => $value )
    {
        $dept_id = $value['DEPT_ID'];
        if ( $dept_id != $priv_dept && !is_dept_parent( $priv_dept, $dept_id ) )
        {
        }
        else
        {
            return TRUE;
            break;
        }
    }
    return FALSE;
}

function get_flow_list_of_priv( $action, $root, $user_id, $user_dept, $user_priv, $user_other_dept = "", $user_other_priv = "" )
{
    $result = array( );
    if ( $root === TRUE )
    {
        $result[] = array( "txt" => _( "ȫ������" ), "value" => "all", "levle" => 0, "node" => "root" );
    }
    $cache_categorys = ( "W_CATEGORY_LIST" );
    if ( is_array( $cache_categorys ) )
    {
        foreach ( $cache_categorys as $catetory_id => $category_value )
        {
            $level = $category_value['LEVEL'];
            $category_name = $category_value['NAME'];
            $cache_work_lists = ( "W_WORK_LIST_".$catetory_id );
            if ( is_array( $cache_work_lists ) )
            {
                foreach ( $cache_work_lists as $flow_id => $value )
                {
                    $flag = FALSE;
                    if ( $action == 0 )
                    {
                        $flag = TRUE;
                    }
                    else if ( $action == 1 )
                    {
                        $priv_str = getflowprivofmanage( $flow_id, $user_id, $user_dept, $user_priv, $user_other_dept, $user_other_priv );
                        if ( find_id( $priv_str, 0 ) || find_id( $priv_str, 1 ) || find_id( $priv_str, 2 ) )
                        {
                            $flag = TRUE;
                        }
                    }
                    else if ( $action == 2 )
                    {
                        if ( getflowprivofadminrole( $user_id, $user_priv, $user_other_priv ) )
                        {
                            $flag = TRUE;
                        }
                        else
                        {
                            $priv_str = getflowprivofmanage( $flow_id, $user_id, $user_dept, $user_priv, $user_other_dept, $user_other_priv );
                            if ( find_id( $priv_str, 0 ) || find_id( $priv_str, 1 ) || find_id( $priv_str, 2 ) )
                            {
                                $flag = TRUE;
                            }
                        }
                    }
                    else if ( $action == 3 )
                    {
                        if ( getflowprivofadminrole( $user_id, $user_priv, $user_other_priv ) )
                        {
                            $flag = TRUE;
                        }
                        else
                        {
                            $flag = getflowprivofexcute( $flow_id, $user_id, $user_dept, $user_priv, $user_other_dept, $user_other_priv );
                        }
                    }
                    else if ( $action == 4 )
                    {
                        if ( getflowprivofadminrole( $user_id, $user_priv, $user_other_priv ) )
                        {
                            $flag = TRUE;
                        }
                        else
                        {
                            if ( getflowprivofexcute( $flow_id, $user_id, $user_dept, $user_priv, $user_other_dept, $user_other_priv ) )
                            {
                                $flag = TRUE;
                            }
                            else
                            {
                                $priv_str = getflowprivofmanage( $flow_id, $user_id, $user_dept, $user_priv, $user_other_dept, $user_other_priv );
                                if ( $priv_str != NULL && $priv_str != "" )
                                {
                                    $flag = TRUE;
                                }
                            }
                        }
                    }
                    else if ( $action == 5 )
                    {
                        if ( getflowprivofadminrole( $user_id, $user_priv, $user_other_priv ) )
                        {
                            $flag = TRUE;
                        }
                        else
                        {
                            if ( getflowprivofexcute( $flow_id, $user_id, $user_dept, $user_priv, $user_other_dept, $user_other_priv ) )
                            {
                                $flag = TRUE;
                            }
                            else
                            {
                                $priv_str = getflowprivofmanage( $flow_id, $user_id, $user_dept, $user_priv, $user_other_dept, $user_other_priv );
                                if ( find_id( $priv_str, 0 ) || find_id( $priv_str, 1 ) || find_id( $priv_str, 2 ) )
                                {
                                    $flag = TRUE;
                                }
                            }
                        }
                    }
                    else if ( $action == 6 )
                    {
                        $flowInfo = getflowinfo( $flow_id );
                        if ( getflowprivofadminrole( $user_id, $user_priv, $user_other_priv ) && $flowInfo['FREE_OTHER'] == 2 )
                        {
                            $flag = TRUE;
                        }
                        else
                        {
                            $flag = getflowprivofexcute( $flow_id, $user_id, $user_dept, $user_priv, $user_other_dept, $user_other_priv );
                            if ( $flag && $flowInfo['FREE_OTHER'] == 2 )
                            {
                                $flag = TRUE;
                            }
                            else
                            {
                                $flag = FALSE;
                            }
                        }
                    }
                    if ( $flag )
                    {
                        $category_name = cstr_replace( "\\", "\\\\", $category_name );
                        $flow_name = cstr_replace( "\\", "\\\\", $value['FLOW_NAME'] );
                        $result[] = array( "txt" => $flow_name, "category" => $category_name, "value" => $flow_id, "type" => $value['FLOW_TYPE'], "level" => $level, "node" => "leaf" );
                    }
                }
            }
        }
    }
    return $result;
}

function get_sub_flow_list_of_priv( $category_id, $action, $user_id, $user_dept, $user_priv, $user_other_dept = "", $user_other_priv = "" )
{
}

?>
