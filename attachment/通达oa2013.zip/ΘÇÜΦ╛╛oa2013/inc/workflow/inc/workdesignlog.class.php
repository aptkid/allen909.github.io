<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class WorkDesignLog
{

    public static $LOG_TYPE_INSERT = 1;
    public static $LOG_TYPE_UPDATE = 2;
    public static $LOG_TYPE_DELETE = 3;
    public static $LOG_TYPE_PRIV = 4;
    public static $LOG_TYPE_IMPORT = 5;
    public static $LOG_TYPE_CLEAN = 6;
    public static $LOG_TYPE_REMOVE = 7;
    public static $LOG_TYPE_MATCH = 8;

    public static function log( $flow_id, $flow_name, $user_id, $log_type, $content, $r_connection = NULL )
    {
        if ( $r_connection == NULL )
        {
            $r_connection = ( );
        }
        $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
        if ( $flow_name == NULL || $flow_name == "" )
        {
            $flow_name = getflowname( $flow_id );
        }
        $keyValues = array( );
        $keyValues['FLOW_ID'] = $flow_id;
        $keyValues['FLOW_NAME'] = $flow_name;
        $keyValues['USER_ID'] = $user_id;
        $keyValues['UID'] = userid2uid( $user_id );
        $keyValues['TYPE'] = $log_type;
        $keyValues['CONTENT'] = $content;
        $keyValues['IP'] = get_client_ip( );
        $keyValues['TIME'] = date( "Y-m-d H:i:s", time( ) );
        $sql = $OBJ_SQL_SYNTAX->getInsertSQL( "FLOW_MANAGE_LOG", $keyValues );
        exequery( $r_connection, $sql );
    }

    public static function getLogList( $start_pos = 0, $row_count = 10, $fields, $condition_keys = NULL, $order_by_field = NULL, $order_by_directory = NULL, $r_connection = NULL )
    {
        if ( $r_connection == NULL )
        {
            $r_connection = ( );
        }
        $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
        $conditions = array( );
        if ( isset( $conditions ) && is_array( $condition_keys ) )
        {
            foreach ( $condition_keys as $key => $value )
            {
                switch ( strtolower( $key ) )
                {
                    case "flow_id" :
                        array_push( &$conditions, $condition_keys[$key]( "FLOW_ID", EXPR_OP_IS, $condition_keys[$key], FIELD_TYPE_INT ) );
                        break;
                    case "flow_name" :
                        array_push( &$conditions, $condition_keys[$key]( "FLOW_NAME", EXPR_OP_IS, $condition_keys[$key], FIELD_TYPE_CHAR ) );
                        break;
                    case "ip" :
                        array_push( &$conditions, $condition_keys[$key]( "IP", EXPR_OP_IS, $condition_keys[$key], FIELD_TYPE_CHAR ) );
                        break;
                    case "user_id" :
                        array_push( &$conditions, $condition_keys[$key]( "USER_ID", EXPR_OP_IS, $condition_keys[$key], FIELD_TYPE_CHAR ) );
                        break;
                    case "type" :
                        array_push( &$conditions, $condition_keys[$key]( "TYPE", EXPR_OP_IS, $condition_keys[$key], FIELD_TYPE_CHAR ) );
                        break;
                    case "start_time" :
                        array_push( &$conditions, $condition_keys[$key]( "TIME", EXPR_OP_GRTEQ, $condition_keys[$key], FIELD_TYPE_DATETIME ) );
                        break;
                    case "end_time" :
                        array_push( &$conditions, $condition_keys[$key]( "TIME", EXPR_OP_LSTEQ, $condition_keys[$key], FIELD_TYPE_DATETIME ) );
                }
            }
            $where_definition = $OBJ_SQL_SYNTAX->getWhereDefinition( $conditions, CONDITION_LOGIC_OP_AND );
        }
        else
        {
            $where_definition = "";
        }
        $select_exprs = $OBJ_SQL_SYNTAX->getSelectExprs( $fields );
        if ( !isset( $order_by_field ) || $order_by_field == "" )
        {
            $order_by_definition = $OBJ_SQL_SYNTAX->getOrderByDefinition( "ID", "DESC" );
        }
        else
        {
            if ( !isset( $order_by_directory ) || $order_by_directory == "" )
            {
                $order_by_directory = "ASC";
            }
            else
            {
                $order_by_directory = $order_by_directory;
            }
            $order_by_definition = $OBJ_SQL_SYNTAX->getOrderByDefinition( $order_by_field, $order_by_directory );
        }
        $sql = $OBJ_SQL_SYNTAX->getQuerySQL( $start_pos, $row_count, $select_exprs, "FLOW_MANAGE_LOG", $where_definition, $order_by_definition );
        $r_cursor = exequery( $r_connection, $sql );
        return $r_cursor;
    }

    public static function getLogCount( $condition_keys = NULL, $r_connection = NULL )
    {
        $total_number = 0;
        if ( $r_connection == NULL )
        {
            $r_connection = ( );
        }
        $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
        $conditions = array( );
        if ( isset( $conditions ) && is_array( $condition_keys ) )
        {
            foreach ( $condition_keys as $key => $value )
            {
                switch ( strtolower( $key ) )
                {
                    case "flow_id" :
                        array_push( &$conditions, $condition_keys[$key]( "FLOW_ID", EXPR_OP_IS, $condition_keys[$key], FIELD_TYPE_INT ) );
                        break;
                    case "flow_name" :
                        array_push( &$conditions, $condition_keys[$key]( "FLOW_NAME", EXPR_OP_IS, $condition_keys[$key], FIELD_TYPE_CHAR ) );
                        break;
                    case "ip" :
                        array_push( &$conditions, $condition_keys[$key]( "IP", EXPR_OP_IS, $condition_keys[$key], FIELD_TYPE_CHAR ) );
                        break;
                    case "user_id" :
                        array_push( &$conditions, $condition_keys[$key]( "USER_ID", EXPR_OP_IS, $condition_keys[$key], FIELD_TYPE_CHAR ) );
                        break;
                    case "type" :
                        array_push( &$conditions, $condition_keys[$key]( "TYPE", EXPR_OP_IS, $condition_keys[$key], FIELD_TYPE_CHAR ) );
                        break;
                    case "start_time" :
                        array_push( &$conditions, $condition_keys[$key]( "TIME", EXPR_OP_GRTEQ, $condition_keys[$key], FIELD_TYPE_DATETIME ) );
                        break;
                    case "end_time" :
                        array_push( &$conditions, $condition_keys[$key]( "TIME", EXPR_OP_LSTEQ, $condition_keys[$key], FIELD_TYPE_DATETIME ) );
                }
            }
            $where_definition = $OBJ_SQL_SYNTAX->getWhereDefinition( $conditions, CONDITION_LOGIC_OP_AND );
        }
        else
        {
            $where_definition = "";
        }
        $select_exprs = $OBJ_SQL_SYNTAX->getSelectExprs( "COUNT(ID) as total_number " );
        $sql = $OBJ_SQL_SYNTAX->getQuerySQL( $start_pos, $row_count, $select_exprs, "FLOW_MANAGE_LOG", $where_definition );
        $r_cursor = exequery( $r_connection, $sql );
        if ( $row = mysql_fetch_array( $r_cursor ) )
        {
            $total_number = $row['total_number'];
        }
        return $total_number;
    }

    public static function delete( $condition_keys = NULL, $r_connection = NULL )
    {
        if ( $r_connection == NULL )
        {
            $r_connection = ( );
        }
        $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
        $conditions = array( );
        if ( isset( $conditions ) && is_array( $condition_keys ) )
        {
            foreach ( $condition_keys as $key => $value )
            {
                switch ( strtolower( $key ) )
                {
                    case "flow_id" :
                        array_push( &$conditions, $condition_keys[$key]( "FLOW_ID", EXPR_OP_IS, $condition_keys[$key], FIELD_TYPE_INT ) );
                        break;
                    case "flow_name" :
                        array_push( &$conditions, $condition_keys[$key]( "RUN_NAME", EXPR_OP_IS, $condition_keys[$key], FIELD_TYPE_CHAR ) );
                        break;
                    case "ip" :
                        array_push( &$conditions, $condition_keys[$key]( "IP", EXPR_OP_IS, $condition_keys[$key], FIELD_TYPE_CHAR ) );
                        break;
                    case "user_id" :
                        array_push( &$conditions, $condition_keys[$key]( "USER_ID", EXPR_OP_IS, $condition_keys[$key], FIELD_TYPE_CHAR ) );
                        break;
                    case "type" :
                        array_push( &$conditions, $condition_keys[$key]( "TYPE", EXPR_OP_IS, $condition_keys[$key], FIELD_TYPE_CHAR ) );
                        break;
                    case "start_time" :
                        array_push( &$conditions, $condition_keys[$key]( "TIME", EXPR_OP_GRTEQ, $condition_keys[$key], FIELD_TYPE_DATETIME ) );
                        break;
                    case "end_time" :
                        array_push( &$conditions, $condition_keys[$key]( "TIME", EXPR_OP_LSTEQ, $condition_keys[$key], FIELD_TYPE_DATETIME ) );
                        break;
                    case "log_ids" :
                        $value = $condition_keys[$key];
                        if ( substr( $value, -1, 1 ) == "," )
                        {
                            $value = substr( $value, 0, -1 );
                        }
                        array_push( &$conditions, $OBJ_SQL_SYNTAX->getConditionExpr( "ID", EXPR_OP_IN, $value, FIELD_TYPE_INT ) );
                }
            }
            $where_definition = $OBJ_SQL_SYNTAX->getWhereDefinition( $conditions, CONDITION_LOGIC_OP_AND );
        }
        else
        {
            $where_definition = "";
        }
        $sql = $OBJ_SQL_SYNTAX->getDeleteSQL( "FLOW_MANAGE_LOG", $where_definition );
        exequery( $r_connection, $sql );
    }

}

?>
