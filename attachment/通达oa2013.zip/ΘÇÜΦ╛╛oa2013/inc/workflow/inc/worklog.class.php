<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class WorkLog
{

    public static $LOG_TYPE_BASE = 1;
    public static $LOG_TYPE_DEPUTE = 2;
    public static $LOG_TYPE_DELETE = 3;
    public static $LOG_TYPE_DESTROY = 4;
    public static $LOG_TYPE_RESTORE = 5;
    public static $LOG_TYPE_EDITDATA = 6;
    public static $LOG_TYPE_AUTH_CHANGE = 7;
    public static $LOG_TYPE_FORCE_END = 8;
    public static $LOG_TYPE_RESTORE_END = 9;
    public static $LOG_TYPE_REMOVE_TO = 10;

    public static function log( $flow_id, $run_id, $run_name, $prcs_id, $flow_prcs, $user_id, $log_type, $content, $r_connection = NULL )
    {
        if ( $r_connection == NULL )
        {
            $r_connection = ( );
        }
        $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
        if ( $flow_id == NULL || $flow_id == "" || $run_name == NULL || $run_name == "" )
        {
            $select_exprs = "FLOW_ID,RUN_NAME";
            $table_references = "FLOW_RUN";
            $where_definition = $OBJ_SQL_SYNTAX->getConditionExpr( "RUN_ID", EXPR_OP_IS, $run_id, FIELD_TYPE_INT );
            $sql = $OBJ_SQL_SYNTAX->getQuerySQL( 0, 0, $select_exprs, $table_references, $where_definition );
            $r_cursor = exequery( $r_connection, $sql );
            if ( $row = mysql_fetch_array( $r_cursor ) )
            {
                $flow_id = $row['FLOW_ID'];
                $run_name = $row['RUN_NAME'];
            }
        }
        $keyValues = array( );
        $keyValues['RUN_ID'] = $run_id;
        $keyValues['RUN_NAME'] = addslashes( $run_name );
        $keyValues['FLOW_ID'] = $flow_id;
        $keyValues['PRCS_ID'] = $prcs_id;
        $keyValues['FLOW_PRCS'] = $flow_prcs;
        $keyValues['USER_ID'] = $user_id;
        $keyValues['TYPE'] = $log_type;
        $keyValues['CONTENT'] = $content;
        $keyValues['IP'] = get_client_ip( );
        $keyValues['TIME'] = date( "Y-m-d H:i:s", time( ) );
        $sql = $OBJ_SQL_SYNTAX->getInsertSQL( "FLOW_RUN_LOG", $keyValues );
        exequery( $r_connection, $sql );
    }

    public static function logBatch( $flow_ids, $run_ids, $run_names, $prcs_ids, $flow_prcss, $user_id, $log_type, $contents, $r_connection = NULL )
    {
        if ( $r_connection == NULL )
        {
            $r_connection = ( );
        }
        $sql = "INSERT INTO FLOW_RUN_LOG(RUN_ID, RUN_NAME, FLOW_ID, PRCS_ID, FLOW_PRCS, USER_ID, TYPE, CONTENT, IP, TIME) VALUES";
        $ip = get_client_ip( );
        $cur_time = date( "Y-m-d H:i:s", time( ) );
        $count = count( $run_ids );
        $i = 0;
        for ( ; $i < $count; ++$i )
        {
            $sql .= "(";
            $sql .= "'".$run_ids[$i]."',";
            $sql .= "'".$run_names[$i]."',";
            $sql .= "'".$flow_ids[$i]."',";
            $sql .= "'".$prcs_ids[$i]."',";
            $sql .= "'".$flow_prcss[$i]."',";
            $sql .= "'".$user_id."',";
            $sql .= "'".$log_type."',";
            $sql .= "'".$contents[$i]."',";
            $sql .= "'".$ip."',";
            $sql .= "'".$cur_time."'),";
        }
        $sql = substr( $sql, 0, -1 );
        exequery( $r_connection, $sql, TRUE );
    }

    public static function getLogList( $start_pos = 0, $row_count = 10, $fields = NULL, $condition_keys = NULL, $order_by_field = NULL, $order_by_directory = NULL, $r_connection = NULL )
    {
        if ( $r_connection == NULL )
        {
            $r_connection = ( );
        }
        $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
        $conditions = array( );
        $str_flow = "";
        if ( isset( $conditions ) && is_array( $condition_keys ) )
        {
            foreach ( $condition_keys as $key => $value )
            {
                switch ( strtolower( $key ) )
                {
                    case "flow_id" :
                        array_push( &$conditions, $condition_keys[$key]( "FLOW_RUN_LOG.`FLOW_ID`", EXPR_OP_IS, $condition_keys[$key], FIELD_TYPE_INT ) );
                        $str_flow = $condition_keys[$key];
                        break;
                    case "run_id" :
                        array_push( &$conditions, $condition_keys[$key]( "FLOW_RUN_LOG.RUN_ID", EXPR_OP_IS, $condition_keys[$key], FIELD_TYPE_INT ) );
                        break;
                    case "run_name" :
                        array_push( &$conditions, $condition_keys[$key]( "FLOW_RUN_LOG.RUN_NAME", EXPR_OP_IS, $condition_keys[$key], FIELD_TYPE_CHAR ) );
                        break;
                    case "ip" :
                        array_push( &$conditions, $condition_keys[$key]( "FLOW_RUN_LOG.IP", EXPR_OP_IS, $condition_keys[$key], FIELD_TYPE_CHAR ) );
                        break;
                    case "user_id" :
                        array_push( &$conditions, $condition_keys[$key]( "FLOW_RUN_LOG.USER_ID", EXPR_OP_IS, $condition_keys[$key], FIELD_TYPE_CHAR ) );
                        break;
                    case "type" :
                        array_push( &$conditions, $condition_keys[$key]( "FLOW_RUN_LOG.TYPE", EXPR_OP_IS, $condition_keys[$key], FIELD_TYPE_CHAR ) );
                        break;
                    case "start_time" :
                        array_push( &$conditions, $condition_keys[$key]( "FLOW_RUN_LOG.TIME", EXPR_OP_GRTEQ, $condition_keys[$key], FIELD_TYPE_DATETIME ) );
                        break;
                    case "end_time" :
                        array_push( &$conditions, $condition_keys[$key]( "FLOW_RUN_LOG.TIME", EXPR_OP_LSTEQ, $condition_keys[$key], FIELD_TYPE_DATETIME ) );
                }
            }
            $where_definition = $OBJ_SQL_SYNTAX->getWhereDefinition( $conditions, CONDITION_LOGIC_OP_AND );
        }
        else
        {
            $where_definition = "1";
        }
        $select_exprs = $OBJ_SQL_SYNTAX->getSelectExprs( $fields );
        if ( !isset( $order_by_field ) || $order_by_field == "" )
        {
            $order_by_definition = $OBJ_SQL_SYNTAX->getOrderByDefinition( "ID", "DESC" );
        }
        else
        {
            if ( !isset( $order_by_directory ) || $order_by_directory == "" )
            {
                $order_by_directory = "ASC";
            }
            else
            {
                $order_by_directory = $order_by_directory;
            }
            $order_by_definition = $OBJ_SQL_SYNTAX->getOrderByDefinition( $order_by_field, $order_by_directory );
        }
        $user_id = $_SESSION['LOGIN_USER_ID'];
        $priv_str = getprivquerycondition( $str_flow, "0,1,2,3,4,5", $user_id, $_SESSION['LOGIN_DEPT_ID'], $_SESSION['LOGIN_USER_PRIV'], $_SESSION['LOGIN_DEPT_ID_OTHER'], $_SESSION['LOGIN_USER_PRIV_OTHER'] );
        $str_condition = " AND (";
        $str_condition .= " FLOW_RUN.BEGIN_USER = '".$user_id."' ";
        if ( !empty( $priv_str ) && trim( $priv_str ) != "" )
        {
            $str_condition .= " OR ".$priv_str;
        }
        $myOpRunQueryStr = " SELECT FLOW_RUN_PRCS.RUN_ID FROM FLOW_RUN_PRCS WHERE FLOW_RUN_PRCS.USER_ID = '".$user_id."' ";
        $str_condition .= " OR FLOW_RUN.RUN_ID IN (".$myOpRunQueryStr.") ";
        $str_condition .= " OR FIND_IN_SET('".$user_id."',FLOW_RUN.FOCUS_USER)";
        $str_condition .= " OR FIND_IN_SET('".$user_id."',FLOW_RUN.VIEW_USER)";
        $str_condition .= ") ";
        $where_definition .= $str_condition;
        $table_references = $OBJ_SQL_SYNTAX->getTableReferences( "FLOW_RUN_LOG", "LEFT JOIN", "FLOW_RUN", "FLOW_RUN.RUN_ID=FLOW_RUN_LOG.RUN_ID" );
        $sql = $OBJ_SQL_SYNTAX->getQuerySQL( $start_pos, $row_count, $select_exprs, $table_references, $where_definition, $order_by_definition );
        $r_cursor = exequery( $r_connection, $sql );
        return $r_cursor;
    }

    public static function getLogCount( $condition_keys = NULL, $r_connection = NULL )
    {
        $total_number = 0;
        if ( $r_connection == NULL )
        {
            $r_connection = ( );
        }
        $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
        $conditions = array( );
        $str_flow = "";
        if ( isset( $conditions ) && is_array( $condition_keys ) )
        {
            foreach ( $condition_keys as $key => $value )
            {
                switch ( strtolower( $key ) )
                {
                    case "flow_id" :
                        array_push( &$conditions, $condition_keys[$key]( "FLOW_RUN_LOG.`FLOW_ID`", EXPR_OP_IS, $condition_keys[$key], FIELD_TYPE_INT ) );
                        $str_flow = $condition_keys[$key];
                        break;
                    case "run_id" :
                        array_push( &$conditions, $condition_keys[$key]( "FLOW_RUN_LOG.RUN_ID", EXPR_OP_IS, $condition_keys[$key], FIELD_TYPE_INT ) );
                        break;
                    case "run_name" :
                        array_push( &$conditions, $condition_keys[$key]( "FLOW_RUN_LOG.RUN_NAME", EXPR_OP_IS, $condition_keys[$key], FIELD_TYPE_CHAR ) );
                        break;
                    case "ip" :
                        array_push( &$conditions, $condition_keys[$key]( "FLOW_RUN_LOG.IP", EXPR_OP_IS, $condition_keys[$key], FIELD_TYPE_CHAR ) );
                        break;
                    case "user_id" :
                        array_push( &$conditions, $condition_keys[$key]( "FLOW_RUN_LOG.USER_ID", EXPR_OP_IS, $condition_keys[$key], FIELD_TYPE_CHAR ) );
                        break;
                    case "type" :
                        array_push( &$conditions, $condition_keys[$key]( "FLOW_RUN_LOG.TYPE", EXPR_OP_IS, $condition_keys[$key], FIELD_TYPE_CHAR ) );
                        break;
                    case "start_time" :
                        array_push( &$conditions, $condition_keys[$key]( "FLOW_RUN_LOG.TIME", EXPR_OP_GRTEQ, $condition_keys[$key], FIELD_TYPE_DATETIME ) );
                        break;
                    case "end_time" :
                        array_push( &$conditions, $condition_keys[$key]( "FLOW_RUN_LOG.TIME", EXPR_OP_LSTEQ, $condition_keys[$key], FIELD_TYPE_DATETIME ) );
                }
            }
            $where_definition = $OBJ_SQL_SYNTAX->getWhereDefinition( $conditions, CONDITION_LOGIC_OP_AND );
        }
        else
        {
            $where_definition = "1";
        }
        $select_exprs = $OBJ_SQL_SYNTAX->getSelectExprs( "COUNT(FLOW_RUN_LOG.`LOG_ID`) as total_number " );
        $user_id = $_SESSION['LOGIN_USER_ID'];
        $priv_str = getprivquerycondition( $str_flow, "0,1,2,3,4,5", $user_id, $_SESSION['LOGIN_DEPT_ID'], $_SESSION['LOGIN_USER_PRIV'], $_SESSION['LOGIN_DEPT_ID_OTHER'], $_SESSION['LOGIN_USER_PRIV_OTHER'] );
        $str_condition = " AND (";
        $str_condition .= " FLOW_RUN.BEGIN_USER = '".$user_id."' ";
        if ( !empty( $priv_str ) && trim( $priv_str ) != "" )
        {
            $str_condition .= " OR ".$priv_str;
        }
        $myOpRunQueryStr = " SELECT FLOW_RUN_PRCS.RUN_ID FROM FLOW_RUN_PRCS WHERE FLOW_RUN_PRCS.USER_ID = '".$user_id."' ";
        $str_condition .= " OR FLOW_RUN.RUN_ID IN (".$myOpRunQueryStr.") ";
        $str_condition .= " OR FIND_IN_SET('".$user_id."',FLOW_RUN.FOCUS_USER)";
        $str_condition .= " OR FIND_IN_SET('".$user_id."',FLOW_RUN.VIEW_USER)";
        $str_condition .= ") ";
        $where_definition .= $str_condition;
        $table_references = $OBJ_SQL_SYNTAX->getTableReferences( "FLOW_RUN_LOG", "LEFT JOIN", "FLOW_RUN", "FLOW_RUN.RUN_ID=FLOW_RUN_LOG.RUN_ID" );
        $sql = $OBJ_SQL_SYNTAX->getQuerySQL( $start_pos, $row_count, $select_exprs, $table_references, $where_definition, $order_by_definition );
        $r_cursor = exequery( $r_connection, $sql );
        if ( $row = mysql_fetch_array( $r_cursor ) )
        {
            $total_number = $row['total_number'];
        }
        return $total_number;
    }

    public static function delete( $condition_keys = NULL, $r_connection = NULL )
    {
        if ( $r_connection == NULL )
        {
            $r_connection = ( );
        }
        $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
        $conditions = array( );
        if ( isset( $conditions ) && is_array( $condition_keys ) )
        {
            foreach ( $condition_keys as $key => $value )
            {
                switch ( strtolower( $key ) )
                {
                    case "flow_id" :
                        array_push( &$conditions, $condition_keys[$key]( "FLOW_ID", EXPR_OP_IS, $condition_keys[$key], FIELD_TYPE_INT ) );
                        break;
                    case "run_id" :
                        array_push( &$conditions, $condition_keys[$key]( "RUN_ID", EXPR_OP_IS, $condition_keys[$key], FIELD_TYPE_INT ) );
                        break;
                    case "run_name" :
                        array_push( &$conditions, $condition_keys[$key]( "RUN_NAME", EXPR_OP_IS, $condition_keys[$key], FIELD_TYPE_CHAR ) );
                        break;
                    case "ip" :
                        array_push( &$conditions, $condition_keys[$key]( "IP", EXPR_OP_IS, $condition_keys[$key], FIELD_TYPE_CHAR ) );
                        break;
                    case "user_id" :
                        array_push( &$conditions, $condition_keys[$key]( "USER_ID", EXPR_OP_IS, $condition_keys[$key], FIELD_TYPE_CHAR ) );
                        break;
                    case "type" :
                        array_push( &$conditions, $condition_keys[$key]( "TYPE", EXPR_OP_IS, $condition_keys[$key], FIELD_TYPE_CHAR ) );
                        break;
                    case "start_time" :
                        array_push( &$conditions, $condition_keys[$key]( "TIME", EXPR_OP_GRTEQ, $condition_keys[$key], FIELD_TYPE_DATETIME ) );
                        break;
                    case "end_time" :
                        array_push( &$conditions, $condition_keys[$key]( "TIME", EXPR_OP_LSTEQ, $condition_keys[$key], FIELD_TYPE_DATETIME ) );
                        break;
                    case "log_ids" :
                        $value = $condition_keys[$key];
                        if ( substr( $value, -1, 1 ) == "," )
                        {
                            $value = substr( $value, 0, -1 );
                        }
                        array_push( &$conditions, $OBJ_SQL_SYNTAX->getConditionExpr( "LOG_ID", EXPR_OP_IN, $value, FIELD_TYPE_INT ) );
                }
            }
            $where_definition = $OBJ_SQL_SYNTAX->getWhereDefinition( $conditions, CONDITION_LOGIC_OP_AND );
        }
        else
        {
            $where_definition = "";
        }
        $sql = $OBJ_SQL_SYNTAX->getDeleteSQL( "FLOW_RUN_LOG", $where_definition );
        exequery( $r_connection, $sql );
    }

}

?>
