<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
function getFlowPrivOfManage( $flow_id, $user_id, $user_dept, $user_priv, $user_other_dept = "", $user_other_priv = "" )
{
    $role_str = "";
    $flow_cache = ( "W_FLOW" );
    $flow_cache = $flow_cache[$flow_id];
    $arr_priv = $flow_cache['PRIV'];
    if ( is_array( $arr_priv ) )
    {
        foreach ( $arr_priv as $priv_type => $privs )
        {
            if ( is_array( $privs ) )
            {
                foreach ( $privs as $priv_scope => $values )
                {
                    $priv_user = $values['USER'];
                    $priv_dept = $values['DEPT'];
                    $priv_role = $values['ROLE'];
                    if ( !( !find_id( $priv_dept, "ALL_DEPT" ) && !find_id( $priv_user, $user_id ) && !find_id( $priv_dept, $user_dept ) && !find_id( $priv_role, $user_priv ) && !( check_id( $priv_dept, $user_other_dept, TRUE ) != "" ) && !( check_id( $priv_role, $user_other_priv, TRUE ) != "" ) ) )
                    {
                        continue;
                    }
                    else if ( $priv_type == "0" )
                    {
                        return "1,2,3,4,5,";
                    }
                    else
                    {
                        $role_str .= $priv_type.",";
                        break;
                    }
                }
            }
        }
    }
    return $role_str;
}

function getFlowRunPrivOfManage( $flow_id, $begin_dept_id, $user_id, $user_dept, $user_priv, $user_other_dept = "", $user_other_priv = "" )
{
    $role_str = "";
    $flow_cache = ( "W_FLOW" );
    $flow_cache = $flow_cache[$flow_id];
    $arr_priv = $flow_cache['PRIV'];
    if ( is_array( $arr_priv ) )
    {
        foreach ( $arr_priv as $priv_type => $priv_info )
        {
            if ( is_array( $priv_info['ALL_DEPT'] ) )
            {
                $priv_user = empty( $priv_info['ALL_DEPT']['USER'] ) ? "" : $priv_info['ALL_DEPT']['USER'];
                $priv_dept = empty( $priv_info['ALL_DEPT']['DEPT'] ) ? "" : $priv_info['ALL_DEPT']['DEPT'];
                $priv_role = empty( $priv_info['ALL_DEPT']['ROLE'] ) ? "" : $priv_info['ALL_DEPT']['ROLE'];
                if ( $priv_dept == "ALL_DEPT" || find_id( $priv_user, $user_id ) || find_id( $priv_dept, $user_dept ) || find_id( $priv_role, $user_priv ) || check_id( $priv_dept, $user_other_dept, TRUE ) != "" || check_id( $priv_role, $user_other_priv, TRUE ) != "" )
                {
                    if ( $priv_type == 0 )
                    {
                        return "1,2,3,4,5,";
                    }
                    $role_str .= $priv_type.",";
                }
            }
            else if ( is_array( $priv_info['SELF_ORG'] ) )
            {
                $priv_user = empty( $priv_info['SELF_ORG']['USER'] ) ? "" : $priv_info['SELF_ORG']['USER'];
                $priv_dept = empty( $priv_info['SELF_ORG']['DEPT'] ) ? "" : $priv_info['SELF_ORG']['DEPT'];
                $priv_role = empty( $priv_info['SELF_ORG']['ROLE'] ) ? "" : $priv_info['SELF_ORG']['ROLE'];
                if ( $priv_dept == "ALL_DEPT" || find_id( $priv_user, $user_id ) || find_id( $priv_dept, $user_dept ) || find_id( $priv_role, $user_priv ) || check_id( $priv_dept, $user_other_dept, TRUE ) != "" || check_id( $priv_role, $user_other_priv, TRUE ) != "" )
                {
                    if ( $priv_type == 0 )
                    {
                        return "1,2,3,4,5,";
                    }
                    $role_str .= $priv_type.",";
                }
            }
            else if ( is_array( $priv_info['SELF_DEPT'] ) )
            {
                $priv_user = empty( $priv_info['SELF_DEPT']['USER'] ) ? "" : $priv_info['SELF_DEPT']['USER'];
                $priv_dept = empty( $priv_info['SELF_DEPT']['DEPT'] ) ? "" : $priv_info['SELF_DEPT']['DEPT'];
                $priv_role = empty( $priv_info['SELF_DEPT']['ROLE'] ) ? "" : $priv_info['SELF_DEPT']['ROLE'];
                if ( $priv_dept == "ALL_DEPT" || find_id( $priv_user, $user_id ) || find_id( $priv_dept, $user_dept ) || find_id( $priv_role, $user_priv ) || check_id( $priv_dept, $user_other_dept, TRUE ) != "" || check_id( $priv_role, $user_other_priv, TRUE ) != "" )
                {
                    $self_depts = getselfdept( $user_dept );
                    if ( find_id( $self_depts, $begin_dept_id ) )
                    {
                        if ( $priv_type == 0 )
                        {
                            return "1,2,3,4,5,";
                        }
                        $role_str .= $priv_type.",";
                    }
                }
            }
            else if ( is_array( $priv_info['SELF_BRANCH'] ) )
            {
                $priv_user = empty( $priv_info['SELF_BRANCH']['USER'] ) ? "" : $priv_info['SELF_BRANCH']['USER'];
                $priv_dept = empty( $priv_info['SELF_BRANCH']['DEPT'] ) ? "" : $priv_info['SELF_BRANCH']['DEPT'];
                $priv_role = empty( $priv_info['SELF_BRANCH']['ROLE'] ) ? "" : $priv_info['SELF_BRANCH']['ROLE'];
                if ( ( $priv_dept == "ALL_DEPT" || find_id( $priv_user, $user_id ) || find_id( $priv_dept, $user_dept ) || find_id( $priv_role, $user_priv ) || check_id( $priv_dept, $user_other_dept, TRUE ) != "" || check_id( $priv_role, $user_other_priv, TRUE ) != "" ) && $user_dept == $begin_dept_id )
                {
                    if ( $priv_type == 0 )
                    {
                        return "1,2,3,4,5,";
                    }
                    $role_str .= $priv_type.",";
                }
            }
            else
            {
                foreach ( $priv_info as $priv_scope => $priv_scope_info )
                {
                    if ( $priv_scope == "ALL_DEPT" || $priv_scope == "SELF_ORG" || $priv_scope == "SELF_DEPT" )
                    {
                    }
                    else
                    {
                        continue;
                    }
                    $priv_user = empty( $priv_scope_info['USER'] ) ? "" : $priv_scope_info['USER'];
                    $priv_dept = empty( $priv_scope_info['DEPT'] ) ? "" : $priv_scope_info['DEPT'];
                    $priv_role = empty( $priv_scope_info['ROLE'] ) ? "" : $priv_scope_info['ROLE'];
                    if ( !( !( $priv_dept == "ALL_DEPT" ) && !find_id( $priv_user, $user_id ) && !find_id( $priv_dept, $user_dept ) && !find_id( $priv_role, $user_priv ) && !( check_id( $priv_dept, $user_other_dept, TRUE ) != "" ) && !( check_id( $priv_role, $user_other_priv, TRUE ) != "" ) || !find_id( $priv_scope, $begin_dept_id ) ) )
                    {
                        continue;
                    }
                    else if ( $priv_type == 0 )
                    {
                        return "1,2,3,4,5,";
                    }
                    else
                    {
                        $role_str .= $priv_type.",";
                    }
                }
            }
        }
    }
    return $role_str;
}

function ifGetPrivOfFlowRun( $priv_id, $flow_id, $run_id, $begin_dept_id, $user_id, $user_dept, $user_priv, $user_other_dept = "", $user_other_priv = "" )
{
    $role_str = "";
    $flow_cache = ( "W_FLOW" );
    $flow_cache = $flow_cache[$flow_id];
    $arr_priv = $flow_cache['PRIV'];
    if ( is_array( $arr_priv ) )
    {
        foreach ( $arr_priv as $priv_type => $priv_info )
        {
            if ( 0 < $priv_type && $priv_type != $priv_id )
            {
                if ( is_array( $priv_info['ALL_DEPT'] ) )
                {
                    $priv_user = empty( $priv_info['ALL_DEPT']['USER'] ) ? "" : $priv_info['ALL_DEPT']['USER'];
                    $priv_dept = empty( $priv_info['ALL_DEPT']['DEPT'] ) ? "" : $priv_info['ALL_DEPT']['DEPT'];
                    $priv_role = empty( $priv_info['ALL_DEPT']['ROLE'] ) ? "" : $priv_info['ALL_DEPT']['ROLE'];
                    if ( $priv_dept == "ALL_DEPT" || find_id( $priv_user, $user_id ) || find_id( $priv_dept, $user_dept ) || find_id( $priv_role, $user_priv ) || check_id( $priv_dept, $user_other_dept, TRUE ) != "" || check_id( $priv_role, $user_other_priv, TRUE ) != "" )
                    {
                        return TRUE;
                    }
                }
                if ( is_array( $priv_info['SELF_ORG'] ) )
                {
                    $priv_user = empty( $priv_info['SELF_ORG']['USER'] ) ? "" : $priv_info['SELF_ORG']['USER'];
                    $priv_dept = empty( $priv_info['SELF_ORG']['DEPT'] ) ? "" : $priv_info['SELF_ORG']['DEPT'];
                    $priv_role = empty( $priv_info['SELF_ORG']['ROLE'] ) ? "" : $priv_info['SELF_ORG']['ROLE'];
                    if ( $priv_dept == "ALL_DEPT" || find_id( $priv_user, $user_id ) || find_id( $priv_dept, $user_dept ) || find_id( $priv_role, $user_priv ) || check_id( $priv_dept, $user_other_dept, TRUE ) != "" || check_id( $priv_role, $user_other_priv, TRUE ) != "" )
                    {
                        return TRUE;
                    }
                }
                if ( is_array( $priv_info['SELF_DEPT'] ) )
                {
                    $priv_user = empty( $priv_info['SELF_DEPT']['USER'] ) ? "" : $priv_info['SELF_DEPT']['USER'];
                    $priv_dept = empty( $priv_info['SELF_DEPT']['DEPT'] ) ? "" : $priv_info['SELF_DEPT']['DEPT'];
                    $priv_role = empty( $priv_info['SELF_DEPT']['ROLE'] ) ? "" : $priv_info['SELF_DEPT']['ROLE'];
                    if ( $priv_dept == "ALL_DEPT" || find_id( $priv_user, $user_id ) || find_id( $priv_dept, $user_dept ) || find_id( $priv_role, $user_priv ) || check_id( $priv_dept, $user_other_dept, TRUE ) != "" || check_id( $priv_role, $user_other_priv, TRUE ) != "" )
                    {
                        $self_depts = getselfdept( $user_dept );
                        if ( find_id( $self_depts, $begin_dept_id ) )
                        {
                            return TRUE;
                        }
                    }
                }
                if ( is_array( $priv_info['SELF_BRANCH'] ) )
                {
                    $priv_user = empty( $priv_info['SELF_BRANCH']['USER'] ) ? "" : $priv_info['SELF_BRANCH']['USER'];
                    $priv_dept = empty( $priv_info['SELF_BRANCH']['DEPT'] ) ? "" : $priv_info['SELF_BRANCH']['DEPT'];
                    $priv_role = empty( $priv_info['SELF_BRANCH']['ROLE'] ) ? "" : $priv_info['SELF_BRANCH']['ROLE'];
                    if ( ( $priv_dept == "ALL_DEPT" || find_id( $priv_user, $user_id ) || find_id( $priv_dept, $user_dept ) || find_id( $priv_role, $user_priv ) || check_id( $priv_dept, $user_other_dept, TRUE ) != "" || check_id( $priv_role, $user_other_priv, TRUE ) != "" ) && $user_dept == $begin_dept_id )
                    {
                        return TRUE;
                    }
                }
                foreach ( $priv_info as $priv_scope => $priv_scope_info )
                {
                    if ( $priv_scope == "ALL_DEPT" || $priv_scope == "SELF_ORG" || $priv_scope == "SELF_DEPT" )
                    {
                    }
                    else
                    {
                        continue;
                    }
                    $priv_user = empty( $priv_scope_info['USER'] ) ? "" : $priv_scope_info['USER'];
                    $priv_dept = empty( $priv_scope_info['DEPT'] ) ? "" : $priv_scope_info['DEPT'];
                    $priv_role = empty( $priv_scope_info['ROLE'] ) ? "" : $priv_scope_info['ROLE'];
                    if ( !( $priv_dept == "ALL_DEPT" ) && !find_id( $priv_user, $user_id ) && !find_id( $priv_dept, $user_dept ) && !find_id( $priv_role, $user_priv ) && !( check_id( $priv_dept, $user_other_dept, TRUE ) != "" ) && !( check_id( $priv_role, $user_other_priv, TRUE ) != "" ) || !find_id( $priv_scope, $begin_dept_id ) )
                    {
                        return TRUE;
                        break;
                    }
                }
            }
        }
    }
    return FALSE;
}

function getFlowPrivOfExcute( $flow_id, $user_id, $user_dept, $user_priv, $user_other_dept = "", $user_other_priv = "" )
{
    $flow_cache = ( "W_FLOW" );
    $flow_cache = $flow_cache[$flow_id];
    if ( $flow_cache['FLOW_TYPE'] == 1 )
    {
        $arr_prcs = ( "W_PROCESS_".$flow_id );
        if ( is_array( $arr_prcs ) )
        {
            foreach ( $arr_prcs as $prcs_id => $value )
            {
                $prcs_user = $value['PRCS_USER'];
                $prcs_dept = $value['PRCS_DEPT'];
                $prcs_priv = $value['PRCS_PRIV'];
                if ( !find_id( $prcs_dept, "ALL_DEPT" ) && !find_id( $prcs_user, $user_id ) && !find_id( $prcs_dept, $user_dept ) && !find_id( $prcs_priv, $user_priv ) && !( check_id( $prcs_dept, $user_other_dept, TRUE ) != "" ) && !( check_id( $prcs_priv, $user_other_priv, TRUE ) != "" ) )
                {
                    return TRUE;
                }
            }
        }
        return FALSE;
    }
    if ( $flow_cache['FLOW_TYPE'] == 2 )
    {
        return TRUE;
    }
}

function getFlowPrivOfCreate( $flow_id, $user_id, $user_dept, $user_priv, $user_other_dept = "", $user_other_priv = "" )
{
    $flow_cache = ( "W_FLOW" );
    $flow_cache = $flow_cache[$flow_id];
    if ( $flow_cache['FLOW_TYPE'] == 1 )
    {
        $arr_prcs = ( "W_PROCESS_".$flow_id );
        if ( is_array( $arr_prcs ) )
        {
            $prcs_user = $arr_prcs['1']['PRCS_USER'];
            $prcs_dept = $arr_prcs['1']['PRCS_DEPT'];
            $prcs_priv = $arr_prcs['1']['PRCS_PRIV'];
            if ( find_id( $prcs_dept, "ALL_DEPT" ) || find_id( $prcs_user, $user_id ) || find_id( $prcs_dept, $user_dept ) || find_id( $prcs_priv, $user_priv ) || check_id( $prcs_dept, $user_other_dept, TRUE ) != "" || check_id( $prcs_priv, $user_other_priv, TRUE ) != "" )
            {
                return TRUE;
            }
        }
        return FALSE;
    }
    if ( $flow_cache['FLOW_TYPE'] == 2 )
    {
        $PRIV_USER = $flow_cache['FREE_FLOW_NEW_USER'];
        $PRIV_DEPT = $flow_cache['FREE_FLOW_NEW_DEPT'];
        $PRIV_ROLE = $flow_cache['FREE_FLOW_NEW_PRIV'];
        if ( $PRIV_DEPT == "ALL_DEPT" || find_id( $PRIV_USER, $user_id ) || find_id( $PRIV_DEPT, $user_dept ) || find_id( $PRIV_ROLE, $user_priv ) || check_id( $PRIV_ROLE, $user_other_priv, TRUE ) != "" || check_id( $PRIV_DEPT, $user_other_dept, TRUE ) != "" )
        {
            return TRUE;
        }
        return FALSE;
    }
}

function getFlowPrivOfAdminRole( $user_id, $user_priv, $user_other_priv = "" )
{
    if ( $user_priv == 1 || find_id( $user_other_priv, 1 ) )
    {
        return TRUE;
    }
    return FALSE;
}

function getPrivQueryCondition( $str_flow = NULL, $priv_str = NULL, $user_id, $user_dept, $user_priv, $user_other_dept, $user_other_priv, $archive = "", $archive_id = "" )
{
    cache_flow_type( );
    $flow_cache = ( "W_FLOW" );
    $where_definition = "";
    $all_flows = "";
    foreach ( $flow_cache as $flow_id => $flow_info )
    {
        if ( !empty( $str_flow ) && $str_flow != "" && !find_id( $str_flow, $flow_id ) )
        {
        }
        else
        {
            $dept_ids = "";
            $arr_priv = $flow_info['PRIV'];
            if ( is_array( $arr_priv ) )
            {
                $dept_ids = "";
                foreach ( $arr_priv as $priv_type => $priv_info )
                {
                    if ( find_id( $all_flows, $flow_id ) )
                    {
                    }
                    else if ( !( !( $priv_str == NULL ) && !( $priv_type == "0" ) && !find_id( $priv_str, $priv_type ) ) )
                    {
                        continue;
                    }
                    else if ( is_array( $priv_info['ALL_DEPT'] ) )
                    {
                        $priv_user = empty( $priv_info['ALL_DEPT']['USER'] ) ? "" : $priv_info['ALL_DEPT']['USER'];
                        $priv_dept = empty( $priv_info['ALL_DEPT']['DEPT'] ) ? "" : $priv_info['ALL_DEPT']['DEPT'];
                        $priv_role = empty( $priv_info['ALL_DEPT']['ROLE'] ) ? "" : $priv_info['ALL_DEPT']['ROLE'];
                        if ( $priv_dept == "ALL_DEPT" || find_id( $priv_user, $user_id ) || find_id( $priv_dept, $user_dept ) || find_id( $priv_role, $user_priv ) || check_id( $priv_dept, $user_other_dept, TRUE ) != "" || check_id( $priv_role, $user_other_priv, TRUE ) != "" )
                        {
                            $all_flows .= $flow_id.",";
                            break;
                        }
                    }
                    else
                    {
                        if ( is_array( $priv_info['SELF_ORG'] ) )
                        {
                            $priv_user = empty( $priv_info['SELF_ORG']['USER'] ) ? "" : $priv_info['SELF_ORG']['USER'];
                            $priv_dept = empty( $priv_info['SELF_ORG']['DEPT'] ) ? "" : $priv_info['SELF_ORG']['DEPT'];
                            $priv_role = empty( $priv_info['SELF_ORG']['ROLE'] ) ? "" : $priv_info['SELF_ORG']['ROLE'];
                            if ( $priv_dept == "ALL_DEPT" || find_id( $priv_user, $user_id ) || find_id( $priv_dept, $user_dept ) || find_id( $priv_role, $user_priv ) || check_id( $priv_dept, $user_other_dept, TRUE ) != "" || check_id( $priv_role, $user_other_priv, TRUE ) != "" )
                            {
                                $all_flows .= $flow_id.",";
                                break;
                            }
                        }
                        else
                        {
                            if ( is_array( $priv_info['SELF_DEPT'] ) )
                            {
                                $priv_user = empty( $priv_info['SELF_DEPT']['USER'] ) ? "" : $priv_info['SELF_DEPT']['USER'];
                                $priv_dept = empty( $priv_info['SELF_DEPT']['DEPT'] ) ? "" : $priv_info['SELF_DEPT']['DEPT'];
                                $priv_role = empty( $priv_info['SELF_DEPT']['ROLE'] ) ? "" : $priv_info['SELF_DEPT']['ROLE'];
                                if ( $priv_dept == "ALL_DEPT" || find_id( $priv_user, $user_id ) || find_id( $priv_dept, $user_dept ) || find_id( $priv_role, $user_priv ) || check_id( $priv_dept, $user_other_dept, TRUE ) != "" || check_id( $priv_role, $user_other_priv, TRUE ) != "" )
                                {
                                    $self_depts = getselfdept( $user_dept );
                                    $dept_ids = str_merge( $dept_ids, $self_depts );
                                }
                            }
                            if ( is_array( $priv_info['SELF_BRANCH'] ) )
                            {
                                $priv_user = empty( $priv_info['SELF_BRANCH']['USER'] ) ? "" : $priv_info['SELF_BRANCH']['USER'];
                                $priv_dept = empty( $priv_info['SELF_BRANCH']['DEPT'] ) ? "" : $priv_info['SELF_BRANCH']['DEPT'];
                                $priv_role = empty( $priv_info['SELF_BRANCH']['ROLE'] ) ? "" : $priv_info['SELF_BRANCH']['ROLE'];
                                if ( $priv_dept == "ALL_DEPT" || find_id( $priv_user, $user_id ) || find_id( $priv_dept, $user_dept ) || find_id( $priv_role, $user_priv ) || check_id( $priv_dept, $user_other_dept, TRUE ) != "" || check_id( $priv_role, $user_other_priv, TRUE ) != "" )
                                {
                                    $dept_ids = str_merge( $dept_ids, $user_dept );
                                }
                            }
                            foreach ( $priv_info as $priv_scope => $priv_scope_info )
                            {
                                if ( $priv_scope == "ALL_DEPT" || $priv_scope == "SELF_ORG" || $priv_scope == "SELF_DEPT" )
                                {
                                }
                                else
                                {
                                    continue;
                                }
                                $priv_user = empty( $priv_scope_info['USER'] ) ? "" : $priv_scope_info['USER'];
                                $priv_dept = empty( $priv_scope_info['DEPT'] ) ? "" : $priv_scope_info['DEPT'];
                                $priv_role = empty( $priv_scope_info['ROLE'] ) ? "" : $priv_scope_info['ROLE'];
                                if ( !( $priv_dept == "ALL_DEPT" ) && !find_id( $priv_user, $user_id ) && !find_id( $priv_dept, $user_dept ) && !find_id( $priv_role, $user_priv ) && !( check_id( $priv_dept, $user_other_dept, TRUE ) != "" ) && !( check_id( $priv_role, $user_other_priv, TRUE ) != "" ) )
                                {
                                    $dept_ids = str_merge( $dept_ids, $priv_scope );
                                }
                            }
                        }
                    }
                }
            }
            if ( !( find_id( $all_flows, $flow_id ) || !( $dept_ids != "" ) ) )
            {
                continue;
            }
            else if ( strpos( $dept_ids, "," ) === FALSE )
            {
                $where_definition .= " OR (".$archive."FLOW_RUN".$archive_id.".FLOW_ID = '".$flow_id."' AND FLOW_RUN".$archive_id.".BEGIN_DEPT = '".$dept_ids."') ";
            }
            else
            {
                $where_definition .= " OR (".$archive."FLOW_RUN".$archive_id.".FLOW_ID = '".$flow_id."' AND FLOW_RUN".$archive_id.".BEGIN_DEPT IN (".$dept_ids.")) ";
            }
        }
    }
    if ( $all_flows != "" )
    {
        $all_flows = substr( $all_flows, 0, -1 );
        if ( $where_definition != "" )
        {
            $where_definition = "(".$archive."FLOW_RUN".$archive_id.".FLOW_ID IN (".$all_flows.") ".$where_definition.") ";
            return $where_definition;
        }
        $where_definition = "".$archive."FLOW_RUN".$archive_id.".FLOW_ID IN (".$all_flows.") ";
        return $where_definition;
    }
    if ( $where_definition != "" )
    {
        $where_definition = "(".substr( $where_definition, 4 ).")";
    }
    return $where_definition;
}

?>
