<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
function getFlowPrcsName( $flow_id, $flow_prcs )
{
    $cache = ( "W_PROCESS_".$flow_id );
    return $cache[$flow_prcs]['PRCS_NAME'];
}

function getRunPrcsName( $run_id, $prcs_id, $flow_prcs, $op_flag, $prcs_key_id = "" )
{
    $r_connection = ( );
    $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
    $select_exprs = $OBJ_SQL_SYNTAX->getSelectExprs( "RUN_PRCS_NAME" );
    $table_references = $OBJ_SQL_SYNTAX->getTableReferences( "flow_run_prcs" );
    $conditions = array( );
    if ( $prcs_key_id )
    {
        array_push( &$conditions, $OBJ_SQL_SYNTAX->getConditionExpr( "ID", EXPR_OP_IS, $prcs_key_id, FIELD_TYPE_INT ) );
    }
    array_push( &$conditions, $OBJ_SQL_SYNTAX->getConditionExpr( "RUN_ID", EXPR_OP_IS, $run_id, FIELD_TYPE_INT ) );
    array_push( &$conditions, $OBJ_SQL_SYNTAX->getConditionExpr( "PRCS_ID", EXPR_OP_IS, $prcs_id, FIELD_TYPE_INT ) );
    array_push( &$conditions, $OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_PRCS", EXPR_OP_IS, $flow_prcs, FIELD_TYPE_INT ) );
    array_push( &$conditions, $OBJ_SQL_SYNTAX->getConditionExpr( "OP_FLAG", EXPR_OP_IS, $op_flag, FIELD_TYPE_INT ) );
    $where_definitions = $OBJ_SQL_SYNTAX->getWhereDefinition( $conditions, CONDITION_LOGIC_OP_AND );
    $sql = $OBJ_SQL_SYNTAX->getQuerySQL( 0, 0, $select_exprs, $table_references, $where_definitions );
    $r_cursor = exequery( $r_connection, $sql, TRUE );
    while ( $row = mysql_fetch_array( $r_cursor ) )
    {
        $run_prcs_name = $row['RUN_PRCS_NAME'];
    }
    return $run_prcs_name;
}

function getPrcsType( $flow_id, $prcs_id )
{
    $r_connection = ( );
    $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
    $select_exprs = $OBJ_SQL_SYNTAX->getSelectExprs( "PRCS_TYPE" );
    $table_references = $OBJ_SQL_SYNTAX->getTableReferences( "flow_process" );
    $conditions = array( );
    array_push( &$conditions, $OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_ID", EXPR_OP_IS, $flow_id, FIELD_TYPE_INT ) );
    array_push( &$conditions, $OBJ_SQL_SYNTAX->getConditionExpr( "PRCS_ID", EXPR_OP_IS, $prcs_id, FIELD_TYPE_INT ) );
    $where_definitions = $OBJ_SQL_SYNTAX->getWhereDefinition( $conditions, CONDITION_LOGIC_OP_AND );
    $sql = $OBJ_SQL_SYNTAX->getQuerySQL( 0, 0, $select_exprs, $table_references, $where_definitions );
    $r_cursor = exequery( $r_connection, $sql, TRUE );
    while ( $row = mysql_fetch_array( $r_cursor ) )
    {
        $prcs_type = $row['PRCS_TYPE'];
    }
    return $prcs_type;
}

function getFlowPrcsRemindFlag( $flow_id, $flow_prcs )
{
    $cache = ( "W_PROCESS_".$flow_id );
    $remind_sys = get_sys_para( "SMS_REMIND" );
    $remind_sys_flag_array = explode( "|", $remind_sys['SMS_REMIND'] );
    $remind_sys_flag_allow_array = explode( ",", $remind_sys_flag_array[2] );
    $remind_sys_flag_default_array = explode( ",", $remind_sys_flag_array[0] );
    $remind_sys_flag_default_mobile_array = explode( ",", $remind_sys_flag_array[1] );
    $sms2_module = "";
    $sms2_remind_priv = array( );
    $sms_mobile_next_prcs = TRUE;
    $sms_mobile_all_users = TRUE;
    $sms_mobile_begin_user = TRUE;
    $query_sms2 = "select type_priv,sms2_remind_priv from sms2_priv";
    $cursor_sms2 = exequery( ( ), $query_sms2 );
    if ( $row = mysql_fetch_array( $cursor_sms2 ) )
    {
        $sms2_module = $row['type_priv'];
        $sms2_remind_priv = explode( ",", $row['sms2_remind_priv'] );
    }
    if ( $sms2_module == "" )
    {
        $sms_mobile_next_prcs = FALSE;
        $sms_mobile_all_users = FALSE;
        $sms_mobile_begin_user = FALSE;
    }
    else
    {
        $arr_sms_mobile = explode( ",", $sms2_module );
        if ( in_array( "7", $arr_sms_mobile ) )
        {
            $sms_mobile_next_prcs = FALSE;
        }
        if ( in_array( 40, $arr_sms_mobile ) )
        {
            $sms_mobile_begin_user = FALSE;
        }
        if ( in_array( "41", $arr_sms_mobile ) )
        {
            $sms_mobile_all_users = FALSE;
        }
    }
    $remind_flag = $cache[$flow_prcs]['REMIND_FLAG'];
    if ( 0 < ( $remind_flag & 512 ) )
    {
        $remind_str = "";
        if ( in_array( "7", $remind_sys_flag_allow_array ) )
        {
            $remind_str .= "2,2,2,";
        }
        else
        {
            if ( 0 < ( $remind_flag & 256 ) )
            {
                $remind_str .= "1,";
            }
            else
            {
                $remind_str .= "0,";
            }
            if ( !$sms_mobile_next_prcs || !in_array( $_SESSION['LOGIN_USER_ID'], $sms2_remind_priv ) )
            {
                $remind_str .= "2,";
            }
            else if ( 0 < ( $remind_flag & 128 ) )
            {
                $remind_str .= "1,";
            }
            else
            {
                $remind_str .= "0,";
            }
            if ( 0 < ( $remind_flag & 64 ) )
            {
                $remind_str .= "1,";
            }
            else
            {
                $remind_str .= "0,";
            }
        }
        if ( in_array( "40", $remind_sys_flag_allow_array ) )
        {
            $remind_str .= "2,2,2,";
        }
        else
        {
            if ( 0 < ( $remind_flag & 32 ) )
            {
                $remind_str .= "1,";
            }
            else
            {
                $remind_str .= "0,";
            }
            if ( !$sms_mobile_all_users || !in_array( $_SESSION['LOGIN_USER_ID'], $sms2_remind_priv ) )
            {
                $remind_str .= "2,";
            }
            else if ( 0 < ( $remind_flag & 16 ) )
            {
                $remind_str .= "1,";
            }
            else
            {
                $remind_str .= "0,";
            }
            if ( 0 < ( $remind_flag & 8 ) )
            {
                $remind_str .= "1,";
            }
            else
            {
                $remind_str .= "0,";
            }
        }
        if ( in_array( "41", $remind_sys_flag_allow_array ) )
        {
            $remind_str .= "2,2,2,";
            return $remind_str;
        }
        if ( 0 < ( $remind_flag & 4 ) )
        {
            $remind_str .= "1,";
        }
        else
        {
            $remind_str .= "0,";
        }
        if ( !$sms_mobile_begin_user || !in_array( $_SESSION['LOGIN_USER_ID'], $sms2_remind_priv ) )
        {
            $remind_str .= "2,";
        }
        else if ( 0 < ( $remind_flag & 2 ) )
        {
            $remind_str .= "1,";
        }
        else
        {
            $remind_str .= "0,";
        }
        if ( 0 < ( $remind_flag & 1 ) )
        {
            $remind_str .= "1";
            return $remind_str;
        }
        $remind_str .= "0";
        return $remind_str;
    }
    $remind_str = "";
    if ( in_array( "7", $remind_sys_flag_allow_array ) )
    {
        $remind_str .= "2,2,2,";
    }
    else
    {
        if ( in_array( "7", $remind_sys_flag_default_array ) )
        {
            $remind_str .= "1,";
        }
        else
        {
            $remind_str .= "0,";
        }
        if ( !$sms_mobile_next_prcs || !in_array( $_SESSION['LOGIN_USER_ID'], $sms2_remind_priv ) )
        {
            $remind_str .= "2,";
        }
        else if ( in_array( "7", $remind_sys_flag_default_mobile_array ) )
        {
            $remind_str .= "1,";
        }
        else
        {
            $remind_str .= "0,";
        }
        $remind_str .= "0,";
    }
    if ( in_array( "40", $remind_sys_flag_allow_array ) )
    {
        $remind_str .= "2,2,2,";
    }
    else
    {
        if ( in_array( "40", $remind_sys_flag_default_array ) )
        {
            $remind_str .= "1,";
        }
        else
        {
            $remind_str .= "0,";
        }
        if ( !$sms_mobile_begin_user || !in_array( $_SESSION['LOGIN_USER_ID'], $sms2_remind_priv ) )
        {
            $remind_str .= "2,";
        }
        else if ( in_array( "40", $remind_sys_flag_default_mobile_array ) )
        {
            $remind_str .= "1,";
        }
        else
        {
            $remind_str .= "0,";
        }
        $remind_str .= "0,";
    }
    if ( in_array( "41", $remind_sys_flag_allow_array ) )
    {
        $remind_str .= "2,2,2,";
        return $remind_str;
    }
    if ( in_array( "41", $remind_sys_flag_default_array ) )
    {
        $remind_str .= "1,";
    }
    else
    {
        $remind_str .= "0,";
    }
    if ( !$sms_mobile_all_users || !in_array( $_SESSION['LOGIN_USER_ID'], $sms2_remind_priv ) )
    {
        $remind_str .= "2,";
    }
    else if ( in_array( "41", $remind_sys_flag_default_mobile_array ) )
    {
        $remind_str .= "1,";
    }
    else
    {
        $remind_str .= "0,";
    }
    $remind_str .= "0,";
    return $remind_str;
}

function getAllFlowPrcsInfo( $flow_id )
{
    $cache = ( "W_PROCESS_".$flow_id );
    return $cache;
}

function getFlowPrcsInfo( $flow_id, $flow_prcs )
{
    $cache = ( "W_PROCESS_".$flow_id );
    return $cache[$flow_prcs];
}

function getFlowName( $flow_id )
{
    $cache = ( "W_FLOW" );
    return $cache[$flow_id]['FLOW_NAME'];
}

function getFlowInfo( $flow_id )
{
    $cache = ( "W_FLOW" );
    return $cache[$flow_id];
}

function getFlowDeputeType( $flow_id )
{
    $cache = ( "W_FLOW" );
    return $cache[$flow_id]['FREE_OTHER'];
}

function getAllPrevPrcs( $flow_id, $flow_prcs, $used_flow_prcs_str = "" )
{
    if ( find_id( $used_flow_prcs_str, $flow_prcs ) )
    {
        $used_flow_prcs_str .= $flow_prcs.",";
    }
    else
    {
        return "";
    }
    $prev_prcs = "";
    $cache = ( "W_PROCESS_".$flow_id );
    if ( is_array( $cache[$flow_prcs] ) )
    {
        return "";
    }
    if ( is_array( $cache ) )
    {
        foreach ( $cache as $key => $info )
        {
            if ( find_id( $info['PRCS_TO'], $flow_prcs ) )
            {
                $prev_prcs .= $key.",";
                if ( $key != 1 )
                {
                    $thePrevPrcs = getallprevprcs( $flow_id, $key, $used_flow_prcs_str );
                    if ( $thePrevPrcs )
                    {
                        $prev_prcs .= $thePrevPrcs.",";
                    }
                }
            }
        }
        if ( is_array( $cache[$flow_prcs - 1] ) && ( $cache[$flow_prcs - 1]['PRCS_TO'] == NULL || $cache[$flow_prcs - 1]['PRCS_TO'] == "" ) )
        {
            $thePrevPrcs = getallprevprcs( $flow_id, $flow_prcs - 1, $used_flow_prcs_str );
            if ( $thePrevPrcs )
            {
                $prev_prcs .= $thePrevPrcs.",";
            }
            $prev_prcs .= ( $flow_prcs - 1 ).",";
        }
    }
    $prev_prcs = td_trim( str_remove_dup( $prev_prcs ) );
    return $prev_prcs;
}

function getPrevPrcs( $flow_id, $flow_prcs, $array_flag = FALSE )
{
    $prev_prcs = "";
    $cache = ( "W_PROCESS_".$flow_id );
    if ( is_array( $cache[$flow_prcs] ) )
    {
        return "";
    }
    if ( is_array( $cache ) )
    {
        foreach ( $cache as $key => $info )
        {
            if ( find_id( $info['PRCS_TO'], $flow_prcs ) )
            {
                $prev_prcs .= $key.",";
            }
        }
        if ( is_array( $cache[$flow_prcs - 1] ) && ( $cache[$flow_prcs - 1]['PRCS_TO'] == NULL || $cache[$flow_prcs - 1]['PRCS_TO'] == "" ) )
        {
            $prev_prcs .= ( $flow_prcs - 1 ).",";
        }
    }
    $prev_prcs = td_trim( str_remove_dup( $prev_prcs ) );
    if ( $array_flag )
    {
        if ( $prev_prcs != "" )
        {
            return explode( ",", $prev_prcs );
        }
    }
    else
    {
        return $prev_prcs;
    }
}

function getAllPathPrcs( $flow_id, $flow_prcs )
{
    $stack = array( );
    $stack[] = $flow_prcs;
    $path_nodes = "";
    while ( 0 < count( $stack ) )
    {
        $cur_node = array_shift( &$stack );
        $arr_prev = getprevprcs( $flow_id, $cur_node, TRUE );
        $str_prev = getprevprcs( $flow_id, $cur_node, FALSE );
        if ( is_array( $arr_prev ) )
        {
            foreach ( $arr_prev as $prev_node )
            {
                if ( find_id( $path_nodes, $prev_node ) )
                {
                    $path_nodes .= $prev_node.",";
                    $stack[] = $prev_node;
                }
            }
        }
    }
    $path_nodes = str_remove_dup( td_trim( $path_nodes ) );
    return $path_nodes;
}

function getTimeOutConfig( $flow_id, $flow_prcs )
{
    $cache = ( "W_PROCESS_".$flow_id );
    $config = array( );
    $config['TIME_OUT'] = $cache[$flow_prcs]['TIME_OUT'];
    $config['TIME_OUT_MODIFY'] = $cache[$flow_prcs]['TIME_OUT_MODIFY'];
    $config['TIME_OUT_TYPE'] = $cache[$flow_prcs]['TIME_OUT_TYPE'];
    $config['TIME_OUT_ATTEND'] = $cache[$flow_prcs]['TIME_OUT_ATTEND'];
    return $config;
}

function getDeputeConfig( $flow_id )
{
    $cache = ( "W_FLOW" );
    return $cache[$flow_id]['FREE_OTHER'];
}

function getMaxPrcsId( $flow_id )
{
    $cache = ( "W_FLOW" );
    return $cache[$flow_id]['MAX_PRCS_ID'];
}

function td_htmlspecial( $Character )
{
    $search = array( "/\\'/", "/\\\"/", "/\\//", "/\\\\/" );
    $replace = array( "&#39;", "&#34;", "&#47;", "&#47;" );
    $Character = preg_replace( $search, $replace, $Character );
    return $Character;
}

function is_new_first_prcs( $run_id, $prcs_id, $flow_prcs, $prcs_key_id = "" )
{
    $condition = $prcs_key_id ? " and id='".$prcs_key_id."' " : " ";
    $sql = "select parent, parent_prcs_id from flow_run_prcs where run_id = '".$run_id."'".$condition." and prcs_id = '".$prcs_id."' and flow_prcs='".$flow_prcs."' limit 0, 1";
    $r_cursor = exequery( ( ), $sql, TRUE );
    if ( $row = mysql_fetch_array( $r_cursor ) )
    {
        $parent = $row['parent'];
        $parent_prcs_id = $row['parent_prcs_id'];
        if ( $parent == 0 && $parent_prcs_id == 0 )
        {
            return TRUE;
        }
        return FALSE;
    }
    return TRUE;
}

include_once( "inc/workflow/inc/workflow.cache.php" );
include_once( "inc/utility_all.php" );
if ( function_exists( "getFlowRunPrcsById" ) )
{
    function getFlowRunPrcsById( $id, $check_current_user = TRUE )
    {
        $condition = $check_current_user ? " and USER_ID='".$_SESSION['LOGIN_USER_ID']."'" : "";
        $sql = "select * from flow_run_prcs where ID='".$id."'".$condition;
        $r_cursor = exequery( ( ), $sql, TRUE );
        if ( $row = mysql_fetch_array( $r_cursor ) )
        {
            return $row;
        }
        return FALSE;
    }
}
?>
