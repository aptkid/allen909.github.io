<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
function getOpOfWork( $run_id, $prcs_id, $flow_prcs, $user_id )
{
    $obj_work_item = ( $run_id, $prcs_id, $flow_prcs, $user_id, "ID,OP_FLAG" );
    if ( isset( $obj_work_item ) )
    {
        $op_flag = $obj_work_item->_get( "op_flag" );
        return $op_flag;
    }
    $op_flag = -1;
    return $op_flag;
}

function getPrcsFlagOfWork( $run_id, $prcs_id, $flow_prcs, $user_id )
{
    $obj_work_item = ( $run_id, $prcs_id, $flow_prcs, $user_id, "ID,PRCS_FLAG" );
    if ( isset( $obj_work_item ) )
    {
        $prcs_flag = $obj_work_item->_get( "prcs_flag" );
        return $prcs_flag;
    }
    $prcs_flag = -1;
    return $prcs_flag;
}

function isDeputerOfWork( $run_id, $prcs_id, $flow_prcs, $user_id, $r_connection = NULL )
{
    $flag = FALSE;
    $obj_work_item = ( $run_id, $prcs_id, $flow_prcs, $user_id, "ID,OTHER_USER" );
    if ( isset( $obj_work_item ) )
    {
        $other_user = $obj_work_item->_get( "other_user" );
        if ( strpos( $other_user, $user_id."," ) == 0 || strpos( $other_user, ",".$user_id."," ) !== FALSE )
        {
            $flag = TRUE;
            return $flag;
        }
        $flag = FALSE;
        return $flag;
    }
    $flag = FALSE;
    return $flag;
}

function isViewerOfFlow( $run_id, $user_id, $r_connection = NULL )
{
    $op_flag = FALSE;
    if ( $r_connection == NULL )
    {
        $r_connection = ( );
    }
    $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
    $select_expr = $OBJ_SQL_SYNTAX->getSelectExprs( " RUN_ID " );
    $table_references = $OBJ_SQL_SYNTAX->getTableReferences( "flow_run" );
    $conditions = array( );
    array_push( &$conditions, $OBJ_SQL_SYNTAX->getConditionExpr( "RUN_ID", EXPR_OP_IS, $run_id, FIELD_TYPE_INT ) );
    array_push( &$conditions, $OBJ_SQL_SYNTAX->getConditionExpr( "VIEW_USER", EXPR_OP_FIND_IN_SET, $user_id, FIELD_TYPE_CHAR ) );
    $where_definition = $OBJ_SQL_SYNTAX->getWhereDefinition( $definitions, CONDITION_LOGIC_OP_AND );
    $sql = $OBJ_SQL_SYNTAX->getQuerySQL( 0, 0, $select_expr, $table_references, $where_definition );
    $r_cursor = exequery( $r_connection, $sql );
    if ( $row = mysql_fetch_array( $r_cursor ) )
    {
        $op_flag = TRUE;
    }
    return $op_flag;
}

function getFocusUser( $run_id, $r_connection = NULL )
{
    if ( $r_connection == NULL )
    {
        $r_connection = ( );
    }
    $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
    $select_exprs = $OBJ_SQL_SYNTAX->getSelectExprs( " FOCUS_USER " );
    $table_references = $OBJ_SQL_SYNTAX->getTableReferences( "flow_run" );
    $where_definition = $OBJ_SQL_SYNTAX->getConditionExpr( "RUN_ID", EXPR_OP_IS, $run_id, FIELD_TYPE_INT );
    $focus_user = "";
    $sql = $OBJ_SQL_SYNTAX->getQuerySQL( 0, 0, $select_exprs, $table_references, $where_definition );
    $r_cursor = exequery( $r_connection, $sql );
    if ( $row = mysql_fetch_array( $r_cursor ) )
    {
        $focus_user = $row['FOCUS_USER'];
    }
    return $focus_user;
}

function getWorkItemTime( $user_id, $create_time, $prcs_time, $deliver_time, $time_out_config )
{
    if ( $time_out_config['TIME_OUT_TYPE'] == "0" )
    {
        if ( $prcs_time == "0000-00-00 00:00:00" )
        {
            return 0;
        }
        $from_time = strtotime( $prcs_time );
    }
    else if ( $time_out_config['TIME_OUT_TYPE'] == "1" )
    {
        $from_time = strtotime( $create_time );
    }
    if ( $deliver_time != NULL && $deliver_time != "0000-00-00 00:00:00" )
    {
        $to_time = strtotime( $deliver_time );
    }
    else
    {
        $to_time = time( );
    }
    if ( $time_out_config['TIME_OUT_ATTEND'] == "0" )
    {
        $schedule = array( );
        $schedule['holiday'] = "";
        $schedule['work'] = array( );
        $schedule['work'][0]['from'] = "00:00:00";
        $schedule['work'][0]['to'] = "24:00:00";
    }
    else if ( $time_out_config['TIME_OUT_ATTEND'] == "1" )
    {
        $schedule = getworkschedule( $user_id );
    }
    return calworktime( $from_time, $to_time, $schedule );
}

function get_depute_user_by_rule( $flow_id, $user_id )
{
    $cur_date = date( "Y-m-d H:i:s", time( ) );
    $result = "";
    $flow_info = getflowinfo( $flow_id );
    if ( $flow_info['FREE_OTHER'] == 2 )
    {
        $where_definition = "WHERE FLOW_ID = '".$flow_id."' AND USER_ID='".$user_id."' AND STATUS=1";
        $where_definition .= "( (BEGIN_DATE = '0000-00-00 00:00:00' AND END_DATE = '0000-00-00 00:00:00') ";
        $where_definition .= " OR (BEGIN_DATE = '0000-00-00 00:00:00' AND END_DATE >= '".$cur_date."') ";
        $where_definition .= " OR (END_DATE = '0000-00-00 00:00:00' AND BEGIN_DATE <= '".$cur_date."') ";
        $where_definition .= " OR (BEGIN_DATE <= '".$cur_time."' AND END_DATE >= '".$cur_date."') ) ";
        $order_by_definition = " ORDER BY RULE_ID DESC ";
        $limit_definition = " limit 0, 1 ";
        $sql = "SELECT TO_ID FROM flow_rule ".$where_definition.$order_by_definition.$limit_definition;
        $cursor = exequery( ( ), $sql );
        if ( $row = mysql_fetch_array( $cursor ) )
        {
            $result = $row['TO_ID'];
        }
        return $result;
    }
}

function getPrcsNodeInfo( $run_id, $prcs_id, $flow_prcs )
{
    $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
    $select_exprs = "top_flag, op_flag, user_id, deliver_time ";
    $conditions = array( );
    $conditions[] = $OBJ_SQL_SYNTAX->getConditionExpr( "RUN_ID", EXPR_OP_IS, $run_id, FIELD_TYPE_INT );
    $conditions[] = $OBJ_SQL_SYNTAX->getConditionExpr( "PRCS_ID", EXPR_OP_IS, $prcs_id, FIELD_TYPE_INT );
    $conditions[] = $OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_PRCS", EXPR_OP_IS, $flow_prcs, FIELD_TYPE_INT );
    $where_definitions = $OBJ_SQL_SYNTAX->getWhereDefinition( $conditions, CONDITION_LOGIC_OP_AND );
    $order_definition = $OBJ_SQL_SYNTAX->getOrderByDefinition( "OP_FLAG", ORDER_DIR_DESC );
    $sql = $OBJ_SQL_SYNTAX->getQuerySQL( 0, 0, $select_exprs, "flow_run_prcs", $where_definitions, $order_definition );
    $result = array( );
    $cursor = exequery( ( ), $sql, TRUE );
    while ( $row = mysql_fetch_array( $cursor ) )
    {
        $result[] = array( "USER_ID" => $row['user_id'], "OP_FLAG" => $row['op_flag'], "TOP_FLAG" => $row['top_flag'], "DELIVER_TIME" => $row['deliver_time'] );
    }
    return $result;
}

?>
