<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class WorkItem
{

    public static $WORK_PRCS_STATUS_INIT = 5;
    public static $WORK_PRCS_STATUS_NOT_ACCEPT = 1;
    public static $WORK_PRCS_STATUS_DOING = 2;
    public static $WORK_PRCS_STATUS_NEXT = 3;
    public static $WORK_PRCS_STATUS_FINISH = 4;
    public static $WORK_PRCS_STATUS_HANG_UP = 6;
    private $id = 0;
    private $user_id;
    private $flow_id = 0;
    private $run_id = 0;
    private $run_name;
    private $work_level;
    private $flow_prcs = 0;
    private $prcs_id = 0;
    private $parent;
    private $op_flag = 1;
    private $prcs_flag = 1;
    private $top_flag = 0;
    private $time_out_flag = 0;
    private $time_out;
    private $work_item;
    private $flow_start_user;
    private $flow_create_time;
    private $flow_end_time;
    private $create_time;
    private $prcs_time;
    private $deliver_time;
    private $other_user;
    private $active_time;
    private $free_item;
    private $child_run;
    private $comment;
    private $prcs_dept;
    private $time_out_type;
    private $time_out_attend;

    public function _set( $property_name, $value )
    {
        $property_name = strtolower( $property_name );
        $this->$property_name = $value;
    }

    public function _get( $property_name )
    {
        $property_name = strtolower( $property_name );
        if ( isset( $this->$property_name ) )
        {
            return $this->$property_name;
        }
    }

    public function getFlowPrcsName( )
    {
        return getflowprcsname( $this->flow_id, $this->flow_prcs );
    }

    public function ifEndOfWorkFlow( )
    {
        if ( isset( $this->flow_end_time ) && $this->flow_end_time != "00-00-00 00:00:00" )
        {
            return FALSE;
        }
        return TRUE;
    }

    public function getProcessTime( )
    {
        $schedule['holiday'] = "";
        $schedule['work'][0]['from'] = "00:00:00";
        $schedule['work'][0]['from'] = "24:00:00";
        do
        {
            if ( $this->prcs_flag == self::$WORK_PRCS_STATUS_DOING )
            {
                break;
            }
            else
            {
            }
            if ( $this->prcs_flag == self::$WORK_PRCS_STATUS_HANG_UP )
            {
            }
        } while ( 0 );
        return calworktime( strtotime( $this->prcs_time ), time( ), $schedule );
        do
        {
            if ( $this->prcs_flag == self::$WORK_PRCS_STATUS_NEXT )
            {
                break;
            }
            else
            {
            }
            if ( $this->prcs_flag == self::$WORK_PRCS_STATUS_FINISH )
            {
            }
        } while ( 0 );
        return calworktime( strtotime( $this->prcs_time ), strtotime( $this->deliver_time ), $schedule );
        return 0;
    }

    public function getStayTime( )
    {
        $schedule['holiday'] = "";
        $schedule['work'][0]['from'] = "00:00:00";
        $schedule['work'][0]['from'] = "24:00:00";
        do
        {
            if ( $this->prcs_flag == self::$WORK_PRCS_STATUS_NOT_ACCEPT )
            {
                break;
            }
            else
            {
                if ( $this->prcs_flag == self::$WORK_PRCS_STATUS_DOING )
                {
                    break;
                }
                else
                {
                }
            }
            if ( $this->prcs_flag == self::$WORK_PRCS_STATUS_HANG_UP )
            {
            }
        } while ( 0 );
        return calworktime( strtotime( $this->create_time ), time( ), $schedule );
        do
        {
            if ( $this->prcs_flag == self::$WORK_PRCS_STATUS_NEXT )
            {
                break;
            }
            else
            {
            }
            if ( $this->prcs_flag == self::$WORK_PRCS_STATUS_FINISH )
            {
            }
        } while ( 0 );
        return calworktime( strtotime( $this->create_time ), strtotime( $this->deliver_time ), $schedule );
        return 0;
    }

    public function calTimeOut( $work_schedule, $r_connection = NULL )
    {
        $config = gettimeoutconfig( $this->flow_id, $this->flow_prcs );
        if ( !isset( $config['TIME_OUT'] ) || !is_numeric( $config['TIME_OUT'] ) )
        {
            return 0;
        }
        if ( $config['TIME_OUT_TYPE'] == 0 )
        {
            do
            {
                if ( $this->prcs_flag == self::$WORK_PRCS_STATUS_NOT_ACCEPT )
                {
                    break;
                }
                else
                {
                }
                if ( $this->prcs_flag == self::$WORK_PRCS_STATUS_INIT )
                {
                }
            } while ( 0 );
            return 0;
            $start_time = $this->deliver_time;
        }
        else
        {
            $start_time = $this->create_time;
        }
        if ( $config['TIME_OUT_ATTEND'] == 0 )
        {
            $schedule = $work_schedule;
        }
        else
        {
            $schedule['holiday'] = "";
            $schedule['work'][0]['from'] = "00:00:00";
            $schedule['work'][0]['to'] = "24:00:00";
        }
        if ( isset( $this->deliver_time ) && $this->deliver_time != "" )
        {
            $end_time = strtotime( $this->deliver_time );
        }
        else
        {
            $end_time = time( );
        }
        $work_time = calworktime( strtotime( $start_time ), time( ), $schedule );
        $limit_time = $config['TIME_OUT'] * 3600;
        if ( $limit_time < $work_time )
        {
            return $work_time - $limit_time;
        }
        return 0;
    }

}

?>
