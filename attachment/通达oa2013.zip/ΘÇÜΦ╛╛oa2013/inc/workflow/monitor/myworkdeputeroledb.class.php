<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class MyWorkDeputeRoleDB extends ObjDB
{

    private $flow_id;
    private $status;
    private $user_id;
    private $to_id;
    private $order_field;
    private $order_directory;
    private $start_pos = 0;
    private $row_number = 10;

    public function __construct( )
    {
        ( );
        self::$TABLE_NAME = "flow_rule";
        $this->_obj_class_name = "MyWorkDeputeRole";
        $this->_db_key_field = "RULE_ID";
        $this->_obj_key_field = "rule_id";
        $this->_default_key_map = array( "FLOW_ID" => "flow_id", "USER_ID" => "user_id", "TO_ID" => "to_id", "BEGIN_DATE" => "begin_date", "END_DATE" => "end_date", "STATUS" => "status", "CREATE_USER" => "create_user", "CREATE_TIME" => "create_time", "UPDATE_USER" => "update_user", "UPDATE_TIME" => "update_time" );
    }

    public function _get( $property_name )
    {
        $property_name = strtolower( $property_name );
        if ( isset( $this->$property_name ) )
        {
            return $this->$property_name;
        }
    }

    public function _set( $property_name, $value )
    {
        $property_name = strtolower( $property_name );
        $this->$property_name = $value;
    }

    public function insert( $obj, $key_map = NULL, $r_connection = NULL )
    {
        return ( $obj, $key_map, $r_connection );
    }

    public function update( $obj, $key_map = NULL, $r_connection = NULL )
    {
        return ( $obj, $key_map, $r_connection );
    }

    public function delete( $obj, $r_connection = NULL )
    {
        return ( $obj, $r_connection );
    }

    public function fetch( $obj, $selectFields = NULL, $r_connection = NULL )
    {
        return ( $obj, $selectFields, $r_connection );
    }

    public function deleteBatch( $rule_ids )
    {
        $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
        $rule_ids = td_trim( $rule_ids );
        if ( 0 < strpos( $rule_ids, "," ) )
        {
            $where_condition = $OBJ_SQL_SYNTAX->getConditionExpr( "rule_id", EXPR_OP_IN, $rule_ids, FIELD_TYPE_INT );
        }
        else
        {
            $where_condition = $OBJ_SQL_SYNTAX->getConditionExpr( "rule_id", EXPR_OP_IS, $rule_ids, FIELD_TYPE_INT );
        }
        $sql = $OBJ_SQL_SYNTAX->getDeleteSQL( "flow_rule", $where_condition );
        exequery( ( ), $sql, TRUE );
    }

    public function openRule( $rule_ids )
    {
        $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
        $keyValueMap = array( "STATUS" => 1 );
        $rule_ids = td_trim( $rule_ids );
        if ( 0 < strpos( $rule_ids, "," ) )
        {
            $where_condition = $OBJ_SQL_SYNTAX->getConditionExpr( "rule_id", EXPR_OP_IN, $rule_ids, FIELD_TYPE_INT );
        }
        else
        {
            $where_condition = $OBJ_SQL_SYNTAX->getConditionExpr( "rule_id", EXPR_OP_IS, $rule_ids, FIELD_TYPE_INT );
        }
        $sql = $OBJ_SQL_SYNTAX->getUpdateSQL( "flow_rule", $keyValueMap, $where_condition );
        exequery( ( ), $sql, TRUE );
    }

    public function closeRule( $rule_ids )
    {
        $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
        $keyValueMap = array( "STATUS" => 0 );
        if ( 0 < strpos( $rule_ids, "," ) )
        {
            $where_condition = $OBJ_SQL_SYNTAX->getConditionExpr( "rule_id", EXPR_OP_IN, $rule_ids, FIELD_TYPE_INT );
        }
        else
        {
            $where_condition = $OBJ_SQL_SYNTAX->getConditionExpr( "rule_id", EXPR_OP_IS, $rule_ids, FIELD_TYPE_INT );
        }
        $sql = $OBJ_SQL_SYNTAX->getUpdateSQL( "flow_rule", $keyValueMap, $where_condition );
        exequery( ( ), $sql, TRUE );
    }

    public function getRuleList( )
    {
        if ( $r_connection == NULL )
        {
            $r_connection = ( );
        }
        $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
        $select_expr = $OBJ_SQL_SYNTAX->getSelectExprs( "RULE_ID, FLOW_ID, USER_ID, TO_ID, BEGIN_DATE, END_DATE, STATUS, CREATE_USER, CREATE_TIME, UPDATE_USER, UPDATE_TIME" );
        $table_reference = $OBJ_SQL_SYNTAX->getTableReferences( "flow_rule" );
        $conditions = array( );
        if ( !empty( $this->flow_id ) && $this->flow_id != "" )
        {
            $conditions[] = $this->flow_id( "FLOW_ID", EXPR_OP_IS, $this->flow_id, FIELD_TYPE_INT );
        }
        if ( !empty( $this->status ) && $this->status != "" )
        {
            $conditions[] = $this->status( "FLOW_ID", EXPR_OP_IS, $this->status, FIELD_TYPE_INT );
        }
        if ( !empty( $this->user_id ) && $this->user_id != "" )
        {
            $conditions[] = $this->user_id( "USER_ID", EXPR_OP_IS, $this->user_id, FIELD_TYPE_CHAR );
        }
        if ( !empty( $this->to_id ) && $this->to_id != "" )
        {
            $conditions[] = $this->to_id( "TO_ID", EXPR_OP_IS, $this->to_id, FIELD_TYPE_CHAR );
        }
        if ( is_array( $conditions ) && 0 < count( $conditions ) )
        {
            $where_definition = $OBJ_SQL_SYNTAX->getWhereDefinition( $conditions, CONDITION_LOGIC_OP_AND );
        }
        if ( empty( $this->$order_field ) || $this->$order_field == "" )
        {
            if ( empty( $this->order_directory ) || $this->order_directory == "" )
            {
                $order_by_definition = $OBJ_SQL_SYNTAX->getOrderByDefinition( "FLOW_ID", "ASC" );
            }
            else
            {
                $order_by_definition = $this->order_directory( "FLOW_ID", $this->order_directory );
            }
        }
        else if ( empty( $this->order_directory ) || $this->order_directory == "" )
        {
            $order_by_definition = $this->$order_field( $this->$order_field, "ASC" );
        }
        else
        {
            $order_by_definition = $this->order_directory( $this->$order_field, $this->order_directory );
        }
        $sql = $this->row_number( $this->start_pos, $this->row_number, $select_expr, $table_reference, $where_definition, $order_by_definition );
        $list = array( );
        $r_cursor = exequery( $r_connection, $sql );
        while ( $row = mysql_fetch_array( $r_cursor ) )
        {
            $obj = new MyWorkDeputeRole( );
            $row['RULE_ID']( "rule_id", $row['RULE_ID'] );
            $row['FLOW_ID']( "flow_id", $row['FLOW_ID'] );
            $row['USER_ID']( "user_id", $row['USER_ID'] );
            $row['TO_ID']( "to_id", $row['TO_ID'] );
            $row['BEGIN_DATE']( "begin_date", $row['BEGIN_DATE'] );
            $row['END_DATE']( "end_date", $row['END_DATE'] );
            $row['STATUS']( "status", $row['STATUS'] );
            $row['CREATE_USER']( "create_user", $row['CREATE_USER'] );
            $row['CREATE_TIME']( "create_time", $row['CREATE_TIME'] );
            $row['UPDATE_USER']( "update_user", $row['UPDATE_USER'] );
            $row['UPDATE_TIME']( "update_time", $row['UPDATE_TIME'] );
            $list[] = $obj;
        }
        return $list;
    }

    public function getRuleListCount( )
    {
        if ( $r_connection == NULL )
        {
            $r_connection = ( );
        }
        $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
        $select_expr = $OBJ_SQL_SYNTAX->getSelectExprs( "COUNT(RULE_ID) as TOTAL_NUMBER" );
        $table_reference = $OBJ_SQL_SYNTAX->getTableReferences( "flow_rule" );
        $conditions = array( );
        if ( !empty( $this->flow_id ) && $this->flow_id != "" )
        {
            $conditions[] = $this->flow_id( "FLOW_ID", EXPR_OP_IS, $this->flow_id, FIELD_TYPE_INT );
        }
        if ( !empty( $this->status ) && $this->status != "" )
        {
            $conditions[] = $this->status( "FLOW_ID", EXPR_OP_IS, $this->status, FIELD_TYPE_INT );
        }
        if ( !empty( $this->user_id ) && $this->user_id != "" )
        {
            $conditions[] = $this->user_id( "USER_ID", EXPR_OP_IS, $this->user_id, FIELD_TYPE_CHAR );
        }
        if ( !empty( $this->to_id ) && $this->to_id != "" )
        {
            $conditions[] = $this->to_id( "TO_ID", EXPR_OP_IS, $this->to_id, FIELD_TYPE_CHAR );
        }
        if ( is_array( $conditions ) && 0 < count( $conditions ) )
        {
            $where_definition = $OBJ_SQL_SYNTAX->getWhereDefinition( $conditions, CONDITION_LOGIC_OP_AND );
        }
        $sql = $OBJ_SQL_SYNTAX->getQuerySQL( 0, 0, $select_expr, $table_reference, $where_definition );
        $total_number = 0;
        $r_cursor = exequery( $r_connection, $sql );
        if ( $row = mysql_fetch_array( $r_cursor ) )
        {
            $total_number = $row['TOTAL_NUMBER'];
        }
        return $total_number;
    }

    public static function verify( $flow_id, $user_priv, $user_other_priv )
    {
        $depute_type = getflowdeputetype( $flow_id );
        if ( $depute_type == "2" )
        {
            return 2;
        }
        if ( $user_priv == 1 || find_id( $user_other_priv, 1 ) )
        {
            return 1;
        }
        return 0;
    }

}

?>
