<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class MyManageWorkList
{

    public static $PRIV_TYPE_ALL = 0;
    public static $PRIV_TYPE_MANAGE = 1;
    public static $PRIV_TYPE_NONITOR = 2;
    public static $PRIV_TYPE_QUERY = 3;
    public static $PRIV_TYPE_EDIT = 4;
    public static $PRIV_TYPE_COMMENT = 5;
    public static $PRIV_SCOPE_SELF_ORG = "SELF_ORG";
    public static $PRIV_SCOPE_ALL_DEPT = "ALL_DEPT";
    public static $PRIV_SCOPE_SELF_DEPT = "SELF_DEPT";
    public static $PRIV_SCOPE_DEPT_IDS = "DEPT_IDS";
    private $order_by_field;
    private $order_by_direct;
    private $flow_id;
    private $run_id;
    private $run_name;
    private $user_id;
    private $user_dept;
    private $user_priv;
    private $user_other_dept;
    private $user_other_priv;
    private $start_pos = 0;
    private $row_number = 10;
    private $priv_str;
    private $begin_user;
    private $op_user;

    public function __construct( $user_id, $user_dept, $user_priv, $user_other_dept, $user_other_priv )
    {
        $this->user_id = $user_id;
        $this->user_dept = $user_dept;
        $this->user_priv = $user_priv;
        $this->user_other_dept = $user_other_dept;
        $this->user_other_priv = $user_other_priv;
        $this->order_by_field = "FLOW_RUN.RUN_ID";
        $this->order_by_direct = "DESC";
    }

    public function _get( $property_name )
    {
        $property_name = strtolower( $property_name );
        if ( isset( $this->$property_name ) )
        {
            return $this->$property_name;
        }
    }

    public function _set( $property_name, $value )
    {
        $property_name = strtolower( $property_name );
        $this->$property_name = $value;
    }

    public function initPriv( $str_flow = NULL )
    {
        $this->priv_str = getprivquerycondition( $str_flow, "0,1,2", $this->user_id, $this->user_dept, $this->user_priv, $this->user_other_dept, $this->user_other_priv );
    }

    public function getWorkListCount( $r_connection = NULL )
    {
        if ( empty( $this->priv_str ) && trim( $this->priv_str ) == "" )
        {
            return 0;
        }
        if ( $r_connection == NULL )
        {
            $r_connection = ( );
        }
        $select_expr = " COUNT(RUN_ID) as TOTAL_NUMBER ";
        $where_definition = $this->getCondition( );
        $table_reference = " FLOW_RUN ";
        $sql = "SELECT ".$select_expr." FROM ".$table_reference.$where_definition;
        $total_number = 0;
        $r_cursor = exequery( $r_connection, $sql );
        if ( $row = mysql_fetch_array( $r_cursor ) )
        {
            $total_number = $row['TOTAL_NUMBER'];
        }
        return $total_number;
    }

    public function getWorkList( $r_connection = NULL )
    {
        if ( empty( $this->priv_str ) && trim( $this->priv_str ) == "" )
        {
        }
        else
        {
            if ( $r_connection == NULL )
            {
                $r_connection = ( );
            }
            $list = array( );
            $select_expr = " FLOW_RUN.RUN_ID, FLOW_RUN.FLOW_ID,FLOW_RUN.RUN_NAME,FLOW_RUN.BEGIN_DEPT ";
            $where_definition = $this->getCondition( );
            $order_definition = " ORDER BY ".$this->order_by_field." ".$this->order_by_direct;
            if ( $this->start_pos != 0 || $this->row_number != 0 )
            {
                $limit_definition = " LIMIT ".$this->start_pos.", ".$this->row_number;
            }
            else
            {
                $limit_definition = "";
            }
            $run_ids = "";
            $sql = "SELECT ".$select_expr." FROM FLOW_RUN ".$where_definition.$order_definition.$limit_definition;
            $r_cursor = exequery( $r_connection, $sql );
            while ( $row = mysql_fetch_array( $r_cursor ) )
            {
                $run_ids .= $row['RUN_ID'].",";
                $list[$row['RUN_ID']] = array( "FLOW_ID" => $row['FLOW_ID'], "FLOW_NAME" => getflowname( $row['FLOW_ID'] ), "RUN_NAME" => $row['RUN_NAME'], "BEGIN_DEPT" => $row['BEGIN_DEPT'], "PRCS_INFO" => array( ) );
            }
            if ( $run_ids != "" )
            {
                $run_ids = substr( $run_ids, 0, -1 );
                $select_expr = " ID,RUN_ID,PRCS_ID,USER_ID,PRCS_FLAG,FLOW_PRCS,OP_FLAG,TOP_FLAG,PRCS_TIME,DELIVER_TIME,CREATE_TIME,TIME_OUT,TIME_OUT_FLAG,TIME_OUT_TYPE,TIME_OUT_ATTEND ";
                $table_reference = " FLOW_RUN_PRCS ";
                $where_definition = " WHERE RUN_ID IN (".$run_ids.") AND PRCS_FLAG IN (1,2,6) ";
                $order_definition = " ORDER BY RUN_ID DESC,PRCS_ID DESC, OP_FLAG DESC ";
                $sql = "SELECT ".$select_expr." FROM ".$table_reference.$where_definition.$order_definition;
                $r_cursor = exequery( $r_connection, $sql );
                while ( $row = mysql_fetch_array( $r_cursor ) )
                {
                    $config = array( "TIME_OUT" => $row['TIME_OUT'], "TIME_OUT_TYPE" => $row['TIME_OUT_TYPE'], "TIME_OUT_ATTEND" => $row['TIME_OUT_ATTEND'] );
                    $work_time = getworkitemtime( $row['USER_ID'], $row['CREATE_TIME'], $row['PRCS_TIME'], $row['DELIVER_TIME'], $config );
                    $list[$row['RUN_ID']]['PRCS_INFO'][] = array( "KEY_PRCS_ID" => $row['ID'], "PRCS_ID" => $row['PRCS_ID'], "FLOW_PRCS" => $row['FLOW_PRCS'], "PRCS_FLAG" => $row['PRCS_FLAG'], "OP_FLAG" => $row['OP_FLAG'], "TOP_FLAG" => $row['TOP_FLAG'], "USER_ID" => $row['USER_ID'], "PRCS_TIME" => $row['PRCS_TIME'], "DELIVER_TIME" => $row['DELIVER_TIME'], "CREATE_TIME" => $row['CREATE_TIME'], "TIME_OUT" => $row['TIME_OUT'], "TIME_OUT_FLAG" => $row['TIME_OUT_FLAG'], "WORK_TIME" => $work_time );
                }
            }
            return $list;
        }
    }

    private function getCondition( )
    {
        $str_condition = " WHERE FLOW_RUN.DEL_FLAG = 0 ";
        $str_condition .= " AND FLOW_RUN.END_TIME IS NULL ";
        if ( !empty( $this->run_id ) && $this->run_id != "" )
        {
            $str_condition .= " AND FLOW_RUN.RUN_ID = '".$this->run_id."' ";
        }
        if ( !empty( $this->flow_id ) && $this->flow_id != "" )
        {
            $str_condition .= " AND FLOW_RUN.FLOW_ID = '".$this->flow_id."' ";
        }
        if ( !empty( $this->begin_user ) && $this->begin_user != "" )
        {
            $str_condition .= " AND FLOW_RUN.BEGIN_USER = '".$this->begin_user."' ";
        }
        $str_condition .= " AND FLOW_RUN.BEGIN_TIME IS NOT NULL AND FLOW_RUN.END_TIME IS NULL ";
        if ( !empty( $this->run_name ) && $this->run_name != "" )
        {
            $str_condition .= " AND FLOW_RUN.RUN_NAME LIKE '%".$this->run_name."%' ";
        }
        if ( !empty( $this->op_user ) && $this->op_user != "" )
        {
            $str_condition .= " AND FLOW_RUN.RUN_ID in (\r\n                                SELECT RUN_ID from FLOW_RUN_PRCS\r\n                                WHERE FLOW_RUN_PRCS.USER_ID = '".$this->op_user."'\r\n                                AND FLOW_RUN_PRCS.PRCS_FLAG in (1,2,6))";
        }
        if ( !empty( $this->priv_str ) && trim( $this->priv_str ) != "" )
        {
            $str_condition .= " AND ".$this->priv_str;
        }
        $s_filterParentRun = $this->getFilterParentRun( );
        if ( $s_filterParentRun != "" )
        {
            $str_condition .= "AND (FLOW_RUN.RUN_ID NOT IN(".$s_filterParentRun."))";
        }
        return $str_condition;
    }

    public function getFilterParentRun( )
    {
        $sql = "SELECT PARENT_RUN FROM FLOW_RUN WHERE PARENT_RUN!=0 AND END_TIME IS NULL";
        $cursor = exequery( ( ), $sql );
        while ( $row = mysql_fetch_array( $cursor ) )
        {
            $tempFilterParentRun = $row['PARENT_RUN'];
            $s_filterParentRun .= $tempFilterParentRun.",";
        }
        $s_filterParentRun = rtrim( $s_filterParentRun, "," );
        return $s_filterParentRun;
    }

}

?>
