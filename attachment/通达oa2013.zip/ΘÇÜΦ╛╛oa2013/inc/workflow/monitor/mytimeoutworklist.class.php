<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class MyTimeOutWorkList
{

    private $start_pos = 0;
    private $row_number = 10;
    private $order_by_field;
    private $order_by_direct;
    private $flow_id;
    private $run_id;
    private $user_id;
    private $run_name;
    private $prcs_status;
    private $op_user;
    private $prcs_dept;
    private $flow_status;
    private $prcs_time_from;
    private $prcs_time_to;
    private $user_type;

    public function __construct( $user_id, $user_dept, $user_priv, $user_other_dept, $user_other_priv )
    {
        $this->user_id = $user_id;
        $this->user_dept = $user_dept;
        $this->user_priv = $user_priv;
        $this->user_other_dept = $user_other_dept;
        $this->user_other_priv = $user_other_priv;
        $this->order_by_field = "FLOW_RUN.RUN_ID";
        $this->order_by_direct = "DESC";
    }

    public function _get( $property_name )
    {
        $property_name = strtolower( $property_name );
        if ( isset( $this->$property_name ) )
        {
            return $this->$property_name;
        }
    }

    public function _set( $property_name, $value )
    {
        $property_name = strtolower( $property_name );
        $this->$property_name = $value;
    }

    public function getTimeOurWorkListCount( $r_connection = NULL )
    {
        if ( $r_connection == NULL )
        {
            $r_connection = ( );
        }
        $select_expr = " COUNT(FLOW_RUN_PRCS.ID) as TOTAL_NUMBER ";
        $select_exprs = " FLOW_RUN_PRCS.ID,FLOW_RUN_PRCS.USER_ID ";
        $table_references = " FLOW_RUN_PRCS ";
        $table_references .= " INNER JOIN FLOW_RUN ON FLOW_RUN.RUN_ID = FLOW_RUN_PRCS.RUN_ID AND ".$this->getFlowRunConidtion( );
        $table_references .= " INNER JOIN FLOW_PROCESS ON FLOW_RUN.FLOW_ID=FLOW_PROCESS.FLOW_ID and FLOW_RUN_PRCS.FLOW_PRCS=FLOW_PROCESS.PRCS_ID and FLOW_PROCESS.TIME_OUT !='' ";
        $where_definition = $this->getFlowRunPrcsCondtion( );
        $select_ids = td_trim( $this->prcs_dept );
        $select_id_arr = explode( ",", $select_ids );
        $s_count = count( $select_id_arr );
        $conditions = "";
        $i = 0;
        for ( ; $i < $s_count; ++$i )
        {
            $conditions .= " OR FIND_IN_SET('".$select_id_arr[$i]."',USER.DEPT_ID_OTHER) ";
        }
        if ( !empty( $this->prcs_dept ) && $this->prcs_dept != "" && $this->prcs_dept != "ALL_DEPT" )
        {
            $sql = "SELECT COUNT(FLOW_RUN_PRCS.ID) as TOTAL_NUMBER FROM USER right JOIN (SELECT ".$select_exprs." FROM ".$table_references.$where_definition.") as FLOW_RUN_PRCS ON FLOW_RUN_PRCS.USER_ID= USER.USER_ID WHERE USER.DEPT_ID IN (".$select_ids.")".$conditions;
        }
        else
        {
            $sql = "SELECT ".$select_expr." FROM ".$table_references.$where_definition;
        }
        $total_number = 0;
        $r_cursor = exequery( $r_connection, $sql );
        if ( $row = mysql_fetch_array( $r_cursor ) )
        {
            $total_number = $row['TOTAL_NUMBER'];
        }
        return $total_number;
    }

    public function getTimeOurWorkList( $r_connection = NULL )
    {
        if ( $r_connection == NULL )
        {
            $r_connection = ( );
        }
        $list = array( );
        $select_exprs = "FLOW_RUN_PRCS.ID as KEY_PRCS_ID, \r\n                         FLOW_RUN_PRCS.RUN_ID,\r\n                         FLOW_RUN_PRCS.CREATE_TIME,\r\n                         FLOW_RUN_PRCS.DELIVER_TIME,\r\n                         FLOW_RUN_PRCS.PRCS_TIME,\r\n                         FLOW_RUN_PRCS.OP_FLAG,\r\n                         FLOW_RUN_PRCS.PRCS_ID,\r\n                         FLOW_RUN_PRCS.TIME_OUT as T_TIME_OUT,\r\n                         FLOW_RUN_PRCS.FLOW_PRCS,\r\n                         FLOW_RUN_PRCS.PRCS_FLAG,\r\n                         FLOW_RUN_PRCS.USER_ID,\r\n                         FLOW_RUN_PRCS.PRCS_DEPT,\r\n                         FLOW_RUN_PRCS.TIME_OUT as TIME_OUT_RUN,\r\n                         FLOW_RUN.FLOW_ID,\r\n                         FLOW_RUN.RUN_NAME,\r\n                         FLOW_RUN.END_TIME,\r\n                         FLOW_PROCESS.TIME_OUT_MODIFY,\r\n                         FLOW_PROCESS.TIME_OUT_TYPE,\r\n                         FLOW_PROCESS.TIME_OUT,\r\n                         FLOW_PROCESS.TIME_OUT_ATTEND";
        $table_references = " FROM FLOW_RUN_PRCS ";
        $table_references .= " INNER JOIN FLOW_RUN ON FLOW_RUN.RUN_ID = FLOW_RUN_PRCS.RUN_ID AND ".$this->getFlowRunConidtion( );
        $table_references .= " INNER JOIN FLOW_PROCESS ON FLOW_RUN.FLOW_ID=FLOW_PROCESS.FLOW_ID and FLOW_RUN_PRCS.FLOW_PRCS=FLOW_PROCESS.PRCS_ID and FLOW_PROCESS.TIME_OUT !='' ";
        $where_definition = $this->getFlowRunPrcsCondtion( );
        $order_definition = " ORDER BY ".$this->order_by_field." ".$this->order_by_direct;
        if ( $this->start_pos != 0 || $this->row_number != 0 )
        {
            $limit_definition = " LIMIT ".$this->start_pos.", ".$this->row_number;
        }
        else
        {
            $limit_definition = "";
        }
        $select_ids = td_trim( $this->prcs_dept );
        $select_id_arr = explode( ",", $select_ids );
        $s_count = count( $select_id_arr );
        $conditions = "";
        $i = 0;
        for ( ; $i < $s_count; ++$i )
        {
            $conditions .= " OR FIND_IN_SET('".$select_id_arr[$i]."',USER.DEPT_ID_OTHER) ";
        }
        if ( !empty( $this->prcs_dept ) && $this->prcs_dept != "" && $this->prcs_dept != "ALL_DEPT" )
        {
            $sql = "SELECT FLOW_RUN_PRCS.* FROM USER right JOIN (SELECT ".$select_exprs.$table_references.$where_definition.$order_definition.") as FLOW_RUN_PRCS ON FLOW_RUN_PRCS.USER_ID= USER.USER_ID WHERE USER.DEPT_ID IN (".$select_ids.") ".$conditions.$limit_definition;
        }
        else
        {
            $sql = "SELECT ".$select_exprs.$table_references.$where_definition.$order_definition.$limit_definition;
        }
        $work_schedule = getworkschedule( $this->user_id );
        $std_schedule = array( );
        $std_schedule['holiday'] = "";
        $std_schedule['work'] = array( );
        $std_schedule['work'][0]['from'] = "00:00:00";
        $std_schedule['work'][0]['from'] = "24:00:00";
        $r_cursor = exequery( $r_connection, $sql );
        while ( $row = mysql_fetch_array( $r_cursor ) )
        {
            $config = array( );
            $config['TIME_OUT'] = $row['TIME_OUT'];
            $config['TIME_OUT_MODIFY'] = $row['TIME_OUT_MODIFY'];
            $config['TIME_OUT_TYPE'] = $row['TIME_OUT_TYPE'];
            $config['TIME_OUT_ATTEND'] = $row['TIME_OUT_ATTEND'];
            $work_time = getworkitemtime( $row['USER_ID'], $row['CREATE_TIME'], $row['PRCS_TIME'], $row['DELIVER_TIME'], $config );
            if ( $row['TIME_OUT_RUN'] != "" )
            {
                $time_out = $row['TIME_OUT_RUN'];
            }
            else
            {
                $time_out = $row['TIME_OUT'];
            }
            $list[$row['KEY_PRCS_ID']] = array( "RUN_ID" => $row['RUN_ID'], "FLOW_ID" => $row['FLOW_ID'], "FLOW_NAME" => getflowname( $row['FLOW_ID'] ), "RUN_NAME" => $row['RUN_NAME'], "CREATE_TIME" => $row['CREATE_TIME'], "DELIVER_TIME" => $row['DELIVER_TIME'], "PRCS_ID" => $row['PRCS_ID'], "FLOW_PRCS" => $row['FLOW_PRCS'], "PRCS_FLAG" => $row['PRCS_FLAG'], "USER_ID" => $row['USER_ID'], "PRCS_DEPT" => $row['PRCS_DEPT'], "TIME_OUT" => $time_out, "END_TIME" => $row['END_TIME'], "OP_FLAG" => $row['OP_FLAG'], "WORK_TIME" => $work_time );
        }
        return $list;
    }

    private function getFlowRunPrcsCondtion( )
    {
        if ( $this->user_type == 1 )
        {
            $op_condition = " FLOW_RUN_PRCS.OP_FLAG='1' AND ";
        }
        else if ( $this->user_type == 2 )
        {
            $op_condition = " FLOW_RUN_PRCS.OP_FLAG='0' AND ";
        }
        else
        {
            $op_condition = "";
        }
        $str_condition = " WHERE ".$op_condition." FLOW_RUN_PRCS.TIME_OUT_FLAG='1' ";
        if ( !empty( $this->op_user ) && $this->op_user != "" )
        {
            $str_condition .= " AND FLOW_RUN_PRCS.USER_ID = '".$this->op_user."' ";
        }
        if ( $this->prcs_status == "1" )
        {
            $str_condition .= " AND FLOW_RUN_PRCS.PRCS_FLAG = '1' ";
        }
        else if ( $this->prcs_status == "2" )
        {
            $str_condition .= " AND FLOW_RUN_PRCS.PRCS_FLAG = '2' ";
        }
        else if ( $this->prcs_status == "3" )
        {
            $str_condition .= " AND FLOW_RUN_PRCS.PRCS_FLAG in (3,4) ";
        }
        else if ( $this->prcs_status == "4" )
        {
            $str_condition .= " AND FLOW_RUN_PRCS.PRCS_FLAG = '6' ";
        }
        else
        {
            $str_condition .= " AND FLOW_RUN_PRCS.PRCS_FLAG <> '5' ";
        }
        if ( !empty( $this->prcs_time_from ) && trim( $this->prcs_time_from ) != "" )
        {
            if ( !empty( $this->prcs_time_to ) && trim( $this->prcs_time_to ) != "" )
            {
                $str_condition .= " AND (FLOW_RUN_PRCS.PRCS_TIME BETWEEN '".$this->prcs_time_from." 00:00:00' AND '".$this->prcs_time_to." 23:59:59') ";
            }
            else
            {
                $str_condition .= " AND FLOW_RUN_PRCS.PRCS_TIME >= '".$this->prcs_time_from." 00:00:00' ";
            }
        }
        else if ( !empty( $this->prcs_time_to ) && trim( $this->prcs_time_to ) != "" )
        {
            $str_condition .= " AND FLOW_RUN_PRCS.PRCS_TIME <= '".$this->prcs_time_to." 23:59:59' ";
        }
        if ( !empty( $this->finish_prcs_time_from ) && trim( $this->finish_prcs_time_from ) != "" )
        {
            if ( !empty( $this->finish_prcs_time_to ) && trim( $this->finish_prcs_time_to ) != "" )
            {
                $str_condition .= " AND (FLOW_RUN_PRCS.DELIVER_TIME BETWEEN '".$this->finish_prcs_time_from." 00:00:00' AND '".$this->finish_prcs_time_to." 23:59:59') ";
            }
            else
            {
                $str_condition .= " AND FLOW_RUN_PRCS.DELIVER_TIME >= '".$this->finish_prcs_time_from." 00:00:00' ";
            }
        }
        else if ( !empty( $this->finish_prcs_time_to ) && trim( $this->finish_prcs_time_to ) != "" )
        {
            $str_condition .= " AND FLOW_RUN_PRCS.DELIVER_TIME <= '".$this->prcs_time_to." 23:59:59' ";
        }
        if ( $this->user_id != "admin" )
        {
            $priv_str = getprivquerycondition( $this->flow_id, "0,1,2", $this->user_id, $this->user_dept, $this->user_priv, $this->user_other_dept, $this->user_other_priv );
            if ( !empty( $priv_str ) && $priv_str != "" )
            {
                $str_condition .= " AND ( ".$priv_str;
            }
            $str_condition .= " )";
        }
        return $str_condition;
    }

    private function getFlowRunConidtion( )
    {
        $str_condition = "  FLOW_RUN.DEL_FLAG = 0 ";
        if ( !empty( $this->run_id ) && $this->run_id != "" )
        {
            $str_condition .= " AND FLOW_RUN.RUN_ID = '".$this->run_id."' ";
        }
        if ( !empty( $this->flow_id ) && $this->flow_id != "" )
        {
            $str_condition .= " AND FLOW_RUN.FLOW_ID = '".$this->flow_id."' ";
        }
        if ( !empty( $this->run_name ) && $this->run_name != "" )
        {
            $str_condition .= " AND FLOW_RUN.RUN_NAME LIKE '%".$this->run_name."%' ";
        }
        if ( $this->flow_status == "1" )
        {
            $str_condition .= " AND FLOW_RUN.END_TIME IS NULL";
            return $str_condition;
        }
        if ( $this->flow_status == "2" )
        {
            $str_condition .= " AND FLOW_RUN.END_TIME IS NOT NULL";
        }
        return $str_condition;
    }

}

?>
