<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class MyWorkDeputeRole
{

    private $rule_id;
    private $flow_id;
    private $user_id;
    private $to_id;
    private $begin_date;
    private $end_date;
    private $status;
    private $create_user;
    private $create_time;
    private $update_user;
    private $update_time;

    public function _get( $property_name )
    {
        $property_name = strtolower( $property_name );
        if ( isset( $this->$property_name ) )
        {
            return $this->$property_name;
        }
    }

    public function _set( $property_name, $value )
    {
        $property_name = strtolower( $property_name );
        $this->$property_name = $value;
    }

}

?>
