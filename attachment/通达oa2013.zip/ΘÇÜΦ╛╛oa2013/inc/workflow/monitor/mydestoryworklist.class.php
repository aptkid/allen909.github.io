<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class MyDestoryWorkList
{

    private $flow_id;
    private $run_id;
    private $run_name;
    private $begin_users;
    private $begin_time_from;
    private $begin_time_to;
    private $order_by_field;
    private $order_by_direct;
    private $start_pos = 0;
    private $row_number = 10;

    public function _get( $property_name )
    {
        $property_name = strtolower( $property_name );
        if ( isset( $this->$property_name ) )
        {
            return $this->$property_name;
        }
    }

    public function _set( $property_name, $value )
    {
        $property_name = strtolower( $property_name );
        $this->$property_name = $value;
    }

    public function getDestoryList( $r_connection = NULL )
    {
        if ( $r_connection == NULL )
        {
            $r_connection = ( );
        }
        $list = array( );
        $select_expr = " FLOW_RUN.RUN_ID,\r\n                         FLOW_RUN.FLOW_ID,\r\n                         FLOW_RUN.RUN_NAME,\r\n                         FLOW_RUN.BEGIN_TIME,\r\n                         FLOW_RUN.END_TIME,\r\n                         FLOW_RUN.BEGIN_USER,\r\n                         FLOW_RUN.BEGIN_DEPT,\r\n                         FLOW_RUN.PARENT_RUN,\r\n                         FLOW_RUN.ATTACHMENT_ID,\r\n                         FLOW_RUN.ATTACHMENT_NAME";
        $where_definition = $this->getCondition( );
        $order_definition = " ORDER BY ".$this->order_by_field." ".$this->order_by_direct;
        $limit_definition = " LIMIT ".$this->start_pos.", ".$this->row_number;
        $run_ids = "";
        $sql = "SELECT ".$select_expr." FROM FLOW_RUN ".$where_definition.$order_definition.$limit_definition;
        $r_cursor = exequery( $r_connection, $sql );
        while ( $row = mysql_fetch_array( $r_cursor ) )
        {
            $list[$row['RUN_ID']] = array( "FLOW_ID" => $row['FLOW_ID'], "FLOW_NAME" => getflowname( $row['FLOW_ID'] ), "RUN_NAME" => $row['RUN_NAME'], "BEGIN_TIME" => $row['BEGIN_TIME'], "BEGIN_USER" => $row['BEGIN_USER'], "BEGIN_DEPT" => $row['BEGIN_DEPT'], "END_TIME" => $row['END_TIME'], "PARENT_RUN" => $row['PARENT_RUN'], "ATTACHMENT_ID" => $row['ATTACHMENT_ID'], "ATTACHMENT_NAME" => $row['ATTACHMENT_NAME'], "ARCHIVE" => $row['ARCHIVE'], "FOCUS_USER" => $row['FOCUS_USER'] );
        }
        return $list;
    }

    public function getDestoryListCount( $r_connection = NULL )
    {
        if ( $r_connection == NULL )
        {
            $r_connection = ( );
        }
        $select_expr = " COUNT(RUN_ID) as TOTAL_NUMBER ";
        $where_definition = $this->getCondition( );
        $table_reference = " FLOW_RUN ";
        $sql = "SELECT ".$select_expr." FROM ".$table_reference.$where_definition;
        $total_number = 0;
        $r_cursor = exequery( $r_connection, $sql );
        if ( $row = mysql_fetch_array( $r_cursor ) )
        {
            $total_number = $row['TOTAL_NUMBER'];
        }
        return $total_number;
    }

    public function restory_work( $user_id, $run_ids = NULL )
    {
        $condition = "";
        if ( empty( $run_ids ) || $run_ids == "" )
        {
            $where_definition = $this->getCondition( );
            $condition = " AND END_TIME='.".$this->run_id.".'";
        }
        else
        {
            $run_ids = td_trim( $run_ids );
            if ( 0 < strpos( $run_ids, "," ) )
            {
                $where_definition = " WHERE FLOW_RUN.DEL_FLAG = 1 AND FLOW_RUN.RUN_ID IN (".$run_ids.") ";
                $condition = " AND END_TIME in('".$run_ids."')";
            }
            else
            {
                $where_definition = " WHERE FLOW_RUN.DEL_FLAG = 1 AND FLOW_RUN.RUN_ID = '".$run_ids."' ";
                $condition = " AND END_TIME='".$run_ids."'";
            }
        }
        $sql = "SELECT FLOW_RUN.RUN_ID,FLOW_RUN.RUN_NAME,FLOW_RUN.FLOW_ID FROM FLOW_RUN ".$where_definition;
        $flow_ids = array( );
        $run_ids = array( );
        $run_names = array( );
        $flow_prcss = array( );
        $prcs_ids = array( );
        $contents = array( );
        $r_cursor = exequery( ( ), $sql, TRUE );
        while ( $row = mysql_fetch_array( $r_cursor ) )
        {
            $run_ids[] = $row['RUN_ID'];
            $flow_ids[] = $row['FLOW_ID'];
            $run_names[] = $row['RUN_NAME'];
            $prcs_ids[] = 0;
            $flow_prcss[] = 0;
            $contents[] = "��ԭ�˹���";
        }
        $sql = "UPDATE FLOW_RUN set DEL_FLAG=0 ".$where_definition;
        exequery( ( ), $sql, TRUE );
        if ( $condition )
        {
            $query = "UPDATE taskcenter  SET IGNORE_FLAG=0 WHERE CATAGORY='WORKFLOW'".$condition;
            exequery( ( ), $query, TRUE );
        }
        ( $flow_ids, $run_ids, $run_names, $prcs_ids, $flow_prcss, $user_id, WorkLog::$LOG_TYPE_RESTORE, $contents );
    }

    public function destory_work( $user_id, $run_ids = NULL )
    {
        $where_definition = $this->getDestoryCondition( $run_ids );
        $sql = "SELECT FLOW_RUN.RUN_ID,FLOW_RUN.RUN_NAME,FLOW_RUN.FLOW_ID,FLOW_RUN.ATTACHMENT_ID,FLOW_RUN.ATTACHMENT_NAME FROM FLOW_RUN ".$where_definition;
        $flow_ids = array( );
        $run_ids = array( );
        $run_names = array( );
        $flow_prcss = array( );
        $prcs_ids = array( );
        $contents = array( );
        $r_cursor = exequery( ( ), $sql, TRUE );
    }
    do
    {
        if ( $row = mysql_fetch_array( $r_cursor ) )
        {
            $run_ids[] = $row['RUN_ID'];
            $flow_ids[] = $row['FLOW_ID'];
            $run_names[] = $row['RUN_NAME'];
            $prcs_ids[] = 0;
            $flow_prcss[] = 0;
            $contents[] = "���ٴ˹���";
            $attachment_id = $row['ATTACHMENT_ID'];
            $attachment_name = $row['ATTACHMENT_NAME'];
        }
    } while ( !( $attachment_name != "" ) );
    $ATTACHMENT_ID_ARRAY = explode( ",", $attachment_id );
    $ATTACHMENT_NAME_ARRAY = explode( "*", $attachment_name );
    $ARRAY_COUNT = sizeof( $ATTACHMENT_ID_ARRAY );
    $i = 0;
    do
    {
        do
        {
            for ( ; $i < $ARRAY_COUNT; } while ( 0 ), do
 {
 ++$i, } while ( 1 ) )
        {
            if ( $ATTACHMENT_ID_ARRAY[$i] != "" )
            {
                delete_attach( $ATTACHMENT_ID_ARRAY[$i], $ATTACHMENT_NAME_ARRAY[$i] );
            }
        } while ( 1 );
        break;
        $this->destoryFlowRunAttach( $run_ids );
        $this->destoryTaskCenter( $run_ids );
        $this->destoryFeedBack( $where_definition );
        $this->destoryData( $flow_ids, $where_definition );
        $this->destoryPrcsAndRun( $where_definition );
        ( $flow_ids, $run_ids, $run_names, $prcs_ids, $flow_prcss, $user_id, WorkLog::$LOG_TYPE_DESTROY, $contents );
    }

    private function destoryData( $flow_ids, $where_definition )
    {
        $where_definition = " WHERE RUN_ID IN (SELECT RUN_ID FROM FLOW_RUN ".$where_definition.") ";
        if ( 0 < count( $flow_ids ) )
        {
            foreach ( $flow_ids as $flow_id )
            {
                $query = "SELECT form_id FROM FLOW_TYPE WHERE flow_id='".$flow_id."'";
                $cursor = exequery( ( ), $query );
                $row = mysql_fetch_array( $cursor );
                $form_id = $row['form_id'];
                $arr_element = ( "workflow/form/ELEMENT_ARRAY_".$form_id );
                $table_name = "flow_data_".$flow_id;
                if ( is_array( $arr_element ) && 0 < count( $arr_element ) )
                {
                    foreach ( $arr_element as $element_name => $info )
                    {
                        if ( empty( $info['TAG'] ) )
                        {
                            if ( empty( $element_name ) )
                            {
                                $field_name = strtolower( trim( $element_name ) );
                                if ( substr( $field_name, 0, 5 ) == "data_" )
                                {
                                    if ( strtoupper( $info['CLASS'] ) == "LIST_VIEW" )
                                    {
                                        $tbl_name = "flow_data_".$flow_id;
                                        if ( table_exists( $tbl_name ) )
                                        {
                                            $item_table_name = $table_name."_list_".substr( $field_name, 5 );
                                            $sql = "delete from ".$item_table_name.$where_definition;
                                            exequery( ( ), $sql, TRUE );
                                        }
                                    }
                                    else
                                    {
                                        if ( strtoupper( $info['CLASS'] ) == "FILEUPLOAD" )
                                        {
                                            $table_name = "flow_data_".$flow_id;
                                            $sql = "select ".$field_name.",".$field_name."_key from ".$table_name.$where_definition;
                                            $cursor = exequery( ( ), $sql, TRUE );
                                        }
                                        do
                                        {
                                            if ( $row = mysql_fetch_array( $cursor ) )
                                            {
                                                $attachment_id = $row[$field_name."_key"];
                                                $attachment_name = $row[$field_name];
                                            }
                                        } while ( !( $attachment_name != "" ) );
                                        $ATTACHMENT_ID_ARRAY = explode( ",", $attachment_id );
                                        $ATTACHMENT_NAME_ARRAY = explode( "*", $attachment_name );
                                        $ARRAY_COUNT = sizeof( $ATTACHMENT_ID_ARRAY );
                                        $i = 0;
                                        do
                                        {
                                            for ( ; $i < $ARRAY_COUNT; do
 {
 ++$i, } while ( 1 ) )
                                            {
                                                if ( $ATTACHMENT_ID_ARRAY[$i] != "" )
                                                {
                                                    delete_attach( $ATTACHMENT_ID_ARRAY[$i], $ATTACHMENT_NAME_ARRAY[$i] );
                                                }
                                            } while ( 1 );
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                $tbl_name = "flow_data_".$flow_id;
                if ( table_exists( $tbl_name ) )
                {
                    $sql = "delete from ".$tbl_name.$where_definition;
                    exequery( ( ), $sql, TRUE );
                }
            }
        }
    }

    private function destoryPrcsAndRun( $where_definition )
    {
        $sql = "SELECT RUN_ID FROM FLOW_RUN ".$where_definition;
        $r_cursor = exequery( ( ), $sql, TRUE );
        $run_id_str = "";
        while ( $row = mysql_fetch_array( $r_cursor ) )
        {
            $run_id_str .= ",".$row['RUN_ID'];
        }
        $run_id_str = ltrim( $run_id_str, "," );
        if ( $run_id_str == "" )
        {
        }
        else
        {
            $where_definition1 = " WHERE RUN_ID IN (".$run_id_str.") ";
            $sql = "delete from FLOW_RUN_PRCS ".$where_definition1;
            exequery( ( ), $sql, TRUE );
            $sql = "delete from FLOW_RUN ".$where_definition;
            exequery( ( ), $sql );
        }
    }

    private function destoryFlowRunAttach( $run_ids )
    {
        $a_flow_run_attachment_id = array( );
        if ( empty( $run_ids ) || !( $run_ids != "" ) || !( $run_ids != NULL ) )
        {
            $count_r = 0;
            for ( ; $count_r < count( $run_ids ); ++$count_r )
            {
                $sql = "select ATTACHMENT_ID from flow_run where RUN_ID='".$run_ids[$count_r]."' and DEL_FLAG='1'";
                $cursor = exequery( ( ), $sql );
                if ( $row = mysql_fetch_array( $cursor ) )
                {
                    $flow_run_attachment_id = $row['ATTACHMENT_ID'];
                }
                $flow_run_attachment_id = rtrim( $flow_run_attachment_id, "," );
                $a_flow_run_attachment_id = explode( ",", $flow_run_attachment_id );
                $count_f = 0;
                for ( ; $count_f < count( $a_flow_run_attachment_id ); ++$count_f )
                {
                    $sql = "delete from flow_run_attach where RUN_ID='".$run_ids[$count_r]."' and ATTACHMENT_ID='{$a_flow_run_attachment_id[$count_f]}'";
                    $cursor = exequery( ( ), $sql );
                }
            }
        }
    }

    private function destoryFeedBack( $where_definition )
    {
        $where_definition = " WHERE RUN_ID IN (SELECT RUN_ID FROM FLOW_RUN ".$where_definition.") ";
        $sql = "select ATTACHMENT_ID,ATTACHMENT_NAME from FLOW_RUN_FEEDBACK ".$where_definition;
        $cursor = exequery( ( ), $sql, TRUE );
    }
    do
    {
        if ( $row = mysql_fetch_array( $cursor ) )
        {
            $attachment_id = $row['ATTACHMENT_ID'];
            $attachment_name = $row['ATTACHMENT_NAME'];
        }
    } while ( !( $attachment_name != "" ) );
    $ATTACHMENT_ID_ARRAY = explode( ",", $attachment_id );
    $ATTACHMENT_NAME_ARRAY = explode( "*", $attachment_name );
    $ARRAY_COUNT = sizeof( $ATTACHMENT_ID_ARRAY );
    $i = 0;
    do
    {
        do
        {
            for ( ; $i < $ARRAY_COUNT; } while ( 0 ), do
 {
 ++$i, } while ( 1 ) )
        {
            if ( $ATTACHMENT_ID_ARRAY[$i] != "" )
            {
                delete_attach( $ATTACHMENT_ID_ARRAY[$i], $ATTACHMENT_NAME_ARRAY[$i] );
            }
        } while ( 1 );
        break;
        $sql = "delete from FLOW_RUN_FEEDBACK ".$where_definition;
        exequery( ( ), $sql, TRUE );
    }

    private function destoryTaskCenter( $run_ids )
    {
        if ( $run_ids )
        {
            $query = "DELETE FROM taskcenter WHERE CATAGORY='WORKFLOW' AND END_TIME in(".implode( ",", $run_ids ).")";
            exequery( ( ), $query );
        }
    }

    private function getDestoryCondition( $run_ids = NULL )
    {
        if ( $run_ids == NULL || $run_ids == "" )
        {
            $where_definition = $this->getCondition( );
            return $where_definition;
        }
        $run_ids = td_trim( $run_ids );
        if ( 0 < strpos( $run_ids, "," ) )
        {
            $where_definition = " WHERE FLOW_RUN.DEL_FLAG = 1 AND FLOW_RUN.RUN_ID IN (".$run_ids.") ";
            return $where_definition;
        }
        $where_definition = " WHERE FLOW_RUN.DEL_FLAG = 1 AND FLOW_RUN.RUN_ID = '".$run_ids."' ";
        return $where_definition;
    }

    private function getCondition( )
    {
        $str_condition = " WHERE FLOW_RUN.DEL_FLAG = 1 ";
        if ( !empty( $this->run_id ) && $this->run_id != "" )
        {
            $str_condition .= " AND FLOW_RUN.RUN_ID = '".$this->run_id."' ";
        }
        if ( !empty( $this->flow_id ) && $this->flow_id != "" )
        {
            $str_condition .= " AND FLOW_RUN.FLOW_ID = '".$this->flow_id."' ";
        }
        if ( !empty( $this->run_name ) && $this->run_name != "" )
        {
            $str_condition .= " AND FLOW_RUN.RUN_NAME LIKE '%".$this->run_name."%' ";
        }
        if ( !empty( $this->begin_users ) && $this->begin_users != "" )
        {
            $str_condition .= " AND FIND_IN_SET(FLOW_RUN.BEGIN_USER, '".$this->begin_users."') ";
        }
        if ( !empty( $this->begin_time_from ) && trim( $this->begin_time_from ) != "" )
        {
            if ( !empty( $this->begin_time_to ) && trim( $this->begin_time_to ) != "" )
            {
                $str_condition .= " AND (FLOW_RUN.BEGIN_TIME BETWEEN '".$this->begin_time_from." 00:00:00' AND '".$this->begin_time_to." 23:59:59') ";
                return $str_condition;
            }
            $str_condition .= " AND FLOW_RUN.BEGIN_TIME >= '".$this->begin_time_from." 00:00:00' ";
            return $str_condition;
        }
        if ( !empty( $this->begin_time_to ) && trim( $this->begin_time_to ) != "" )
        {
            $str_condition .= " AND FLOW_RUN.BEGIN_TIME <= '".$this->begin_time_to." 23:59:59' ";
        }
        return $str_condition;
    }

}

?>
