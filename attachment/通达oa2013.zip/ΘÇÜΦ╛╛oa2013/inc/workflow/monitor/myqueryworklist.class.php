<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class MyQueryWorkList
{

    public static $PRIV_TYPE_ALL = 0;
    public static $PRIV_TYPE_MANAGE = 1;
    public static $PRIV_TYPE_NONITOR = 2;
    public static $PRIV_TYPE_QUERY = 3;
    public static $PRIV_TYPE_EDIT = 4;
    public static $PRIV_TYPE_COMMENT = 5;
    public static $PRIV_SCOPE_SELF_ORG = "SELF_ORG";
    public static $PRIV_SCOPE_ALL_DEPT = "ALL_DEPT";
    public static $PRIV_SCOPE_SELF_DEPT = "SELF_DEPT";
    public static $PRIV_SCOPE_DEPT_IDS = "DEPT_IDS";
    private $order_by_field;
    private $order_by_direct;
    private $flow_id;
    private $run_id;
    private $run_name;
    private $user_id;
    private $user_dept;
    private $user_priv;
    private $user_other_dept;
    private $user_other_priv;
    private $begin_time_from;
    private $begin_time_to;
    private $start_pos = 0;
    private $row_number = 10;
    private $priv_str;
    private $manage_priv_str;
    private $flow_status;
    private $flow_query_type;
    private $to_id;

    public function __construct( $user_id, $user_dept, $user_priv, $user_other_dept, $user_other_priv, $archive = "", $archive_id = "" )
    {
        $this->user_id = $user_id;
        $this->user_dept = $user_dept;
        $this->user_priv = $user_priv;
        $this->user_other_dept = $user_other_dept;
        $this->user_other_priv = $user_other_priv;
        $this->archive_id = $archive_id;
        $this->archive = $archive;
        $this->order_by_field = $archive."FLOW_RUN".$archive_id.".RUN_ID";
        $this->order_by_direct = "DESC";
    }

    public function _get( $property_name )
    {
        $property_name = strtolower( $property_name );
        if ( isset( $this->$property_name ) )
        {
            return $this->$property_name;
        }
    }

    public function _set( $property_name, $value )
    {
        $property_name = strtolower( $property_name );
        $this->$property_name = $value;
    }

    public function initPriv( $flow_query_type = NULL, $str_flow = NULL )
    {
        if ( empty( $flow_query_type ) || $flow_query_type == "ALL" || $flow_query_type == "" )
        {
            $this->priv_str = getprivquerycondition( $str_flow, "0,1,2,3,4,5", $this->user_id, $this->user_dept, $this->user_priv, $this->user_other_dept, $this->user_other_priv, $this->archive, $this->archive_id );
        }
        else if ( $flow_query_type == "3" )
        {
            $this->priv_str = getprivquerycondition( $str_flow, "0,1", $this->user_id, $this->user_dept, $this->user_priv, $this->user_other_dept, $this->user_other_priv, $this->archive, $this->archive_id );
        }
        else
        {
            if ( $flow_query_type == "7" )
            {
                $this->priv_str = getprivquerycondition( $str_flow, "0,5", $this->user_id, $this->user_dept, $this->user_priv, $this->user_other_dept, $this->user_other_priv, $this->archive, $this->archive_id );
            }
            else
            {
                if ( $flow_query_type == "6" )
                {
                    $this->priv_str = getprivquerycondition( $str_flow, "0,1,2,3,4,5", $this->user_id, $this->user_dept, $this->user_priv, $this->user_other_dept, $this->user_other_priv, $this->archive, $this->archive_id );
                }
            }
        }
    }

    public function getWorkListCount( $r_connection = NULL )
    {
        if ( $r_connection == NULL )
        {
            $r_connection = ( );
        }
        $select_expr = " COUNT(".$this->archive."FLOW_RUN".$this->archive_id.".RUN_ID) as TOTAL_NUMBER ";
        $where_definition = $this->getCondition( );
        $table_reference = " ".$this->archive."FLOW_RUN".$this->archive_id." ";
        $sql = "SELECT ".$select_expr." FROM ".$table_reference.$where_definition;
        $total_number = 0;
        $r_cursor = exequery( $r_connection, $sql );
        if ( $row = mysql_fetch_array( $r_cursor ) )
        {
            $total_number = $row['TOTAL_NUMBER'];
        }
        return $total_number;
    }

    public function getWorkList( $r_connection = NULL )
    {
        if ( $r_connection == NULL )
        {
            $r_connection = ( );
        }
        $list = array( );
        $select_expr = " ".$this->archive."FLOW_RUN".$this->archive_id.".RUN_ID, \r\n                         ".$this->archive."FLOW_RUN".$this->archive_id.".FLOW_ID, \r\n                         ".$this->archive."FLOW_RUN".$this->archive_id.".RUN_NAME,\r\n                         ".$this->archive."FLOW_RUN".$this->archive_id.".BEGIN_TIME,\r\n                         ".$this->archive."FLOW_RUN".$this->archive_id.".END_TIME,\r\n                         ".$this->archive."FLOW_RUN".$this->archive_id.".BEGIN_USER,\r\n                         ".$this->archive."FLOW_RUN".$this->archive_id.".BEGIN_DEPT,\r\n                         ".$this->archive."FLOW_RUN".$this->archive_id.".PARENT_RUN,\r\n                         ".$this->archive."FLOW_RUN".$this->archive_id.".ATTACHMENT_ID,\r\n                         ".$this->archive."FLOW_RUN".$this->archive_id.".ATTACHMENT_NAME,\r\n                         ".$this->archive."FLOW_RUN".$this->archive_id.".ARCHIVE,\r\n                         ".$this->archive."FLOW_RUN".$this->archive_id.".FOCUS_USER ";
        $where_definition = $this->getCondition( );
        $order_definition = " ORDER BY ".$this->order_by_field." ".$this->order_by_direct;
        if ( $this->start_pos != 0 || $this->row_number != 0 )
        {
            $limit_definition = " LIMIT ".$this->start_pos.", ".$this->row_number;
        }
        else
        {
            $limit_definition = "";
        }
        $sql = "SELECT ".$select_expr." FROM ".$this->archive."FLOW_RUN".$this->archive_id." ".$where_definition.$order_definition.$limit_definition;
        $r_cursor = exequery( $r_connection, $sql );
        while ( $row = mysql_fetch_array( $r_cursor ) )
        {
            $list[$row['RUN_ID']] = array( "FLOW_ID" => $row['FLOW_ID'], "FLOW_NAME" => getflowname( $row['FLOW_ID'] ), "RUN_NAME" => $row['RUN_NAME'], "BEGIN_TIME" => $row['BEGIN_TIME'], "BEGIN_USER" => $row['BEGIN_USER'], "BEGIN_DEPT" => $row['BEGIN_DEPT'], "END_TIME" => $row['END_TIME'], "PARENT_RUN" => $row['PARENT_RUN'], "ATTACHMENT_ID" => $row['ATTACHMENT_ID'], "ATTACHMENT_NAME" => $row['ATTACHMENT_NAME'], "ARCHIVE" => $row['ARCHIVE'], "FOCUS_USER" => $row['FOCUS_USER'] );
        }
        return $list;
    }

    private function getCondition( )
    {
        $str_condition = " WHERE ".$this->archive."FLOW_RUN".$this->archive_id.".DEL_FLAG = 0 ";
        if ( !empty( $this->run_id ) && $this->run_id != "" )
        {
            $str_condition .= " AND ".$this->archive."FLOW_RUN".$this->archive_id.".RUN_ID = '".$this->run_id."' ";
        }
        if ( !empty( $this->flow_id ) && $this->flow_id != "" )
        {
            $str_condition .= " AND ".$this->archive."FLOW_RUN".$this->archive_id.".FLOW_ID = '".$this->flow_id."' ";
        }
        if ( !empty( $this->begin_user ) && $this->begin_user != "" )
        {
            $str_condition .= " AND ".$this->archive."FLOW_RUN".$this->archive_id.".BEGIN_USER = '".$this->begin_user."' ";
        }
        if ( !empty( $this->run_name ) && $this->run_name != "" )
        {
            $str_condition .= " AND ".$this->archive."FLOW_RUN".$this->archive_id.".RUN_NAME LIKE '%".$this->run_name."%' ";
        }
        if ( $this->flow_status == "0" )
        {
            $str_condition .= " AND ".$this->archive."FLOW_RUN".$this->archive_id.".END_TIME IS NULL";
        }
        else if ( $this->flow_status == "1" )
        {
            $str_condition .= " AND ".$this->archive."FLOW_RUN".$this->archive_id.".END_TIME IS NOT NULL";
        }
        else if ( $this->flow_status == "2" )
        {
            $str_condition .= " AND ".$this->archive."FLOW_RUN".$this->archive_id.".ARCHIVE='1' ";
        }
        if ( !empty( $this->begin_time_from ) && trim( $this->begin_time_from ) != "" )
        {
            if ( !empty( $this->begin_time_to ) && trim( $this->begin_time_to ) != "" )
            {
                $str_condition .= " AND (".$this->archive."FLOW_RUN".$this->archive_id.".BEGIN_TIME BETWEEN '".$this->begin_time_from." 00:00:00' AND '".$this->begin_time_to." 23:59:59') ";
            }
            else
            {
                $str_condition .= " AND ".$this->archive."FLOW_RUN".$this->archive_id.".BEGIN_TIME >= '".$this->begin_time_from." 00:00:00' ";
            }
        }
        else if ( !empty( $this->begin_time_to ) && $this->begin_time_to != NULL && trim( $this->begin_time_to ) != "" )
        {
            $str_condition .= " AND ".$this->archive."FLOW_RUN".$this->archive_id.".BEGIN_TIME <= '".$this->begin_time_to." 23:59:59' ";
        }
        if ( $this->flow_query_type == "1" )
        {
            $str_condition .= " AND ".$this->archive."FLOW_RUN".$this->archive_id.".BEGIN_USER = '".$this->user_id."' ";
            return $str_condition;
        }
        if ( $this->flow_query_type == "2" )
        {
            $str_condition .= " AND ".$this->archive."FLOW_RUN".$this->archive_id.".RUN_ID IN (".$this->getMyOpRunQueryStr( ).") ";
            return $str_condition;
        }
        if ( $this->flow_query_type == "3" )
        {
            if ( !empty( $this->priv_str ) && $this->priv_str != "" )
            {
                $str_condition .= " AND ".$this->priv_str;
                return $str_condition;
            }
            $str_condition .= " AND FALSE ";
            return $str_condition;
        }
        if ( $this->flow_query_type == "4" )
        {
            $str_condition .= " AND FIND_IN_SET('".$this->user_id."',".$this->archive."FLOW_RUN".$this->archive_id.".FOCUS_USER)";
            return $str_condition;
        }
        if ( $this->flow_query_type == "5" )
        {
            $str_condition .= " AND FIND_IN_SET('".$this->user_id."',".$this->archive."FLOW_RUN".$this->archive_id.".VIEW_USER) AND ".$this->archive."FLOW_RUN".$this->archive_id.".END_TIME is not null";
            return $str_condition;
        }
        if ( $this->flow_query_type == "7" )
        {
            if ( !empty( $this->priv_str ) && $this->priv_str != "" )
            {
                $str_condition .= " AND ".$this->priv_str." AND RUN_ID IN ( SELECT RUN_ID FROM ".$this->archive."FLOW_RUN_FEEDBACK".$this->archive_id." WHERE USER_ID='".$this->user_id."' AND FEED_FLAG='1' ) ";
                return $str_condition;
            }
            $str_condition .= " AND FALSE ";
            return $str_condition;
        }
        if ( !empty( $this->to_id ) && $this->flow_query_type == "6" )
        {
            if ( $this->to_id != $this->user_id )
            {
                $str_condition .= " AND ".$this->archive."FLOW_RUN".$this->archive_id.".BEGIN_USER = '".$this->to_id."' ";
                if ( !empty( $this->priv_str ) && trim( $this->priv_str ) != "" )
                {
                    $str_condition .= " AND (".$this->priv_str;
                    $str_condition .= " OR ".$this->archive."FLOW_RUN".$this->archive_id.".RUN_ID IN (".$this->getMyOpRunQueryStr( ).")) ";
                    return $str_condition;
                }
                $str_condition .= " AND (FALSE ";
                $str_condition .= " OR ".$this->archive."FLOW_RUN".$this->archive_id.".RUN_ID IN (".$this->getMyOpRunQueryStr( ).")) ";
                return $str_condition;
            }
            $str_condition .= " AND ".$this->archive."FLOW_RUN".$this->archive_id.".BEGIN_USER = '".$this->to_id."' ";
            return $str_condition;
        }
        $str_condition .= " AND (";
        $str_condition .= " ".$this->archive."FLOW_RUN".$this->archive_id.".BEGIN_USER = '".$this->user_id."' ";
        if ( $this->to_id != $this->user_id && !empty( $this->priv_str ) && trim( $this->priv_str ) != "" )
        {
            $str_condition .= " OR ".$this->priv_str;
        }
        $str_condition .= " OR ".$this->archive."FLOW_RUN".$this->archive_id.".RUN_ID IN (".$this->getMyOpRunQueryStr( ).") ";
        $str_condition .= " OR FIND_IN_SET('".$this->user_id."',".$this->archive."FLOW_RUN".$this->archive_id.".FOCUS_USER)";
        $str_condition .= " OR (FIND_IN_SET('".$this->user_id."',".$this->archive."FLOW_RUN".$this->archive_id.".VIEW_USER) AND ".$this->archive."FLOW_RUN".$this->archive_id.".END_TIME is not null)";
        $str_condition .= ") ";
        return $str_condition;
    }

    private function getMyOpRunQueryStr( )
    {
        $sql = " SELECT ".$this->archive."FLOW_RUN_PRCS".$this->archive_id.".RUN_ID FROM ".$this->archive."FLOW_RUN_PRCS".$this->archive_id." WHERE ".$this->archive."FLOW_RUN_PRCS".$this->archive_id.".USER_ID = '".$this->user_id."' ";
        return $sql;
    }

}

?>
