<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class MyTimeOutWorkStat
{

    private $start_pos = 0;
    private $row_number = 0;
    private $order_by_field;
    private $order_by_direct;
    private $flow_id;
    private $flow_status;
    private $select_user_ids;
    private $work_prcs_time_from;
    private $work_prcs_time_to;
    private $finish_work_prcs_time_from;
    private $finish_work_prcs_time_to;
    private $user_status;

    public function __construct( $user_id, $user_dept, $user_priv, $user_other_dept, $user_other_priv )
    {
        $this->user_id = $user_id;
        $this->user_dept = $user_dept;
        $this->user_priv = $user_priv;
        $this->user_other_dept = $user_other_dept;
        $this->user_other_priv = $user_other_priv;
    }

    public function _get( $property_name )
    {
        $property_name = strtolower( $property_name );
        if ( isset( $this->$property_name ) )
        {
            return $this->$property_name;
        }
    }

    public function _set( $property_name, $value )
    {
        $property_name = strtolower( $property_name );
        $this->$property_name = $value;
    }

    public function setSelectUsers( $select_type, $select_ids )
    {
        $this->select_user_ids = get_user_ids_by_select( $select_type, $select_ids );
    }

    public function getTimeOutWorkStaticCount( $r_connection = NULL )
    {
        if ( $r_connection == NULL )
        {
            $r_connection = ( );
        }
        $select_expr = " COUNT(FLOW_RUN_PRCS.ID) as TOTAL_NUMBER ";
        $table_reference = " FLOW_RUN_PRCS\r\n                            INNER JOIN FLOW_RUN ON FLOW_RUN.RUN_ID = FLOW_RUN_PRCS.RUN_ID ";
        $where_definition = $this->getCondition( );
        $group_by_definition = " GROUP BY FLOW_RUN_PRCS.USER_ID, FLOW_RUN_PRCS.PRCS_FLAG, FLOW_RUN_PRCS.TIME_OUT_FLAG, FLOW_RUN.FLOW_ID ";
        $sql = "SELECT ".$select_expr." FROM ".$table_reference.$where_definition.$group_by_definition;
        $total_number = 0;
        $r_cursor = exequery( $r_connection, $sql );
        if ( $row = mysql_fetch_array( $r_cursor ) )
        {
            $total_number = $row['TOTAL_NUMBER'];
        }
        return $total_number;
    }

    public function getTimeOurWorkStatic( $r_connection = NULL )
    {
        $list = array( );
        $select_exprs = " count(FLOW_RUN_PRCS.ID) as TIME_OUT_COUNT,\r\n                          FLOW_RUN_PRCS.USER_ID, \r\n                          FLOW_RUN_PRCS.PRCS_FLAG, \r\n                          FLOW_RUN_PRCS.TIME_OUT_FLAG,\r\n                          FLOW_RUN.FLOW_ID";
        $table_reference = " FLOW_RUN_PRCS\r\n                            INNER JOIN FLOW_RUN ON FLOW_RUN.RUN_ID = FLOW_RUN_PRCS.RUN_ID ";
        $where_definition = $this->getCondition( );
        $group_by_definition = " GROUP BY FLOW_RUN_PRCS.USER_ID,FLOW_RUN.FLOW_ID,FLOW_RUN_PRCS.PRCS_FLAG, FLOW_RUN_PRCS.TIME_OUT_FLAG";
        $order_by_definition = " ORDER BY FLOW_RUN.FLOW_ID,FLOW_RUN_PRCS.USER_ID ";
        $limit_definition = "";
        $sql = "SELECT ".$select_exprs." FROM ".$table_reference.$where_definition.$group_by_definition.$order_by_definition.$limit_definition;
        $arr_stat = array( );
        $r_cursor = exequery( ( ), $sql );
        while ( $row = mysql_fetch_array( $r_cursor ) )
        {
            if ( is_array( $arr_stat[$row['FLOW_ID']] ) )
            {
                $arr_stat[$row['FLOW_ID']] = array( );
            }
            0;
            0;
            0;
            0;
            0;
            0;
            if ( $row['TIME_OUT_FLAG'] == "1" )
            {
                if ( $row['PRCS_FLAG'] == "1" )
                {
                    $arr_stat[$row['FLOW_ID']][$row['USER_ID']] += "N_ACCEPT";
                }
                else if ( $row['PRCS_FLAG'] == "2" )
                {
                    $arr_stat[$row['FLOW_ID']][$row['USER_ID']] += "PROCESS";
                }
                else if ( $row['PRCS_FLAG'] == "4" )
                {
                    $arr_stat[$row['FLOW_ID']][$row['USER_ID']] += "END";
                }
                else if ( $row['PRCS_FLAG'] == "6" )
                {
                    $arr_stat[$row['FLOW_ID']][$row['USER_ID']] += "HANGUP";
                }
                $arr_stat[$row['FLOW_ID']][$row['USER_ID']] += "TOTAL";
            }
            $arr_stat[$row['FLOW_ID']][$row['USER_ID']] += "ALL";
        }
        return $arr_stat;
    }

    private function getCondition( )
    {
        if ( $this->user_status == 1 )
        {
            $op_condition = " FLOW_RUN_PRCS.OP_FLAG='1' AND ";
        }
        else if ( $this->user_status == 2 )
        {
            $op_condition = " FLOW_RUN_PRCS.OP_FLAG='0' AND ";
        }
        else
        {
            $op_condition = "";
        }
        $str_condition = " WHERE ".$op_condition." FLOW_RUN.DEL_FLAG = '0' AND FLOW_RUN_PRCS.PRCS_FLAG <> '5' ";
        if ( $this->flow_id != NULL && $this->flow_id != "" )
        {
            $str_condition .= " AND FLOW_RUN.FLOW_ID = '".$this->flow_id."' ";
        }
        if ( $this->flow_status == "1" )
        {
            $str_condition .= " AND FLOW_RUN.END_TIME IS NULL ";
        }
        else if ( $this->flow_status == "2" )
        {
            $str_condition .= " AND FLOW_RUN.END_TIME IS NOT NULL ";
        }
        if ( $this->work_prcs_time_from != NULL && trim( $this->work_prcs_time_from ) != "" )
        {
            if ( $this->work_prcs_time_to != NULL && trim( $this->work_prcs_time_to ) != "" )
            {
                $str_condition .= " AND (FLOW_RUN_PRCS.PRCS_TIME BETWEEN '".$this->work_prcs_time_from." 00:00:00' AND '".$this->work_prcs_time_to." 23:59:59') ";
            }
            else
            {
                $str_condition .= " AND FLOW_RUN_PRCS.PRCS_TIME >= '".$this->work_prcs_time_from." 00:00:00' ";
            }
        }
        else if ( $this->work_prcs_time_to != NULL && trim( $this->work_prcs_time_to ) != "" )
        {
            $str_condition .= " AND FLOW_RUN_PRCS.PRCS_TIME <= '".$this->work_prcs_time_to." 23:59:59' ";
        }
        if ( $this->finish_work_prcs_time_from != NULL && trim( $this->finish_work_prcs_time_from ) != "" )
        {
            if ( $this->finish_work_prcs_time_to != NULL && trim( $this->finish_work_prcs_time_to ) != "" )
            {
                $str_condition .= " AND (FLOW_RUN_PRCS.PRCS_TIME BETWEEN '".$this->finish_work_prcs_time_from." 00:00:00' AND '".$this->finish_work_prcs_time_to." 23:59:59') ";
            }
            else
            {
                $str_condition .= " AND FLOW_RUN_PRCS.PRCS_TIME >= '".$this->finish_work_prcs_time_from." 00:00:00' ";
            }
        }
        else if ( $this->finish_work_prcs_time_to != NULL && trim( $this->finish_work_prcs_time_to ) != "" )
        {
            $str_condition .= " AND FLOW_RUN_PRCS.PRCS_TIME <= '".$this->finish_work_prcs_time_to." 23:59:59' ";
        }
        if ( $this->select_user_ids != NULL && trim( $this->select_user_ids ) != "" )
        {
            $str_condition .= " AND FLOW_RUN_PRCS.USER_ID IN ('".$this->select_user_ids."') ";
        }
        if ( $this->user_id != "admin" )
        {
            $priv_str = getprivquerycondition( $this->flow_id, "0,1,2", $this->user_id, $this->user_dept, $this->user_priv, $this->user_other_dept, $this->user_other_priv );
            if ( !empty( $priv_str ) && $priv_str != "" )
            {
                $str_condition .= " AND (  ".$priv_str;
            }
            $str_condition .= " )";
        }
        return $str_condition;
    }

}

echo "  ";
?>
