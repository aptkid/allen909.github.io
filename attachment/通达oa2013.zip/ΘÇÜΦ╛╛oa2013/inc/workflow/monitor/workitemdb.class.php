<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class WorkItemDB
{

    public static $dbToPropertyKeys = array( 'ID' => "id", 'USER_ID' => "user_id", 'RUN_ID' => "run_id", 'PRCS_ID' => "prcs_id", 'FLOW_PRCS' => "flow_prcs", 'PRCS_DEPT' => "prcs_dept", 'PARENT' => "parent", 'CHILD_RUN' => "child_run", 'OP_FLAG' => "op_flag", 'PRCS_FLAG' => "prcs_flag", 'TOP_FLAG' => "top_flag", 'CREATE_TIME' => "create_time", 'PRCS_TIME' => "prcs_time", 'DELIVER_TIME' => "deliver_time", 'ACTIVE_TIME' => "active_time", 'OTHER_USER' => "other_user", 'FREE_ITEM' => "free_item", 'COMMENT' => "comment" );

    public static function getWorkItemProperty( $run_id, $prcs_id, $flow_prcs, $user_id, $propertys = NULL, $prcs_key_id = 0 )
    {
        $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
        $r_connection = ( );
        if ( !isset( $propertys ) || $propertys == "" )
        {
            foreach ( self::$dbToPropertyKeys as $key => $value )
            {
                $propertys .= $key.",";
            }
        }
        else
        {
            $propertys = strtoupper( $propertys );
        }
        if ( substr( $propertys, -1, 1 ) == "," )
        {
            $propertys = substr( $propertys, 0, -1 );
        }
        $select_exprs = $OBJ_SQL_SYNTAX->getSelectExprs( $propertys );
        $conditions = array( );
        if ( $prcs_key_id )
        {
            array_push( &$conditions, $OBJ_SQL_SYNTAX->getConditionExpr( "ID", EXPR_OP_IS, $prcs_key_id, FIELD_TYPE_INT ) );
        }
        array_push( &$conditions, $OBJ_SQL_SYNTAX->getConditionExpr( "RUN_ID", EXPR_OP_IS, $run_id, FIELD_TYPE_INT ) );
        array_push( &$conditions, $OBJ_SQL_SYNTAX->getConditionExpr( "PRCS_ID", EXPR_OP_IS, $prcs_id, FIELD_TYPE_INT ) );
        array_push( &$conditions, $OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_PRCS", EXPR_OP_IS, $flow_prcs, FIELD_TYPE_INT ) );
        array_push( &$conditions, $OBJ_SQL_SYNTAX->getConditionExpr( "USER_ID", EXPR_OP_IS, $user_id, FIELD_TYPE_CHAR ) );
        $where_definitions = $OBJ_SQL_SYNTAX->getWhereDefinition( $conditions, CONDITION_LOGIC_OP_AND );
        $sql = $OBJ_SQL_SYNTAX->getQuerySQL( 0, 1, $select_exprs, "flow_run_prcs", $where_definitions );
        $cursor = exequery( $r_connection, $sql, TRUE );
        if ( $row = mysql_fetch_array( $cursor ) )
        {
            $obj = new WorkItem( );
            $arr_property = explode( ",", $propertys );
            foreach ( $arr_property as $key )
            {
                $row[trim( $key )]( self::$dbToPropertyKeys[trim( $key )], $row[trim( $key )] );
            }
        }
        return $obj;
    }

    public static function getWorkItemPropertyByID( $id, $propertys = NULL )
    {
        $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
        $r_connection = ( );
        if ( !isset( $propertys ) || $propertys == "" )
        {
            foreach ( self::$dbToPropertyKeys as $key => $value )
            {
                $propertys .= $key.",";
            }
        }
        else
        {
            $propertys = strtoupper( $propertys );
        }
        if ( substr( $propertys, -1, 1 ) == "," )
        {
            $propertys = substr( $propertys, 0, -1 );
        }
        $select_exprs = $OBJ_SQL_SYNTAX->getSelectExprs( $propertys );
        $where_definitions = $OBJ_SQL_SYNTAX->getConditionExpr( "ID", EXPR_OP_IS, $id, FIELD_TYPE_INT );
        $sql = $OBJ_SQL_SYNTAX->getQuerySQL( 0, 1, $select_exprs, "flow_run_prcs", $where_definitions );
        $cursor = exequery( $r_connection, $sql, TRUE );
        if ( $row = mysql_fetch_array( $cursor ) )
        {
            $obj = new WorkItem( );
            $arr_property = explode( ",", $propertys );
            foreach ( $arr_property as $key )
            {
                $row[trim( $key )]( self::$dbToPropertyKeys[trim( $key )], $row[trim( $key )] );
            }
        }
        return $obj;
    }

    public static function insertWorkItem( $obj, $propertys = NULL )
    {
        $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
        $r_connection = ( );
        if ( !isset( $propertys ) || $propertys == "" )
        {
            foreach ( self::$dbToPropertyKeys as $key => $value )
            {
                $propertys .= $key.",";
            }
        }
        else
        {
            $propertys = strtoupper( $propertys );
        }
        $keyValueMap = array( );
        $arr_property = explode( ",", $propertys );
        foreach ( $arr_property as $key )
        {
            $keyValueMap[trim( $key )] = self::$dbToPropertyKeys[trim( $key )]( self::$dbToPropertyKeys[trim( $key )] );
        }
        $sql = $OBJ_SQL_SYNTAX->getInsertSQL( "flow_run_prcs", $keyValueMap );
        exequery( $r_connection, $sql, TRUE );
        if ( 0 < mysql_affected_rows( $r_connection ) )
        {
            $id = mysql_insert_id( $r_connection );
            return $id;
        }
        $id = -1;
        return $id;
    }

    public static function updateWorkItemProperty( $obj, $propertys = NULL )
    {
        $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
        $r_connection = ( );
        if ( !isset( $propertys ) || $propertys == "" )
        {
            foreach ( self::$dbToPropertyKeys as $key => $value )
            {
                $propertys .= $key.",";
            }
        }
        else
        {
            $propertys = strtoupper( $propertys );
        }
        if ( substr( $propertys, -1, 1 ) == "," )
        {
            $propertys = substr( $propertys, 0, -1 );
        }
        $keyValueMap = array( );
        $arr_property = explode( ",", $propertys );
        foreach ( $arr_property as $key )
        {
            $keyValueMap[trim( $key )] = self::$dbToPropertyKeys[trim( $key )]( self::$dbToPropertyKeys[trim( $key )] );
        }
        $conditions = array( );
        array_push( &$conditions, $OBJ_SQL_SYNTAX->getConditionExpr( "RUN_ID", EXPR_OP_IS, $obj->_get( "run_id" ), FIELD_TYPE_INT ) );
        array_push( &$conditions, $OBJ_SQL_SYNTAX->getConditionExpr( "PRCS_ID", EXPR_OP_IS, $obj->_get( "prcs_id" ), FIELD_TYPE_INT ) );
        array_push( &$conditions, $OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_PRCS", EXPR_OP_IS, $obj->_get( "flow_prcs" ), FIELD_TYPE_INT ) );
        array_push( &$conditions, $OBJ_SQL_SYNTAX->getConditionExpr( "USER_ID", EXPR_OP_IS, $obj->_get( "user_id" ), FIELD_TYPE_CHAR ) );
        $where_definitions = $OBJ_SQL_SYNTAX->getWhereDefinition( $conditions, CONDITION_LOGIC_OP_AND );
        $sql = $OBJ_SQL_SYNTAX->getUpdateSQL( "flow_run_prcs", $keyValueMap, $where_definitions );
        exequery( $r_connection, $sql, TRUE );
    }

    public static function updateWorkItemPropertyByID( $obj, $propertys = NULL )
    {
        $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
        $r_connection = ( );
        if ( !isset( $propertys ) || $propertys == "" )
        {
            foreach ( self::$dbToPropertyKeys as $key => $value )
            {
                $propertys .= $key.",";
            }
        }
        else
        {
            $propertys = strtoupper( $propertys );
        }
        if ( substr( $propertys, -1, 1 ) == "," )
        {
            $propertys = substr( $propertys, 0, -1 );
        }
        if ( strpos( $propertys, "ID" ) === FALSE )
        {
            $propertys .= ",ID";
        }
        $keyValueMap = array( );
        $arr_property = explode( ",", $propertys );
        foreach ( $arr_property as $key )
        {
            $keyValueMap[trim( $key )] = self::$dbToPropertyKeys[trim( $key )]( self::$dbToPropertyKeys[trim( $key )] );
        }
        $where_definitions = $OBJ_SQL_SYNTAX->getConditionExpr( "ID", EXPR_OP_IS, $obj->_get( "id" ), FIELD_TYPE_INT );
        $sql = $OBJ_SQL_SYNTAX->getUpdateSQL( "flow_run_prcs", $keyValueMap, $where_definitions );
        exequery( $r_connection, $sql, TRUE );
    }

}

?>
