<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class MyWorkListDB
{

    public static $OBJ_SQL_SYNTAX;
    public static $QUERY_TYPE_DIM = 0;
    public static $QUEYR_TYPE_ADV = 1;
    public static $ORDER_BY_RUN_ID_DESC = 0;
    public static $ORDER_BY_RUN_ID_ASC = 1;
    public static $ORDER_BY_FLOW_TYPE_DESC = 2;
    public static $ORDER_BY_FLOW_TYPE_ASC = 3;
    public static $ORDER_BY_RUN_NAME_DESC = 4;
    public static $ORDER_BY_RUN_NAME_ASC = 5;
    public static $ORDER_BY_CREATE_TIME_DESC = 6;
    public static $ORDER_BY_CREATE_TIME_ASC = 7;
    public static $ORDER_BY_PRCS_TIME_DESC = 8;
    public static $ORDER_BY_PRCS_TIME_ASC = 9;
    public static $ORDER_BY_DELIVER_TIME_DESC = 10;
    public static $ORDER_BY_DELIVER_TIME_ASC = 11;
    public static $ORDER_BY_FLOW_RUN_ID_DESC = 12;
    public static $ORDER_BY_FLOW_RUN_ID_ASC = 13;
    public static $ORDER_BY_PRCS_FLAG_ASC = 14;
    public static $ORDER_BY_PRCS_FLAG_DESC = 15;
    public static $ORDER_BY_RUN_ID_SET_ASC = 16;
    public static $ORDER_BY_RUN_ID_SET_DESC = 17;
    public static $PRCS_FLAG_TO_DO = "todo";
    public static $PRCS_FLAG_NOT_ACCEPT = "not_accept";
    public static $PRCS_FLAG_PROCESS = "process";
    public static $PRCS_FLAG_FINISH = "finish";
    public static $PRCS_FLAG_PAUSE = "pause";
    public static $PRCS_FLAG_ALL = "all";
    public static $PRCS_FLAG_DEPUTE = "depute";
    public static $PRCS_FLAG_FOCUS = "focus";
    private $user_id;
    private $dim_str;
    private $flow_id;
    private $run_id;
    private $run_name;
    private $work_level;
    private $prcs_flag;
    private $time_out_flag;
    private $_order_by_way = 0;
    private $flow_status;
    private $_query_type = 0;

    public function __construct( )
    {
        self::$OBJ_SQL_SYNTAX = ( MYOA_DBMS );
    }

    public function _get( $property_name )
    {
        $property_name = strtolower( $property_name );
        if ( isset( $this->$property_name ) )
        {
            return $this->$property_name;
        }
    }

    public function _set( $property_name, $value )
    {
        $property_name = strtolower( $property_name );
        $this->$property_name = $value;
    }

    public function setOrderByWay( $order_by_way )
    {
        $this->_order_by_way = $order_by_way;
    }

    public function getOrderByWay( )
    {
        return $this->_order_by_way;
    }

    public function setQueryType( $query_type )
    {
        $this->_query_type = $query_type;
    }

    public function getQueryType( )
    {
        return $this->_query_type;
    }

    public function getToDoWorkList( $start_pos, $row_count, $r_connection = NULL )
    {
        $work_list = array( );
        if ( $r_connection == NULL )
        {
            $r_connection = ( );
        }
        $selectExpr = self::$OBJ_SQL_SYNTAX->getSelectExprs( "\tFLOW_RUN.RUN_ID,\r\n                                                    FLOW_RUN.WORK_LEVEL,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN.FLOW_ID,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN.RUN_NAME,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN.BEGIN_USER,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN.BEGIN_DEPT,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.ID AS PRCS_KEY_ID,\r\n        \t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.USER_ID,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.PRCS_ID,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.FLOW_PRCS,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.COMMENT,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.OP_FLAG,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.TOP_FLAG,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.PRCS_FLAG,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.TIME_OUT_FLAG,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.PRCS_TIME,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.CREATE_TIME,\r\n                                                    FLOW_RUN_PRCS.DELIVER_TIME,\r\n\t\t\t        \t\t\t\t\t\t\t\tFLOW_RUN_PRCS.TIME_OUT_TYPE,\r\n\t\t\t        \t\t\t\t\t\t\t\tFLOW_RUN_PRCS.TIME_OUT_ATTEND,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.TIME_OUT" );
        $table_references = self::$OBJ_SQL_SYNTAX->getTableReferences( "FLOW_RUN_PRCS", "INNER JOIN", "FLOW_RUN", self::$OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_RUN.RUN_ID", EXPR_OP_IS, "FLOW_RUN_PRCS.RUN_ID", FIELD_TYPE_EXPR ) );
        $conditions = array( );
        $conditions[] = self::$PRCS_FLAG_TO_DO( self::$PRCS_FLAG_TO_DO );
        $conditions[] = $this->getFlowRunFilters( );
        $where_definition = self::$OBJ_SQL_SYNTAX->getWhereDefinition( $conditions, CONDITION_LOGIC_OP_AND );
        $order_definition = self::$PRCS_FLAG_TO_DO( self::$PRCS_FLAG_TO_DO );
        $sql = self::$OBJ_SQL_SYNTAX->getQuerySQL( $start_pos, $row_count, $selectExpr, $table_references, $where_definition, $order_definition );
        $r_cursor = exequery( $r_connection, $sql );
        while ( $row = mysql_fetch_array( $r_cursor ) )
        {
            $config = array( "TIME_OUT" => $row['TIME_OUT'], "TIME_OUT_MODIFY" => $row['TIME_OUT_MODIFY'], "TIME_OUT_TYPE" => $row['TIME_OUT_TYPE'], "TIME_OUT_ATTEND" => $row['TIME_OUT_ATTEND'] );
            $work_time = getworkitemtime( $row['USER_ID'], $row['CREATE_TIME'], $row['PRCS_TIME'], $row['DELIVER_TIME'], $config );
            $work_item = new WorkItem( );
            $row['PRCS_KEY_ID']( "id", $row['PRCS_KEY_ID'] );
            $row['RUN_ID']( "run_id", $row['RUN_ID'] );
            $row['FLOW_ID']( "flow_id", $row['FLOW_ID'] );
            $row['WORK_LEVEL']( "work_level", $row['WORK_LEVEL'] );
            $row['RUN_NAME']( "run_name", $row['RUN_NAME'] );
            $row['BEGIN_USER']( "flow_start_user", $row['BEGIN_USER'] );
            $row['BEGIN_DEPT']( "begin_dept", $row['BEGIN_DEPT'] );
            $row['USER_ID']( "user_id", $row['USER_ID'] );
            $row['PRCS_ID']( "prcs_id", $row['PRCS_ID'] );
            $row['FLOW_PRCS']( "flow_prcs", $row['FLOW_PRCS'] );
            $row['OP_FLAG']( "op_flag", $row['OP_FLAG'] );
            $row['TOP_FLAG']( "top_flag", $row['TOP_FLAG'] );
            $row['PRCS_FLAG']( "prcs_flag", $row['PRCS_FLAG'] );
            $row['CREATE_TIME']( "create_time", $row['CREATE_TIME'] );
            $row['PRCS_TIME']( "prcs_time", $row['PRCS_TIME'] );
            $row['TIME_OUT_FLAG']( "time_out_flag", $row['TIME_OUT_FLAG'] );
            $row['TIME_OUT']( "time_out", $row['TIME_OUT'] );
            $row['TIME_OUT_TYPE']( "time_out_type", $row['TIME_OUT_TYPE'] );
            $row['TIME_OUT_ATTEND']( "time_out_attend", $row['TIME_OUT_ATTEND'] );
            $row['COMMENT']( "comment", $row['COMMENT'] );
            $work_item->_set( "work_time", $work_time );
            $work_list[] = $work_item;
        }
        return $work_list;
    }

    public function getToDoWorkListCount( $r_connection = NULL )
    {
        $count = 0;
        if ( $r_connection == NULL )
        {
            $r_connection = ( );
        }
        $select_expr = self::$OBJ_SQL_SYNTAX->getSelectExprs( "COUNT(FLOW_RUN_PRCS.RUN_ID) as COUNT" );
        $table_references = self::$OBJ_SQL_SYNTAX->getTableReferences( "FLOW_RUN_PRCS", "INNER JOIN", "FLOW_RUN", self::$OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_RUN.RUN_ID", EXPR_OP_IS, "FLOW_RUN_PRCS.RUN_ID", FIELD_TYPE_EXPR ) );
        $conditions = array( );
        $conditions[] = self::$PRCS_FLAG_TO_DO( self::$PRCS_FLAG_TO_DO );
        $conditions[] = $this->getFlowRunFilters( );
        $where_definition = self::$OBJ_SQL_SYNTAX->getWhereDefinition( $conditions, CONDITION_LOGIC_OP_AND );
        $sql = self::$OBJ_SQL_SYNTAX->getQuerySQL( 0, 0, $select_expr, $table_references, $where_definition );
        $r_cursor = exequery( $r_connection, $sql );
        if ( $row = mysql_fetch_array( $r_cursor ) )
        {
            $count = $row['COUNT'];
        }
        return $count;
    }

    public function getNotAcceptWorkList( $start_pos, $row_count, $r_connection = NULL )
    {
        $work_list = array( );
        if ( $r_connection == NULL )
        {
            $r_connection = ( );
        }
        $selectExpr = self::$OBJ_SQL_SYNTAX->getSelectExprs( "FLOW_RUN.RUN_ID,\r\n                                                    FLOW_RUN.WORK_LEVEL,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN.FLOW_ID,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN.RUN_NAME,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN.BEGIN_USER,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.ID AS PRCS_KEY_ID,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.PRCS_ID,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.FLOW_PRCS,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.COMMENT,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.OP_FLAG,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.PRCS_FLAG,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.TIME_OUT_FLAG,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.PRCS_TIME,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.CREATE_TIME,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.TIME_OUT" );
        $table_references = self::$OBJ_SQL_SYNTAX->getTableReferences( "FLOW_RUN_PRCS", "INNER JOIN", "FLOW_RUN", self::$OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_RUN.RUN_ID", EXPR_OP_IS, "FLOW_RUN_PRCS.RUN_ID", FIELD_TYPE_EXPR ) );
        $conditions = array( );
        $conditions = self::$PRCS_FLAG_NOT_ACCEPT( self::$PRCS_FLAG_NOT_ACCEPT );
        $conditions = $this->getFlowRunFilters( );
        $where_definition = self::$OBJ_SQL_SYNTAX->getWhereDefinition( $conditions, CONDITION_LOGIC_OP_AND );
        $order_definition = self::$PRCS_FLAG_NOT_ACCEPT( self::$PRCS_FLAG_NOT_ACCEPT );
        $sql = self::$OBJ_SQL_SYNTAX->getQuerySQL( $start_pos, $row_count, $selectExpr, $table_references, $where_definition, $order_definition );
        $r_cursor = exequery( $r_connection, $sql );
        while ( $row = mysql_fetch_array( $r_cursor ) )
        {
            $work_item = new WorkItem( );
            $row['PRCS_KEY_ID']( "id", $row['PRCS_KEY_ID'] );
            $row['RUN_ID']( "run_id", $row['RUN_ID'] );
            $row['FLOW_ID']( "flow_id", $row['FLOW_ID'] );
            $row['WORK_LEVEL']( "work_level", $row['WORK_LEVEL'] );
            $row['RUN_NAME']( "run_name", $row['RUN_NAME'] );
            $row['BEGIN_USER']( "flow_start_user", $row['BEGIN_USER'] );
            $row['PRCS_ID']( "prcs_id", $row['PRCS_ID'] );
            $row['FLOW_PRCS']( "flow_prcs", $row['FLOW_PRCS'] );
            $row['OP_FLAG']( "op_flag", $row['OP_FLAG'] );
            $row['PRCS_FLAG']( "prcs_flag", $row['PRCS_FLAG'] );
            $row['CREATE_TIME']( "create_time", $row['CREATE_TIME'] );
            $row['PRCS_TIME']( "prcs_time", $row['PRCS_TIME'] );
            $row['TIME_OUT_FLAG']( "time_out_flag", $row['TIME_OUT_FLAG'] );
            $row['TIME_OUT']( "time_out", $row['TIME_OUT'] );
            $row['COMMENT']( "comment", $row['COMMENT'] );
            array_push( &$work_list, $work_item );
        }
        return $work_list;
    }

    public function getNotAcceptWorkListCount( $r_connection = NULL )
    {
        $count = 0;
        if ( $r_connection == NULL )
        {
            $r_connection = ( );
        }
        $select_expr = self::$OBJ_SQL_SYNTAX->getSelectExprs( "COUNT(FLOW_RUN_PRCS.RUN_ID) as COUNT" );
        $table_references = self::$OBJ_SQL_SYNTAX->getTableReferences( "FLOW_RUN_PRCS", "INNER JOIN", "FLOW_RUN", self::$OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_RUN.RUN_ID", EXPR_OP_IS, "FLOW_RUN_PRCS.RUN_ID", FIELD_TYPE_EXPR ) );
        $conditions = array( );
        $conditions[] = self::$PRCS_FLAG_NOT_ACCEPT( self::$PRCS_FLAG_NOT_ACCEPT );
        $conditions[] = $this->getFlowRunFilters( );
        $where_definition = self::$OBJ_SQL_SYNTAX->getWhereDefinition( $conditions, CONDITION_LOGIC_OP_AND );
        $sql = self::$OBJ_SQL_SYNTAX->getQuerySQL( 0, 0, $select_expr, $table_references, $where_definition );
        $r_cursor = exequery( $r_connection, $sql );
        if ( $row = mysql_fetch_array( $r_cursor ) )
        {
            $count = $row['COUNT'];
        }
        return $count;
    }

    public function getProcessWorkList( $start_pos, $row_count, $r_connection = NULL )
    {
        $work_list = array( );
        if ( $r_connection == NULL )
        {
            $r_connection = ( );
        }
        $selectExpr = self::$OBJ_SQL_SYNTAX->getSelectExprs( "\tFLOW_RUN.RUN_ID,\r\n                                                    FLOW_RUN.WORK_LEVEL,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN.FLOW_ID,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN.RUN_NAME,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN.BEGIN_USER,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.ID AS PRCS_KEY_ID,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.PRCS_ID,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.FLOW_PRCS,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.COMMENT,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.OP_FLAG,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.PRCS_FLAG,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.TIME_OUT_FLAG,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.PRCS_TIME,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.CREATE_TIME,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.TIME_OUT" );
        $table_references = self::$OBJ_SQL_SYNTAX->getTableReferences( "FLOW_RUN_PRCS", "INNER JOIN", "FLOW_RUN", self::$OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_RUN.RUN_ID", EXPR_OP_IS, "FLOW_RUN_PRCS.RUN_ID", FIELD_TYPE_EXPR ) );
        $conditions = array( );
        $conditions[] = self::$PRCS_FLAG_PROCESS( self::$PRCS_FLAG_PROCESS );
        $conditions[] = $this->getFlowRunFilters( );
        $where_definition = self::$OBJ_SQL_SYNTAX->getWhereDefinition( $conditions, CONDITION_LOGIC_OP_AND );
        $order_definition = self::$PRCS_FLAG_PROCESS( self::$PRCS_FLAG_PROCESS );
        $sql = self::$OBJ_SQL_SYNTAX->getQuerySQL( $start_pos, $row_count, $selectExpr, $table_references, $where_definition, $order_definition );
        $r_cursor = exequery( $r_connection, $sql );
        while ( $row = mysql_fetch_array( $r_cursor ) )
        {
            $config = gettimeoutconfig( $row['FLOW_ID'], $row['FLOW_PRCS'] );
            $work_time = getworkitemtime( $row['USER_ID'], $row['CREATE_TIME'], $row['PRCS_TIME'], $row['DELIVER_TIME'], $config );
            $work_item = new WorkItem( );
            $row['PRCS_KEY_ID']( "id", $row['PRCS_KEY_ID'] );
            $row['RUN_ID']( "run_id", $row['RUN_ID'] );
            $row['FLOW_ID']( "flow_id", $row['FLOW_ID'] );
            $row['WORK_LEVEL']( "work_level", $row['WORK_LEVEL'] );
            $row['RUN_NAME']( "run_name", $row['RUN_NAME'] );
            $row['BEGIN_USER']( "flow_start_user", $row['BEGIN_USER'] );
            $row['PRCS_ID']( "prcs_id", $row['PRCS_ID'] );
            $row['FLOW_PRCS']( "flow_prcs", $row['FLOW_PRCS'] );
            $row['OP_FLAG']( "op_flag", $row['OP_FLAG'] );
            $row['PRCS_FLAG']( "prcs_flag", $row['PRCS_FLAG'] );
            $row['CREATE_TIME']( "create_time", $row['CREATE_TIME'] );
            $row['PRCS_TIME']( "prcs_time", $row['PRCS_TIME'] );
            $row['TIME_OUT_FLAG']( "time_out_flag", $row['TIME_OUT_FLAG'] );
            $config['TIME_OUT']( "time_out", $config['TIME_OUT'] );
            $work_item->_set( "{$work_time}", $work_time );
            $row['COMMENT']( "comment", $row['COMMENT'] );
            array_push( &$work_list, $work_item );
        }
        return $work_list;
    }

    public function getProcessWorkListCount( $r_connection = NULL )
    {
        $count = 0;
        if ( $r_connection == NULL )
        {
            $r_connection = ( );
        }
        $select_expr = self::$OBJ_SQL_SYNTAX->getSelectExprs( "COUNT(FLOW_RUN_PRCS.RUN_ID) as COUNT" );
        $table_references = self::$OBJ_SQL_SYNTAX->getTableReferences( "FLOW_RUN_PRCS", "INNER JOIN", "FLOW_RUN", self::$OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_RUN.RUN_ID", EXPR_OP_IS, "FLOW_RUN_PRCS.RUN_ID", FIELD_TYPE_EXPR ) );
        $conditions = array( );
        $conditions[] = self::$PRCS_FLAG_PROCESS( self::$PRCS_FLAG_PROCESS );
        $conditions[] = $this->getFlowRunFilters( );
        $where_definition = self::$OBJ_SQL_SYNTAX->getWhereDefinition( $conditions, CONDITION_LOGIC_OP_AND );
        $sql = self::$OBJ_SQL_SYNTAX->getQuerySQL( 0, 0, $select_expr, $table_references, $where_definition );
        $r_cursor = exequery( $r_connection, $sql );
        if ( $row = mysql_fetch_array( $r_cursor ) )
        {
            $count = $row['COUNT'];
        }
        return $count;
    }

    public function getOverWorkList( $start_pos, $row_count, $r_connection = NULL )
    {
        $work_list = array( );
        if ( $r_connection == NULL )
        {
            $r_connection = ( );
        }
        $selectExpr = self::$OBJ_SQL_SYNTAX->getSelectExprs( "FLOW_RUN.RUN_ID, MAX(FLOW_RUN_PRCS.DELIVER_TIME) AS DELIVER_TIME" );
        $table_references = self::$OBJ_SQL_SYNTAX->getTableReferences( "FLOW_RUN_PRCS", "INNER JOIN", "FLOW_RUN", self::$OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_RUN.RUN_ID", EXPR_OP_IS, "FLOW_RUN_PRCS.RUN_ID", FIELD_TYPE_EXPR ) );
        $conditions = array( );
        $conditions[] = self::$PRCS_FLAG_FINISH( self::$PRCS_FLAG_FINISH );
        $conditions[] = $this->getFlowRunFilters( );
        $where_definition = self::$OBJ_SQL_SYNTAX->getWhereDefinition( $conditions, CONDITION_LOGIC_OP_AND );
        $order_definition = self::$PRCS_FLAG_FINISH( self::$PRCS_FLAG_FINISH );
        $group_by_definition = " FLOW_RUN.RUN_ID ";
        $sql = self::$OBJ_SQL_SYNTAX->getQuerySQL( $start_pos, $row_count, $selectExpr, $table_references, $where_definition, $order_definition, NULL, $group_by_definition );
        $r_cursor = exequery( $r_connection, $sql );
        while ( $row = mysql_fetch_array( $r_cursor ) )
        {
            $run_ids .= $row['RUN_ID'].",";
            $list[$row['RUN_ID']] = array( "FLOW_ID" => $row['FLOW_ID'], "FLOW_NAME" => getflowname( $row['FLOW_ID'] ), "RUN_NAME" => $row['RUN_NAME'], "BEGIN_DEPT" => $row['BEGIN_DEPT'], "PRCS_INFO" => array( ) );
        }
        if ( $run_ids != "" )
        {
            $run_ids = substr( $run_ids, 0, -1 );
            $selectExpr = self::$OBJ_SQL_SYNTAX->getSelectExprs( "\tFLOW_RUN.RUN_ID,\r\n                                                    FLOW_RUN.WORK_LEVEL,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN.FLOW_ID,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN.RUN_NAME,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN.BEGIN_USER,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN.END_TIME,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.ID AS PRCS_KEY_ID,\r\n        \t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.USER_ID,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.PRCS_ID,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.FLOW_PRCS,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.COMMENT,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.OP_FLAG,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.TOP_FLAG,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.PRCS_FLAG,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.TIME_OUT_FLAG,\r\n\t\t\t\t\t\t\t\t\t        \t\tFLOW_RUN_PRCS.PRCS_TIME,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.CREATE_TIME,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.DELIVER_TIME,\r\n\t\t\t        \t\t\t\t\t\t\t\tFLOW_RUN_PRCS.TIME_OUT_TYPE,\r\n\t\t\t        \t\t\t\t\t\t\t\tFLOW_RUN_PRCS.TIME_OUT_ATTEND,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.TIME_OUT" );
            $table_references = self::$OBJ_SQL_SYNTAX->getTableReferences( "FLOW_RUN_PRCS", "INNER JOIN", "FLOW_RUN", self::$OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_RUN.RUN_ID", EXPR_OP_IS, "FLOW_RUN_PRCS.RUN_ID", FIELD_TYPE_EXPR ) );
            $conditions = array( );
            $conditions[] = self::$PRCS_FLAG_FINISH( self::$PRCS_FLAG_FINISH );
            $conditions[] = $this->getFlowRunFilters( );
            $where_definition = self::$OBJ_SQL_SYNTAX->getWhereDefinition( $conditions, CONDITION_LOGIC_OP_AND );
            $where_definition .= " AND FLOW_RUN_PRCS.RUN_ID IN (".$run_ids.") ";
            $order_definition = self::$PRCS_FLAG_FINISH( self::$PRCS_FLAG_FINISH );
            $sql = self::$OBJ_SQL_SYNTAX->getQuerySQL( "", "", $selectExpr, $table_references, $where_definition, $order_definition );
            file_put_contents( "sql1.txt", var_export( $sql, TRUE ) );
            $r_cursor = exequery( $r_connection, $sql );
            while ( $row = mysql_fetch_array( $r_cursor ) )
            {
                $config = array( "TIME_OUT" => $row['TIME_OUT'], "TIME_OUT_MODIFY" => $row['TIME_OUT_MODIFY'], "TIME_OUT_TYPE" => $row['TIME_OUT_TYPE'], "TIME_OUT_ATTEND" => $row['TIME_OUT_ATTEND'] );
                $work_time = getworkitemtime( $row['USER_ID'], $row['CREATE_TIME'], $row['PRCS_TIME'], $row['DELIVER_TIME'], $config );
                $list[$row['RUN_ID']]['PRCS_INFO'][] = array( "id" => $row['PRCS_KEY_ID'], "run_id" => $row['RUN_ID'], "flow_id" => $row['FLOW_ID'], "work_level" => $row['WORK_LEVEL'], "run_name" => $row['RUN_NAME'], "flow_start_user" => $row['BEGIN_USER'], "prcs_id" => $row['PRCS_ID'], "flow_prcs" => $row['FLOW_PRCS'], "op_flag" => $row['OP_FLAG'], "top_flag" => $row['TOP_FLAG'], "prcs_flag" => $row['PRCS_FLAG'], "delivery_time" => $row['DELIVER_TIME'], "time_out_flag" => $row['TIME_OUT_FLAG'], "time_out" => $row['TIME_OUT'], "comment" => $row['COMMENT'], "time_out_type" => $row['TIME_OUT_TYPE'], "time_out_attend" => $row['TIME_OUT_ATTEND'], "flow_end_time" => $row['END_TIME'], "work_time" => $work_time );
            }
            return $list;
        }
    }

    public function getOverWorkListCount( $r_connection = NULL )
    {
        $count = 0;
        if ( $r_connection == NULL )
        {
            $r_connection = ( );
        }
        $select_expr = self::$OBJ_SQL_SYNTAX->getSelectExprs( "COUNT(DISTINCT FLOW_RUN_PRCS.RUN_ID) as COUNT" );
        $table_references = self::$OBJ_SQL_SYNTAX->getTableReferences( "FLOW_RUN_PRCS", "INNER JOIN", "FLOW_RUN", self::$OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_RUN.RUN_ID", EXPR_OP_IS, "FLOW_RUN_PRCS.RUN_ID", FIELD_TYPE_EXPR ) );
        $conditions = array( );
        $conditions[] = self::$PRCS_FLAG_FINISH( self::$PRCS_FLAG_FINISH );
        $conditions[] = $this->getFlowRunFilters( );
        $where_definition = self::$OBJ_SQL_SYNTAX->getWhereDefinition( $conditions, CONDITION_LOGIC_OP_AND );
        $sql = self::$OBJ_SQL_SYNTAX->getQuerySQL( 0, 0, $select_expr, $table_references, $where_definition );
        $r_cursor = exequery( $r_connection, $sql );
        if ( $row = mysql_fetch_array( $r_cursor ) )
        {
            $count = $row['COUNT'];
        }
        return $count;
    }

    public function getDeputeWorkList( $start_pos, $row_count, $r_connection = NULL )
    {
        $work_list = array( );
        if ( $r_connection == NULL )
        {
            $r_connection = ( );
        }
        $selectExpr = self::$OBJ_SQL_SYNTAX->getSelectExprs( "\tFLOW_RUN.RUN_ID,\r\n                                                    FLOW_RUN.WORK_LEVEL,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN.FLOW_ID,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN.RUN_NAME,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN.BEGIN_USER,\r\n                                                    FLOW_RUN.END_TIME,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.ID AS PRCS_KEY_ID,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.PRCS_ID,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.FLOW_PRCS,\r\n                                                    FLOW_RUN_PRCS.USER_ID,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.COMMENT,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.OP_FLAG,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.PRCS_FLAG,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.TIME_OUT_FLAG,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.PRCS_TIME,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.TIME_OUT,\r\n                                                    count(distinct FLOW_RUN.RUN_ID,FLOW_RUN.FLOW_ID,FLOW_RUN_PRCS.PRCS_ID,FLOW_RUN_PRCS.FLOW_PRCS)" );
        $table_references = self::$OBJ_SQL_SYNTAX->getTableReferences( "FLOW_RUN_PRCS", "INNER JOIN", "FLOW_RUN", self::$OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_RUN.RUN_ID", EXPR_OP_IS, "FLOW_RUN_PRCS.RUN_ID", FIELD_TYPE_EXPR ) );
        $conditions = array( );
        $conditions[] = self::$PRCS_FLAG_DEPUTE( self::$PRCS_FLAG_DEPUTE );
        $conditions[] = $this->getFlowRunFilters( );
        $where_definition = self::$OBJ_SQL_SYNTAX->getWhereDefinition( $conditions, CONDITION_LOGIC_OP_AND );
        $order_definition = self::$PRCS_FLAG_DEPUTE( self::$PRCS_FLAG_DEPUTE );
        $group_by_definition = " FLOW_RUN.RUN_ID,FLOW_RUN.FLOW_ID,FLOW_RUN_PRCS.PRCS_ID,FLOW_RUN_PRCS.FLOW_PRCS ";
        $sql = self::$OBJ_SQL_SYNTAX->getQuerySQL( $start_pos, $row_count, $selectExpr, $table_references, $where_definition, $order_definition, NULL, $group_by_definition );
        $r_cursor = exequery( $r_connection, $sql );
        while ( $row = mysql_fetch_array( $r_cursor ) )
        {
            $work_item = new WorkItem( );
            $row['PRCS_KEY_ID']( "id", $row['PRCS_KEY_ID'] );
            $row['RUN_ID']( "run_id", $row['RUN_ID'] );
            $row['FLOW_ID']( "flow_id", $row['FLOW_ID'] );
            $row['WORK_LEVEL']( "work_level", $row['WORK_LEVEL'] );
            $row['RUN_NAME']( "run_name", $row['RUN_NAME'] );
            $row['BEGIN_USER']( "flow_start_user", $row['BEGIN_USER'] );
            $row['PRCS_ID']( "prcs_id", $row['PRCS_ID'] );
            $row['FLOW_PRCS']( "flow_prcs", $row['FLOW_PRCS'] );
            $row['USER_ID']( "user_id", $row['USER_ID'] );
            $row['OP_FLAG']( "op_flag", $row['OP_FLAG'] );
            $row['PRCS_FLAG']( "prcs_flag", $row['PRCS_FLAG'] );
            $row['PRCS_TIME']( "prcs_time", $row['PRCS_TIME'] );
            $row['TIME_OUT_FLAG']( "time_out_flag", $row['TIME_OUT_FLAG'] );
            $row['TIME_OUT']( "time_out", $row['TIME_OUT'] );
            $row['COMMENT']( "comment", $row['COMMENT'] );
            $row['END_TIME']( "flow_end_time", $row['END_TIME'] );
            array_push( &$work_list, $work_item );
        }
        return $work_list;
    }

    public function getDeputeWorkListCount( $r_connection = NULL )
    {
        $count = 0;
        if ( $r_connection == NULL )
        {
            $r_connection = ( );
        }
        $select_expr = self::$OBJ_SQL_SYNTAX->getSelectExprs( "COUNT(FLOW_RUN_PRCS.RUN_ID) as COUNT" );
        $table_references = self::$OBJ_SQL_SYNTAX->getTableReferences( "FLOW_RUN_PRCS", "INNER JOIN", "FLOW_RUN", self::$OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_RUN.RUN_ID", EXPR_OP_IS, "FLOW_RUN_PRCS.RUN_ID", FIELD_TYPE_EXPR ) );
        $conditions = array( );
        $conditions[] = self::$PRCS_FLAG_DEPUTE( self::$PRCS_FLAG_DEPUTE );
        $conditions[] = $this->getFlowRunFilters( );
        $where_definition = self::$OBJ_SQL_SYNTAX->getWhereDefinition( $conditions, CONDITION_LOGIC_OP_AND );
        $sql = self::$OBJ_SQL_SYNTAX->getQuerySQL( 0, 0, $select_expr, $table_references, $where_definition );
        $r_cursor = exequery( $r_connection, $sql );
        if ( $row = mysql_fetch_array( $r_cursor ) )
        {
            $count = $row['COUNT'];
        }
        return $count;
    }

    public function getFocusWorkList( $start_pos, $row_count, $r_connection = NULL )
    {
        $work_list = array( );
        if ( $r_connection == NULL )
        {
            $r_connection = ( );
        }
        $selectExpr = self::$OBJ_SQL_SYNTAX->getSelectExprs( "\tFLOW_RUN.RUN_ID,\r\n                                                    FLOW_RUN.WORK_LEVEL,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN.FLOW_ID,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN.RUN_NAME,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN.BEGIN_USER,\r\n                                                    FLOW_RUN.BEGIN_TIME,\r\n                                                    FLOW_RUN.END_TIME,\r\n                                                    FLOW_RUN.BEGIN_DEPT,\r\n                                                    FLOW_RUN.PARENT_RUN,\r\n                                                    FLOW_RUN.ATTACHMENT_ID,\r\n                                                    FLOW_RUN.ATTACHMENT_NAME,\r\n                                                    FLOW_RUN.ARCHIVE,\r\n                                                    FLOW_RUN.FOCUS_USER " );
        $table_references = self::$OBJ_SQL_SYNTAX->getTableReferences( "FLOW_RUN" );
        $where_definition = self::$PRCS_FLAG_FOCUS( self::$PRCS_FLAG_FOCUS );
        $order_definition = self::$PRCS_FLAG_FOCUS( self::$PRCS_FLAG_FOCUS );
        $sql = self::$OBJ_SQL_SYNTAX->getQuerySQL( $start_pos, $row_count, $selectExpr, $table_references, $where_definition, $order_definition );
        $work_list = array( );
        $r_cursor = exequery( $r_connection, $sql );
        while ( $row = mysql_fetch_array( $r_cursor ) )
        {
            $work_list[$row['RUN_ID']] = array( );
            $work_list[$row['RUN_ID']]['RUN_NAME'] = $row['RUN_NAME'];
            $work_list[$row['RUN_ID']]['FLOW_ID'] = $row['FLOW_ID'];
            $work_list[$row['RUN_ID']]['WORK_LEVEL'] = $row['WORK_LEVEL'];
            $work_list[$row['RUN_ID']]['BEGIN_USER'] = $row['BEGIN_USER'];
            $work_list[$row['RUN_ID']]['BEGIN_TIME'] = $row['BEGIN_TIME'];
            $work_list[$row['RUN_ID']]['END_TIME'] = $row['END_TIME'];
            $work_list[$row['RUN_ID']]['BEGIN_DEPT'] = $row['BEGIN_DEPT'];
            $work_list[$row['RUN_ID']]['PARENT_RUN'] = $row['PARENT_RUN'];
            $work_list[$row['RUN_ID']]['ATTACHMENT_ID'] = $row['ATTACHMENT_ID'];
            $work_list[$row['RUN_ID']]['ATTACHMENT_NAME'] = $row['ATTACHMENT_NAME'];
            $work_list[$row['RUN_ID']]['FOCUS_USER'] = $row['FOCUS_USER'];
        }
        return $work_list;
    }

    public function getFocusWorkListCount( $r_connection = NULL )
    {
        $count = 0;
        if ( $r_connection == NULL )
        {
            $r_connection = ( );
        }
        $select_expr = self::$OBJ_SQL_SYNTAX->getSelectExprs( "COUNT(FLOW_RUN.RUN_ID) as COUNT" );
        $table_references = self::$OBJ_SQL_SYNTAX->getTableReferences( "FLOW_RUN" );
        $where_definition = self::$PRCS_FLAG_FOCUS( self::$PRCS_FLAG_FOCUS );
        $sql = self::$OBJ_SQL_SYNTAX->getQuerySQL( 0, 0, $select_expr, $table_references, $where_definition );
        $r_cursor = exequery( $r_connection, $sql );
        if ( $row = mysql_fetch_array( $r_cursor ) )
        {
            $count = $row['COUNT'];
        }
        return $count;
    }

    public function getHangUpWorkList( $start_pos, $row_count, $r_connection = NULL )
    {
        $work_list = array( );
        if ( $r_connection == NULL )
        {
            $r_connection = ( );
        }
        $selectExpr = self::$OBJ_SQL_SYNTAX->getSelectExprs( "\tFLOW_RUN.RUN_ID,\r\n                                                    FLOW_RUN.WORK_LEVEL,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN.FLOW_ID,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN.RUN_NAME,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN.BEGIN_USER,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.ID AS PRCS_KEY_ID,\r\n        \t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.USER_ID,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.PRCS_ID,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.FLOW_PRCS,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.COMMENT,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.OP_FLAG,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.TOP_FLAG,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.PRCS_FLAG,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.TIME_OUT_FLAG,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.PRCS_TIME,\r\n                                                    FLOW_RUN_PRCS.ACTIVE_TIME,\r\n                                                    FLOW_RUN_PRCS.CREATE_TIME,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.DELIVER_TIME,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.TIME_OUT_TYPE,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.TIME_OUT_ATTEND,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.TIME_OUT" );
        $table_references = self::$OBJ_SQL_SYNTAX->getTableReferences( "FLOW_RUN_PRCS", "INNER JOIN", "FLOW_RUN", self::$OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_RUN.RUN_ID", EXPR_OP_IS, "FLOW_RUN_PRCS.RUN_ID", FIELD_TYPE_EXPR ) );
        $conditions = array( );
        $conditions[] = self::$PRCS_FLAG_PAUSE( self::$PRCS_FLAG_PAUSE );
        $conditions[] = $this->getFlowRunFilters( );
        $where_definition = self::$OBJ_SQL_SYNTAX->getWhereDefinition( $conditions, CONDITION_LOGIC_OP_AND );
        $order_definition = self::$PRCS_FLAG_PAUSE( self::$PRCS_FLAG_PAUSE );
        $sql = self::$OBJ_SQL_SYNTAX->getQuerySQL( $start_pos, $row_count, $selectExpr, $table_references, $where_definition, $order_definition );
        $r_cursor = exequery( $r_connection, $sql );
        while ( $row = mysql_fetch_array( $r_cursor ) )
        {
            $work_item = new WorkItem( );
            $config = array( "TIME_OUT" => $row['TIME_OUT'], "TIME_OUT_MODIFY" => $row['TIME_OUT_MODIFY'], "TIME_OUT_TYPE" => $row['TIME_OUT_TYPE'], "TIME_OUT_ATTEND" => $row['TIME_OUT_ATTEND'] );
            $work_time = getworkitemtime( $row['USER_ID'], $row['CREATE_TIME'], $row['PRCS_TIME'], $row['DELIVER_TIME'], $config );
            $row['PRCS_KEY_ID']( "id", $row['PRCS_KEY_ID'] );
            $row['RUN_ID']( "run_id", $row['RUN_ID'] );
            $row['FLOW_ID']( "flow_id", $row['FLOW_ID'] );
            $row['WORK_LEVEL']( "work_level", $row['WORK_LEVEL'] );
            $row['RUN_NAME']( "run_name", $row['RUN_NAME'] );
            $row['BEGIN_USER']( "flow_start_user", $row['BEGIN_USER'] );
            $row['PRCS_ID']( "prcs_id", $row['PRCS_ID'] );
            $row['FLOW_PRCS']( "flow_prcs", $row['FLOW_PRCS'] );
            $row['OP_FLAG']( "op_flag", $row['OP_FLAG'] );
            $row['TOP_FLAG']( "top_flag", $row['TOP_FLAG'] );
            $row['PRCS_FLAG']( "prcs_flag", $row['PRCS_FLAG'] );
            $row['PRCS_TIME']( "prcs_time", $row['PRCS_TIME'] );
            $row['TIME_OUT_FLAG']( "time_out_flag", $row['TIME_OUT_FLAG'] );
            $row['TIME_OUT']( "time_out", $row['TIME_OUT'] );
            $row['CREATE_TIME']( "create_time", $row['CREATE_TIME'] );
            $row['ACTIVE_TIME']( "active_time", $row['ACTIVE_TIME'] );
            $row['COMMENT']( "comment", $row['COMMENT'] );
            $work_item->_set( "work_time", $work_time );
            array_push( &$work_list, $work_item );
        }
        return $work_list;
    }

    public function getHangUpWorkListCount( $r_connection = NULL )
    {
        $count = 0;
        if ( $r_connection == NULL )
        {
            $r_connection = ( );
        }
        $select_expr = self::$OBJ_SQL_SYNTAX->getSelectExprs( "COUNT(FLOW_RUN_PRCS.RUN_ID) as COUNT" );
        $table_references = self::$OBJ_SQL_SYNTAX->getTableReferences( "FLOW_RUN_PRCS", "INNER JOIN", "FLOW_RUN", self::$OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_RUN.RUN_ID", EXPR_OP_IS, "FLOW_RUN_PRCS.RUN_ID", FIELD_TYPE_EXPR ) );
        $conditions = array( );
        $conditions[] = self::$PRCS_FLAG_PAUSE( self::$PRCS_FLAG_PAUSE );
        $conditions[] = $this->getFlowRunFilters( );
        $where_definition = self::$OBJ_SQL_SYNTAX->getWhereDefinition( $conditions, CONDITION_LOGIC_OP_AND );
        $sql = self::$OBJ_SQL_SYNTAX->getQuerySQL( 0, 0, $select_expr, $table_references, $where_definition );
        $r_cursor = exequery( $r_connection, $sql );
        if ( $row = mysql_fetch_array( $r_cursor ) )
        {
            $count = $row['COUNT'];
        }
        return $count;
    }

    public function getAllWorkList( $start_pos, $row_count, $r_connection = NULL )
    {
        $work_list = array( );
        if ( $r_connection == NULL )
        {
            $r_connection = ( );
        }
        $selectExpr = self::$OBJ_SQL_SYNTAX->getSelectExprs( "\tFLOW_RUN.RUN_ID,\r\n                                                    FLOW_RUN.WORK_LEVEL,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN.FLOW_ID,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN.RUN_NAME,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN.BEGIN_USER,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN.END_TIME,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.ID AS PRCS_KEY_ID,\r\n        \t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.USER_ID,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.PRCS_ID,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.FLOW_PRCS,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.COMMENT,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.OP_FLAG,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.TOP_FLAG,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.PRCS_FLAG,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.TIME_OUT_FLAG,\r\n\t\t\t\t\t\t\t\t\t        \t\tFLOW_RUN_PRCS.PRCS_TIME,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.CREATE_TIME,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.DELIVER_TIME,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.TIME_OUT_TYPE,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.TIME_OUT_ATTEND,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\tFLOW_RUN_PRCS.TIME_OUT" );
        $table_references = self::$OBJ_SQL_SYNTAX->getTableReferences( "FLOW_RUN_PRCS", "INNER JOIN", "FLOW_RUN", self::$OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_RUN.RUN_ID", EXPR_OP_IS, "FLOW_RUN_PRCS.RUN_ID", FIELD_TYPE_EXPR ) );
        $conditions = array( );
        if ( $this->flow_status == self::$PRCS_FLAG_NOT_ACCEPT )
        {
            $conditions[] = self::$PRCS_FLAG_NOT_ACCEPT( self::$PRCS_FLAG_NOT_ACCEPT );
        }
        else
        {
            if ( $this->flow_status == self::$PRCS_FLAG_PROCESS )
            {
                $conditions[] = self::$PRCS_FLAG_PROCESS( self::$PRCS_FLAG_PROCESS );
            }
            else
            {
                if ( $this->flow_status == self::$PRCS_FLAG_FINISH )
                {
                    $conditions[] = self::$PRCS_FLAG_FINISH( self::$PRCS_FLAG_FINISH );
                }
                else
                {
                    if ( $this->flow_status == self::$PRCS_FLAG_PAUSE )
                    {
                        $conditions[] = self::$PRCS_FLAG_PAUSE( self::$PRCS_FLAG_PAUSE );
                    }
                    else
                    {
                        $conditions[] = self::$PRCS_FLAG_ALL( self::$PRCS_FLAG_ALL );
                    }
                }
            }
        }
        $conditions[] = $this->getFlowRunFilters( );
        $where_definition = self::$OBJ_SQL_SYNTAX->getWhereDefinition( $conditions, CONDITION_LOGIC_OP_AND );
        $order_definition = $this->getOrderBy( );
        $sql = self::$OBJ_SQL_SYNTAX->getQuerySQL( $start_pos, $row_count, $selectExpr, $table_references, $where_definition, $order_definition );
        $r_cursor = exequery( $r_connection, $sql );
        while ( $row = mysql_fetch_array( $r_cursor ) )
        {
            $work_item = new WorkItem( );
            $config = array( "TIME_OUT" => $row['TIME_OUT'], "TIME_OUT_MODIFY" => $row['TIME_OUT_MODIFY'], "TIME_OUT_TYPE" => $row['TIME_OUT_TYPE'], "TIME_OUT_ATTEND" => $row['TIME_OUT_ATTEND'] );
            $work_time = getworkitemtime( $row['USER_ID'], $row['CREATE_TIME'], $row['PRCS_TIME'], $row['DELIVER_TIME'], $config );
            $row['PRCS_KEY_ID']( "id", $row['PRCS_KEY_ID'] );
            $row['RUN_ID']( "run_id", $row['RUN_ID'] );
            $row['FLOW_ID']( "flow_id", $row['FLOW_ID'] );
            $row['RUN_NAME']( "run_name", $row['RUN_NAME'] );
            $row['BEGIN_USER']( "flow_start_user", $row['BEGIN_USER'] );
            $row['PRCS_ID']( "prcs_id", $row['PRCS_ID'] );
            $row['FLOW_PRCS']( "flow_prcs", $row['FLOW_PRCS'] );
            $row['OP_FLAG']( "op_flag", $row['OP_FLAG'] );
            $row['TOP_FLAG']( "top_flag", $row['TOP_FLAG'] );
            $row['PRCS_FLAG']( "prcs_flag", $row['PRCS_FLAG'] );
            $row['DELIVER_TIME']( "delivery_time", $row['DELIVER_TIME'] );
            $row['TIME_OUT_FLAG']( "time_out_flag", $row['TIME_OUT_FLAG'] );
            $row['TIME_OUT']( "time_out", $row['TIME_OUT'] );
            $row['COMMENT']( "comment", $row['COMMENT'] );
            $row['END_TIME']( "flow_end_time", $row['END_TIME'] );
            $work_item->_set( "work_time", $work_time );
            array_push( &$work_list, $work_item );
        }
        return $work_list;
    }

    public function getAllWorkListCount( $r_connection = NULL )
    {
        $count = 0;
        if ( $r_connection == NULL )
        {
            $r_connection = ( );
        }
        $select_expr = self::$OBJ_SQL_SYNTAX->getSelectExprs( "COUNT(FLOW_RUN_PRCS.RUN_ID) as COUNT" );
        $table_references = self::$OBJ_SQL_SYNTAX->getTableReferences( "FLOW_RUN_PRCS", "INNER JOIN", "FLOW_RUN", self::$OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_RUN.RUN_ID", EXPR_OP_IS, "FLOW_RUN_PRCS.RUN_ID", FIELD_TYPE_EXPR ) );
        $conditions = array( );
        if ( $this->flow_status == self::$PRCS_FLAG_NOT_ACCEPT )
        {
            $conditions[] = self::$PRCS_FLAG_NOT_ACCEPT( self::$PRCS_FLAG_NOT_ACCEPT );
        }
        else
        {
            if ( $this->flow_status == self::$PRCS_FLAG_PROCESS )
            {
                $conditions[] = self::$PRCS_FLAG_PROCESS( self::$PRCS_FLAG_PROCESS );
            }
            else
            {
                if ( $this->flow_status == self::$PRCS_FLAG_FINISH )
                {
                    $conditions[] = self::$PRCS_FLAG_FINISH( self::$PRCS_FLAG_FINISH );
                }
                else
                {
                    if ( $this->flow_status == self::$PRCS_FLAG_PAUSE )
                    {
                        $conditions[] = self::$PRCS_FLAG_PAUSE( self::$PRCS_FLAG_PAUSE );
                    }
                    else
                    {
                        $conditions[] = self::$PRCS_FLAG_ALL( self::$PRCS_FLAG_ALL );
                    }
                }
            }
        }
        $conditions[] = $this->getFlowRunFilters( );
        $where_definition = self::$OBJ_SQL_SYNTAX->getWhereDefinition( $conditions, CONDITION_LOGIC_OP_AND );
        $sql = self::$OBJ_SQL_SYNTAX->getQuerySQL( 0, 0, $select_expr, $table_references, $where_definition );
        $r_cursor = exequery( $r_connection, $sql );
        if ( $row = mysql_fetch_array( $r_cursor ) )
        {
            $count = $row['COUNT'];
        }
        return $count;
    }

    private function getFlowRunFilters( $type = NULL )
    {
        $conditions = array( );
        $conditions[] = self::$OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_RUN.DEL_FLAG", EXPR_OP_IS, 0, FIELD_TYPE_INT );
        if ( $type == self::$PRCS_FLAG_FOCUS )
        {
            $conditions[] = self::$OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_RUN.FOCUS_USER", EXPR_OP_FIND_IN_SET, $this->user_id, FIELD_TYPE_CHAR );
        }
        if ( isset( $this->dim_str ) && trim( $this->dim_str ) )
        {
            $s_dim_str = trim( $this->dim_str );
            if ( preg_match( "/^\\d+$/", $s_dim_str ) )
            {
                $conditions[] = self::$OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_RUN.RUN_NAME", EXPR_OP_CTS, $s_dim_str, FIELD_TYPE_CHAR );
            }
            else
            {
                if ( $type == self::$PRCS_FLAG_FOCUS )
                {
                    $conditions[] = self::$OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_RUN.RUN_ID", EXPR_OP_IS, $s_dim_str, FIELD_TYPE_INT );
                }
            }
        }
        else
        {
            if ( $type == self::$PRCS_FLAG_FOCUS && isset( $this->run_id ) && trim( $this->run_id ) != "" )
            {
                $conditions[] = self::$OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_RUN.RUN_ID", EXPR_OP_IS, $this->run_id, FIELD_TYPE_INT );
            }
            if ( isset( $this->flow_id ) && trim( $this->flow_id ) != "" && $this->flow_id != "ALL" )
            {
                $conditions[] = self::$OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_RUN.FLOW_ID", EXPR_OP_IS, $this->flow_id, FIELD_TYPE_INT );
            }
            if ( isset( $this->run_name ) && trim( $this->run_name ) != "" )
            {
                $conditions[] = self::$OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_RUN.RUN_NAME", EXPR_OP_CTS, $this->run_name, FIELD_TYPE_CHAR );
            }
            if ( $this->work_level == "0" )
            {
                $conditions[] = self::$OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_RUN.WORK_LEVEL", EXPR_OP_IS, $this->work_level, FIELD_TYPE_INT );
            }
            else if ( $this->work_level == "2" )
            {
                $conditions[] = self::$OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_RUN.WORK_LEVEL", EXPR_OP_GRTEQ, $this->work_level, FIELD_TYPE_INT );
            }
        }
        if ( $type == self::$PRCS_FLAG_FOCUS )
        {
            $conditions[] = self::$OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_RUN.FOCUS_USER", EXPR_OP_FIND_IN_SET, $this->user_id, FIELD_TYPE_CHAR );
        }
        return self::$OBJ_SQL_SYNTAX->getWhereDefinition( $conditions, CONDITION_LOGIC_OP_AND );
    }

    private function getFlowRunPrcsFilters( $type )
    {
        $conditions = array( );
        $conditions[] = $this->getPrcsFlagCondition( $type );
        $conditions[] = self::$OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_RUN_PRCS.CHILD_RUN", EXPR_OP_IS, 0, FIELD_TYPE_INT );
        if ( $type == self::$PRCS_FLAG_DEPUTE )
        {
            $conditions[] = self::$OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_RUN_PRCS.OTHER_USER", EXPR_OP_FIND_IN_SET, $this->user_id, FIELD_TYPE_CHAR );
        }
        else
        {
            if ( $type != self::$PRCS_FLAG_FOCUS )
            {
                $conditions[] = self::$OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_RUN_PRCS.USER_ID", EXPR_OP_IS, $this->user_id, FIELD_TYPE_CHAR );
            }
        }
        $conditions[] = self::$OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_RUN_PRCS.CHILD_RUN", EXPR_OP_IS, 0, FIELD_TYPE_INT );
        if ( isset( $this->dim_str ) && trim( $this->dim_str ) )
        {
            $s_dim_str = trim( $this->dim_str );
            if ( preg_match( "/^\\d+$/", $s_dim_str ) )
            {
                $conditions[] = self::$OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_RUN_PRCS.RUN_ID", EXPR_OP_IS, $s_dim_str, FIELD_TYPE_INT );
            }
        }
        else
        {
            if ( isset( $this->run_id ) && trim( $this->run_id ) != "" )
            {
                $conditions[] = self::$OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_RUN_PRCS.RUN_ID", EXPR_OP_IS, $this->run_id, FIELD_TYPE_INT );
            }
            $conditions1 = array( );
            if ( $this->time_out_flag == "1" )
            {
                $conditions[] = self::$OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_RUN_PRCS.TIME_OUT_FLAG", EXPR_OP_IS, $this->time_out_flag, FIELD_TYPE_INT );
                $conditions[] = self::$OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_RUN_PRCS.OP_FLAG", EXPR_OP_IS, "1", FIELD_TYPE_INT );
            }
            else if ( $this->time_out_flag == "0" )
            {
                $conditions1[] = self::$OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_RUN_PRCS.OP_FLAG", EXPR_OP_ISN, "1", FIELD_TYPE_INT );
                $conditions1[] = self::$OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_RUN_PRCS.TIME_OUT_FLAG", EXPR_OP_ISN, "1", FIELD_TYPE_INT );
            }
        }
        $conditions[] = self::$OBJ_SQL_SYNTAX->getWhereDefinition( $conditions, CONDITION_LOGIC_OP_AND );
        if ( $conditions1 )
        {
            $conditions[] = self::$OBJ_SQL_SYNTAX->getWhereDefinition( $conditions1, CONDITION_LOGIC_OP_OR );
        }
        return self::$OBJ_SQL_SYNTAX->getWhereDefinition( $conditions, CONDITION_LOGIC_OP_AND );
    }

    private function getPrcsFlagCondition( $type )
    {
        switch ( $type )
        {
            case self::$PRCS_FLAG_NOT_ACCEPT :
                return self::$OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_RUN_PRCS.PRCS_FLAG", EXPR_OP_IS, 1, FIELD_TYPE_INT );
        }
        switch ( $type )
        {
            case self::$PRCS_FLAG_PROCESS :
                return self::$OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_RUN_PRCS.PRCS_FLAG", EXPR_OP_IS, 2, FIELD_TYPE_INT );
        }
        switch ( $type )
        {
            case self::$PRCS_FLAG_TO_DO :
                return self::$OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_RUN_PRCS.PRCS_FLAG", EXPR_OP_IN, "1,2", FIELD_TYPE_INT );
        }
        switch ( $type )
        {
            case self::$PRCS_FLAG_FINISH :
                return self::$OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_RUN_PRCS.PRCS_FLAG", EXPR_OP_IN, "3,4", FIELD_TYPE_INT );
        }
        switch ( $type )
        {
            case self::$PRCS_FLAG_PAUSE :
                return self::$OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_RUN_PRCS.PRCS_FLAG", EXPR_OP_IS, 6, FIELD_TYPE_INT );
        }
        switch ( $type )
        {
            case self::$PRCS_FLAG_ALL :
                switch ( $type )
                {
                    case self::$PRCS_FLAG_DEPUTE :
                        switch ( $type )
                        {
                            case self::$PRCS_FLAG_FOCUS :
                        }
                }
                return self::$OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_RUN_PRCS.PRCS_FLAG", EXPR_OP_ISN, 5, FIELD_TYPE_INT );
        }
    }

    private function getOrderBy( $type = NULL, $set = NULL )
    {
        $order_by_fields = array( );
        $order_by_directorys = array( );
        switch ( $this->_order_by_way )
        {
            case self::$ORDER_BY_RUN_ID_DESC :
                if ( $type == self::$PRCS_FLAG_DEPUTE )
                {
                    $order_by_fields[] = "FLOW_RUN.RUN_ID";
                    $order_by_directorys[] = ORDER_DIR_DESC;
                    $order_by_fields[] = "FLOW_RUN_PRCS.FLOW_PRCS";
                    $order_by_directorys[] = ORDER_DIR_ASC;
                    break;
                }
                else
                {
                    if ( $type == self::$PRCS_FLAG_TO_DO )
                    {
                        $order_by_fields[] = "FLOW_RUN.WORK_LEVEL";
                        $order_by_directorys[] = ORDER_DIR_DESC;
                        $order_by_fields[] = "FLOW_RUN_PRCS.RUN_ID";
                        $order_by_directorys[] = ORDER_DIR_DESC;
                        break;
                    }
                    else
                    {
                        if ( $type == self::$PRCS_FLAG_FINISH )
                        {
                            $order_by_fields[] = "FLOW_RUN_PRCS.DELIVER_TIME";
                            $order_by_directorys[] = ORDER_DIR_DESC;
                            break;
                        }
                        else
                        {
                            $order_by_fields[] = "FLOW_RUN.RUN_ID";
                            $order_by_directorys[] = ORDER_DIR_DESC;
                            break;
                        }
                    }
                }
            default :
                switch ( $this->_order_by_way )
                {
                    case self::$ORDER_BY_RUN_ID_ASC :
                        $order_by_fields[] = "FLOW_RUN.RUN_ID";
                        $order_by_directorys[] = ORDER_DIR_ASC;
                        break;
                    default :
                        switch ( $this->_order_by_way )
                        {
                            case self::$ORDER_BY_FLOW_TYPE_DESC :
                                $order_by_fields[] = "FLOW_RUN.FLOW_ID";
                                $order_by_directorys[] = ORDER_DIR_DESC;
                                break;
                            default :
                                switch ( $this->_order_by_way )
                                {
                                    case self::$ORDER_BY_FLOW_TYPE_ASC :
                                        $order_by_fields[] = "FLOW_RUN.FLOW_ID";
                                        $order_by_directorys[] = ORDER_DIR_ASC;
                                        break;
                                    default :
                                        switch ( $this->_order_by_way )
                                        {
                                            case self::$ORDER_BY_RUN_NAME_DESC :
                                                $order_by_fields[] = "FLOW_RUN.RUN_NAME";
                                                $order_by_directorys[] = ORDER_DIR_DESC;
                                                break;
                                            default :
                                                switch ( $this->_order_by_way )
                                                {
                                                    case self::$ORDER_BY_RUN_NAME_ASC :
                                                        $order_by_fields[] = "FLOW_RUN.RUN_NAME";
                                                        $order_by_directorys[] = ORDER_DIR_ASC;
                                                        break;
                                                    default :
                                                        switch ( $this->_order_by_way )
                                                        {
                                                            case self::$ORDER_BY_CREATE_TIME_DESC :
                                                                $order_by_fields[] = "FLOW_RUN_PRCS.CREATE_TIME";
                                                                $order_by_directorys[] = ORDER_DIR_DESC;
                                                                break;
                                                            default :
                                                                switch ( $this->_order_by_way )
                                                                {
                                                                    case self::$ORDER_BY_CREATE_TIME_ASC :
                                                                        $order_by_fields[] = "FLOW_RUN_PRCS.CREATE_TIME";
                                                                        $order_by_directorys[] = ORDER_DIR_ASC;
                                                                        break;
                                                                    default :
                                                                        switch ( $this->_order_by_way )
                                                                        {
                                                                            case self::$ORDER_BY_PRCS_TIME_DESC :
                                                                                $order_by_fields[] = "FLOW_RUN_PRCS.PRCS_TIME";
                                                                                $order_by_directorys[] = ORDER_DIR_DESC;
                                                                                break;
                                                                            default :
                                                                                switch ( $this->_order_by_way )
                                                                                {
                                                                                    case self::$ORDER_BY_PRCS_TIME_ASC :
                                                                                        $order_by_fields[] = "FLOW_RUN_PRCS.PRCS_TIME";
                                                                                        $order_by_directorys[] = ORDER_DIR_ASC;
                                                                                        break;
                                                                                    default :
                                                                                        switch ( $this->_order_by_way )
                                                                                        {
                                                                                            case self::$ORDER_BY_DELIVER_TIME_DESC :
                                                                                                $order_by_fields[] = "FLOW_RUN_PRCS.DELIVER_TIME";
                                                                                                $order_by_directorys[] = ORDER_DIR_DESC;
                                                                                                break;
                                                                                            default :
                                                                                                switch ( $this->_order_by_way )
                                                                                                {
                                                                                                    case self::$ORDER_BY_DELIVER_TIME_ASC :
                                                                                                        $order_by_fields[] = "FLOW_RUN_PRCS.DELIVER_TIME";
                                                                                                        $order_by_directorys[] = ORDER_DIR_ASC;
                                                                                                        break;
                                                                                                    default :
                                                                                                        switch ( $this->_order_by_way )
                                                                                                        {
                                                                                                            case self::$ORDER_BY_FLOW_RUN_ID_DESC :
                                                                                                                $order_by_fields[] = "FLOW_RUN.RUN_ID";
                                                                                                                $order_by_directorys[] = ORDER_DIR_DESC;
                                                                                                                break;
                                                                                                            default :
                                                                                                                switch ( $this->_order_by_way )
                                                                                                                {
                                                                                                                    case self::$ORDER_BY_FLOW_RUN_ID_ASC :
                                                                                                                        $order_by_fields[] = "FLOW_RUN.RUN_ID";
                                                                                                                        $order_by_directorys[] = ORDER_DIR_ASC;
                                                                                                                        break;
                                                                                                                    default :
                                                                                                                        switch ( $this->_order_by_way )
                                                                                                                        {
                                                                                                                            case self::$ORDER_BY_PRCS_FLAG_ASC :
                                                                                                                                $order_by_fields[] = "FLOW_RUN_PRCS.PRCS_FLAG";
                                                                                                                                $order_by_directorys[] = ORDER_DIR_ASC;
                                                                                                                                break;
                                                                                                                            default :
                                                                                                                                switch ( $this->_order_by_way )
                                                                                                                                {
                                                                                                                                    case self::$ORDER_BY_PRCS_FLAG_DESC :
                                                                                                                                        $order_by_fields[] = "FLOW_RUN_PRCS.PRCS_FLAG";
                                                                                                                                        $order_by_directorys[] = ORDER_DIR_DESC;
                                                                                                                                        break;
                                                                                                                                    default :
                                                                                                                                        switch ( $this->_order_by_way )
                                                                                                                                        {
                                                                                                                                            case self::$ORDER_BY_RUN_ID_SET_ASC :
                                                                                                                                                $order_by_fields[] = "FLOW_RUN.RUN_ID";
                                                                                                                                                $order_by_directorys[] = ORDER_DIR_ASC;
                                                                                                                                                break;
                                                                                                                                            default :
                                                                                                                                                switch ( $this->_order_by_way )
                                                                                                                                                {
                                                                                                                                                    case self::$ORDER_BY_RUN_ID_SET_DESC :
                                                                                                                                                        $order_by_fields[] = "FLOW_RUN.RUN_ID";
                                                                                                                                                        $order_by_directorys[] = ORDER_DIR_DESC;
                                                                                                                                                        break;
                                                                                                                                                    default :
                                                                                                                                                        $order_by_fields[] = "FLOW_RUN_PRCS.RUN_ID";
                                                                                                                                                        $order_by_directorys[] = ORDER_DIR_DESC;
                                                                                                                                                }
                                                                                                                                        }
                                                                                                                                }
                                                                                                                        }
                                                                                                                }
                                                                                                        }
                                                                                                }
                                                                                        }
                                                                                }
                                                                        }
                                                                }
                                                        }
                                                }
                                        }
                                }
                        }
                }
        }
        return self::$OBJ_SQL_SYNTAX->getOrderByDefinition( $order_by_fields, $order_by_directorys );
    }

    public static function getMyWorksCount( $user_id, $flow_ids )
    {
        $list_flow = array( );
        $r_connection = ( );
        $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
        $select_expr = "PRCS_FLAG, FLOW_ID, count(FLOW_RUN_PRCS.ID) as NUMBER";
        $table_references = $OBJ_SQL_SYNTAX->getTableReferences( "FLOW_RUN_PRCS", "INNER JOIN", "FLOW_RUN", "FLOW_RUN.RUN_ID=FLOW_RUN_PRCS.RUN_ID" );
        $conditions = array( );
        $conditions[] = $OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_RUN_PRCS.USER_ID", EXPR_OP_IS, $user_id, FIELD_TYPE_CHAR );
        if ( isset( $flow_ids ) && $flow_ids != "" )
        {
            if ( is_int( $flow_ids ) )
            {
                $conditions[] = $OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_RUN.FLOW_ID", EXPR_OP_IS, $flow_ids, FIELD_TYPE_INT );
            }
            else
            {
                $conditions[] = $OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_RUN.FLOW_ID", EXPR_OP_IN, $flow_ids, FIELD_TYPE_INT );
            }
        }
        $where_definition = $OBJ_SQL_SYNTAX->getWhereDefinition( $conditions, CONDITION_LOGIC_OP_AND );
        $order_by_defintion = $OBJ_SQL_SYNTAX->getOrderByDefinition( "flow_run.FLOW_ID" );
        $group_by_definition = $OBJ_SQL_SYNTAX->getGroupByDefinition( "flow_run.FLOW_ID, PRCS_FLAG" );
        $sql = $OBJ_SQL_SYNTAX->getQuerySQL( 0, 0, $select_expr, $table_references, $where_definition, NULL, NULL, $group_by_definition );
        $r_cursor = exequery( $r_connection, $sql );
        while ( $row = mysql_fetch_array( $r_cursor ) )
        {
            $list_flow[$row['FLOW_ID']][$row['PRCS_FLAG']] = $row['NUMBER'];
        }
        return $list_flow;
    }

    public static function getLastCreateWorkInfoOfMy( $user_id, $flow_id )
    {
        $list_flow = array( );
        $r_connection = ( );
        $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
        $select_exprs = "RUN_ID, RUN_NAME ";
        $table_references = "FLOW_RUN";
        $condition = array( );
        $condition[] = $OBJ_SQL_SYNTAX->getConditionExpr( "BEGIN_USER", EXPR_OP_IS, $user_id, FIELD_TYPE_CHAR );
        $condition[] = $OBJ_SQL_SYNTAX->getConditionExpr( "DEL_FLAG", EXPR_OP_IS, 0, FIELD_TYPE_INT );
        $condition[] = $OBJ_SQL_SYNTAX->getConditionExpr( "FLOW_ID", EXPR_OP_IS, $flow_id, FIELD_TYPE_INT );
        $where_definition = $OBJ_SQL_SYNTAX->getWhereDefinition( $condition, CONDITION_LOGIC_OP_AND );
        $order_by_defintion = $OBJ_SQL_SYNTAX->getOrderByDefinition( "RUN_ID", ORDER_DIR_DESC );
        $sql = $OBJ_SQL_SYNTAX->getQuerySQL( 0, 1, $select_exprs, $table_references, $where_definition, $order_by_defintion, NULL, $group_by_definition );
        $r_cursor = exequery( ( ), $sql );
        if ( $row = mysql_fetch_array( $r_cursor ) )
        {
            $last_work = array( "run_id" => $row['RUN_ID'], "run_name" => $row['RUN_NAME'] );
        }
        return $last_work;
    }

}

?>
