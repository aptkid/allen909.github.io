<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class ExtDataSource
{

    private $d_id;
    private $d_name;
    private $d_desc;
    private $d_priv;
    private $d_dept;
    private $d_creator;
    private $d_editor;
    private $d_create_time;
    private $d_edit_time;
    private $last_update_time;
    private $size;
    private $total_number = 0;
    private $d_fields = array( );

    public function _get( $property_name )
    {
        $property_name = strtolower( $property_name );
        if ( isset( $this->$property_name ) )
        {
            return $this->$property_name;
        }
    }

    public function _set( $property_name, $value )
    {
        $property_name = strtolower( $property_name );
        $this->$property_name = $value;
    }

    public function addField( $field_name, $field_desc, $field_type, $is_unique )
    {
        $this->d_fields[] = array( "field_name" => $field_name, "field_desc" => $field_desc, "field_type" => $field_type, "is_unique" => $is_unique );
    }

}

?>
