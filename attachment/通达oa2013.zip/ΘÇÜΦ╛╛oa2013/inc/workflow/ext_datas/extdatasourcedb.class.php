<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class ExtDataSourceDb extends IObjDB implements IObjDB
{

    public static function datasource_exists( $ds_name )
    {
        if ( trim( $ds_name ) == "" )
        {
            return FALSE;
        }
        $tableName = trim( $tableName );
        $sql = "SHOW TABLES LIKE 'data_".$ds_name."'";
        $cursor = exequery( ( ), $sql, TRUE );
        if ( 0 < mysql_num_rows( $cursor ) )
        {
            return TRUE;
        }
        return FALSE;
    }

    public static function getDataSourcesListCount( $name = NULL, $desc = NULL, $r_connection = NULL )
    {
        if ( $r_connection == NULL )
        {
            $r_connection = ( );
        }
        $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
        $select_exprs = " COUNT(d_id) as total_number ";
        $conditions = array( );
        if ( isset( $name ) && trim( $name ) != "" )
        {
            $conditions[] = $OBJ_SQL_SYNTAX->getConditionExpr( "d_name", EXPR_OP_CTS, $name, FIELD_TYPE_CHAR );
        }
        if ( isset( $desc ) && trim( $desc ) != "" )
        {
            $conditions[] = $OBJ_SQL_SYNTAX->getConditionExpr( "d_desc", EXPR_OP_CTS, $desc, FIELD_TYPE_CHAR );
        }
        if ( is_array( $conditions ) && 0 < count( $conditions ) )
        {
            $where_condition = $OBJ_SQL_SYNTAX->getWhereDefinition( $conditions, CONDITION_LOGIC_OP_AND );
        }
        else
        {
            $where_condition = NULL;
        }
        $sql = $OBJ_SQL_SYNTAX->getQuerySQL( 0, 0, $select_exprs, "data_src", $where_condition );
        $r_cursor = exequery( $r_connection, $sql );
        if ( $row = mysql_fetch_array( $r_cursor ) )
        {
            return $row['total_number'];
        }
        return 0;
    }

    public static function getDataSourcesList( $start_pos = 0, $row_count = 0, $name = NULL, $desc = NULL, $r_connection = NULL )
    {
        if ( $r_connection == NULL )
        {
            $r_connection = ( );
        }
        $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
        $select_exprs = "d_id, d_name, d_desc, d_dept, d_creator, d_editor, d_create_time, d_edit_time";
        $conditions = array( );
        if ( isset( $name ) && trim( $name ) != "" )
        {
            $conditions[] = $OBJ_SQL_SYNTAX->getConditionExpr( "d_name", EXPR_OP_CTS, $name, FIELD_TYPE_CHAR );
        }
        if ( isset( $desc ) && trim( $desc ) != "" )
        {
            $conditions[] = $OBJ_SQL_SYNTAX->getConditionExpr( "d_desc", EXPR_OP_CTS, $desc, FIELD_TYPE_CHAR );
        }
        if ( is_array( $conditions ) && 0 < count( $conditions ) )
        {
            $where_condition = $OBJ_SQL_SYNTAX->getWhereDefinition( $conditions, CONDITION_LOGIC_OP_AND );
        }
        else
        {
            $where_condition = NULL;
        }
        $sql = $OBJ_SQL_SYNTAX->getQuerySQL( $start_pos, $row_count, $select_exprs, "data_src", $where_condition );
        $arr_datasource = array( );
        $r_cursor = exequery( $r_connection, $sql );
        while ( $row = mysql_fetch_array( $r_cursor ) )
        {
            $obj = new ExtDataSource( );
            $row['d_id']( "d_id", $row['d_id'] );
            $row['d_name']( "d_name", $row['d_name'] );
            $row['d_desc']( "d_desc", $row['d_desc'] );
            $row['d_dept']( "d_dept", $row['d_dept'] );
            $row['d_creator']( "d_creator", $row['d_creator'] );
            $row['d_editor']( "d_editor", $row['d_editor'] );
            $row['d_create_time']( "d_create_time", $row['d_create_time'] );
            $row['d_edit_time']( "d_edit_time", $row['d_edit_time'] );
            $row['d_edit_time']( "last_update_time", $row['d_edit_time'] );
            $status_sql = "SHOW TABLE STATUS LIKE 'data_".$row['d_name']."' ";
            $r_cursor1 = exequery( $r_connection, $status_sql );
            if ( $row1 = mysql_fetch_array( $r_cursor1 ) )
            {
                $row1['Rows']( "total_number", $row1['Rows'] );
                $size = $row1['Data_length'];
                if ( 0 < floor( $size / 1024 / 1024 ) )
                {
                    $SIZE = round( $size / 1024 / 1024, 1 )."M";
                }
                else if ( 0 < floor( $size / 1024 ) )
                {
                    $size = round( $size / 1024, 1 )."K";
                }
                else
                {
                    $size .= "B";
                }
                $obj->_set( "size", $size );
            }
            $arr_datasource[] = $obj;
        }
        return $arr_datasource;
    }

    public function __construct( )
    {
        ( );
        parent::$TABLE_NAME = "data_src";
        $this->_obj_class_name = "ExtDataSource";
        $this->_db_key_field = "d_id";
        $this->_obj_key_field = "d_id";
        $this->_default_key_map = array( "D_NAME" => "d_name", "D_DESC" => "d_desc", "D_DEPT" => "d_dept", "D_CREATOR" => "d_creator", "D_EDITOR" => "d_editor", "D_CREATE_TIME" => "d_create_time", "D_EDIT_TIME" => "d_edit_time", "D_PRIV" => "d_priv" );
    }

    public function insert( $obj, $key_map = NULL, $r_connection = NULL )
    {
        return ( $obj, $key_map, $r_connection );
    }

    public function update( $obj, $key_map = NULL, $r_connection = NULL )
    {
        return ( $obj, $key_map, $r_connection );
    }

    public function delete( $obj, $r_connection = NULL )
    {
        return ( $obj, $r_connection );
    }

    public function fetch( $obj, $selectFields = NULL, $r_connection = NULL )
    {
        return ( $obj, $selectFields, $r_connection );
    }

    public function createDataSource( $obj )
    {
        $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
        if ( get_class( $obj ) != "ExtDataSource" )
        {
            return -1;
        }
        $arr_field = $obj->_get( "d_fields" );
        $fieldDefs = array( );
        $indices = array( );
        $fieldDefs[] = array( "name" => "ds_key_id", "type" => "int", "comment" => "ϵͳ�Զ�������", "auto_increment" => "1" );
        $indices[] = array( "fields" => "ds_key_id", "type" => "primary", "name" => "pkey_ds_key_id" );
        if ( is_array( $arr_field ) )
        {
            foreach ( $arr_field as $key => $value )
            {
                if ( $value['field_type'] == 0 )
                {
                    $field_type = "text";
                }
                else if ( $value['field_type'] == 1 )
                {
                    $field_type = "int";
                }
                $fieldDefs[] = array( "name" => $value['field_name'], "type" => $field_type, "comment" => $value['field_desc'] );
                if ( $value['is_unique'] == 1 )
                {
                    $indices[] = array( "fields" => $value['field_name'], "type" => "unique", "name" => $value['field_name'] );
                }
            }
        }
        $query = "SET character_set_connection=".MYOA_DB_CHARSET.",character_set_results=".MYOA_DB_CHARSET.",character_set_client=".MYOA_DB_CHARSET.";";
        exequery( ( ), $query, TRUE );
        $sql = $obj->_get( "d_name" )( "data_".$obj->_get( "d_name" ), $fieldDefs, $indices );
        exequery( ( ), $sql, TRUE );
        return 1;
    }

    public function dropDataSource( $ds_name )
    {
        $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
        $sql = $OBJ_SQL_SYNTAX->dropTableSQL( "data_".$ds_name );
        exequery( ( ), $sql, TRUE );
    }

    public function dropDataSouceField( $ds_name, $field_name )
    {
        $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
        $fieldDefs = array( "name" => $field_name );
        $sql = $OBJ_SQL_SYNTAX->changeColumnSQL( "data_".$ds_name, $fieldDefs, "drop" );
        exequery( ( ), $sql, TRUE );
    }

    public function addDataSourceField( $ds_name, $fieldDef )
    {
        $table_name = "data_".$ds_name;
        $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
        $query = "SET character_set_connection=".MYOA_DB_CHARSET.",character_set_results=".MYOA_DB_CHARSET.",character_set_client=".MYOA_DB_CHARSET.";";
        exequery( ( ), $query, TRUE );
        $sql = $OBJ_SQL_SYNTAX->changeColumnSQL( $table_name, $fieldDef, "add" );
        exequery( ( ), $sql, TRUE );
        if ( $fieldDef['is_unique'] == 1 )
        {
            $sql = $fieldDef['name']( $table_name, $fieldDef['name'], "unique", $fieldDef['name'] );
            exequery( ( ), $sql, TRUE );
        }
    }

    public function changeDataSourceField( $ds_name, $old_column_name, $is_old_unique, $nFieldDefs )
    {
        $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
        $table_name = "data_".$ds_name;
        $query = "SET character_set_connection=".MYOA_DB_CHARSET.",character_set_results=".MYOA_DB_CHARSET.",character_set_client=".MYOA_DB_CHARSET.";";
        exequery( ( ), $query, TRUE );
        $fieldDefs = array( "old_name" => $old_column_name, "name" => $nFieldDefs['name'], "type" => $nFieldDefs['type'], "comment" => $nFieldDefs['comment'] );
        $sql = $OBJ_SQL_SYNTAX->changeColumnSQL( $table_name, $fieldDefs, "alter" );
        exequery( ( ), $sql, TRUE );
        if ( $is_old_unique == 1 )
        {
            if ( $nFieldDefs['is_unique'] == 0 )
            {
                $sql = $OBJ_SQL_SYNTAX->dropIndexSQL( $table_name, $old_column_name );
                exequery( ( ), $sql, TRUE );
            }
            else
            {
                if ( $nFieldDefs['is_unique'] == 1 && $old_column_name != $nFieldDefs['name'] )
                {
                    $sql = $OBJ_SQL_SYNTAX->dropIndexSQL( $table_name, $old_column_name );
                    exequery( ( ), $sql, TRUE );
                    $sql = $fieldDefs['name']( $table_name, $fieldDefs['name'], "unique", $fieldDefs['name'] );
                    exequery( ( ), $sql, TRUE );
                }
            }
        }
        else
        {
            if ( $is_old_unique == 0 && $nFieldDefs['is_unique'] == 1 )
            {
                $sql = $fieldDefs['name']( $table_name, $fieldDefs['name'], "unique", $fieldDefs['name'] );
                exequery( ( ), $sql, TRUE );
            }
        }
    }

    public function truncateDataSource( $ds_name )
    {
        $table_name = "data_".$ds_name;
        $sql = "TRUNCATE TABLE ".$table_name;
        exequery( ( ), $sql, TRUE );
    }

    public function getFieldsOfDataSource( $ds_name )
    {
        $fields = array( );
        $sql = "SHOW FULL COLUMNS FROM data_".$ds_name;
        $r_cursor = exequery( ( ), $sql, TRUE );
        while ( $row = mysql_fetch_array( $r_cursor ) )
        {
            if ( $row['Field'] != "ds_key_id" )
            {
                if ( $row['Type'] == "int(11)" )
                {
                    $type = "int";
                }
                else
                {
                    $type = "text";
                }
                if ( $row['Key'] == "UNI" )
                {
                    $is_unique = 1;
                }
                else
                {
                    $is_unique = 0;
                }
                $fields[] = array( "name" => $row['Field'], "desc" => $row['Comment'], "type" => $type, "is_unique" => $is_unique );
            }
        }
        return $fields;
    }

    public function addDataRow( $ds_name, $key_fields )
    {
        $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
        $table_name = "data_".$ds_name;
        $sql = $OBJ_SQL_SYNTAX->getInsertSQL( $table_name, $key_fields );
        exequery( ( ), $sql, TRUE );
    }

    public function updateDataRow( $ds_name, $key_value, $key_fields )
    {
        $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
        $table_name = "data_".$ds_name;
        $where_condition = $OBJ_SQL_SYNTAX->getConditionExpr( "ds_key_id", EXPR_OP_IS, $key_value, FIELD_TYPE_INT );
        $sql = $OBJ_SQL_SYNTAX->getUpdateSQL( $table_name, $key_fields, $where_condition );
        exequery( ( ), $sql, TRUE );
    }

    public function delDataRow( $ds_name, $key_value )
    {
        $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
        $table_name = "data_".$ds_name;
        $where_condition = $OBJ_SQL_SYNTAX->getConditionExpr( "ds_key_id", EXPR_OP_IS, $key_value, FIELD_TYPE_INT );
        $sql = $OBJ_SQL_SYNTAX->getDeleteSQL( $table_name, $where_condition );
        exequery( ( ), $sql, TRUE );
    }

    public function fetchDataRows( $ds_name, $start_pos, $row_count, $fields, $r_connection = NULL )
    {
        if ( $r_connection == NULL )
        {
            $r_connection = ( );
        }
        $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
        $table_name = "data_".$ds_name;
        $sql = $OBJ_SQL_SYNTAX->getQuerySQL( $start_pos, $row_count, $fields, $table_name );
        $r_cursor = exequery( $r_connection, $sql );
        return $r_cursor;
    }

    public function fetchDataRowCount( $ds_name, $r_connection = NULL )
    {
        if ( $r_connection == NULL )
        {
            $r_connection = ( );
        }
        $OBJ_SQL_SYNTAX = ( MYOA_DBMS );
        $table_name = "data_".$ds_name;
        $sql = $OBJ_SQL_SYNTAX->getQuerySQL( 0, 0, " COUNT(ds_key_id) as total_count ", $table_name );
        $r_cursor = exequery( $r_connection, $sql );
        if ( $row = mysql_fetch_array( $r_cursor ) )
        {
            return $row['total_count'];
        }
        return 0;
    }

}

?>
