<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
include_once( "inc/auth.inc.php" );
include_once( "inc/header.inc.php" );
include_once( "rss.php" );
ob_clean( );
$ROWS = intval( $ROWS );
$RSSURL = base64_decode( $RSSURL );
$RSS_CACHE = ( "RSS_CACHE_".md5( $RSSURL ) );
if ( $RSS_CACHE === FALSE )
{
    $data = @file_get_contents( $RSSURL );
    if ( $data )
    {
        ob_clean( );
        echo _( "���Ӳ�����ַ��" ).$RSSURL;
        exit( );
    }
    $r = new myoa_rss( );
    $r->parse( $data );
    $data = $r->getContent( $ROWS );
    $RSS_CACHE = $data;
    ( "RSS_CACHE_".md5( $RSSURL ), $RSS_CACHE, 3600 );
}
echo $RSS_CACHE;
?>
