<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class myoa_rss
{

    public $file;
    public $data;
    public $rss_channel = array( );
    public $currently_writing = "";
    public $main = "";
    public $item_counter = 0;

    public function startElement( $parser, $name, $attrs )
    {
        switch ( $name )
        {
            case "RSS" :
            case "RDF:RDF" :
            case "ITEMS" :
                $this->currently_writing = "";
                return;
            case "CHANNEL" :
                $this->main = "CHANNEL";
                return;
            case "IMAGE" :
                $this->main = "IMAGE";
                $this->rss_channel['IMAGE'] = array( );
                return;
            case "ITEM" :
                $this->main = "ITEMS";
                return;
        }
        $this->currently_writing = $name;
    }

    public function endElement( $parser, $name )
    {
        if ( $name == "IMAGE" )
        {
            $this->main = "CHANNEL";
        }
        $this->currently_writing = "";
        if ( $name == "ITEM" )
        {
            $this->item_counter++;
        }
    }

    public function characterData( $parser, $data )
    {
        $data = iconv( "UTF-8", MYOA_CHARSET, $data );
        if ( $this->currently_writing != "" )
        {
            switch ( $this->main )
            {
                case "CHANNEL" :
                    if ( isset( $this->rss_channel[$this->currently_writing] ) )
                    {
                        $this->rss_channel[$this->currently_writing] = $data;
                        break;
                    }
                    else
                    {
                        $this->rss_channel[$this->currently_writing] = $data;
                        break;
                    }
                case "IMAGE" :
                    if ( isset( $this->rss_channel[$this->main][$this->currently_writing] ) )
                    {
                        $this->rss_channel[$this->main] .= $this->currently_writing;
                        break;
                    }
                    else
                    {
                        $this->rss_channel[$this->main][$this->currently_writing] = $data;
                        break;
                    }
                case "ITEMS" :
                    if ( isset( $this->rss_channel[$this->main][$this->item_counter][$this->currently_writing] ) )
                    {
                        $this->rss_channel[$this->main][$this->item_counter] .= $this->currently_writing;
                    }
                    else
                    {
                        $this->rss_channel[$this->main][$this->item_counter][$this->currently_writing] = $data;
                    }
            }
        }
    }

    public function myoa_rss( $file = "" )
    {
        $this->file = $file;
        $this->data = "";
        if ( $file != "" )
        {
            include_once( "inc/utility_file.php" );
            $fp = @td_fopen( $file, "rb" );
            while ( !feof( $fp ) )
            {
                $ && _514500696 .= "data";
            }
            fclose( $fp );
        }
    }

    public function parse( $data = "" )
    {
        $this->xml_parser = xml_parser_create( );
        xml_set_object( $this->xml_parser, &$this );
        xml_set_element_handler( $this->xml_parser, "startElement", "endElement" );
        xml_set_character_data_handler( $this->xml_parser, "characterData" );
        if ( $data == "" )
        {
            $data = $this->data;
        }
        if ( substr( $data, 0, 1 ) != "<" )
        {
            $this->data = substr( $data, strpos( $data, "<" ) );
        }
        @xml_parse( @$this->xml_parser, $data );
        xml_parser_free( $this->xml_parser );
    }

    public function getTitle( )
    {
        return $this->rss_channel['TITLE'];
    }

    public function getContent( $rows_count = 10 )
    {
        if ( !isset( $this->rss_channel['ITEMS'] ) || !( 0 < count( $this->rss_channel['ITEMS'] ) ) )
        {
            $i = 0;
            for ( ; $i < count( $this->rss_channel['ITEMS'] ); ++$i )
            {
                if ( $rows_count != 0 && $rows_count <= $i )
                {
                    break;
                }
                else
                {
                    $itemTitle = strip_tags( $this->rss_channel['ITEMS'][$i]['TITLE'] );
                    $itemLink = $this->rss_channel['ITEMS'][$i]['LINK'];
                }
                if ( strtolower( substr( $itemLink, 0, 7 ) ) != "http://" )
                {
                    $itemLink = $this->rss_channel['LINK']."/".$itemLink;
                }
                if ( $this->rss_channel['ITEMS'][$i]['PUBDATE'] != "" )
                {
                    $TimeStamp = strtotime( $this->rss_channel['ITEMS'][$i]['PUBDATE'] );
                    if ( $TimeStamp != -1 )
                    {
                        $itemPubDate = " (".date( "m-d H:i", $TimeStamp ).")";
                    }
                }
                $OUTPUT_HTML .= "<li><a href=\"".$itemLink."\" target=\"_blank\"";
                if ( 42 < strlen( $itemTitle ) )
                {
                    $OUTPUT_HTML .= " title=\"".$itemTitle."\">".csubstr( $itemTitle, 0, 42 )."...";
                }
                else
                {
                    $OUTPUT_HTML .= ">".$itemTitle;
                }
                $OUTPUT_HTML .= "</a>".$itemPubDate."</li>\n";
            }
        }
        return $OUTPUT_HTML;
    }

}

include_once( "inc/utility_all.php" );
?>
