<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class IWorkflow
{

    private $m_para = array( );

    public function __construct( $paraArr )
    {
        foreach ( $paraArr as $key => $value )
        {
            $this->m_para[$key] = $value;
        }
        if ( $this->m_para['ACT'] == "new" )
        {
            if ( $this->m_para['FLOW_ID'] == "" )
            {
                $this->error( 301 );
            }
            if ( $this->is_sys_flow( ) )
            {
                $this->error( 302 );
            }
            if ( $this->m_para['BEGIN_USER'] == "" )
            {
                $this->error( 303 );
            }
            if ( $this->is_sys_user( ) )
            {
                $this->error( 304 );
            }
        }
    }

    public function new_flow( )
    {
        if ( $this->m_para['RUN_NAME'] != "" )
        {
            $query = "select 1 from FLOW_RUN WHERE RUN_NAME = '".$this->m_para['RUN_NAME']."'";
            $cursor = exequery( ( ), $query );
            if ( mysql_fetch_array( $cursor ) )
            {
                $this->error( 305 );
            }
            else
            {
                $RUN_NAME = $this->m_para['RUN_NAME'];
            }
        }
        $CUR_TIME = date( "Y-m-d H:i:s" );
        $query = "SELECT * from FLOW_TYPE WHERE FLOW_ID='".$this->m_para['FLOW_ID']."'";
        $cursor1 = exequery( ( ), $query );
        if ( $ROW = mysql_fetch_array( $cursor1 ) )
        {
            $FLOW_NAME = $ROW['FLOW_NAME'];
            $FLOW_TYPE = $ROW['FLOW_TYPE'];
            $FORM_ID = $ROW['FORM_ID'];
            $AUTO_NAME = $ROW['AUTO_NAME'];
            $AUTO_NUM = $ROW['AUTO_NUM'];
            $AUTO_LEN = $ROW['AUTO_LEN'];
            $AUTO_EDIT = $ROW['AUTO_EDIT'];
            $FLOW_SORT = $ROW['FLOW_SORT'];
            $query = "SELECT MAX(RUN_ID) from FLOW_RUN";
            $cursor = exequery( ( ), $query );
            if ( $ROW = mysql_fetch_array( $cursor ) )
            {
                $RUN_ID = $ROW[0] + 1;
            }
            if ( $RUN_NAME == "" )
            {
                if ( $AUTO_NAME == "" )
                {
                    $RUN_NAME = $FLOW_NAME."(".$CUR_TIME.")";
                }
                else
                {
                    $RUN_NAME = $AUTO_NAME;
                    $CUR_YEAR = date( "Y", time( ) );
                    $CUR_MON = date( "m", time( ) );
                    $CUR_DAY = date( "d", time( ) );
                    $CUR_HOUR = date( "H" );
                    $CUR_MINITE = date( "i" );
                    $CUR_SECOND = date( "s" );
                    $query = "SELECT USER_NAME,DEPT_ID,USER_PRIV from USER WHERE USER_ID='".$this->m_para['BEGIN_USER']."'";
                    $cursor1 = exequery( ( ), $query );
                    if ( $ROW = mysql_fetch_array( $cursor1 ) )
                    {
                        $USER_NAME = $ROW['USER_NAME'];
                        $DEPT_ID = $ROW['DEPT_ID'];
                        $USER_PRIV = $ROW['USER_PRIV'];
                    }
                    $query = "SELECT SORT_NAME from FLOW_SORT WHERE SORT_ID='".$FLOW_SORT."'";
                    $cursor1 = exequery( ( ), $query );
                    if ( $ROW = mysql_fetch_array( $cursor1 ) )
                    {
                        $SORT_NAME = $ROW['SORT_NAME'];
                    }
                    $DEPARTMENT_ARRAY = ( "SYS_DEPARTMENT" );
                    $DEPT_NAME = $DEPARTMENT_ARRAY[$DEPT_ID]['DEPT_NAME'];
                    $LONG_DEPT_NAME = dept_long_name( $_SESSION['LOGIN_DEPT_ID'] );
                    $query = "SELECT PRIV_NAME from USER_PRIV WHERE USER_PRIV='".$USER_PRIV."'";
                    $cursor1 = exequery( ( ), $query );
                    if ( $ROW = mysql_fetch_array( $cursor1 ) )
                    {
                        $PRIV_NAME = $ROW['PRIV_NAME'];
                    }
                    ++$AUTO_NUM;
                    $AUTO_NUM = str_pad( $AUTO_NUM, $AUTO_LEN, "0", STR_PAD_LEFT );
                    if ( strstr( $RUN_NAME, "{N}" ) )
                    {
                        $query = "update FLOW_TYPE set AUTO_NUM=AUTO_NUM+1 where FLOW_ID='".$this->m_para['FLOW_ID']."'";
                        exequery( ( ), $query );
                    }
                    $SEARCH_ARRAY = array( "{Y}", "{M}", "{D}", "{H}", "{I}", "{S}", "{F}", "{FS}", "{U}", "{SD}", "{LD}", "{R}", "{N}", "{RUN}" );
                    $REPLACE_ARRAY = array( $CUR_YEAR, $CUR_MON, $CUR_DAY, $CUR_HOUR, $CUR_MINITE, $CUR_SECOND, $FLOW_NAME, $SORT_NAME, $USER_NAME, $DEPT_NAME, $LONG_DEPT_NAME, $PRIV_NAME, $AUTO_NUM, $RUN_ID );
                    $RUN_NAME = str_replace( $SEARCH_ARRAY, $REPLACE_ARRAY, $RUN_NAME );
                }
            }
            $query = "SELECT MAX(RUN_ID) from FLOW_RUN";
            $cursor = exequery( ( ), $query );
            if ( $ROW = mysql_fetch_array( $cursor ) )
            {
                $RUN_ID = $ROW[0] + 1;
            }
            $query = "insert into FLOW_RUN(RUN_ID,RUN_NAME,FLOW_ID,BEGIN_USER,BEGIN_TIME,PARENT_RUN,ATTACHMENT_ID,ATTACHMENT_NAME,BEGIN_DEPT) values (".$RUN_ID.",'{$RUN_NAME}','".$this->m_para['FLOW_ID']."','".$this->m_para['BEGIN_USER'].( "','".$CUR_TIME."','" ).$this->m_para['PARENT_RUN']."','".$this->m_para['ATTACHMENT_ID']."','".$this->m_para['ATTACHMENT_NAME']."','".$this->m_para['BEGIN_DEPT']."')";
            exequery( ( ), $query );
            if ( $this->m_para['USER_STR'] != "" )
            {
                $USER_ARRAY = explode( ",", $USER_STR );
                foreach ( $USER_ARRAY as $PRCS_USER )
                {
                    if ( $PRCS_USER == "" )
                    {
                        if ( $PRCS_USER == $this->m_para['BEGIN_USER'] )
                        {
                            $OP_FLAG = 1;
                        }
                        else
                        {
                            $OP_FLAG = 0;
                        }
                        $query_dept = "SELECT DEPT_ID FROM user WHERE USER_ID = '".$PRCS_USER."';";
                        $cursor_dept = exequery( ( ), $query_dept );
                        if ( $row_dept = mysql_fetch_array( $cursor_dept ) )
                        {
                            $PRCS_DEPT = $row_dept['DEPT_ID'];
                        }
                        $query = "insert into FLOW_RUN_PRCS(RUN_ID,PRCS_ID,USER_ID,PRCS_DEPT,PRCS_FLAG,FLOW_PRCS,OP_FLAG,CREATE_TIME) values (".$RUN_ID.",1,'{$PRCS_USER}','".$PRCS_DEPT.( "','1','1','".$OP_FLAG."','{$CUR_TIME}')" );
                        exequery( ( ), $query );
                    }
                }
            }
            else
            {
                $query_dept = "SELECT DEPT_ID FROM user WHERE USER_ID = '".$this->m_para['BEGIN_USER']."';";
                $cursor_dept = exequery( ( ), $query_dept );
                if ( $row_dept = mysql_fetch_array( $cursor_dept ) )
                {
                    $PRCS_DEPT = $row_dept['DEPT_ID'];
                }
                $query = "insert into FLOW_RUN_PRCS(RUN_ID,PRCS_ID,USER_ID,PRCS_DEPT,PRCS_FLAG,FLOW_PRCS,OP_FLAG,CREATE_TIME) values (".$RUN_ID.",1,'".$this->m_para['BEGIN_USER']."','".$PRCS_DEPT.( "','1','1','1','".$CUR_TIME."')" );
                exequery( ( ), $query );
            }
            $PARENT_FIELD = array( );
            $SUBFLOW_FIELD = array( );
            if ( $this->m_para['PARENT_RUN'] )
            {
                if ( $this->m_para['ATTACH_FLAG'] != 0 )
                {
                    $query = "SELECT ATTACHMENT_ID,ATTACHMENT_NAME FROM FLOW_RUN WHERE RUN_ID='".$this->m_para['PARENT_RUN']."'";
                    $cursor = exequery( ( ), $query );
                    if ( $ROW = mysql_fetch_array( $cursor ) )
                    {
                        $ATTACHMENT_ID = $ROW['ATTACHMENT_ID'];
                        $ATTACHMENT_NAME = $ROW['ATTACHMENT_NAME'];
                        if ( $ATTACHMENT_ID != "" )
                        {
                            $ATTACHMENT_ID_NEW = copy_attach( $ATTACHMENT_ID, $ATTACHMENT_NAME, TRUE ).",";
                        }
                        $query = "update FLOW_RUN set ATTACHMENT_ID='".$ATTACHMENT_ID_NEW."' AND ATTACHMENT_NAME='{$ATTACHMENT_NAME}' WHERE RUN_ID='{$RUN_ID}'";
                        exequery( ( ), $query );
                    }
                }
                $query = "SELECT FLOW_ID from FLOW_RUN WHERE RUN_ID='".$this->m_para['PARENT_RUN']."'";
                $cursor1 = exequery( ( ), $query );
                if ( $ROW = mysql_fetch_array( $cursor1 ) )
                {
                    $PARENT_FLOW_ID = $ROW['FLOW_ID'];
                }
                $query = "SELECT RELATION from FLOW_PROCESS WHERE FLOW_ID='".$PARENT_FLOW_ID."' AND CHILD_FLOW='".$this->m_para['FLOW_ID']."'";
                $cursor1 = exequery( ( ), $query );
                if ( $ROW = mysql_fetch_array( $cursor1 ) )
                {
                    $RELATION = $ROW['RELATION'];
                }
                $FIELD = explode( ",", $RELATION );
                $I = 0;
                for ( ; $I < sizeof( $FIELD ); ++$I )
                {
                    $TMP = $FIELD[$I];
                    if ( $TMP != "" )
                    {
                        $PARENT_FIELD[] = substr( $TMP, 0, strpos( $TMP, "=>" ) );
                        $SUBFLOW_FIELD[] = substr( $TMP, strpos( $TMP, "=>" ) + 2 );
                    }
                }
                $RUN_DATA = getrundata( $this->m_para['PARENT_RUN'] );
            }
            $WORKFLOW_ELEMENT_ARRAY = ( "workflow/form/ELEMENT_ARRAY_".$FORM_ID );
            foreach ( $WORKFLOW_ELEMENT_ARRAY as $ENAME => $ELEMENT_ARR )
            {
                $ETAG = strtoupper( $ELEMENT_ARR['TAG'] );
                $ECLASS = $ELEMENT_ARR['CLASS'];
                $ETITLE = $ELEMENT_ARR['TITLE'];
                $ITEM_ID = $ELEMENT_ARR['ITEM_ID'];
                $EVALUE = $ELEMENT_ARR['VALUE'];
                $ITEM_DATA = "";
                if ( strtoupper( $ETAG ) == "INPUT" && stristr( $ELEMENT, "checkbox" ) )
                {
                    if ( stristr( $ELEMENT, "CHECKED" ) || stristr( $ELEMENT, " checked=\"checked\"" ) )
                    {
                        $ITEM_DATA = "on";
                    }
                    else
                    {
                        $ITEM_DATA = "";
                    }
                }
                else if ( strtoupper( $ETAG ) != "SELECT" && strtoupper( $ECLASS ) != "LIST_VIEW" )
                {
                    $ITEM_DATA = $EVALUE;
                    $ITEM_DATA = str_replace( "\"", "", $ITEM_DATA );
                    if ( $ITEM_DATA == "{MACRO}" )
                    {
                        $ITEM_DATA = "";
                    }
                }
                else
                {
                    $ITEM_DATA = "";
                }
                if ( in_array( $ETITLE, $SUBFLOW_FIELD ) )
                {
                    $K = array_search( $ETITLE, $SUBFLOW_FIELD );
                    $PARENT_TITLE = $PARENT_FIELD[$K];
                    $ITEM_DATA = $RUN_DATA["{$PARENT_TITLE}"];
                    if ( is_array( $ITEM_DATA ) && strtoupper( $ECLASS ) == "LIST_VIEW" )
                    {
                        $ITEM_DATA_STR = "";
                        $NEW_DATA_STR = "";
                        $i = 1;
                        for ( ; $i < count( $ITEM_DATA ); ++$i )
                        {
                            foreach ( $ITEM_DATA[$i] as $val )
                            {
                                $NEW_DATA_STR .= $val."`";
                            }
                            $ITEM_DATA_STR .= $NEW_DATA_STR."\r\n";
                            $NEW_DATA_STR = "";
                        }
                        $ITEM_DATA = $ITEM_DATA_STR;
                    }
                }
                if ( !empty( $this->m_para['DATA'] ) && array_key_exists( $ETITLE, $this->m_para['DATA'] ) )
                {
                    $ITEM_DATA = $this->m_para['DATA'][$ETITLE];
                }
                if ( $ITEM_ID != "" )
                {
                    $run_data["data_".$ITEM_ID] = $ITEM_DATA;
                }
            }
        }
        $run_data['run_id'] = $RUN_ID;
        $run_data['run_name'] = $RUN_NAME;
        $run_data['begin_time'] = $CUR_TIME;
        $run_data['begin_user'] = $this->m_para['BEGIN_USER'];
        reset( &$WORKFLOW_ELEMENT_ARRAY );
        update_table( $this->m_para['FLOW_ID'], $WORKFLOW_ELEMENT_ARRAY );
        insert_table_data( $this->m_para['FLOW_ID'], $run_data );
        return $RUN_ID;
    }

    public function update( $run_id, $data )
    {
        if ( !$run_id || !$data )
        {
            return FALSE;
        }
        $sql = "";
        foreach ( $data as $key => $value )
        {
            if ( strstr( tirm( $key ), "DATA_" ) == 0 )
            {
                $sql .= $key."='".$value."',";
            }
        }
        if ( $sql == "" )
        {
            return FALSE;
        }
        $sql = substr( $sql, 0, -1 );
    }

    private function is_sys_flow( )
    {
        $query = "select 1 from FLOW_TYPE where FLOW_ID='".$this->m_para['FLOW_ID']."'";
        $cursor = exequery( ( ), $query );
        if ( mysql_fetch_array( $cursor ) )
        {
            return FALSE;
        }
        return TRUE;
    }

    private function is_sys_user( )
    {
        $query = "select 1 from USER where USER_ID='".$this->m_para['BEGIN_USER']."'";
        $cursor = exequery( ( ), $query );
        if ( mysql_fetch_array( $cursor ) )
        {
            return FALSE;
        }
        return TRUE;
    }

    private function error( $errNo )
    {
        $errString = "";
        switch ( $errNo )
        {
            case 301 :
                $errString = $errNo."#|#"._( "����IDΪ�ջ�������" );
                exit( $errString );
            case 302 :
                $errString = $errNo."#|#"._( "����ID��ϵͳ�в�����" );
                exit( $errString );
            case 303 :
                $errString = $errNo."#|#"._( "���̷�����Ϊ��" );
                exit( $errString );
            case 304 :
                $errString = $errNo."#|#"._( "���̷����˲���ϵͳ�û�" ).$this->m_para['USER_ID'];
                exit( $errString );
            case 305 :
                $errString = $errNo."#|#"._( "���������ĺ��ظ�" );
            default :
                exit( $errString );
        }
    }

    public function get_list( )
    {
        $WHERE_STR = "";
        if ( $this->m_para['BEGIN_USER'] )
        {
            $WHERE_STR .= " and a.BEGIN_USER='".$this->m_para['BEGIN_USER']."'";
        }
        if ( $this->m_para['DEPT_ID'] )
        {
            $WHERE_STR .= " and c.DEPT_ID='".$this->m_para['DEPT_ID']."'";
        }
        if ( $this->m_para['FLOW_ID'] )
        {
            $WHERE_STR .= " and a.FLOW_ID='".$this->m_para['FLOW_ID']."'";
        }
        if ( $this->m_para['START_TIME'] )
        {
            $WHERE_STR .= " and a.BEGIN_TIME>'".$this->m_para['START_TIME']."'";
        }
        if ( $this->m_para['END_TIME'] )
        {
            $WHERE_STR .= " and a.BEGIN_TIME<'".$this->m_para['END_TIME']."'";
        }
        if ( $this->m_para['LIMIT'] )
        {
            $LIMIT = " LIMIT 0,".$this->m_para['LIMIT'];
        }
        if ( !$this->m_para['START_TIME'] && !$this->m_para['END_TIME'] )
        {
            $START_TIME = date( "Y-m-d H:i:s", strtotime( "-2 month" ) );
            $END_TIME = date( "Y-m-d H:i:s", time( ) );
            $WHERE_STR .= " and a.BEGIN_TIME>'".$START_TIME."' and a.BEGIN_TIME<'{$END_TIME}'";
        }
        $XML_OUT .= "<?xml version=\"1.0\" encoding=\"utf-8\"?>\r\n";
        $XML_OUT .= "<WorkFlow>\r\n";
        $query = "select a.RUN_ID,RUN_NAME,c.USER_NAME,d.PRCS_NAME from FLOW_RUN AS a,FLOW_RUN_PRCS AS b,USER AS c,FLOW_PROCESS AS d where a.RUN_ID=b.RUN_ID AND c.USER_ID=b.USER_ID AND b.PRCS_FLAG IN(1,2) AND d.PRCS_ID=b.FLOW_PRCS ".$WHERE_STR."ORDER BY a.RUN_ID DESC".$LIMIT;
        $cursor = exequery( ( ), $query );
        while ( $ROW = mysql_fetch_assoc( $cursor ) )
        {
            $XML_OUT .= "\t<RUN>\r\n";
            foreach ( $ROW as $K => $V )
            {
                $XML_OUT .= "\t\t<".$K."><![CDATA[".$V."]]></".$K.">\r\n";
            }
            $XML_OUT .= "\t</RUN>\r\n";
        }
        $XML_OUT .= "</WorkFlow>\r\n";
        $XML_OUT = iconv( MYOA_DB_CHARSET, "utf-8", $XML_OUT );
        return $XML_OUT;
    }

    public function run( )
    {
        switch ( $this->m_para['ACT'] )
        {
            case "new" :
                $result = $this->new_flow( );
                break;
            case "list" :
                $result = $this->get_list( );
                break;
            default :
                $result = $this->get_list( );
        }
        return $result;
    }

}

include_once( "inc/conn.php" );
include_once( "inc/utility_file.php" );
?>
