<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
include_once( "inc/auth.inc.php" );
ob_end_clean( );
if ( strtolower( $dataType ) == "javascript" )
{
    $JS_ARRAY = "";
    foreach ( $MENU_TOP as $MENU )
    {
        $JS_ARRAY .= "{text:\"".htmlspecialchars( $MENU['text'] )."\",title:\"".htmlspecialchars( $MENU['title'] )."\",href:\"".str_replace( "\"", "\\\"", $MENU['href'] )."\",active:\"".$MENU['active']."\"},";
    }
    echo "[".str_replace( array( "\r", "\n" ), array( "", "" ), td_trim( $JS_ARRAY ) )."]";
    exit( );
}
$MENU_TOP_CONFIGS['href'] = isset( $MENU_TOP_CONFIGS ) && isset( $MENU_TOP_CONFIGS['href'] ) ? $MENU_TOP_CONFIGS['href'] : $MENU_TOP[0]['href'];
$MENU_TOP_CONFIGS['framename'] = isset( $MENU_TOP_CONFIGS ) && isset( $MENU_TOP_CONFIGS['framename'] ) ? $MENU_TOP_CONFIGS['framename'] : "menu_main";
$FRAME_INDEX = isset( $MENU_TOP_CONFIGS ) && isset( $MENU_TOP_CONFIGS['index'] ) ? " index=\"".$MENU_TOP_CONFIGS['index']."\" " : "";
$HTML_PAGE_BASE_STYLE = stripos( $MENU_RIGHT, "type=\"button\"" ) !== FALSE ? 1 : 0;
include( "inc/header.inc.php" );
echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"";
echo MYOA_STATIC_SERVER;
echo "/static/theme/";
echo $_SESSION['LOGIN_THEME'];
echo "/menu_top.css\" />\r\n<script language=\"JavaScript\" src=\"";
echo MYOA_JS_SERVER;
echo "/static/js/menu_top.js\"></script>\r\n";
echo $SCRIPT;
echo "\r\n\r\n<style>\r\nhtml,body{\r\n    overflow: hidden;\r\n    height: 100%;\r\n}\r\n#north{\r\n    position: absolute;\r\n    top:0;\r\n    left:0;\r\n    right:0;\r\n}\r\n#center{\r\n    position: absolute;\r\n    bottom:0;\r\n    left:0;\r\n    right:0;\r\n    overflow: hidden;\r\n}\r\n#center iframe{\r\n    width: 100%;\r\n    height: 100%;\r\n    display: block;\r\n    position: absolute;\r\n    top:0;\r\n    bottom:0;\r\n    left:0;\r\n    right:0;\r\n}\r\n/* for ie6 */\r\n* html #center{\r\n    position: relative;\r\n}\r\n\r\n</style>\r\n<div id=\"north\">\r\n    <div id=\"navPanel\" ";
if ( $F == "1" )
{
    echo "class=\"mutiwork\"";
}
echo ">\r\n        <div id=\"navMenu\" style=\"width:auto;\">\r\n        ";
foreach ( ( array ) as $MENU )
{
    echo "            <a href=\"";
    echo $MENU['href'];
    echo "\" \r\n                target=\"";
    echo $MENU['target'] == "" ? "menu_main" : $MENU['target'];
    echo "\" \r\n                title=\"";
    echo $MENU['title'] == "" ? htmlspecialchars( $MENU['text'] ) : htmlspecialchars( $MENU['title'] );
    echo "\" \r\n                hidefocus=\"hidefocus\"\r\n                ";
    echo $MENU['active'] == "1" ? " class=\"active\"" : "";
    echo ">\r\n                <span>";
    if ( $MENU['closeable'] == 1 )
    {
        echo "<span class=\"close\"></span>";
    }
    echo "                    ";
    if ( $MENU['img'] != "" )
    {
        echo "<img style=\"height:16px;\" src=\"";
        echo $MENU['img'];
        echo "\" align=\"absmiddle\" /> ";
    }
    echo "                    ";
    echo htmlspecialchars( $MENU['text'] );
    echo "                </span>\r\n            </a>\r\n        ";
}
echo "        </div>\r\n        <div id=\"navRight\" style=\"float:left;\">\r\n           <img id=\"navScroll\" src=\"";
echo MYOA_STATIC_SERVER;
echo "/static/images/nav_r1.gif\" style=\"display:none;cursor:pointer;\" align=\"absMiddle\" title=\"";
echo _( "��ʾ��һ��" );
echo "\" />\r\n           ";
echo $MENU_RIGHT;
echo "      </div>\r\n    </div>\r\n</div>\r\n<div id=\"center\">\r\n    <iframe src=\"";
echo $MENU_TOP_CONFIGS['href'];
echo "\" id=\"";
echo $MENU_TOP_CONFIGS['framename'];
echo "\" name=\"";
echo $MENU_TOP_CONFIGS['framename'];
echo "\" ";
echo $FRAME_INDEX;
echo " frameborder=\"0\"></iframe>\r\n</div>\r\n\r\n\r\n<body>\r\n\r\n</body>\r\n</html>\r\n";
?>
