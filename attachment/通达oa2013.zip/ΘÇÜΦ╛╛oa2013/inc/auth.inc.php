<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
include_once( "inc/session.php" );
if ( stristr( $PHP_SELF, "export" ) || stristr( $PHP_SELF, "excel" ) || stristr( $PHP_SELF, "word" ) || stristr( $PHP_SELF, "attach.php" ) || stristr( $PHP_SELF, "download.php" ) || stristr( $PHP_SELF, "down.php" ) )
{
    session_cache_limiter( "private, must-revalidate" );
}
session_start( );
ob_start( );
include_once( "inc/utility.php" );
$SCRIPT_NAME = $_SERVER['SCRIPT_NAME'];
if ( 0 < MYOA_OFFLINE_TIME_MIN )
{
    $LAST_OPERATION_TIME = $_COOKIE['LAST_OPERATION_TIME'];
    if ( !stristr( $SCRIPT_NAME, "/general/ipanel/" ) && !stristr( $SCRIPT_NAME, "/general/task_center/" ) && !stristr( $SCRIPT_NAME, "/general/mytable/" ) && !stristr( $SCRIPT_NAME, "/general/status_bar/" ) && !stristr( $SCRIPT_NAME, "/general/topbar.php" ) )
    {
        setcookie( "LAST_OPERATION_TIME", time( ), 0, "/" );
    }
    if ( $LAST_OPERATION_TIME != "" && MYOA_OFFLINE_TIME_MIN * 60 < time( ) - $LAST_OPERATION_TIME )
    {
        $query = "delete from USER_ONLINE where SID='".session_id( )."'";
        exequery( ( ), $query );
        clear_online_status( );
        setcookie( "LAST_OPERATION_TIME", "", 1, "/" );
        session_unset( );
        session_destroy( );
    }
}
if ( !isset( $_SESSION['LOGIN_USER_ID'] ) || $_SESSION['LOGIN_USER_ID'] == "" || !isset( $_SESSION['LOGIN_UID'] ) || $_SESSION['LOGIN_UID'] == "" )
{
    sleep( 1 );
    if ( !isset( $_SESSION['LOGIN_USER_ID'] ) || $_SESSION['LOGIN_USER_ID'] == "" || !isset( $_SESSION['LOGIN_UID'] ) || $_SESSION['LOGIN_UID'] == "" )
    {
        $HTML_PAGE_TITLE = _( "�û�δ��¼" );
        include_once( "inc/header.inc.php" );
        message( _( "����" ), _( "�û�δ��¼�������µ�¼!" ) );
        echo "<center><br><input type=\"button\" value=\""._( "���µ�¼" )."\" class=\"BigButton\" onclick=\"window.top.location='/';\"></center>";
        echo "<script>var d=new Date();var h=Math.abs(parseInt((d.getTime()/1000-".time( ).")/3600));if(h>=1) alert(\""._( "�ͻ��˺ͷ�����ʱ������1��Сʱ������ͻ��˺ͷ����������ں�ʱ���Ƿ���ȷ" )."\");</script>";
        exit( );
    }
}
if ( isset( $_SESSION['LOGIN_USER_PRIV'] ) )
{
    $query = "select USER_PRIV from USER where UID='".$_SESSION['LOGIN_UID']."'";
    $cursor = exequery( ( ), $query );
    if ( $ROW = mysql_fetch_array( $cursor ) )
    {
        $_SESSION['LOGIN_USER_PRIV'] = $ROW['USER_PRIV'];
    }
}
if ( !isset( $SESSION_WRITE_CLOSE ) || $SESSION_WRITE_CLOSE != 0 )
{
    session_write_close( );
}
$USER_FUNC_ID_STR = $_SESSION['LOGIN_FUNC_STR'];
if ( $_SESSION['LOGIN_USER_ID'] == "admin" )
{
    $USER_FUNC_ID_STR .= "32,33,56,";
}
$SAFE_CHECK_OK = 0;
if ( stristr( $SCRIPT_NAME, "/general" ) )
{
    $SAFE_CHECK_OK = 1;
}
else
{
    $SCRIPT_NAME = substr( $SCRIPT_NAME, 9 );
    $SCRIPT_NAME = ltrim( $SCRIPT_NAME, "/" );
    if ( stristr( $SCRIPT_NAME, "/" ) )
    {
        $SCRIPT_NAME1 = substr( $SCRIPT_NAME, 0, strpos( $SCRIPT_NAME, "/" ) );
        $SCRIPT_NAME2 = substr( $SCRIPT_NAME, 0, strpos( $SCRIPT_NAME, "/", strlen( $SCRIPT_NAME1 ) + 1 ) );
        $SCRIPT_NAME3 = substr( $SCRIPT_NAME, 0, strrpos( $SCRIPT_NAME, "/" ) );
    }
    if ( $SCRIPT_NAME1 == "" || find_id( "status_bar,ipanel,task_center,ilook,winexe,mytable,crm,setting_guide", $SCRIPT_NAME1 ) || stristr( $SCRIPT_NAME, "news/show" ) || stristr( $SCRIPT_NAME, "vote/show" ) || stristr( $SCRIPT_NAME, "reportshop/utils" ) )
    {
        $SAFE_CHECK_OK = 1;
    }
    else
    {
        include_once( "inc/menu_map.php" );
        if ( $SCRIPT_NAME2 != "" && ( $FUNC_ID = array_search( $SCRIPT_NAME2, $MENU_MAP2 ) ) !== FALSE )
        {
            if ( find_id( $USER_FUNC_ID_STR, $FUNC_ID ) )
            {
                $SAFE_CHECK_OK = 1;
            }
        }
        else if ( ( $FUNC_ID = array_search( $SCRIPT_NAME1, $MENU_MAP1 ) ) !== FALSE && find_id( $USER_FUNC_ID_STR, $FUNC_ID ) )
        {
            $SAFE_CHECK_OK = 1;
        }
        if ( $SAFE_CHECK_OK )
        {
            $FUNCTION_ARRAY = ( "SYS_FUNCTION_".bin2hex( MYOA_LANG_COOKIE ) );
            do
            {
                do
                {
                    if ( list( $FUNC_ID, $FUNC_CODE ) = each( &$FUNCTION_ARRAY ) )
                    {
                        while ( !find_id( $USER_FUNC_ID_STR, $FUNC_ID ) )
                        {
                        }
                        if ( $SCRIPT_NAME1 == "file_folder" || $SCRIPT_NAME1 == "netdisk" || $SCRIPT_NAME1 == "picture" || $SCRIPT_NAME1 == "im" )
                        {
                            if ( substr( $FUNC_CODE, 0, strlen( $SCRIPT_NAME1 ) ) == $SCRIPT_NAME1 )
                            {
                                $SAFE_CHECK_OK = 1;
                            }
                            else
                            {
                                $SAFE_CHECK_OK = 1;
                            }
                        }
                        else
                        {
                            if ( find_id( $USER_FUNC_ID_STR, 15 ) && $SCRIPT_NAME1 == "workflow" )
                            {
                                $SAFE_CHECK_OK = 1;
                            }
                            else
                            {
                                $FUNC_CODE = trim( $FUNC_CODE, "/" );
                                if ( strstr( $FUNC_CODE, "/" ) )
                                {
                                    $FUNC_CODE_LAST_PART = substr( $FUNC_CODE, strrpos( $FUNC_CODE, "/" ) + 1 );
                                    if ( strstr( $FUNC_CODE_LAST_PART, "." ) )
                                    {
                                        $FUNC_CODE = substr( $FUNC_CODE, 0, strrpos( $FUNC_CODE, "/" ) );
                                    }
                                }
                                $FUNC_CODE .= "/";
                            }
                        }
                    }
                } while ( !( substr( $SCRIPT_NAME, 0, strlen( $FUNC_CODE ) ) == $FUNC_CODE ) );
            } while ( !( substr( $SCRIPT_NAME, 0, strlen( $FUNC_CODE ) ) == $FUNC_CODE ) );
            $SAFE_CHECK_OK = 1;
        }
    }
}
if ( $SAFE_CHECK_OK == 0 )
{
    $HTML_PAGE_TITLE = _( "Ŀ¼��������" );
    include_once( "inc/header.inc.php" );
    message( _( "����" ), _( "�޸�ģ��ʹ��Ȩ�ޣ�����ʹ�ø�ģ�飬����ϵ����Ա�������ñ���ɫȨ�ޣ�" ) );
    exit( );
}
$GZIP_POSTFIX = "";
if ( isset( $HTML_PAGE_TITLE ) )
{
    unset( $HTML_PAGE_TITLE );
}
?>
