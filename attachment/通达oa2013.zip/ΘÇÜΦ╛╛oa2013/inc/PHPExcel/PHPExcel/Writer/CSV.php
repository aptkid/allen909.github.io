<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class PHPExcel_Writer_CSV extends PHPExcel_Writer_IWriter implements PHPExcel_Writer_IWriter
{

    private $_phpExcel;
    private $_delimiter = ",";
    private $_enclosure = "\"";
    private $_lineEnding = PHP_EOL;
    private $_sheetIndex = 0;
    private $_useBOM = FALSE;
    private $_excelCompatibility = FALSE;

    public function __construct( $phpExcel )
    {
        $this->_phpExcel = $phpExcel;
    }

    public function save( $pFilename = NULL )
    {
        $sheet = $this->_phpExcel->getSheet( $this->_sheetIndex );
        $saveDebugLog = ( $this->_phpExcel )->getDebugLog( )->getWriteDebugLog( );
        ( $this->_phpExcel )->getDebugLog( )->setWriteDebugLog( FALSE );
        $saveArrayReturnType = ( );
        ( PHPExcel_Calculation::RETURN_ARRAY_AS_VALUE );
        $fileHandle = fopen( $pFilename, "wb+" );
        if ( $fileHandle === FALSE )
        {
            throw new PHPExcel_Writer_Exception( "Could not open file ".$pFilename." for writing." );
        }
        if ( $this->_excelCompatibility )
        {
            fwrite( $fileHandle, "��" );
            $this->setEnclosure( );
            $this->setDelimiter( "\t" );
        }
        else if ( $this->_useBOM )
        {
            fwrite( $fileHandle, "﻿" );
        }
        $maxCol = $sheet->getHighestColumn( );
        $maxRow = $sheet->getHighestRow( );
        $row = 1;
        for ( ; $row <= $maxRow; ++$row )
        {
            $cellsArray = $this->_preCalculateFormulas( "A".$row.":".$maxCol.$row, "", $this->_preCalculateFormulas );
            $cellsArray[0]( $fileHandle, $cellsArray[0] );
        }
        fclose( $fileHandle );
        ( $saveArrayReturnType );
        ( $this->_phpExcel )->getDebugLog( )->setWriteDebugLog( $saveDebugLog );
    }

    public function getDelimiter( )
    {
        return $this->_delimiter;
    }

    public function setDelimiter( $pValue = "," )
    {
        $this->_delimiter = $pValue;
        return $this;
    }

    public function getEnclosure( )
    {
        return $this->_enclosure;
    }

    public function setEnclosure( $pValue = "\"" )
    {
        if ( $pValue == "" )
        {
            $pValue = NULL;
        }
        $this->_enclosure = $pValue;
        return $this;
    }

    public function getLineEnding( )
    {
        return $this->_lineEnding;
    }

    public function setLineEnding( $pValue = PHP_EOL )
    {
        $this->_lineEnding = $pValue;
        return $this;
    }

    public function getUseBOM( )
    {
        return $this->_useBOM;
    }

    public function setUseBOM( $pValue = FALSE )
    {
        $this->_useBOM = $pValue;
        return $this;
    }

    public function getExcelCompatibility( )
    {
        return $this->_excelCompatibility;
    }

    public function setExcelCompatibility( $pValue = FALSE )
    {
        $this->_excelCompatibility = $pValue;
        return $this;
    }

    public function getSheetIndex( )
    {
        return $this->_sheetIndex;
    }

    public function setSheetIndex( $pValue = 0 )
    {
        $this->_sheetIndex = $pValue;
        return $this;
    }

    private function _writeLine( $pFileHandle = NULL, $pValues = NULL )
    {
        if ( is_array( $pValues ) )
        {
            $writeDelimiter = FALSE;
            $line = "";
            foreach ( $pValues as $element )
            {
                $element = str_replace( $this->_enclosure, $this->_enclosure.$this->_enclosure, $element );
                if ( $writeDelimiter )
                {
                    $line .= $this->_delimiter;
                }
                else
                {
                    $writeDelimiter = TRUE;
                }
                $line .= $this->_enclosure.$element.$this->_enclosure;
            }
            $line .= $this->_lineEnding;
            if ( $this->_excelCompatibility )
            {
                fwrite( $pFileHandle, mb_convert_encoding( $line, "UTF-16LE", "UTF-8" ) );
            }
            else
            {
                fwrite( $pFileHandle, $line );
            }
        }
        else
        {
            throw new PHPExcel_Writer_Exception( "Invalid data row passed to CSV writer." );
        }
    }

}

?>
