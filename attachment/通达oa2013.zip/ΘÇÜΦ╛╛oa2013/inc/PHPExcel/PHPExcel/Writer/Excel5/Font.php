<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class PHPExcel_Writer_Excel5_Font
{

    private $_colorIndex;
    private $_font;
    private static $_mapUnderline = array( 'PHPExcel_Style_Font::UNDERLINE_NONE' => ?id #0, 'PHPExcel_Style_Font::UNDERLINE_SINGLE' => ?id #1, 'PHPExcel_Style_Font::UNDERLINE_DOUBLE' => ?id #2, 'PHPExcel_Style_Font::UNDERLINE_SINGLEACCOUNTING' => ?id #33, 'PHPExcel_Style_Font::UNDERLINE_DOUBLEACCOUNTING' => ?id #34 );

    public function __construct( $font = NULL )
    {
        $this->_colorIndex = 32767;
        $this->_font = $font;
    }

    public function setColorIndex( $colorIndex )
    {
        $this->_colorIndex = $colorIndex;
    }

    public function writeFont( )
    {
        $font_outline = 0;
        $font_shadow = 0;
        $icv = $this->_colorIndex;
        if ( $this->_font->getSuperScript( ) )
        {
            $sss = 1;
        }
        else if ( $this->_font->getSubScript( ) )
        {
            $sss = 2;
        }
        else
        {
            $sss = 0;
        }
        $bFamily = 0;
        $bCharSet = ( $this->_font->getName( ) );
        $record = 49;
        $reserved = 0;
        $grbit = 0;
        if ( $this->_font->getItalic( ) )
        {
            $grbit |= 2;
        }
        if ( $this->_font->getStrikethrough( ) )
        {
            $grbit |= 8;
        }
        if ( $font_outline )
        {
            $grbit |= 16;
        }
        if ( $font_shadow )
        {
            $grbit |= 32;
        }
        $data = pack( "vvvvvCCCC", $this->_font->getSize( ) * 20, $grbit, $icv, ( $this->_font->getBold( ) ), $sss, ( $this->_font->getUnderline( ) ), $bFamily, $bCharSet, $reserved );
        $data .= ( $this->_font->getName( ) );
        $length = strlen( $data );
        $header = pack( "vv", $record, $length );
        return $header.$data;
    }

    private static function _mapBold( $bold )
    {
        if ( $bold )
        {
            return 700;
        }
        return 400;
    }

    private static function _mapUnderline( $underline )
    {
        if ( isset( $_mapUnderline[$underline] ) )
        {
            return self::$_mapUnderline[$underline];
        }
        return 0;
    }

}

?>
