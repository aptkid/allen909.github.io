<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class PHPExcel_Writer_Excel5_Xf
{

    private $_isStyleXf;
    private $_fontIndex;
    public $_numberFormatIndex;
    public $_text_justlast;
    public $_fg_color;
    public $_bg_color;
    public $_bottom_color;
    public $_top_color;
    public $_left_color;
    public $_right_color;
    private static $_mapBorderStyle = array( 'PHPExcel_Style_Border::BORDER_NONE' => ?id #0, 'PHPExcel_Style_Border::BORDER_THIN' => ?id #1, 'PHPExcel_Style_Border::BORDER_MEDIUM' => ?id #2, 'PHPExcel_Style_Border::BORDER_DASHED' => ?id #3, 'PHPExcel_Style_Border::BORDER_DOTTED' => ?id #4, 'PHPExcel_Style_Border::BORDER_THICK' => ?id #5, 'PHPExcel_Style_Border::BORDER_DOUBLE' => ?id #6, 'PHPExcel_Style_Border::BORDER_HAIR' => ?id #7, 'PHPExcel_Style_Border::BORDER_MEDIUMDASHED' => ?id #8, 'PHPExcel_Style_Border::BORDER_DASHDOT' => ?id #9, 'PHPExcel_Style_Border::BORDER_MEDIUMDASHDOT' => ?id #10, 'PHPExcel_Style_Border::BORDER_DASHDOTDOT' => ?id #11, 'PHPExcel_Style_Border::BORDER_MEDIUMDASHDOTDOT' => ?id #12, 'PHPExcel_Style_Border::BORDER_SLANTDASHDOT' => ?id #13 );
    private static $_mapFillType = array( 'PHPExcel_Style_Fill::FILL_NONE' => ?id #0, 'PHPExcel_Style_Fill::FILL_SOLID' => ?id #1, 'PHPExcel_Style_Fill::FILL_PATTERN_MEDIUMGRAY' => ?id #2, 'PHPExcel_Style_Fill::FILL_PATTERN_DARKGRAY' => ?id #3, 'PHPExcel_Style_Fill::FILL_PATTERN_LIGHTGRAY' => ?id #4, 'PHPExcel_Style_Fill::FILL_PATTERN_DARKHORIZONTAL' => ?id #5, 'PHPExcel_Style_Fill::FILL_PATTERN_DARKVERTICAL' => ?id #6, 'PHPExcel_Style_Fill::FILL_PATTERN_DARKDOWN' => ?id #7, 'PHPExcel_Style_Fill::FILL_PATTERN_DARKUP' => ?id #8, 'PHPExcel_Style_Fill::FILL_PATTERN_DARKGRID' => ?id #9, 'PHPExcel_Style_Fill::FILL_PATTERN_DARKTRELLIS' => ?id #10, 'PHPExcel_Style_Fill::FILL_PATTERN_LIGHTHORIZONTAL' => ?id #11, 'PHPExcel_Style_Fill::FILL_PATTERN_LIGHTVERTICAL' => ?id #12, 'PHPExcel_Style_Fill::FILL_PATTERN_LIGHTDOWN' => ?id #13, 'PHPExcel_Style_Fill::FILL_PATTERN_LIGHTUP' => ?id #14, 'PHPExcel_Style_Fill::FILL_PATTERN_LIGHTGRID' => ?id #15, 'PHPExcel_Style_Fill::FILL_PATTERN_LIGHTTRELLIS' => ?id #16, 'PHPExcel_Style_Fill::FILL_PATTERN_GRAY125' => ?id #17, 'PHPExcel_Style_Fill::FILL_PATTERN_GRAY0625' => ?id #18, 'PHPExcel_Style_Fill::FILL_GRADIENT_LINEAR' => ?id #0, 'PHPExcel_Style_Fill::FILL_GRADIENT_PATH' => ?id #0 );
    private static $_mapHAlign = array( 'PHPExcel_Style_Alignment::HORIZONTAL_GENERAL' => ?id #0, 'PHPExcel_Style_Alignment::HORIZONTAL_LEFT' => ?id #1, 'PHPExcel_Style_Alignment::HORIZONTAL_CENTER' => ?id #2, 'PHPExcel_Style_Alignment::HORIZONTAL_RIGHT' => ?id #3, 'PHPExcel_Style_Alignment::HORIZONTAL_JUSTIFY' => ?id #5, 'PHPExcel_Style_Alignment::HORIZONTAL_CENTER_CONTINUOUS' => ?id #6 );
    private static $_mapVAlign = array( 'PHPExcel_Style_Alignment::VERTICAL_TOP' => ?id #0, 'PHPExcel_Style_Alignment::VERTICAL_CENTER' => ?id #1, 'PHPExcel_Style_Alignment::VERTICAL_BOTTOM' => ?id #2, 'PHPExcel_Style_Alignment::VERTICAL_JUSTIFY' => ?id #3 );

    public function __construct( $style = NULL )
    {
        $this->_isStyleXf = FALSE;
        $this->_fontIndex = 0;
        $this->_numberFormatIndex = 0;
        $this->_text_justlast = 0;
        $this->_fg_color = 64;
        $this->_bg_color = 65;
        $this->_diag = 0;
        $this->_bottom_color = 64;
        $this->_top_color = 64;
        $this->_left_color = 64;
        $this->_right_color = 64;
        $this->_diag_color = 64;
        $this->_style = $style;
    }

    public function writeXf( )
    {
        if ( $this->_isStyleXf )
        {
            $style = 65525;
        }
        else
        {
            $style = ( $this->_style->getProtection( )->getLocked( ) );
            $style |= ( $this->_style->getProtection( )->getHidden( ) ) << 1;
        }
        $atr_num = $this->_numberFormatIndex != 0 ? 1 : 0;
        $atr_fnt = $this->_fontIndex != 0 ? 1 : 0;
        $atr_alc = ( integer ) ? 1 : 0;
        do
        {
            if ( ( $this->_style->getBorders( )->getBottom( )->getBorderStyle( ) ) )
            {
                break;
            }
            else
            {
                if ( ( $this->_style->getBorders( )->getTop( )->getBorderStyle( ) ) )
                {
                    break;
                }
                else
                {
                    if ( ( $this->_style->getBorders( )->getLeft( )->getBorderStyle( ) ) )
                    {
                        break;
                    }
                    else
                    {
                    }
                }
            }
        } while ( 0 );
        $atr_bdr = ( $this->_style->getBorders( )->getRight( )->getBorderStyle( ) ) ? 1 : 0;
        if ( !( $this->_fg_color != 64 ) && !( $this->_bg_color != 65 ) )
        {
        }
        $atr_pat = ( $this->_style->getFill( )->getFillType( ) ) ? 1 : 0;
        $atr_prot = ( $this->_style->getProtection( )->getLocked( ) ) | ( $this->_style->getProtection( )->getHidden( ) );
        if ( ( $this->_style->getBorders( )->getBottom( )->getBorderStyle( ) ) == 0 )
        {
            $this->_bottom_color = 0;
        }
        if ( ( $this->_style->getBorders( )->getTop( )->getBorderStyle( ) ) == 0 )
        {
            $this->_top_color = 0;
        }
        if ( ( $this->_style->getBorders( )->getRight( )->getBorderStyle( ) ) == 0 )
        {
            $this->_right_color = 0;
        }
        if ( ( $this->_style->getBorders( )->getLeft( )->getBorderStyle( ) ) == 0 )
        {
            $this->_left_color = 0;
        }
        if ( ( $this->_style->getBorders( )->getDiagonal( )->getBorderStyle( ) ) == 0 )
        {
            $this->_diag_color = 0;
        }
        $record = 224;
        $length = 20;
        $ifnt = $this->_fontIndex;
        $ifmt = $this->_numberFormatIndex;
        $align = $this->_style->getAlignment( )->getHorizontal( )( $this->_style->getAlignment( )->getHorizontal( ) );
        $align |= ( integer ) << 3;
        $align |= ( $this->_style->getAlignment( )->getVertical( ) ) << 4;
        $align |= $this->_text_justlast << 7;
        $used_attrib = $atr_num << 2;
        $used_attrib |= $atr_fnt << 3;
        $used_attrib |= $atr_alc << 4;
        $used_attrib |= $atr_bdr << 5;
        $used_attrib |= $atr_pat << 6;
        $used_attrib |= $atr_prot << 7;
        $icv = $this->_fg_color;
        $icv |= $this->_bg_color << 7;
        $border1 = ( $this->_style->getBorders( )->getLeft( )->getBorderStyle( ) );
        $border1 |= ( $this->_style->getBorders( )->getRight( )->getBorderStyle( ) ) << 4;
        $border1 |= ( $this->_style->getBorders( )->getTop( )->getBorderStyle( ) ) << 8;
        $border1 |= ( $this->_style->getBorders( )->getBottom( )->getBorderStyle( ) ) << 12;
        $border1 |= $this->_left_color << 16;
        $border1 |= $this->_right_color << 23;
        $diagonalDirection = $this->_style->getBorders( )->getDiagonalDirection( );
        $diag_tl_to_rb = $diagonalDirection == PHPExcel_Style_Borders::DIAGONAL_DOWN;
        $diag_tr_to_lb = $diagonalDirection == PHPExcel_Style_Borders::DIAGONAL_UP;
        $border1 |= $diag_tl_to_rb << 30;
        $border1 |= $diag_tr_to_lb << 31;
        $border2 = $this->_top_color;
        $border2 |= $this->_bottom_color << 7;
        $border2 |= $this->_diag_color << 14;
        $border2 |= ( $this->_style->getBorders( )->getDiagonal( )->getBorderStyle( ) ) << 21;
        $border2 |= ( $this->_style->getFill( )->getFillType( ) ) << 26;
        $header = pack( "vv", $record, $length );
        $biff8_options = $this->_style->getAlignment( )->getIndent( );
        $biff8_options |= ( integer ) << 4;
        $data = pack( "vvvC", $ifnt, $ifmt, $style, $align );
        $data .= pack( "CCC", ( $this->_style->getAlignment( )->getTextRotation( ) ), $biff8_options, $used_attrib );
        $data .= pack( "VVv", $border1, $border2, $icv );
        return $header.$data;
    }

    public function setIsStyleXf( $value )
    {
        $this->_isStyleXf = $value;
    }

    public function setBottomColor( $colorIndex )
    {
        $this->_bottom_color = $colorIndex;
    }

    public function setTopColor( $colorIndex )
    {
        $this->_top_color = $colorIndex;
    }

    public function setLeftColor( $colorIndex )
    {
        $this->_left_color = $colorIndex;
    }

    public function setRightColor( $colorIndex )
    {
        $this->_right_color = $colorIndex;
    }

    public function setDiagColor( $colorIndex )
    {
        $this->_diag_color = $colorIndex;
    }

    public function setFgColor( $colorIndex )
    {
        $this->_fg_color = $colorIndex;
    }

    public function setBgColor( $colorIndex )
    {
        $this->_bg_color = $colorIndex;
    }

    public function setNumberFormatIndex( $numberFormatIndex )
    {
        $this->_numberFormatIndex = $numberFormatIndex;
    }

    public function setFontIndex( $value )
    {
        $this->_fontIndex = $value;
    }

    private static function _mapBorderStyle( $borderStyle )
    {
        if ( isset( $_mapBorderStyle[$borderStyle] ) )
        {
            return self::$_mapBorderStyle[$borderStyle];
        }
        return 0;
    }

    private static function _mapFillType( $fillType )
    {
        if ( isset( $_mapFillType[$fillType] ) )
        {
            return self::$_mapFillType[$fillType];
        }
        return 0;
    }

    private function _mapHAlign( $hAlign )
    {
        if ( isset( $_mapHAlign[$hAlign] ) )
        {
            return self::$_mapHAlign[$hAlign];
        }
        return 0;
    }

    private static function _mapVAlign( $vAlign )
    {
        if ( isset( $_mapVAlign[$vAlign] ) )
        {
            return self::$_mapVAlign[$vAlign];
        }
        return 2;
    }

    private static function _mapTextRotation( $textRotation )
    {
        if ( 0 <= $textRotation )
        {
            return $textRotation;
        }
        if ( $textRotation == -165 )
        {
            return 255;
        }
        if ( $textRotation < 0 )
        {
            return 90 - $textRotation;
        }
    }

    private static function _mapLocked( $locked )
    {
        switch ( $locked )
        {
            case PHPExcel_Style_Protection::PROTECTION_INHERIT :
                return 1;
            case PHPExcel_Style_Protection::PROTECTION_PROTECTED :
                return 1;
            case PHPExcel_Style_Protection::PROTECTION_UNPROTECTED :
                return 0;
            default :
                return 1;
        }
    }

    private static function _mapHidden( $hidden )
    {
        switch ( $hidden )
        {
            case PHPExcel_Style_Protection::PROTECTION_INHERIT :
                return 0;
            case PHPExcel_Style_Protection::PROTECTION_PROTECTED :
                return 1;
            case PHPExcel_Style_Protection::PROTECTION_UNPROTECTED :
                return 0;
            default :
                return 0;
        }
    }

}

?>
