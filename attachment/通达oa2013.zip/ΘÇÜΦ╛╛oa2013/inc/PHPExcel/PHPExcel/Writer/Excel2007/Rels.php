<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class PHPExcel_Writer_Excel2007_Rels extends PHPExcel_Writer_Excel2007_WriterPart
{

    public function writeRelationships( $pPHPExcel = NULL )
    {
        $objWriter = NULL;
        if ( $this->getParentWriter( )->getUseDiskCaching( ) )
        {
            $objWriter = new PHPExcel_Shared_XMLWriter( PHPExcel_Shared_XMLWriter::STORAGE_DISK, $this->getParentWriter( )->getDiskCachingDirectory( ) );
        }
        else
        {
            $objWriter = new PHPExcel_Shared_XMLWriter( PHPExcel_Shared_XMLWriter::STORAGE_MEMORY );
        }
        $objWriter->startDocument( "1.0", "UTF-8", "yes" );
        $objWriter->startElement( "Relationships" );
        $objWriter->writeAttribute( "xmlns", "http://schemas.openxmlformats.org/package/2006/relationships" );
        $customPropertyList = $pPHPExcel->getProperties( )->getCustomProperties( );
        if ( empty( $customPropertyList ) )
        {
            $this->_writeRelationship( $objWriter, 4, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/custom-properties", "docProps/custom.xml" );
        }
        $this->_writeRelationship( $objWriter, 3, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties", "docProps/app.xml" );
        $this->_writeRelationship( $objWriter, 2, "http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties", "docProps/core.xml" );
        $this->_writeRelationship( $objWriter, 1, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument", "xl/workbook.xml" );
        $objWriter->endElement( );
        return $objWriter->getData( );
    }

    public function writeWorkbookRelationships( $pPHPExcel = NULL )
    {
        $objWriter = NULL;
        if ( $this->getParentWriter( )->getUseDiskCaching( ) )
        {
            $objWriter = new PHPExcel_Shared_XMLWriter( PHPExcel_Shared_XMLWriter::STORAGE_DISK, $this->getParentWriter( )->getDiskCachingDirectory( ) );
        }
        else
        {
            $objWriter = new PHPExcel_Shared_XMLWriter( PHPExcel_Shared_XMLWriter::STORAGE_MEMORY );
        }
        $objWriter->startDocument( "1.0", "UTF-8", "yes" );
        $objWriter->startElement( "Relationships" );
        $objWriter->writeAttribute( "xmlns", "http://schemas.openxmlformats.org/package/2006/relationships" );
        $this->_writeRelationship( $objWriter, 1, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles", "styles.xml" );
        $this->_writeRelationship( $objWriter, 2, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme", "theme/theme1.xml" );
        $this->_writeRelationship( $objWriter, 3, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings", "sharedStrings.xml" );
        $sheetCount = $pPHPExcel->getSheetCount( );
        $i = 0;
        for ( ; $i < $sheetCount; ++$i )
        {
            $this->_writeRelationship( $objWriter, $i + 1 + 3, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet", "worksheets/sheet".( $i + 1 ).".xml" );
        }
        $objWriter->endElement( );
        return $objWriter->getData( );
    }

    public function writeWorksheetRelationships( $pWorksheet = NULL, $pWorksheetId = 1, $includeCharts = FALSE )
    {
        $objWriter = NULL;
        if ( $this->getParentWriter( )->getUseDiskCaching( ) )
        {
            $objWriter = new PHPExcel_Shared_XMLWriter( PHPExcel_Shared_XMLWriter::STORAGE_DISK, $this->getParentWriter( )->getDiskCachingDirectory( ) );
        }
        else
        {
            $objWriter = new PHPExcel_Shared_XMLWriter( PHPExcel_Shared_XMLWriter::STORAGE_MEMORY );
        }
        $objWriter->startDocument( "1.0", "UTF-8", "yes" );
        $objWriter->startElement( "Relationships" );
        $objWriter->writeAttribute( "xmlns", "http://schemas.openxmlformats.org/package/2006/relationships" );
        $d = 0;
        if ( $includeCharts )
        {
            $charts = $pWorksheet->getChartCollection( );
        }
        else
        {
            $charts = array( );
        }
        if ( 0 < $pWorksheet->getDrawingCollection( )->count( ) || 0 < count( $charts ) )
        {
            ++$d( $objWriter, ++$d, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing", "../drawings/drawing".$pWorksheetId.".xml" );
        }
        $i = 1;
        foreach ( $pWorksheet->getHyperlinkCollection( ) as $hyperlink )
        {
            if ( $hyperlink->isInternal( ) )
            {
                $this->_writeRelationship( $objWriter, "_hyperlink_".$i, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink", $hyperlink->getUrl( ), "External" );
                ++$i;
            }
        }
        $i = 1;
        if ( 0 < count( $pWorksheet->getComments( ) ) )
        {
            $this->_writeRelationship( $objWriter, "_comments_vml".$i, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/vmlDrawing", "../drawings/vmlDrawing".$pWorksheetId.".vml" );
            $this->_writeRelationship( $objWriter, "_comments".$i, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/comments", "../comments".$pWorksheetId.".xml" );
        }
        $i = 1;
        if ( 0 < count( $pWorksheet->getHeaderFooter( )->getImages( ) ) )
        {
            $this->_writeRelationship( $objWriter, "_headerfooter_vml".$i, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/vmlDrawing", "../drawings/vmlDrawingHF".$pWorksheetId.".vml" );
        }
        $objWriter->endElement( );
        return $objWriter->getData( );
    }

    public function writeDrawingRelationships( $pWorksheet = NULL, &$chartRef, $includeCharts = FALSE )
    {
        $objWriter = NULL;
        if ( $this->getParentWriter( )->getUseDiskCaching( ) )
        {
            $objWriter = new PHPExcel_Shared_XMLWriter( PHPExcel_Shared_XMLWriter::STORAGE_DISK, $this->getParentWriter( )->getDiskCachingDirectory( ) );
        }
        else
        {
            $objWriter = new PHPExcel_Shared_XMLWriter( PHPExcel_Shared_XMLWriter::STORAGE_MEMORY );
        }
        $objWriter->startDocument( "1.0", "UTF-8", "yes" );
        $objWriter->startElement( "Relationships" );
        $objWriter->writeAttribute( "xmlns", "http://schemas.openxmlformats.org/package/2006/relationships" );
        $i = 1;
        $iterator = $pWorksheet->getDrawingCollection( )->getIterator( );
        while ( $iterator->valid( ) )
        {
            if ( $iterator->current( ) instanceof PHPExcel_Worksheet_Drawing || $iterator->current( ) instanceof PHPExcel_Worksheet_MemoryDrawing )
            {
                $this->_writeRelationship( $objWriter, $i, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image", "../media/".str_replace( " ", "", $iterator->current( )->getIndexedFilename( ) ) );
            }
            $iterator->next( );
            ++$i;
        }
        if ( $includeCharts )
        {
            $chartCount = $pWorksheet->getChartCount( );
            if ( 0 < $chartCount )
            {
                $c = 0;
                for ( ; $c < $chartCount; ++$c )
                {
                    ++$chartRef( $objWriter, $i++, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/chart", "../charts/chart".++$chartRef.".xml" );
                }
            }
        }
        $objWriter->endElement( );
        return $objWriter->getData( );
    }

    public function writeHeaderFooterDrawingRelationships( $pWorksheet = NULL )
    {
        $objWriter = NULL;
        if ( $this->getParentWriter( )->getUseDiskCaching( ) )
        {
            $objWriter = new PHPExcel_Shared_XMLWriter( PHPExcel_Shared_XMLWriter::STORAGE_DISK, $this->getParentWriter( )->getDiskCachingDirectory( ) );
        }
        else
        {
            $objWriter = new PHPExcel_Shared_XMLWriter( PHPExcel_Shared_XMLWriter::STORAGE_MEMORY );
        }
        $objWriter->startDocument( "1.0", "UTF-8", "yes" );
        $objWriter->startElement( "Relationships" );
        $objWriter->writeAttribute( "xmlns", "http://schemas.openxmlformats.org/package/2006/relationships" );
        foreach ( $pWorksheet->getHeaderFooter( )->getImages( ) as $key => $value )
        {
            $value->getIndexedFilename( )( $objWriter, $key, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image", "../media/".$value->getIndexedFilename( ) );
        }
        $objWriter->endElement( );
        return $objWriter->getData( );
    }

    private function _writeRelationship( $objWriter = NULL, $pId = 1, $pType = "", $pTarget = "", $pTargetMode = "" )
    {
        if ( $pType != "" && $pTarget != "" )
        {
            $objWriter->startElement( "Relationship" );
            $objWriter->writeAttribute( "Id", "rId".$pId );
            $objWriter->writeAttribute( "Type", $pType );
            $objWriter->writeAttribute( "Target", $pTarget );
            if ( $pTargetMode != "" )
            {
                $objWriter->writeAttribute( "TargetMode", $pTargetMode );
            }
            $objWriter->endElement( );
        }
        else
        {
            throw new PHPExcel_Writer_Exception( "Invalid parameters passed." );
        }
    }

}

?>
