<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
$pdfRendererClassFile = ( )."/tcpdf.php";
if ( file_exists( $pdfRendererClassFile ) )
{
    $k_path_url = ( );
    require_once( $pdfRendererClassFile );
}
else
{
    throw new PHPExcel_Writer_Exception( "Unable to load PDF Rendering library" );
}
class PHPExcel_Writer_PDF_tcPDF extends PHPExcel_Writer_IWriter implements PHPExcel_Writer_IWriter
{

    public function __construct( $phpExcel )
    {
        ( $phpExcel );
    }

    public function save( $pFilename = NULL )
    {
        $fileHandle = ( $pFilename );
        $paperSize = "LETTER";
        if ( is_null( $this->getSheetIndex( ) ) )
        {
            $orientation = $this->_phpExcel->getSheet( 0 )->getPageSetup( )->getOrientation( ) == PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE ? "L" : "P";
            $printPaperSize = $this->_phpExcel->getSheet( 0 )->getPageSetup( )->getPaperSize( );
            $printMargins = $this->_phpExcel->getSheet( 0 )->getPageMargins( );
        }
        else
        {
            $orientation = $this->_phpExcel->getSheet( $this->getSheetIndex( ) )->getPageSetup( )->getOrientation( ) == PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE ? "L" : "P";
            $printPaperSize = $this->_phpExcel->getSheet( $this->getSheetIndex( ) )->getPageSetup( )->getPaperSize( );
            $printMargins = $this->_phpExcel->getSheet( $this->getSheetIndex( ) )->getPageMargins( );
        }
        $orientation = "P";
        if ( is_null( $this->getPaperSize( ) ) )
        {
            $printPaperSize = $this->getPaperSize( );
        }
        if ( isset( $_paperSizes[$printPaperSize] ) )
        {
            $paperSize = self::$_paperSizes[$printPaperSize];
        }
        $pdf = new TCPDF( $orientation, "pt", $paperSize );
        $pdf->setFontSubsetting( FALSE );
        $printMargins->getLeft( )( $printMargins->getLeft( ) * 72, $printMargins->getTop( ) * 72, $printMargins->getRight( ) * 72 );
        $printMargins->getBottom( )( TRUE, $printMargins->getBottom( ) * 72 );
        $pdf->setPrintHeader( FALSE );
        $pdf->setPrintFooter( FALSE );
        $pdf->AddPage( );
        $pdf->SetFont( $this->getFont( ) );
        $this->generateSheetData( )( $this->generateHTMLHeader( FALSE ).$this->generateSheetData( ).$this->generateHTMLFooter( ) );
        $this->_phpExcel->getProperties( )->getTitle( )( $this->_phpExcel->getProperties( )->getTitle( ) );
        $this->_phpExcel->getProperties( )->getCreator( )( $this->_phpExcel->getProperties( )->getCreator( ) );
        $this->_phpExcel->getProperties( )->getSubject( )( $this->_phpExcel->getProperties( )->getSubject( ) );
        $this->_phpExcel->getProperties( )->getKeywords( )( $this->_phpExcel->getProperties( )->getKeywords( ) );
        $this->_phpExcel->getProperties( )->getCreator( )( $this->_phpExcel->getProperties( )->getCreator( ) );
        fwrite( $fileHandle, $pdf->output( $pFilename, "S" ) );
        ( $fileHandle );
    }

}

?>
