<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
$pdfRendererClassFile = ( )."/mpdf.php";
if ( file_exists( $pdfRendererClassFile ) )
{
    require_once( $pdfRendererClassFile );
}
else
{
    throw new PHPExcel_Writer_Exception( "Unable to load PDF Rendering library" );
}
class PHPExcel_Writer_PDF_mPDF extends PHPExcel_Writer_IWriter implements PHPExcel_Writer_IWriter
{

    public function __construct( $phpExcel )
    {
        ( $phpExcel );
    }

    public function save( $pFilename = NULL )
    {
        $fileHandle = ( $pFilename );
        $paperSize = "LETTER";
        if ( is_null( $this->getSheetIndex( ) ) )
        {
            $orientation = $this->_phpExcel->getSheet( 0 )->getPageSetup( )->getOrientation( ) == PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE ? "L" : "P";
            $printPaperSize = $this->_phpExcel->getSheet( 0 )->getPageSetup( )->getPaperSize( );
            $printMargins = $this->_phpExcel->getSheet( 0 )->getPageMargins( );
        }
        else
        {
            $orientation = $this->_phpExcel->getSheet( $this->getSheetIndex( ) )->getPageSetup( )->getOrientation( ) == PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE ? "L" : "P";
            $printPaperSize = $this->_phpExcel->getSheet( $this->getSheetIndex( ) )->getPageSetup( )->getPaperSize( );
            $printMargins = $this->_phpExcel->getSheet( $this->getSheetIndex( ) )->getPageMargins( );
        }
        $this->setOrientation( $orientation );
        $orientation = $this->getOrientation( );
        $orientation = strtoupper( $orientation );
        if ( is_null( $this->getPaperSize( ) ) )
        {
            $printPaperSize = $this->getPaperSize( );
        }
        if ( isset( $_paperSizes[$printPaperSize] ) )
        {
            $paperSize = self::$_paperSizes[$printPaperSize];
        }
        $pdf = new mpdf( );
        $ortmp = $orientation;
        strtoupper( $paperSize )( strtoupper( $paperSize ), $ortmp );
        $pdf->DefOrientation = $orientation;
        $pdf->AddPage( $orientation );
        $this->_phpExcel->getProperties( )->getTitle( )( $this->_phpExcel->getProperties( )->getTitle( ) );
        $this->_phpExcel->getProperties( )->getCreator( )( $this->_phpExcel->getProperties( )->getCreator( ) );
        $this->_phpExcel->getProperties( )->getSubject( )( $this->_phpExcel->getProperties( )->getSubject( ) );
        $this->_phpExcel->getProperties( )->getKeywords( )( $this->_phpExcel->getProperties( )->getKeywords( ) );
        $this->_phpExcel->getProperties( )->getCreator( )( $this->_phpExcel->getProperties( )->getCreator( ) );
        $this->generateSheetData( )( $this->generateHTMLHeader( FALSE ).$this->generateSheetData( ).$this->generateHTMLFooter( ) );
        fwrite( $fileHandle, $pdf->Output( "", "S" ) );
        ( $fileHandle );
    }

}

?>
