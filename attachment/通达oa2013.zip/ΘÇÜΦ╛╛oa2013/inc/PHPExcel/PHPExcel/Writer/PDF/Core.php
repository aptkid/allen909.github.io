<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
abstract class PHPExcel_Writer_PDF_Core extends PHPExcel_Writer_HTML
{

    protected $_tempDir = "";
    protected $_font = "freesans";
    protected $_orientation;
    protected $_paperSize;
    private $_saveArrayReturnType;
    protected static $_paperSizes = array( 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_LETTER' => ?id #25179584, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_LETTER_SMALL' => ?id #25180856, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_TABLOID' => ?id #25180992, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_LEDGER' => ?id #25181344, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_LEGAL' => ?id #25181696, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_STATEMENT' => ?id #25181832, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_EXECUTIVE' => ?id #25182184, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_A3' => ?id #25182328, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4' => ?id #25182456, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4_SMALL' => ?id #25182656, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_A5' => ?id #25182792, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_B4' => ?id #25182920, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_B5' => ?id #25183048, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_FOLIO' => ?id #25183176, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_QUARTO' => ?id #25183312, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_STANDARD_1' => ?id #25183624, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_STANDARD_2' => ?id #25183976, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_NOTE' => ?id #25184328, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_NO9_ENVELOPE' => ?id #25184456, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_NO10_ENVELOPE' => ?id #25184808, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_NO11_ENVELOPE' => ?id #25185064, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_NO12_ENVELOPE' => ?id #25185424, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_NO14_ENVELOPE' => ?id #25185784, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_C' => ?id #25186144, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_D' => ?id #25186488, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_E' => ?id #25186832, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_DL_ENVELOPE' => ?id #25187176, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_C5_ENVELOPE' => ?id #25187528, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_C3_ENVELOPE' => ?id #25187664, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_C4_ENVELOPE' => ?id #25187800, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_C6_ENVELOPE' => ?id #25187936, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_C65_ENVELOPE' => ?id #25188072, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_B4_ENVELOPE' => ?id #25188424, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_B5_ENVELOPE' => ?id #25188824, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_B6_ENVELOPE' => ?id #25188960, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_ITALY_ENVELOPE' => ?id #25189312, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_MONARCH_ENVELOPE' => ?id #25189672, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_6_3_4_ENVELOPE' => ?id #25190032, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_US_STANDARD_FANFOLD' => ?id #25190392, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_GERMAN_STANDARD_FANFOLD' => ?id #25190832, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_GERMAN_LEGAL_FANFOLD' => ?id #25191200, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_ISO_B4' => ?id #25191344, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_JAPANESE_DOUBLE_POSTCARD' => ?id #25191480, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_STANDARD_PAPER_1' => ?id #25191848, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_STANDARD_PAPER_2' => ?id #25192208, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_STANDARD_PAPER_3' => ?id #25192568, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_INVITE_ENVELOPE' => ?id #25192928, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_LETTER_EXTRA_PAPER' => ?id #25193288, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_LEGAL_EXTRA_PAPER' => ?id #25193648, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_TABLOID_EXTRA_PAPER' => ?id #25194008, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4_EXTRA_PAPER' => ?id #25194368, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_LETTER_TRANSVERSE_PAPER' => ?id #25194728, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4_TRANSVERSE_PAPER' => ?id #25195096, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_LETTER_EXTRA_TRANSVERSE_PAPER' => ?id #25195240, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_SUPERA_SUPERA_A4_PAPER' => ?id #25195616, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_SUPERB_SUPERB_A3_PAPER' => ?id #25195984, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_LETTER_PLUS_PAPER' => ?id #25196352, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4_PLUS_PAPER' => ?id #25196712, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_A5_TRANSVERSE_PAPER' => ?id #25197072, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_JIS_B5_TRANSVERSE_PAPER' => ?id #25197216, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_A3_EXTRA_PAPER' => ?id #25197584, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_A5_EXTRA_PAPER' => ?id #25197944, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_ISO_B5_EXTRA_PAPER' => ?id #25198304, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_A2_PAPER' => ?id #25198664, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_A3_TRANSVERSE_PAPER' => ?id #25198800, 'PHPExcel_Worksheet_PageSetup::PAPERSIZE_A3_EXTRA_TRANSVERSE_PAPER' => ?id #25188560 );

    public function __construct( $phpExcel )
    {
        ( $phpExcel );
        $this->setUseInlineCss( TRUE );
        $this->_tempDir = ( );
    }

    public function getFont( )
    {
        return $this->_font;
    }

    public function setFont( $fontName )
    {
        $this->_font = $fontName;
        return $this;
    }

    public function getPaperSize( )
    {
        return $this->_paperSize;
    }

    public function setPaperSize( $pValue = PHPExcel_Worksheet_PageSetup::PAPERSIZE_LETTER )
    {
        $this->_paperSize = $pValue;
        return $this;
    }

    public function getOrientation( )
    {
        return $this->_orientation;
    }

    public function setOrientation( $pValue = PHPExcel_Worksheet_PageSetup::ORIENTATION_DEFAULT )
    {
        $this->_orientation = $pValue;
        return $this;
    }

    public function getTempDir( )
    {
        return $this->_tempDir;
    }

    public function setTempDir( $pValue = "" )
    {
        if ( is_dir( $pValue ) )
        {
            $this->_tempDir = $pValue;
        }
        else
        {
            throw new PHPExcel_Writer_Exception( "Directory does not exist: ".$pValue );
        }
        return $this;
    }

    protected function prepareForSave( $pFilename = NULL )
    {
        $this->_phpExcel->garbageCollect( );
        $this->_saveArrayReturnType = ( );
        ( PHPExcel_Calculation::RETURN_ARRAY_AS_VALUE );
        $fileHandle = fopen( $pFilename, "w" );
        if ( $fileHandle === FALSE )
        {
            throw new PHPExcel_Writer_Exception( "Could not open file ".$pFilename." for writing." );
        }
        $this->_isPdf = TRUE;
        $this->buildCSS( TRUE );
        return $fileHandle;
    }

    protected function restoreStateAfterSave( $fileHandle )
    {
        fclose( $fileHandle );
        ( $this->_saveArrayReturnType );
    }

}

?>
