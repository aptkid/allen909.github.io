<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
if ( defined( "PHPEXCEL_ROOT" ) )
{
    define( "PHPEXCEL_ROOT", dirname( __FILE__ )."/../../" );
    require( PHPEXCEL_ROOT."PHPExcel/Autoloader.php" );
}
class PHPExcel_Cell_AdvancedValueBinder extends PHPExcel_Cell_IValueBinder implements PHPExcel_Cell_IValueBinder
{

    public function bindValue( $cell, $value = NULL )
    {
        if ( is_string( $value ) )
        {
            $value = ( $value );
        }
        $dataType = ( $value );
        if ( $dataType === PHPExcel_Cell_DataType::TYPE_STRING && !$value instanceof PHPExcel_RichText )
        {
            if ( $value == ( ) )
            {
                $cell->setValueExplicit( TRUE, PHPExcel_Cell_DataType::TYPE_BOOL );
                return TRUE;
            }
            if ( $value == ( ) )
            {
                $cell->setValueExplicit( FALSE, PHPExcel_Cell_DataType::TYPE_BOOL );
                return TRUE;
            }
            if ( preg_match( "/^".PHPExcel_Calculation::CALCULATION_REGEXP_NUMBER."$/", $value ) )
            {
                $cell->setValueExplicit( ( double ), PHPExcel_Cell_DataType::TYPE_NUMERIC );
                return TRUE;
            }
            if ( preg_match( "/^([+-]?) *([0-9]*)\\s?\\/\\s*([0-9]*)$/", $value, $matches ) )
            {
                $value = $matches[2] / $matches[3];
                if ( $matches[1] == "-" )
                {
                    $value = 0 - $value;
                }
                $cell->setValueExplicit( ( double ), PHPExcel_Cell_DataType::TYPE_NUMERIC );
                $cell->getWorksheet( )->getStyle( $cell->getCoordinate( ) )->getNumberFormat( )->setFormatCode( "??/??" );
                return TRUE;
            }
            if ( preg_match( "/^([+-]?)([0-9]*) +([0-9]*)\\s?\\/\\s*([0-9]*)$/", $value, $matches ) )
            {
                $value = $matches[2] + $matches[3] / $matches[4];
                if ( $matches[1] == "-" )
                {
                    $value = 0 - $value;
                }
                $cell->setValueExplicit( ( double ), PHPExcel_Cell_DataType::TYPE_NUMERIC );
                $cell->getWorksheet( )->getStyle( $cell->getCoordinate( ) )->getNumberFormat( )->setFormatCode( "# ??/??" );
                return TRUE;
            }
            if ( preg_match( "/^\\-?[0-9]*\\.?[0-9]*\\s?\\%$/", $value ) )
            {
                $value = ( double ) / 100;
                $cell->setValueExplicit( $value, PHPExcel_Cell_DataType::TYPE_NUMERIC );
                $cell->getWorksheet( )->getStyle( $cell->getCoordinate( ) )->getNumberFormat( )->setFormatCode( PHPExcel_Style_NumberFormat::FORMAT_PERCENTAGE_00 );
                return TRUE;
            }
            $currencyCode = ( );
            $decimalSeparator = ( );
            $thousandsSeparator = ( );
            if ( preg_match( "/^".preg_quote( $currencyCode )." *(\\d{1,3}(".preg_quote( $thousandsSeparator )."\\d{3})*|(\\d+))(".preg_quote( $decimalSeparator )."\\d{2})?$/", $value ) )
            {
                $value = ( double );
                $cell->setValueExplicit( $value, PHPExcel_Cell_DataType::TYPE_NUMERIC );
                $cell->getWorksheet( )->getStyle( $cell->getCoordinate( ) )->getNumberFormat( )->setFormatCode( str_replace( "\$", $currencyCode, PHPExcel_Style_NumberFormat::FORMAT_CURRENCY_USD_SIMPLE ) );
                return TRUE;
            }
            if ( preg_match( "/^\\$ *(\\d{1,3}(\\,\\d{3})*|(\\d+))(\\.\\d{2})?$/", $value ) )
            {
                $value = ( double );
                $cell->setValueExplicit( $value, PHPExcel_Cell_DataType::TYPE_NUMERIC );
                $cell->getWorksheet( )->getStyle( $cell->getCoordinate( ) )->getNumberFormat( )->setFormatCode( PHPExcel_Style_NumberFormat::FORMAT_CURRENCY_USD_SIMPLE );
                return TRUE;
            }
            if ( preg_match( "/^(\\d|[0-1]\\d|2[0-3]):[0-5]\\d$/", $value ) )
            {
                $m = explode( ":", $value )[1];
                $h = explode( ":", $value )[0];
                $days = $h / 24 + $m / 1440;
                $cell->setValueExplicit( $days, PHPExcel_Cell_DataType::TYPE_NUMERIC );
                $cell->getWorksheet( )->getStyle( $cell->getCoordinate( ) )->getNumberFormat( )->setFormatCode( PHPExcel_Style_NumberFormat::FORMAT_DATE_TIME3 );
                return TRUE;
            }
            if ( preg_match( "/^(\\d|[0-1]\\d|2[0-3]):[0-5]\\d:[0-5]\\d$/", $value ) )
            {
                $s = explode( ":", $value )[2];
                $m = explode( ":", $value )[1];
                $h = explode( ":", $value )[0];
                $days = $h / 24 + $m / 1440 + $s / 86400;
                $cell->setValueExplicit( $days, PHPExcel_Cell_DataType::TYPE_NUMERIC );
                $cell->getWorksheet( )->getStyle( $cell->getCoordinate( ) )->getNumberFormat( )->setFormatCode( PHPExcel_Style_NumberFormat::FORMAT_DATE_TIME4 );
                return TRUE;
            }
            if ( ( $d = ( $value ) ) !== FALSE )
            {
                $cell->setValueExplicit( $d, PHPExcel_Cell_DataType::TYPE_NUMERIC );
                if ( strpos( $value, ":" ) !== FALSE )
                {
                    $formatCode = "yyyy-mm-dd h:mm";
                }
                else
                {
                    $formatCode = "yyyy-mm-dd";
                }
                $cell->getWorksheet( )->getStyle( $cell->getCoordinate( ) )->getNumberFormat( )->setFormatCode( $formatCode );
                return TRUE;
            }
            if ( strpos( $value, "\n" ) !== FALSE )
            {
                $value = ( $value );
                $cell->setValueExplicit( $value, PHPExcel_Cell_DataType::TYPE_STRING );
                $cell->getWorksheet( )->getStyle( $cell->getCoordinate( ) )->getAlignment( )->setWrapText( TRUE );
                return TRUE;
            }
        }
        return ( $cell, $value );
    }

}

?>
