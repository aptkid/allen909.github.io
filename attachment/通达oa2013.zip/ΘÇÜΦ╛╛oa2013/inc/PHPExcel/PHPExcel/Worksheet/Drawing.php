<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class PHPExcel_Worksheet_Drawing extends PHPExcel_IComparable implements PHPExcel_IComparable
{

    private $_path;

    public function __construct( )
    {
        $this->_path = "";
        ( );
    }

    public function getFilename( )
    {
        return basename( $this->_path );
    }

    public function getIndexedFilename( )
    {
        $fileName = $this->getFilename( );
        $fileName = str_replace( " ", "_", $fileName );
        return str_replace( ".".$this->getExtension( ), "", $fileName ).$this->getImageIndex( ).".".$this->getExtension( );
    }

    public function getExtension( )
    {
        $exploded = explode( ".", basename( $this->_path ) );
        return $exploded[count( $exploded ) - 1];
    }

    public function getPath( )
    {
        return $this->_path;
    }

    public function setPath( $pValue = "", $pVerifyFile = TRUE )
    {
        if ( $pVerifyFile )
        {
            if ( file_exists( $pValue ) )
            {
                $this->_path = $pValue;
                if ( $this->_width == 0 && $this->_height == 0 )
                {
                    $this->_height = getimagesize( $pValue )[1];
                    $this->_width = getimagesize( $pValue )[0];
                }
            }
            else
            {
                throw new PHPExcel_Exception( "File ".$pValue." not found!" );
            }
        }
        $this->_path = $pValue;
        return $this;
    }

    public function getHashCode( )
    {
        return md5( $this->_path.( )."PHPExcel_Worksheet_Drawing" );
    }

    public function __clone( )
    {
        $vars = get_object_vars( $this );
        foreach ( $vars as $key => $value )
        {
            if ( is_object( $value ) )
            {
                $this->$key = clone $value;
            }
            else
            {
                $this->$key = $value;
            }
        }
    }

}

?>
