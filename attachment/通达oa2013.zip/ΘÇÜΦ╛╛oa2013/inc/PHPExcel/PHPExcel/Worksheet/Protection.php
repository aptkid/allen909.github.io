<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class PHPExcel_Worksheet_Protection
{

    private $_sheet = FALSE;
    private $_objects = FALSE;
    private $_scenarios = FALSE;
    private $_formatCells = FALSE;
    private $_formatColumns = FALSE;
    private $_formatRows = FALSE;
    private $_insertColumns = FALSE;
    private $_insertRows = FALSE;
    private $_insertHyperlinks = FALSE;
    private $_deleteColumns = FALSE;
    private $_deleteRows = FALSE;
    private $_selectLockedCells = FALSE;
    private $_sort = FALSE;
    private $_autoFilter = FALSE;
    private $_pivotTables = FALSE;
    private $_selectUnlockedCells = FALSE;
    private $_password = "";

    public function __construct( )
    {
    }

    public function isProtectionEnabled( )
    {
        return $this->_sheet || $this->_objects || $this->_scenarios || $this->_formatCells || $this->_formatColumns || $this->_formatRows || $this->_insertColumns || $this->_insertRows || $this->_insertHyperlinks || $this->_deleteColumns || $this->_deleteRows || $this->_selectLockedCells || $this->_sort || $this->_autoFilter || $this->_pivotTables || $this->_selectUnlockedCells;
    }

    public function getSheet( )
    {
        return $this->_sheet;
    }

    public function setSheet( $pValue = FALSE )
    {
        $this->_sheet = $pValue;
        return $this;
    }

    public function getObjects( )
    {
        return $this->_objects;
    }

    public function setObjects( $pValue = FALSE )
    {
        $this->_objects = $pValue;
        return $this;
    }

    public function getScenarios( )
    {
        return $this->_scenarios;
    }

    public function setScenarios( $pValue = FALSE )
    {
        $this->_scenarios = $pValue;
        return $this;
    }

    public function getFormatCells( )
    {
        return $this->_formatCells;
    }

    public function setFormatCells( $pValue = FALSE )
    {
        $this->_formatCells = $pValue;
        return $this;
    }

    public function getFormatColumns( )
    {
        return $this->_formatColumns;
    }

    public function setFormatColumns( $pValue = FALSE )
    {
        $this->_formatColumns = $pValue;
        return $this;
    }

    public function getFormatRows( )
    {
        return $this->_formatRows;
    }

    public function setFormatRows( $pValue = FALSE )
    {
        $this->_formatRows = $pValue;
        return $this;
    }

    public function getInsertColumns( )
    {
        return $this->_insertColumns;
    }

    public function setInsertColumns( $pValue = FALSE )
    {
        $this->_insertColumns = $pValue;
        return $this;
    }

    public function getInsertRows( )
    {
        return $this->_insertRows;
    }

    public function setInsertRows( $pValue = FALSE )
    {
        $this->_insertRows = $pValue;
        return $this;
    }

    public function getInsertHyperlinks( )
    {
        return $this->_insertHyperlinks;
    }

    public function setInsertHyperlinks( $pValue = FALSE )
    {
        $this->_insertHyperlinks = $pValue;
        return $this;
    }

    public function getDeleteColumns( )
    {
        return $this->_deleteColumns;
    }

    public function setDeleteColumns( $pValue = FALSE )
    {
        $this->_deleteColumns = $pValue;
        return $this;
    }

    public function getDeleteRows( )
    {
        return $this->_deleteRows;
    }

    public function setDeleteRows( $pValue = FALSE )
    {
        $this->_deleteRows = $pValue;
        return $this;
    }

    public function getSelectLockedCells( )
    {
        return $this->_selectLockedCells;
    }

    public function setSelectLockedCells( $pValue = FALSE )
    {
        $this->_selectLockedCells = $pValue;
        return $this;
    }

    public function getSort( )
    {
        return $this->_sort;
    }

    public function setSort( $pValue = FALSE )
    {
        $this->_sort = $pValue;
        return $this;
    }

    public function getAutoFilter( )
    {
        return $this->_autoFilter;
    }

    public function setAutoFilter( $pValue = FALSE )
    {
        $this->_autoFilter = $pValue;
        return $this;
    }

    public function getPivotTables( )
    {
        return $this->_pivotTables;
    }

    public function setPivotTables( $pValue = FALSE )
    {
        $this->_pivotTables = $pValue;
        return $this;
    }

    public function getSelectUnlockedCells( )
    {
        return $this->_selectUnlockedCells;
    }

    public function setSelectUnlockedCells( $pValue = FALSE )
    {
        $this->_selectUnlockedCells = $pValue;
        return $this;
    }

    public function getPassword( )
    {
        return $this->_password;
    }

    public function setPassword( $pValue = "", $pAlreadyHashed = FALSE )
    {
        if ( $pAlreadyHashed )
        {
            $pValue = ( $pValue );
        }
        $this->_password = $pValue;
        return $this;
    }

    public function __clone( )
    {
        $vars = get_object_vars( $this );
        foreach ( $vars as $key => $value )
        {
            if ( is_object( $value ) )
            {
                $this->$key = clone $value;
            }
            else
            {
                $this->$key = $value;
            }
        }
    }

}

?>
