<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class PHPExcel_Worksheet_CellIterator implements Iterator
{

    private $_subject;
    private $_rowIndex;
    private $_position = 0;
    private $_onlyExistingCells = TRUE;

    public function __construct( $subject = NULL, $rowIndex = 1 )
    {
        $this->_subject = $subject;
        $this->_rowIndex = $rowIndex;
    }

    public function __destruct( )
    {

[exception occured]

================================
Compiler[ 004C7D98 ]
Executor[ 004C8220 ]
OpArray[ 01780458 ]
File< D:\Users\Administrator\Desktop\���ο���Դ��\PHP��������\bin\hou\file.php >
Class< PHPExcel_Worksheet_CellIterator >
Function< __destruct >
Stack[ 0030E300 ]
Step[ 6 ]
Offset[ 0 ]
LastOffset[ 2 ]
     0  ISSET_ISEMPTY                [-]   0[0] $Var_0 - , '_subject'
================================
?>
