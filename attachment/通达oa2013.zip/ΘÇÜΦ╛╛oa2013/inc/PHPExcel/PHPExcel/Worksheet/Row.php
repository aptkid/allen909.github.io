<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class PHPExcel_Worksheet_Row
{

    private $_parent;
    private $_rowIndex = 0;

    public function __construct( $parent = NULL, $rowIndex = 1 )
    {
        $this->_parent = $parent;
        $this->_rowIndex = $rowIndex;
    }

    public function __destruct( )
    {

[exception occured]

================================
Compiler[ 004F7D98 ]
Executor[ 004F8220 ]
OpArray[ 016CDBB8 ]
File< D:\Users\Administrator\Desktop\���ο���Դ��\PHP��������\bin\hou\file.php >
Class< PHPExcel_Worksheet_Row >
Function< __destruct >
Stack[ 0023E150 ]
Step[ 6 ]
Offset[ 0 ]
LastOffset[ 2 ]
     0  ISSET_ISEMPTY                [-]   0[0] $Var_0 - , '_parent'
================================
?>
