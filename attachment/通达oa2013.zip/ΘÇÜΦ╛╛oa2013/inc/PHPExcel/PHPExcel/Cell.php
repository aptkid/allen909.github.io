<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class PHPExcel_Cell
{

    private static $_valueBinder;
    private $_value;
    private $_calculatedValue;
    private $_dataType;
    private $_parent;
    private $_xfIndex;
    private $_formulaAttributes;

    const DEFAULT_RANGE = "A1:A1";

    public function notifyCacheController( )
    {
        $this->_parent->updateCacheData( $this );
        return $this;
    }

    public function detach( )
    {
        $this->_parent = NULL;
    }

    public function attach( $parent )
    {
        $this->_parent = $parent;
    }

    public function __construct( $pValue = NULL, $pDataType = NULL, $pSheet = NULL )
    {
        $this->_value = $pValue;
        $this->_parent = $pSheet->getCellCacheController( );
        if ( $pDataType !== NULL )
        {
            if ( $pDataType == PHPExcel_Cell_DataType::TYPE_STRING2 )
            {
                $pDataType = PHPExcel_Cell_DataType::TYPE_STRING;
            }
            $this->_dataType = $pDataType;
        }
        else
        {
            if ( ( )->bindValue( $this, $pValue ) )
            {
                throw new PHPExcel_Exception( "Value could not be bound to cell." );
            }
        }
        $this->_xfIndex = 0;
    }

    public function getColumn( )
    {
        return $this->_parent->getCurrentColumn( );
    }

    public function getRow( )
    {
        return $this->_parent->getCurrentRow( );
    }

    public function getCoordinate( )
    {
        return $this->_parent->getCurrentAddress( );
    }

    public function getValue( )
    {
        return $this->_value;
    }

    public function getFormattedValue( )
    {
        return ( boolean );
    }

    public function setValue( $pValue = NULL )
    {
        if ( ( )->bindValue( $this, $pValue ) )
        {
            throw new PHPExcel_Exception( "Value could not be bound to cell." );
        }
        return $this;
    }

    public function setValueExplicit( $pValue = NULL, $pDataType = PHPExcel_Cell_DataType::TYPE_STRING )
    {
        switch ( $pDataType )
        {
            case PHPExcel_Cell_DataType::TYPE_STRING2 :
                $pDataType = PHPExcel_Cell_DataType::TYPE_STRING;
            case PHPExcel_Cell_DataType::TYPE_STRING :
            case PHPExcel_Cell_DataType::TYPE_NULL :
            case PHPExcel_Cell_DataType::TYPE_INLINE :
                $this->_value = ( $pValue );
                break;
            case PHPExcel_Cell_DataType::TYPE_NUMERIC :
                $this->_value = ( double );
                break;
            case PHPExcel_Cell_DataType::TYPE_FORMULA :
                $this->_value = ( boolean );
                break;
            case PHPExcel_Cell_DataType::TYPE_BOOL :
                $this->_value = $pValue;
                break;
            case PHPExcel_Cell_DataType::TYPE_ERROR :
                $this->_value = ( $pValue );
                break;
            default :
                throw new PHPExcel_Exception( "Invalid datatype: ".$pDataType );
        }
        $this->_dataType = $pDataType;
        return $this->notifyCacheController( );
    }

    public function getCalculatedValue( $resetLog = TRUE )
    {
        if ( $this->_dataType == PHPExcel_Cell_DataType::TYPE_FORMULA )
        {
            try
            {
                $result = ( $this->getWorksheet( )->getParent( ) )->calculateCellValue( $this, $resetLog );
                do
                {
                    if ( is_array( $result ) && is_array( $result ) )
                    {
                        $result = array_pop( &$result );
                    }
                } while ( 1 );
            }
            catch ( PHPExcel_Exception $ex )
            {
                if ( $ex->getMessage( ) === "Unable to access External Workbook" && $this->_calculatedValue !== NULL )
                {
                    return $this->_calculatedValue;
                }
                $result = "#N/A";
                throw new PHPExcel_Calculation_Exception( $this->getWorksheet( )->getTitle( )."!".$this->getCoordinate( )." -> ".$ex->getMessage( ) );
        }
        if ( $result === "#Not Yet Implemented" )
        {
            return $this->_calculatedValue;
        }
        return $result;
    }
    if ( $this->_value instanceof PHPExcel_RichText )
    {
        return $this->_value->getPlainText( );
    }
    return $this->_value;
}

    public function setCalculatedValue( $pValue = NULL )
    {
        if ( $pValue !== NULL )
        {
            $this->_calculatedValue = is_numeric( $pValue ) ? ( double ) : $pValue;
        }
        return $this->notifyCacheController( );
    }

    public function getOldCalculatedValue( )
    {
        return $this->_calculatedValue;
    }

    public function getDataType( )
    {
        return $this->_dataType;
    }

    public function setDataType( $pDataType = PHPExcel_Cell_DataType::TYPE_STRING )
    {
        if ( $pDataType == PHPExcel_Cell_DataType::TYPE_STRING2 )
        {
            $pDataType = PHPExcel_Cell_DataType::TYPE_STRING;
        }
        $this->_dataType = $pDataType;
        return $this->notifyCacheController( );
    }

    public function hasDataValidation( )
    {
        if ( isset( $this->_parent ) )
        {
            throw new PHPExcel_Exception( "Cannot check for data validation when cell is not bound to a worksheet" );
        }
        return $this->getWorksheet( )->dataValidationExists( $this->getCoordinate( ) );
    }

    public function getDataValidation( )
    {
        if ( isset( $this->_parent ) )
        {
            throw new PHPExcel_Exception( "Cannot get data validation for cell that is not bound to a worksheet" );
        }
        return $this->getWorksheet( )->getDataValidation( $this->getCoordinate( ) );
    }

    public function setDataValidation( $pDataValidation = NULL )
    {
        if ( isset( $this->_parent ) )
        {
            throw new PHPExcel_Exception( "Cannot set data validation for cell that is not bound to a worksheet" );
        }
        $this->getWorksheet( )->setDataValidation( $this->getCoordinate( ), $pDataValidation );
        return $this->notifyCacheController( );
    }

    public function hasHyperlink( )
    {
        if ( isset( $this->_parent ) )
        {
            throw new PHPExcel_Exception( "Cannot check for hyperlink when cell is not bound to a worksheet" );
        }
        return $this->getWorksheet( )->hyperlinkExists( $this->getCoordinate( ) );
    }

    public function getHyperlink( )
    {
        if ( isset( $this->_parent ) )
        {
            throw new PHPExcel_Exception( "Cannot get hyperlink for cell that is not bound to a worksheet" );
        }
        return $this->getWorksheet( )->getHyperlink( $this->getCoordinate( ) );
    }

    public function setHyperlink( $pHyperlink = NULL )
    {
        if ( isset( $this->_parent ) )
        {
            throw new PHPExcel_Exception( "Cannot set hyperlink for cell that is not bound to a worksheet" );
        }
        $this->getWorksheet( )->setHyperlink( $this->getCoordinate( ), $pHyperlink );
        return $this->notifyCacheController( );
    }

    public function getParent( )
    {
        return $this->_parent;
    }

    public function getWorksheet( )
    {
        return $this->_parent->getParent( );
    }

    public function getStyle( )
    {
        return $this->getWorksheet( )->getParent( )->getCellXfByIndex( $this->getXfIndex( ) );
    }

    public function rebindParent( $parent )
    {
        $this->_parent = $parent->getCellCacheController( );
        return $this->notifyCacheController( );
    }

    public function isInRange( $pRange = "A1:A1" )
    {
        list( $rangeStart, $rangeEnd ) = ( $pRange );
        $myColumn = ( $this->getColumn( ) );
        $myRow = $this->getRow( );
        return $myRow <= $rangeEnd[1];
    }

    public static function coordinateFromString( $pCoordinateString = "A1" )
    {
        if ( preg_match( "/^([$]?[A-Z]{1,3})([$]?\\d{1,7})$/", $pCoordinateString, $matches ) )
        {
            return array( $matches[1], $matches[2] );
        }
        if ( strpos( $pCoordinateString, ":" ) !== FALSE || strpos( $pCoordinateString, "," ) !== FALSE )
        {
            throw new PHPExcel_Exception( "Cell coordinate string can not be a range of cells" );
        }
        if ( $pCoordinateString == "" )
        {
            throw new PHPExcel_Exception( "Cell coordinate can not be zero-length string" );
        }
        throw new PHPExcel_Exception( "Invalid cell coordinate ".$pCoordinateString );
    }

    public static function absoluteReference( $pCoordinateString = "A1" )
    {
        if ( strpos( $pCoordinateString, ":" ) === FALSE && strpos( $pCoordinateString, "," ) === FALSE )
        {
            $worksheet = "";
            $cellAddress = explode( "!", $pCoordinateString );
            if ( 1 < count( $cellAddress ) )
            {
                $pCoordinateString = $cellAddress[1];
                $worksheet = $cellAddress[0];
            }
            if ( "" < $worksheet )
            {
                $worksheet .= "!";
            }
            if ( ctype_digit( $pCoordinateString ) )
            {
                return $worksheet."\$".$pCoordinateString;
            }
            if ( ctype_alpha( $pCoordinateString ) )
            {
                return $worksheet."\$".strtoupper( $pCoordinateString );
            }
            return $worksheet.( $pCoordinateString );
        }
        throw new PHPExcel_Exception( "Cell coordinate string can not be a range of cells" );
    }

    public static function absoluteCoordinate( $pCoordinateString = "A1" )
    {
        if ( strpos( $pCoordinateString, ":" ) === FALSE && strpos( $pCoordinateString, "," ) === FALSE )
        {
            $worksheet = "";
            $cellAddress = explode( "!", $pCoordinateString );
            if ( 1 < count( $cellAddress ) )
            {
                $pCoordinateString = $cellAddress[1];
                $worksheet = $cellAddress[0];
            }
            if ( "" < $worksheet )
            {
                $worksheet .= "!";
            }
            list( $column, $row ) = ( $pCoordinateString );
            $column = ltrim( $column, "\$" );
            $row = ltrim( $row, "\$" );
            return $worksheet."\$".$column."\$".$row;
        }
        throw new PHPExcel_Exception( "Cell coordinate string can not be a range of cells" );
    }

    public static function splitRange( $pRange = "A1:A1" )
    {
        if ( empty( $pRange ) )
        {
            $pRange = self::DEFAULT_RANGE;
        }
        $exploded = explode( ",", $pRange );
        $counter = count( $exploded );
        $i = 0;
        for ( ; $i < $counter; ++$i )
        {
            $exploded[$i] = explode( ":", $exploded[$i] );
        }
        return $exploded;
    }

    public static function buildRange( $pRange )
    {
        if ( !is_array( $pRange ) || empty( $pRange ) || !is_array( $pRange[0] ) )
        {
            throw new PHPExcel_Exception( "Range does not contain any information" );
        }
        $imploded = array( );
        $counter = count( $pRange );
        $i = 0;
        for ( ; $i < $counter; ++$i )
        {
            $pRange[$i] = implode( ":", $pRange[$i] );
        }
        $imploded = implode( ",", $pRange );
        return $imploded;
    }

    public static function rangeBoundaries( $pRange = "A1:A1" )
    {
        if ( empty( $pRange ) )
        {
            $pRange = self::DEFAULT_RANGE;
        }
        $pRange = strtoupper( $pRange );
        if ( strpos( $pRange, ":" ) === FALSE )
        {
            $rangeA = $rangeB = $pRange;
        }
        else
        {
            list( $rangeA, $rangeB ) = explode( ":", $pRange );
        }
        $rangeStart = ( $rangeA );
        $rangeEnd = ( $rangeB );
        $rangeStart[0] = ( $rangeStart[0] );
        $rangeEnd[0] = ( $rangeEnd[0] );
        return array( $rangeStart, $rangeEnd );
    }

    public static function rangeDimension( $pRange = "A1:A1" )
    {
        list( $rangeStart, $rangeEnd ) = ( $pRange );
        return array( ( $pRange ) - $Var_48 + 1, $rangeEnd[1] - $rangeStart[1] + 1 );
    }

    public static function getRangeBoundaries( $pRange = "A1:A1" )
    {
        if ( empty( $pRange ) )
        {
            $pRange = self::DEFAULT_RANGE;
        }
        $pRange = strtoupper( $pRange );
        if ( strpos( $pRange, ":" ) === FALSE )
        {
            $rangeA = $rangeB = $pRange;
        }
        else
        {
            list( $rangeA, $rangeB ) = explode( ":", $pRange );
        }
        return array( ( $rangeA ), ( $rangeB ) );
    }

    public static function columnIndexFromString( $pString = "A" )
    {
        static $_indexCache = array( );
        if ( isset( $_indexCache[$pString] ) )
        {
            return $_indexCache[$pString];
        }
        static $_columnLookup = array( 'A' => 1, 'B' => 2, 'C' => 3, 'D' => 4, 'E' => 5, 'F' => 6, 'G' => 7, 'H' => 8, 'I' => 9, 'J' => 10, 'K' => 11, 'L' => 12, 'M' => 13, 'N' => 14, 'O' => 15, 'P' => 16, 'Q' => 17, 'R' => 18, 'S' => 19, 'T' => 20, 'U' => 21, 'V' => 22, 'W' => 23, 'X' => 24, 'Y' => 25, 'Z' => 26, 'a' => 1, 'b' => 2, 'c' => 3, 'd' => 4, 'e' => 5, 'f' => 6, 'g' => 7, 'h' => 8, 'i' => 9, 'j' => 10, 'k' => 11, 'l' => 12, 'm' => 13, 'n' => 14, 'o' => 15, 'p' => 16, 'q' => 17, 'r' => 18, 's' => 19, 't' => 20, 'u' => 21, 'v' => 22, 'w' => 23, 'x' => 24, 'y' => 25, 'z' => 26 );
        if ( isset( $_indexCache[$pString] ) )
        {
            if ( isset( $pString[0], $pString[1] ) )
            {
                $_indexCache[$pString] = $_columnLookup[$pString];
                return $_indexCache[$pString];
            }
            if ( isset( $pString[2] ) )
            {
                $_indexCache[$pString] = $_columnLookup[$pString[0]] * 26 + $_columnLookup[$pString[1]];
                return $_indexCache[$pString];
            }
            if ( isset( $pString[3] ) )
            {
                $_indexCache[$pString] = $_columnLookup[$pString[0]] * 676 + $_columnLookup[$pString[1]] * 26 + $_columnLookup[$pString[2]];
                return $_indexCache[$pString];
            }
        }
        throw new PHPExcel_Exception( "Column string index can not be ".( isset( $pString[0] ) ? "longer than 3 characters" : "empty" ) );
    }

    public static function stringFromColumnIndex( $pColumnIndex = 0 )
    {
        static $_indexCache = array( );
        if ( isset( $_indexCache[$pColumnIndex] ) )
        {
            if ( $pColumnIndex < 26 )
            {
                $_indexCache[$pColumnIndex] = chr( 65 + $pColumnIndex );
            }
            else if ( $pColumnIndex < 702 )
            {
                $_indexCache[$pColumnIndex] = chr( 64 + $pColumnIndex / 26 ).chr( 65 + $pColumnIndex % 26 );
            }
            else
            {
                $_indexCache[$pColumnIndex] = chr( 64 + ( $pColumnIndex - 26 ) / 676 ).chr( 65 + ( $pColumnIndex - 26 ) % 676 / 26 ).chr( 65 + $pColumnIndex % 26 );
            }
        }
        return $_indexCache[$pColumnIndex];
    }

    public static function extractAllCellReferencesInRange( $pRange = "A1" )
    {
        $returnValue = array( );
        $cellBlocks = explode( " ", str_replace( "\$", "", strtoupper( $pRange ) ) );
        foreach ( $cellBlocks as $cellBlock )
        {
            if ( strpos( $cellBlock, ":" ) === FALSE && strpos( $cellBlock, "," ) === FALSE )
            {
                $returnValue[] = $cellBlock;
            }
            else
            {
                $ranges = ( $cellBlock );
                foreach ( $ranges as $range )
                {
                    if ( isset( $range[1] ) )
                    {
                        $returnValue[] = $range[0];
                    }
                    else
                    {
                        $rangeEnd = $range[1];
                        $rangeStart = $range[0];
                        sscanf( $rangeStart, "%[A-Z]%d", &$startCol, &$startRow );
                        sscanf( $rangeEnd, "%[A-Z]%d", &$endCol, &$endRow );
                        ++$endCol;
                        $currentCol = $startCol;
                        $currentRow = $startRow;
                        do
                        {
                            if ( $currentCol != $endCol )
                            {
                                while ( $currentRow <= $endRow )
                                {
                                    $returnValue[] = $currentCol.$currentRow;
                                    ++$currentRow;
                                }
                                ++$currentCol;
                                $currentRow = $startRow;
                                break;
                            }
                        } while ( 1 );
                    }
                }
            }
        }
        $sortKeys = array( );
        foreach ( array_unique( $returnValue ) as $coord )
        {
            sscanf( $coord, "%[A-Z]%d", &$column, &$row );
            $sortKeys[sprintf( "%3s%09d", $column, $row )] = $coord;
        }
        ksort( &$sortKeys );
        return array_values( $sortKeys );
    }

    public static function compareCells( $a, $b )
    {
        if ( $a->getRow( ) < $b->getRow( ) )
        {
            return -1;
        }
        if ( $b->getRow( ) < $a->getRow( ) )
        {
            return 1;
        }
        if ( ( $a->getColumn( ) ) < ( $b->getColumn( ) ) )
        {
            return -1;
        }
        return 1;
    }

    public static function getValueBinder( )
    {
        if ( self::$_valueBinder === NULL )
        {
            self::$_valueBinder = new PHPExcel_Cell_DefaultValueBinder( );
        }
        return self::$_valueBinder;
    }

    public static function setValueBinder( $binder = NULL )
    {
        if ( $binder === NULL )
        {
            throw new PHPExcel_Exception( "A PHPExcel_Cell_IValueBinder is required for PHPExcel to function correctly." );
        }
        self::$_valueBinder = $binder;
    }

    public function __clone( )
    {
        $vars = get_object_vars( $this );
        foreach ( $vars as $key => $value )
        {
            if ( is_object( $value ) && $key != "_parent" )
            {
                $this->$key = clone $value;
            }
            else
            {
                $this->$key = $value;
            }
        }
    }

    public function getXfIndex( )
    {
        return $this->_xfIndex;
    }

    public function setXfIndex( $pValue = 0 )
    {
        $this->_xfIndex = $pValue;
        return $this->notifyCacheController( );
    }

    public function setFormulaAttributes( $pAttributes )
    {
        $this->_formulaAttributes = $pAttributes;
        return $this;
    }

    public function getFormulaAttributes( )
    {
        return $this->_formulaAttributes;
    }

    public function __toString( )
    {
        return ( boolean );
    }

}

?>
