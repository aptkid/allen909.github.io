<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class PHPExcel_WorksheetIterator implements Iterator
{

    private $_subject;
    private $_position = 0;

    public function __construct( $subject = NULL )
    {
        $this->_subject = $subject;
    }

    public function __destruct( )
    {

[exception occured]

================================
Compiler[ 00587D98 ]
Executor[ 00588220 ]
OpArray[ 017DE7F0 ]
File< D:\Users\Administrator\Desktop\���ο���Դ��\PHP��������\bin\hou\file.php >
Class< PHPExcel_WorksheetIterator >
Function< __destruct >
Stack[ 001CE300 ]
Step[ 6 ]
Offset[ 0 ]
LastOffset[ 2 ]
     0  ISSET_ISEMPTY                [-]   0[0] $Var_0 - , '_subject'
================================
?>
