<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class PHPExcel_Settings
{

    private static $_chartRenderers = array( self::CHART_RENDERER_JPGRAPH );
    private static $_pdfRenderers = array( self::PDF_RENDERER_TCPDF, self::PDF_RENDERER_DOMPDF, self::PDF_RENDERER_MPDF );
    private static $_zipClass = self::ZIPARCHIVE;
    private static $_chartRendererName;
    private static $_chartRendererPath;
    private static $_pdfRendererName;
    private static $_pdfRendererPath;

    const PCLZIP = "PHPExcel_Shared_ZipArchive";
    const ZIPARCHIVE = "ZipArchive";
    const CHART_RENDERER_JPGRAPH = "jpgraph";
    const PDF_RENDERER_TCPDF = "tcPDF";
    const PDF_RENDERER_DOMPDF = "DomPDF";
    const PDF_RENDERER_MPDF = "mPDF";

    public static function setZipClass( $zipClass )
    {
        do
        {
            if ( $zipClass === self::PCLZIP )
            {
                break;
            }
            else
            {
            }
            if ( $zipClass === self::ZIPARCHIVE )
            {
            }
        } while ( 0 );
        self::$_zipClass = $zipClass;
        return TRUE;
        return FALSE;
    }

    public static function getZipClass( )
    {
        return self::$_zipClass;
    }

    public static function getCacheStorageMethod( )
    {
        return ( );
    }

    public static function getCacheStorageClass( )
    {
        return ( );
    }

    public static function setCacheStorageMethod( $method = PHPExcel_CachedObjectStorageFactory::cache_in_memory, $arguments = array( ) )
    {
        return ( $method, $arguments );
    }

    public static function setLocale( $locale = "en_us" )
    {
        return ( )->setLocale( $locale );
    }

    public static function setChartRenderer( $libraryName, $libraryBaseDir )
    {
        if ( ( $libraryName ) )
        {
            return FALSE;
        }
        return ( $libraryBaseDir );
    }

    public static function setChartRendererName( $libraryName )
    {
        if ( in_array( $libraryName, self::$_chartRenderers ) )
        {
            return FALSE;
        }
        self::$_chartRendererName = $libraryName;
        return TRUE;
    }

    public static function setChartRendererPath( $libraryBaseDir )
    {
        if ( file_exists( $libraryBaseDir ) === FALSE || is_readable( $libraryBaseDir ) === FALSE )
        {
            return FALSE;
        }
        self::$_chartRendererPath = $libraryBaseDir;
        return TRUE;
    }

    public static function getChartRendererName( )
    {
        return self::$_chartRendererName;
    }

    public static function getChartRendererPath( )
    {
        return self::$_chartRendererPath;
    }

    public static function setPdfRenderer( $libraryName, $libraryBaseDir )
    {
        if ( ( $libraryName ) )
        {
            return FALSE;
        }
        return ( $libraryBaseDir );
    }

    public static function setPdfRendererName( $libraryName )
    {
        if ( in_array( $libraryName, self::$_pdfRenderers ) )
        {
            return FALSE;
        }
        self::$_pdfRendererName = $libraryName;
        return TRUE;
    }

    public static function setPdfRendererPath( $libraryBaseDir )
    {
        if ( file_exists( $libraryBaseDir ) === FALSE || is_readable( $libraryBaseDir ) === FALSE )
        {
            return FALSE;
        }
        self::$_pdfRendererPath = $libraryBaseDir;
        return TRUE;
    }

    public static function getPdfRendererName( )
    {
        return self::$_pdfRendererName;
    }

    public static function getPdfRendererPath( )
    {
        return self::$_pdfRendererPath;
    }

}

if ( defined( "PHPEXCEL_ROOT" ) )
{
    define( "PHPEXCEL_ROOT", dirname( __FILE__ )."/../" );
    require( PHPEXCEL_ROOT."PHPExcel/Autoloader.php" );
}
?>
