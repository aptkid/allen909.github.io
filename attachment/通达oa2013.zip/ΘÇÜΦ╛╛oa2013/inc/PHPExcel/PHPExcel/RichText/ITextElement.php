<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
interface PHPExcel_RichText_ITextElement
{

    public abstract function getText( );

    public abstract function setText( );
$pText = "" )
    {

    public abstract function getFont( );

    public abstract function getHashCode( );

}

?>
