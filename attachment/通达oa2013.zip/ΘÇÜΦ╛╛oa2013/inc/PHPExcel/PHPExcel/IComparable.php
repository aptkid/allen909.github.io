<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
interface PHPExcel_IComparable
{

    public abstract function getHashCode( );

}

?>
