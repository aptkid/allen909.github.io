<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class PHPExcel_Shared_ZipStreamWrapper
{

    private $_archive;
    private $_fileNameInArchive = "";
    private $_position = 0;
    private $_data = "";

    public static function register( )
    {
        @stream_wrapper_unregister( "zip" );
        @stream_wrapper_register( "zip", "PHPExcel_Shared_ZipStreamWrapper" );
    }

    public function stream_open( $path, $mode, $options, &$opened_path )
    {
        if ( $mode[0] != "r" )
        {
            throw new PHPExcel_Reader_Exception( "Mode ".$mode." is not supported. Only read mode is supported." );
        }
        $pos = strrpos( $path, "#" );
        $url['host'] = substr( $path, 6, $pos - 6 );
        $url['fragment'] = substr( $path, $pos + 1 );
        $this->_archive = new ZipArchive( );
        $this->_archive->open( $url['host'] );
        $this->_fileNameInArchive = $url['fragment'];
        $this->_position = 0;
        $this->_data = $this->_archive->getFromName( $this->_fileNameInArchive );
        return TRUE;
    }

    public function statName( )
    {
        return $this->_fileNameInArchive;
    }

    public function url_stat( )
    {
        return $this->_fileNameInArchive( $this->_fileNameInArchive );
    }

    public function stream_stat( )
    {
        return $this->_archive->statName( $this->_fileNameInArchive );
    }

    public function stream_read( $count )
    {
        $ret = substr( $this->_data, $this->_position, $count );
        $ && _766767872 += "_position";
        return $ret;
    }

    public function stream_tell( )
    {
        return $this->_position;
    }

    public function stream_eof( )
    {
        return strlen( $this->_data ) <= $this->_position;
    }

    public function stream_seek( $offset, $whence )
    {
        switch ( $whence )
        {
            case SEEK_SET :
                if ( $offset < strlen( $this->_data ) && 0 <= $offset )
                {
                    $this->_position = $offset;
                    return TRUE;
                }
                return FALSE;
            case SEEK_CUR :
                if ( 0 <= $offset )
                {
                    $ && _712023488 += "_position";
                    return TRUE;
                }
                return FALSE;
            case SEEK_END :
                if ( 0 <= strlen( $this->_data ) + $offset )
                {
                    $this->_position = strlen( $this->_data ) + $offset;
                    return TRUE;
                }
                return FALSE;
            default :
                return FALSE;
        }
    }

}

?>
