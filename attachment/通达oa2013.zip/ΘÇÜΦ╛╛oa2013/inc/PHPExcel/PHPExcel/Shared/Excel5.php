<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class PHPExcel_Shared_Excel5
{

    public static function sizeCol( $sheet, $col = "A" )
    {
        $font = $sheet->getParent( )->getDefaultStyle( )->getFont( );
        $columnDimensions = $sheet->getColumnDimensions( );
        if ( isset( $columnDimensions[$col] ) && $columnDimensions[$col]->getWidth( ) != -1 )
        {
            $columnDimension = $columnDimensions[$col];
            $width = $columnDimension->getWidth( );
            $pixelWidth = ( $width, $font );
        }
        else if ( $sheet->getDefaultColumnDimension( )->getWidth( ) != -1 )
        {
            $defaultColumnDimension = $sheet->getDefaultColumnDimension( );
            $width = $defaultColumnDimension->getWidth( );
            $pixelWidth = ( $width, $font );
        }
        else
        {
            $pixelWidth = ( $font, TRUE );
        }
        if ( isset( $columnDimensions[$col] ) && !$columnDimensions[$col]->getVisible( ) )
        {
            $effectivePixelWidth = 0;
            return $effectivePixelWidth;
        }
        $effectivePixelWidth = $pixelWidth;
        return $effectivePixelWidth;
    }

    public static function sizeRow( $sheet, $row = 1 )
    {
        $font = $sheet->getParent( )->getDefaultStyle( )->getFont( );
        $rowDimensions = $sheet->getRowDimensions( );
        if ( isset( $rowDimensions[$row] ) && $rowDimensions[$row]->getRowHeight( ) != -1 )
        {
            $rowDimension = $rowDimensions[$row];
            $rowHeight = $rowDimension->getRowHeight( );
            $pixelRowHeight = ( integer );
        }
        else if ( $sheet->getDefaultRowDimension( )->getRowHeight( ) != -1 )
        {
            $defaultRowDimension = $sheet->getDefaultRowDimension( );
            $rowHeight = $defaultRowDimension->getRowHeight( );
            $pixelRowHeight = ( $rowHeight );
        }
        else
        {
            $pointRowHeight = ( $font );
            $pixelRowHeight = ( $pointRowHeight );
        }
        if ( isset( $rowDimensions[$row] ) && !$rowDimensions[$row]->getVisible( ) )
        {
            $effectivePixelRowHeight = 0;
            return $effectivePixelRowHeight;
        }
        $effectivePixelRowHeight = $pixelRowHeight;
        return $effectivePixelRowHeight;
    }

    public static function getDistanceX( $sheet, $startColumn = "A", $startOffsetX = 0, $endColumn = "A", $endOffsetX = 0 )
    {
        $distanceX = 0;
        $startColumnIndex = ( $startColumn ) - 1;
        $endColumnIndex = ( $endColumn ) - 1;
        $i = $startColumnIndex;
        for ( ; $i <= $endColumnIndex; ++$i )
        {
            $distanceX += ( $sheet, ( $i ) );
        }
        $distanceX -= ( integer );
        $distanceX -= ( integer );
        return $distanceX;
    }

    public static function getDistanceY( $sheet, $startRow = 1, $startOffsetY = 0, $endRow = 1, $endOffsetY = 0 )
    {
        $distanceY = 0;
        $row = $startRow;
        for ( ; $row <= $endRow; ++$row )
        {
            $distanceY += ( $sheet, $row );
        }
        $distanceY -= ( integer );
        $distanceY -= ( integer );
        return $distanceY;
    }

    public static function oneAnchor2twoAnchor( $sheet, $coordinates, $offsetX, $offsetY, $width, $height )
    {
        list( $column, $row ) = ( $coordinates );
        $col_start = ( $column ) - 1;
        $row_start = $row - 1;
        $x1 = $offsetX;
        $y1 = $offsetY;
        $col_end = $col_start;
        $row_end = $row_start;
        if ( ( $sheet, ( $col_start ) ) <= $x1 )
        {
            $x1 = 0;
        }
        if ( ( $sheet, $row_start + 1 ) <= $y1 )
        {
            $y1 = 0;
        }
        $width = $width + $x1 - 1;
        $height = $height + $y1 - 1;
        do
        {
            if ( ( $sheet, ( $col_end ) ) <= $width )
            {
                $width -= ( $sheet, ( $col_end ) );
                ++$col_end;
            }
        } while ( 1 );
        do
        {
            if ( ( $sheet, $row_end + 1 ) <= $height )
            {
                $height -= ( $sheet, $row_end + 1 );
                ++$row_end;
            }
        } while ( 1 );
        if ( ( $sheet, ( $col_start ) ) == 0 )
        {
        }
        else
        {
            if ( ( $sheet, ( $col_end ) ) == 0 )
            {
            }
            else
            {
                if ( ( $sheet, $row_start + 1 ) == 0 )
                {
                }
                else
                {
                    if ( ( $sheet, $row_end + 1 ) == 0 )
                    {
                    }
                    else
                    {
                        $x1 = $x1 / ( $sheet, ( $col_start ) ) * 1024;
                        $y1 = $y1 / ( $sheet, $row_start + 1 ) * 256;
                        $x2 = ( $width + 1 ) / ( $sheet, ( $col_end ) ) * 1024;
                        $y2 = ( $height + 1 ) / ( $sheet, $row_end + 1 ) * 256;
                        $startCoordinates = ( $col_start ).( $row_start + 1 );
                        $endCoordinates = ( $col_end ).( $row_end + 1 );
                        $twoAnchor = array( "startCoordinates" => $startCoordinates, "startOffsetX" => $x1, "startOffsetY" => $y1, "endCoordinates" => $endCoordinates, "endOffsetX" => $x2, "endOffsetY" => $y2 );
                        return $twoAnchor;
                    }
                }
            }
        }
    }

}

?>
