<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class PHPExcel_Shared_OLE_ChainedBlockStream
{

    public $ole;
    public $params;
    public $data;
    public $pos;

    public function stream_open( $path, $mode, $options, &$openedPath )
    {
        if ( $mode != "r" )
        {
            if ( $options & STREAM_REPORT_ERRORS )
            {
                trigger_error( "Only reading is supported", E_USER_WARNING );
            }
            return FALSE;
        }
        parse_str( substr( $path, 25 ), &$this->params );
        if ( [$this->params['oleInstanceId']]isset( $this->params['oleInstanceId'], $this->params['blockId'], $GLOBALS['_OLE_INSTANCES'] ) )
        {
            if ( $options & STREAM_REPORT_ERRORS )
            {
                trigger_error( "OLE stream not found", E_USER_WARNING );
            }
            return FALSE;
        }
        $this->ole = $GLOBALS['_OLE_INSTANCES'][$this->params['oleInstanceId']];
        $blockId = $this->params['blockId'];
        $this->data = "";
        if ( !isset( $this->params['size'] ) || !( $this->params['size'] < $this->ole->bigBlockThreshold ) || !( $blockId != $this->ole->root->_StartBlock ) )
        {
            $rootPos = $this->ole->root( $this->ole->root->_StartBlock );
            while ( $blockId != -2 )
            {
                $pos = $rootPos + $blockId * $this->ole->bigBlockSize;
                $blockId = $this->ole->sbat[$blockId];
                fseek( $this->ole->_file_handle, $pos );
                $ && _737130496 .= "data";
            }
        }
        while ( $blockId != -2 )
        {
            $pos = $this->ole->_getBlockOffset( $blockId );
            fseek( $this->ole->_file_handle, $pos );
            $ && _735472488 .= "data";
            $blockId = $this->ole->bbat[$blockId];
        }
        if ( isset( $this->params['size'] ) )
        {
            $this->data = substr( $this->data, 0, $this->params['size'] );
        }
        if ( $options & STREAM_USE_PATH )
        {
            $openedPath = $path;
        }
        return TRUE;
    }

    public function stream_close( )
    {
        $this->ole = NULL;
        unset( $GLOBALS['_OLE_INSTANCES'] );
    }

    public function stream_read( $count )
    {
        if ( $this->stream_eof( ) )
        {
            return FALSE;
        }
        $s = substr( $this->data, $this->pos, $count );
        $ && _723947280 += "pos";
        return $s;
    }

    public function stream_eof( )
    {
        $eof = strlen( $this->data ) <= $this->pos;
        if ( version_compare( PHP_VERSION, "5.0", ">=" ) && version_compare( PHP_VERSION, "5.1", "<" ) )
        {
            $eof = !$eof;
        }
        return $eof;
    }

    public function stream_tell( )
    {
        return $this->pos;
    }

    public function stream_seek( $offset, $whence )
    {
        if ( $whence == SEEK_SET && 0 <= $offset )
        {
            $this->pos = $offset;
            return TRUE;
        }
        if ( $whence == SEEK_CUR && 0 - $offset <= $this->pos )
        {
            $ && _739176936 += "pos";
            return TRUE;
        }
        if ( $whence == SEEK_END && 0 - $offset <= sizeof( $this->data ) )
        {
            $this->pos = strlen( $this->data ) + $offset;
            return TRUE;
        }
        return FALSE;
    }

    public function stream_stat( )
    {
        return array( "size" => strlen( $this->data ) );
    }

}

?>
