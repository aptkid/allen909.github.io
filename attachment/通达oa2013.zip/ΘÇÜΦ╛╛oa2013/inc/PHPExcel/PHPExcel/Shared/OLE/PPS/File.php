<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class PHPExcel_Shared_OLE_PPS_File extends PHPExcel_Shared_OLE_PPS
{

    public function __construct( $name )
    {
        ( NULL, $name, PHPExcel_Shared_OLE::OLE_PPS_TYPE_FILE, NULL, NULL, NULL, NULL, NULL, "", array( ) );
    }

    public function init( )
    {
        return TRUE;
    }

    public function append( $data )
    {
        $ && _514799608 .= "_data";
    }

    public function getStream( )
    {
        $this->ole->getStream( $this );
    }

}

?>
