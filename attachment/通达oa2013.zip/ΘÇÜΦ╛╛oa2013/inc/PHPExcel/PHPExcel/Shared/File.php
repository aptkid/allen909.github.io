<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class PHPExcel_Shared_File
{

    protected static $_useUploadTempDirectory = FALSE;

    public static function setUseUploadTempDirectory( $useUploadTempDir = FALSE )
    {
        self::$_useUploadTempDirectory = $useUploadTempDir;
    }

    public static function getUseUploadTempDirectory( )
    {
        return self::$_useUploadTempDirectory;
    }

    public static function file_exists( $pFilename )
    {
        if ( strtolower( substr( $pFilename, 0, 3 ) ) == "zip" )
        {
            $zipFile = substr( $pFilename, 6, strpos( $pFilename, "#" ) - 6 );
            $archiveFile = substr( $pFilename, strpos( $pFilename, "#" ) + 1 );
            $zip = new ZipArchive( );
            if ( $zip->open( $zipFile ) === TRUE )
            {
                $returnValue = $zip->getFromName( $archiveFile ) !== FALSE;
                $zip->close( );
                return $returnValue;
            }
            return FALSE;
        }
        return file_exists( $pFilename );
    }

    public static function realpath( $pFilename )
    {
        $returnValue = "";
        if ( file_exists( $pFilename ) )
        {
            $returnValue = realpath( $pFilename );
        }
        if ( $returnValue == "" || $returnValue === NULL )
        {
            $pathArray = explode( "/", $pFilename );
            while ( !in_array( "..", $pathArray ) || !( $pathArray[0] != ".." ) )
            {
                $i = 0;
                for ( ; do
 {
 $i < count( $pathArray ); do
 {
 ++$i, } while ( 1 ) )
                    {
                    } while ( !( $pathArray[$i] == ".." ) || !( 0 < $i ) );
                    unset( $pathArray[$i] );
                    unset( $pathArray[$i - 1] );
                }
            }
            $returnValue = implode( "/", $pathArray );
        }
        return $returnValue;
    }

    public static function sys_get_temp_dir( )
    {
        if ( self::$_useUploadTempDirectory && ini_get( "upload_tmp_dir" ) !== FALSE && ( $temp = ini_get( "upload_tmp_dir" ) ) && file_exists( $temp ) )
        {
            return realpath( $temp );
        }
        if ( function_exists( "sys_get_temp_dir" ) )
        {
            if ( ( $temp = getenv( "TMP" ) ) && !empty( $temp ) && file_exists( $temp ) )
            {
                return realpath( $temp );
            }
            if ( ( $temp = getenv( "TEMP" ) ) && !empty( $temp ) && file_exists( $temp ) )
            {
                return realpath( $temp );
            }
            if ( ( $temp = getenv( "TMPDIR" ) ) && !empty( $temp ) && file_exists( $temp ) )
            {
                return realpath( $temp );
            }
            $temp = tempnam( __FILE__, "" );
            if ( file_exists( $temp ) )
            {
                unlink( $temp );
                return realpath( dirname( $temp ) );
            }
        }
        else
        {
            return realpath( sys_get_temp_dir( ) );
        }
    }

}

?>
