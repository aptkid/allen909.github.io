<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class PHPExcel_Shared_TimeZone
{

    protected static $_timezone = "UTC";

    public static function _validateTimeZone( $timezone )
    {
        if ( in_array( $timezone, ( ) ) )
        {
            return TRUE;
        }
        return FALSE;
    }

    public static function setTimeZone( $timezone )
    {
        if ( ( $timezone ) )
        {
            self::$_timezone = $timezone;
            return TRUE;
        }
        return FALSE;
    }

    public static function getTimeZone( )
    {
        return self::$_timezone;
    }

    private static function _getTimezoneTransitions( $objTimezone, $timestamp )
    {
        $allTransitions = $objTimezone->getTransitions( );
        $transitions = array( );
        foreach ( $allTransitions as $key => $transition )
        {
            if ( $timestamp < $transition['ts'] )
            {
                $transitions[] = 0 < $key ? $allTransitions[$key - 1] : $transition;
            }
            else if ( empty( $transitions ) )
            {
                $transitions[] = end( &$allTransitions );
            }
        }
        return $transitions;
    }

    public static function getTimeZoneAdjustment( $timezone, $timestamp )
    {
        if ( $timezone !== NULL )
        {
            if ( ( $timezone ) )
            {
                throw new PHPExcel_Exception( "Invalid timezone ".$timezone );
            }
        }
        $timezone = self::$_timezone;
        if ( $timezone == "UST" )
        {
            return 0;
        }
        $objTimezone = new DateTimeZone( $timezone );
        if ( 0 <= version_compare( PHP_VERSION, "5.3.0" ) )
        {
            $transitions = $objTimezone->getTransitions( $timestamp, $timestamp );
        }
        else
        {
            $transitions = ( $objTimezone, $timestamp );
        }
        if ( 0 < count( $transitions ) )
        {
            return $transitions[0]['offset'];
        }
        return 0;
    }

}

?>
