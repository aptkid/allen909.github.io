<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class PHPExcel_Worksheet implements PHPExcel_IComparable
{

    private static $_invalidCharacters = array( "*", ":", "/", "\\", "?", "[", "]" );
    private $_parent;
    private $_cellCollection;
    private $_rowDimensions = array( );
    private $_defaultRowDimension;
    private $_columnDimensions = array( );
    private $_defaultColumnDimension;
    private $_drawingCollection;
    private $_chartCollection = array( );
    private $_title;
    private $_sheetState;
    private $_pageSetup;
    private $_pageMargins;
    private $_headerFooter;
    private $_sheetView;
    private $_protection;
    private $_styles = array( );
    private $_conditionalStylesCollection = array( );
    private $_cellCollectionIsSorted = FALSE;
    private $_breaks = array( );
    private $_mergeCells = array( );
    private $_protectedCells = array( );
    private $_autoFilter;
    private $_freezePane = "";
    private $_showGridlines = TRUE;
    private $_printGridlines = FALSE;
    private $_showRowColHeaders = TRUE;
    private $_showSummaryBelow = TRUE;
    private $_showSummaryRight = TRUE;
    private $_comments = array( );
    private $_activeCell = "A1";
    private $_selectedCells = "A1";
    private $_cachedHighestColumn = "A";
    private $_b_fixed_cachedHighestColumn = FALSE;
    private $_cachedHighestRow = 1;
    private $_b_fixed_cachedHighestRow = FALSE;
    private $_rightToLeft = FALSE;
    private $_hyperlinkCollection = array( );
    private $_dataValidationCollection = array( );
    private $_tabColor;
    private $_dirty = TRUE;
    private $_hash;

    const BREAK_NONE = 0;
    const BREAK_ROW = 1;
    const BREAK_COLUMN = 2;
    const SHEETSTATE_VISIBLE = "visible";
    const SHEETSTATE_HIDDEN = "hidden";
    const SHEETSTATE_VERYHIDDEN = "veryHidden";

    public function __construct( $pParent = NULL, $pTitle = "Worksheet" )
    {
        $this->_parent = $pParent;
        $this->setTitle( $pTitle, FALSE );
        $this->setSheetState( PHPExcel_Worksheet::SHEETSTATE_VISIBLE );
        $this->_cellCollection = ( $this );
        $this->_pageSetup = new PHPExcel_Worksheet_PageSetup( );
        $this->_pageMargins = new PHPExcel_Worksheet_PageMargins( );
        $this->_headerFooter = new PHPExcel_Worksheet_HeaderFooter( );
        $this->_sheetView = new PHPExcel_Worksheet_SheetView( );
        $this->_drawingCollection = new ArrayObject( );
        $this->_chartCollection = new ArrayObject( );
        $this->_protection = new PHPExcel_Worksheet_Protection( );
        $this->_defaultRowDimension = new PHPExcel_Worksheet_RowDimension( NULL );
        $this->_defaultColumnDimension = new PHPExcel_Worksheet_ColumnDimension( NULL );
        $this->_autoFilter = new PHPExcel_Worksheet_AutoFilter( NULL, $this );
    }

    public function disconnectCells( )
    {
        if ( $this->_cellCollection !== NULL )
        {
            $this->_cellCollection->unsetWorksheetCells( );
            $this->_cellCollection = NULL;
        }
        $this->_parent = NULL;
    }

    public function __destruct( )
    {
        ( $this->_parent )->clearCalculationCacheForWorksheet( $this->_title );
        $this->disconnectCells( );
    }

    public function getCellCacheController( )
    {
        return $this->_cellCollection;
    }

    public static function getInvalidCharacters( )
    {
        return self::$_invalidCharacters;
    }

    private static function _checkSheetTitle( $pValue )
    {
        if ( str_replace( self::$_invalidCharacters, "", $pValue ) !== $pValue )
        {
            throw new PHPExcel_Exception( "Invalid character found in sheet title" );
        }
        if ( 31 < ( $pValue ) )
        {
            throw new PHPExcel_Exception( "Maximum 31 characters allowed in sheet title." );
        }
        return $pValue;
    }

    public function getCellCollection( $pSorted = TRUE )
    {
        if ( $pSorted )
        {
            return $this->sortCellCollection( );
        }
        if ( $this->_cellCollection !== NULL )
        {
            return $this->_cellCollection->getCellList( );
        }
        return array( );
    }

    public function sortCellCollection( )
    {
        if ( $this->_cellCollection !== NULL )
        {
            return $this->_cellCollection->getSortedCellList( );
        }
        return array( );
    }

    public function getRowDimensions( )
    {
        return $this->_rowDimensions;
    }

    public function getDefaultRowDimension( )
    {
        return $this->_defaultRowDimension;
    }

    public function getColumnDimensions( )
    {
        return $this->_columnDimensions;
    }

    public function getDefaultColumnDimension( )
    {
        return $this->_defaultColumnDimension;
    }

    public function getDrawingCollection( )
    {
        return $this->_drawingCollection;
    }

    public function getChartCollection( )
    {
        return $this->_chartCollection;
    }

    public function addChart( $pChart = NULL, $iChartIndex = NULL )
    {
        $this( $this );
        if ( is_null( $iChartIndex ) )
        {
            $this->_chartCollection[] = $pChart;
            return $pChart;
        }
        array_splice( &$this->_chartCollection, $iChartIndex, 0, array( $pChart ) );
        return $pChart;
    }

    public function getChartCount( )
    {
        return count( $this->_chartCollection );
    }

    public function getChartByIndex( $index = NULL )
    {
        $chartCount = count( $this->_chartCollection );
        if ( $chartCount == 0 )
        {
            return FALSE;
        }
        if ( is_null( $index ) )
        {
            $index = --$chartCount;
        }
        if ( isset( $this->_chartCollection[$index] ) )
        {
            return FALSE;
        }
        return $this->_chartCollection[$index];
    }

    public function getChartNames( )
    {
        $chartNames = array( );
        foreach ( $this->_chartCollection as $chart )
        {
            $chartNames[] = $chart->getName( );
        }
        return $chartNames;
    }

    public function getChartByName( $chartName = "" )
    {
        $chartCount = count( $this->_chartCollection );
        if ( $chartCount == 0 )
        {
            return FALSE;
        }
        foreach ( $this->_chartCollection as $index => $chart )
        {
            if ( $chart->getName( ) == $chartName )
            {
                return $this->_chartCollection[$index];
                break;
            }
        }
        return FALSE;
    }

    public function refreshColumnDimensions( )
    {
        $currentColumnDimensions = $this->getColumnDimensions( );
        $newColumnDimensions = array( );
        foreach ( $currentColumnDimensions as $objColumnDimension )
        {
            $newColumnDimensions[$objColumnDimension->getColumnIndex( )] = $objColumnDimension;
        }
        $this->_columnDimensions = $newColumnDimensions;
        return $this;
    }

    public function refreshRowDimensions( )
    {
        $currentRowDimensions = $this->getRowDimensions( );
        $newRowDimensions = array( );
        foreach ( $currentRowDimensions as $objRowDimension )
        {
            $newRowDimensions[$objRowDimension->getRowIndex( )] = $objRowDimension;
        }
        $this->_rowDimensions = $newRowDimensions;
        return $this;
    }

    public function calculateWorksheetDimension( )
    {
        return "A1:".$this->getHighestColumn( ).$this->getHighestRow( );
    }

    public function calculateWorksheetDataDimension( )
    {
        return "A1:".$this->getHighestDataColumn( ).$this->getHighestDataRow( );
    }

    public function calculateColumnWidths( $calculateMergeCells = FALSE )
    {
        $autoSizes = array( );
        foreach ( $this->getColumnDimensions( ) as $colDimension )
        {
            if ( $colDimension->getAutoSize( ) )
            {
                $autoSizes[$colDimension->getColumnIndex( )] = -1;
            }
        }
        if ( empty( $autoSizes ) )
        {
            $isMergeCell = array( );
            foreach ( $this->getMergeCells( ) as $cells )
            {
                foreach ( ( $cells ) as $cellReference )
                {
                    $isMergeCell[$cellReference] = TRUE;
                }
            }
            foreach ( $this->getCellCollection( FALSE ) as $cellID )
            {
                $cell = $this->getCell( $cellID );
                if ( !isset( $autoSizes[$this->_cellCollection->getCurrentColumn( )] ) || isset( $isMergeCell[$this->_cellCollection->getCurrentAddress( )] ) )
                {
                    $cellValue = ( $cell->getCalculatedValue( ), $this->getParent( )->getCellXfByIndex( $cell->getXfIndex( ) )->getNumberFormat( )->getFormatCode( ) );
                    $autoSizes[$this->_cellCollection->getCurrentColumn( )] = max( ( double ), ( double ) );
                }
            }
            foreach ( $autoSizes as $columnIndex => $width )
            {
                if ( $width == -1 )
                {
                    $width = $this->getDefaultColumnDimension( )->getWidth( );
                }
                $this->getColumnDimension( $columnIndex )->setWidth( $width );
            }
        }
        return $this;
    }

    public function getParent( )
    {
        return $this->_parent;
    }

    public function rebindParent( $parent )
    {
        $namedRanges = $this->_parent->getNamedRanges( );
        foreach ( $namedRanges as $namedRange )
        {
            $parent->addNamedRange( $namedRange );
        }
        $this->_parent->removeSheetByIndex( $this->_parent->getIndex( $this ) );
        $this->_parent = $parent;
        return $this;
    }

    public function getTitle( )
    {
        return $this->_title;
    }

    public function setTitle( $pValue = "Worksheet", $updateFormulaCellReferences = TRUE )
    {
        if ( $this->getTitle( ) == $pValue )
        {
            return $this;
        }
        ( $pValue );
        $oldTitle = $this->getTitle( );
        if ( $this->_parent && $this->_parent->sheetNameExists( $pValue ) )
        {
            if ( 29 < ( $pValue ) )
            {
                $pValue = ( $pValue, 0, 29 );
            }
            $i = 1;
            while ( $this->_parent->sheetNameExists( $pValue." ".$i ) )
            {
                ++$i;
                if ( $i == 10 )
                {
                    if ( 28 < ( $pValue ) )
                    {
                        $pValue = ( $pValue, 0, 28 );
                    }
                }
                else if ( !( $i == 100 ) || !( 27 < ( $pValue ) ) )
                {
                    $pValue = ( $pValue, 0, 27 );
                }
            }
            $altTitle = $pValue." ".$i;
            return $this->setTitle( $altTitle, $updateFormulaCellReferences );
        }
        $this->_title = $pValue;
        $this->_dirty = TRUE;
        if ( $this->_parent )
        {
            $newTitle = $this->getTitle( );
            ( $this->_parent )->renameCalculationCacheForWorksheet( $oldTitle, $newTitle );
            if ( $updateFormulaCellReferences )
            {
                ( )->updateNamedFormulas( $this->_parent, $oldTitle, $newTitle );
            }
        }
        return $this;
    }

    public function getSheetState( )
    {
        return $this->_sheetState;
    }

    public function setSheetState( $value = PHPExcel_Worksheet::SHEETSTATE_VISIBLE )
    {
        $this->_sheetState = $value;
        return $this;
    }

    public function getPageSetup( )
    {
        return $this->_pageSetup;
    }

    public function setPageSetup( $pValue )
    {
        $this->_pageSetup = $pValue;
        return $this;
    }

    public function getPageMargins( )
    {
        return $this->_pageMargins;
    }

    public function setPageMargins( $pValue )
    {
        $this->_pageMargins = $pValue;
        return $this;
    }

    public function getHeaderFooter( )
    {
        return $this->_headerFooter;
    }

    public function setHeaderFooter( $pValue )
    {
        $this->_headerFooter = $pValue;
        return $this;
    }

    public function getSheetView( )
    {
        return $this->_sheetView;
    }

    public function setSheetView( $pValue )
    {
        $this->_sheetView = $pValue;
        return $this;
    }

    public function getProtection( )
    {
        return $this->_protection;
    }

    public function setProtection( $pValue )
    {
        $this->_protection = $pValue;
        $this->_dirty = TRUE;
        return $this;
    }

    public function getHighestColumn( )
    {
        if ( $this->_b_fixed_cachedHighestColumn )
        {
            $this->_b_fixed_cachedHighestColumn = TRUE;
            $i_max_col = ( $this->_cachedHighestColumn );
            while ( !( 1 < $i_max_col ) || 0 < $this->_parent->i_max_col && $i_max_col <= $this->_parent->i_max_col )
            {
                $b_blank = TRUE;
                $i = 1;
                for ( ; $i <= $this->_cachedHighestRow; ++$i )
                {
                    if ( $this->cellExistsByColumnAndRow( $i_max_col - 1, $i ) )
                    {
                        $obj_cell = $this->getCellByColumnAndRow( $i_max_col - 1, $i );
                        if ( $obj_cell->getValue( ) != "" )
                        {
                            $b_blank = FALSE;
                        }
                    }
                }
                if ( $b_blank )
                {
                    --$i_max_col;
                }
            }
            $this->_cachedHighestColumn = ( $i_max_col );
        }
        return $this->_cachedHighestColumn;
    }

    public function getHighestDataColumn( )
    {
        return $this->_cellCollection->getHighestColumn( );
    }

    public function getHighestRow( )
    {
        if ( $this->_b_fixed_cachedHighestRow )
        {
            $this->_b_fixed_cachedHighestRow = TRUE;
            $i_max_col = ( $this->_cachedHighestColumn );
            while ( !( 1 < $this->_cachedHighestRow ) || 0 < $this->_parent->i_max_row && $this->_cachedHighestRow <= $this->_parent->i_max_row )
            {
                $b_blank = TRUE;
                $i = 0;
                for ( ; $i < $i_max_col; ++$i )
                {
                    if ( $this->_cachedHighestRow( $i, $this->_cachedHighestRow ) )
                    {
                        $obj_cell = $this->_cachedHighestRow( $i, $this->_cachedHighestRow );
                        if ( $obj_cell->getValue( ) != "" )
                        {
                            $b_blank = FALSE;
                        }
                    }
                }
                if ( $b_blank )
                {
                    $this->_cachedHighestRow--;
                }
            }
        }
        return $this->_cachedHighestRow;
    }

    public function getHighestDataRow( )
    {
        return $this->_cellCollection->getHighestRow( );
    }

    public function getHighestRowAndColumn( )
    {
        return $this->_cellCollection->getHighestRowAndColumn( );
    }

    public function setCellValue( $pCoordinate = "A1", $pValue = NULL, $returnCell = FALSE )
    {
        $cell = $this->getCell( $pCoordinate )->setValue( $pValue );
        if ( $returnCell )
        {
            return $cell;
        }
        return $this;
    }

    public function setCellValueByColumnAndRow( $pColumn = 0, $pRow = 1, $pValue = NULL, $returnCell = FALSE )
    {
        $cell = $this->getCell( ( $pColumn ).$pRow )->setValue( $pValue );
        if ( $returnCell )
        {
            return $cell;
        }
        return $this;
    }

    public function setCellValueExplicit( $pCoordinate = "A1", $pValue = NULL, $pDataType = PHPExcel_Cell_DataType::TYPE_STRING, $returnCell = FALSE )
    {
        $cell = $this->getCell( $pCoordinate )->setValueExplicit( $pValue, $pDataType );
        if ( $returnCell )
        {
            return $cell;
        }
        return $this;
    }

    public function setCellValueExplicitByColumnAndRow( $pColumn = 0, $pRow = 1, $pValue = NULL, $pDataType = PHPExcel_Cell_DataType::TYPE_STRING, $returnCell = FALSE )
    {
        $cell = $this->getCell( ( $pColumn ).$pRow )->setValueExplicit( $pValue, $pDataType );
        if ( $returnCell )
        {
            return $cell;
        }
        return $this;
    }

    public function getCell( $pCoordinate = "A1" )
    {
        if ( $this->_cellCollection->isDataSet( $pCoordinate ) )
        {
            return $this->_cellCollection->getCacheData( $pCoordinate );
        }
        if ( strpos( $pCoordinate, "!" ) !== FALSE )
        {
            $worksheetReference = ( $pCoordinate, TRUE );
            return $this->_parent->getSheetByName( $worksheetReference[0] )->getCell( $worksheetReference[1] );
        }
        if ( !preg_match( "/^".PHPExcel_Calculation::CALCULATION_REGEXP_CELLREF."$/i", $pCoordinate, $matches ) && preg_match( "/^".PHPExcel_Calculation::CALCULATION_REGEXP_NAMEDRANGE."$/i", $pCoordinate, $matches ) )
        {
            $namedRange = ( $pCoordinate, $this );
            if ( $namedRange !== NULL )
            {
                $pCoordinate = $namedRange->getRange( );
                return $namedRange->getWorksheet( )->getCell( $pCoordinate );
            }
        }
        $pCoordinate = strtoupper( $pCoordinate );
        if ( strpos( $pCoordinate, ":" ) !== FALSE || strpos( $pCoordinate, "," ) !== FALSE )
        {
            throw new PHPExcel_Exception( "Cell coordinate can not be a range of cells." );
        }
        if ( strpos( $pCoordinate, "\$" ) !== FALSE )
        {
            throw new PHPExcel_Exception( "Cell coordinate must not be absolute." );
        }
        $aCoordinates = ( $pCoordinate );
        $cell = $this( $pCoordinate, new PHPExcel_Cell( NULL, PHPExcel_Cell_DataType::TYPE_NULL, $this ) );
        $this->_cellCollectionIsSorted = FALSE;
        if ( ( $this->_cachedHighestColumn ) < ( $aCoordinates[0] ) )
        {
            $this->_cachedHighestColumn = $aCoordinates[0];
        }
        $this->_cachedHighestRow = max( $this->_cachedHighestRow, $aCoordinates[1] );
        $rowDimensions = $this->getRowDimensions( );
        $columnDimensions = $this->getColumnDimensions( );
        if ( isset( $rowDimensions[$aCoordinates[1]] ) && $rowDimensions[$aCoordinates[1]]->getXfIndex( ) !== NULL )
        {
            $rowDimensions[$aCoordinates[1]]->getXfIndex( )( $rowDimensions[$aCoordinates[1]]->getXfIndex( ) );
            return $cell;
        }
        if ( isset( $columnDimensions[$aCoordinates[0]] ) )
        {
            $columnDimensions[$aCoordinates[0]]->getXfIndex( )( $columnDimensions[$aCoordinates[0]]->getXfIndex( ) );
            return $cell;
        }
        $cell->setXfIndex( 0 );
        return $cell;
    }

    public function getCellByColumnAndRow( $pColumn = 0, $pRow = 1 )
    {
        $columnLetter = ( $pColumn );
        $coordinate = $columnLetter.$pRow;
        if ( $this->_cellCollection->isDataSet( $coordinate ) )
        {
            $cell = $this( $coordinate, new PHPExcel_Cell( NULL, PHPExcel_Cell_DataType::TYPE_NULL, $this ) );
            $this->_cellCollectionIsSorted = FALSE;
            if ( ( $this->_cachedHighestColumn ) < $pColumn )
            {
                $this->_cachedHighestColumn = $columnLetter;
            }
            $this->_cachedHighestRow = max( $this->_cachedHighestRow, $pRow );
            return $cell;
        }
        return $this->_cellCollection->getCacheData( $coordinate );
    }

    public function cellExists( $pCoordinate = "A1" )
    {
        if ( strpos( $pCoordinate, "!" ) !== FALSE )
        {
            $worksheetReference = ( $pCoordinate, TRUE );
            return $this->_parent->getSheetByName( $worksheetReference[0] )->cellExists( $worksheetReference[1] );
        }
        if ( !preg_match( "/^".PHPExcel_Calculation::CALCULATION_REGEXP_CELLREF."$/i", $pCoordinate, $matches ) && preg_match( "/^".PHPExcel_Calculation::CALCULATION_REGEXP_NAMEDRANGE."$/i", $pCoordinate, $matches ) )
        {
            $namedRange = ( $pCoordinate, $this );
            if ( $namedRange !== NULL )
            {
                $pCoordinate = $namedRange->getRange( );
                if ( $this->getHashCode( ) != $namedRange->getWorksheet( )->getHashCode( ) )
                {
                    if ( $namedRange->getLocalOnly( ) )
                    {
                        return $namedRange->getWorksheet( )->cellExists( $pCoordinate );
                    }
                    throw new PHPExcel_Exception( "Named range ".$namedRange->getName( )." is not accessible from within sheet ".$this->getTitle( ) );
                }
            }
            return FALSE;
        }
        $pCoordinate = strtoupper( $pCoordinate );
        if ( strpos( $pCoordinate, ":" ) !== FALSE || strpos( $pCoordinate, "," ) !== FALSE )
        {
            throw new PHPExcel_Exception( "Cell coordinate can not be a range of cells." );
        }
        if ( strpos( $pCoordinate, "\$" ) !== FALSE )
        {
            throw new PHPExcel_Exception( "Cell coordinate must not be absolute." );
        }
        $aCoordinates = ( $pCoordinate );
        return $this->_cellCollection->isDataSet( $pCoordinate );
    }

    public function cellExistsByColumnAndRow( $pColumn = 0, $pRow = 1 )
    {
        return $this->cellExists( ( $pColumn ).$pRow );
    }

    public function getRowDimension( $pRow = 1 )
    {
        $found = NULL;
        if ( isset( $this->_rowDimensions[$pRow] ) )
        {
            $this->_rowDimensions[$pRow] = new PHPExcel_Worksheet_RowDimension( $pRow );
            $this->_cachedHighestRow = max( $this->_cachedHighestRow, $pRow );
        }
        return $this->_rowDimensions[$pRow];
    }

    public function getColumnDimension( $pColumn = "A" )
    {
        $pColumn = strtoupper( $pColumn );
        if ( isset( $this->_columnDimensions[$pColumn] ) )
        {
            $this->_columnDimensions[$pColumn] = new PHPExcel_Worksheet_ColumnDimension( $pColumn );
            if ( ( $this->_cachedHighestColumn ) < ( $pColumn ) )
            {
                $this->_cachedHighestColumn = $pColumn;
            }
        }
        return $this->_columnDimensions[$pColumn];
    }

    public function getColumnDimensionByColumn( $pColumn = 0 )
    {
        return ( $pColumn )( ( $pColumn ) );
    }

    public function getStyles( )
    {
        return $this->_styles;
    }

    public function getDefaultStyle( )
    {
        return $this->_parent->getDefaultStyle( );
    }

    public function setDefaultStyle( $pValue )
    {
        $this->_parent->getDefaultStyle( )->applyFromArray( array( "font" => array( "name" => $pValue->getFont( )->getName( ), "size" => $pValue->getFont( )->getSize( ) ) ) );
        return $this;
    }

    public function getStyle( $pCellCoordinate = "A1" )
    {
        $this->_parent->setActiveSheetIndex( $this->_parent->getIndex( $this ) );
        $this->setSelectedCells( $pCellCoordinate );
        return $this->_parent->getCellXfSupervisor( );
    }

    public function getConditionalStyles( $pCoordinate = "A1" )
    {
        if ( isset( $this->_conditionalStylesCollection[$pCoordinate] ) )
        {
            $this->_conditionalStylesCollection[$pCoordinate] = array( );
        }
        return $this->_conditionalStylesCollection[$pCoordinate];
    }

    public function conditionalStylesExists( $pCoordinate = "A1" )
    {
        if ( isset( $this->_conditionalStylesCollection[$pCoordinate] ) )
        {
            return TRUE;
        }
        return FALSE;
    }

    public function removeConditionalStyles( $pCoordinate = "A1" )
    {
        unset( $Var_0[$pCoordinate] );
        return $this;
    }

    public function getConditionalStylesCollection( )
    {
        return $this->_conditionalStylesCollection;
    }

    public function setConditionalStyles( $pCoordinate = "A1", $pValue )
    {
        $this->_conditionalStylesCollection[$pCoordinate] = $pValue;
        return $this;
    }

    public function getStyleByColumnAndRow( $pColumn = 0, $pRow = 1 )
    {
        return $this->getStyle( ( $pColumn ).$pRow );
    }

    public function setSharedStyle( $pSharedCellStyle = NULL, $pRange = "" )
    {
        $this->duplicateStyle( $pSharedCellStyle, $pRange );
        return $this;
    }

    public function duplicateStyle( $pCellStyle = NULL, $pRange = "" )
    {
        $style = $pCellStyle->getIsSupervisor( ) ? $pCellStyle->getSharedComponent( ) : $pCellStyle;
        $workbook = $this->_parent;
        if ( $this->_parent->cellXfExists( $pCellStyle ) )
        {
            $xfIndex = $pCellStyle->getIndex( );
        }
        else
        {
            $workbook->addCellXf( $pCellStyle );
            $xfIndex = $pCellStyle->getIndex( );
        }
        $pRange = strtoupper( $pRange );
        $rangeA = "";
        $rangeB = "";
        if ( strpos( $pRange, ":" ) === FALSE )
        {
            $rangeA = $pRange;
            $rangeB = $pRange;
        }
        else
        {
            $rangeB = explode( ":", $pRange )[1];
            $rangeA = explode( ":", $pRange )[0];
        }
        $rangeStart = ( $rangeA );
        $rangeEnd = ( $rangeB );
        $rangeStart[0] = ( $rangeStart[0] ) - 1;
        $rangeEnd[0] = ( $rangeEnd[0] ) - 1;
        if ( $rangeEnd[0] < $rangeStart[0] && $rangeEnd[1] < $rangeStart[1] )
        {
            $tmp = $rangeStart;
            $rangeStart = $rangeEnd;
            $rangeEnd = $tmp;
        }
        $col = $rangeStart[0];
        for ( ; $col <= $rangeEnd[0]; ++$col )
        {
            $row = $rangeStart[1];
            for ( ; $row <= $rangeEnd[1]; ++$row )
            {
                $this->getCell( ( $col ).$row )->setXfIndex( $xfIndex );
            }
        }
        return $this;
    }

    public function duplicateConditionalStyle( $pCellStyle = NULL, $pRange = "" )
    {
        foreach ( $pCellStyle as $cellStyle )
        {
            if ( $cellStyle instanceof PHPExcel_Style_Conditional )
            {
                throw new PHPExcel_Exception( "Style is not a conditional style" );
                break;
            }
        }
        $pRange = strtoupper( $pRange );
        $rangeA = "";
        $rangeB = "";
        if ( strpos( $pRange, ":" ) === FALSE )
        {
            $rangeA = $pRange;
            $rangeB = $pRange;
        }
        else
        {
            list( $rangeA, $rangeB ) = explode( ":", $pRange );
        }
        $rangeStart = ( $rangeA );
        $rangeEnd = ( $rangeB );
        $rangeStart[0] = ( $rangeStart[0] ) - 1;
        $rangeEnd[0] = ( $rangeEnd[0] ) - 1;
        if ( $rangeEnd[0] < $rangeStart[0] && $rangeEnd[1] < $rangeStart[1] )
        {
            $tmp = $rangeStart;
            $rangeStart = $rangeEnd;
            $rangeEnd = $tmp;
        }
        $col = $rangeStart[0];
        for ( ; $col <= $rangeEnd[0]; ++$col )
        {
            $row = $rangeStart[1];
            for ( ; $row <= $rangeEnd[1]; ++$row )
            {
                $this->setConditionalStyles( ( $col ).$row, $pCellStyle );
            }
        }
        return $this;
    }

    public function duplicateStyleArray( $pStyles = NULL, $pRange = "", $pAdvanced = TRUE )
    {
        $this->getStyle( $pRange )->applyFromArray( $pStyles, $pAdvanced );
        return $this;
    }

    public function setBreak( $pCell = "A1", $pBreak = PHPExcel_Worksheet::BREAK_NONE )
    {
        $pCell = strtoupper( $pCell );
        if ( $pCell != "" )
        {
            if ( $pBreak == PHPExcel_Worksheet::BREAK_NONE )
            {
                if ( isset( $this->_breaks[$pCell] ) )
                {
                    unset( strtoupper( $pCell )[$pCell] );
                }
            }
            else
            {
                $this->_breaks[$pCell] = $pBreak;
            }
        }
        else
        {
            throw new PHPExcel_Exception( "No cell coordinate specified." );
        }
        return $this;
    }

    public function setBreakByColumnAndRow( $pColumn = 0, $pRow = 1, $pBreak = PHPExcel_Worksheet::BREAK_NONE )
    {
        return $this->setBreak( ( $pColumn ).$pRow, $pBreak );
    }

    public function getBreaks( )
    {
        return $this->_breaks;
    }

    public function mergeCells( $pRange = "A1:A1" )
    {
        $pRange = strtoupper( $pRange );
        if ( strpos( $pRange, ":" ) !== FALSE )
        {
            $this->_mergeCells[$pRange] = $pRange;
            $aReferences = ( $pRange );
            $upperLeft = $aReferences[0];
            if ( $this->cellExists( $upperLeft ) )
            {
                $this->getCell( $upperLeft )->setValueExplicit( NULL, PHPExcel_Cell_DataType::TYPE_NULL );
            }
            $count = count( $aReferences );
            $i = 1;
            for ( ; $i < $count; ++$i )
            {
                $aReferences[$i]( $aReferences[$i] )->setValueExplicit( NULL, PHPExcel_Cell_DataType::TYPE_NULL );
            }
        }
        else
        {
            throw new PHPExcel_Exception( "Merge must be set on a range of cells." );
        }
        return $this;
    }

    public function mergeCellsByColumnAndRow( $pColumn1 = 0, $pRow1 = 1, $pColumn2 = 0, $pRow2 = 1 )
    {
        $cellRange = ( $pColumn1 ).$pRow1.":".( $pColumn2 ).$pRow2;
        return $this->mergeCells( $cellRange );
    }

    public function unmergeCells( $pRange = "A1:A1" )
    {
        $pRange = strtoupper( $pRange );
        if ( strpos( $pRange, ":" ) !== FALSE )
        {
            if ( isset( $this->_mergeCells[$pRange] ) )
            {
                unset( strtoupper( $pRange )[$pRange] );
            }
            else
            {
                throw new PHPExcel_Exception( "Cell range ".$pRange." not known as merged." );
            }
        }
        throw new PHPExcel_Exception( "Merge can only be removed from a range of cells." );
        return $this;
    }

    public function unmergeCellsByColumnAndRow( $pColumn1 = 0, $pRow1 = 1, $pColumn2 = 0, $pRow2 = 1 )
    {
        $cellRange = ( $pColumn1 ).$pRow1.":".( $pColumn2 ).$pRow2;
        return $this->unmergeCells( $cellRange );
    }

    public function getMergeCells( )
    {
        return $this->_mergeCells;
    }

    public function setMergeCells( $pValue = array( ) )
    {
        $this->_mergeCells = $pValue;
        return $this;
    }

    public function protectCells( $pRange = "A1", $pPassword = "", $pAlreadyHashed = FALSE )
    {
        $pRange = strtoupper( $pRange );
        if ( $pAlreadyHashed )
        {
            $pPassword = ( $pPassword );
        }
        $this->_protectedCells[$pRange] = $pPassword;
        return $this;
    }

    public function protectCellsByColumnAndRow( $pColumn1 = 0, $pRow1 = 1, $pColumn2 = 0, $pRow2 = 1, $pPassword = "", $pAlreadyHashed = FALSE )
    {
        $cellRange = ( $pColumn1 ).$pRow1.":".( $pColumn2 ).$pRow2;
        return $this->protectCells( $cellRange, $pPassword, $pAlreadyHashed );
    }

    public function unprotectCells( $pRange = "A1" )
    {
        $pRange = strtoupper( $pRange );
        if ( isset( $this->_protectedCells[$pRange] ) )
        {
            unset( strtoupper( $pRange )[$pRange] );
        }
        else
        {
            throw new PHPExcel_Exception( "Cell range ".$pRange." not known as protected." );
        }
        return $this;
    }

    public function unprotectCellsByColumnAndRow( $pColumn1 = 0, $pRow1 = 1, $pColumn2 = 0, $pRow2 = 1, $pPassword = "", $pAlreadyHashed = FALSE )
    {
        $cellRange = ( $pColumn1 ).$pRow1.":".( $pColumn2 ).$pRow2;
        return $this->unprotectCells( $cellRange, $pPassword, $pAlreadyHashed );
    }

    public function getProtectedCells( )
    {
        return $this->_protectedCells;
    }

    public function getAutoFilter( )
    {
        return $this->_autoFilter;
    }

    public function setAutoFilter( $pValue )
    {
        if ( is_string( $pValue ) )
        {
            $this->_autoFilter->setRange( $pValue );
        }
        else if ( is_object( $pValue ) && $pValue instanceof PHPExcel_Worksheet_AutoFilter )
        {
            $this->_autoFilter = $pValue;
        }
        return $this;
    }

    public function setAutoFilterByColumnAndRow( $pColumn1 = 0, $pRow1 = 1, $pColumn2 = 0, $pRow2 = 1 )
    {
        return ( $pColumn1 )( ( $pColumn1 ).$pRow1.":".( $pColumn2 ).$pRow2 );
    }

    public function removeAutoFilter( )
    {
        $this->_autoFilter->setRange( NULL );
        return $this;
    }

    public function getFreezePane( )
    {
        return $this->_freezePane;
    }

    public function freezePane( $pCell = "" )
    {
        $pCell = strtoupper( $pCell );
        if ( strpos( $pCell, ":" ) === FALSE && strpos( $pCell, "," ) === FALSE )
        {
            $this->_freezePane = $pCell;
        }
        else
        {
            throw new PHPExcel_Exception( "Freeze pane can not be set on a range of cells." );
        }
        return $this;
    }

    public function freezePaneByColumnAndRow( $pColumn = 0, $pRow = 1 )
    {
        return $this->freezePane( ( $pColumn ).$pRow );
    }

    public function unfreezePane( )
    {
        return $this->freezePane( "" );
    }

    public function insertNewRowBefore( $pBefore = 1, $pNumRows = 1 )
    {
        if ( 1 <= $pBefore )
        {
            $objReferenceHelper = ( );
            $this( "A".$pBefore, 0, $pNumRows, $this );
        }
        else
        {
            throw new PHPExcel_Exception( "Rows can only be inserted before at least row 1." );
        }
        return $this;
    }

    public function insertNewColumnBefore( $pBefore = "A", $pNumCols = 1 )
    {
        if ( is_numeric( $pBefore ) )
        {
            $objReferenceHelper = ( );
            $this( $pBefore."1", $pNumCols, 0, $this );
        }
        else
        {
            throw new PHPExcel_Exception( "Column references should not be numeric." );
        }
        return $this;
    }

    public function insertNewColumnBeforeByIndex( $pBefore = 0, $pNumCols = 1 )
    {
        if ( 0 <= $pBefore )
        {
            return ( $pBefore )( ( $pBefore ), $pNumCols );
        }
        throw new PHPExcel_Exception( "Columns can only be inserted before at least column A (0)." );
    }

    public function removeRow( $pRow = 1, $pNumRows = 1 )
    {
        if ( 1 <= $pRow )
        {
            $objReferenceHelper = ( );
            $this( "A".( $pRow + $pNumRows ), 0, 0 - $pNumRows, $this );
        }
        else
        {
            throw new PHPExcel_Exception( "Rows to be deleted should at least start from row 1." );
        }
        return $this;
    }

    public function removeColumn( $pColumn = "A", $pNumCols = 1 )
    {
        if ( is_numeric( $pColumn ) )
        {
            $pColumn = ( ( $pColumn ) - 1 + $pNumCols );
            $objReferenceHelper = ( );
            $this( $pColumn."1", 0 - $pNumCols, 0, $this );
        }
        else
        {
            throw new PHPExcel_Exception( "Column references should not be numeric." );
        }
        return $this;
    }

    public function removeColumnByIndex( $pColumn = 0, $pNumCols = 1 )
    {
        if ( 0 <= $pColumn )
        {
            return ( $pColumn )( ( $pColumn ), $pNumCols );
        }
        throw new PHPExcel_Exception( "Columns to be deleted should at least start from column 0" );
    }

    public function getShowGridlines( )
    {
        return $this->_showGridlines;
    }

    public function setShowGridlines( $pValue = FALSE )
    {
        $this->_showGridlines = $pValue;
        return $this;
    }

    public function getPrintGridlines( )
    {
        return $this->_printGridlines;
    }

    public function setPrintGridlines( $pValue = FALSE )
    {
        $this->_printGridlines = $pValue;
        return $this;
    }

    public function getShowRowColHeaders( )
    {
        return $this->_showRowColHeaders;
    }

    public function setShowRowColHeaders( $pValue = FALSE )
    {
        $this->_showRowColHeaders = $pValue;
        return $this;
    }

    public function getShowSummaryBelow( )
    {
        return $this->_showSummaryBelow;
    }

    public function setShowSummaryBelow( $pValue = TRUE )
    {
        $this->_showSummaryBelow = $pValue;
        return $this;
    }

    public function getShowSummaryRight( )
    {
        return $this->_showSummaryRight;
    }

    public function setShowSummaryRight( $pValue = TRUE )
    {
        $this->_showSummaryRight = $pValue;
        return $this;
    }

    public function getComments( )
    {
        return $this->_comments;
    }

    public function setComments( $pValue = array( ) )
    {
        $this->_comments = $pValue;
        return $this;
    }

    public function getComment( $pCellCoordinate = "A1" )
    {
        $pCellCoordinate = strtoupper( $pCellCoordinate );
        if ( strpos( $pCellCoordinate, ":" ) !== FALSE || strpos( $pCellCoordinate, "," ) !== FALSE )
        {
            throw new PHPExcel_Exception( "Cell coordinate string can not be a range of cells." );
        }
        if ( strpos( $pCellCoordinate, "\$" ) !== FALSE )
        {
            throw new PHPExcel_Exception( "Cell coordinate string must not be absolute." );
        }
        if ( $pCellCoordinate == "" )
        {
            throw new PHPExcel_Exception( "Cell coordinate can not be zero-length string." );
        }
        if ( isset( $this->_comments[$pCellCoordinate] ) )
        {
            return $this->_comments[$pCellCoordinate];
        }
        $newComment = new PHPExcel_Comment( );
        $this->_comments[$pCellCoordinate] = $newComment;
        return $newComment;
    }

    public function getCommentByColumnAndRow( $pColumn = 0, $pRow = 1 )
    {
        return $this->getComment( ( $pColumn ).$pRow );
    }

    public function getSelectedCell( )
    {
        return $this->getSelectedCells( );
    }

    public function getActiveCell( )
    {
        return $this->_activeCell;
    }

    public function getSelectedCells( )
    {
        return $this->_selectedCells;
    }

    public function setSelectedCell( $pCoordinate = "A1" )
    {
        return $this->setSelectedCells( $pCoordinate );
    }

    public function setSelectedCells( $pCoordinate = "A1" )
    {
        $pCoordinate = strtoupper( $pCoordinate );
        $pCoordinate = preg_replace( "/^([A-Z]+)$/", "${1}:${1}", $pCoordinate );
        $pCoordinate = preg_replace( "/^([0-9]+)$/", "${1}:${1}", $pCoordinate );
        $pCoordinate = preg_replace( "/^([A-Z]+):([A-Z]+)$/", "${1}1:${2}1048576", $pCoordinate );
        $pCoordinate = preg_replace( "/^([0-9]+):([0-9]+)$/", "A${1}:XFD${2}", $pCoordinate );
        if ( strpos( $pCoordinate, ":" ) !== FALSE || strpos( $pCoordinate, "," ) !== FALSE )
        {
            list( $first ) = ( $pCoordinate );
            $this->_activeCell = preg_replace( "/^([0-9]+):([0-9]+)$/", "A${1}:XFD${2}", $pCoordinate );
        }
        else
        {
            $this->_activeCell = $pCoordinate;
        }
        $this->_selectedCells = $pCoordinate;
        return $this;
    }

    public function setSelectedCellByColumnAndRow( $pColumn = 0, $pRow = 1 )
    {
        return $this->setSelectedCells( ( $pColumn ).$pRow );
    }

    public function getRightToLeft( )
    {
        return $this->_rightToLeft;
    }

    public function setRightToLeft( $value = FALSE )
    {
        $this->_rightToLeft = $value;
        return $this;
    }

    public function fromArray( $source = NULL, $nullValue = NULL, $startCell = "A1", $strictNullComparison = FALSE )
    {
        if ( is_array( $source ) )
        {
            if ( is_array( end( &$source ) ) )
            {
                $source = array( $source );
            }
            list( $startColumn, $startRow ) = ( $startCell );
            foreach ( $source as $currentColumn => $rowData )
            {
                foreach ( $rowData as $cellValue )
                {
                    if ( $strictNullComparison )
                    {
                        if ( $cellValue !== $nullValue )
                        {
                            $this->getCell( $currentColumn.$startRow )->setValue( $cellValue );
                        }
                    }
                    else if ( $cellValue != $nullValue )
                    {
                        $this->getCell( $currentColumn.$startRow )->setValue( $cellValue );
                    }
                    ++$currentColumn;
                }
                ++$startRow;
            }
        }
        else
        {
            throw new PHPExcel_Exception( "Parameter \$source should be an array." );
        }
        return $this;
    }

    public function rangeToArray( $pRange = "A1", $nullValue = NULL, $calculateFormulas = TRUE, $formatData = TRUE, $returnCellRef = FALSE )
    {
        $returnValue = array( );
        list( $rangeStart, $rangeEnd ) = ( $pRange );
        $minCol = ( $rangeStart[0] - 1 );
        $minRow = $rangeStart[1];
        $maxCol = ( $rangeEnd[0] - 1 );
        $maxRow = $rangeEnd[1];
        ++$maxCol;
        $r = -1;
        $row = $minRow;
        for ( ; $row <= $maxRow; ++$row )
        {
            $rRef = $returnCellRef ? $row : ++$r;
            $c = -1;
            $col = $minCol;
            for ( ; $col != $maxCol; ++$col )
            {
                $cRef = $returnCellRef ? $col : ++$c;
                if ( $this->_cellCollection->isDataSet( $col.$row ) )
                {
                    $cell = $this->_cellCollection->getCacheData( $col.$row );
                    if ( $cell->getValue( ) !== NULL )
                    {
                        if ( $cell->getValue( ) instanceof PHPExcel_RichText )
                        {
                            $returnValue[$rRef][$cRef] = $cell->getValue( )->getPlainText( );
                        }
                        else if ( $calculateFormulas )
                        {
                            $returnValue[$rRef][$cRef] = $cell->getCalculatedValue( );
                        }
                        else
                        {
                            $returnValue[$rRef][$cRef] = $cell->getValue( );
                        }
                        if ( $formatData )
                        {
                            $style = $this->_parent->getCellXfByIndex( $cell->getXfIndex( ) );
                            $returnValue[$rRef][$cRef] = ( $returnValue[$rRef][$cRef], $style->getNumberFormat( ) ? $style->getNumberFormat( )->getFormatCode( ) : PHPExcel_Style_NumberFormat::FORMAT_GENERAL );
                        }
                    }
                    else
                    {
                        $returnValue[$rRef][$cRef] = $nullValue;
                    }
                }
                else
                {
                    $returnValue[$rRef][$cRef] = $nullValue;
                }
            }
        }
        return $returnValue;
    }

    public function namedRangeToArray( $pNamedRange = "", $nullValue = NULL, $calculateFormulas = TRUE, $formatData = TRUE, $returnCellRef = FALSE )
    {
        $namedRange = ( $pNamedRange, $this );
        if ( $namedRange !== NULL )
        {
            $pWorkSheet = $namedRange->getWorksheet( );
            $pCellRange = $namedRange->getRange( );
            return $pWorkSheet->rangeToArray( $pCellRange, $nullValue, $calculateFormulas, $formatData, $returnCellRef );
        }
        throw new PHPExcel_Exception( "Named Range ".$pNamedRange." does not exist." );
    }

    public function toArray( $nullValue = NULL, $calculateFormulas = TRUE, $formatData = TRUE, $returnCellRef = FALSE )
    {
        $this->garbageCollect( );
        $maxCol = $this->getHighestColumn( );
        $maxRow = $this->getHighestRow( );
        return $this->rangeToArray( "A1:".$maxCol.$maxRow, $nullValue, $calculateFormulas, $formatData, $returnCellRef );
    }

    public function getRowIterator( $startRow = 1 )
    {
        return new PHPExcel_Worksheet_RowIterator( $this, $startRow );
    }

    public function garbageCollect( )
    {
        $this->_cellCollection->getCacheData( "A1" );
        $colRow = $this->_cellCollection->getHighestRowAndColumn( );
        $highestRow = $colRow['row'];
        $highestColumn = ( $colRow['column'] );
        foreach ( $this->_columnDimensions as $dimension )
        {
            $highestColumn = max( $highestColumn, ( $dimension->getColumnIndex( ) ) );
        }
        foreach ( $this->_rowDimensions as $dimension )
        {
            $highestRow = max( $highestRow, $dimension->getRowIndex( ) );
        }
        if ( $highestColumn < 0 )
        {
            $this->_cachedHighestColumn = "A";
        }
        else
        {
            $this->_cachedHighestColumn = ( --$highestColumn );
        }
        $this->_cachedHighestRow = $highestRow;
        return $this;
    }

    public function getHashCode( )
    {
        if ( $this->_dirty )
        {
            $this->_hash = md5( $this->_title.$this->_autoFilter.( $this->_protection->isProtectionEnabled( ) ? "t" : "f" )."PHPExcel_Worksheet" );
            $this->_dirty = FALSE;
        }
        return $this->_hash;
    }

    public static function extractSheetTitle( $pRange, $returnRange = FALSE )
    {
        if ( ( $sep = strpos( $pRange, "!" ) ) === FALSE )
        {
            return "";
        }
        if ( $returnRange )
        {
            return array( trim( substr( $pRange, 0, $sep ), "'" ), substr( $pRange, $sep + 1 ) );
        }
        return substr( $pRange, $sep + 1 );
    }

    public function getHyperlink( $pCellCoordinate = "A1" )
    {
        if ( isset( $this->_hyperlinkCollection[$pCellCoordinate] ) )
        {
            return $this->_hyperlinkCollection[$pCellCoordinate];
        }
        $this->_hyperlinkCollection[$pCellCoordinate] = new PHPExcel_Cell_Hyperlink( );
        return $this->_hyperlinkCollection[$pCellCoordinate];
    }

    public function setHyperlink( $pCellCoordinate = "A1", $pHyperlink = NULL )
    {
        if ( $pHyperlink === NULL )
        {
            unset( $Var_24[$pCellCoordinate] );
        }
        else
        {
            $this->_hyperlinkCollection[$pCellCoordinate] = $pHyperlink;
        }
        return $this;
    }

    public function hyperlinkExists( $pCoordinate = "A1" )
    {
        return isset( $this->_hyperlinkCollection[$pCoordinate] );
    }

    public function getHyperlinkCollection( )
    {
        return $this->_hyperlinkCollection;
    }

    public function getDataValidation( $pCellCoordinate = "A1" )
    {
        if ( isset( $this->_dataValidationCollection[$pCellCoordinate] ) )
        {
            return $this->_dataValidationCollection[$pCellCoordinate];
        }
        $this->_dataValidationCollection[$pCellCoordinate] = new PHPExcel_Cell_DataValidation( );
        return $this->_dataValidationCollection[$pCellCoordinate];
    }

    public function setDataValidation( $pCellCoordinate = "A1", $pDataValidation = NULL )
    {
        if ( $pDataValidation === NULL )
        {
            unset( $Var_24[$pCellCoordinate] );
        }
        else
        {
            $this->_dataValidationCollection[$pCellCoordinate] = $pDataValidation;
        }
        return $this;
    }

    public function dataValidationExists( $pCoordinate = "A1" )
    {
        return isset( $this->_dataValidationCollection[$pCoordinate] );
    }

    public function getDataValidationCollection( )
    {
        return $this->_dataValidationCollection;
    }

    public function shrinkRangeToFit( $range )
    {
        $maxCol = $this->getHighestColumn( );
        $maxRow = $this->getHighestRow( );
        $maxCol = ( $maxCol );
        $rangeBlocks = explode( " ", $range );
        foreach ( $rangeBlocks as $rangeBoundaries )
        {
            if ( $maxCol < ( $rangeBoundaries[0][0] ) )
            {
                $rangeBoundaries[0][0] = ( $maxCol );
            }
            if ( $maxRow < $rangeBoundaries[0][1] )
            {
                $rangeBoundaries[0][1] = $maxRow;
            }
            if ( $maxCol < ( $rangeBoundaries[1][0] ) )
            {
                $rangeBoundaries[1][0] = ( $maxCol );
            }
            if ( $maxRow < $rangeBoundaries[1][1] )
            {
                $rangeBoundaries[1][1] = $maxRow;
            }
            $rangeSet = $rangeBoundaries[0][0].$rangeBoundaries[0][1].":".$rangeBoundaries[1][0].$rangeBoundaries[1][1];
        }
        unset( $rangeSet );
        $stRange = implode( " ", $rangeBlocks );
        return $stRange;
    }

    public function getTabColor( )
    {
        if ( $this->_tabColor === NULL )
        {
            $this->_tabColor = new PHPExcel_Style_Color( );
        }
        return $this->_tabColor;
    }

    public function resetTabColor( )
    {
        $this->_tabColor = NULL;
        return $this;
    }

    public function isTabColorSet( )
    {
        return $this->_tabColor !== NULL;
    }

    public function copy( )
    {
        $copied = clone $this;
        return $copied;
    }

    public function __clone( )
    {
        foreach ( $this as $key => $val )
        {
            if ( !( $key == "_parent" || !is_object( $val ) && !is_array( $val ) ) )
            {
                continue;
            }
            else if ( $key == "_cellCollection" )
            {
                $newCollection = clone $this->_cellCollection;
                $this( $this );
                $this->_cellCollection = $newCollection;
            }
            else if ( $key == "_drawingCollection" )
            {
                $newCollection = clone $this->_drawingCollection;
                $this->_drawingCollection = $newCollection;
            }
            else if ( $key == "_autoFilter" && $this->_autoFilter instanceof PHPExcel_Worksheet_AutoFilter )
            {
                $newAutoFilter = clone $this->_autoFilter;
                $this->_autoFilter = $newAutoFilter;
                $this->_autoFilter->setParent( $this );
            }
            else
            {
                $this->$key = unserialize( serialize( $val ) );
            }
        }
    }

}

?>
