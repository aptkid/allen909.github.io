<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class PHPExcel_NamedRange
{

    private $_name;
    private $_worksheet;
    private $_range;
    private $_localOnly;
    private $_scope;

    public function __construct( $pName = NULL, $pWorksheet, $pRange = "A1", $pLocalOnly = FALSE, $pScope = NULL )
    {
        if ( $pName === NULL || $pWorksheet === NULL || $pRange === NULL )
        {
            throw new PHPExcel_Exception( "Parameters can not be null." );
        }
        $this->_name = $pName;
        $this->_worksheet = $pWorksheet;
        $this->_range = $pRange;
        $this->_localOnly = $pLocalOnly;
        $this->_scope = $pLocalOnly ? $pScope == NULL ? $pWorksheet : $pScope : NULL;
    }

    public function getName( )
    {
        return $this->_name;
    }

    public function setName( $value = NULL )
    {
        if ( $value !== NULL )
        {
            $oldTitle = $this->_name;
            if ( $this->_worksheet !== NULL )
            {
                $this->_worksheet->getParent( )->removeNamedRange( $this->_name, $this->_worksheet );
            }
            $this->_name = $value;
            if ( $this->_worksheet !== NULL )
            {
                $this->_worksheet->getParent( )->addNamedRange( $this );
            }
            $newTitle = $this->_name;
            ( )->updateNamedFormulas( $this->_worksheet->getParent( ), $oldTitle, $newTitle );
        }
        return $this;
    }

    public function getWorksheet( )
    {
        return $this->_worksheet;
    }

    public function setWorksheet( $value = NULL )
    {
        if ( $value !== NULL )
        {
            $this->_worksheet = $value;
        }
        return $this;
    }

    public function getRange( )
    {
        return $this->_range;
    }

    public function setRange( $value = NULL )
    {
        if ( $value !== NULL )
        {
            $this->_range = $value;
        }
        return $this;
    }

    public function getLocalOnly( )
    {
        return $this->_localOnly;
    }

    public function setLocalOnly( $value = FALSE )
    {
        $this->_localOnly = $value;
        $this->_scope = $value ? $this->_worksheet : NULL;
        return $this;
    }

    public function getScope( )
    {
        return $this->_scope;
    }

    public function setScope( $value = NULL )
    {
        $this->_scope = $value;
        $this->_localOnly = TRUE;
        return $this;
    }

    public static function resolveRange( $pNamedRange = "", $pSheet )
    {
        return $pSheet->getParent( )->getNamedRange( $pNamedRange, $pSheet );
    }

    public function __clone( )
    {
        $vars = get_object_vars( $this );
        foreach ( $vars as $key => $value )
        {
            if ( is_object( $value ) )
            {
                $this->$key = clone $value;
            }
            else
            {
                $this->$key = $value;
            }
        }
    }

}

?>
