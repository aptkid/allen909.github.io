<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class PHPExcel_Style_Font extends PHPExcel_IComparable implements PHPExcel_IComparable
{

    protected $_name = "Calibri";
    protected $_size = 11;
    protected $_bold = FALSE;
    protected $_italic = FALSE;
    protected $_superScript = FALSE;
    protected $_subScript = FALSE;
    protected $_underline = self::UNDERLINE_NONE;
    protected $_strikethrough = FALSE;
    protected $_color;

    const UNDERLINE_NONE = "none";
    const UNDERLINE_DOUBLE = "double";
    const UNDERLINE_DOUBLEACCOUNTING = "doubleAccounting";
    const UNDERLINE_SINGLE = "single";
    const UNDERLINE_SINGLEACCOUNTING = "singleAccounting";

    public function __construct( $isSupervisor = FALSE, $isConditional = FALSE )
    {
        ( $isSupervisor );
        if ( $isConditional )
        {
            $this->_name = NULL;
            $this->_size = NULL;
            $this->_bold = NULL;
            $this->_italic = NULL;
            $this->_superScript = NULL;
            $this->_subScript = NULL;
            $this->_underline = NULL;
            $this->_strikethrough = NULL;
            $this->_color = new PHPExcel_Style_Color( PHPExcel_Style_Color::COLOR_BLACK, $isSupervisor, $isConditional );
        }
        else
        {
            $this->_color = new PHPExcel_Style_Color( PHPExcel_Style_Color::COLOR_BLACK, $isSupervisor );
        }
        if ( $isSupervisor )
        {
            $this->_color->bindParent( $this, "_color" );
        }
    }

    public function getSharedComponent( )
    {
        return $this->_parent->getSharedComponent( )->getFont( );
    }

    public function getStyleArray( $array )
    {
        return array( "font" => $array );
    }

    public function applyFromArray( $pStyles = NULL )
    {
        if ( is_array( $pStyles ) )
        {
            if ( $this->_isSupervisor )
            {
                $this->getActiveSheet( )->getStyle( $this->getSelectedCells( ) )->applyFromArray( $this->getStyleArray( $pStyles ) );
            }
            else
            {
                if ( array_key_exists( "name", $pStyles ) )
                {
                    $pStyles['name']( $pStyles['name'] );
                }
                if ( array_key_exists( "bold", $pStyles ) )
                {
                    $pStyles['bold']( $pStyles['bold'] );
                }
                if ( array_key_exists( "italic", $pStyles ) )
                {
                    $pStyles['italic']( $pStyles['italic'] );
                }
                if ( array_key_exists( "superScript", $pStyles ) )
                {
                    $pStyles['superScript']( $pStyles['superScript'] );
                }
                if ( array_key_exists( "subScript", $pStyles ) )
                {
                    $pStyles['subScript']( $pStyles['subScript'] );
                }
                if ( array_key_exists( "underline", $pStyles ) )
                {
                    $pStyles['underline']( $pStyles['underline'] );
                }
                if ( array_key_exists( "strike", $pStyles ) )
                {
                    $pStyles['strike']( $pStyles['strike'] );
                }
                if ( array_key_exists( "color", $pStyles ) )
                {
                    $this->getColor( )->applyFromArray( $pStyles['color'] );
                }
                if ( array_key_exists( "size", $pStyles ) )
                {
                    $pStyles['size']( $pStyles['size'] );
                }
            }
        }
        else
        {
            throw new PHPExcel_Exception( "Invalid style array passed." );
        }
        return $this;
    }

    public function getName( )
    {
        if ( $this->_isSupervisor )
        {
            return $this->getSharedComponent( )->getName( );
        }
        return $this->_name;
    }

    public function setName( $pValue = "Calibri" )
    {
        if ( $pValue == "" )
        {
            $pValue = "Calibri";
        }
        if ( $this->_isSupervisor )
        {
            $styleArray = $this->getStyleArray( array( "name" => $pValue ) );
            $this->getActiveSheet( )->getStyle( $this->getSelectedCells( ) )->applyFromArray( $styleArray );
        }
        else
        {
            $this->_name = $pValue;
        }
        return $this;
    }

    public function getSize( )
    {
        if ( $this->_isSupervisor )
        {
            return $this->getSharedComponent( )->getSize( );
        }
        return $this->_size;
    }

    public function setSize( $pValue = 10 )
    {
        if ( $pValue == "" )
        {
            $pValue = 10;
        }
        if ( $this->_isSupervisor )
        {
            $styleArray = $this->getStyleArray( array( "size" => $pValue ) );
            $this->getActiveSheet( )->getStyle( $this->getSelectedCells( ) )->applyFromArray( $styleArray );
        }
        else
        {
            $this->_size = $pValue;
        }
        return $this;
    }

    public function getBold( )
    {
        if ( $this->_isSupervisor )
        {
            return $this->getSharedComponent( )->getBold( );
        }
        return $this->_bold;
    }

    public function setBold( $pValue = FALSE )
    {
        if ( $pValue == "" )
        {
            $pValue = FALSE;
        }
        if ( $this->_isSupervisor )
        {
            $styleArray = $this->getStyleArray( array( "bold" => $pValue ) );
            $this->getActiveSheet( )->getStyle( $this->getSelectedCells( ) )->applyFromArray( $styleArray );
        }
        else
        {
            $this->_bold = $pValue;
        }
        return $this;
    }

    public function getItalic( )
    {
        if ( $this->_isSupervisor )
        {
            return $this->getSharedComponent( )->getItalic( );
        }
        return $this->_italic;
    }

    public function setItalic( $pValue = FALSE )
    {
        if ( $pValue == "" )
        {
            $pValue = FALSE;
        }
        if ( $this->_isSupervisor )
        {
            $styleArray = $this->getStyleArray( array( "italic" => $pValue ) );
            $this->getActiveSheet( )->getStyle( $this->getSelectedCells( ) )->applyFromArray( $styleArray );
        }
        else
        {
            $this->_italic = $pValue;
        }
        return $this;
    }

    public function getSuperScript( )
    {
        if ( $this->_isSupervisor )
        {
            return $this->getSharedComponent( )->getSuperScript( );
        }
        return $this->_superScript;
    }

    public function setSuperScript( $pValue = FALSE )
    {
        if ( $pValue == "" )
        {
            $pValue = FALSE;
        }
        if ( $this->_isSupervisor )
        {
            $styleArray = $this->getStyleArray( array( "superScript" => $pValue ) );
            $this->getActiveSheet( )->getStyle( $this->getSelectedCells( ) )->applyFromArray( $styleArray );
        }
        else
        {
            $this->_superScript = $pValue;
            $this->_subScript = !$pValue;
        }
        return $this;
    }

    public function getSubScript( )
    {
        if ( $this->_isSupervisor )
        {
            return $this->getSharedComponent( )->getSubScript( );
        }
        return $this->_subScript;
    }

    public function setSubScript( $pValue = FALSE )
    {
        if ( $pValue == "" )
        {
            $pValue = FALSE;
        }
        if ( $this->_isSupervisor )
        {
            $styleArray = $this->getStyleArray( array( "subScript" => $pValue ) );
            $this->getActiveSheet( )->getStyle( $this->getSelectedCells( ) )->applyFromArray( $styleArray );
        }
        else
        {
            $this->_subScript = $pValue;
            $this->_superScript = !$pValue;
        }
        return $this;
    }

    public function getUnderline( )
    {
        if ( $this->_isSupervisor )
        {
            return $this->getSharedComponent( )->getUnderline( );
        }
        return $this->_underline;
    }

    public function setUnderline( $pValue = self::UNDERLINE_NONE )
    {
        if ( is_bool( $pValue ) )
        {
            $pValue = $pValue ? self::UNDERLINE_SINGLE : self::UNDERLINE_NONE;
        }
        else if ( $pValue == "" )
        {
            $pValue = self::UNDERLINE_NONE;
        }
        if ( $this->_isSupervisor )
        {
            $styleArray = $this->getStyleArray( array( "underline" => $pValue ) );
            $this->getActiveSheet( )->getStyle( $this->getSelectedCells( ) )->applyFromArray( $styleArray );
        }
        else
        {
            $this->_underline = $pValue;
        }
        return $this;
    }

    public function getStrikethrough( )
    {
        if ( $this->_isSupervisor )
        {
            return $this->getSharedComponent( )->getStrikethrough( );
        }
        return $this->_strikethrough;
    }

    public function setStrikethrough( $pValue = FALSE )
    {
        if ( $pValue == "" )
        {
            $pValue = FALSE;
        }
        if ( $this->_isSupervisor )
        {
            $styleArray = $this->getStyleArray( array( "strike" => $pValue ) );
            $this->getActiveSheet( )->getStyle( $this->getSelectedCells( ) )->applyFromArray( $styleArray );
        }
        else
        {
            $this->_strikethrough = $pValue;
        }
        return $this;
    }

    public function getColor( )
    {
        return $this->_color;
    }

    public function setColor( $pValue = NULL )
    {
        $color = $pValue->getIsSupervisor( ) ? $pValue->getSharedComponent( ) : $pValue;
        if ( $this->_isSupervisor )
        {
            $styleArray = $this->getColor( )->getStyleArray( array( "argb" => $color->getARGB( ) ) );
            $this->getActiveSheet( )->getStyle( $this->getSelectedCells( ) )->applyFromArray( $styleArray );
        }
        else
        {
            $this->_color = $color;
        }
        return $this;
    }

    public function getHashCode( )
    {
        if ( $this->_isSupervisor )
        {
            return $this->getSharedComponent( )->getHashCode( );
        }
        return md5( $this->_name.$this->_size.( $this->_bold ? "t" : "f" ).( $this->_italic ? "t" : "f" ).( $this->_superScript ? "t" : "f" ).( $this->_subScript ? "t" : "f" ).$this->_underline.( $this->_strikethrough ? "t" : "f" ).$this->_color->getHashCode( )."PHPExcel_Style_Font" );
    }

}

?>
