<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class PHPExcel_CachedObjectStorage_APC extends PHPExcel_CachedObjectStorage_ICache implements PHPExcel_CachedObjectStorage_ICache
{

    private $_cachePrefix;
    private $_cacheTime = 600;

    protected function _storeData( )
    {
        if ( $this->_currentCellIsDirty )
        {
            $this->_currentObject->detach( );
            if ( apc_store( $this->_cachePrefix.$this->_currentObjectID.".cache", serialize( $this->_currentObject ), $this->_cacheTime ) )
            {
                $this->__destruct( );
                throw new PHPExcel_Exception( "Failed to store cell ".$this->_currentObjectID." in APC" );
            }
            $this->_currentCellIsDirty = FALSE;
        }
        $this->_currentObjectID = $this->_currentObject = NULL;
    }

    public function addCacheData( $pCoord, $cell )
    {
        if ( $pCoord !== $this->_currentObjectID && $this->_currentObjectID !== NULL )
        {
            $this->_storeData( );
        }
        $this->_cellCache[$pCoord] = TRUE;
        $this->_currentObjectID = $pCoord;
        $this->_currentObject = $cell;
        $this->_currentCellIsDirty = TRUE;
        return $cell;
    }

    public function isDataSet( $pCoord )
    {
        if ( ( $pCoord ) )
        {
            if ( $this->_currentObjectID == $pCoord )
            {
                return TRUE;
            }
            $success = apc_fetch( $this->_cachePrefix.$pCoord.".cache" );
            if ( $success === FALSE )
            {
                ( $pCoord );
                throw new PHPExcel_Exception( "Cell entry ".$pCoord." no longer exists in APC cache" );
            }
            return TRUE;
        }
        return FALSE;
    }

    public function getCacheData( $pCoord )
    {
        if ( $pCoord === $this->_currentObjectID )
        {
            return $this->_currentObject;
        }
        $this->_storeData( );
        do
        {
            if ( ( $pCoord ) )
            {
                $obj = apc_fetch( $this->_cachePrefix.$pCoord.".cache" );
                if ( !( $obj === FALSE ) )
                {
                    break;
                }
                else
                {
                    ( $pCoord );
                    throw new PHPExcel_Exception( "Cell entry ".$pCoord." no longer exists in APC cache" );
                }
            }
            return;
        } while ( 0 );
        $this->_currentObjectID = $pCoord;
        $this->_currentObject = unserialize( $obj );
        $this->_currentObject->attach( $this );
        return $this->_currentObject;
    }

    public function getCellList( )
    {
        if ( $this->_currentObjectID !== NULL )
        {
            $this->_storeData( );
        }
        return ( );
    }

    public function deleteCacheData( $pCoord )
    {
        apc_delete( $this->_cachePrefix.$pCoord.".cache" );
        ( $pCoord );
    }

    public function copyCellCollection( $parent )
    {
        ( $parent );
        $baseUnique = $this->_getUniqueID( );
        $newCachePrefix = substr( md5( $baseUnique ), 0, 8 ).".";
        $cacheList = $this->getCellList( );
        foreach ( $cacheList as $cellID )
        {
            if ( $cellID != $this->_currentObjectID )
            {
                $obj = apc_fetch( $this->_cachePrefix.$cellID.".cache" );
                if ( $obj === FALSE )
                {
                    ( $cellID );
                    throw new PHPExcel_Exception( "Cell entry ".$cellID." no longer exists in APC" );
                }
                if ( apc_store( $newCachePrefix.$cellID.".cache", $obj, $this->_cacheTime ) )
                {
                    $this->__destruct( );
                    throw new PHPExcel_Exception( "Failed to store cell ".$cellID." in APC" );
                    break;
                }
            }
        }
        $this->_cachePrefix = $newCachePrefix;
    }

    public function unsetWorksheetCells( )
    {
        if ( $this->_currentObject !== NULL )
        {
            $this->_currentObject->detach( );
            $this->_currentObject = $this->_currentObjectID = NULL;
        }
        $this->__destruct( );
        $this->_cellCache = array( );
        $this->_parent = NULL;
    }

    public function __construct( $parent, $arguments )
    {
        $cacheTime = isset( $arguments['cacheTime'] ) ? $arguments['cacheTime'] : 600;
        if ( $this->_cachePrefix === NULL )
        {
            $baseUnique = $this->_getUniqueID( );
            $this->_cachePrefix = substr( md5( $baseUnique ), 0, 8 ).".";
            $this->_cacheTime = $cacheTime;
            ( $parent );
        }
    }

    public function __destruct( )
    {
        $cacheList = $this->getCellList( );
        foreach ( $cacheList as $cellID )
        {
            apc_delete( $this->_cachePrefix.$cellID.".cache" );
        }
    }

    public static function cacheMethodIsAvailable( )
    {
        if ( function_exists( "apc_store" ) )
        {
            return FALSE;
        }
        if ( apc_sma_info( ) === FALSE )
        {
            return FALSE;
        }
        return TRUE;
    }

}

?>
