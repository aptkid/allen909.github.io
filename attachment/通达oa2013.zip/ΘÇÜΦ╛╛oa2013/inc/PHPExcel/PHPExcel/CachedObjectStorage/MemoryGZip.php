<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class PHPExcel_CachedObjectStorage_MemoryGZip extends PHPExcel_CachedObjectStorage_ICache implements PHPExcel_CachedObjectStorage_ICache
{

    protected function _storeData( )
    {
        if ( $this->_currentCellIsDirty )
        {
            $this->_currentObject->detach( );
            $this->_cellCache[$this->_currentObjectID] = gzdeflate( serialize( $this->_currentObject ) );
            $this->_currentCellIsDirty = FALSE;
        }
        $this->_currentObjectID = $this->_currentObject = NULL;
    }

    public function addCacheData( $pCoord, $cell )
    {
        if ( $pCoord !== $this->_currentObjectID && $this->_currentObjectID !== NULL )
        {
            $this->_storeData( );
        }
        $this->_currentObjectID = $pCoord;
        $this->_currentObject = $cell;
        $this->_currentCellIsDirty = TRUE;
        return $cell;
    }

    public function getCacheData( $pCoord )
    {
        if ( $pCoord === $this->_currentObjectID )
        {
            return $this->_currentObject;
        }
        $this->_storeData( );
        if ( isset( $this->_cellCache[$pCoord] ) )
        {
        }
        else
        {
            $this->_currentObjectID = $pCoord;
            $this->_currentObject = unserialize( gzinflate( $this->_cellCache[$pCoord] ) );
            $this->_currentObject->attach( $this );
            return $this->_currentObject;
        }
    }

    public function getCellList( )
    {
        if ( $this->_currentObjectID !== NULL )
        {
            $this->_storeData( );
        }
        return ( );
    }

    public function unsetWorksheetCells( )
    {
        if ( is_null( $this->_currentObject ) )
        {
            $this->_currentObject->detach( );
            $this->_currentObject = $this->_currentObjectID = NULL;
        }
        $this->_cellCache = array( );
        $this->_parent = NULL;
    }

}

?>
