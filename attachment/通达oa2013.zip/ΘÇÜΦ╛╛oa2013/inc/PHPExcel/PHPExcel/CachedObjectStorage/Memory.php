<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class PHPExcel_CachedObjectStorage_Memory extends PHPExcel_CachedObjectStorage_ICache implements PHPExcel_CachedObjectStorage_ICache
{

    protected function _storeData( )
    {
    }

    public function addCacheData( $pCoord, $cell )
    {
        $this->_cellCache[$pCoord] = $cell;
        $this->_currentObjectID = $pCoord;
        return $cell;
    }

    public function getCacheData( $pCoord )
    {
        if ( isset( $this->_cellCache[$pCoord] ) )
        {
            $this->_currentObjectID = NULL;
        }
        else
        {
            $this->_currentObjectID = $pCoord;
            return $this->_cellCache[$pCoord];
        }
    }

    public function copyCellCollection( $parent )
    {
        ( $parent );
        $newCollection = array( );
        foreach ( $this->_cellCache as $k )
        {
            $newCollection[$k] = clone $cell;
            $newCollection[$k]->attach( $parent );
        }
        $this->_cellCache = $newCollection;
    }

    public function unsetWorksheetCells( )
    {
        foreach ( $this->_cellCache as $k )
        {
            $cell->detach( );
            $this->_cellCache[$k] = NULL;
        }
        unset( $cell );
        $this->_cellCache = array( );
        $this->_parent = NULL;
    }

}

?>
