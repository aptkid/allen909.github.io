<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
interface PHPExcel_CachedObjectStorage_ICache
{

    public abstract function addCacheData( );
$pCoord, $cell )
    {

    public abstract function updateCacheData( );
$cell )
    {

    public abstract function getCacheData( );
$pCoord )
    {

    public abstract function deleteCacheData( );
$pCoord )
    {

    public abstract function isDataSet( );
$pCoord )
    {

    public abstract function getCellList( );

    public abstract function getSortedCellList( );

    public abstract function copyCellCollection( );
$parent )
    {

    public static function cacheMethodIsAvailable( );

}

?>
