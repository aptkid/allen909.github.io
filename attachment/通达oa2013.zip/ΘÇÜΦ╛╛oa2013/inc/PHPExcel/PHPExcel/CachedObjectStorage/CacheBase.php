<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
abstract class PHPExcel_CachedObjectStorage_CacheBase
{

    protected $_parent;
    protected $_currentObject;
    protected $_currentObjectID;
    protected $_currentCellIsDirty = TRUE;
    protected $_cellCache = array( );

    public function __construct( $parent )
    {
        $this->_parent = $parent;
    }

    public function getParent( )
    {
        return $this->_parent;
    }

    public function isDataSet( $pCoord )
    {
        if ( $pCoord === $this->_currentObjectID )
        {
            return TRUE;
        }
        return isset( $this->_cellCache[$pCoord] );
    }

    public function moveCell( $fromAddress, $toAddress )
    {
        if ( $fromAddress === $this->_currentObjectID )
        {
            $this->_currentObjectID = $toAddress;
        }
        $this->_currentCellIsDirty = TRUE;
        if ( isset( $this->_cellCache[$fromAddress] ) )
        {
            $this->_cellCache[$toAddress] =& $this->_cellCache[$fromAddress];
            unset( $this->_cellCache[$toAddress][$fromAddress] );
        }
        return TRUE;
    }

    public function updateCacheData( $cell )
    {
        return $this->addCacheData( $cell->getCoordinate( ), $cell );
    }

    public function deleteCacheData( $pCoord )
    {
        if ( $pCoord === $this->_currentObjectID )
        {
            $this->_currentObject->detach( );
            $this->_currentObjectID = $this->_currentObject = NULL;
        }
        if ( is_object( $this->_cellCache[$pCoord] ) )
        {
            $this->_cellCache[$pCoord]->detach( );
            unset( $this->_cellCache[$pCoord][$pCoord] );
        }
        $this->_currentCellIsDirty = FALSE;
    }

    public function getCellList( )
    {
        return array_keys( $this->_cellCache );
    }

    public function getSortedCellList( )
    {
        $sortKeys = array( );
        foreach ( $this->getCellList( ) as $coord )
        {
            sscanf( $coord, "%[A-Z]%d", &$column, &$row );
            $sortKeys[sprintf( "%09d%3s", $row, $column )] = $coord;
        }
        ksort( &$sortKeys );
        return array_values( $sortKeys );
    }

    public function getHighestRowAndColumn( )
    {
        $col = array( "A" => "1A" );
        $row = array( 1 );
        foreach ( $this->getCellList( ) as $coord )
        {
            sscanf( $coord, "%[A-Z]%d", &$c, &$r );
            $row[$r] = $r;
            $col[$c] = strlen( $c ).$c;
        }
        if ( empty( $row ) )
        {
            $highestRow = max( $row );
            $highestColumn = substr( max( $col ), 1 );
        }
        return array( "row" => $highestRow, "column" => $highestColumn );
    }

    public function getCurrentAddress( )
    {
        return $this->_currentObjectID;
    }

    public function getCurrentColumn( )
    {
        sscanf( $this->_currentObjectID, "%[A-Z]%d", &$column, &$row );
        return $column;
    }

    public function getCurrentRow( )
    {
        sscanf( $this->_currentObjectID, "%[A-Z]%d", &$column, &$row );
        return $row;
    }

    public function getHighestColumn( )
    {
        $colRow = $this->getHighestRowAndColumn( );
        return $colRow['column'];
    }

    public function getHighestRow( )
    {
        $colRow = $this->getHighestRowAndColumn( );
        return $colRow['row'];
    }

    protected function _getUniqueID( )
    {
        if ( function_exists( "posix_getpid" ) )
        {
            $baseUnique = posix_getpid( );
        }
        else
        {
            $baseUnique = mt_rand( );
        }
        return uniqid( $baseUnique, TRUE );
    }

    public function copyCellCollection( $parent )
    {
        $this->_currentCellIsDirty;
        $this->_storeData( );
        $this->_parent = $parent;
        if ( $this->_currentObject !== NULL && is_object( $this->_currentObject ) )
        {
            $this->_currentObject->attach( $this );
        }
    }

    public static function cacheMethodIsAvailable( )
    {
        return TRUE;
    }

}

?>
