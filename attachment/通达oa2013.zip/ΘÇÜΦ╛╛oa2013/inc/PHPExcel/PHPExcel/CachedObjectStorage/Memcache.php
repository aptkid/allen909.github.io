<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class PHPExcel_CachedObjectStorage_Memcache extends PHPExcel_CachedObjectStorage_ICache implements PHPExcel_CachedObjectStorage_ICache
{

    private $_cachePrefix;
    private $_cacheTime = 600;
    private $_memcache;

    protected function _storeData( )
    {
        if ( $this->_currentCellIsDirty )
        {
            $this->_currentObject->detach( );
            $obj = serialize( $this->_currentObject );
            if ( !$this->_memcache->replace( $this->_cachePrefix.$this->_currentObjectID.".cache", $obj, NULL, $this->_cacheTime ) && !$this->_memcache->add( $this->_cachePrefix.$this->_currentObjectID.".cache", $obj, NULL, $this->_cacheTime ) )
            {
                $this->__destruct( );
                throw new PHPExcel_Exception( "Failed to store cell ".$this->_currentObjectID." in MemCache" );
            }
            $this->_currentCellIsDirty = FALSE;
        }
        $this->_currentObjectID = $this->_currentObject = NULL;
    }

    public function addCacheData( $pCoord, $cell )
    {
        if ( $pCoord !== $this->_currentObjectID && $this->_currentObjectID !== NULL )
        {
            $this->_storeData( );
        }
        $this->_cellCache[$pCoord] = TRUE;
        $this->_currentObjectID = $pCoord;
        $this->_currentObject = $cell;
        $this->_currentCellIsDirty = TRUE;
        return $cell;
    }

    public function isDataSet( $pCoord )
    {
        if ( ( $pCoord ) )
        {
            if ( $this->_currentObjectID == $pCoord )
            {
                return TRUE;
            }
            $success = $this->_memcache->get( $this->_cachePrefix.$pCoord.".cache" );
            if ( $success === FALSE )
            {
                ( $pCoord );
                throw new PHPExcel_Exception( "Cell entry ".$pCoord." no longer exists in MemCache" );
            }
            return TRUE;
        }
        return FALSE;
    }

    public function getCacheData( $pCoord )
    {
        if ( $pCoord === $this->_currentObjectID )
        {
            return $this->_currentObject;
        }
        $this->_storeData( );
        do
        {
            if ( ( $pCoord ) )
            {
                $obj = $this->_memcache->get( $this->_cachePrefix.$pCoord.".cache" );
                if ( !( $obj === FALSE ) )
                {
                    break;
                }
                else
                {
                    ( $pCoord );
                    throw new PHPExcel_Exception( "Cell entry ".$pCoord." no longer exists in MemCache" );
                }
            }
            return;
        } while ( 0 );
        $this->_currentObjectID = $pCoord;
        $this->_currentObject = unserialize( $obj );
        $this->_currentObject->attach( $this );
        return $this->_currentObject;
    }

    public function getCellList( )
    {
        if ( $this->_currentObjectID !== NULL )
        {
            $this->_storeData( );
        }
        return ( );
    }

    public function deleteCacheData( $pCoord )
    {
        $this->_memcache->delete( $this->_cachePrefix.$pCoord.".cache" );
        ( $pCoord );
    }

    public function copyCellCollection( $parent )
    {
        ( $parent );
        $baseUnique = $this->_getUniqueID( );
        $newCachePrefix = substr( md5( $baseUnique ), 0, 8 ).".";
        $cacheList = $this->getCellList( );
        foreach ( $cacheList as $cellID )
        {
            if ( $cellID != $this->_currentObjectID )
            {
                $obj = $this->_memcache->get( $this->_cachePrefix.$cellID.".cache" );
                if ( $obj === FALSE )
                {
                    ( $cellID );
                    throw new PHPExcel_Exception( "Cell entry ".$cellID." no longer exists in MemCache" );
                }
                if ( $this->_memcache->add( $newCachePrefix.$cellID.".cache", $obj, NULL, $this->_cacheTime ) )
                {
                    $this->__destruct( );
                    throw new PHPExcel_Exception( "Failed to store cell ".$cellID." in MemCache" );
                    break;
                }
            }
        }
        $this->_cachePrefix = $newCachePrefix;
    }

    public function unsetWorksheetCells( )
    {
        if ( is_null( $this->_currentObject ) )
        {
            $this->_currentObject->detach( );
            $this->_currentObject = $this->_currentObjectID = NULL;
        }
        $this->__destruct( );
        $this->_cellCache = array( );
        $this->_parent = NULL;
    }

    public function __construct( $parent, $arguments )
    {
        $memcacheServer = isset( $arguments['memcacheServer'] ) ? $arguments['memcacheServer'] : "localhost";
        $memcachePort = isset( $arguments['memcachePort'] ) ? $arguments['memcachePort'] : 11211;
        $cacheTime = isset( $arguments['cacheTime'] ) ? $arguments['cacheTime'] : 600;
        if ( is_null( $this->_cachePrefix ) )
        {
            $baseUnique = $this->_getUniqueID( );
            $this->_cachePrefix = substr( md5( $baseUnique ), 0, 8 ).".";
            $this->_memcache = new Memcache( );
            if ( $this( $memcacheServer, $memcachePort, FALSE, 50, 5, 5, TRUE, array( $this, "failureCallback" ) ) )
            {
                throw new PHPExcel_Exception( "Could not connect to MemCache server at ".$memcacheServer.":".$memcachePort );
            }
            $this->_cacheTime = $cacheTime;
            ( $parent );
        }
    }

    public function failureCallback( $host, $port )
    {
        throw new PHPExcel_Exception( "memcache ".$host.":".$port." failed" );
    }

    public function __destruct( )
    {
        $cacheList = $this->getCellList( );
        foreach ( $cacheList as $cellID )
        {
            $this->_memcache->delete( $this->_cachePrefix.$cellID.".cache" );
        }
    }

    public static function cacheMethodIsAvailable( )
    {
        if ( function_exists( "memcache_add" ) )
        {
            return FALSE;
        }
        return TRUE;
    }

}

?>
