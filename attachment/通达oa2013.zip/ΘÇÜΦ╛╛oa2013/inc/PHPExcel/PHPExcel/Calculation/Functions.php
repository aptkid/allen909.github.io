<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class PHPExcel_Calculation_Functions
{

    protected static $compatibilityMode = self::COMPATIBILITY_EXCEL;
    protected static $ReturnDateType = self::RETURNDATE_EXCEL;
    protected static $_errorCodes = array( 'null' => "#NULL!", 'divisionbyzero' => "#DIV/0!", 'value' => "#VALUE!", 'reference' => "#REF!", 'name' => "#NAME?", 'num' => "#NUM!", 'na' => "#N/A", 'gettingdata' => "#GETTING_DATA" );

    const COMPATIBILITY_EXCEL = "Excel";
    const COMPATIBILITY_GNUMERIC = "Gnumeric";
    const COMPATIBILITY_OPENOFFICE = "OpenOfficeCalc";
    const RETURNDATE_PHP_NUMERIC = "P";
    const RETURNDATE_PHP_OBJECT = "O";
    const RETURNDATE_EXCEL = "E";

    public static function setCompatibilityMode( $compatibilityMode )
    {
        do
        {
            if ( $compatibilityMode == self::COMPATIBILITY_EXCEL )
            {
                break;
            }
            else
            {
                if ( $compatibilityMode == self::COMPATIBILITY_GNUMERIC )
                {
                    break;
                }
                else
                {
                }
            }
            if ( $compatibilityMode == self::COMPATIBILITY_OPENOFFICE )
            {
            }
        } while ( 0 );
        self::$compatibilityMode = $compatibilityMode;
        return TRUE;
        return FALSE;
    }

    public static function getCompatibilityMode( )
    {
        return self::$compatibilityMode;
    }

    public static function setReturnDateType( $returnDateType )
    {
        do
        {
            if ( $returnDateType == self::RETURNDATE_PHP_NUMERIC )
            {
                break;
            }
            else
            {
                if ( $returnDateType == self::RETURNDATE_PHP_OBJECT )
                {
                    break;
                }
                else
                {
                }
            }
            if ( $returnDateType == self::RETURNDATE_EXCEL )
            {
            }
        } while ( 0 );
        self::$ReturnDateType = $returnDateType;
        return TRUE;
        return FALSE;
    }

    public static function getReturnDateType( )
    {
        return self::$ReturnDateType;
    }

    public static function DUMMY( )
    {
        return "#Not Yet Implemented";
    }

    public static function DIV0( )
    {
        return self::$_errorCodes['divisionbyzero'];
    }

    public static function NA( )
    {
        return self::$_errorCodes['na'];
    }

    public static function NaN( )
    {
        return self::$_errorCodes['num'];
    }

    public static function NAME( )
    {
        return self::$_errorCodes['name'];
    }

    public static function REF( )
    {
        return self::$_errorCodes['reference'];
    }

    public static function NULL( )
    {
        return self::$_errorCodes['null'];
    }

    public static function VALUE( )
    {
        return self::$_errorCodes['value'];
    }

    public static function isMatrixValue( $idx )
    {
        return 0 < preg_match( "/\\.[A-Z]/", $idx );
    }

    public static function isValue( $idx )
    {
        return substr_count( $idx, "." ) == 0;
    }

    public static function isCellValue( $idx )
    {
        return 1 < substr_count( $idx, "." );
    }

    public static function _ifCondition( $condition )
    {
        $condition = ( $condition );
        if ( isset( $condition[0] ) )
        {
            $condition = "=\"\"";
        }
        if ( in_array( $condition[0], array( ">", "<", "=" ) ) )
        {
            if ( is_numeric( $condition ) )
            {
                $condition = ( strtoupper( $condition ) );
            }
            return "=".$condition;
        }
        preg_match( "/([<>=]+)(.*)/", $condition, $matches );
        $operand = $matches[2];
        $operator = $matches[1];
        if ( is_numeric( $operand ) )
        {
            $operand = ( strtoupper( $operand ) );
        }
        return $operator.$operand;
    }

    public static function ERROR_TYPE( $value = "" )
    {
        $value = ( $value );
        $i = 1;
        foreach ( self::$_errorCodes as $errorCode )
        {
            if ( $value === $errorCode )
            {
                return $i;
            }
            ++$i;
        }
        return ( );
    }

    public static function IS_BLANK( $value = NULL )
    {
        if ( is_null( $value ) )
        {
            $value = ( $value );
        }
        return is_null( $value );
    }

    public static function IS_ERR( $value = "" )
    {
        $value = ( $value );
        return ( $value ) && !( $value );
    }

    public static function IS_ERROR( $value = "" )
    {
        $value = ( $value );
        if ( is_string( $value ) )
        {
            return FALSE;
        }
        return in_array( $value, array_values( self::$_errorCodes ) );
    }

    public static function IS_NA( $value = "" )
    {
        $value = ( $value );
        return $value === ( );
    }

    public static function IS_EVEN( $value = NULL )
    {
        $value = ( $value );
        if ( $value === NULL )
        {
            return ( );
        }
        if ( is_bool( $value ) || is_string( $value ) && !is_numeric( $value ) )
        {
            return ( );
        }
        return $value % 2 == 0;
    }

    public static function IS_ODD( $value = NULL )
    {
        $value = ( $value );
        if ( $value === NULL )
        {
            return ( );
        }
        if ( is_bool( $value ) || is_string( $value ) && !is_numeric( $value ) )
        {
            return ( );
        }
        return abs( $value ) % 2 == 1;
    }

    public static function IS_NUMBER( $value = NULL )
    {
        $value = ( $value );
        if ( is_string( $value ) )
        {
            return FALSE;
        }
        return is_numeric( $value );
    }

    public static function IS_LOGICAL( $value = NULL )
    {
        $value = ( $value );
        return is_bool( $value );
    }

    public static function IS_TEXT( $value = NULL )
    {
        $value = ( $value );
        return is_string( $value ) && !( $value );
    }

    public static function IS_NONTEXT( $value = NULL )
    {
        return !( $value );
    }

    public static function VERSION( )
    {
        return "PHPExcel 1.7.9, 2013-06-02";
    }

    public static function N( $value = NULL )
    {
        while ( is_array( $value ) )
        {
            $value = array_shift( &$value );
        }
        switch ( gettype( $value ) )
        {
            case "double" :
            case "float" :
            case "integer" :
                return $value;
            case "boolean" :
                return ( integer );
            case "string" :
                if ( !( 0 < strlen( $value ) ) || !( $value[0] == "#" ) )
                {
                    return $value;
                }
        }
        return 0;
    }

    public static function TYPE( $value = NULL )
    {
        $value = ( $value );
        if ( is_array( $value ) && 1 < count( $value ) )
        {
            $a = array_keys( $value );
            $a = array_pop( &$a );
            if ( ( $a ) )
            {
                return 16;
            }
            else
            {
                if ( ( $a ) )
                {
                    return 64;
                }
            }
        }
        else
        {
            if ( empty( $value ) )
            {
                return 1;
            }
        }
        $value = ( $value );
        if ( $value === NULL || is_float( $value ) || is_int( $value ) )
        {
            return 1;
        }
        else if ( is_bool( $value ) )
        {
            return 4;
        }
        else
        {
            if ( is_array( $value ) )
            {
                return 64;
                break;
            }
            else if ( is_string( $value ) )
            {
                if ( 0 < strlen( $value ) && $value[0] == "#" )
                {
                    return 16;
                }
                return 2;
            }
        }
        return 0;
    }

    public static function flattenArray( $array )
    {
        if ( is_array( $array ) )
        {
            return ( array );
        }
        $arrayValues = array( );
        foreach ( $array as $value )
        {
            if ( is_array( $value ) )
            {
                foreach ( $value as $val )
                {
                    if ( is_array( $val ) )
                    {
                        foreach ( $val as $v )
                        {
                            $arrayValues[] = $v;
                        }
                    }
                    else
                    {
                        $arrayValues[] = $val;
                    }
                }
            }
            else
            {
                $arrayValues[] = $value;
            }
        }
        return $arrayValues;
    }

    public static function flattenArrayIndexed( $array )
    {
        if ( is_array( $array ) )
        {
            return ( array );
        }
        $arrayValues = array( );
        foreach ( $array as $k1 => $value )
        {
            if ( is_array( $value ) )
            {
                foreach ( $value as $k2 => $val )
                {
                    if ( is_array( $val ) )
                    {
                        foreach ( $val as $k3 => $v )
                        {
                            $arrayValues[$k1.".".$k2.".".$k3] = $v;
                        }
                    }
                    else
                    {
                        $arrayValues[$k1.".".$k2] = $val;
                    }
                }
            }
            else
            {
                $arrayValues[$k1] = $value;
            }
        }
        return $arrayValues;
    }

    public static function flattenSingleValue( $value = "" )
    {
        while ( is_array( $value ) )
        {
            $value = array_pop( &$value );
        }
        return $value;
    }

}

if ( defined( "PHPEXCEL_ROOT" ) )
{
    define( "PHPEXCEL_ROOT", dirname( __FILE__ )."/../../" );
    require( PHPEXCEL_ROOT."PHPExcel/Autoloader.php" );
}
define( "MAX_VALUE", 1.2e+308 );
define( "M_2DIVPI", 0.63662 );
define( "MAX_ITERATIONS", 256 );
define( "PRECISION", 8.88e-016 );
if ( function_exists( "acosh" ) )
{
    function acosh( $x )
    {
        return 2 * log( sqrt( ( $x + 1 ) / 2 ) + sqrt( ( $x - 1 ) / 2 ) );
    }
}
if ( function_exists( "asinh" ) )
{
    function asinh( $x )
    {
        return log( $x + sqrt( 1 + $x * $x ) );
    }
}
if ( function_exists( "atanh" ) )
{
    function atanh( $x )
    {
        return ( log( 1 + $x ) - log( 1 - $x ) ) / 2;
    }
}
if ( function_exists( "money_format" ) )
{
    function money_format( $format, $number )
    {
        $regex = array( "/%((?:[\\^!\\-]|\\+|\\(|\\=.)*)([0-9]+)?(?:#([0-9]+))?", "(?:\\.([0-9]+))?([in%])/" );
        $regex = implode( "", $regex );
        if ( setlocale( LC_MONETARY, NULL ) == "" )
        {
            setlocale( LC_MONETARY, "" );
        }
        $locale = localeconv( );
        $number = floatval( $number );
        if ( preg_match( $regex, $format, $fmatch ) )
        {
            trigger_error( "No format specified or invalid format", E_USER_WARNING );
            return $number;
        }
        $flags = array( "fillchar" => preg_match( "/\\=(.)/", $fmatch[1], $match ) ? $match[1] : " ", "nogroup" => 0 < preg_match( "/\\^/", $fmatch[1] ), "usesignal" => preg_match( "/\\+|\\(/", $fmatch[1], $match ) ? $match[0] : "+", "nosimbol" => 0 < preg_match( "/\\!/", $fmatch[1] ), "isleft" => 0 < preg_match( "/\\-/", $fmatch[1] ) );
        $width = trim( $fmatch[2] ) ? ( integer ) : 0;
        $left = trim( $fmatch[3] ) ? ( integer ) : 0;
        $right = trim( $fmatch[4] ) ? ( integer ) : $locale['int_frac_digits'];
        $conversion = $fmatch[5];
        $positive = TRUE;
        if ( $number < 0 )
        {
            $positive = FALSE;
            $number *= -1;
        }
        $letter = $positive ? "p" : "n";
        $prefix = $suffix = $cprefix = $csuffix = $signal = "";
        if ( $positive )
        {
            $signal = $locale['negative_sign'];
            switch ( TRUE )
            {
                case $flags['usesignal'] == "(" :
                    $prefix = "(";
                    $suffix = ")";
                    break;
                case $locale['n_sign_posn'] == 1 :
                    $prefix = $signal;
                    break;
                case $locale['n_sign_posn'] == 2 :
                    $suffix = $signal;
                    break;
                case $locale['n_sign_posn'] == 3 :
                    $cprefix = $signal;
                    break;
                case $locale['n_sign_posn'] == 4 :
                    $csuffix = $signal;
            }
        }
        if ( $flags['nosimbol'] )
        {
            $currency = $cprefix;
            $currency .= $conversion == "i" ? $locale['int_curr_symbol'] : $locale['currency_symbol'];
            $currency .= $csuffix;
            $currency = iconv( "ISO-8859-1", "UTF-8", $currency );
        }
        else
        {
            $currency = "";
        }
        $space = $locale["{$letter}_sep_by_space"] ? " " : "";
        if ( $locale["{$letter}_sep_by_space"] ? " " : "" )
        {
            $locale['mon_decimal_point'] = isset( $locale['mon_decimal_point'], $locale['mon_decimal_point'], $locale['decimal_point'], $locale['decimal_point'] ) ? $locale['decimal_point'] : ".";
        }
        $number = number_format( $number, $right, $locale['mon_decimal_point'], $flags['nogroup'] ? "" : $locale['mon_thousands_sep'] );
        $number = explode( $locale['mon_decimal_point'], $number );
        $n = strlen( $prefix ) + strlen( $currency );
        if ( 0 < $left && $n < $left )
        {
            if ( $flags['isleft'] )
            {
                $number .= 0;
            }
            else
            {
                $number[0] = str_repeat( $flags['fillchar'], $left - $n ).$number[0];
            }
        }
        $number = implode( $locale['mon_decimal_point'], $number );
        if ( $locale["{$letter}_cs_precedes"] )
        {
            $number = $prefix.$currency.$space.$number.$suffix;
        }
        else
        {
            $number = $prefix.$number.$space.$currency.$suffix;
        }
        if ( 0 < $width )
        {
            $number = str_pad( $number, $width, $flags['fillchar'], $flags['isleft'] ? STR_PAD_RIGHT : STR_PAD_LEFT );
        }
        $format = str_replace( $fmatch[0], $number, $format );
        return $format;
    }
}
if ( !function_exists( "mb_str_replace" ) && function_exists( "mb_substr" ) && function_exists( "mb_strlen" ) && function_exists( "mb_strpos" ) )
{
    function mb_str_replace( $search, $replace, $subject )
    {
        if ( is_array( $subject ) )
        {
            $ret = array( );
            foreach ( $subject as $key => $val )
            {
                $ret[$key] = mb_str_replace( $search, $replace, $val );
                return $ret;
            }
            else
            {
                foreach ( ( array ) as $key => $s )
                {
                    if ( $s == "" )
                    {
                        $r = !is_array( $replace ) ? $replace : array_key_exists( $key, $replace ) ? $replace[$key] : "";
                        $pos = mb_strpos( $subject, $s, 0, "UTF-8" );
                        do
                        {
                            if ( $pos !== FALSE )
                            {
                                $subject = mb_substr( $subject, 0, $pos, "UTF-8" ).$r.mb_substr( $subject, $pos + mb_strlen( $s, "UTF-8" ), 65535, "UTF-8" );
                                $pos = mb_strpos( $subject, $s, $pos + mb_strlen( $r, "UTF-8" ), "UTF-8" );
                                break;
                                break;
                            }
                        } while ( 1 );
                    }
                }
            }
        }
        return $subject;
    }
}
?>
