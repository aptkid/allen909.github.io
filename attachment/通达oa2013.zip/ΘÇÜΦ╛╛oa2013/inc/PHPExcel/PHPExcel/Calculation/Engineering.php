<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class PHPExcel_Calculation_Engineering
{

    private static $_conversionUnits = array( 'g' => array( 'Group' => "Mass", 'Unit Name' => "Gram", 'AllowPrefix' => TRUE ), 'sg' => array( 'Group' => "Mass", 'Unit Name' => "Slug", 'AllowPrefix' => FALSE ), 'lbm' => array( 'Group' => "Mass", 'Unit Name' => "Pound mass (avoirdupois)", 'AllowPrefix' => FALSE ), 'u' => array( 'Group' => "Mass", 'Unit Name' => "U (atomic mass unit)", 'AllowPrefix' => TRUE ), 'ozm' => array( 'Group' => "Mass", 'Unit Name' => "Ounce mass (avoirdupois)", 'AllowPrefix' => FALSE ), 'm' => array( 'Group' => "Distance", 'Unit Name' => "Meter", 'AllowPrefix' => TRUE ), 'mi' => array( 'Group' => "Distance", 'Unit Name' => "Statute mile", 'AllowPrefix' => FALSE ), 'Nmi' => array( 'Group' => "Distance", 'Unit Name' => "Nautical mile", 'AllowPrefix' => FALSE ), 'in' => array( 'Group' => "Distance", 'Unit Name' => "Inch", 'AllowPrefix' => FALSE ), 'ft' => array( 'Group' => "Distance", 'Unit Name' => "Foot", 'AllowPrefix' => FALSE ), 'yd' => array( 'Group' => "Distance", 'Unit Name' => "Yard", 'AllowPrefix' => FALSE ), 'ang' => array( 'Group' => "Distance", 'Unit Name' => "Angstrom", 'AllowPrefix' => TRUE ), 'Pica' => array( 'Group' => "Distance", 'Unit Name' => "Pica (1/72 in)", 'AllowPrefix' => FALSE ), 'yr' => array( 'Group' => "Time", 'Unit Name' => "Year", 'AllowPrefix' => FALSE ), 'day' => array( 'Group' => "Time", 'Unit Name' => "Day", 'AllowPrefix' => FALSE ), 'hr' => array( 'Group' => "Time", 'Unit Name' => "Hour", 'AllowPrefix' => FALSE ), 'mn' => array( 'Group' => "Time", 'Unit Name' => "Minute", 'AllowPrefix' => FALSE ), 'sec' => array( 'Group' => "Time", 'Unit Name' => "Second", 'AllowPrefix' => TRUE ), 'Pa' => array( 'Group' => "Pressure", 'Unit Name' => "Pascal", 'AllowPrefix' => TRUE ), 'p' => array( 'Group' => "Pressure", 'Unit Name' => "Pascal", 'AllowPrefix' => TRUE ), 'atm' => array( 'Group' => "Pressure", 'Unit Name' => "Atmosphere", 'AllowPrefix' => TRUE ), 'at' => array( 'Group' => "Pressure", 'Unit Name' => "Atmosphere", 'AllowPrefix' => TRUE ), 'mmHg' => array( 'Group' => "Pressure", 'Unit Name' => "mm of Mercury", 'AllowPrefix' => TRUE ), 'N' => array( 'Group' => "Force", 'Unit Name' => "Newton", 'AllowPrefix' => TRUE ), 'dyn' => array( 'Group' => "Force", 'Unit Name' => "Dyne", 'AllowPrefix' => TRUE ), 'dy' => array( 'Group' => "Force", 'Unit Name' => "Dyne", 'AllowPrefix' => TRUE ), 'lbf' => array( 'Group' => "Force", 'Unit Name' => "Pound force", 'AllowPrefix' => FALSE ), 'J' => array( 'Group' => "Energy", 'Unit Name' => "Joule", 'AllowPrefix' => TRUE ), 'e' => array( 'Group' => "Energy", 'Unit Name' => "Erg", 'AllowPrefix' => TRUE ), 'c' => array( 'Group' => "Energy", 'Unit Name' => "Thermodynamic calorie", 'AllowPrefix' => TRUE ), 'cal' => array( 'Group' => "Energy", 'Unit Name' => "IT calorie", 'AllowPrefix' => TRUE ), 'eV' => array( 'Group' => "Energy", 'Unit Name' => "Electron volt", 'AllowPrefix' => TRUE ), 'ev' => array( 'Group' => "Energy", 'Unit Name' => "Electron volt", 'AllowPrefix' => TRUE ), 'HPh' => array( 'Group' => "Energy", 'Unit Name' => "Horsepower-hour", 'AllowPrefix' => FALSE ), 'hh' => array( 'Group' => "Energy", 'Unit Name' => "Horsepower-hour", 'AllowPrefix' => FALSE ), 'Wh' => array( 'Group' => "Energy", 'Unit Name' => "Watt-hour", 'AllowPrefix' => TRUE ), 'wh' => array( 'Group' => "Energy", 'Unit Name' => "Watt-hour", 'AllowPrefix' => TRUE ), 'flb' => array( 'Group' => "Energy", 'Unit Name' => "Foot-pound", 'AllowPrefix' => FALSE ), 'BTU' => array( 'Group' => "Energy", 'Unit Name' => "BTU", 'AllowPrefix' => FALSE ), 'btu' => array( 'Group' => "Energy", 'Unit Name' => "BTU", 'AllowPrefix' => FALSE ), 'HP' => array( 'Group' => "Power", 'Unit Name' => "Horsepower", 'AllowPrefix' => FALSE ), 'h' => array( 'Group' => "Power", 'Unit Name' => "Horsepower", 'AllowPrefix' => FALSE ), 'W' => array( 'Group' => "Power", 'Unit Name' => "Watt", 'AllowPrefix' => TRUE ), 'w' => array( 'Group' => "Power", 'Unit Name' => "Watt", 'AllowPrefix' => TRUE ), 'T' => array( 'Group' => "Magnetism", 'Unit Name' => "Tesla", 'AllowPrefix' => TRUE ), 'ga' => array( 'Group' => "Magnetism", 'Unit Name' => "Gauss", 'AllowPrefix' => TRUE ), 'C' => array( 'Group' => "Temperature", 'Unit Name' => "Celsius", 'AllowPrefix' => FALSE ), 'cel' => array( 'Group' => "Temperature", 'Unit Name' => "Celsius", 'AllowPrefix' => FALSE ), 'F' => array( 'Group' => "Temperature", 'Unit Name' => "Fahrenheit", 'AllowPrefix' => FALSE ), 'fah' => array( 'Group' => "Temperature", 'Unit Name' => "Fahrenheit", 'AllowPrefix' => FALSE ), 'K' => array( 'Group' => "Temperature", 'Unit Name' => "Kelvin", 'AllowPrefix' => FALSE ), 'kel' => array( 'Group' => "Temperature", 'Unit Name' => "Kelvin", 'AllowPrefix' => FALSE ), 'tsp' => array( 'Group' => "Liquid", 'Unit Name' => "Teaspoon", 'AllowPrefix' => FALSE ), 'tbs' => array( 'Group' => "Liquid", 'Unit Name' => "Tablespoon", 'AllowPrefix' => FALSE ), 'oz' => array( 'Group' => "Liquid", 'Unit Name' => "Fluid Ounce", 'AllowPrefix' => FALSE ), 'cup' => array( 'Group' => "Liquid", 'Unit Name' => "Cup", 'AllowPrefix' => FALSE ), 'pt' => array( 'Group' => "Liquid", 'Unit Name' => "U.S. Pint", 'AllowPrefix' => FALSE ), 'us_pt' => array( 'Group' => "Liquid", 'Unit Name' => "U.S. Pint", 'AllowPrefix' => FALSE ), 'uk_pt' => array( 'Group' => "Liquid", 'Unit Name' => "U.K. Pint", 'AllowPrefix' => FALSE ), 'qt' => array( 'Group' => "Liquid", 'Unit Name' => "Quart", 'AllowPrefix' => FALSE ), 'gal' => array( 'Group' => "Liquid", 'Unit Name' => "Gallon", 'AllowPrefix' => FALSE ), 'l' => array( 'Group' => "Liquid", 'Unit Name' => "Litre", 'AllowPrefix' => TRUE ), 'lt' => array( 'Group' => "Liquid", 'Unit Name' => "Litre", 'AllowPrefix' => TRUE ) );
    private static $_conversionMultipliers = array( 'Y' => array( 'multiplier' => 1e+024, 'name' => "yotta" ), 'Z' => array( 'multiplier' => 1e+021, 'name' => "zetta" ), 'E' => array( 'multiplier' => 1e+018, 'name' => "exa" ), 'P' => array( 'multiplier' => 1e+015, 'name' => "peta" ), 'T' => array( 'multiplier' => 1e+012, 'name' => "tera" ), 'G' => array( 'multiplier' => 1e+009, 'name' => "giga" ), 'M' => array( 'multiplier' => 1e+006, 'name' => "mega" ), 'k' => array( 'multiplier' => 1000, 'name' => "kilo" ), 'h' => array( 'multiplier' => 100, 'name' => "hecto" ), 'e' => array( 'multiplier' => 10, 'name' => "deka" ), 'd' => array( 'multiplier' => 0.1, 'name' => "deci" ), 'c' => array( 'multiplier' => 0.01, 'name' => "centi" ), 'm' => array( 'multiplier' => 0.001, 'name' => "milli" ), 'u' => array( 'multiplier' => 1e-006, 'name' => "micro" ), 'n' => array( 'multiplier' => 1e-009, 'name' => "nano" ), 'p' => array( 'multiplier' => 1e-012, 'name' => "pico" ), 'f' => array( 'multiplier' => 1e-015, 'name' => "femto" ), 'a' => array( 'multiplier' => 1e-018, 'name' => "atto" ), 'z' => array( 'multiplier' => 1e-021, 'name' => "zepto" ), 'y' => array( 'multiplier' => 1e-024, 'name' => "yocto" ) );
    private static $_unitConversions = array( 'Mass' => array( 'g' => array( 'g' => 1, 'sg' => 6.85221e-005, 'lbm' => 0.00220462, 'u' => 6.02217e+023, 'ozm' => 0.035274 ), 'sg' => array( 'g' => 14593.8, 'sg' => 1, 'lbm' => 32.1739, 'u' => 8.78866e+027, 'ozm' => 514.783 ), 'lbm' => array( 'g' => 453.592, 'sg' => 0.0310811, 'lbm' => 1, 'u' => 2.73161e+026, 'ozm' => 16 ), 'u' => array( 'g' => 1.66053e-024, 'sg' => 1.13783e-028, 'lbm' => 3.66084e-027, 'u' => 1, 'ozm' => 5.85735e-026 ), 'ozm' => array( 'g' => 28.3495, 'sg' => 0.00194257, 'lbm' => 0.0625, 'u' => 1.70726e+025, 'ozm' => 1 ) ), 'Distance' => array( 'm' => array( 'm' => 1, 'mi' => 0.000621371, 'Nmi' => 0.000539957, 'in' => 39.3701, 'ft' => 3.28084, 'yd' => 1.09361, 'ang' => 1e+010, 'Pica' => 2834.65 ), 'mi' => array( 'm' => 1609.34, 'mi' => 1, 'Nmi' => 0.868976, 'in' => 63360, 'ft' => 5280, 'yd' => 1760, 'ang' => 1.60934e+013, 'Pica' => 4.56192e+006 ), 'Nmi' => array( 'm' => 1852, 'mi' => 1.15078, 'Nmi' => 1, 'in' => 72913.4, 'ft' => 6076.12, 'yd' => 2025.37, 'ang' => 1.852e+013, 'Pica' => 5.24976e+006 ), 'in' => array( 'm' => 0.0254, 'mi' => 1.57828e-005, 'Nmi' => 1.37149e-005, 'in' => 1, 'ft' => 0.0833333, 'yd' => 0.0277778, 'ang' => 2.54e+008, 'Pica' => 72 ), 'ft' => array( 'm' => 0.3048, 'mi' => 0.000189394, 'Nmi' => 0.000164579, 'in' => 12, 'ft' => 1, 'yd' => 0.333333, 'ang' => 3.048e+009, 'Pica' => 864 ), 'yd' => array( 'm' => 0.9144, 'mi' => 0.000568182, 'Nmi' => 0.000493737, 'in' => 36, 'ft' => 3, 'yd' => 1, 'ang' => 9.144e+009, 'Pica' => 2592 ), 'ang' => array( 'm' => 1e-010, 'mi' => 6.21371e-014, 'Nmi' => 5.39957e-014, 'in' => 3.93701e-009, 'ft' => 3.28084e-010, 'yd' => 1.09361e-010, 'ang' => 1, 'Pica' => 2.83465e-007 ), 'Pica' => array( 'm' => 0.000352778, 'mi' => 2.19206e-007, 'Nmi' => 1.90485e-007, 'in' => 0.0138889, 'ft' => 0.00115741, 'yd' => 0.000385802, 'ang' => 3.52778e+006, 'Pica' => 1 ) ), 'Time' => array( 'yr' => array( 'yr' => 1, 'day' => 365.25, 'hr' => 8766, 'mn' => 525960, 'sec' => 3.15576e+007 ), 'day' => array( 'yr' => 0.00273785, 'day' => 1, 'hr' => 24, 'mn' => 1440, 'sec' => 86400 ), 'hr' => array( 'yr' => 0.000114077, 'day' => 0.0416667, 'hr' => 1, 'mn' => 60, 'sec' => 3600 ), 'mn' => array( 'yr' => 1.90129e-006, 'day' => 0.000694444, 'hr' => 0.0166667, 'mn' => 1, 'sec' => 60 ), 'sec' => array( 'yr' => 3.16881e-008, 'day' => 1.15741e-005, 'hr' => 0.000277778, 'mn' => 0.0166667, 'sec' => 1 ) ), 'Pressure' => array( 'Pa' => array( 'Pa' => 1, 'p' => 1, 'atm' => 9.86923e-006, 'at' => 9.86923e-006, 'mmHg' => 0.00750062 ), 'p' => array( 'Pa' => 1, 'p' => 1, 'atm' => 9.86923e-006, 'at' => 9.86923e-006, 'mmHg' => 0.00750062 ), 'atm' => array( 'Pa' => 101325, 'p' => 101325, 'atm' => 1, 'at' => 1, 'mmHg' => 760 ), 'at' => array( 'Pa' => 101325, 'p' => 101325, 'atm' => 1, 'at' => 1, 'mmHg' => 760 ), 'mmHg' => array( 'Pa' => 133.322, 'p' => 133.322, 'atm' => 0.00131579, 'at' => 0.00131579, 'mmHg' => 1 ) ), 'Force' => array( 'N' => array( 'N' => 1, 'dyn' => 100000, 'dy' => 100000, 'lbf' => 0.224809 ), 'dyn' => array( 'N' => 1e-005, 'dyn' => 1, 'dy' => 1, 'lbf' => 2.24809e-006 ), 'dy' => array( 'N' => 1e-005, 'dyn' => 1, 'dy' => 1, 'lbf' => 2.24809e-006 ), 'lbf' => array( 'N' => 4.44822, 'dyn' => 444822, 'dy' => 444822, 'lbf' => 1 ) ), 'Energy' => array( 'J' => array( 'J' => 1, 'e' => 1e+007, 'c' => 0.239006, 'cal' => 0.238846, 'eV' => 6.24146e+018, 'ev' => 6.24146e+018, 'HPh' => 3.72506e-007, 'hh' => 3.72506e-007, 'Wh' => 0.000277778, 'wh' => 0.000277778, 'flb' => 23.7304, 'BTU' => 0.000947815, 'btu' => 0.000947815 ), 'e' => array( 'J' => 1e-007, 'e' => 1, 'c' => 2.39006e-008, 'cal' => 2.38846e-008, 'eV' => 6.24146e+011, 'ev' => 6.24146e+011, 'HPh' => 3.72507e-014, 'hh' => 3.72507e-014, 'Wh' => 2.77778e-011, 'wh' => 2.77778e-011, 'flb' => 2.37304e-006, 'BTU' => 9.47816e-011, 'btu' => 9.47816e-011 ), 'c' => array( 'J' => 4.18399, 'e' => 4.18399e+007, 'c' => 1, 'cal' => 0.99933, 'eV' => 2.61142e+019, 'ev' => 2.61142e+019, 'HPh' => 1.55856e-006, 'hh' => 1.55856e-006, 'Wh' => 0.00116222, 'wh' => 0.00116222, 'flb' => 99.2879, 'BTU' => 0.00396565, 'btu' => 0.00396565 ), 'cal' => array( 'J' => 4.18679, 'e' => 4.18679e+007, 'c' => 1.00067, 'cal' => 1, 'eV' => 2.61317e+019, 'ev' => 2.61317e+019, 'HPh' => 1.55961e-006, 'hh' => 1.55961e-006, 'Wh' => 0.001163, 'wh' => 0.001163, 'flb' => 99.3544, 'BTU' => 0.00396831, 'btu' => 0.00396831 ), 'eV' => array( 'J' => 1.60219e-019, 'e' => 1.60219e-012, 'c' => 3.82933e-020, 'cal' => 3.82677e-020, 'eV' => 1, 'ev' => 1, 'HPh' => 5.96826e-026, 'hh' => 5.96826e-026, 'Wh' => 4.45053e-023, 'wh' => 4.45053e-023, 'flb' => 3.80206e-018, 'BTU' => 1.51858e-022, 'btu' => 1.51858e-022 ), 'ev' => array( 'J' => 1.60219e-019, 'e' => 1.60219e-012, 'c' => 3.82933e-020, 'cal' => 3.82677e-020, 'eV' => 1, 'ev' => 1, 'HPh' => 5.96826e-026, 'hh' => 5.96826e-026, 'Wh' => 4.45053e-023, 'wh' => 4.45053e-023, 'flb' => 3.80206e-018, 'BTU' => 1.51858e-022, 'btu' => 1.51858e-022 ), 'HPh' => array( 'J' => 2.68452e+006, 'e' => 2.68452e+013, 'c' => 641616, 'cal' => 641187, 'eV' => 1.67553e+025, 'ev' => 1.67553e+025, 'HPh' => 1, 'hh' => 1, 'Wh' => 745.7, 'wh' => 745.7, 'flb' => 6.37047e+007, 'BTU' => 2544.43, 'btu' => 2544.43 ), 'hh' => array( 'J' => 2.68452e+006, 'e' => 2.68452e+013, 'c' => 641616, 'cal' => 641187, 'eV' => 1.67553e+025, 'ev' => 1.67553e+025, 'HPh' => 1, 'hh' => 1, 'Wh' => 745.7, 'wh' => 745.7, 'flb' => 6.37047e+007, 'BTU' => 2544.43, 'btu' => 2544.43 ), 'Wh' => array( 'J' => 3600, 'e' => 3.6e+010, 'c' => 860.422, 'cal' => 859.846, 'eV' => 2.24692e+022, 'ev' => 2.24692e+022, 'HPh' => 0.00134102, 'hh' => 0.00134102, 'Wh' => 1, 'wh' => 1, 'flb' => 85429.5, 'BTU' => 3.41213, 'btu' => 3.41213 ), 'wh' => array( 'J' => 3600, 'e' => 3.6e+010, 'c' => 860.422, 'cal' => 859.846, 'eV' => 2.24692e+022, 'ev' => 2.24692e+022, 'HPh' => 0.00134102, 'hh' => 0.00134102, 'Wh' => 1, 'wh' => 1, 'flb' => 85429.5, 'BTU' => 3.41213, 'btu' => 3.41213 ), 'flb' => array( 'J' => 0.04214, 'e' => 421400, 'c' => 0.0100717, 'cal' => 0.010065, 'eV' => 2.63015e+017, 'ev' => 2.63015e+017, 'HPh' => 1.56974e-008, 'hh' => 1.56974e-008, 'Wh' => 1.17056e-005, 'wh' => 1.17056e-005, 'flb' => 1, 'BTU' => 3.99409e-005, 'btu' => 3.99409e-005 ), 'BTU' => array( 'J' => 1055.06, 'e' => 1.05506e+010, 'c' => 252.165, 'cal' => 251.997, 'eV' => 6.5851e+021, 'ev' => 6.5851e+021, 'HPh' => 0.000393016, 'hh' => 0.000393016, 'Wh' => 0.293072, 'wh' => 0.293072, 'flb' => 25037, 'BTU' => 1, 'btu' => 1 ), 'btu' => array( 'J' => 1055.06, 'e' => 1.05506e+010, 'c' => 252.165, 'cal' => 251.997, 'eV' => 6.5851e+021, 'ev' => 6.5851e+021, 'HPh' => 0.000393016, 'hh' => 0.000393016, 'Wh' => 0.293072, 'wh' => 0.293072, 'flb' => 25037, 'BTU' => 1, 'btu' => 1 ) ), 'Power' => array( 'HP' => array( 'HP' => 1, 'h' => 1, 'W' => 745.701, 'w' => 745.701 ), 'h' => array( 'HP' => 1, 'h' => 1, 'W' => 745.701, 'w' => 745.701 ), 'W' => array( 'HP' => 0.00134102, 'h' => 0.00134102, 'W' => 1, 'w' => 1 ), 'w' => array( 'HP' => 0.00134102, 'h' => 0.00134102, 'W' => 1, 'w' => 1 ) ), 'Magnetism' => array( 'T' => array( 'T' => 1, 'ga' => 10000 ), 'ga' => array( 'T' => 0.0001, 'ga' => 1 ) ), 'Liquid' => array( 'tsp' => array( 'tsp' => 1, 'tbs' => 0.333333, 'oz' => 0.166667, 'cup' => 0.0208333, 'pt' => 0.0104167, 'us_pt' => 0.0104167, 'uk_pt' => 0.00867559, 'qt' => 0.00520833, 'gal' => 0.00130208, 'l' => 0.00492999, 'lt' => 0.00492999 ), 'tbs' => array( 'tsp' => 3, 'tbs' => 1, 'oz' => 0.5, 'cup' => 0.0625, 'pt' => 0.03125, 'us_pt' => 0.03125, 'uk_pt' => 0.0260268, 'qt' => 0.015625, 'gal' => 0.00390625, 'l' => 0.01479, 'lt' => 0.01479 ), 'oz' => array( 'tsp' => 6, 'tbs' => 2, 'oz' => 1, 'cup' => 0.125, 'pt' => 0.0625, 'us_pt' => 0.0625, 'uk_pt' => 0.0520535, 'qt' => 0.03125, 'gal' => 0.0078125, 'l' => 0.02958, 'lt' => 0.02958 ), 'cup' => array( 'tsp' => 48, 'tbs' => 16, 'oz' => 8, 'cup' => 1, 'pt' => 0.5, 'us_pt' => 0.5, 'uk_pt' => 0.416428, 'qt' => 0.25, 'gal' => 0.0625, 'l' => 0.23664, 'lt' => 0.23664 ), 'pt' => array( 'tsp' => 96, 'tbs' => 32, 'oz' => 16, 'cup' => 2, 'pt' => 1, 'us_pt' => 1, 'uk_pt' => 0.832856, 'qt' => 0.5, 'gal' => 0.125, 'l' => 0.473279, 'lt' => 0.473279 ), 'us_pt' => array( 'tsp' => 96, 'tbs' => 32, 'oz' => 16, 'cup' => 2, 'pt' => 1, 'us_pt' => 1, 'uk_pt' => 0.832856, 'qt' => 0.5, 'gal' => 0.125, 'l' => 0.473279, 'lt' => 0.473279 ), 'uk_pt' => array( 'tsp' => 115.266, 'tbs' => 38.422, 'oz' => 19.211, 'cup' => 2.40137, 'pt' => 1.20069, 'us_pt' => 1.20069, 'uk_pt' => 1, 'qt' => 0.600344, 'gal' => 0.150086, 'l' => 0.568261, 'lt' => 0.568261 ), 'qt' => array( 'tsp' => 192, 'tbs' => 64, 'oz' => 32, 'cup' => 4, 'pt' => 2, 'us_pt' => 2, 'uk_pt' => 1.66571, 'qt' => 1, 'gal' => 0.25, 'l' => 0.946559, 'lt' => 0.946559 ), 'gal' => array( 'tsp' => 768, 'tbs' => 256, 'oz' => 128, 'cup' => 16, 'pt' => 8, 'us_pt' => 8, 'uk_pt' => 6.66285, 'qt' => 4, 'gal' => 1, 'l' => 3.78624, 'lt' => 3.78624 ), 'l' => array( 'tsp' => 202.84, 'tbs' => 67.6133, 'oz' => 33.8067, 'cup' => 4.22583, 'pt' => 2.11292, 'us_pt' => 2.11292, 'uk_pt' => 1.75976, 'qt' => 1.05646, 'gal' => 0.264115, 'l' => 1, 'lt' => 1 ), 'lt' => array( 'tsp' => 202.84, 'tbs' => 67.6133, 'oz' => 33.8067, 'cup' => 4.22583, 'pt' => 2.11292, 'us_pt' => 2.11292, 'uk_pt' => 1.75976, 'qt' => 1.05646, 'gal' => 0.264115, 'l' => 1, 'lt' => 1 ) ) );
    private static $_two_sqrtpi = 1.12838;
    private static $_one_sqrtpi = 0.56419;

    public static function _parseComplex( $complexNumber )
    {
        $workString = ( boolean );
        $realNumber = $imaginary = 0;
        $suffix = substr( $workString, -1 );
        if ( is_numeric( $suffix ) )
        {
            $workString = substr( $workString, 0, -1 );
        }
        else
        {
            $suffix = "";
        }
        $leadingSign = 0;
        $leadingSign = 0;
        $power = "";
        $realNumber = strtok( $workString, "+-" );
        if ( strtoupper( substr( $realNumber, -1 ) ) == "E" )
        {
            $power = strtok( "+-" );
            ++$leadingSign;
        }
        $realNumber = substr( $workString, 0, strlen( $realNumber ) + strlen( $power ) + $leadingSign );
        if ( $suffix != "" )
        {
            $imaginary = substr( $workString, strlen( $realNumber ) );
            if ( $realNumber == "-" )
            {
                $imaginary = $realNumber."1";
                $realNumber = "0";
            }
            else if ( $imaginary == "" )
            {
                $imaginary = $realNumber;
                $realNumber = "0";
            }
            else if ( $imaginary == "-" )
            {
                $imaginary .= "1";
            }
        }
        return array( "real" => $realNumber, "imaginary" => $imaginary, "suffix" => $suffix );
    }

    private static function _cleanComplex( $complexNumber )
    {
        if ( $complexNumber[0] == "+" )
        {
            $complexNumber = substr( $complexNumber, 1 );
        }
        if ( $complexNumber[0] == "0" )
        {
            $complexNumber = substr( $complexNumber, 1 );
        }
        if ( $complexNumber[0] == "." )
        {
            $complexNumber = "0".$complexNumber;
        }
        if ( $complexNumber[0] == "+" )
        {
            $complexNumber = substr( $complexNumber, 1 );
        }
        return $complexNumber;
    }

    private static function _nbrConversionFormat( $xVal, $places )
    {
        if ( is_null( $places ) )
        {
            if ( strlen( $xVal ) <= $places )
            {
                return substr( str_pad( $xVal, $places, "0", STR_PAD_LEFT ), -10 );
            }
            return ( );
        }
        return substr( $xVal, -10 );
    }

    public static function BESSELI( $x, $ord )
    {
        $x = is_null( $x ) ? 0 : ( $x );
        $ord = is_null( $ord ) ? 0 : ( $ord );
        if ( is_numeric( $x ) && is_numeric( $ord ) )
        {
            $ord = floor( $ord );
            if ( $ord < 0 )
            {
                return ( );
            }
            if ( abs( $x ) <= 30 )
            {
                $fResult = $fTerm = pow( $x / 2, $ord ) / ( $ord );
                $ordK = 1;
                $fSqrX = $x * $x / 4;
                $fTerm *= $fSqrX;
                $fTerm /= $ordK * ( $ordK + $ord );
                $fResult += $fTerm;
            }
            else
            {
                $f_2_PI = 2 * M_PI;
                $fXAbs = abs( $x );
                $fResult = exp( $fXAbs ) / sqrt( $f_2_PI * $fXAbs );
                if ( $ord & 1 && $x < 0 )
                {
                    $fResult = 0 - $fResult;
                }
            }
            if ( is_nan( $fResult ) )
            {
                return ( );
            }
            return $fResult;
        }
        return ( );
    }

    public static function BESSELJ( $x, $ord )
    {
        $x = is_null( $x ) ? 0 : ( $x );
        $ord = is_null( $ord ) ? 0 : ( $ord );
        if ( is_numeric( $x ) && is_numeric( $ord ) )
        {
            $ord = floor( $ord );
            if ( $ord < 0 )
            {
                return ( );
            }
            $fResult = 0;
            if ( abs( $x ) <= 30 )
            {
                $fResult = $fTerm = pow( $x / 2, $ord ) / ( $ord );
                $ordK = 1;
                $fSqrX = $x * $x / -4;
                $fTerm *= $fSqrX;
                $fTerm /= $ordK * ( $ordK + $ord );
                $fResult += $fTerm;
            }
            else
            {
                $f_PI_DIV_2 = M_PI / 2;
                $f_PI_DIV_4 = M_PI / 4;
                $fXAbs = abs( $x );
                $fResult = sqrt( M_2DIVPI / $fXAbs ) * cos( $fXAbs - $ord * $f_PI_DIV_2 - $f_PI_DIV_4 );
                if ( $ord & 1 && $x < 0 )
                {
                    $fResult = 0 - $fResult;
                }
            }
            if ( is_nan( $fResult ) )
            {
                return ( );
            }
            return $fResult;
        }
        return ( );
    }

    private static function _Besselk0( $fNum )
    {
        if ( $fNum <= 2 )
        {
            $fNum2 = $fNum * 0.5;
            $y = $fNum2 * $fNum2;
            $fRet = 0 - log( $fNum2 ) * ( $fNum, 0 ) + ( -0.577216 + $y * ( 0.422784 + $y * ( 0.230698 + $y * ( 0.0348859 + $y * ( 0.00262698 + $y * ( 0.0001075 + $y * 7.4e-006 ) ) ) ) ) );
            return $fRet;
        }
        $y = 2 / $fNum;
        $fRet = exp( 0 - $fNum ) / sqrt( $fNum ) * ( 1.25331 + $y * ( -0.0783236 + $y * ( 0.0218957 + $y * ( -0.0106245 + $y * ( 0.00587872 + $y * ( -0.0025154 + $y * 0.00053208 ) ) ) ) ) );
        return $fRet;
    }

    private static function _Besselk1( $fNum )
    {
        if ( $fNum <= 2 )
        {
            $fNum2 = $fNum * 0.5;
            $y = $fNum2 * $fNum2;
            $fRet = log( $fNum2 ) * ( $fNum, 1 ) + ( 1 + $y * ( 0.154431 + $y * ( -0.672786 + $y * ( -0.181569 + $y * ( -0.019194 + $y * ( -0.00110404 + $y * -4.686e-005 ) ) ) ) ) ) / $fNum;
            return $fRet;
        }
        $y = 2 / $fNum;
        $fRet = exp( 0 - $fNum ) / sqrt( $fNum ) * ( 1.25331 + $y * ( 0.234986 + $y * ( -0.0365562 + $y * ( 0.0150427 + $y * ( -0.00780353 + $y * ( 0.00325614 + $y * -0.00068245 ) ) ) ) ) );
        return $fRet;
    }

    public static function BESSELK( $x, $ord )
    {
        $x = is_null( $x ) ? 0 : ( $x );
        $ord = is_null( $ord ) ? 0 : ( $ord );
        if ( is_numeric( $x ) && is_numeric( $ord ) )
        {
            if ( $ord < 0 || $x == 0 )
            {
                return ( );
            }
            switch ( floor( $ord ) )
            {
                case 0 :
                    return ( $x );
                case 1 :
                    return ( $x );
            }
            $fTox = 2 / $x;
            $fBkm = ( $x );
            $fBk = ( $x );
            $n = 1;
            for ( ; $n < $ord; ++$n )
            {
                $fBkp = $fBkm + $n * $fTox * $fBk;
                $fBkm = $fBk;
                $fBk = $fBkp;
            }
            if ( is_nan( $fBk ) )
            {
                return ( );
            }
            return $fBk;
        }
        return ( );
    }

    private static function _Bessely0( $fNum )
    {
        if ( $fNum < 8 )
        {
            $y = $fNum * $fNum;
            $f1 = -2.95782e+009 + $y * ( 7.06283e+009 + $y * ( -5.1236e+008 + $y * ( 1.08799e+007 + $y * ( -86327.9 + $y * 228.462 ) ) ) );
            $f2 = 4.00765e+010 + $y * ( 7.4525e+008 + $y * ( 7.18947e+006 + $y * ( 47447.3 + $y * ( 226.103 + $y ) ) ) );
            $fRet = $f1 / $f2 + 0.63662 * ( $fNum, 0 ) * log( $fNum );
            return $fRet;
        }
        $z = 8 / $fNum;
        $y = $z * $z;
        $xx = $fNum - 0.785398;
        $f1 = 1 + $y * ( -0.00109863 + $y * ( 2.73451e-005 + $y * ( -2.07337e-006 + $y * 2.09389e-007 ) ) );
        $f2 = -0.015625 + $y * ( 0.000143049 + $y * ( -6.91115e-006 + $y * ( 7.6211e-007 + $y * -9.34945e-008 ) ) );
        $fRet = sqrt( 0.63662 / $fNum ) * ( sin( $xx ) * $f1 + $z * cos( $xx ) * $f2 );
        return $fRet;
    }

    private static function _Bessely1( $fNum )
    {
        if ( $fNum < 8 )
        {
            $y = $fNum * $fNum;
            $f1 = $fNum * ( -4.9006e+012 + $y * ( 1.27527e+012 + $y * ( -5.15344e+010 + $y * ( 7.34926e+008 + $y * ( -4.23792e+006 + $y * 8511.94 ) ) ) ) );
            $f2 = 2.49958e+013 + $y * ( 4.24442e+011 + $y * ( 3.73365e+009 + $y * ( 2.2459e+007 + $y * ( 102043 + $y * ( 354.963 + $y ) ) ) ) );
            $fRet = $f1 / $f2 + 0.63662 * ( ( $fNum, 1 ) * log( $fNum ) - 1 / $fNum );
            return $fRet;
        }
        $fRet = sqrt( 0.63662 / $fNum ) * sin( $fNum - 2.35619 );
        return $fRet;
    }

    public static function BESSELY( $x, $ord )
    {
        $x = is_null( $x ) ? 0 : ( $x );
        $ord = is_null( $ord ) ? 0 : ( $ord );
        if ( is_numeric( $x ) && is_numeric( $ord ) )
        {
            if ( $ord < 0 || $x == 0 )
            {
                return ( );
            }
            switch ( floor( $ord ) )
            {
                case 0 :
                    return ( $x );
                case 1 :
                    return ( $x );
            }
            $fTox = 2 / $x;
            $fBym = ( $x );
            $fBy = ( $x );
            $n = 1;
            for ( ; $n < $ord; ++$n )
            {
                $fByp = $n * $fTox * $fBy - $fBym;
                $fBym = $fBy;
                $fBy = $fByp;
            }
            if ( is_nan( $fBy ) )
            {
                return ( );
            }
            return $fBy;
        }
        return ( );
    }

    public static function BINTODEC( $x )
    {
        $x = ( $x );
        if ( is_bool( $x ) )
        {
            if ( ( ) == PHPExcel_Calculation_Functions::COMPATIBILITY_OPENOFFICE )
            {
                $x = ( integer );
            }
            else
            {
                return ( );
            }
        }
        if ( ( ) == PHPExcel_Calculation_Functions::COMPATIBILITY_GNUMERIC )
        {
            $x = floor( $x );
        }
        $x = ( boolean );
        if ( preg_match_all( "/[01]/", $x, $out ) < strlen( $x ) )
        {
            return ( );
        }
        if ( 10 < strlen( $x ) )
        {
            return ( );
        }
        if ( strlen( $x ) == 10 )
        {
            $x = substr( $x, -9 );
            return "-".( 512 - bindec( $x ) );
        }
        return bindec( $x );
    }

    public static function BINTOHEX( $x, $places = NULL )
    {
        $x = ( $x );
        $places = ( $places );
        if ( is_bool( $x ) )
        {
            if ( ( ) == PHPExcel_Calculation_Functions::COMPATIBILITY_OPENOFFICE )
            {
                $x = ( integer );
            }
            else
            {
                return ( );
            }
        }
        if ( ( ) == PHPExcel_Calculation_Functions::COMPATIBILITY_GNUMERIC )
        {
            $x = floor( $x );
        }
        $x = ( boolean );
        if ( preg_match_all( "/[01]/", $x, $out ) < strlen( $x ) )
        {
            return ( );
        }
        if ( 10 < strlen( $x ) )
        {
            return ( );
        }
        if ( strlen( $x ) == 10 )
        {
            return str_repeat( "F", 8 ).substr( strtoupper( dechex( bindec( substr( $x, -9 ) ) ) ), -2 );
        }
        $hexVal = ( boolean );
        return ( $hexVal, $places );
    }

    public static function BINTOOCT( $x, $places = NULL )
    {
        $x = ( $x );
        $places = ( $places );
        if ( is_bool( $x ) )
        {
            if ( ( ) == PHPExcel_Calculation_Functions::COMPATIBILITY_OPENOFFICE )
            {
                $x = ( integer );
            }
            else
            {
                return ( );
            }
        }
        if ( ( ) == PHPExcel_Calculation_Functions::COMPATIBILITY_GNUMERIC )
        {
            $x = floor( $x );
        }
        $x = ( boolean );
        if ( preg_match_all( "/[01]/", $x, $out ) < strlen( $x ) )
        {
            return ( );
        }
        if ( 10 < strlen( $x ) )
        {
            return ( );
        }
        if ( strlen( $x ) == 10 )
        {
            return str_repeat( "7", 7 ).substr( strtoupper( decoct( bindec( substr( $x, -9 ) ) ) ), -3 );
        }
        $octVal = ( boolean );
        return ( $octVal, $places );
    }

    public static function DECTOBIN( $x, $places = NULL )
    {
        $x = ( $x );
        $places = ( $places );
        if ( is_bool( $x ) )
        {
            if ( ( ) == PHPExcel_Calculation_Functions::COMPATIBILITY_OPENOFFICE )
            {
                $x = ( integer );
            }
            else
            {
                return ( );
            }
        }
        $x = ( boolean );
        if ( preg_match_all( "/[-0123456789.]/", $x, $out ) < strlen( $x ) )
        {
            return ( );
        }
        $x = ( boolean );
        $r = decbin( $x );
        if ( strlen( $r ) == 32 )
        {
            $r = substr( $r, -10 );
        }
        else
        {
            if ( 11 < strlen( $r ) )
            {
                return ( );
            }
        }
        return ( $r, $places );
    }

    public static function DECTOHEX( $x, $places = NULL )
    {
        $x = ( $x );
        $places = ( $places );
        if ( is_bool( $x ) )
        {
            if ( ( ) == PHPExcel_Calculation_Functions::COMPATIBILITY_OPENOFFICE )
            {
                $x = ( integer );
            }
            else
            {
                return ( );
            }
        }
        $x = ( boolean );
        if ( preg_match_all( "/[-0123456789.]/", $x, $out ) < strlen( $x ) )
        {
            return ( );
        }
        $x = ( boolean );
        $r = strtoupper( dechex( $x ) );
        if ( strlen( $r ) == 8 )
        {
            $r = "FF".$r;
        }
        return ( $r, $places );
    }

    public static function DECTOOCT( $x, $places = NULL )
    {
        $x = ( $x );
        $places = ( $places );
        if ( is_bool( $x ) )
        {
            if ( ( ) == PHPExcel_Calculation_Functions::COMPATIBILITY_OPENOFFICE )
            {
                $x = ( integer );
            }
            else
            {
                return ( );
            }
        }
        $x = ( boolean );
        if ( preg_match_all( "/[-0123456789.]/", $x, $out ) < strlen( $x ) )
        {
            return ( );
        }
        $x = ( boolean );
        $r = decoct( $x );
        if ( strlen( $r ) == 11 )
        {
            $r = substr( $r, -10 );
        }
        return ( $r, $places );
    }

    public static function HEXTOBIN( $x, $places = NULL )
    {
        $x = ( $x );
        $places = ( $places );
        if ( is_bool( $x ) )
        {
            return ( );
        }
        $x = ( boolean );
        if ( preg_match_all( "/[0123456789ABCDEF]/", strtoupper( $x ), $out ) < strlen( $x ) )
        {
            return ( );
        }
        $binVal = decbin( hexdec( $x ) );
        return substr( ( $binVal, $places ), -10 );
    }

    public static function HEXTODEC( $x )
    {
        $x = ( $x );
        if ( is_bool( $x ) )
        {
            return ( );
        }
        $x = ( boolean );
        if ( preg_match_all( "/[0123456789ABCDEF]/", strtoupper( $x ), $out ) < strlen( $x ) )
        {
            return ( );
        }
        return hexdec( $x );
    }

    public static function HEXTOOCT( $x, $places = NULL )
    {
        $x = ( $x );
        $places = ( $places );
        if ( is_bool( $x ) )
        {
            return ( );
        }
        $x = ( boolean );
        if ( preg_match_all( "/[0123456789ABCDEF]/", strtoupper( $x ), $out ) < strlen( $x ) )
        {
            return ( );
        }
        $octVal = decoct( hexdec( $x ) );
        return ( $octVal, $places );
    }

    public static function OCTTOBIN( $x, $places = NULL )
    {
        $x = ( $x );
        $places = ( $places );
        if ( is_bool( $x ) )
        {
            return ( );
        }
        $x = ( boolean );
        if ( preg_match_all( "/[01234567]/", $x, $out ) != strlen( $x ) )
        {
            return ( );
        }
        $r = decbin( octdec( $x ) );
        return ( $r, $places );
    }

    public static function OCTTODEC( $x )
    {
        $x = ( $x );
        if ( is_bool( $x ) )
        {
            return ( );
        }
        $x = ( boolean );
        if ( preg_match_all( "/[01234567]/", $x, $out ) != strlen( $x ) )
        {
            return ( );
        }
        return octdec( $x );
    }

    public static function OCTTOHEX( $x, $places = NULL )
    {
        $x = ( $x );
        $places = ( $places );
        if ( is_bool( $x ) )
        {
            return ( );
        }
        $x = ( boolean );
        if ( preg_match_all( "/[01234567]/", $x, $out ) != strlen( $x ) )
        {
            return ( );
        }
        $hexVal = strtoupper( dechex( octdec( $x ) ) );
        return ( $hexVal, $places );
    }

    public static function COMPLEX( $realNumber = 0, $imaginary = 0, $suffix = "i" )
    {
        $realNumber = is_null( $realNumber ) ? 0 : ( $realNumber );
        $imaginary = is_null( $imaginary ) ? 0 : ( $imaginary );
        $suffix = is_null( $suffix ) ? "i" : ( $suffix );
        if ( is_numeric( $realNumber ) && is_numeric( $imaginary ) && ( $suffix == "i" || $suffix == "j" || $suffix == "" ) )
        {
            $realNumber = ( double );
            $imaginary = ( double );
            if ( $suffix == "" )
            {
                $suffix = "i";
            }
            if ( $realNumber == 0 )
            {
                if ( $imaginary == 0 )
                {
                    return "0";
                }
                if ( $imaginary == 1 )
                {
                    return ( boolean );
                }
                if ( $imaginary == -1 )
                {
                    return "-".$suffix;
                }
                return ( boolean ).$suffix;
            }
            if ( $imaginary == 0 )
            {
                return ( boolean );
            }
            if ( $imaginary == 1 )
            {
                return ( boolean )."+".$suffix;
            }
            if ( $imaginary == -1 )
            {
                return ( boolean )."-".$suffix;
            }
            if ( 0 < $imaginary )
            {
                $imaginary = "+".$imaginary;
            }
            return ( boolean ).$imaginary.$suffix;
        }
        return ( );
    }

    public static function IMAGINARY( $complexNumber )
    {
        $complexNumber = ( $complexNumber );
        $parsedComplex = ( $complexNumber );
        return $parsedComplex['imaginary'];
    }

    public static function IMREAL( $complexNumber )
    {
        $complexNumber = ( $complexNumber );
        $parsedComplex = ( $complexNumber );
        return $parsedComplex['real'];
    }

    public static function IMABS( $complexNumber )
    {
        $complexNumber = ( $complexNumber );
        $parsedComplex = ( $complexNumber );
        return sqrt( $parsedComplex['real'] * $parsedComplex['real'] + $parsedComplex['imaginary'] * $parsedComplex['imaginary'] );
    }

    public static function IMARGUMENT( $complexNumber )
    {
        $complexNumber = ( $complexNumber );
        $parsedComplex = ( $complexNumber );
        if ( $parsedComplex['real'] == 0 )
        {
            if ( $parsedComplex['imaginary'] == 0 )
            {
                return 0;
            }
            if ( $parsedComplex['imaginary'] < 0 )
            {
                return M_PI / -2;
            }
            return M_PI / 2;
        }
        if ( 0 < $parsedComplex['real'] )
        {
            return atan( $parsedComplex['imaginary'] / $parsedComplex['real'] );
        }
        if ( $parsedComplex['imaginary'] < 0 )
        {
            return 0 - ( M_PI - atan( abs( $parsedComplex['imaginary'] ) / abs( $parsedComplex['real'] ) ) );
        }
        return M_PI - atan( $parsedComplex['imaginary'] / abs( $parsedComplex['real'] ) );
    }

    public static function IMCONJUGATE( $complexNumber )
    {
        $complexNumber = ( $complexNumber );
        $parsedComplex = ( $complexNumber );
        if ( $parsedComplex['imaginary'] == 0 )
        {
            return $parsedComplex['real'];
        }
        return ( ( $parsedComplex['real'], 0 - $parsedComplex['imaginary'], $parsedComplex['suffix'] ) );
    }

    public static function IMCOS( $complexNumber )
    {
        $complexNumber = ( $complexNumber );
        $parsedComplex = ( $complexNumber );
        if ( $parsedComplex['imaginary'] == 0 )
        {
            return cos( $parsedComplex['real'] );
        }
        return ( ( cos( $parsedComplex['real'] ) * cosh( $parsedComplex['imaginary'] ), sin( $parsedComplex['real'] ) * sinh( $parsedComplex['imaginary'] ), $parsedComplex['suffix'] ) );
    }

    public static function IMSIN( $complexNumber )
    {
        $complexNumber = ( $complexNumber );
        $parsedComplex = ( $complexNumber );
        if ( $parsedComplex['imaginary'] == 0 )
        {
            return sin( $parsedComplex['real'] );
        }
        return ( sin( $parsedComplex['real'] ) * cosh( $parsedComplex['imaginary'] ), cos( $parsedComplex['real'] ) * sinh( $parsedComplex['imaginary'] ), $parsedComplex['suffix'] );
    }

    public static function IMSQRT( $complexNumber )
    {
        $complexNumber = ( $complexNumber );
        $parsedComplex = ( $complexNumber );
        $theta = ( $complexNumber );
        $d1 = cos( $theta / 2 );
        $d2 = sin( $theta / 2 );
        $r = sqrt( sqrt( $parsedComplex['real'] * $parsedComplex['real'] + $parsedComplex['imaginary'] * $parsedComplex['imaginary'] ) );
        if ( $parsedComplex['suffix'] == "" )
        {
            return ( $d1 * $r, $d2 * $r );
        }
        return ( $d1 * $r, $d2 * $r, $parsedComplex['suffix'] );
    }

    public static function IMLN( $complexNumber )
    {
        $complexNumber = ( $complexNumber );
        $parsedComplex = ( $complexNumber );
        if ( $parsedComplex['real'] == 0 && $parsedComplex['imaginary'] == 0 )
        {
            return ( );
        }
        $logR = log( sqrt( $parsedComplex['real'] * $parsedComplex['real'] + $parsedComplex['imaginary'] * $parsedComplex['imaginary'] ) );
        $t = ( $complexNumber );
        if ( $parsedComplex['suffix'] == "" )
        {
            return ( $logR, $t );
        }
        return ( $logR, $t, $parsedComplex['suffix'] );
    }

    public static function IMLOG10( $complexNumber )
    {
        $complexNumber = ( $complexNumber );
        $parsedComplex = ( $complexNumber );
        if ( $parsedComplex['real'] == 0 && $parsedComplex['imaginary'] == 0 )
        {
            return ( );
        }
        if ( 0 < $parsedComplex['real'] && $parsedComplex['imaginary'] == 0 )
        {
            return log10( $parsedComplex['real'] );
        }
        return ( log10( EULER ), ( $complexNumber ) );
    }

    public static function IMLOG2( $complexNumber )
    {
        $complexNumber = ( $complexNumber );
        $parsedComplex = ( $complexNumber );
        if ( $parsedComplex['real'] == 0 && $parsedComplex['imaginary'] == 0 )
        {
            return ( );
        }
        if ( 0 < $parsedComplex['real'] && $parsedComplex['imaginary'] == 0 )
        {
            return log( $parsedComplex['real'], 2 );
        }
        return ( log( EULER, 2 ), ( $complexNumber ) );
    }

    public static function IMEXP( $complexNumber )
    {
        $complexNumber = ( $complexNumber );
        $parsedComplex = ( $complexNumber );
        if ( $parsedComplex['real'] == 0 && $parsedComplex['imaginary'] == 0 )
        {
            return "1";
        }
        $e = exp( $parsedComplex['real'] );
        $eX = $e * cos( $parsedComplex['imaginary'] );
        $eY = $e * sin( $parsedComplex['imaginary'] );
        if ( $parsedComplex['suffix'] == "" )
        {
            return ( $eX, $eY );
        }
        return ( $eX, $eY, $parsedComplex['suffix'] );
    }

    public static function IMPOWER( $complexNumber, $realNumber )
    {
        $complexNumber = ( $complexNumber );
        $realNumber = ( $realNumber );
        if ( is_numeric( $realNumber ) )
        {
            return ( );
        }
        $parsedComplex = ( $complexNumber );
        $r = sqrt( $parsedComplex['real'] * $parsedComplex['real'] + $parsedComplex['imaginary'] * $parsedComplex['imaginary'] );
        $rPower = pow( $r, $realNumber );
        $theta = ( $complexNumber ) * $realNumber;
        if ( $theta == 0 )
        {
            return 1;
        }
        if ( $parsedComplex['imaginary'] == 0 )
        {
            return ( $rPower * cos( $theta ), $rPower * sin( $theta ), $parsedComplex['suffix'] );
        }
        return ( $rPower * cos( $theta ), $rPower * sin( $theta ), $parsedComplex['suffix'] );
    }

    public static function IMDIV( $complexDividend, $complexDivisor )
    {
        $complexDividend = ( $complexDividend );
        $complexDivisor = ( $complexDivisor );
        $parsedComplexDividend = ( $complexDividend );
        $parsedComplexDivisor = ( $complexDivisor );
        if ( $parsedComplexDividend['suffix'] != "" && $parsedComplexDivisor['suffix'] != "" && $parsedComplexDividend['suffix'] != $parsedComplexDivisor['suffix'] )
        {
            return ( );
        }
        if ( $parsedComplexDividend['suffix'] != "" && $parsedComplexDivisor['suffix'] == "" )
        {
            $parsedComplexDivisor['suffix'] = $parsedComplexDividend['suffix'];
        }
        $d1 = $parsedComplexDividend['real'] * $parsedComplexDivisor['real'] + $parsedComplexDividend['imaginary'] * $parsedComplexDivisor['imaginary'];
        $d2 = $parsedComplexDividend['imaginary'] * $parsedComplexDivisor['real'] - $parsedComplexDividend['real'] * $parsedComplexDivisor['imaginary'];
        $d3 = $parsedComplexDivisor['real'] * $parsedComplexDivisor['real'] + $parsedComplexDivisor['imaginary'] * $parsedComplexDivisor['imaginary'];
        $r = $d1 / $d3;
        $i = $d2 / $d3;
        if ( 0 < $i )
        {
            return ( $r."+".$i.$parsedComplexDivisor['suffix'] );
        }
        if ( $i < 0 )
        {
            return ( $r.$i.$parsedComplexDivisor['suffix'] );
        }
        return $r;
    }

    public static function IMSUB( $complexNumber1, $complexNumber2 )
    {
        $complexNumber1 = ( $complexNumber1 );
        $complexNumber2 = ( $complexNumber2 );
        $parsedComplex1 = ( $complexNumber1 );
        $parsedComplex2 = ( $complexNumber2 );
        if ( $parsedComplex1['suffix'] != "" && $parsedComplex2['suffix'] != "" && $parsedComplex1['suffix'] != $parsedComplex2['suffix'] )
        {
            return ( );
        }
        if ( $parsedComplex1['suffix'] == "" && $parsedComplex2['suffix'] != "" )
        {
            $parsedComplex1['suffix'] = $parsedComplex2['suffix'];
        }
        $d1 = $parsedComplex1['real'] - $parsedComplex2['real'];
        $d2 = $parsedComplex1['imaginary'] - $parsedComplex2['imaginary'];
        return ( $d1, $d2, $parsedComplex1['suffix'] );
    }

    public static function IMSUM( )
    {
        $returnValue = ( "0" );
        $activeSuffix = "";
        $aArgs = ( func_get_args( ) );
        foreach ( $aArgs as $arg )
        {
            $parsedComplex = ( $arg );
            if ( $activeSuffix == "" )
            {
                $activeSuffix = $parsedComplex['suffix'];
            }
            else
            {
                if ( $parsedComplex['suffix'] != "" && $activeSuffix != $parsedComplex['suffix'] )
                {
                    return ( );
                }
            }
            $returnValue += "real";
            $returnValue += "imaginary";
        }
        if ( $returnValue['imaginary'] == 0 )
        {
            $activeSuffix = "";
        }
        return ( $returnValue['real'], $returnValue['imaginary'], $activeSuffix );
    }

    public static function IMPRODUCT( )
    {
        $returnValue = ( "1" );
        $activeSuffix = "";
        $aArgs = ( func_get_args( ) );
        foreach ( $aArgs as $arg )
        {
            $parsedComplex = ( $arg );
            $workValue = $returnValue;
            if ( $parsedComplex['suffix'] != "" && $activeSuffix == "" )
            {
                $activeSuffix = $parsedComplex['suffix'];
            }
            else
            {
                if ( $parsedComplex['suffix'] != "" && $activeSuffix != $parsedComplex['suffix'] )
                {
                    return ( );
                }
            }
            $returnValue['real'] = $workValue['real'] * $parsedComplex['real'] - $workValue['imaginary'] * $parsedComplex['imaginary'];
            $returnValue['imaginary'] = $workValue['real'] * $parsedComplex['imaginary'] + $workValue['imaginary'] * $parsedComplex['real'];
        }
        if ( $returnValue['imaginary'] == 0 )
        {
            $activeSuffix = "";
        }
        return ( $returnValue['real'], $returnValue['imaginary'], $activeSuffix );
    }

    public static function DELTA( $a, $b = 0 )
    {
        $a = ( $a );
        $b = ( $b );
        return ( integer )( $a == $b );
    }

    public static function GESTEP( $number, $step = 0 )
    {
        $number = ( $number );
        $step = ( $step );
        return ( integer )( $step <= $number );
    }

    public static function _erfVal( $x )
    {
        if ( 2.2 < abs( $x ) )
        {
            return 1 - ( $x );
        }
        $sum = $term = $x;
        $xsqr = $x * $x;
        $j = 1;
        do
        {
            $term *= $xsqr / $j;
            $sum -= $term / ( 2 * $j + 1 );
            ++$j;
            $term *= $xsqr / $j;
            $sum += $term / ( 2 * $j + 1 );
            ++$j;
        } while ( !( $sum == 0 ) && PRECISION < abs( $term / $sum ) );
        return self::$_two_sqrtpi * $sum;
    }

    public static function ERF( $lower, $upper = NULL )
    {
        $lower = ( $lower );
        $upper = ( $upper );
        if ( is_numeric( $lower ) )
        {
            if ( is_null( $upper ) )
            {
                return ( $lower );
            }
            if ( is_numeric( $upper ) )
            {
                return ( $upper ) - ( $lower );
            }
        }
        return ( );
    }

    private static function _erfcVal( $x )
    {
        if ( abs( $x ) < 2.2 )
        {
            return 1 - ( $x );
        }
        if ( $x < 0 )
        {
            return 2 - ( 0 - $x );
        }
        $a = $n = 1;
        $b = $c = $x;
        $d = $x * $x + 0.5;
        $q1 = $q2 = $b / $d;
        $t = 0;
        do
        {
            $t = $a * $n + $b * $x;
            $a = $b;
            $b = $t;
            $t = $c * $n + $d * $x;
            $c = $d;
            $d = $t;
            $n += 0.5;
            $q1 = $q2;
            $q2 = $b / $d;
        } while ( PRECISION < abs( $q1 - $q2 ) / $q2 );
        return self::$_one_sqrtpi * exp( 0 - $x * $x ) * $q2;
    }

    public static function ERFC( $x )
    {
        $x = ( $x );
        if ( is_numeric( $x ) )
        {
            return ( $x );
        }
        return ( );
    }

    public static function getConversionGroups( )
    {
        $conversionGroups = array( );
        foreach ( self::$_conversionUnits as $conversionUnit )
        {
            $conversionGroups[] = $conversionUnit['Group'];
        }
        return array_merge( array_unique( $conversionGroups ) );
    }

    public static function getConversionGroupUnits( $group = NULL )
    {
        $conversionGroups = array( );
        foreach ( self::$_conversionUnits as $conversionUnit => $conversionGroup )
        {
            if ( !is_null( $group ) && !( $conversionGroup['Group'] == $group ) )
            {
                $conversionGroups[$conversionGroup['Group']][] = $conversionUnit;
            }
        }
        return $conversionGroups;
    }

    public static function getConversionGroupUnitDetails( $group = NULL )
    {
        $conversionGroups = array( );
        foreach ( self::$_conversionUnits as $conversionUnit => $conversionGroup )
        {
            if ( !is_null( $group ) && !( $conversionGroup['Group'] == $group ) )
            {
                $conversionGroups[$conversionGroup['Group']][] = array( "unit" => $conversionUnit, "description" => $conversionGroup['Unit Name'] );
            }
        }
        return $conversionGroups;
    }

    public static function getConversionMultipliers( )
    {
        return self::$_conversionMultipliers;
    }

    public static function CONVERTUOM( $value, $fromUOM, $toUOM )
    {
        $value = ( $value );
        $fromUOM = ( $fromUOM );
        $toUOM = ( $toUOM );
        if ( is_numeric( $value ) )
        {
            return ( );
        }
        $fromMultiplier = 1;
        if ( isset( $_conversionUnits[$fromUOM] ) )
        {
            $unitGroup1 = self::$_conversionUnits[$fromUOM]['Group'];
        }
        else
        {
            $fromMultiplier = substr( $fromUOM, 0, 1 );
            $fromUOM = substr( $fromUOM, 1 );
            if ( isset( $_conversionMultipliers[$fromMultiplier] ) )
            {
                $fromMultiplier = self::$_conversionMultipliers[$fromMultiplier]['multiplier'];
            }
            else
            {
                return ( );
            }
            if ( isset( $_conversionUnits[$fromUOM] ) )
            {
                if ( self::$_conversionUnits[$fromUOM]['AllowPrefix'] )
                {
                    $unitGroup1 = self::$_conversionUnits[$fromUOM]['Group'];
                }
            }
            else
            {
                return ( );
            }
        }
        $value *= $fromMultiplier;
        $toMultiplier = 1;
        if ( isset( $_conversionUnits[$toUOM] ) )
        {
            $unitGroup2 = self::$_conversionUnits[$toUOM]['Group'];
        }
        else
        {
            $toMultiplier = substr( $toUOM, 0, 1 );
            $toUOM = substr( $toUOM, 1 );
            if ( isset( $_conversionMultipliers[$toMultiplier] ) )
            {
                $toMultiplier = self::$_conversionMultipliers[$toMultiplier]['multiplier'];
            }
            else
            {
                return ( );
            }
            if ( isset( $_conversionUnits[$toUOM] ) )
            {
                if ( self::$_conversionUnits[$toUOM]['AllowPrefix'] )
                {
                    $unitGroup2 = self::$_conversionUnits[$toUOM]['Group'];
                }
            }
            else
            {
                return ( );
            }
        }
        if ( $unitGroup1 != $unitGroup2 )
        {
            return ( );
        }
        if ( $fromUOM == $toUOM && $fromMultiplier == $toMultiplier )
        {
            return $value / $fromMultiplier;
        }
        if ( $unitGroup1 == "Temperature" )
        {
            if ( $fromUOM == "F" || $fromUOM == "fah" )
            {
                if ( $toUOM == "F" || $toUOM == "fah" )
                {
                    return $value;
                }
                $value = ( $value - 32 ) / 1.8;
                if ( $toUOM == "K" || $toUOM == "kel" )
                {
                    $value += 273.15;
                }
                return $value;
            }
            if ( ( $fromUOM == "K" || $fromUOM == "kel" ) && ( $toUOM == "K" || $toUOM == "kel" ) )
            {
                return $value;
            }
            if ( ( $fromUOM == "C" || $fromUOM == "cel" ) && ( $toUOM == "C" || $toUOM == "cel" ) )
            {
                return $value;
            }
            if ( $toUOM == "F" || $toUOM == "fah" )
            {
                if ( $fromUOM == "K" || $fromUOM == "kel" )
                {
                    $value -= 273.15;
                }
                return $value * 1.8 + 32;
            }
            if ( $toUOM == "C" || $toUOM == "cel" )
            {
                return $value - 273.15;
            }
            return $value + 273.15;
        }
        return $value * self::$_unitConversions[$unitGroup1][$fromUOM][$toUOM] / $toMultiplier;
    }

}

if ( defined( "PHPEXCEL_ROOT" ) )
{
    define( "PHPEXCEL_ROOT", dirname( __FILE__ )."/../../" );
    require( PHPEXCEL_ROOT."PHPExcel/Autoloader.php" );
}
define( "EULER", 2.71828 );
?>
