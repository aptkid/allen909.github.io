<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class PHPExcel_Calculation_MathTrig
{

    private static function _factors( $value )
    {
        $startVal = floor( sqrt( $value ) );
        $factorArray = array( );
        $i = $startVal;
        for ( ; 1 < $i; --$i )
        {
            if ( $value % $i == 0 )
            {
                $factorArray = array_merge( $factorArray, ( $value / $i ) );
                $factorArray = array_merge( $factorArray, ( $i ) );
                if ( $i <= sqrt( $value ) )
                {
                }
            }
        }
        if ( empty( $factorArray ) )
        {
            rsort( &$factorArray );
            return $factorArray;
        }
        return array( ( integer ) );
    }

    private static function _romanCut( $num, $n )
    {
        return ( $num - $num % $n ) / $n;
    }

    public static function ATAN2( $xCoordinate = NULL, $yCoordinate = NULL )
    {
        $xCoordinate = ( $xCoordinate );
        $yCoordinate = ( $yCoordinate );
        $xCoordinate = $xCoordinate !== NULL ? $xCoordinate : 0;
        $yCoordinate = $yCoordinate !== NULL ? $yCoordinate : 0;
        if ( is_numeric( $xCoordinate ) || !is_bool( $xCoordinate ) || is_numeric( $yCoordinate ) || is_bool( $yCoordinate ) )
        {
            $xCoordinate = ( double );
            $yCoordinate = ( double );
            if ( $xCoordinate == 0 && $yCoordinate == 0 )
            {
                return ( );
            }
            return atan2( $yCoordinate, $xCoordinate );
        }
        return ( );
    }

    public static function CEILING( $number, $significance = NULL )
    {
        $number = ( $number );
        $significance = ( $significance );
        if ( is_null( $significance ) && ( ) == PHPExcel_Calculation_Functions::COMPATIBILITY_GNUMERIC )
        {
            $significance = $number / abs( $number );
        }
        if ( is_numeric( $number ) && is_numeric( $significance ) )
        {
            if ( $significance == 0 )
            {
                return 0;
            }
            if ( ( $number ) == ( $significance ) )
            {
                return ceil( $number / $significance ) * $significance;
            }
            return ( );
        }
        return ( );
    }

    public static function COMBIN( $numObjs, $numInSet )
    {
        $numObjs = ( $numObjs );
        $numInSet = ( $numInSet );
        if ( is_numeric( $numObjs ) && is_numeric( $numInSet ) )
        {
            if ( $numObjs < $numInSet )
            {
                return ( );
            }
            if ( $numInSet < 0 )
            {
                return ( );
            }
            return round( ( $numObjs ) / ( $numObjs - $numInSet ) ) / ( $numInSet );
        }
        return ( );
    }

    public static function EVEN( $number )
    {
        $number = ( $number );
        if ( is_null( $number ) )
        {
            return 0;
        }
        if ( is_bool( $number ) )
        {
            $number = ( integer );
        }
        if ( is_numeric( $number ) )
        {
            $significance = 2 * ( $number );
            return ( integer );
        }
        return ( );
    }

    public static function FACT( $factVal )
    {
        $factVal = ( $factVal );
        if ( is_numeric( $factVal ) )
        {
            if ( $factVal < 0 )
            {
                return ( );
            }
            $factLoop = floor( $factVal );
            if ( ( ) == PHPExcel_Calculation_Functions::COMPATIBILITY_GNUMERIC && $factLoop < $factVal )
            {
                return ( );
            }
            $factorial = 1;
            while ( 1 < $factLoop )
            {
                $factorial *= $factLoop--;
            }
            return $factorial;
        }
        return ( );
    }

    public static function FACTDOUBLE( $factVal )
    {
        $factLoop = ( $factVal );
        if ( is_numeric( $factLoop ) )
        {
            $factLoop = floor( $factLoop );
            if ( $factVal < 0 )
            {
                return ( );
            }
            $factorial = 1;
            while ( 1 < $factLoop )
            {
                $factorial *= $factLoop--;
                --$factLoop;
            }
            return $factorial;
        }
        return ( );
    }

    public static function FLOOR( $number, $significance = NULL )
    {
        $number = ( $number );
        $significance = ( $significance );
        if ( is_null( $significance ) && ( ) == PHPExcel_Calculation_Functions::COMPATIBILITY_GNUMERIC )
        {
            $significance = $number / abs( $number );
        }
        if ( is_numeric( $number ) && is_numeric( $significance ) )
        {
            if ( ( double ) == 0 )
            {
                return ( );
            }
            if ( ( $number ) == ( $significance ) )
            {
                return floor( $number / $significance ) * $significance;
            }
            return ( );
        }
        return ( );
    }

    public static function GCD( )
    {
        $returnValue = 1;
        $allValuesFactors = array( );
        foreach ( ( func_get_args( ) ) as $value )
        {
            if ( is_numeric( $value ) )
            {
                return ( );
            }
            if ( $value == 0 )
            {
                continue;
            }
            else if ( $value < 0 )
            {
                return ( );
            }
            else
            {
                $myFactors = ( $value );
                $myCountedFactors = array_count_values( $myFactors );
                $allValuesFactors[] = $myCountedFactors;
            }
        }
        $allValuesCount = count( $allValuesFactors );
        if ( $allValuesCount == 0 )
        {
            return 0;
        }
        $mergedArray = $allValuesFactors[0];
        $i = 1;
        for ( ; $i < $allValuesCount; ++$i )
        {
            $mergedArray = array_intersect_key( $mergedArray, $allValuesFactors[$i] );
        }
        $mergedArrayValues = count( $mergedArray );
        if ( $mergedArrayValues == 0 )
        {
            return $returnValue;
        }
        if ( 1 < $mergedArrayValues )
        {
            foreach ( $mergedArray as $mergedKey => $mergedValue )
            {
                foreach ( $allValuesFactors as $highestPowerTest )
                {
                    foreach ( $highestPowerTest as $testKey => $testValue )
                    {
                        if ( !( $testKey == $mergedKey ) || !( $testValue < $mergedValue ) )
                        {
                            $mergedArray[$mergedKey] = $testValue;
                            $mergedValue = $testValue;
                        }
                    }
                }
            }
            $returnValue = 1;
            foreach ( $mergedArray as $key => $value )
            {
                $returnValue *= pow( $key, $value );
                return $returnValue;
            }
            else
            {
                $keys = array_keys( $mergedArray );
                $key = $keys[0];
                $value = $mergedArray[$key];
                foreach ( $allValuesFactors as $testValue )
                {
                    foreach ( $testValue as $mergedKey => $mergedValue )
                    {
                        if ( !( $mergedKey == $key ) || !( $mergedValue < $value ) )
                        {
                            $value = $mergedValue;
                        }
                    }
                    break;
                }
            }
        }
        return pow( $key, $value );
    }

    public static function INT( $number )
    {
        $number = ( $number );
        if ( is_null( $number ) )
        {
            return 0;
        }
        if ( is_bool( $number ) )
        {
            return ( integer );
        }
        if ( is_numeric( $number ) )
        {
            return ( integer );
        }
        return ( );
    }

    public static function LCM( )
    {
        $returnValue = 1;
        $allPoweredFactors = array( );
        foreach ( ( func_get_args( ) ) as $value )
        {
            if ( is_numeric( $value ) )
            {
                return ( );
            }
            if ( $value == 0 )
            {
                return 0;
            }
            if ( $value < 0 )
            {
                return ( );
            }
            $myFactors = ( floor( $value ) );
            $myCountedFactors = array_count_values( $myFactors );
            $myPoweredFactors = array( );
            foreach ( $myCountedFactors as $myCountedFactor => $myCountedPower )
            {
                $myPoweredFactors[$myCountedFactor] = pow( $myCountedFactor, $myCountedPower );
            }
            foreach ( $myPoweredFactors as $myPoweredValue => $myPoweredFactor )
            {
                if ( array_key_exists( $myPoweredValue, $allPoweredFactors ) )
                {
                    if ( $allPoweredFactors[$myPoweredValue] < $myPoweredFactor )
                    {
                        $allPoweredFactors[$myPoweredValue] = $myPoweredFactor;
                    }
                }
                else
                {
                    $allPoweredFactors[$myPoweredValue] = $myPoweredFactor;
                }
            }
        }
        foreach ( $allPoweredFactors as $allPoweredFactor )
        {
            $returnValue *= ( integer );
        }
        return $returnValue;
    }

    public static function LOG_BASE( $number = NULL, $base = 10 )
    {
        $number = ( $number );
        $base = is_null( $base ) ? 10 : ( double );
        if ( !is_numeric( $base ) || !is_numeric( $number ) )
        {
            return ( );
        }
        if ( $base <= 0 || $number <= 0 )
        {
            return ( );
        }
        return log( $number, $base );
    }

    public static function MDETERM( $matrixValues )
    {
        $matrixData = array( );
        if ( is_array( $matrixValues ) )
        {
            $matrixValues = array( array( $matrixValues ) );
        }
        $row = $maxColumn = 0;
        foreach ( $matrixValues as $matrixRow )
        {
            if ( is_array( $matrixRow ) )
            {
                $matrixRow = array( $matrixRow );
            }
            $column = 0;
            foreach ( $matrixRow as $matrixCell )
            {
                if ( is_string( $matrixCell ) || $matrixCell === NULL )
                {
                    return ( );
                }
                $matrixData[$column][$row] = $matrixCell;
                ++$column;
            }
            if ( $maxColumn < $column )
            {
                $maxColumn = $column;
            }
            ++$row;
        }
        if ( $row != $maxColumn )
        {
            return ( );
        }
        try
        {
            $matrix = new PHPExcel_Shared_JAMA_Matrix( $matrixData );
            return $matrix->det( );
        }
        catch ( PHPExcel_Exception $ex )
        {
            return ( );
    }
}

    public static function MINVERSE( $matrixValues )
    {
        $matrixData = array( );
        if ( is_array( $matrixValues ) )
        {
            $matrixValues = array( array( $matrixValues ) );
        }
        $row = $maxColumn = 0;
        foreach ( $matrixValues as $matrixRow )
        {
            if ( is_array( $matrixRow ) )
            {
                $matrixRow = array( $matrixRow );
            }
            $column = 0;
            foreach ( $matrixRow as $matrixCell )
            {
                if ( is_string( $matrixCell ) || $matrixCell === NULL )
                {
                    return ( );
                }
                $matrixData[$column][$row] = $matrixCell;
                ++$column;
            }
            if ( $maxColumn < $column )
            {
                $maxColumn = $column;
            }
            ++$row;
        }
        if ( $row != $maxColumn )
        {
            return ( );
        }
        try
        {
            $matrix = new PHPExcel_Shared_JAMA_Matrix( $matrixData );
            return $matrix->inverse( )->getArray( );
        }
        catch ( PHPExcel_Exception $ex )
        {
            return ( );
    }
}

    public static function MMULT( $matrixData1, $matrixData2 )
    {
        $matrixAData = $matrixBData = array( );
        if ( is_array( $matrixData1 ) )
        {
            $matrixData1 = array( array( $matrixData1 ) );
        }
        if ( is_array( $matrixData2 ) )
        {
            $matrixData2 = array( array( $matrixData2 ) );
        }
        $rowA = 0;
        foreach ( $matrixData1 as $matrixRow )
        {
            if ( is_array( $matrixRow ) )
            {
                $matrixRow = array( $matrixRow );
            }
            $columnA = 0;
            foreach ( $matrixRow as $matrixCell )
            {
                if ( is_string( $matrixCell ) || $matrixCell === NULL )
                {
                    return ( );
                }
                $matrixAData[$rowA][$columnA] = $matrixCell;
                ++$columnA;
            }
            ++$rowA;
        }
        try
        {
            $matrixA = new PHPExcel_Shared_JAMA_Matrix( $matrixAData );
            $rowB = 0;
            foreach ( $matrixData2 as $matrixRow )
            {
                if ( is_array( $matrixRow ) )
                {
                    $matrixRow = array( $matrixRow );
                }
                $columnB = 0;
                foreach ( $matrixRow as $matrixCell )
                {
                    if ( is_string( $matrixCell ) || $matrixCell === NULL )
                    {
                        return ( );
                    }
                    $matrixBData[$rowB][$columnB] = $matrixCell;
                    ++$columnB;
                }
                ++$rowB;
            }
            $matrixB = new PHPExcel_Shared_JAMA_Matrix( $matrixBData );
            if ( $rowA != $columnB || $rowB != $columnA )
            {
                return ( );
            }
            return $matrixA->times( $matrixB )->getArray( );
        }
        catch ( PHPExcel_Exception $ex )
        {
            return ( );
    }
}

    public static function MOD( $a = 1, $b = 1 )
    {
        $a = ( $a );
        $b = ( $b );
        if ( $b == 0 )
        {
            return ( );
        }
        if ( $a < 0 && 0 < $b )
        {
            return $b - fmod( abs( $a ), $b );
        }
        if ( 0 < $a && $b < 0 )
        {
            return $b + fmod( $a, abs( $b ) );
        }
        return fmod( $a, $b );
    }

    public static function MROUND( $number, $multiple )
    {
        $number = ( $number );
        $multiple = ( $multiple );
        if ( is_numeric( $number ) && is_numeric( $multiple ) )
        {
            if ( $multiple == 0 )
            {
                return 0;
            }
            if ( ( $number ) == ( $multiple ) )
            {
                $multiplier = 1 / $multiple;
                return round( $number * $multiplier ) / $multiplier;
            }
            return ( );
        }
        return ( );
    }

    public static function MULTINOMIAL( )
    {
        $summer = 0;
        $divisor = 1;
        foreach ( ( func_get_args( ) ) as $arg )
        {
            if ( is_numeric( $arg ) )
            {
                if ( $arg < 1 )
                {
                    return ( );
                }
                $summer += floor( $arg );
                $divisor *= ( $arg );
            }
            else
            {
                return ( );
                break;
            }
        }
        if ( 0 < $summer )
        {
            $summer = ( $summer );
            return $summer / $divisor;
        }
        return 0;
    }

    public static function ODD( $number )
    {
        $number = ( $number );
        if ( is_null( $number ) )
        {
            return 1;
        }
        if ( is_bool( $number ) )
        {
            $number = ( integer );
        }
        if ( is_numeric( $number ) )
        {
            $significance = ( $number );
            if ( $significance == 0 )
            {
                return 1;
            }
            $result = ( $number, $significance );
            if ( $result == ( $result ) )
            {
                $result += $significance;
            }
            return ( integer );
        }
        return ( );
    }

    public static function POWER( $x = 0, $y = 2 )
    {
        $x = ( $x );
        $y = ( $y );
        if ( $x == 0 && $y == 0 )
        {
            return ( );
        }
        if ( $x == 0 && $y < 0 )
        {
            return ( );
        }
        $result = pow( $x, $y );
        if ( !is_nan( $result ) && !is_infinite( $result ) )
        {
            return $result;
        }
        return ( );
    }

    public static function PRODUCT( )
    {
        $returnValue = NULL;
        foreach ( ( func_get_args( ) ) as $arg )
        {
            if ( !is_numeric( $arg ) || is_string( $arg ) )
            {
                continue;
            }
            else if ( is_null( $returnValue ) )
            {
                $returnValue = $arg;
            }
            else
            {
                $returnValue *= $arg;
            }
        }
        if ( is_null( $returnValue ) )
        {
            return 0;
        }
        return $returnValue;
    }

    public static function QUOTIENT( )
    {
        $returnValue = NULL;
        foreach ( ( func_get_args( ) ) as $arg )
        {
            if ( !is_numeric( $arg ) || is_string( $arg ) )
            {
                continue;
            }
            else if ( is_null( $returnValue ) )
            {
                $returnValue = $arg == 0 ? 0 : $arg;
            }
            else if ( $returnValue == 0 || $arg == 0 )
            {
                $returnValue = 0;
            }
            else
            {
                $returnValue /= $arg;
            }
        }
        return intval( $returnValue );
    }

    public static function RAND( $min = 0, $max = 0 )
    {
        $min = ( $min );
        $max = ( $max );
        if ( $min == 0 && $max == 0 )
        {
            return rand( 0, 10000000 ) / 10000000;
        }
        return rand( $min, $max );
    }

    public static function ROMAN( $aValue, $style = 0 )
    {
        $aValue = ( $aValue );
        $style = is_null( $style ) ? 0 : ( integer );
        if ( !is_numeric( $aValue ) || $aValue < 0 || 4000 <= $aValue )
        {
            return ( );
        }
        $aValue = ( integer );
        if ( $aValue == 0 )
        {
            return "";
        }
        $mill = array( "", "M", "MM", "MMM", "MMMM", "MMMMM" );
        $cent = array( "", "C", "CC", "CCC", "CD", "D", "DC", "DCC", "DCCC", "CM" );
        $tens = array( "", "X", "XX", "XXX", "XL", "L", "LX", "LXX", "LXXX", "XC" );
        $ones = array( "", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX" );
        $roman = "";
        while ( 5999 < $aValue )
        {
            $roman .= "M";
            $aValue -= 1000;
        }
        $m = ( $aValue, 1000 );
        $aValue %= 1000;
        $c = ( $aValue, 100 );
        $aValue %= 100;
        $t = ( $aValue, 10 );
        $aValue %= 10;
        return $roman.$mill[$m].$cent[$c].$tens[$t].$ones[$aValue];
    }

    public static function ROUNDUP( $number, $digits )
    {
        $number = ( $number );
        $digits = ( $digits );
        if ( is_numeric( $number ) && is_numeric( $digits ) )
        {
            $significance = pow( 10, ( integer ) );
            if ( $number < 0 )
            {
                return floor( $number * $significance ) / $significance;
            }
            return ceil( $number * $significance ) / $significance;
        }
        return ( );
    }

    public static function ROUNDDOWN( $number, $digits )
    {
        $number = ( $number );
        $digits = ( $digits );
        if ( is_numeric( $number ) && is_numeric( $digits ) )
        {
            $significance = pow( 10, ( integer ) );
            if ( $number < 0 )
            {
                return ceil( $number * $significance ) / $significance;
            }
            return floor( $number * $significance ) / $significance;
        }
        return ( );
    }

    public static function SERIESSUM( )
    {
        $returnValue = 0;
        $aArgs = ( func_get_args( ) );
        $x = array_shift( &$aArgs );
        $n = array_shift( &$aArgs );
        $m = array_shift( &$aArgs );
        if ( is_numeric( $x ) && is_numeric( $n ) && is_numeric( $m ) )
        {
            $i = 0;
            foreach ( $aArgs as $arg )
            {
                if ( is_numeric( $arg ) && !is_string( $arg ) )
                {
                    $returnValue += $arg * pow( $x, $n + $m * $i++ );
                }
                else
                {
                    return ( );
                }
            }
            return $returnValue;
        }
        return ( );
    }

    public static function SIGN( $number )
    {
        $number = ( $number );
        if ( is_bool( $number ) )
        {
            return ( integer );
        }
        if ( is_numeric( $number ) )
        {
            if ( $number == 0 )
            {
                return 0;
            }
            return $number / abs( $number );
        }
        return ( );
    }

    public static function SQRTPI( $number )
    {
        $number = ( $number );
        if ( is_numeric( $number ) )
        {
            if ( $number < 0 )
            {
                return ( );
            }
            return sqrt( $number * M_PI );
        }
        return ( );
    }

    public static function SUBTOTAL( )
    {
        $aArgs = ( func_get_args( ) );
        $subtotal = array_shift( &$aArgs );
        if ( is_numeric( $subtotal ) && !is_string( $subtotal ) )
        {
            switch ( $subtotal )
            {
                case 1 :
                    return ( $aArgs );
                case 2 :
                    return ( $aArgs );
                case 3 :
                    return ( $aArgs );
                case 4 :
                    return ( $aArgs );
                case 5 :
                    return ( $aArgs );
                case 6 :
                    return ( $aArgs );
                case 7 :
                    return ( $aArgs );
                case 8 :
                    return ( $aArgs );
                case 9 :
                    return ( $aArgs );
                case 10 :
                    return ( $aArgs );
                case 11 :
                    return ( $aArgs );
                }
                else
                {
                default :
                    return ( );
            }
        }
    }

    public static function SUM( )
    {
        $returnValue = 0;
        foreach ( ( func_get_args( ) ) as $arg )
        {
            if ( !is_numeric( $arg ) || is_string( $arg ) )
            {
                $returnValue += $arg;
            }
        }
        return $returnValue;
    }

    public static function SUMIF( $aArgs, $condition, $sumArgs = array( ) )
    {
        $returnValue = 0;
        $aArgs = ( $aArgs );
        $sumArgs = ( $sumArgs );
        if ( empty( $sumArgs ) )
        {
            $sumArgs = $aArgs;
        }
        $condition = ( $condition );
        foreach ( $aArgs as $key => $arg )
        {
            if ( is_numeric( $arg ) )
            {
                $arg = ( strtoupper( $arg ) );
            }
            $testCondition = "=".$arg.$condition;
            if ( ( )->_calculateFormulaValue( $testCondition ) )
            {
                $returnValue += $sumArgs[$key];
            }
        }
        return $returnValue;
    }

    public static function SUMPRODUCT( )
    {
        $arrayList = func_get_args( );
        $wrkArray = ( array_shift( &$arrayList ) );
        $wrkCellCount = count( $wrkArray );
        $i = 0;
        for ( ; $i < $wrkCellCount; ++$i )
        {
            if ( is_numeric( $wrkArray[$i] ) && !is_string( $wrkArray[$i] ) )
            {
                $wrkArray[$i] = 0;
            }
        }
        foreach ( $arrayList as $matrixData )
        {
            $array2 = ( $matrixData );
            $count = count( $array2 );
            if ( $wrkCellCount != $count )
            {
                return ( );
            }
            foreach ( $array2 as $i => $val )
            {
                if ( !is_numeric( $val ) || is_string( $val ) )
                {
                    $val = 0;
                }
                $wrkArray *= $i;
            }
        }
        return array_sum( $wrkArray );
    }

    public static function SUMSQ( )
    {
        $returnValue = 0;
        foreach ( ( func_get_args( ) ) as $arg )
        {
            if ( !is_numeric( $arg ) || is_string( $arg ) )
            {
                $returnValue += $arg * $arg;
            }
        }
        return $returnValue;
    }

    public static function SUMX2MY2( $matrixData1, $matrixData2 )
    {
        $array1 = ( $matrixData1 );
        $array2 = ( $matrixData2 );
        $count1 = count( $array1 );
        $count2 = count( $array2 );
        if ( $count1 < $count2 )
        {
            $count = $count1;
        }
        else
        {
            $count = $count2;
        }
        $result = 0;
        $i = 0;
        for ( ; $i < $count; ++$i )
        {
            if ( is_numeric( $array1[$i] ) )
            {
                if ( is_string( $array1[$i] ) )
                {
                    if ( !is_numeric( $array2[$i] ) || is_string( $array2[$i] ) )
                    {
                        $result += $array1[$i] * $array1[$i] - $array2[$i] * $array2[$i];
                    }
                }
            }
        }
        return $result;
    }

    public static function SUMX2PY2( $matrixData1, $matrixData2 )
    {
        $array1 = ( $matrixData1 );
        $array2 = ( $matrixData2 );
        $count1 = count( $array1 );
        $count2 = count( $array2 );
        if ( $count1 < $count2 )
        {
            $count = $count1;
        }
        else
        {
            $count = $count2;
        }
        $result = 0;
        $i = 0;
        for ( ; $i < $count; ++$i )
        {
            if ( is_numeric( $array1[$i] ) )
            {
                if ( is_string( $array1[$i] ) )
                {
                    if ( !is_numeric( $array2[$i] ) || is_string( $array2[$i] ) )
                    {
                        $result += $array1[$i] * $array1[$i] + $array2[$i] * $array2[$i];
                    }
                }
            }
        }
        return $result;
    }

    public static function SUMXMY2( $matrixData1, $matrixData2 )
    {
        $array1 = ( $matrixData1 );
        $array2 = ( $matrixData2 );
        $count1 = count( $array1 );
        $count2 = count( $array2 );
        if ( $count1 < $count2 )
        {
            $count = $count1;
        }
        else
        {
            $count = $count2;
        }
        $result = 0;
        $i = 0;
        for ( ; $i < $count; ++$i )
        {
            if ( is_numeric( $array1[$i] ) )
            {
                if ( is_string( $array1[$i] ) )
                {
                    if ( !is_numeric( $array2[$i] ) || is_string( $array2[$i] ) )
                    {
                        $result += ( $array1[$i] - $array2[$i] ) * ( $array1[$i] - $array2[$i] );
                    }
                }
            }
        }
        return $result;
    }

    public static function TRUNC( $value = 0, $digits = 0 )
    {
        $value = ( $value );
        $digits = ( $digits );
        if ( !is_numeric( $value ) || !is_numeric( $digits ) )
        {
            return ( );
        }
        $digits = floor( $digits );
        $adjust = pow( 10, $digits );
        if ( 0 < $digits && rtrim( intval( ( abs( $value ) - abs( intval( $value ) ) ) * $adjust ), "0" ) < $adjust / 10 )
        {
            return $value;
        }
        return intval( $value * $adjust ) / $adjust;
    }

}

if ( defined( "PHPEXCEL_ROOT" ) )
{
    define( "PHPEXCEL_ROOT", dirname( __FILE__ )."/../../" );
    require( PHPEXCEL_ROOT."PHPExcel/Autoloader.php" );
}
?>
