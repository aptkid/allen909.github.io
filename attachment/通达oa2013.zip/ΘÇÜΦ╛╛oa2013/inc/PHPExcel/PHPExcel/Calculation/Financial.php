<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class PHPExcel_Calculation_Financial
{

    private static function _lastDayOfMonth( $testDate )
    {
        return $testDate->format( "d" ) == $testDate->format( "t" );
    }

    private static function _firstDayOfMonth( $testDate )
    {
        return $testDate->format( "d" ) == 1;
    }

    private static function _coupFirstPeriodDate( $settlement, $maturity, $frequency, $next )
    {
        $months = 12 / $frequency;
        $result = ( $maturity );
        $eom = ( $result );
        while ( $settlement < ( $result ) )
        {
            $result->modify( "-".$months." months" );
        }
        if ( $next )
        {
            $result->modify( "+".$months." months" );
        }
        if ( $eom )
        {
            $result->modify( "-1 day" );
        }
        return ( $result );
    }

    private static function _validFrequency( $frequency )
    {
        if ( $frequency == 1 || $frequency == 2 || $frequency == 4 )
        {
            return TRUE;
        }
        if ( ( ) == PHPExcel_Calculation_Functions::COMPATIBILITY_GNUMERIC && ( $frequency == 6 || $frequency == 12 ) )
        {
            return TRUE;
        }
        return FALSE;
    }

    private static function _daysPerYear( $year, $basis = 0 )
    {
        switch ( $basis )
        {
            case 0 :
            case 2 :
            case 4 :
                $daysPerYear = 360;
                return $daysPerYear;
            case 3 :
                $daysPerYear = 365;
                return $daysPerYear;
            case 1 :
                $daysPerYear = ( $year ) ? 366 : 365;
                return $daysPerYear;
            default :
                return ( );
        }
    }

    private static function _interestAndPrincipal( $rate = 0, $per = 0, $nper = 0, $pv = 0, $fv = 0, $type = 0 )
    {
        $pmt = ( $rate, $nper, $pv, $fv, $type );
        $capital = $pv;
        $i = 1;
        for ( ; $i <= $per; ++$i )
        {
            $interest = $type && $i == 1 ? 0 : 0 - $capital * $rate;
            $principal = $pmt - $interest;
            $capital += $principal;
        }
        return array( $interest, $principal );
    }

    public static function ACCRINT( $issue, $firstinterest, $settlement, $rate, $par = 1000, $frequency = 1, $basis = 0 )
    {
        $issue = ( $issue );
        $firstinterest = ( $firstinterest );
        $settlement = ( $settlement );
        $rate = ( $rate );
        $par = is_null( $par ) ? 1000 : ( $par );
        $frequency = is_null( $frequency ) ? 1 : ( $frequency );
        $basis = is_null( $basis ) ? 0 : ( $basis );
        if ( is_numeric( $rate ) && is_numeric( $par ) )
        {
            $rate = ( double );
            $par = ( double );
            if ( $rate <= 0 || $par <= 0 )
            {
                return ( );
            }
            $daysBetweenIssueAndSettlement = ( $issue, $settlement, $basis );
            if ( is_numeric( $daysBetweenIssueAndSettlement ) )
            {
                return $daysBetweenIssueAndSettlement;
            }
            return $par * $rate * $daysBetweenIssueAndSettlement;
        }
        return ( );
    }

    public static function ACCRINTM( $issue, $settlement, $rate, $par = 1000, $basis = 0 )
    {
        $issue = ( $issue );
        $settlement = ( $settlement );
        $rate = ( $rate );
        $par = is_null( $par ) ? 1000 : ( $par );
        $basis = is_null( $basis ) ? 0 : ( $basis );
        if ( is_numeric( $rate ) && is_numeric( $par ) )
        {
            $rate = ( double );
            $par = ( double );
            if ( $rate <= 0 || $par <= 0 )
            {
                return ( );
            }
            $daysBetweenIssueAndSettlement = ( $issue, $settlement, $basis );
            if ( is_numeric( $daysBetweenIssueAndSettlement ) )
            {
                return $daysBetweenIssueAndSettlement;
            }
            return $par * $rate * $daysBetweenIssueAndSettlement;
        }
        return ( );
    }

    public static function AMORDEGRC( $cost, $purchased, $firstPeriod, $salvage, $period, $rate, $basis = 0 )
    {
        $cost = ( $cost );
        $purchased = ( $purchased );
        $firstPeriod = ( $firstPeriod );
        $salvage = ( $salvage );
        $period = floor( ( $period ) );
        $rate = ( $rate );
        $basis = is_null( $basis ) ? 0 : ( integer );
        $fUsePer = 1 / $rate;
        if ( $fUsePer < 3 )
        {
            $amortiseCoeff = 1;
        }
        else if ( $fUsePer < 5 )
        {
            $amortiseCoeff = 1.5;
        }
        else if ( $fUsePer <= 6 )
        {
            $amortiseCoeff = 2;
        }
        else
        {
            $amortiseCoeff = 2.5;
        }
        $rate *= $amortiseCoeff;
        $fNRate = round( ( $purchased, $firstPeriod, $basis ) * $rate * $cost, 0 );
        $cost -= $fNRate;
        $fRest = $cost - $salvage;
        $n = 0;
        for ( ; $n < $period; ++$n )
        {
            $fNRate = round( $rate * $cost, 0 );
            $fRest -= $fNRate;
            if ( $fRest < 0 )
            {
                switch ( $period - $n )
                {
                    case 0 :
                    case 1 :
                        return round( $cost * 0.5, 0 );
                }
                return 0;
            }
            $cost -= $fNRate;
        }
        return $fNRate;
    }

    public static function AMORLINC( $cost, $purchased, $firstPeriod, $salvage, $period, $rate, $basis = 0 )
    {
        $cost = ( $cost );
        $purchased = ( $purchased );
        $firstPeriod = ( $firstPeriod );
        $salvage = ( $salvage );
        $period = ( $period );
        $rate = ( $rate );
        $basis = is_null( $basis ) ? 0 : ( integer );
        $fOneRate = $cost * $rate;
        $fCostDelta = $cost - $salvage;
        $purchasedYear = ( $purchased );
        $yearFrac = ( $purchased, $firstPeriod, $basis );
        if ( $basis == 1 && $yearFrac < 1 && ( $purchasedYear ) )
        {
            $yearFrac *= 0.997268;
        }
        $f0Rate = $yearFrac * $rate * $cost;
        $nNumOfFullPeriods = intval( ( $cost - $salvage - $f0Rate ) / $fOneRate );
        if ( $period == 0 )
        {
            return $f0Rate;
        }
        if ( $period <= $nNumOfFullPeriods )
        {
            return $fOneRate;
        }
        if ( $period == $nNumOfFullPeriods + 1 )
        {
            return $fCostDelta - $fOneRate * $nNumOfFullPeriods - $f0Rate;
        }
        return 0;
    }

    public static function COUPDAYBS( $settlement, $maturity, $frequency, $basis = 0 )
    {
        $settlement = ( $settlement );
        $maturity = ( $maturity );
        $frequency = ( integer );
        $basis = is_null( $basis ) ? 0 : ( integer );
        if ( is_string( $settlement = ( $settlement ) ) )
        {
            return ( );
        }
        if ( is_string( $maturity = ( $maturity ) ) )
        {
            return ( );
        }
        do
        {
            if ( $maturity < $settlement )
            {
                break;
            }
            else
            {
            }
            if ( !( $frequency ) || $basis < 0 || 4 < $basis )
            {
            }
        } while ( 0 );
        return ( );
        $daysPerYear = ( ( $settlement ), $basis );
        $prev = ( $settlement, $maturity, $frequency, FALSE );
        return ( $prev, $settlement, $basis ) * $daysPerYear;
    }

    public static function COUPDAYS( $settlement, $maturity, $frequency, $basis = 0 )
    {
        $settlement = ( $settlement );
        $maturity = ( $maturity );
        $frequency = ( integer );
        $basis = is_null( $basis ) ? 0 : ( integer );
        if ( is_string( $settlement = ( $settlement ) ) )
        {
            return ( );
        }
        if ( is_string( $maturity = ( $maturity ) ) )
        {
            return ( );
        }
        do
        {
            if ( $maturity < $settlement )
            {
                break;
            }
            else
            {
            }
            if ( !( $frequency ) || $basis < 0 || 4 < $basis )
            {
            }
        } while ( 0 );
        return ( );
        switch ( $basis )
        {
            case 3 :
                return 365 / $frequency;
            case 1 :
                if ( $frequency == 1 )
                {
                    $daysPerYear = ( ( $maturity ), $basis );
                    return $daysPerYear / $frequency;
                }
                $prev = ( $settlement, $maturity, $frequency, FALSE );
                $next = ( $settlement, $maturity, $frequency, TRUE );
                return $next - $prev;
            default :
                return 360 / $frequency;
        }
    }

    public static function COUPDAYSNC( $settlement, $maturity, $frequency, $basis = 0 )
    {
        $settlement = ( $settlement );
        $maturity = ( $maturity );
        $frequency = ( integer );
        $basis = is_null( $basis ) ? 0 : ( integer );
        if ( is_string( $settlement = ( $settlement ) ) )
        {
            return ( );
        }
        if ( is_string( $maturity = ( $maturity ) ) )
        {
            return ( );
        }
        do
        {
            if ( $maturity < $settlement )
            {
                break;
            }
            else
            {
            }
            if ( !( $frequency ) || $basis < 0 || 4 < $basis )
            {
            }
        } while ( 0 );
        return ( );
        $daysPerYear = ( ( $settlement ), $basis );
        $next = ( $settlement, $maturity, $frequency, TRUE );
        return ( $settlement, $next, $basis ) * $daysPerYear;
    }

    public static function COUPNCD( $settlement, $maturity, $frequency, $basis = 0 )
    {
        $settlement = ( $settlement );
        $maturity = ( $maturity );
        $frequency = ( integer );
        $basis = is_null( $basis ) ? 0 : ( integer );
        if ( is_string( $settlement = ( $settlement ) ) )
        {
            return ( );
        }
        if ( is_string( $maturity = ( $maturity ) ) )
        {
            return ( );
        }
        do
        {
            if ( $maturity < $settlement )
            {
                break;
            }
            else
            {
            }
            if ( !( $frequency ) || $basis < 0 || 4 < $basis )
            {
            }
        } while ( 0 );
        return ( );
        return ( $settlement, $maturity, $frequency, TRUE );
    }

    public static function COUPNUM( $settlement, $maturity, $frequency, $basis = 0 )
    {
        $settlement = ( $settlement );
        $maturity = ( $maturity );
        $frequency = ( integer );
        $basis = is_null( $basis ) ? 0 : ( integer );
        if ( is_string( $settlement = ( $settlement ) ) )
        {
            return ( );
        }
        if ( is_string( $maturity = ( $maturity ) ) )
        {
            return ( );
        }
        do
        {
            if ( $maturity < $settlement )
            {
                break;
            }
            else
            {
            }
            if ( !( $frequency ) || $basis < 0 || 4 < $basis )
            {
            }
        } while ( 0 );
        return ( );
        $settlement = ( $settlement, $maturity, $frequency, TRUE );
        $daysBetweenSettlementAndMaturity = ( $settlement, $maturity, $basis ) * 365;
        switch ( $frequency )
        {
            case 1 :
                return ceil( $daysBetweenSettlementAndMaturity / 360 );
            case 2 :
                return ceil( $daysBetweenSettlementAndMaturity / 180 );
            case 4 :
                return ceil( $daysBetweenSettlementAndMaturity / 90 );
            case 6 :
                return ceil( $daysBetweenSettlementAndMaturity / 60 );
            case 12 :
                return ceil( $daysBetweenSettlementAndMaturity / 30 );
            default :
                return ( );
        }
    }

    public static function COUPPCD( $settlement, $maturity, $frequency, $basis = 0 )
    {
        $settlement = ( $settlement );
        $maturity = ( $maturity );
        $frequency = ( integer );
        $basis = is_null( $basis ) ? 0 : ( integer );
        if ( is_string( $settlement = ( $settlement ) ) )
        {
            return ( );
        }
        if ( is_string( $maturity = ( $maturity ) ) )
        {
            return ( );
        }
        do
        {
            if ( $maturity < $settlement )
            {
                break;
            }
            else
            {
            }
            if ( !( $frequency ) || $basis < 0 || 4 < $basis )
            {
            }
        } while ( 0 );
        return ( );
        return ( $settlement, $maturity, $frequency, FALSE );
    }

    public static function CUMIPMT( $rate, $nper, $pv, $start, $end, $type = 0 )
    {
        $rate = ( $rate );
        $nper = ( integer );
        $pv = ( $pv );
        $start = ( integer );
        $end = ( integer );
        $type = ( integer );
        if ( $type != 0 && $type != 1 )
        {
            return ( );
        }
        if ( $start < 1 || $end < $start )
        {
            return ( );
        }
        $interest = 0;
        $per = $start;
        for ( ; $per <= $end; ++$per )
        {
            $interest += ( $rate, $per, $nper, $pv, 0, $type );
        }
        return $interest;
    }

    public static function CUMPRINC( $rate, $nper, $pv, $start, $end, $type = 0 )
    {
        $rate = ( $rate );
        $nper = ( integer );
        $pv = ( $pv );
        $start = ( integer );
        $end = ( integer );
        $type = ( integer );
        if ( $type != 0 && $type != 1 )
        {
            return ( );
        }
        if ( $start < 1 || $end < $start )
        {
            return ( );
        }
        $principal = 0;
        $per = $start;
        for ( ; $per <= $end; ++$per )
        {
            $principal += ( $rate, $per, $nper, $pv, 0, $type );
        }
        return $principal;
    }

    public static function DB( $cost, $salvage, $life, $period, $month = 12 )
    {
        $cost = ( $cost );
        $salvage = ( $salvage );
        $life = ( $life );
        $period = ( $period );
        $month = ( $month );
        if ( is_numeric( $cost ) && is_numeric( $salvage ) && is_numeric( $life ) && is_numeric( $period ) && is_numeric( $month ) )
        {
            $cost = ( double );
            $salvage = ( double );
            $life = ( integer );
            $period = ( integer );
            $month = ( integer );
            if ( $cost == 0 )
            {
                return 0;
            }
            if ( $cost < 0 || $salvage / $cost < 0 || $life <= 0 || $period < 1 || $month < 1 )
            {
                return ( );
            }
            $fixedDepreciationRate = 1 - pow( $salvage / $cost, 1 / $life );
            $fixedDepreciationRate = round( $fixedDepreciationRate, 3 );
            $previousDepreciation = 0;
            $per = 1;
            for ( ; $per <= $period; ++$per )
            {
                if ( $per == 1 )
                {
                    $depreciation = $cost * $fixedDepreciationRate * $month / 12;
                }
                else if ( $per == $life + 1 )
                {
                    $depreciation = ( $cost - $previousDepreciation ) * $fixedDepreciationRate * ( 12 - $month ) / 12;
                }
                else
                {
                    $depreciation = ( $cost - $previousDepreciation ) * $fixedDepreciationRate;
                }
                $previousDepreciation += $depreciation;
            }
            if ( ( ) == PHPExcel_Calculation_Functions::COMPATIBILITY_GNUMERIC )
            {
                $depreciation = round( $depreciation, 2 );
            }
            return $depreciation;
        }
        return ( );
    }

    public static function DDB( $cost, $salvage, $life, $period, $factor = 2 )
    {
        $cost = ( $cost );
        $salvage = ( $salvage );
        $life = ( $life );
        $period = ( $period );
        $factor = ( $factor );
        if ( is_numeric( $cost ) && is_numeric( $salvage ) && is_numeric( $life ) && is_numeric( $period ) && is_numeric( $factor ) )
        {
            $cost = ( double );
            $salvage = ( double );
            $life = ( integer );
            $period = ( integer );
            $factor = ( double );
            if ( $cost <= 0 || $salvage / $cost < 0 || $life <= 0 || $period < 1 || $factor <= 0 || $life < $period )
            {
                return ( );
            }
            $fixedDepreciationRate = 1 - pow( $salvage / $cost, 1 / $life );
            $fixedDepreciationRate = round( $fixedDepreciationRate, 3 );
            $previousDepreciation = 0;
            $per = 1;
            for ( ; $per <= $period; ++$per )
            {
                $depreciation = min( ( $cost - $previousDepreciation ) * ( $factor / $life ), $cost - $salvage - $previousDepreciation );
                $previousDepreciation += $depreciation;
            }
            if ( ( ) == PHPExcel_Calculation_Functions::COMPATIBILITY_GNUMERIC )
            {
                $depreciation = round( $depreciation, 2 );
            }
            return $depreciation;
        }
        return ( );
    }

    public static function DISC( $settlement, $maturity, $price, $redemption, $basis = 0 )
    {
        $settlement = ( $settlement );
        $maturity = ( $maturity );
        $price = ( $price );
        $redemption = ( $redemption );
        $basis = ( $basis );
        if ( is_numeric( $price ) && is_numeric( $redemption ) && is_numeric( $basis ) )
        {
            $price = ( double );
            $redemption = ( double );
            $basis = ( integer );
            if ( $price <= 0 || $redemption <= 0 )
            {
                return ( );
            }
            $daysBetweenSettlementAndMaturity = ( $settlement, $maturity, $basis );
            if ( is_numeric( $daysBetweenSettlementAndMaturity ) )
            {
                return $daysBetweenSettlementAndMaturity;
            }
            return ( 1 - $price / $redemption ) / $daysBetweenSettlementAndMaturity;
        }
        return ( );
    }

    public static function DOLLARDE( $fractional_dollar = NULL, $fraction = 0 )
    {
        $fractional_dollar = ( $fractional_dollar );
        $fraction = ( integer );
        if ( is_null( $fractional_dollar ) || $fraction < 0 )
        {
            return ( );
        }
        if ( $fraction == 0 )
        {
            return ( );
        }
        $dollars = floor( $fractional_dollar );
        $cents = fmod( $fractional_dollar, 1 );
        $cents /= $fraction;
        $cents *= pow( 10, ceil( log10( $fraction ) ) );
        return $dollars + $cents;
    }

    public static function DOLLARFR( $decimal_dollar = NULL, $fraction = 0 )
    {
        $decimal_dollar = ( $decimal_dollar );
        $fraction = ( integer );
        if ( is_null( $decimal_dollar ) || $fraction < 0 )
        {
            return ( );
        }
        if ( $fraction == 0 )
        {
            return ( );
        }
        $dollars = floor( $decimal_dollar );
        $cents = fmod( $decimal_dollar, 1 );
        $cents *= $fraction;
        $cents *= pow( 10, 0 - ceil( log10( $fraction ) ) );
        return $dollars + $cents;
    }

    public static function EFFECT( $nominal_rate = 0, $npery = 0 )
    {
        $nominal_rate = ( $nominal_rate );
        $npery = ( integer );
        if ( $nominal_rate <= 0 || $npery < 1 )
        {
            return ( );
        }
        return pow( 1 + $nominal_rate / $npery, $npery ) - 1;
    }

    public static function FV( $rate = 0, $nper = 0, $pmt = 0, $pv = 0, $type = 0 )
    {
        $rate = ( $rate );
        $nper = ( $nper );
        $pmt = ( $pmt );
        $pv = ( $pv );
        $type = ( $type );
        if ( $type != 0 && $type != 1 )
        {
            return ( );
        }
        if ( !is_null( $rate ) && $rate != 0 )
        {
            return 0 - $pv * pow( 1 + $rate, $nper ) - $pmt * ( 1 + $rate * $type ) * ( pow( 1 + $rate, $nper ) - 1 ) / $rate;
        }
        return 0 - $pv - $pmt * $nper;
    }

    public static function FVSCHEDULE( $principal, $schedule )
    {
        $principal = ( $principal );
        $schedule = ( $schedule );
        foreach ( $schedule as $rate )
        {
            $principal *= 1 + $rate;
        }
        return $principal;
    }

    public static function INTRATE( $settlement, $maturity, $investment, $redemption, $basis = 0 )
    {
        $settlement = ( $settlement );
        $maturity = ( $maturity );
        $investment = ( $investment );
        $redemption = ( $redemption );
        $basis = ( $basis );
        if ( is_numeric( $investment ) && is_numeric( $redemption ) && is_numeric( $basis ) )
        {
            $investment = ( double );
            $redemption = ( double );
            $basis = ( integer );
            if ( $investment <= 0 || $redemption <= 0 )
            {
                return ( );
            }
            $daysBetweenSettlementAndMaturity = ( $settlement, $maturity, $basis );
            if ( is_numeric( $daysBetweenSettlementAndMaturity ) )
            {
                return $daysBetweenSettlementAndMaturity;
            }
            return ( $redemption / $investment - 1 ) / $daysBetweenSettlementAndMaturity;
        }
        return ( );
    }

    public static function IPMT( $rate, $per, $nper, $pv, $fv = 0, $type = 0 )
    {
        $rate = ( $rate );
        $per = ( integer );
        $nper = ( integer );
        $pv = ( $pv );
        $fv = ( $fv );
        $type = ( integer );
        if ( $type != 0 && $type != 1 )
        {
            return ( );
        }
        if ( $per <= 0 || $nper < $per )
        {
            return ( );
        }
        $interestAndPrincipal = ( $rate, $per, $nper, $pv, $fv, $type );
        return $interestAndPrincipal[0];
    }

    public static function IRR( $values, $guess = 0.1 )
    {
        if ( is_array( $values ) )
        {
            return ( );
        }
        $values = ( $values );
        $guess = ( $guess );
        $x1 = 0;
        $x2 = $guess;
        $f1 = ( $x1, $values );
        $f2 = ( $x2, $values );
        $i = 0;
        for ( ; $i < FINANCIAL_MAX_ITERATIONS; ++$i )
        {
            if ( $f1 * $f2 < 0 )
            {
            }
            else if ( abs( $f1 ) < abs( $f2 ) )
            {
                $f1 = ( $x1 += 1.6 * ( $x1 - $x2 ), $values );
            }
            else
            {
                $f2 = ( $x2 += 1.6 * ( $x2 - $x1 ), $values );
            }
        }
        if ( 0 < $f1 * $f2 )
        {
            return ( );
        }
        $f = ( $x1, $values );
        if ( $f < 0 )
        {
            $rtb = $x1;
            $dx = $x2 - $x1;
        }
        else
        {
            $rtb = $x2;
            $dx = $x1 - $x2;
        }
        $i = 0;
        for ( ; $i < FINANCIAL_MAX_ITERATIONS; ++$i )
        {
            $dx *= 0.5;
            $x_mid = $rtb + $dx;
            $f_mid = ( $x_mid, $values );
            if ( $f_mid <= 0 )
            {
                $rtb = $x_mid;
            }
            if ( !( abs( $f_mid ) < FINANCIAL_PRECISION ) && !( abs( $dx ) < FINANCIAL_PRECISION ) )
            {
                return $x_mid;
            }
        }
        return ( );
    }

    public static function ISPMT( )
    {
        $returnValue = 0;
        $aArgs = ( func_get_args( ) );
        $interestRate = array_shift( &$aArgs );
        $period = array_shift( &$aArgs );
        $numberPeriods = array_shift( &$aArgs );
        $principleRemaining = array_shift( &$aArgs );
        $principlePayment = $principleRemaining * 1 / ( $numberPeriods * 1 );
        $i = 0;
        for ( ; $i <= $period; ++$i )
        {
            $returnValue = $interestRate * $principleRemaining * -1;
            $principleRemaining -= $principlePayment;
            if ( $i == $numberPeriods )
            {
                $returnValue = 0;
            }
        }
        return $returnValue;
    }

    public static function MIRR( $values, $finance_rate, $reinvestment_rate )
    {
        if ( is_array( $values ) )
        {
            return ( );
        }
        $values = ( $values );
        $finance_rate = ( $finance_rate );
        $reinvestment_rate = ( $reinvestment_rate );
        $n = count( $values );
        $rr = 1 + $reinvestment_rate;
        $fr = 1 + $finance_rate;
        $npv_pos = $npv_neg = 0;
        foreach ( $values as $i => $v )
        {
            if ( 0 <= $v )
            {
                $npv_pos += $v / pow( $rr, $i );
            }
            else
            {
                $npv_neg += $v / pow( $fr, $i );
            }
        }
        if ( $npv_neg == 0 || $npv_pos == 0 || $reinvestment_rate <= -1 )
        {
            return ( );
        }
        $mirr = pow( ( 0 - $npv_pos * pow( $rr, $n ) ) / ( $npv_neg * $rr ), 1 / ( $n - 1 ) ) - 1;
        if ( is_finite( $mirr ) )
        {
            return $mirr;
        }
        return ( );
    }

    public static function NOMINAL( $effect_rate = 0, $npery = 0 )
    {
        $effect_rate = ( $effect_rate );
        $npery = ( integer );
        if ( $effect_rate <= 0 || $npery < 1 )
        {
            return ( );
        }
        return $npery * ( pow( $effect_rate + 1, 1 / $npery ) - 1 );
    }

    public static function NPER( $rate = 0, $pmt = 0, $pv = 0, $fv = 0, $type = 0 )
    {
        $rate = ( $rate );
        $pmt = ( $pmt );
        $pv = ( $pv );
        $fv = ( $fv );
        $type = ( $type );
        if ( $type != 0 && $type != 1 )
        {
            return ( );
        }
        if ( !is_null( $rate ) && $rate != 0 )
        {
            if ( $pmt == 0 && $pv == 0 )
            {
                return ( );
            }
            return log( ( $pmt * ( 1 + $rate * $type ) / $rate - $fv ) / ( $pv + $pmt * ( 1 + $rate * $type ) / $rate ) ) / log( 1 + $rate );
        }
        if ( $pmt == 0 )
        {
            return ( );
        }
        return ( 0 - $pv - $fv ) / $pmt;
    }

    public static function NPV( )
    {
        $returnValue = 0;
        $aArgs = ( func_get_args( ) );
        $rate = array_shift( &$aArgs );
        $i = 1;
        for ( ; $i <= count( $aArgs ); ++$i )
        {
            if ( is_numeric( $aArgs[$i - 1] ) )
            {
                $returnValue += $aArgs[$i - 1] / pow( 1 + $rate, $i );
            }
        }
        return $returnValue;
    }

    public static function PMT( $rate = 0, $nper = 0, $pv = 0, $fv = 0, $type = 0 )
    {
        $rate = ( $rate );
        $nper = ( $nper );
        $pv = ( $pv );
        $fv = ( $fv );
        $type = ( $type );
        if ( $type != 0 && $type != 1 )
        {
            return ( );
        }
        if ( !is_null( $rate ) && $rate != 0 )
        {
            return ( 0 - $fv - $pv * pow( 1 + $rate, $nper ) ) / ( 1 + $rate * $type ) / ( ( pow( 1 + $rate, $nper ) - 1 ) / $rate );
        }
        return ( 0 - $pv - $fv ) / $nper;
    }

    public static function PPMT( $rate, $per, $nper, $pv, $fv = 0, $type = 0 )
    {
        $rate = ( $rate );
        $per = ( integer );
        $nper = ( integer );
        $pv = ( $pv );
        $fv = ( $fv );
        $type = ( integer );
        if ( $type != 0 && $type != 1 )
        {
            return ( );
        }
        if ( $per <= 0 || $nper < $per )
        {
            return ( );
        }
        $interestAndPrincipal = ( $rate, $per, $nper, $pv, $fv, $type );
        return $interestAndPrincipal[1];
    }

    public static function PRICE( $settlement, $maturity, $rate, $yield, $redemption, $frequency, $basis = 0 )
    {
        $settlement = ( $settlement );
        $maturity = ( $maturity );
        $rate = ( double );
        $yield = ( double );
        $redemption = ( double );
        $frequency = ( integer );
        $basis = is_null( $basis ) ? 0 : ( integer );
        if ( is_string( $settlement = ( $settlement ) ) )
        {
            return ( );
        }
        if ( is_string( $maturity = ( $maturity ) ) )
        {
            return ( );
        }
        do
        {
            if ( $maturity < $settlement )
            {
                break;
            }
            else
            {
            }
            if ( !( $frequency ) || $basis < 0 || 4 < $basis )
            {
            }
        } while ( 0 );
        return ( );
        $dsc = ( $settlement, $maturity, $frequency, $basis );
        $e = ( $settlement, $maturity, $frequency, $basis );
        $n = ( $settlement, $maturity, $frequency, $basis );
        $a = ( $settlement, $maturity, $frequency, $basis );
        $baseYF = 1 + $yield / $frequency;
        $rfp = 100 * ( $rate / $frequency );
        $de = $dsc / $e;
        $result = $redemption / pow( $baseYF, --$n + $de );
        $k = 0;
        for ( ; $k <= $n; ++$k )
        {
            $result += $rfp / pow( $baseYF, $k + $de );
        }
        $result -= $rfp * ( $a / $e );
        return $result;
    }

    public static function PRICEDISC( $settlement, $maturity, $discount, $redemption, $basis = 0 )
    {
        $settlement = ( $settlement );
        $maturity = ( $maturity );
        $discount = ( double );
        $redemption = ( double );
        $basis = ( integer );
        if ( is_numeric( $discount ) && is_numeric( $redemption ) && is_numeric( $basis ) )
        {
            if ( $discount <= 0 || $redemption <= 0 )
            {
                return ( );
            }
            $daysBetweenSettlementAndMaturity = ( $settlement, $maturity, $basis );
            if ( is_numeric( $daysBetweenSettlementAndMaturity ) )
            {
                return $daysBetweenSettlementAndMaturity;
            }
            return $redemption * ( 1 - $discount * $daysBetweenSettlementAndMaturity );
        }
        return ( );
    }

    public static function PRICEMAT( $settlement, $maturity, $issue, $rate, $yield, $basis = 0 )
    {
        $settlement = ( $settlement );
        $maturity = ( $maturity );
        $issue = ( $issue );
        $rate = ( $rate );
        $yield = ( $yield );
        $basis = ( integer );
        if ( is_numeric( $rate ) && is_numeric( $yield ) )
        {
            if ( $rate <= 0 || $yield <= 0 )
            {
                return ( );
            }
            $daysPerYear = ( ( $settlement ), $basis );
            if ( is_numeric( $daysPerYear ) )
            {
                return $daysPerYear;
            }
            $daysBetweenIssueAndSettlement = ( $issue, $settlement, $basis );
            if ( is_numeric( $daysBetweenIssueAndSettlement ) )
            {
                return $daysBetweenIssueAndSettlement;
            }
            $daysBetweenIssueAndSettlement *= $daysPerYear;
            $daysBetweenIssueAndMaturity = ( $issue, $maturity, $basis );
            if ( is_numeric( $daysBetweenIssueAndMaturity ) )
            {
                return $daysBetweenIssueAndMaturity;
            }
            $daysBetweenIssueAndMaturity *= $daysPerYear;
            $daysBetweenSettlementAndMaturity = ( $settlement, $maturity, $basis );
            if ( is_numeric( $daysBetweenSettlementAndMaturity ) )
            {
                return $daysBetweenSettlementAndMaturity;
            }
            $daysBetweenSettlementAndMaturity *= $daysPerYear;
            return ( 100 + $daysBetweenIssueAndMaturity / $daysPerYear * $rate * 100 ) / ( 1 + $daysBetweenSettlementAndMaturity / $daysPerYear * $yield ) - $daysBetweenIssueAndSettlement / $daysPerYear * $rate * 100;
        }
        return ( );
    }

    public static function PV( $rate = 0, $nper = 0, $pmt = 0, $fv = 0, $type = 0 )
    {
        $rate = ( $rate );
        $nper = ( $nper );
        $pmt = ( $pmt );
        $fv = ( $fv );
        $type = ( $type );
        if ( $type != 0 && $type != 1 )
        {
            return ( );
        }
        if ( !is_null( $rate ) && $rate != 0 )
        {
            return ( 0 - $pmt * ( 1 + $rate * $type ) * ( ( pow( 1 + $rate, $nper ) - 1 ) / $rate ) - $fv ) / pow( 1 + $rate, $nper );
        }
        return 0 - $fv - $pmt * $nper;
    }

    public static function RATE( $nper, $pmt, $pv, $fv = 0, $type = 0, $guess = 0.1 )
    {
        $nper = ( integer );
        $pmt = ( $pmt );
        $pv = ( $pv );
        $fv = is_null( $fv ) ? 0 : ( $fv );
        $type = is_null( $type ) ? 0 : ( integer );
        $guess = is_null( $guess ) ? 0.1 : ( $guess );
        $rate = $guess;
        if ( abs( $rate ) < FINANCIAL_PRECISION )
        {
            $y = $pv * ( 1 + $nper * $rate ) + $pmt * ( 1 + $rate * $type ) * $nper + $fv;
        }
        else
        {
            $f = exp( $nper * log( 1 + $rate ) );
            $y = $pv * $f + $pmt * ( 1 / $rate + $type ) * ( $f - 1 ) + $fv;
        }
        $y0 = $pv + $pmt * $nper + $fv;
        $y1 = $pv * $f + $pmt * ( 1 / $rate + $type ) * ( $f - 1 ) + $fv;
        $i = $x0 = 0;
        $x1 = $rate;
        while ( !( FINANCIAL_PRECISION < abs( $y0 - $y1 ) ) || !( $i < FINANCIAL_MAX_ITERATIONS ) )
        {
            $rate = ( $y1 * $x0 - $y0 * $x1 ) / ( $y1 - $y0 );
            $x0 = $x1;
            $x1 = $rate;
            if ( $pv - $fv < $nper * abs( $pmt ) )
            {
                $x1 = abs( $x1 );
            }
            if ( abs( $rate ) < FINANCIAL_PRECISION )
            {
                $y = $pv * ( 1 + $nper * $rate ) + $pmt * ( 1 + $rate * $type ) * $nper + $fv;
            }
            else
            {
                $f = exp( $nper * log( 1 + $rate ) );
                $y = $pv * $f + $pmt * ( 1 / $rate + $type ) * ( $f - 1 ) + $fv;
            }
            $y0 = $y1;
            $y1 = $y;
            ++$i;
        }
        return $rate;
    }

    public static function RECEIVED( $settlement, $maturity, $investment, $discount, $basis = 0 )
    {
        $settlement = ( $settlement );
        $maturity = ( $maturity );
        $investment = ( double );
        $discount = ( double );
        $basis = ( integer );
        if ( is_numeric( $investment ) && is_numeric( $discount ) && is_numeric( $basis ) )
        {
            if ( $investment <= 0 || $discount <= 0 )
            {
                return ( );
            }
            $daysBetweenSettlementAndMaturity = ( $settlement, $maturity, $basis );
            if ( is_numeric( $daysBetweenSettlementAndMaturity ) )
            {
                return $daysBetweenSettlementAndMaturity;
            }
            return $investment / ( 1 - $discount * $daysBetweenSettlementAndMaturity );
        }
        return ( );
    }

    public static function SLN( $cost, $salvage, $life )
    {
        $cost = ( $cost );
        $salvage = ( $salvage );
        $life = ( $life );
        if ( is_numeric( $cost ) && is_numeric( $salvage ) && is_numeric( $life ) )
        {
            if ( $life < 0 )
            {
                return ( );
            }
            return ( $cost - $salvage ) / $life;
        }
        return ( );
    }

    public static function SYD( $cost, $salvage, $life, $period )
    {
        $cost = ( $cost );
        $salvage = ( $salvage );
        $life = ( $life );
        $period = ( $period );
        if ( is_numeric( $cost ) && is_numeric( $salvage ) && is_numeric( $life ) && is_numeric( $period ) )
        {
            if ( $life < 1 || $life < $period )
            {
                return ( );
            }
            return ( $cost - $salvage ) * ( $life - $period + 1 ) * 2 / ( $life * ( $life + 1 ) );
        }
        return ( );
    }

    public static function TBILLEQ( $settlement, $maturity, $discount )
    {
        $settlement = ( $settlement );
        $maturity = ( $maturity );
        $discount = ( $discount );
        $testValue = ( $settlement, $maturity, $discount );
        if ( is_string( $testValue ) )
        {
            return $testValue;
        }
        if ( is_string( $maturity = ( $maturity ) ) )
        {
            return ( );
        }
        if ( ( ) == PHPExcel_Calculation_Functions::COMPATIBILITY_OPENOFFICE )
        {
            ++$maturity;
            $daysBetweenSettlementAndMaturity = ( $settlement, $maturity ) * 360;
        }
        else
        {
            $daysBetweenSettlementAndMaturity = ( $maturity ) - ( $settlement );
        }
        return 365 * $discount / ( 360 - $discount * $daysBetweenSettlementAndMaturity );
    }

    public static function TBILLPRICE( $settlement, $maturity, $discount )
    {
        $settlement = ( $settlement );
        $maturity = ( $maturity );
        $discount = ( $discount );
        if ( is_string( $maturity = ( $maturity ) ) )
        {
            return ( );
        }
        if ( is_numeric( $discount ) )
        {
            if ( $discount <= 0 )
            {
                return ( );
            }
            if ( ( ) == PHPExcel_Calculation_Functions::COMPATIBILITY_OPENOFFICE )
            {
                ++$maturity;
                $daysBetweenSettlementAndMaturity = ( $settlement, $maturity ) * 360;
                if ( is_numeric( $daysBetweenSettlementAndMaturity ) )
                {
                    return $daysBetweenSettlementAndMaturity;
                }
            }
            $daysBetweenSettlementAndMaturity = ( $maturity ) - ( $settlement );
            if ( 360 < $daysBetweenSettlementAndMaturity )
            {
                return ( );
            }
            $price = 100 * ( 1 - $discount * $daysBetweenSettlementAndMaturity / 360 );
            if ( $price <= 0 )
            {
                return ( );
            }
            return $price;
        }
        return ( );
    }

    public static function TBILLYIELD( $settlement, $maturity, $price )
    {
        $settlement = ( $settlement );
        $maturity = ( $maturity );
        $price = ( $price );
        if ( is_numeric( $price ) )
        {
            if ( $price <= 0 )
            {
                return ( );
            }
            if ( ( ) == PHPExcel_Calculation_Functions::COMPATIBILITY_OPENOFFICE )
            {
                ++$maturity;
                $daysBetweenSettlementAndMaturity = ( $settlement, $maturity ) * 360;
                if ( is_numeric( $daysBetweenSettlementAndMaturity ) )
                {
                    return $daysBetweenSettlementAndMaturity;
                }
            }
            $daysBetweenSettlementAndMaturity = ( $maturity ) - ( $settlement );
            if ( 360 < $daysBetweenSettlementAndMaturity )
            {
                return ( );
            }
            return ( 100 - $price ) / $price * ( 360 / $daysBetweenSettlementAndMaturity );
        }
        return ( );
    }

    public static function XIRR( $values, $dates, $guess = 0.1 )
    {
        if ( !is_array( $values ) && !is_array( $dates ) )
        {
            return ( );
        }
        $values = ( $values );
        $dates = ( $dates );
        $guess = ( $guess );
        if ( count( $values ) != count( $dates ) )
        {
            return ( );
        }
        $x1 = 0;
        $x2 = $guess;
        $f1 = ( $x1, $values, $dates );
        $f2 = ( $x2, $values, $dates );
        $i = 0;
        for ( ; $i < FINANCIAL_MAX_ITERATIONS; ++$i )
        {
            if ( $f1 * $f2 < 0 )
            {
            }
            else if ( abs( $f1 ) < abs( $f2 ) )
            {
                $f1 = ( $x1 += 1.6 * ( $x1 - $x2 ), $values, $dates );
            }
            else
            {
                $f2 = ( $x2 += 1.6 * ( $x2 - $x1 ), $values, $dates );
            }
        }
        if ( 0 < $f1 * $f2 )
        {
            return ( );
        }
        $f = ( $x1, $values, $dates );
        if ( $f < 0 )
        {
            $rtb = $x1;
            $dx = $x2 - $x1;
        }
        else
        {
            $rtb = $x2;
            $dx = $x1 - $x2;
        }
        $i = 0;
        for ( ; $i < FINANCIAL_MAX_ITERATIONS; ++$i )
        {
            $dx *= 0.5;
            $x_mid = $rtb + $dx;
            $f_mid = ( $x_mid, $values, $dates );
            if ( $f_mid <= 0 )
            {
                $rtb = $x_mid;
            }
            if ( !( abs( $f_mid ) < FINANCIAL_PRECISION ) && !( abs( $dx ) < FINANCIAL_PRECISION ) )
            {
                return $x_mid;
            }
        }
        return ( );
    }

    public static function XNPV( $rate, $values, $dates )
    {
        $rate = ( $rate );
        if ( is_numeric( $rate ) )
        {
            return ( );
        }
        if ( !is_array( $values ) || !is_array( $dates ) )
        {
            return ( );
        }
        $values = ( $values );
        $dates = ( $dates );
        $valCount = count( $values );
        if ( $valCount != count( $dates ) )
        {
            return ( );
        }
        if ( 0 < min( $values ) || max( $values ) < 0 )
        {
            return ( );
        }
        $xnpv = 0;
        $i = 0;
        for ( ; $i < $valCount; ++$i )
        {
            if ( is_numeric( $values[$i] ) )
            {
                return ( );
            }
            $xnpv += $values[$i] / pow( 1 + $rate, ( $dates[0], $dates[$i], "d" ) / 365 );
        }
        if ( is_finite( $xnpv ) )
        {
            return $xnpv;
        }
        return ( );
    }

    public static function YIELDDISC( $settlement, $maturity, $price, $redemption, $basis = 0 )
    {
        $settlement = ( $settlement );
        $maturity = ( $maturity );
        $price = ( $price );
        $redemption = ( $redemption );
        $basis = ( integer );
        if ( is_numeric( $price ) && is_numeric( $redemption ) )
        {
            if ( $price <= 0 || $redemption <= 0 )
            {
                return ( );
            }
            $daysPerYear = ( ( $settlement ), $basis );
            if ( is_numeric( $daysPerYear ) )
            {
                return $daysPerYear;
            }
            $daysBetweenSettlementAndMaturity = ( $settlement, $maturity, $basis );
            if ( is_numeric( $daysBetweenSettlementAndMaturity ) )
            {
                return $daysBetweenSettlementAndMaturity;
            }
            $daysBetweenSettlementAndMaturity *= $daysPerYear;
            return ( $redemption - $price ) / $price * ( $daysPerYear / $daysBetweenSettlementAndMaturity );
        }
        return ( );
    }

    public static function YIELDMAT( $settlement, $maturity, $issue, $rate, $price, $basis = 0 )
    {
        $settlement = ( $settlement );
        $maturity = ( $maturity );
        $issue = ( $issue );
        $rate = ( $rate );
        $price = ( $price );
        $basis = ( integer );
        if ( is_numeric( $rate ) && is_numeric( $price ) )
        {
            if ( $rate <= 0 || $price <= 0 )
            {
                return ( );
            }
            $daysPerYear = ( ( $settlement ), $basis );
            if ( is_numeric( $daysPerYear ) )
            {
                return $daysPerYear;
            }
            $daysBetweenIssueAndSettlement = ( $issue, $settlement, $basis );
            if ( is_numeric( $daysBetweenIssueAndSettlement ) )
            {
                return $daysBetweenIssueAndSettlement;
            }
            $daysBetweenIssueAndSettlement *= $daysPerYear;
            $daysBetweenIssueAndMaturity = ( $issue, $maturity, $basis );
            if ( is_numeric( $daysBetweenIssueAndMaturity ) )
            {
                return $daysBetweenIssueAndMaturity;
            }
            $daysBetweenIssueAndMaturity *= $daysPerYear;
            $daysBetweenSettlementAndMaturity = ( $settlement, $maturity, $basis );
            if ( is_numeric( $daysBetweenSettlementAndMaturity ) )
            {
                return $daysBetweenSettlementAndMaturity;
            }
            $daysBetweenSettlementAndMaturity *= $daysPerYear;
            return ( 1 + $daysBetweenIssueAndMaturity / $daysPerYear * $rate - ( $price / 100 + $daysBetweenIssueAndSettlement / $daysPerYear * $rate ) ) / ( $price / 100 + $daysBetweenIssueAndSettlement / $daysPerYear * $rate ) * ( $daysPerYear / $daysBetweenSettlementAndMaturity );
        }
        return ( );
    }

}

if ( defined( "PHPEXCEL_ROOT" ) )
{
    define( "PHPEXCEL_ROOT", dirname( __FILE__ )."/../../" );
    require( PHPEXCEL_ROOT."PHPExcel/Autoloader.php" );
}
define( "FINANCIAL_MAX_ITERATIONS", 128 );
define( "FINANCIAL_PRECISION", 1e-008 );
?>
