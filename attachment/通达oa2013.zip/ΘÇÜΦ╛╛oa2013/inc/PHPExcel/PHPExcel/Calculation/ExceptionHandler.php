<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class PHPExcel_Calculation_ExceptionHandler
{

    public function __construct( )
    {
        set_error_handler( array( "PHPExcel_Calculation_Exception", "errorHandlerCallback" ), E_ALL );
    }

    public function __destruct( )
    {
        restore_error_handler( );
    }

}

?>
