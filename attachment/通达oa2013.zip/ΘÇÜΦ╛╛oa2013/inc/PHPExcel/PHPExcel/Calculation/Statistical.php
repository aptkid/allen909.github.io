<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class PHPExcel_Calculation_Statistical
{

    private static $_logBetaCache_p = 0;
    private static $_logBetaCache_q = 0;
    private static $_logBetaCache_result = 0;
    private static $_logGammaCache_result = 0;
    private static $_logGammaCache_x = 0;

    private static function _checkTrendArrays( &$array1, &$array2 )
    {
        if ( is_array( $array1 ) )
        {
            $array1 = array( $array1 );
        }
        if ( is_array( $array2 ) )
        {
            $array2 = array( $array2 );
        }
        $array1 = ( $array1 );
        $array2 = ( $array2 );
        foreach ( $array1 as $key => $value )
        {
            if ( !is_bool( $value ) && !is_string( $value ) && !is_null( $value ) )
            {
                unset( $array1[$key] );
                unset( $array2[$key] );
            }
        }
        foreach ( $array2 as $key => $value )
        {
            if ( !is_bool( $value ) && !is_string( $value ) && !is_null( $value ) )
            {
                unset( $array1[$key] );
                unset( $array2[$key] );
            }
        }
        $array1 = array_merge( $array1 );
        $array2 = array_merge( $array2 );
        return TRUE;
    }

    private static function _beta( $p, $q )
    {
        if ( $p <= 0 || $q <= 0 || LOG_GAMMA_X_MAX_VALUE < $p + $q )
        {
            return 0;
        }
        return exp( ( $p, $q ) );
    }

    private static function _incompleteBeta( $x, $p, $q )
    {
        if ( $x <= 0 )
        {
            return 0;
        }
        if ( 1 <= $x )
        {
            return 1;
        }
        if ( $p <= 0 || $q <= 0 || LOG_GAMMA_X_MAX_VALUE < $p + $q )
        {
            return 0;
        }
        $beta_gam = exp( 0 - ( $p, $q ) + $p * log( $x ) + $q * log( 1 - $x ) );
        if ( $x < ( $p + 1 ) / ( $p + $q + 2 ) )
        {
            return $beta_gam * ( $x, $p, $q ) / $p;
        }
        return 1 - $beta_gam * ( 1 - $x, $q, $p ) / $q;
    }

    private static function _logBeta( $p, $q )
    {
        do
        {
            if ( $p != self::$_logBetaCache_p )
            {
                break;
            }
            else
            {
            }
            if ( $q != self::$_logBetaCache_q )
            {
            }
        } while ( 0 );
        self::$_logBetaCache_p = $p;
        self::$_logBetaCache_q = $q;
        if ( $p <= 0 || $q <= 0 || LOG_GAMMA_X_MAX_VALUE < $p + $q )
        {
            self::$_logBetaCache_result = 0;
        }
        else
        {
            self::$_logBetaCache_result = ( $p ) + ( $q ) - ( $p + $q );
        }
        return self::$_logBetaCache_result;
    }

    private static function _betaFraction( $x, $p, $q )
    {
        $c = 1;
        $sum_pq = $p + $q;
        $p_plus = $p + 1;
        $p_minus = $p - 1;
        $h = 1 - $sum_pq * $x / $p_plus;
        if ( abs( $h ) < XMININ )
        {
            $h = XMININ;
        }
        $h = 1 / $h;
        $frac = $h;
        $m = 1;
        $delta = 0;
        while ( !( $m <= MAX_ITERATIONS ) || !( PRECISION < abs( $delta - 1 ) ) )
        {
            $m2 = 2 * $m;
            $d = $m * ( $q - $m ) * $x / ( ( $p_minus + $m2 ) * ( $p + $m2 ) );
            $h = 1 + $d * $h;
            if ( abs( $h ) < XMININ )
            {
                $h = XMININ;
            }
            $h = 1 / $h;
            $c = 1 + $d / $c;
            if ( abs( $c ) < XMININ )
            {
                $c = XMININ;
            }
            $frac *= $h * $c;
            $d = 0 - ( $p + $m ) * ( $sum_pq + $m ) * $x / ( ( $p + $m2 ) * ( $p_plus + $m2 ) );
            $h = 1 + $d * $h;
            if ( abs( $h ) < XMININ )
            {
                $h = XMININ;
            }
            $h = 1 / $h;
            $c = 1 + $d / $c;
            if ( abs( $c ) < XMININ )
            {
                $c = XMININ;
            }
            $delta = $h * $c;
            $frac *= $delta;
            ++$m;
        }
        return $frac;
    }

    private static function _logGamma( $x )
    {
        static $lg_d1 = -0.577216;
        static $lg_d2 = 0.422784;
        static $lg_d4 = 1.79176;
        static $lg_p1 = array( 4.94524, 201.811, 2290.84, 11319.7, 28557.2, 38485, 26377.5, 7225.81 );
        static $lg_p2 = array( 4.97461, 542.414, 15506.9, 184793, 1.0882e+006, 3.33815e+006, 5.10666e+006, 3.07411e+006 );
        static $lg_p4 = array( 14745, 2.42681e+006, 1.21476e+008, 2.66343e+009, 2.94038e+010, 1.70267e+011, 4.92613e+011, 5.60625e+011 );
        static $lg_q1 = array( 67.4821, 1113.33, 7738.76, 27639.9, 54993.1, 61611.2, 36351.3, 8785.54 );
        static $lg_q2 = array( 183.033, 7765.05, 133190, 1.13671e+006, 5.26796e+006, 1.3467e+007, 1.78274e+007, 9.5331e+006 );
        static $lg_q4 = array( 2690.53, 639389, 4.1356e+007, 1.12087e+009, 1.48861e+010, 1.0168e+011, 3.41748e+011, 4.46316e+011 );
        static $lg_c = array( -0.00191044, 0.000841714, -0.000595238, 0.000793651, -0.00277778, 0.0833333, 0.00570838 );
        static $lg_frtbig = 2.25e+076;
        static $pnt68 = 0.679688;
        if ( $x == self::$_logGammaCache_x )
        {
            return self::$_logGammaCache_result;
        }
        $y = $x;
        if ( 0 < $y && $y <= LOG_GAMMA_X_MAX_VALUE )
        {
            if ( $y <= EPS )
            {
                $res = 0 - log( y );
            }
            else
            {
                if ( $y <= 1.5 )
                {
                    if ( $y < $pnt68 )
                    {
                        $corr = 0 - log( $y );
                        $xm1 = $y;
                    }
                    else
                    {
                        $corr = 0;
                        $xm1 = $y - 1;
                    }
                    if ( $y <= 0.5 || $pnt68 <= $y )
                    {
                        $xden = 1;
                        $xnum = 0;
                        $i = 0;
                        for ( ; $i < 8; ++$i )
                        {
                            $xnum = $xnum * $xm1 + $lg_p1[$i];
                            $xden = $xden * $xm1 + $lg_q1[$i];
                        }
                        $res = $corr + $xm1 * ( $lg_d1 + $xm1 * ( $xnum / $xden ) );
                    }
                    else
                    {
                        $xm2 = $y - 1;
                        $xden = 1;
                        $xnum = 0;
                        $i = 0;
                        for ( ; $i < 8; ++$i )
                        {
                            $xnum = $xnum * $xm2 + $lg_p2[$i];
                            $xden = $xden * $xm2 + $lg_q2[$i];
                        }
                        $res = $corr + $xm2 * ( $lg_d2 + $xm2 * ( $xnum / $xden ) );
                    }
                }
                else
                {
                    if ( $y <= 4 )
                    {
                        $xm2 = $y - 2;
                        $xden = 1;
                        $xnum = 0;
                        $i = 0;
                        for ( ; $i < 8; ++$i )
                        {
                            $xnum = $xnum * $xm2 + $lg_p2[$i];
                            $xden = $xden * $xm2 + $lg_q2[$i];
                        }
                        $res = $xm2 * ( $lg_d2 + $xm2 * ( $xnum / $xden ) );
                    }
                    else
                    {
                        if ( $y <= 12 )
                        {
                            $xm4 = $y - 4;
                            $xden = -1;
                            $xnum = 0;
                            $i = 0;
                            for ( ; $i < 8; ++$i )
                            {
                                $xnum = $xnum * $xm4 + $lg_p4[$i];
                                $xden = $xden * $xm4 + $lg_q4[$i];
                            }
                            $res = $lg_d4 + $xm4 * ( $xnum / $xden );
                        }
                        else
                        {
                            $res = 0;
                            if ( $y <= $lg_frtbig )
                            {
                                $res = $lg_c[6];
                                $ysq = $y * $y;
                                $i = 0;
                                for ( ; $i < 6; ++$i )
                                {
                                    $res = $res / $ysq + $lg_c[$i];
                                }
                            }
                            $res /= $y;
                            $corr = log( $y );
                            $res = $res + log( SQRT2PI ) - 0.5 * $corr;
                            $res += $y * ( $corr - 1 );
                        }
                    }
                }
            }
        }
        else
        {
            $res = MAX_VALUE;
        }
        self::$_logGammaCache_x = $x;
        self::$_logGammaCache_result = $res;
        return $res;
    }

    private static function _incompleteGamma( $a, $x )
    {
        static $max = 32;
        $summer = 0;
        $n = 0;
        for ( ; $n <= $max; ++$n )
        {
            $divisor = $a;
            $i = 1;
            for ( ; $i <= $n; ++$i )
            {
                $divisor *= $a + $i;
            }
            $summer += pow( $x, $n ) / $divisor;
        }
        return pow( $x, $a ) * exp( 0 - $x ) * $summer;
    }

    private static function _gamma( $data )
    {
        if ( $data == 0 )
        {
            return 0;
        }
        static $p0 = 1;
        static $p = array( 76.1801, -86.5053, 24.0141, -1.23174, 0.00120865, -5.39524e-006 );
        $y = $x = $data;
        $tmp = $x + 5.5;
        $tmp -= ( $x + 0.5 ) * log( $tmp );
        $summer = $p0;
        $j = 1;
        for ( ; $j <= 6; ++$j )
        {
            $summer += $p[$j] / ++$y;
        }
        return exp( 0 - $tmp + log( SQRT2PI * $summer / $x ) );
    }

    private static function _inverse_ncdf( $p )
    {
        static $a = array( -39.6968, 220.946, -275.929, 138.358, -30.6648, 2.50663 );
        static $b = array( -54.4761, 161.586, -155.699, 66.8013, -13.2807 );
        static $c = array( -0.00778489, -0.322396, -2.40076, -2.54973, 4.37466, 2.93816 );
        static $d = array( 0.0077847, 0.322467, 2.44513, 3.75441 );
        $p_low = 0.02425;
        $p_high = 1 - $p_low;
        if ( 0 < $p && $p < $p_low )
        {
            $q = sqrt( 0 - 2 * log( $p ) );
            return ( ( ( ( ( $c[1] * $q + $c[2] ) * $q + $c[3] ) * $q + $c[4] ) * $q + $c[5] ) * $q + $c[6] ) / ( ( ( ( $d[1] * $q + $d[2] ) * $q + $d[3] ) * $q + $d[4] ) * $q + 1 );
        }
        if ( $p_low <= $p && $p <= $p_high )
        {
            $q = $p - 0.5;
            $r = $q * $q;
            return ( ( ( ( ( $a[1] * $r + $a[2] ) * $r + $a[3] ) * $r + $a[4] ) * $r + $a[5] ) * $r + $a[6] ) * $q / ( ( ( ( ( $b[1] * $r + $b[2] ) * $r + $b[3] ) * $r + $b[4] ) * $r + $b[5] ) * $r + 1 );
        }
        if ( $p_high < $p && $p < 1 )
        {
            $q = sqrt( 0 - 2 * log( 1 - $p ) );
            return 0 - ( ( ( ( ( $c[1] * $q + $c[2] ) * $q + $c[3] ) * $q + $c[4] ) * $q + $c[5] ) * $q + $c[6] ) / ( ( ( ( $d[1] * $q + $d[2] ) * $q + $d[3] ) * $q + $d[4] ) * $q + 1 );
        }
        return ( );
    }

    private static function _inverse_ncdf2( $prob )
    {
        $a1 = 2.50663;
        $a2 = -18.615;
        $a3 = 41.3912;
        $a4 = -25.4411;
        $b1 = -8.47351;
        $b2 = 23.0834;
        $b3 = -21.0622;
        $b4 = 3.13083;
        $c1 = 0.337475;
        $c2 = 0.976169;
        $c3 = 0.160798;
        $c4 = 0.0276439;
        $c5 = 0.00384057;
        $c6 = 0.00039519;
        $c7 = 3.21768e-005;
        $c8 = 2.88817e-007;
        $c9 = 3.96032e-007;
        $y = $prob - 0.5;
        if ( abs( $y ) < 0.42 )
        {
            $z = $y * $y;
            $z = $y * ( ( ( $a4 * $z + $a3 ) * $z + $a2 ) * $z + $a1 ) / ( ( ( ( $b4 * $z + $b3 ) * $z + $b2 ) * $z + $b1 ) * $z + 1 );
            return $z;
        }
        if ( 0 < $y )
        {
            $z = log( 0 - log( 1 - $prob ) );
        }
        else
        {
            $z = log( 0 - log( $prob ) );
        }
        $z = $c1 + $z * ( $c2 + $z * ( $c3 + $z * ( $c4 + $z * ( $c5 + $z * ( $c6 + $z * ( $c7 + $z * ( $c8 + $z * $c9 ) ) ) ) ) ) );
        if ( $y < 0 )
        {
            $z = 0 - $z;
        }
        return $z;
    }

    private static function _inverse_ncdf3( $p )
    {
        $split1 = 0.425;
        $split2 = 5;
        $const1 = 0.180625;
        $const2 = 1.6;
        $a0 = 3.38713;
        $a1 = 133.142;
        $a2 = 1971.59;
        $a3 = 13731.7;
        $a4 = 45922;
        $a5 = 67265.8;
        $a6 = 33430.6;
        $a7 = 2509.08;
        $b1 = 42.3133;
        $b2 = 687.187;
        $b3 = 5394.2;
        $b4 = 21213.8;
        $b5 = 39307.9;
        $b6 = 28729.1;
        $b7 = 5226.5;
        $c0 = 1.42344;
        $c1 = 4.63034;
        $c2 = 5.7695;
        $c3 = 3.64785;
        $c4 = 1.27046;
        $c5 = 0.241781;
        $c6 = 0.0227238;
        $c7 = 0.000774545;
        $d1 = 2.05319;
        $d2 = 1.67638;
        $d3 = 0.689767;
        $d4 = 0.148104;
        $d5 = 0.0151987;
        $d6 = 0.000547594;
        $d7 = 1.05075e-009;
        $e0 = 6.6579;
        $e1 = 5.46378;
        $e2 = 1.78483;
        $e3 = 0.296561;
        $e4 = 0.0265322;
        $e5 = 0.00124266;
        $e6 = 2.71156e-005;
        $e7 = 2.01033e-007;
        $f1 = 0.599832;
        $f2 = 0.13693;
        $f3 = 0.0148754;
        $f4 = 0.000786869;
        $f5 = 1.84632e-005;
        $f6 = 1.42151e-007;
        $f7 = 2.04426e-015;
        $q = $p - 0.5;
        if ( abs( $q ) <= split1 )
        {
            $R = $const1 - $q * $q;
            $z = $q * ( ( ( ( ( ( ( $a7 * $R + $a6 ) * $R + $a5 ) * $R + $a4 ) * $R + $a3 ) * $R + $a2 ) * $R + $a1 ) * $R + $a0 ) / ( ( ( ( ( ( ( $b7 * $R + $b6 ) * $R + $b5 ) * $R + $b4 ) * $R + $b3 ) * $R + $b2 ) * $R + $b1 ) * $R + 1 );
            return $z;
        }
        if ( $q < 0 )
        {
            $R = $p;
        }
        else
        {
            $R = 1 - $p;
        }
        $R = pow( 0 - log( $R ), 2 );
        if ( $R <= $split2 )
        {
            $R -= $const2;
            $z = ( ( ( ( ( ( ( $c7 * $R + $c6 ) * $R + $c5 ) * $R + $c4 ) * $R + $c3 ) * $R + $c2 ) * $R + $c1 ) * $R + $c0 ) / ( ( ( ( ( ( ( $d7 * $R + $d6 ) * $R + $d5 ) * $R + $d4 ) * $R + $d3 ) * $R + $d2 ) * $R + $d1 ) * $R + 1 );
        }
        else
        {
            $R -= $split2;
            $z = ( ( ( ( ( ( ( $e7 * $R + $e6 ) * $R + $e5 ) * $R + $e4 ) * $R + $e3 ) * $R + $e2 ) * $R + $e1 ) * $R + $e0 ) / ( ( ( ( ( ( ( $f7 * $R + $f6 ) * $R + $f5 ) * $R + $f4 ) * $R + $f3 ) * $R + $f2 ) * $R + $f1 ) * $R + 1 );
        }
        if ( $q < 0 )
        {
            $z = 0 - $z;
        }
        return $z;
    }

    public static function AVEDEV( )
    {
        $aArgs = ( func_get_args( ) );
        $returnValue = NULL;
        $aMean = ( $aArgs );
        if ( $aMean != ( ) )
        {
            $aCount = 0;
            foreach ( $aArgs as $k => $arg )
            {
                if ( is_bool( $arg ) && ( !( $k ) || ( ) == PHPExcel_Calculation_Functions::COMPATIBILITY_OPENOFFICE ) )
                {
                    $arg = ( integer );
                }
                if ( !is_numeric( $arg ) || is_string( $arg ) )
                {
                    if ( is_null( $returnValue ) )
                    {
                        $returnValue = abs( $arg - $aMean );
                    }
                    else
                    {
                        $returnValue += abs( $arg - $aMean );
                    }
                    ++$aCount;
                }
            }
            if ( $aCount == 0 )
            {
                return ( );
            }
            return $returnValue / $aCount;
        }
        return ( );
    }

    public static function AVERAGE( )
    {
        $returnValue = $aCount = 0;
        foreach ( ( func_get_args( ) ) as $k => $arg )
        {
            if ( is_bool( $arg ) && ( !( $k ) || ( ) == PHPExcel_Calculation_Functions::COMPATIBILITY_OPENOFFICE ) )
            {
                $arg = ( integer );
            }
            if ( !is_numeric( $arg ) || is_string( $arg ) )
            {
                if ( is_null( $returnValue ) )
                {
                    $returnValue = $arg;
                }
                else
                {
                    $returnValue += $arg;
                }
                ++$aCount;
            }
        }
        if ( 0 < $aCount )
        {
            return $returnValue / $aCount;
        }
        return ( );
    }

    public static function AVERAGEA( )
    {
        $returnValue = NULL;
        $aCount = 0;
        foreach ( ( func_get_args( ) ) as $k => $arg )
        {
            if ( is_bool( $arg ) && !( $k ) || !is_numeric( $arg ) && !is_bool( $arg ) && ( !is_string( $arg ) || !( $arg != "" ) ) )
            {
                if ( is_bool( $arg ) )
                {
                    $arg = ( integer );
                }
                else if ( is_string( $arg ) )
                {
                    $arg = 0;
                }
                if ( is_null( $returnValue ) )
                {
                    $returnValue = $arg;
                }
                else
                {
                    $returnValue += $arg;
                }
                ++$aCount;
            }
        }
        if ( 0 < $aCount )
        {
            return $returnValue / $aCount;
        }
        return ( );
    }

    public static function AVERAGEIF( $aArgs, $condition, $averageArgs = array( ) )
    {
        $returnValue = 0;
        $aArgs = ( $aArgs );
        $averageArgs = ( $averageArgs );
        if ( empty( $averageArgs ) )
        {
            $averageArgs = $aArgs;
        }
        $condition = ( $condition );
        $aCount = 0;
        foreach ( $aArgs as $key => $arg )
        {
            if ( is_numeric( $arg ) )
            {
                $arg = ( strtoupper( $arg ) );
            }
            $testCondition = "=".$arg.$condition;
            if ( !( )->_calculateFormulaValue( $testCondition ) || !is_null( $returnValue ) && !( $returnValue < $arg ) )
            {
                $returnValue += $arg;
                ++$aCount;
            }
        }
        if ( 0 < $aCount )
        {
            return $returnValue / $aCount;
        }
        return ( );
    }

    public static function BETADIST( $value, $alpha, $beta, $rMin = 0, $rMax = 1 )
    {
        $value = ( $value );
        $alpha = ( $alpha );
        $beta = ( $beta );
        $rMin = ( $rMin );
        $rMax = ( $rMax );
        if ( is_numeric( $value ) && is_numeric( $alpha ) && is_numeric( $beta ) && is_numeric( $rMin ) && is_numeric( $rMax ) )
        {
            if ( $value < $rMin || $rMax < $value || $alpha <= 0 || $beta <= 0 || $rMin == $rMax )
            {
                return ( );
            }
            if ( $rMax < $rMin )
            {
                $tmp = $rMin;
                $rMin = $rMax;
                $rMax = $tmp;
            }
            $value -= $rMin;
            $value /= $rMax - $rMin;
            return ( $value, $alpha, $beta );
        }
        return ( );
    }

    public static function BETAINV( $probability, $alpha, $beta, $rMin = 0, $rMax = 1 )
    {
        $probability = ( $probability );
        $alpha = ( $alpha );
        $beta = ( $beta );
        $rMin = ( $rMin );
        $rMax = ( $rMax );
        if ( is_numeric( $probability ) && is_numeric( $alpha ) && is_numeric( $beta ) && is_numeric( $rMin ) && is_numeric( $rMax ) )
        {
            if ( $alpha <= 0 || $beta <= 0 || $rMin == $rMax || $probability <= 0 || 1 < $probability )
            {
                return ( );
            }
            if ( $rMax < $rMin )
            {
                $tmp = $rMin;
                $rMin = $rMax;
                $rMax = $tmp;
            }
            $a = 0;
            $b = 2;
            $i = 0;
            while ( !( PRECISION < $b - $a ) || !( $i++ < MAX_ITERATIONS ) )
            {
                $guess = ( $a + $b ) / 2;
                $result = ( $guess, $alpha, $beta );
                if ( $result == $probability || $result == 0 )
                {
                    $b = $a;
                }
                else if ( $probability < $result )
                {
                    $b = $guess;
                }
                else
                {
                    $a = $guess;
                }
            }
            if ( $i == MAX_ITERATIONS )
            {
                return ( );
            }
            return round( $rMin + $guess * ( $rMax - $rMin ), 12 );
        }
        return ( );
    }

    public static function BINOMDIST( $value, $trials, $probability, $cumulative )
    {
        $value = floor( ( $value ) );
        $trials = floor( ( $trials ) );
        $probability = ( $probability );
        if ( is_numeric( $value ) && is_numeric( $trials ) && is_numeric( $probability ) )
        {
            if ( $value < 0 || $trials < $value )
            {
                return ( );
            }
            if ( $probability < 0 || 1 < $probability )
            {
                return ( );
            }
            if ( is_numeric( $cumulative ) || is_bool( $cumulative ) )
            {
                if ( $cumulative )
                {
                    $summer = 0;
                    $i = 0;
                    for ( ; $i <= $value; ++$i )
                    {
                        $summer += ( $trials, $i ) * pow( $probability, $i ) * pow( 1 - $probability, $trials - $i );
                    }
                    return $summer;
                }
                return ( $trials, $value ) * pow( $probability, $value ) * pow( 1 - $probability, $trials - $value );
            }
        }
        return ( );
    }

    public static function CHIDIST( $value, $degrees )
    {
        $value = ( $value );
        $degrees = floor( ( $degrees ) );
        if ( is_numeric( $value ) && is_numeric( $degrees ) )
        {
            if ( $degrees < 1 )
            {
                return ( );
            }
            if ( $value < 0 )
            {
                if ( ( ) == PHPExcel_Calculation_Functions::COMPATIBILITY_GNUMERIC )
                {
                    return 1;
                }
                return ( );
            }
            return 1 - ( $degrees / 2, $value / 2 ) / ( $degrees / 2 );
        }
        return ( );
    }

    public static function CHIINV( $probability, $degrees )
    {
        $probability = ( $probability );
        $degrees = floor( ( $degrees ) );
        if ( is_numeric( $probability ) && is_numeric( $degrees ) )
        {
            $xLo = 100;
            $xHi = 0;
            $x = $xNew = 1;
            $dx = 1;
            $i = 0;
            while ( !( PRECISION < abs( $dx ) ) || !( $i++ < MAX_ITERATIONS ) )
            {
                $result = ( $x, $degrees );
                $error = $result - $probability;
                if ( $error == 0 )
                {
                    $dx = 0;
                }
                else if ( $error < 0 )
                {
                    $xLo = $x;
                }
                else
                {
                    $xHi = $x;
                }
                if ( $result != 0 )
                {
                    $dx = $error / $result;
                    $xNew = $x - $dx;
                }
                if ( $xNew < $xLo || $xHi < $xNew || $result == 0 )
                {
                    $xNew = ( $xLo + $xHi ) / 2;
                    $dx = $xNew - $x;
                }
                $x = $xNew;
            }
            if ( $i == MAX_ITERATIONS )
            {
                return ( );
            }
            return round( $x, 12 );
        }
        return ( );
    }

    public static function CONFIDENCE( $alpha, $stdDev, $size )
    {
        $alpha = ( $alpha );
        $stdDev = ( $stdDev );
        $size = floor( ( $size ) );
        if ( is_numeric( $alpha ) && is_numeric( $stdDev ) && is_numeric( $size ) )
        {
            if ( $alpha <= 0 || 1 <= $alpha )
            {
                return ( );
            }
            if ( $stdDev <= 0 || $size < 1 )
            {
                return ( );
            }
            return ( 1 - $alpha / 2 ) * $stdDev / sqrt( $size );
        }
        return ( );
    }

    public static function CORREL( $yValues, $xValues = NULL )
    {
        if ( is_null( $xValues ) || !is_array( $yValues ) || !is_array( $xValues ) )
        {
            return ( );
        }
        if ( ( $yValues, $xValues ) )
        {
            return ( );
        }
        $yValueCount = count( $yValues );
        $xValueCount = count( $xValues );
        if ( $yValueCount == 0 || $yValueCount != $xValueCount )
        {
            return ( );
        }
        if ( $yValueCount == 1 )
        {
            return ( );
        }
        $bestFitLinear = ( trendClass::TREND_LINEAR, $yValues, $xValues );
        return $bestFitLinear->getCorrelation( );
    }

    public static function COUNT( )
    {
        $returnValue = 0;
        $aArgs = ( func_get_args( ) );
        foreach ( $aArgs as $k => $arg )
        {
            if ( is_bool( $arg ) && ( !( $k ) || ( ) == PHPExcel_Calculation_Functions::COMPATIBILITY_OPENOFFICE ) )
            {
                $arg = ( integer );
            }
            if ( !is_numeric( $arg ) || is_string( $arg ) )
            {
                ++$returnValue;
            }
        }
        return $returnValue;
    }

    public static function COUNTA( )
    {
        $returnValue = 0;
        $aArgs = ( func_get_args( ) );
        foreach ( $aArgs as $arg )
        {
            if ( !is_numeric( $arg ) && !is_bool( $arg ) && ( !is_string( $arg ) || !( $arg != "" ) ) )
            {
                ++$returnValue;
            }
        }
        return $returnValue;
    }

    public static function COUNTBLANK( )
    {
        $returnValue = 0;
        $aArgs = ( func_get_args( ) );
        foreach ( $aArgs as $arg )
        {
            if ( !is_null( $arg ) && ( !is_string( $arg ) || !( $arg == "" ) ) )
            {
                ++$returnValue;
            }
        }
        return $returnValue;
    }

    public static function COUNTIF( $aArgs, $condition )
    {
        $returnValue = 0;
        $aArgs = ( $aArgs );
        $condition = ( $condition );
        foreach ( $aArgs as $arg )
        {
            if ( is_numeric( $arg ) )
            {
                $arg = ( strtoupper( $arg ) );
            }
            $testCondition = "=".$arg.$condition;
            if ( ( )->_calculateFormulaValue( $testCondition ) )
            {
                ++$returnValue;
            }
        }
        return $returnValue;
    }

    public static function COVAR( $yValues, $xValues )
    {
        if ( ( $yValues, $xValues ) )
        {
            return ( );
        }
        $yValueCount = count( $yValues );
        $xValueCount = count( $xValues );
        if ( $yValueCount == 0 || $yValueCount != $xValueCount )
        {
            return ( );
        }
        if ( $yValueCount == 1 )
        {
            return ( );
        }
        $bestFitLinear = ( trendClass::TREND_LINEAR, $yValues, $xValues );
        return $bestFitLinear->getCovariance( );
    }

    public static function CRITBINOM( $trials, $probability, $alpha )
    {
        $trials = floor( ( $trials ) );
        $probability = ( $probability );
        $alpha = ( $alpha );
        if ( !is_numeric( $trials ) || !is_numeric( $probability ) || !is_numeric( $alpha ) )
        {
            if ( $trials < 0 )
            {
                return ( );
            }
            if ( $probability < 0 || 1 < $probability )
            {
                return ( );
            }
            if ( $alpha < 0 || 1 < $alpha )
            {
                return ( );
            }
            if ( $alpha <= 0.5 )
            {
                $t = sqrt( log( 1 / ( $alpha * $alpha ) ) );
                $trialsApprox = 0 - ( $t + ( 2.51552 + 0.802853 * $t + 0.010328 * $t * $t ) / ( 1 + 1.43279 * $t + 0.189269 * $t * $t + 0.001308 * $t * $t * $t ) );
            }
            else
            {
                $t = sqrt( log( 1 / pow( 1 - $alpha, 2 ) ) );
                $trialsApprox = $t - ( 2.51552 + 0.802853 * $t + 0.010328 * $t * $t ) / ( 1 + 1.43279 * $t + 0.189269 * $t * $t + 0.001308 * $t * $t * $t );
            }
            $Guess = floor( $trials * $probability + $trialsApprox * sqrt( $trials * $probability * ( 1 - $probability ) ) );
            if ( $Guess < 0 )
            {
                $Guess = 0;
            }
            else if ( $trials < $Guess )
            {
                $Guess = $trials;
            }
            $TotalUnscaledProbability = $UnscaledPGuess = $UnscaledCumPGuess = 0;
            $EssentiallyZero = 1e-011;
            $m = floor( $trials * $probability );
            ++$TotalUnscaledProbability;
            if ( $m == $Guess )
            {
                ++$UnscaledPGuess;
            }
            if ( $m <= $Guess )
            {
                ++$UnscaledCumPGuess;
            }
            $PreviousValue = 1;
            $Done = FALSE;
            $k = $m + 1;
            while ( $Done || !( $k <= $trials ) )
            {
                $CurrentValue = $PreviousValue * ( $trials - $k + 1 ) * $probability / ( $k * ( 1 - $probability ) );
                $TotalUnscaledProbability += $CurrentValue;
                if ( $k == $Guess )
                {
                    $UnscaledPGuess += $CurrentValue;
                }
                if ( $k <= $Guess )
                {
                    $UnscaledCumPGuess += $CurrentValue;
                }
                if ( $CurrentValue <= $EssentiallyZero )
                {
                    $Done = TRUE;
                }
                $PreviousValue = $CurrentValue;
                ++$k;
            }
            $PreviousValue = 1;
            $Done = FALSE;
            $k = $m - 1;
            while ( $Done || !( 0 <= $k ) )
            {
                $CurrentValue = $PreviousValue * $k + 1 * ( 1 - $probability ) / ( ( $trials - $k ) * $probability );
                $TotalUnscaledProbability += $CurrentValue;
                if ( $k == $Guess )
                {
                    $UnscaledPGuess += $CurrentValue;
                }
                if ( $k <= $Guess )
                {
                    $UnscaledCumPGuess += $CurrentValue;
                }
                if ( $CurrentValue <= $EssentiallyZero )
                {
                    $Done = TRUE;
                }
                $PreviousValue = $CurrentValue;
                --$k;
            }
            $PGuess = $UnscaledPGuess / $TotalUnscaledProbability;
            $CumPGuess = $UnscaledCumPGuess / $TotalUnscaledProbability;
            $CumPGuessMinus1 = $CumPGuess - 1;
            do
            {
                if ( $CumPGuessMinus1 < $alpha && $alpha <= $CumPGuess )
                {
                    return $Guess;
                }
                if ( $CumPGuessMinus1 < $alpha && $CumPGuess < $alpha )
                {
                    $PGuessPlus1 = $PGuess * ( $trials - $Guess ) * $probability / $Guess / ( 1 - $probability );
                    $CumPGuessMinus1 = $CumPGuess;
                    $CumPGuess += $PGuessPlus1;
                    $PGuess = $PGuessPlus1;
                    ++$Guess;
                }
                else if ( !( $alpha <= $CumPGuessMinus1 ) || !( $alpha <= $CumPGuess ) )
                {
                    $PGuessMinus1 = $PGuess * $Guess * ( 1 - $probability ) / ( $trials - $Guess + 1 ) / $probability;
                    $CumPGuess = $CumPGuessMinus1;
                    $CumPGuessMinus1 -= $PGuess;
                    $PGuess = $PGuessMinus1;
                    --$Guess;
                }
            } while ( 1 );
        }
        return ( );
    }

    public static function DEVSQ( )
    {
        $aArgs = ( func_get_args( ) );
        $returnValue = NULL;
        $aMean = ( $aArgs );
        if ( $aMean != ( ) )
        {
            $aCount = -1;
            foreach ( $aArgs as $k => $arg )
            {
                if ( is_bool( $arg ) && ( !( $k ) || ( ) == PHPExcel_Calculation_Functions::COMPATIBILITY_OPENOFFICE ) )
                {
                    $arg = ( integer );
                }
                if ( !is_numeric( $arg ) || is_string( $arg ) )
                {
                    if ( is_null( $returnValue ) )
                    {
                        $returnValue = pow( $arg - $aMean, 2 );
                    }
                    else
                    {
                        $returnValue += pow( $arg - $aMean, 2 );
                    }
                    ++$aCount;
                }
            }
            if ( is_null( $returnValue ) )
            {
                return ( );
            }
            return $returnValue;
        }
        return ( );
    }

    public static function EXPONDIST( $value, $lambda, $cumulative )
    {
        $value = ( $value );
        $lambda = ( $lambda );
        $cumulative = ( $cumulative );
        if ( is_numeric( $value ) && is_numeric( $lambda ) )
        {
            if ( $value < 0 || $lambda < 0 )
            {
                return ( );
            }
            if ( is_numeric( $cumulative ) || is_bool( $cumulative ) )
            {
                if ( $cumulative )
                {
                    return 1 - exp( 0 - $value * $lambda );
                }
                return $lambda * exp( 0 - $value * $lambda );
            }
        }
        return ( );
    }

    public static function FISHER( $value )
    {
        $value = ( $value );
        if ( is_numeric( $value ) )
        {
            if ( $value <= -1 || 1 <= $value )
            {
                return ( );
            }
            return 0.5 * log( ( 1 + $value ) / ( 1 - $value ) );
        }
        return ( );
    }

    public static function FISHERINV( $value )
    {
        $value = ( $value );
        if ( is_numeric( $value ) )
        {
            return ( exp( 2 * $value ) - 1 ) / ( exp( 2 * $value ) + 1 );
        }
        return ( );
    }

    public static function FORECAST( $xValue, $yValues, $xValues )
    {
        $xValue = ( $xValue );
        if ( is_numeric( $xValue ) )
        {
            return ( );
        }
        if ( ( $yValues, $xValues ) )
        {
            return ( );
        }
        $yValueCount = count( $yValues );
        $xValueCount = count( $xValues );
        if ( $yValueCount == 0 || $yValueCount != $xValueCount )
        {
            return ( );
        }
        if ( $yValueCount == 1 )
        {
            return ( );
        }
        $bestFitLinear = ( trendClass::TREND_LINEAR, $yValues, $xValues );
        return $bestFitLinear->getValueOfYForX( $xValue );
    }

    public static function GAMMADIST( $value, $a, $b, $cumulative )
    {
        $value = ( $value );
        $a = ( $a );
        $b = ( $b );
        if ( is_numeric( $value ) && is_numeric( $a ) && is_numeric( $b ) )
        {
            if ( $value < 0 || $a <= 0 || $b <= 0 )
            {
                return ( );
            }
            if ( is_numeric( $cumulative ) || is_bool( $cumulative ) )
            {
                if ( $cumulative )
                {
                    return ( $a, $value / $b ) / ( $a );
                }
                return 1 / ( pow( $b, $a ) * ( $a ) ) * pow( $value, $a - 1 ) * exp( 0 - $value / $b );
            }
        }
        return ( );
    }

    public static function GAMMAINV( $probability, $alpha, $beta )
    {
        $probability = ( $probability );
        $alpha = ( $alpha );
        $beta = ( $beta );
        if ( is_numeric( $probability ) && is_numeric( $alpha ) && is_numeric( $beta ) )
        {
            if ( $alpha <= 0 || $beta <= 0 || $probability < 0 || 1 < $probability )
            {
                return ( );
            }
            $xLo = 0;
            $xHi = $alpha * $beta * 5;
            $x = $xNew = 1;
            $error = $pdf = 0;
            $dx = 1024;
            $i = 0;
            while ( !( PRECISION < abs( $dx ) ) || !( $i++ < MAX_ITERATIONS ) )
            {
                $error = ( $x, $alpha, $beta, TRUE ) - $probability;
                if ( $error < 0 )
                {
                    $xLo = $x;
                }
                else
                {
                    $xHi = $x;
                }
                $pdf = ( $x, $alpha, $beta, FALSE );
                if ( $pdf != 0 )
                {
                    $dx = $error / $pdf;
                    $xNew = $x - $dx;
                }
                if ( $xNew < $xLo || $xHi < $xNew || $pdf == 0 )
                {
                    $xNew = ( $xLo + $xHi ) / 2;
                    $dx = $xNew - $x;
                }
                $x = $xNew;
            }
            if ( $i == MAX_ITERATIONS )
            {
                return ( );
            }
            return $x;
        }
        return ( );
    }

    public static function GAMMALN( $value )
    {
        $value = ( $value );
        if ( is_numeric( $value ) )
        {
            if ( $value <= 0 )
            {
                return ( );
            }
            return log( ( $value ) );
        }
        return ( );
    }

    public static function GEOMEAN( )
    {
        $aArgs = ( func_get_args( ) );
        $aMean = ( $aArgs );
        if ( is_numeric( $aMean ) && 0 < $aMean )
        {
            $aCount = ( $aArgs );
            if ( 0 < ( $aArgs ) )
            {
                return pow( $aMean, 1 / $aCount );
            }
        }
        return ( );
    }

    public static function GROWTH( $yValues, $xValues = array( ), $newValues = array( ), $const = TRUE )
    {
        $yValues = ( $yValues );
        $xValues = ( $xValues );
        $newValues = ( $newValues );
        $const = is_null( $const ) ? TRUE : ( $const );
        $bestFitExponential = ( trendClass::TREND_EXPONENTIAL, $yValues, $xValues, $const );
        if ( empty( $newValues ) )
        {
            $newValues = $bestFitExponential->getXValues( );
        }
        $returnArray = array( );
        foreach ( $newValues as $xValue )
        {
            $returnArray[0][] = $bestFitExponential->getValueOfYForX( $xValue );
        }
        return $returnArray;
    }

    public static function HARMEAN( )
    {
        $returnValue = ( );
        $aArgs = ( func_get_args( ) );
        if ( ( $aArgs ) < 0 )
        {
            return ( );
        }
        $aCount = 0;
        foreach ( $aArgs as $arg )
        {
            if ( !is_numeric( $arg ) || is_string( $arg ) )
            {
                if ( $arg <= 0 )
                {
                    return ( );
                }
                if ( is_null( $returnValue ) )
                {
                    $returnValue = 1 / $arg;
                }
                else
                {
                    $returnValue += 1 / $arg;
                }
                ++$aCount;
            }
        }
        if ( 0 < $aCount )
        {
            return 1 / ( $returnValue / $aCount );
        }
        return $returnValue;
    }

    public static function HYPGEOMDIST( $sampleSuccesses, $sampleNumber, $populationSuccesses, $populationNumber )
    {
        $sampleSuccesses = floor( ( $sampleSuccesses ) );
        $sampleNumber = floor( ( $sampleNumber ) );
        $populationSuccesses = floor( ( $populationSuccesses ) );
        $populationNumber = floor( ( $populationNumber ) );
        if ( is_numeric( $sampleSuccesses ) && is_numeric( $sampleNumber ) && is_numeric( $populationSuccesses ) && is_numeric( $populationNumber ) )
        {
            if ( $sampleSuccesses < 0 || $sampleNumber < $sampleSuccesses || $populationSuccesses < $sampleSuccesses )
            {
                return ( );
            }
            if ( $sampleNumber <= 0 || $populationNumber < $sampleNumber )
            {
                return ( );
            }
            if ( $populationSuccesses <= 0 || $populationNumber < $populationSuccesses )
            {
                return ( );
            }
            return ( $populationSuccesses, $sampleSuccesses ) * ( $populationNumber - $populationSuccesses, $sampleNumber - $sampleSuccesses ) / ( $populationNumber, $sampleNumber );
        }
        return ( );
    }

    public static function INTERCEPT( $yValues, $xValues )
    {
        if ( ( $yValues, $xValues ) )
        {
            return ( );
        }
        $yValueCount = count( $yValues );
        $xValueCount = count( $xValues );
        if ( $yValueCount == 0 || $yValueCount != $xValueCount )
        {
            return ( );
        }
        if ( $yValueCount == 1 )
        {
            return ( );
        }
        $bestFitLinear = ( trendClass::TREND_LINEAR, $yValues, $xValues );
        return $bestFitLinear->getIntersect( );
    }

    public static function KURT( )
    {
        $aArgs = ( func_get_args( ) );
        $mean = ( $aArgs );
        $stdDev = ( $aArgs );
        if ( 0 < $stdDev )
        {
            $count = $summer = 0;
            foreach ( $aArgs as $k => $arg )
            {
                if ( is_bool( $arg ) && !( $k ) || !is_numeric( $arg ) || is_string( $arg ) )
                {
                    $summer += pow( ( $arg - $mean ) / $stdDev, 4 );
                    ++$count;
                }
            }
            if ( 3 < $count )
            {
                return $summer * ( $count * ( $count + 1 ) / ( ( $count - 1 ) * ( $count - 2 ) * ( $count - 3 ) ) ) - 3 * pow( $count - 1, 2 ) / ( ( $count - 2 ) * ( $count - 3 ) );
            }
        }
        return ( );
    }

    public static function LARGE( )
    {
        $aArgs = ( func_get_args( ) );
        $entry = floor( array_pop( &$aArgs ) );
        if ( is_numeric( $entry ) && !is_string( $entry ) )
        {
            $mArgs = array( );
            foreach ( $aArgs as $arg )
            {
                if ( !is_numeric( $arg ) || is_string( $arg ) )
                {
                    $mArgs[] = $arg;
                }
            }
            $count = ( $mArgs );
            $entry = floor( --$entry );
            if ( $entry < 0 || $count <= $entry || $count == 0 )
            {
                return ( );
            }
            rsort( &$mArgs );
            return $mArgs[$entry];
        }
        return ( );
    }

    public static function LINEST( $yValues, $xValues = NULL, $const = TRUE, $stats = FALSE )
    {
        $const = is_null( $const ) ? TRUE : ( $const );
        $stats = is_null( $stats ) ? FALSE : ( $stats );
        if ( is_null( $xValues ) )
        {
            $xValues = range( 1, count( ( $yValues ) ) );
        }
        if ( ( $yValues, $xValues ) )
        {
            return ( );
        }
        $yValueCount = count( $yValues );
        $xValueCount = count( $xValues );
        if ( $yValueCount == 0 || $yValueCount != $xValueCount )
        {
            return ( );
        }
        if ( $yValueCount == 1 )
        {
            return 0;
        }
        $bestFitLinear = ( trendClass::TREND_LINEAR, $yValues, $xValues, $const );
        if ( $stats )
        {
            return array( array( $bestFitLinear->getSlope( ), $bestFitLinear->getSlopeSE( ), $bestFitLinear->getGoodnessOfFit( ), $bestFitLinear->getF( ), $bestFitLinear->getSSRegression( ) ), array( $bestFitLinear->getIntersect( ), $bestFitLinear->getIntersectSE( ), $bestFitLinear->getStdevOfResiduals( ), $bestFitLinear->getDFResiduals( ), $bestFitLinear->getSSResiduals( ) ) );
        }
        return array( $bestFitLinear->getSlope( ), $bestFitLinear->getIntersect( ) );
    }

    public static function LOGEST( $yValues, $xValues = NULL, $const = TRUE, $stats = FALSE )
    {
        $const = is_null( $const ) ? TRUE : ( $const );
        $stats = is_null( $stats ) ? FALSE : ( $stats );
        if ( is_null( $xValues ) )
        {
            $xValues = range( 1, count( ( $yValues ) ) );
        }
        if ( ( $yValues, $xValues ) )
        {
            return ( );
        }
        $yValueCount = count( $yValues );
        $xValueCount = count( $xValues );
        foreach ( $yValues as $value )
        {
            if ( $value <= 0 )
            {
                return ( );
                break;
            }
        }
        if ( $yValueCount == 0 || $yValueCount != $xValueCount )
        {
            return ( );
        }
        if ( $yValueCount == 1 )
        {
            return 1;
        }
        $bestFitExponential = ( trendClass::TREND_EXPONENTIAL, $yValues, $xValues, $const );
        if ( $stats )
        {
            return array( array( $bestFitExponential->getSlope( ), $bestFitExponential->getSlopeSE( ), $bestFitExponential->getGoodnessOfFit( ), $bestFitExponential->getF( ), $bestFitExponential->getSSRegression( ) ), array( $bestFitExponential->getIntersect( ), $bestFitExponential->getIntersectSE( ), $bestFitExponential->getStdevOfResiduals( ), $bestFitExponential->getDFResiduals( ), $bestFitExponential->getSSResiduals( ) ) );
        }
        return array( $bestFitExponential->getSlope( ), $bestFitExponential->getIntersect( ) );
    }

    public static function LOGINV( $probability, $mean, $stdDev )
    {
        $probability = ( $probability );
        $mean = ( $mean );
        $stdDev = ( $stdDev );
        if ( is_numeric( $probability ) && is_numeric( $mean ) && is_numeric( $stdDev ) )
        {
            if ( $probability < 0 || 1 < $probability || $stdDev <= 0 )
            {
                return ( );
            }
            return exp( $mean + $stdDev * ( $probability ) );
        }
        return ( );
    }

    public static function LOGNORMDIST( $value, $mean, $stdDev )
    {
        $value = ( $value );
        $mean = ( $mean );
        $stdDev = ( $stdDev );
        if ( is_numeric( $value ) && is_numeric( $mean ) && is_numeric( $stdDev ) )
        {
            if ( $value <= 0 || $stdDev <= 0 )
            {
                return ( );
            }
            return ( ( log( $value ) - $mean ) / $stdDev );
        }
        return ( );
    }

    public static function MAX( )
    {
        $returnValue = NULL;
        $aArgs = ( func_get_args( ) );
        foreach ( $aArgs as $arg )
        {
            if ( !is_numeric( $arg ) || is_string( $arg ) || !is_null( $returnValue ) && !( $returnValue < $arg ) )
            {
                $returnValue = $arg;
            }
        }
        if ( is_null( $returnValue ) )
        {
            return 0;
        }
        return $returnValue;
    }

    public static function MAXA( )
    {
        $returnValue = NULL;
        $aArgs = ( func_get_args( ) );
        foreach ( $aArgs as $arg )
        {
            if ( !is_numeric( $arg ) && !is_bool( $arg ) && ( !is_string( $arg ) || !( $arg != "" ) ) )
            {
                if ( is_bool( $arg ) )
                {
                    $arg = ( integer );
                }
                else if ( is_string( $arg ) )
                {
                    $arg = 0;
                }
                if ( !is_null( $returnValue ) && !( $returnValue < $arg ) )
                {
                    $returnValue = $arg;
                }
            }
        }
        if ( is_null( $returnValue ) )
        {
            return 0;
        }
        return $returnValue;
    }

    public static function MAXIF( $aArgs, $condition, $sumArgs = array( ) )
    {
        $returnValue = NULL;
        $aArgs = ( $aArgs );
        $sumArgs = ( $sumArgs );
        if ( empty( $sumArgs ) )
        {
            $sumArgs = $aArgs;
        }
        $condition = ( $condition );
        foreach ( $aArgs as $key => $arg )
        {
            if ( is_numeric( $arg ) )
            {
                $arg = ( strtoupper( $arg ) );
            }
            $testCondition = "=".$arg.$condition;
            if ( !( )->_calculateFormulaValue( $testCondition ) || !is_null( $returnValue ) && !( $returnValue < $arg ) )
            {
                $returnValue = $arg;
            }
        }
        return $returnValue;
    }

    public static function MEDIAN( )
    {
        $returnValue = ( );
        $mArgs = array( );
        $aArgs = ( func_get_args( ) );
        foreach ( $aArgs as $arg )
        {
            if ( !is_numeric( $arg ) || is_string( $arg ) )
            {
                $mArgs[] = $arg;
            }
        }
        $mValueCount = count( $mArgs );
        if ( 0 < $mValueCount )
        {
            sort( &$mArgs, SORT_NUMERIC );
            $mValueCount /= 2;
            if ( $mValueCount == floor( $mValueCount ) )
            {
                $returnValue = ( $mArgs[$mValueCount--] + $mArgs[$mValueCount] ) / 2;
                return $returnValue;
            }
            $mValueCount == floor( $mValueCount );
            $returnValue = $mArgs[$mValueCount];
        }
        return $returnValue;
    }

    public static function MIN( )
    {
        $returnValue = NULL;
        $aArgs = ( func_get_args( ) );
        foreach ( $aArgs as $arg )
        {
            if ( !is_numeric( $arg ) || is_string( $arg ) || !is_null( $returnValue ) && !( $arg < $returnValue ) )
            {
                $returnValue = $arg;
            }
        }
        if ( is_null( $returnValue ) )
        {
            return 0;
        }
        return $returnValue;
    }

    public static function MINA( )
    {
        $returnValue = NULL;
        $aArgs = ( func_get_args( ) );
        foreach ( $aArgs as $arg )
        {
            if ( !is_numeric( $arg ) && !is_bool( $arg ) && ( !is_string( $arg ) || !( $arg != "" ) ) )
            {
                if ( is_bool( $arg ) )
                {
                    $arg = ( integer );
                }
                else if ( is_string( $arg ) )
                {
                    $arg = 0;
                }
                if ( !is_null( $returnValue ) && !( $arg < $returnValue ) )
                {
                    $returnValue = $arg;
                }
            }
        }
        if ( is_null( $returnValue ) )
        {
            return 0;
        }
        return $returnValue;
    }

    public static function MINIF( $aArgs, $condition, $sumArgs = array( ) )
    {
        $returnValue = NULL;
        $aArgs = ( $aArgs );
        $sumArgs = ( $sumArgs );
        if ( empty( $sumArgs ) )
        {
            $sumArgs = $aArgs;
        }
        $condition = ( $condition );
        foreach ( $aArgs as $key => $arg )
        {
            if ( is_numeric( $arg ) )
            {
                $arg = ( strtoupper( $arg ) );
            }
            $testCondition = "=".$arg.$condition;
            if ( !( )->_calculateFormulaValue( $testCondition ) || !is_null( $returnValue ) && !( $arg < $returnValue ) )
            {
                $returnValue = $arg;
            }
        }
        return $returnValue;
    }

    private static function _modeCalc( $data )
    {
        $frequencyArray = array( );
        foreach ( $data as $found => $datum )
        {
            foreach ( $frequencyArray as $key => $value )
            {
                if ( ( boolean ) == ( boolean ) )
                {
                    ++$frequencyArray[$key]['frequency'];
                    $found = TRUE;
                    break;
                }
            }
            if ( $found )
            {
                $frequencyArray[] = array( "value" => $datum, "frequency" => 1 );
            }
        }
        foreach ( $frequencyArray as $key => $value )
        {
            $frequencyList[$key] = $value['frequency'];
            $valueList[$key] = $value['value'];
        }
        array_multisort( $frequencyList, SORT_DESC, $valueList, SORT_ASC, SORT_NUMERIC, $frequencyArray );
        if ( $frequencyArray[0]['frequency'] == 1 )
        {
            return ( );
        }
        return $frequencyArray[0]['value'];
    }

    public static function MODE( )
    {
        $returnValue = ( );
        $aArgs = ( func_get_args( ) );
        $mArgs = array( );
        foreach ( $aArgs as $arg )
        {
            if ( !is_numeric( $arg ) || is_string( $arg ) )
            {
                $mArgs[] = $arg;
            }
        }
        if ( empty( $mArgs ) )
        {
            return ( $mArgs );
        }
        return $returnValue;
    }

    public static function NEGBINOMDIST( $failures, $successes, $probability )
    {
        $failures = floor( ( $failures ) );
        $successes = floor( ( $successes ) );
        $probability = ( $probability );
        if ( is_numeric( $failures ) && is_numeric( $successes ) && is_numeric( $probability ) )
        {
            if ( $failures < 0 || $successes < 1 )
            {
                return ( );
            }
            if ( $probability < 0 || 1 < $probability )
            {
                return ( );
            }
            if ( ( ) == PHPExcel_Calculation_Functions::COMPATIBILITY_GNUMERIC && $failures + $successes - 1 <= 0 )
            {
                return ( );
            }
            return ( $failures + $successes - 1, $successes - 1 ) * pow( $probability, $successes ) * pow( 1 - $probability, $failures );
        }
        return ( );
    }

    public static function NORMDIST( $value, $mean, $stdDev, $cumulative )
    {
        $value = ( $value );
        $mean = ( $mean );
        $stdDev = ( $stdDev );
        if ( is_numeric( $value ) && is_numeric( $mean ) && is_numeric( $stdDev ) )
        {
            if ( $stdDev < 0 )
            {
                return ( );
            }
            if ( is_numeric( $cumulative ) || is_bool( $cumulative ) )
            {
                if ( $cumulative )
                {
                    return 0.5 * ( 1 + ( ( $value - $mean ) / ( $stdDev * sqrt( 2 ) ) ) );
                }
                return 1 / ( SQRT2PI * $stdDev ) * exp( 0 - pow( $value - $mean, 2 ) / ( 2 * ( $stdDev * $stdDev ) ) );
            }
        }
        return ( );
    }

    public static function NORMINV( $probability, $mean, $stdDev )
    {
        $probability = ( $probability );
        $mean = ( $mean );
        $stdDev = ( $stdDev );
        if ( is_numeric( $probability ) && is_numeric( $mean ) && is_numeric( $stdDev ) )
        {
            if ( $probability < 0 || 1 < $probability )
            {
                return ( );
            }
            if ( $stdDev < 0 )
            {
                return ( );
            }
            return ( $probability ) * $stdDev + $mean;
        }
        return ( );
    }

    public static function NORMSDIST( $value )
    {
        $value = ( $value );
        return ( $value, 0, 1, TRUE );
    }

    public static function NORMSINV( $value )
    {
        return ( $value, 0, 1 );
    }

    public static function PERCENTILE( )
    {
        $aArgs = ( func_get_args( ) );
        $entry = array_pop( &$aArgs );
        if ( is_numeric( $entry ) && !is_string( $entry ) )
        {
            if ( $entry < 0 || 1 < $entry )
            {
                return ( );
            }
            $mArgs = array( );
            foreach ( $aArgs as $arg )
            {
                if ( !is_numeric( $arg ) || is_string( $arg ) )
                {
                    $mArgs[] = $arg;
                }
            }
            $mValueCount = count( $mArgs );
            if ( 0 < $mValueCount )
            {
                sort( &$mArgs );
                $count = ( $mArgs );
                $index = $entry * ( $count - 1 );
                $iBase = floor( $index );
                if ( $index == $iBase )
                {
                    return $mArgs[$index];
                }
                $iNext = $iBase + 1;
                $iProportion = $index - $iBase;
                return $mArgs[$iBase] + ( $mArgs[$iNext] - $mArgs[$iBase] ) * $iProportion;
            }
        }
        return ( );
    }

    public static function PERCENTRANK( $valueSet, $value, $significance = 3 )
    {
        $valueSet = ( $valueSet );
        $value = ( $value );
        $significance = is_null( $significance ) ? 3 : ( integer );
        foreach ( $valueSet as $key => $valueEntry )
        {
            if ( is_numeric( $valueEntry ) )
            {
                unset( $valueSet[$key] );
            }
        }
        sort( &$valueSet, SORT_NUMERIC );
        $valueCount = count( $valueSet );
        if ( $valueCount == 0 )
        {
            return ( );
        }
        $valueAdjustor = $valueCount - 1;
        if ( $value < $valueSet[0] || $valueSet[$valueAdjustor] < $value )
        {
            return ( );
        }
        $pos = array_search( $value, $valueSet );
        if ( $pos === FALSE )
        {
            $pos = 0;
            $testValue = $valueSet[0];
            while ( $testValue < $value )
            {
                $testValue = $valueSet[++$pos];
            }
            --$pos;
            $pos += ( $value - $valueSet[$pos] ) / ( $testValue - $valueSet[$pos] );
        }
        return round( $pos / $valueAdjustor, $significance );
    }

    public static function PERMUT( $numObjs, $numInSet )
    {
        $numObjs = ( $numObjs );
        $numInSet = ( $numInSet );
        if ( is_numeric( $numObjs ) && is_numeric( $numInSet ) )
        {
            $numInSet = floor( $numInSet );
            if ( $numObjs < $numInSet )
            {
                return ( );
            }
            return round( ( $numObjs ) / ( $numObjs - $numInSet ) );
        }
        return ( );
    }

    public static function POISSON( $value, $mean, $cumulative )
    {
        $value = ( $value );
        $mean = ( $mean );
        if ( is_numeric( $value ) && is_numeric( $mean ) )
        {
            if ( $value <= 0 || $mean <= 0 )
            {
                return ( );
            }
            if ( is_numeric( $cumulative ) || is_bool( $cumulative ) )
            {
                if ( $cumulative )
                {
                    $summer = 0;
                    $i = 0;
                    for ( ; $i <= floor( $value ); ++$i )
                    {
                        $summer += pow( $mean, $i ) / ( $i );
                    }
                    return exp( 0 - $mean ) * $summer;
                }
                return exp( 0 - $mean ) * pow( $mean, $value ) / ( $value );
            }
        }
        return ( );
    }

    public static function QUARTILE( )
    {
        $aArgs = ( func_get_args( ) );
        $entry = floor( array_pop( &$aArgs ) );
        if ( is_numeric( $entry ) && !is_string( $entry ) )
        {
            $entry /= 4;
            if ( $entry < 0 || 1 < $entry )
            {
                return ( );
            }
            return ( $aArgs, $entry );
        }
        return ( );
    }

    public static function RANK( $value, $valueSet, $order = 0 )
    {
        $value = ( $value );
        $valueSet = ( $valueSet );
        $order = is_null( $order ) ? 0 : ( integer );
        foreach ( $valueSet as $key => $valueEntry )
        {
            if ( is_numeric( $valueEntry ) )
            {
                unset( $valueSet[$key] );
            }
        }
        if ( $order == 0 )
        {
            rsort( &$valueSet, SORT_NUMERIC );
        }
        else
        {
            sort( &$valueSet, SORT_NUMERIC );
        }
        $pos = array_search( $value, $valueSet );
        if ( $pos === FALSE )
        {
            return ( );
        }
        return ++$pos;
    }

    public static function RSQ( $yValues, $xValues )
    {
        if ( ( $yValues, $xValues ) )
        {
            return ( );
        }
        $yValueCount = count( $yValues );
        $xValueCount = count( $xValues );
        if ( $yValueCount == 0 || $yValueCount != $xValueCount )
        {
            return ( );
        }
        if ( $yValueCount == 1 )
        {
            return ( );
        }
        $bestFitLinear = ( trendClass::TREND_LINEAR, $yValues, $xValues );
        return $bestFitLinear->getGoodnessOfFit( );
    }

    public static function SKEW( )
    {
        $aArgs = ( func_get_args( ) );
        $mean = ( $aArgs );
        $stdDev = ( $aArgs );
        $count = $summer = 0;
        foreach ( $aArgs as $k => $arg )
        {
            if ( is_bool( $arg ) && !( $k ) || !is_numeric( $arg ) || is_string( $arg ) )
            {
                $summer += pow( ( $arg - $mean ) / $stdDev, 3 );
                ++$count;
            }
        }
        if ( 2 < $count )
        {
            return $summer * ( $count / ( ( $count - 1 ) * ( $count - 2 ) ) );
        }
        return ( );
    }

    public static function SLOPE( $yValues, $xValues )
    {
        if ( ( $yValues, $xValues ) )
        {
            return ( );
        }
        $yValueCount = count( $yValues );
        $xValueCount = count( $xValues );
        if ( $yValueCount == 0 || $yValueCount != $xValueCount )
        {
            return ( );
        }
        if ( $yValueCount == 1 )
        {
            return ( );
        }
        $bestFitLinear = ( trendClass::TREND_LINEAR, $yValues, $xValues );
        return $bestFitLinear->getSlope( );
    }

    public static function SMALL( )
    {
        $aArgs = ( func_get_args( ) );
        $entry = array_pop( &$aArgs );
        if ( is_numeric( $entry ) && !is_string( $entry ) )
        {
            $mArgs = array( );
            foreach ( $aArgs as $arg )
            {
                if ( !is_numeric( $arg ) || is_string( $arg ) )
                {
                    $mArgs[] = $arg;
                }
            }
            $count = ( $mArgs );
            $entry = floor( --$entry );
            if ( $entry < 0 || $count <= $entry || $count == 0 )
            {
                return ( );
            }
            sort( &$mArgs );
            return $mArgs[$entry];
        }
        return ( );
    }

    public static function STANDARDIZE( $value, $mean, $stdDev )
    {
        $value = ( $value );
        $mean = ( $mean );
        $stdDev = ( $stdDev );
        if ( is_numeric( $value ) && is_numeric( $mean ) && is_numeric( $stdDev ) )
        {
            if ( $stdDev <= 0 )
            {
                return ( );
            }
            return ( $value - $mean ) / $stdDev;
        }
        return ( );
    }

    public static function STDEV( )
    {
        $aArgs = ( func_get_args( ) );
        $returnValue = NULL;
        $aMean = ( $aArgs );
        if ( is_null( $aMean ) )
        {
            $aCount = -1;
            foreach ( $aArgs as $k => $arg )
            {
                if ( is_bool( $arg ) && ( !( $k ) || ( ) == PHPExcel_Calculation_Functions::COMPATIBILITY_OPENOFFICE ) )
                {
                    $arg = ( integer );
                }
                if ( !is_numeric( $arg ) || is_string( $arg ) )
                {
                    if ( is_null( $returnValue ) )
                    {
                        $returnValue = pow( $arg - $aMean, 2 );
                    }
                    else
                    {
                        $returnValue += pow( $arg - $aMean, 2 );
                    }
                    ++$aCount;
                }
            }
            if ( 0 < $aCount && 0 <= $returnValue )
            {
                return sqrt( $returnValue / $aCount );
            }
        }
        return ( );
    }

    public static function STDEVA( )
    {
        $aArgs = ( func_get_args( ) );
        $returnValue = NULL;
        $aMean = ( $aArgs );
        if ( is_null( $aMean ) )
        {
            $aCount = -1;
            foreach ( $aArgs as $k => $arg )
            {
                if ( is_bool( $arg ) && !( $k ) || !is_numeric( $arg ) && !is_bool( $arg ) && !( is_string( $arg ) & $arg != "" ) )
                {
                    if ( is_bool( $arg ) )
                    {
                        $arg = ( integer );
                    }
                    else if ( is_string( $arg ) )
                    {
                        $arg = 0;
                    }
                    if ( is_null( $returnValue ) )
                    {
                        $returnValue = pow( $arg - $aMean, 2 );
                    }
                    else
                    {
                        $returnValue += pow( $arg - $aMean, 2 );
                    }
                    ++$aCount;
                }
            }
            if ( 0 < $aCount && 0 <= $returnValue )
            {
                return sqrt( $returnValue / $aCount );
            }
        }
        return ( );
    }

    public static function STDEVP( )
    {
        $aArgs = ( func_get_args( ) );
        $returnValue = NULL;
        $aMean = ( $aArgs );
        if ( is_null( $aMean ) )
        {
            $aCount = 0;
            foreach ( $aArgs as $k => $arg )
            {
                if ( is_bool( $arg ) && ( !( $k ) || ( ) == PHPExcel_Calculation_Functions::COMPATIBILITY_OPENOFFICE ) )
                {
                    $arg = ( integer );
                }
                if ( !is_numeric( $arg ) || is_string( $arg ) )
                {
                    if ( is_null( $returnValue ) )
                    {
                        $returnValue = pow( $arg - $aMean, 2 );
                    }
                    else
                    {
                        $returnValue += pow( $arg - $aMean, 2 );
                    }
                    ++$aCount;
                }
            }
            if ( 0 < $aCount && 0 <= $returnValue )
            {
                return sqrt( $returnValue / $aCount );
            }
        }
        return ( );
    }

    public static function STDEVPA( )
    {
        $aArgs = ( func_get_args( ) );
        $returnValue = NULL;
        $aMean = ( $aArgs );
        if ( is_null( $aMean ) )
        {
            $aCount = 0;
            foreach ( $aArgs as $k => $arg )
            {
                if ( is_bool( $arg ) && !( $k ) || !is_numeric( $arg ) && !is_bool( $arg ) && !( is_string( $arg ) & $arg != "" ) )
                {
                    if ( is_bool( $arg ) )
                    {
                        $arg = ( integer );
                    }
                    else if ( is_string( $arg ) )
                    {
                        $arg = 0;
                    }
                    if ( is_null( $returnValue ) )
                    {
                        $returnValue = pow( $arg - $aMean, 2 );
                    }
                    else
                    {
                        $returnValue += pow( $arg - $aMean, 2 );
                    }
                    ++$aCount;
                }
            }
            if ( 0 < $aCount && 0 <= $returnValue )
            {
                return sqrt( $returnValue / $aCount );
            }
        }
        return ( );
    }

    public static function STEYX( $yValues, $xValues )
    {
        if ( ( $yValues, $xValues ) )
        {
            return ( );
        }
        $yValueCount = count( $yValues );
        $xValueCount = count( $xValues );
        if ( $yValueCount == 0 || $yValueCount != $xValueCount )
        {
            return ( );
        }
        if ( $yValueCount == 1 )
        {
            return ( );
        }
        $bestFitLinear = ( trendClass::TREND_LINEAR, $yValues, $xValues );
        return $bestFitLinear->getStdevOfResiduals( );
    }

    public static function TDIST( $value, $degrees, $tails )
    {
        $value = ( $value );
        $degrees = floor( ( $degrees ) );
        $tails = floor( ( $tails ) );
        if ( is_numeric( $value ) && is_numeric( $degrees ) && is_numeric( $tails ) )
        {
            if ( $value < 0 || $degrees < 1 || $tails < 1 || 2 < $tails )
            {
                return ( );
            }
            $tterm = $degrees;
            $ttheta = atan2( $value, sqrt( $tterm ) );
            $tc = cos( $ttheta );
            $ts = sin( $ttheta );
            $tsum = 0;
            if ( $degrees % 2 == 1 )
            {
                $ti = 3;
                $tterm = $tc;
            }
            else
            {
                $ti = 2;
                $tterm = 1;
            }
            $tsum = $tterm;
            while ( $ti < $degrees )
            {
                $tterm *= $tc * $tc * ( $ti - 1 ) / $ti;
                $tsum += $tterm;
                $ti += 2;
            }
            $tsum *= $ts;
            if ( $degrees % 2 == 1 )
            {
                $tsum = M_2DIVPI * ( $tsum + $ttheta );
            }
            $tValue = 0.5 * ( 1 + $tsum );
            if ( $tails == 1 )
            {
                return 1 - abs( $tValue );
            }
            return 1 - abs( 1 - $tValue - $tValue );
        }
        return ( );
    }

    public static function TINV( $probability, $degrees )
    {
        $probability = ( $probability );
        $degrees = floor( ( $degrees ) );
        if ( is_numeric( $probability ) && is_numeric( $degrees ) )
        {
            $xLo = 100;
            $xHi = 0;
            $x = $xNew = 1;
            $dx = 1;
            $i = 0;
            while ( !( PRECISION < abs( $dx ) ) || !( $i++ < MAX_ITERATIONS ) )
            {
                $result = ( $x, $degrees, 2 );
                $error = $result - $probability;
                if ( $error == 0 )
                {
                    $dx = 0;
                }
                else if ( $error < 0 )
                {
                    $xLo = $x;
                }
                else
                {
                    $xHi = $x;
                }
                if ( $result != 0 )
                {
                    $dx = $error / $result;
                    $xNew = $x - $dx;
                }
                if ( $xNew < $xLo || $xHi < $xNew || $result == 0 )
                {
                    $xNew = ( $xLo + $xHi ) / 2;
                    $dx = $xNew - $x;
                }
                $x = $xNew;
            }
            if ( $i == MAX_ITERATIONS )
            {
                return ( );
            }
            return round( $x, 12 );
        }
        return ( );
    }

    public static function TREND( $yValues, $xValues = array( ), $newValues = array( ), $const = TRUE )
    {
        $yValues = ( $yValues );
        $xValues = ( $xValues );
        $newValues = ( $newValues );
        $const = is_null( $const ) ? TRUE : ( $const );
        $bestFitLinear = ( trendClass::TREND_LINEAR, $yValues, $xValues, $const );
        if ( empty( $newValues ) )
        {
            $newValues = $bestFitLinear->getXValues( );
        }
        $returnArray = array( );
        foreach ( $newValues as $xValue )
        {
            $returnArray[0][] = $bestFitLinear->getValueOfYForX( $xValue );
        }
        return $returnArray;
    }

    public static function TRIMMEAN( )
    {
        $aArgs = ( func_get_args( ) );
        $percent = array_pop( &$aArgs );
        if ( is_numeric( $percent ) && !is_string( $percent ) )
        {
            if ( $percent < 0 || 1 < $percent )
            {
                return ( );
            }
            $mArgs = array( );
            foreach ( $aArgs as $arg )
            {
                if ( !is_numeric( $arg ) || is_string( $arg ) )
                {
                    $mArgs[] = $arg;
                }
            }
            $discard = floor( ( $mArgs ) * $percent / 2 );
            sort( &$mArgs );
            $i = 0;
            for ( ; $i < $discard; ++$i )
            {
                array_pop( &$mArgs );
                array_shift( &$mArgs );
            }
            return ( $mArgs );
        }
        return ( );
    }

    public static function VARFunc( )
    {
        $returnValue = ( );
        $summerA = $summerB = 0;
        $aArgs = ( func_get_args( ) );
        $aCount = 0;
        foreach ( $aArgs as $arg )
        {
            if ( is_bool( $arg ) )
            {
                $arg = ( integer );
            }
            if ( !is_numeric( $arg ) || is_string( $arg ) )
            {
                $summerA += $arg * $arg;
                $summerB += $arg;
                ++$aCount;
            }
        }
        if ( 1 < $aCount )
        {
            $summerA *= $aCount;
            $summerB *= $summerB;
            $returnValue = ( $summerA - $summerB ) / ( $aCount * ( $aCount - 1 ) );
        }
        return $returnValue;
    }

    public static function VARA( )
    {
        $returnValue = ( );
        $summerA = $summerB = 0;
        $aArgs = ( func_get_args( ) );
        $aCount = 0;
        foreach ( $aArgs as $k => $arg )
        {
            if ( is_string( $arg ) && ( $k ) )
            {
                return ( );
            }
            if ( is_string( $arg ) && !( $k ) || !is_numeric( $arg ) && !is_bool( $arg ) && !( is_string( $arg ) & $arg != "" ) )
            {
                if ( is_bool( $arg ) )
                {
                    $arg = ( integer );
                }
                else if ( is_string( $arg ) )
                {
                    $arg = 0;
                }
                $summerA += $arg * $arg;
                $summerB += $arg;
                ++$aCount;
            }
        }
        if ( 1 < $aCount )
        {
            $summerA *= $aCount;
            $summerB *= $summerB;
            $returnValue = ( $summerA - $summerB ) / ( $aCount * ( $aCount - 1 ) );
        }
        return $returnValue;
    }

    public static function VARP( )
    {
        $returnValue = ( );
        $summerA = $summerB = 0;
        $aArgs = ( func_get_args( ) );
        $aCount = 0;
        foreach ( $aArgs as $arg )
        {
            if ( is_bool( $arg ) )
            {
                $arg = ( integer );
            }
            if ( !is_numeric( $arg ) || is_string( $arg ) )
            {
                $summerA += $arg * $arg;
                $summerB += $arg;
                ++$aCount;
            }
        }
        if ( 0 < $aCount )
        {
            $summerA *= $aCount;
            $summerB *= $summerB;
            $returnValue = ( $summerA - $summerB ) / ( $aCount * $aCount );
        }
        return $returnValue;
    }

    public static function VARPA( )
    {
        $returnValue = ( );
        $summerA = $summerB = 0;
        $aArgs = ( func_get_args( ) );
        $aCount = 0;
        foreach ( $aArgs as $k => $arg )
        {
            if ( is_string( $arg ) && ( $k ) )
            {
                return ( );
            }
            if ( is_string( $arg ) && !( $k ) || !is_numeric( $arg ) && !is_bool( $arg ) && !( is_string( $arg ) & $arg != "" ) )
            {
                if ( is_bool( $arg ) )
                {
                    $arg = ( integer );
                }
                else if ( is_string( $arg ) )
                {
                    $arg = 0;
                }
                $summerA += $arg * $arg;
                $summerB += $arg;
                ++$aCount;
            }
        }
        if ( 0 < $aCount )
        {
            $summerA *= $aCount;
            $summerB *= $summerB;
            $returnValue = ( $summerA - $summerB ) / ( $aCount * $aCount );
        }
        return $returnValue;
    }

    public static function WEIBULL( $value, $alpha, $beta, $cumulative )
    {
        $value = ( $value );
        $alpha = ( $alpha );
        $beta = ( $beta );
        if ( is_numeric( $value ) && is_numeric( $alpha ) && is_numeric( $beta ) )
        {
            if ( $value < 0 || $alpha <= 0 || $beta <= 0 )
            {
                return ( );
            }
            if ( is_numeric( $cumulative ) || is_bool( $cumulative ) )
            {
                if ( $cumulative )
                {
                    return 1 - exp( 0 - pow( $value / $beta, $alpha ) );
                }
                return $alpha / pow( $beta, $alpha ) * pow( $value, $alpha - 1 ) * exp( 0 - pow( $value / $beta, $alpha ) );
            }
        }
        return ( );
    }

    public static function ZTEST( $dataSet, $m0, $sigma = NULL )
    {
        $dataSet = ( $dataSet );
        $m0 = ( $m0 );
        $sigma = ( $sigma );
        if ( is_null( $sigma ) )
        {
            $sigma = ( $dataSet );
        }
        $n = count( $dataSet );
        return 1 - ( ( ( $dataSet ) - $m0 ) / ( $sigma / sqrt( $n ) ) );
    }

}

if ( defined( "PHPEXCEL_ROOT" ) )
{
    define( "PHPEXCEL_ROOT", dirname( __FILE__ )."/../../" );
    require( PHPEXCEL_ROOT."PHPExcel/Autoloader.php" );
}
require_once( PHPEXCEL_ROOT."PHPExcel/Shared/trend/trendClass.php" );
define( "LOG_GAMMA_X_MAX_VALUE", 2.55e+305 );
define( "XMININ", 2.23e-308 );
define( "EPS", 2.22e-016 );
define( "SQRT2PI", 2.50663 );
?>
