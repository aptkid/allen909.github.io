<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class PHPExcel_Calculation_Logical
{

    public static function TRUE( )
    {
        return TRUE;
    }

    public static function FALSE( )
    {
        return FALSE;
    }

    public static function LOGICAL_AND( )
    {
        $returnValue = TRUE;
        $aArgs = ( func_get_args( ) );
        $argCount = -1;
        foreach ( $aArgs as $argCount => $arg )
        {
            if ( is_bool( $arg ) )
            {
                $returnValue = $returnValue && $arg;
            }
            else if ( is_numeric( $arg ) && !is_string( $arg ) )
            {
                $returnValue = $arg != 0;
            }
            else if ( is_string( $arg ) )
            {
                $arg = strtoupper( $arg );
                if ( $arg == "TRUE" || $arg == ( ) )
                {
                    $arg = TRUE;
                }
                else if ( $arg == "FALSE" || $arg == ( ) )
                {
                    $arg = FALSE;
                }
                else
                {
                    return ( );
                }
                $returnValue = $arg != 0;
            }
        }
        if ( $argCount < 0 )
        {
            return ( );
        }
        return $returnValue;
    }

    public static function LOGICAL_OR( )
    {
        $returnValue = FALSE;
        $aArgs = ( func_get_args( ) );
        $argCount = -1;
        foreach ( $aArgs as $argCount => $arg )
        {
            if ( is_bool( $arg ) )
            {
                $returnValue = $returnValue || $arg;
            }
            else if ( is_numeric( $arg ) && !is_string( $arg ) )
            {
                $returnValue = $arg != 0;
            }
            else if ( is_string( $arg ) )
            {
                $arg = strtoupper( $arg );
                if ( $arg == "TRUE" || $arg == ( ) )
                {
                    $arg = TRUE;
                }
                else if ( $arg == "FALSE" || $arg == ( ) )
                {
                    $arg = FALSE;
                }
                else
                {
                    return ( );
                }
                $returnValue = $arg != 0;
            }
        }
        if ( $argCount < 0 )
        {
            return ( );
        }
        return $returnValue;
    }

    public static function NOT( $logical = FALSE )
    {
        $logical = ( $logical );
        if ( is_string( $logical ) )
        {
            $logical = strtoupper( $logical );
            if ( $logical == "TRUE" || $logical == ( ) )
            {
                return FALSE;
            }
            if ( $logical == "FALSE" || $logical == ( ) )
            {
                return TRUE;
            }
            return ( );
        }
        return !$logical;
    }

    public static function STATEMENT_IF( $condition = TRUE, $returnIfTrue = 0, $returnIfFalse = FALSE )
    {
        $condition = is_null( $condition ) ? TRUE : ( $condition );
        $returnIfTrue = is_null( $returnIfTrue ) ? 0 : ( $returnIfTrue );
        $returnIfFalse = is_null( $returnIfFalse ) ? FALSE : ( $returnIfFalse );
        if ( $condition )
        {
            return $returnIfTrue;
        }
        return $returnIfFalse;
    }

    public static function IFERROR( $testValue = "", $errorpart = "" )
    {
        $testValue = is_null( $testValue ) ? "" : ( $testValue );
        $errorpart = is_null( $errorpart ) ? "" : ( $errorpart );
        return ( ( $testValue ), $errorpart, $testValue );
    }

}

if ( defined( "PHPEXCEL_ROOT" ) )
{
    define( "PHPEXCEL_ROOT", dirname( __FILE__ )."/../../" );
    require( PHPEXCEL_ROOT."PHPExcel/Autoloader.php" );
}
?>
