<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class PHPExcel_Calculation_DateTime
{

    public static function _isLeapYear( $year )
    {
        return $year % 400 == 0;
    }

    private static function _dateDiff360( $startDay, $startMonth, $startYear, $endDay, $endMonth, $endYear, $methodUS )
    {
        if ( $startDay == 31 )
        {
            --$startDay;
        }
        else if ( $methodUS && $startMonth == 2 && ( $startDay == 29 || $startDay == 28 ) )
        {
            if ( ( $startYear ) )
            {
                $startDay = 30;
            }
        }
        if ( $endDay == 31 )
        {
            if ( $methodUS && $startDay != 30 )
            {
                $endDay = 1;
                if ( $endMonth == 12 )
                {
                    ++$endYear;
                    $endMonth = 1;
                }
                else
                {
                    ++$endMonth;
                }
            }
            else
            {
                $endDay = 30;
            }
        }
        return $endDay + $endMonth * 30 + $endYear * 360 - $startDay - $startMonth * 30 - $startYear * 360;
    }

    public static function _getDateValue( $dateValue )
    {
        if ( is_numeric( $dateValue ) )
        {
            if ( is_string( $dateValue ) && ( ) == PHPExcel_Calculation_Functions::COMPATIBILITY_GNUMERIC )
            {
                return ( );
            }
            if ( is_object( $dateValue ) && $dateValue instanceof DateTime )
            {
                $dateValue = ( $dateValue );
                return $dateValue;
            }
            $saveReturnDateType = ( );
            ( PHPExcel_Calculation_Functions::RETURNDATE_EXCEL );
            $dateValue = ( $dateValue );
            ( $saveReturnDateType );
        }
        return $dateValue;
    }

    private static function _getTimeValue( $timeValue )
    {
        $saveReturnDateType = ( );
        ( PHPExcel_Calculation_Functions::RETURNDATE_EXCEL );
        $timeValue = ( $timeValue );
        ( $saveReturnDateType );
        return $timeValue;
    }

    private static function _adjustDateByMonths( $dateValue = 0, $adjustmentMonths = 0 )
    {
        $PHPDateObject = ( $dateValue );
        $oMonth = ( integer );
        $oYear = ( integer );
        $adjustmentMonthsString = ( boolean );
        if ( 0 < $adjustmentMonths )
        {
            $adjustmentMonthsString = "+".$adjustmentMonths;
        }
        if ( $adjustmentMonths != 0 )
        {
            $PHPDateObject->modify( $adjustmentMonthsString." months" );
        }
        $nMonth = ( integer );
        $nYear = ( integer );
        $monthDiff = $nMonth - $oMonth + ( $nYear - $oYear ) * 12;
        if ( $monthDiff != $adjustmentMonths )
        {
            $adjustDays = ( integer );
            $adjustDaysString = "-".$adjustDays." days";
            $PHPDateObject->modify( $adjustDaysString );
        }
        return $PHPDateObject;
    }

    public static function DATETIMENOW( )
    {
        $saveTimeZone = date_default_timezone_get( );
        date_default_timezone_set( "UTC" );
        $retValue = FALSE;
        switch ( ( ) )
        {
            case PHPExcel_Calculation_Functions::RETURNDATE_EXCEL :
                $retValue = ( double );
                break;
            case PHPExcel_Calculation_Functions::RETURNDATE_PHP_NUMERIC :
                $retValue = ( integer );
                break;
            case PHPExcel_Calculation_Functions::RETURNDATE_PHP_OBJECT :
                $retValue = new DateTime( );
        }
        date_default_timezone_set( $saveTimeZone );
        return $retValue;
    }

    public static function DATENOW( )
    {
        $saveTimeZone = date_default_timezone_get( );
        date_default_timezone_set( "UTC" );
        $retValue = FALSE;
        $excelDateTime = floor( ( time( ) ) );
        switch ( ( ) )
        {
            case PHPExcel_Calculation_Functions::RETURNDATE_EXCEL :
                $retValue = ( double );
                break;
            case PHPExcel_Calculation_Functions::RETURNDATE_PHP_NUMERIC :
                $retValue = ( integer );
                break;
            case PHPExcel_Calculation_Functions::RETURNDATE_PHP_OBJECT :
                $retValue = ( $excelDateTime );
        }
        date_default_timezone_set( $saveTimeZone );
        return $retValue;
    }

    public static function DATE( $year = 0, $month = 1, $day = 1 )
    {
        $year = ( $year );
        $month = ( $month );
        $day = ( $day );
        if ( $month !== NULL && !is_numeric( $month ) )
        {
            $month = ( $month );
        }
        if ( $day !== NULL && !is_numeric( $day ) )
        {
            $day = ( $day );
        }
        $year = $year !== NULL ? ( $year ) : 0;
        $month = $month !== NULL ? ( $month ) : 0;
        $day = $day !== NULL ? ( $day ) : 0;
        if ( !is_numeric( $year ) || !is_numeric( $month ) || !is_numeric( $day ) )
        {
            return ( );
        }
        $year = ( integer );
        $month = ( integer );
        $day = ( integer );
        $baseYear = ( );
        if ( $year < $baseYear - 1900 )
        {
            return ( );
        }
        if ( $baseYear - 1900 != 0 && $year < $baseYear && 1900 <= $year )
        {
            return ( );
        }
        if ( $year < $baseYear && $baseYear - 1900 <= $year )
        {
            $year += 1900;
        }
        if ( $month < 1 )
        {
            --$month;
            $year += ceil( $month / 12 ) - 1;
            $month = 13 - abs( $month % 12 );
        }
        else if ( 12 < $month )
        {
            $year += floor( $month / 12 );
            $month %= 12;
        }
        if ( $year < $baseYear || 10000 <= $year )
        {
            return ( );
        }
        $excelDateValue = ( $year, $month, $day );
        switch ( ( ) )
        {
            case PHPExcel_Calculation_Functions::RETURNDATE_EXCEL :
                return ( double );
            case PHPExcel_Calculation_Functions::RETURNDATE_PHP_NUMERIC :
                return ( integer );
            case PHPExcel_Calculation_Functions::RETURNDATE_PHP_OBJECT :
                return ( $excelDateValue );
        }
    }

    public static function TIME( $hour = 0, $minute = 0, $second = 0 )
    {
        $hour = ( $hour );
        $minute = ( $minute );
        $second = ( $second );
        if ( $hour == "" )
        {
            $hour = 0;
        }
        if ( $minute == "" )
        {
            $minute = 0;
        }
        if ( $second == "" )
        {
            $second = 0;
        }
        if ( !is_numeric( $hour ) || !is_numeric( $minute ) || !is_numeric( $second ) )
        {
            return ( );
        }
        $hour = ( integer );
        $minute = ( integer );
        $second = ( integer );
        if ( $second < 0 )
        {
            $minute += floor( $second / 60 );
            $second = 60 - abs( $second % 60 );
            if ( $second == 60 )
            {
                $second = 0;
            }
        }
        else if ( 60 <= $second )
        {
            $minute += floor( $second / 60 );
            $second %= 60;
        }
        if ( $minute < 0 )
        {
            $hour += floor( $minute / 60 );
            $minute = 60 - abs( $minute % 60 );
            if ( $minute == 60 )
            {
                $minute = 0;
            }
        }
        else if ( 60 <= $minute )
        {
            $hour += floor( $minute / 60 );
            $minute %= 60;
        }
        if ( 23 < $hour )
        {
            $hour %= 24;
        }
        else
        {
            if ( $hour < 0 )
            {
                return ( );
            }
        }
        switch ( ( ) )
        {
            case PHPExcel_Calculation_Functions::RETURNDATE_EXCEL :
                $date = 0;
                $calendar = ( );
                if ( $calendar != PHPExcel_Shared_Date::CALENDAR_WINDOWS_1900 )
                {
                    $date = 1;
                }
                return ( double );
            case PHPExcel_Calculation_Functions::RETURNDATE_PHP_NUMERIC :
                return ( integer );
            case PHPExcel_Calculation_Functions::RETURNDATE_PHP_OBJECT :
                $dayAdjust = 0;
                if ( $hour < 0 )
                {
                    $dayAdjust = floor( $hour / 24 );
                    $hour = 24 - abs( $hour % 24 );
                    if ( $hour == 24 )
                    {
                        $hour = 0;
                    }
                }
                else if ( 24 <= $hour )
                {
                    $dayAdjust = floor( $hour / 24 );
                    $hour %= 24;
                }
                $phpDateObject = new DateTime( "1900-01-01 ".$hour.":".$minute.":".$second );
                if ( $dayAdjust != 0 )
                {
                    $phpDateObject->modify( $dayAdjust." days" );
                }
                return $phpDateObject;
        }
    }

    public static function DATEVALUE( $dateValue = 1 )
    {
        $dateValue = trim( ( $dateValue ), "\"" );
        $dateValue = preg_replace( "/(\\d)(st|nd|rd|th)([ -\\/])/Ui", "$1$3", $dateValue );
        $dateValue = str_replace( array( "/", ".", "-", "  " ), array( " ", " ", " ", " " ), $dateValue );
        $yearFound = FALSE;
        $t1 = explode( " ", $dateValue );
        foreach ( $t1 as $yearFound )
        {
            if ( $yearFound )
            {
            }
        }
    }
}
if ( count( $t1 ) == 1 && strpos( $t, ":" ) )
{
    return 0;
}
if ( count( $t1 ) == 2 )
{
    if ( $yearFound )
    {
        array_unshift( &$t1, 1 );
    }
    else
    {
        array_push( &$t1, date( "Y" ) );
    }
}
unset( $t );
$dateValue = implode( " ", $t1 );
$PHPDateArray = date_parse( $dateValue );
if ( $PHPDateArray === FALSE || 0 < $PHPDateArray['error_count'] )
{
    $testVal1 = strtok( $dateValue, "- " );
    if ( $testVal1 !== FALSE )
    {
        $testVal2 = strtok( "- " );
        if ( $testVal2 !== FALSE )
        {
            $testVal3 = strtok( "- " );
            if ( $testVal3 === FALSE )
            {
                $testVal3 = strftime( "%Y" );
            }
        }
        else
        {
            return ( );
        }
    }
    return ( );
    $PHPDateArray = date_parse( $testVal1."-".$testVal2."-".$testVal3 );
    if ( $PHPDateArray === FALSE || 0 < $PHPDateArray['error_count'] )
    {
        $PHPDateArray = date_parse( $testVal2."-".$testVal1."-".$testVal3 );
        if ( $PHPDateArray === FALSE || 0 < $PHPDateArray['error_count'] )
        {
            return ( );
        }
    }
}
if ( $PHPDateArray !== FALSE && $PHPDateArray['error_count'] == 0 )
{
    if ( $PHPDateArray['year'] == "" )
    {
        $PHPDateArray['year'] = strftime( "%Y" );
    }
    if ( $PHPDateArray['year'] < 1900 )
    {
        return ( );
    }
    if ( $PHPDateArray['month'] == "" )
    {
        $PHPDateArray['month'] = strftime( "%m" );
    }
    if ( $PHPDateArray['day'] == "" )
    {
        $PHPDateArray['day'] = strftime( "%d" );
    }
    $excelDateValue = floor( ( $PHPDateArray['year'], $PHPDateArray['month'], $PHPDateArray['day'], $PHPDateArray['hour'], $PHPDateArray['minute'], $PHPDateArray['second'] ) );
    switch ( ( ) )
    {
        case PHPExcel_Calculation_Functions::RETURNDATE_EXCEL :
            return ( double );
        case PHPExcel_Calculation_Functions::RETURNDATE_PHP_NUMERIC :
            return ( integer );
        case PHPExcel_Calculation_Functions::RETURNDATE_PHP_OBJECT :
            return new DateTime( $PHPDateArray['year']."-".$PHPDateArray['month']."-".$PHPDateArray['day']." 00:00:00" );
    }
}
return ( );
}

    public static function TIMEVALUE( $timeValue )
    {
        $timeValue = trim( ( $timeValue ), "\"" );
        $timeValue = str_replace( array( "/", "." ), array( "-", "-" ), $timeValue );
        $PHPDateArray = date_parse( $timeValue );
        if ( $PHPDateArray !== FALSE && $PHPDateArray['error_count'] == 0 )
        {
            if ( ( ) == PHPExcel_Calculation_Functions::COMPATIBILITY_OPENOFFICE )
            {
                $excelDateValue = ( $PHPDateArray['year'], $PHPDateArray['month'], $PHPDateArray['day'], $PHPDateArray['hour'], $PHPDateArray['minute'], $PHPDateArray['second'] );
            }
            else
            {
                $excelDateValue = ( 1900, 1, 1, $PHPDateArray['hour'], $PHPDateArray['minute'], $PHPDateArray['second'] ) - 1;
            }
            switch ( ( ) )
            {
                case PHPExcel_Calculation_Functions::RETURNDATE_EXCEL :
                    return ( double );
                case PHPExcel_Calculation_Functions::RETURNDATE_PHP_NUMERIC :
                    return ( integer )( $phpDateValue = ( $excelDateValue + 25569 ) - 3600 );
                case PHPExcel_Calculation_Functions::RETURNDATE_PHP_OBJECT :
                    return new DateTime( "1900-01-01 ".$PHPDateArray['hour'].":".$PHPDateArray['minute'].":".$PHPDateArray['second'] );
            }
        }
        return ( );
    }

    public static function DATEDIF( $startDate = 0, $endDate = 0, $unit = "D" )
    {
        $startDate = ( $startDate );
        $endDate = ( $endDate );
        $unit = strtoupper( ( $unit ) );
        if ( is_string( $startDate = ( $startDate ) ) )
        {
            return ( );
        }
        if ( is_string( $endDate = ( $endDate ) ) )
        {
            return ( );
        }
        if ( $endDate <= $startDate )
        {
            return ( );
        }
        $difference = $endDate - $startDate;
        $PHPStartDateObject = ( $startDate );
        $startDays = $PHPStartDateObject->format( "j" );
        $startMonths = $PHPStartDateObject->format( "n" );
        $startYears = $PHPStartDateObject->format( "Y" );
        $PHPEndDateObject = ( $endDate );
        $endDays = $PHPEndDateObject->format( "j" );
        $endMonths = $PHPEndDateObject->format( "n" );
        $endYears = $PHPEndDateObject->format( "Y" );
        $retVal = ( );
        switch ( $unit )
        {
            case "D" :
                $retVal = intval( $difference );
                return $retVal;
            case "M" :
                $retVal = intval( $endMonths - $startMonths ) + intval( $endYears - $startYears ) * 12;
                if ( $endDays < $startDays )
                {
                    --$retVal;
                    return $retVal;
                }
            case "Y" :
                $retVal = intval( $endYears - $startYears );
                if ( $endMonths < $startMonths )
                {
                    --$retVal;
                    return $retVal;
                }
                if ( $endMonths == $startMonths && $endDays < $startDays )
                {
                    --$retVal;
                    return $retVal;
                }
            case "MD" :
                if ( $endDays < $startDays )
                {
                    $retVal = $endDays;
                    $PHPEndDateObject->modify( "-".$endDays." days" );
                    $adjustDays = $PHPEndDateObject->format( "j" );
                    if ( $startDays < $adjustDays )
                    {
                        $retVal += $adjustDays - $startDays;
                        return $retVal;
                    }
                }
                $retVal = $endDays - $startDays;
                return $retVal;
            case "YM" :
                $retVal = intval( $endMonths - $startMonths );
                if ( $retVal < 0 )
                {
                    $retVal += 12;
                }
                if ( $endDays < $startDays )
                {
                    --$retVal;
                    return $retVal;
                }
            case "YD" :
                $retVal = intval( $difference );
                if ( $startYears < $endYears )
                {
                    while ( $startYears < $endYears )
                    {
                        $PHPEndDateObject->modify( "-1 year" );
                        $endYears = $PHPEndDateObject->format( "Y" );
                    }
                    $retVal = $PHPEndDateObject->format( "z" ) - $PHPStartDateObject->format( "z" );
                    if ( $retVal < 0 )
                    {
                        $retVal += 365;
                        return $retVal;
                    }
                }
        }
        $retVal = ( );
        return $retVal;
    }

    public static function DAYS360( $startDate = 0, $endDate = 0, $method = FALSE )
    {
        $startDate = ( $startDate );
        $endDate = ( $endDate );
        if ( is_string( $startDate = ( $startDate ) ) )
        {
            return ( );
        }
        if ( is_string( $endDate = ( $endDate ) ) )
        {
            return ( );
        }
        if ( is_bool( $method ) )
        {
            return ( );
        }
        $PHPStartDateObject = ( $startDate );
        $startDay = $PHPStartDateObject->format( "j" );
        $startMonth = $PHPStartDateObject->format( "n" );
        $startYear = $PHPStartDateObject->format( "Y" );
        $PHPEndDateObject = ( $endDate );
        $endDay = $PHPEndDateObject->format( "j" );
        $endMonth = $PHPEndDateObject->format( "n" );
        $endYear = $PHPEndDateObject->format( "Y" );
        return ( $startDay, $startMonth, $startYear, $endDay, $endMonth, $endYear, !$method );
    }

    public static function YEARFRAC( $startDate = 0, $endDate = 0, $method = 0 )
    {
        $startDate = ( $startDate );
        $endDate = ( $endDate );
        $method = ( $method );
        if ( is_string( $startDate = ( $startDate ) ) )
        {
            return ( );
        }
        if ( is_string( $endDate = ( $endDate ) ) )
        {
            return ( );
        }
        if ( !is_numeric( $method ) || !is_string( $method ) || $method == "" )
        {
            switch ( $method )
            {
                case 0 :
                    return ( $startDate, $endDate ) / 360;
                case 1 :
                    $days = ( $startDate, $endDate );
                    $startYear = ( $startDate );
                    $endYear = ( $endDate );
                    $years = $endYear - $startYear + 1;
                    $leapDays = 0;
                    if ( $years == 1 )
                    {
                        if ( ( $endYear ) )
                        {
                            $startMonth = ( $startDate );
                            $endMonth = ( $endDate );
                            $endDay = ( $endDate );
                            if ( $startMonth < 3 || 229 <= $endMonth * 100 + $endDay )
                            {
                                $leapDays += 1;
                            }
                        }
                    }
                    else
                    {
                        $year = $startYear;
                        for ( ; $year <= $endYear; ++$year )
                        {
                            if ( $year == $startYear )
                            {
                                $startMonth = ( $startDate );
                                $startDay = ( $startDate );
                                if ( $startMonth < 3 )
                                {
                                    $leapDays += ( $year ) ? 1 : 0;
                                }
                            }
                            else if ( $year == $endYear )
                            {
                                $endMonth = ( $endDate );
                                $endDay = ( $endDate );
                                if ( 229 <= $endMonth * 100 + $endDay )
                                {
                                    $leapDays += ( $year ) ? 1 : 0;
                                }
                            }
                            else
                            {
                                $leapDays += ( $year ) ? 1 : 0;
                            }
                        }
                        if ( $years == 2 )
                        {
                            if ( $leapDays == 0 )
                            {
                                if ( ( $startYear ) && 365 < $days )
                                {
                                    $leapDays = 1;
                                }
                            }
                            else if ( $days < 366 )
                            {
                                $years = 1;
                            }
                        }
                        $leapDays /= $years;
                    }
                    return $days / ( 365 + $leapDays );
                case 2 :
                    return ( $startDate, $endDate ) / 360;
                case 3 :
                    return ( $startDate, $endDate ) / 365;
                case 4 :
                    return ( $startDate, $endDate, TRUE ) / 360;
                }
                else
                {
                default :
                    return ( );
            }
        }
    }

    public static function NETWORKDAYS( $startDate, $endDate )
    {
        $startDate = ( $startDate );
        $endDate = ( $endDate );
        $dateArgs = ( func_get_args( ) );
        array_shift( &$dateArgs );
        array_shift( &$dateArgs );
        if ( is_string( $startDate = $sDate = ( $startDate ) ) )
        {
            return ( );
        }
        $startDate = ( double );
        if ( is_string( $endDate = $eDate = ( $endDate ) ) )
        {
            return ( );
        }
        $endDate = ( double );
        if ( $eDate < $sDate )
        {
            $startDate = $eDate;
            $endDate = $sDate;
        }
        $startDoW = 6 - ( $startDate, 2 );
        if ( $startDoW < 0 )
        {
            $startDoW = 0;
        }
        $endDoW = ( $endDate, 2 );
        if ( 6 <= $endDoW )
        {
            $endDoW = 0;
        }
        $wholeWeekDays = floor( ( $endDate - $startDate ) / 7 ) * 5;
        $partWeekDays = $endDoW + $startDoW;
        if ( 5 < $partWeekDays )
        {
            $partWeekDays -= 5;
        }
        $holidayCountedArray = array( );
        foreach ( $dateArgs as $holidayDate )
        {
            if ( is_string( $holidayDate = ( $holidayDate ) ) )
            {
                return ( );
            }
            if ( !( $startDate <= $holidayDate ) || !( $holidayDate <= $endDate ) )
            {
                if ( !( ( $holidayDate, 2 ) < 6 ) || in_array( $holidayDate, $holidayCountedArray ) )
                {
                    --$partWeekDays;
                    $holidayCountedArray[] = $holidayDate;
                }
            }
        }
        if ( $eDate < $sDate )
        {
            return 0 - ( $wholeWeekDays + $partWeekDays );
        }
        return $wholeWeekDays + $partWeekDays;
    }

    public static function WORKDAY( $startDate, $endDays )
    {
        $startDate = ( $startDate );
        $endDays = ( $endDays );
        $dateArgs = ( func_get_args( ) );
        array_shift( &$dateArgs );
        array_shift( &$dateArgs );
        if ( is_string( $startDate = ( $startDate ) ) || !is_numeric( $endDays ) )
        {
            return ( );
        }
        $startDate = ( double );
        $endDays = ( integer );
        if ( $endDays == 0 )
        {
            return $startDate;
        }
        $decrementing = $endDays < 0 ? TRUE : FALSE;
        $startDoW = ( $startDate, 3 );
        $startDate += 7 - $startDoW;
        $endDays--;
        $endDate = ( double ) + intval( $endDays / 5 ) * 7 + $endDays % 5;
        $endDoW = ( $endDate, 3 );
        $endDate += 7 - $endDoW;
        if ( empty( $dateArgs ) )
        {
            $holidayCountedArray = $holidayDates = array( );
            foreach ( $dateArgs as $holidayDate )
            {
                if ( "" < trim( $holidayDate ) )
                {
                    if ( is_string( $holidayDate = ( $holidayDate ) ) )
                    {
                        return ( );
                    }
                    if ( ( $holidayDate, 3 ) < 5 )
                    {
                        $holidayDates[] = $holidayDate;
                    }
                }
            }
            if ( $decrementing )
            {
                rsort( &$holidayDates, SORT_NUMERIC );
            }
            else
            {
                sort( &$holidayDates, SORT_NUMERIC );
            }
            foreach ( $holidayDates as $holidayDate )
            {
                if ( $decrementing )
                {
                    if ( in_array( $holidayDate, $holidayCountedArray ) )
                    {
                        --$endDate;
                        $holidayCountedArray[] = $holidayDate;
                    }
                }
                else if ( in_array( $holidayDate, $holidayCountedArray ) )
                {
                    ++$endDate;
                    $holidayCountedArray[] = $holidayDate;
                }
                $endDoW = ( $endDate, 3 );
                if ( 5 <= $endDoW )
                {
                    $endDate += 7 - $endDoW;
                }
            }
        }
        switch ( ( ) )
        {
            case PHPExcel_Calculation_Functions::RETURNDATE_EXCEL :
                return ( double );
            case PHPExcel_Calculation_Functions::RETURNDATE_PHP_NUMERIC :
                return ( integer );
            case PHPExcel_Calculation_Functions::RETURNDATE_PHP_OBJECT :
                return ( $endDate );
        }
    }

    public static function DAYOFMONTH( $dateValue = 1 )
    {
        $dateValue = ( $dateValue );
        if ( is_string( $dateValue = ( $dateValue ) ) )
        {
            return ( );
        }
        if ( $dateValue == 0 )
        {
            return 0;
        }
        if ( $dateValue < 0 )
        {
            return ( );
        }
        $PHPDateObject = ( $dateValue );
        return ( integer );
    }

    public static function DAYOFWEEK( $dateValue = 1, $style = 1 )
    {
        $dateValue = ( $dateValue );
        $style = ( $style );
        if ( is_numeric( $style ) )
        {
            return ( );
        }
        if ( $style < 1 || 3 < $style )
        {
            return ( );
        }
        $style = floor( $style );
        if ( is_string( $dateValue = ( $dateValue ) ) )
        {
            return ( );
        }
        if ( $dateValue < 0 )
        {
            return ( );
        }
        $PHPDateObject = ( $dateValue );
        $DoW = $PHPDateObject->format( "w" );
        $firstDay = 1;
        switch ( $style )
        {
            case 1 :
                ++$DoW;
                break;
            case 2 :
                if ( $DoW == 0 )
                {
                    $DoW = 7;
                    break;
                }
            case 3 :
                if ( $DoW == 0 )
                {
                    $DoW = 7;
                }
                $firstDay = 0;
                --$DoW;
        }
        if ( ( ) == PHPExcel_Calculation_Functions::COMPATIBILITY_EXCEL && $PHPDateObject->format( "Y" ) == 1900 && $PHPDateObject->format( "n" ) <= 2 )
        {
            --$DoW;
            if ( $DoW < $firstDay )
            {
                $DoW += 7;
            }
        }
        return ( integer );
    }

    public static function WEEKOFYEAR( $dateValue = 1, $method = 1 )
    {
        $dateValue = ( $dateValue );
        $method = ( $method );
        if ( is_numeric( $method ) )
        {
            return ( );
        }
        if ( $method < 1 || 2 < $method )
        {
            return ( );
        }
        $method = floor( $method );
        if ( is_string( $dateValue = ( $dateValue ) ) )
        {
            return ( );
        }
        if ( $dateValue < 0 )
        {
            return ( );
        }
        $PHPDateObject = ( $dateValue );
        $dayOfYear = $PHPDateObject->format( "z" );
        $dow = $PHPDateObject->format( "w" );
        $PHPDateObject->modify( "-".$dayOfYear." days" );
        $dow = $PHPDateObject->format( "w" );
        $daysInFirstWeek = 7 - ( $dow + ( 2 - $method ) ) % 7;
        $dayOfYear -= $daysInFirstWeek;
        $weekOfYear = ceil( $dayOfYear / 7 ) + 1;
        return ( integer );
    }

    public static function MONTHOFYEAR( $dateValue = 1 )
    {
        $dateValue = ( $dateValue );
        if ( is_string( $dateValue = ( $dateValue ) ) )
        {
            return ( );
        }
        if ( $dateValue < 0 )
        {
            return ( );
        }
        $PHPDateObject = ( $dateValue );
        return ( integer );
    }

    public static function YEAR( $dateValue = 1 )
    {
        $dateValue = ( $dateValue );
        if ( is_string( $dateValue = ( $dateValue ) ) )
        {
            return ( );
        }
        if ( $dateValue < 0 )
        {
            return ( );
        }
        $PHPDateObject = ( $dateValue );
        return ( integer );
    }

    public static function HOUROFDAY( $timeValue = 0 )
    {
        $timeValue = ( $timeValue );
        if ( is_numeric( $timeValue ) )
        {
            if ( ( ) == PHPExcel_Calculation_Functions::COMPATIBILITY_GNUMERIC )
            {
                $testVal = strtok( $timeValue, "/-: " );
                if ( strlen( $testVal ) < strlen( $timeValue ) )
                {
                    return ( );
                }
            }
            $timeValue = ( $timeValue );
            if ( is_string( $timeValue ) )
            {
                return ( );
            }
        }
        if ( 1 <= $timeValue )
        {
            $timeValue = fmod( $timeValue, 1 );
        }
        else
        {
            if ( $timeValue < 0 )
            {
                return ( );
            }
        }
        $timeValue = ( $timeValue );
        return ( integer );
    }

    public static function MINUTEOFHOUR( $timeValue = 0 )
    {
        $timeValue = $timeTester = ( $timeValue );
        if ( is_numeric( $timeValue ) )
        {
            if ( ( ) == PHPExcel_Calculation_Functions::COMPATIBILITY_GNUMERIC )
            {
                $testVal = strtok( $timeValue, "/-: " );
                if ( strlen( $testVal ) < strlen( $timeValue ) )
                {
                    return ( );
                }
            }
            $timeValue = ( $timeValue );
            if ( is_string( $timeValue ) )
            {
                return ( );
            }
        }
        if ( 1 <= $timeValue )
        {
            $timeValue = fmod( $timeValue, 1 );
        }
        else
        {
            if ( $timeValue < 0 )
            {
                return ( );
            }
        }
        $timeValue = ( $timeValue );
        return ( integer );
    }

    public static function SECONDOFMINUTE( $timeValue = 0 )
    {
        $timeValue = ( $timeValue );
        if ( is_numeric( $timeValue ) )
        {
            if ( ( ) == PHPExcel_Calculation_Functions::COMPATIBILITY_GNUMERIC )
            {
                $testVal = strtok( $timeValue, "/-: " );
                if ( strlen( $testVal ) < strlen( $timeValue ) )
                {
                    return ( );
                }
            }
            $timeValue = ( $timeValue );
            if ( is_string( $timeValue ) )
            {
                return ( );
            }
        }
        if ( 1 <= $timeValue )
        {
            $timeValue = fmod( $timeValue, 1 );
        }
        else
        {
            if ( $timeValue < 0 )
            {
                return ( );
            }
        }
        $timeValue = ( $timeValue );
        return ( integer );
    }

    public static function EDATE( $dateValue = 1, $adjustmentMonths = 0 )
    {
        $dateValue = ( $dateValue );
        $adjustmentMonths = ( $adjustmentMonths );
        if ( is_numeric( $adjustmentMonths ) )
        {
            return ( );
        }
        $adjustmentMonths = floor( $adjustmentMonths );
        if ( is_string( $dateValue = ( $dateValue ) ) )
        {
            return ( );
        }
        $PHPDateObject = ( $dateValue, $adjustmentMonths );
        switch ( ( ) )
        {
            case PHPExcel_Calculation_Functions::RETURNDATE_EXCEL :
                return ( double );
            case PHPExcel_Calculation_Functions::RETURNDATE_PHP_NUMERIC :
                return ( integer );
            case PHPExcel_Calculation_Functions::RETURNDATE_PHP_OBJECT :
                return $PHPDateObject;
        }
    }

    public static function EOMONTH( $dateValue = 1, $adjustmentMonths = 0 )
    {
        $dateValue = ( $dateValue );
        $adjustmentMonths = ( $adjustmentMonths );
        if ( is_numeric( $adjustmentMonths ) )
        {
            return ( );
        }
        $adjustmentMonths = floor( $adjustmentMonths );
        if ( is_string( $dateValue = ( $dateValue ) ) )
        {
            return ( );
        }
        $PHPDateObject = ( $dateValue, $adjustmentMonths + 1 );
        $adjustDays = ( integer );
        $adjustDaysString = "-".$adjustDays." days";
        $PHPDateObject->modify( $adjustDaysString );
        switch ( ( ) )
        {
            case PHPExcel_Calculation_Functions::RETURNDATE_EXCEL :
                return ( double );
            case PHPExcel_Calculation_Functions::RETURNDATE_PHP_NUMERIC :
                return ( integer );
            case PHPExcel_Calculation_Functions::RETURNDATE_PHP_OBJECT :
                return $PHPDateObject;
        }
    }

}

if ( defined( "PHPEXCEL_ROOT" ) )
{
    define( "PHPEXCEL_ROOT", dirname( __FILE__ )."/../../" );
    require( PHPEXCEL_ROOT."PHPExcel/Autoloader.php" );
}
?>
