<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class PHPExcel_Calculation_Database
{

    private static function __fieldExtract( $database, $field )
    {
        $field = strtoupper( ( $field ) );
        $fieldNames = array_map( "strtoupper", array_shift( &$database ) );
        if ( is_numeric( $field ) )
        {
            $keys = array_keys( $fieldNames );
            return $keys[$field - 1];
        }
        $key = array_search( $field, $fieldNames );
        if ( $key )
        {
            return $key;
        }
    }

    private static function __filter( $database, $criteria )
    {
        $fieldNames = array_shift( &$database );
        $criteriaNames = array_shift( &$criteria );
        $testConditions = $testValues = array( );
        $testConditionsCount = 0;
        foreach ( $criteriaNames as $key => $criteriaName )
        {
            $testCondition = array( );
            $testConditionCount = 0;
            foreach ( $criteria as $row => $criterion )
            {
                if ( "" < $criterion[$key] )
                {
                    $testCondition[] = "[:".$criteriaName."]".( $criterion[$key] );
                    ++$testConditionCount;
                }
            }
            if ( 1 < $testConditionCount )
            {
                $testConditions[] = "OR(".implode( ",", $testCondition ).")";
                ++$testConditionsCount;
            }
            else if ( $testConditionCount == 1 )
            {
                $testConditions[] = $testCondition[0];
                ++$testConditionsCount;
            }
        }
        if ( 1 < $testConditionsCount )
        {
            $testConditionSet = "AND(".implode( ",", $testConditions ).")";
        }
        else if ( $testConditionsCount == 1 )
        {
            $testConditionSet = $testConditions[0];
        }
        foreach ( $database as $dataRow => $dataValues )
        {
            $testConditionList = $testConditionSet;
            foreach ( $criteriaNames as $key => $criteriaName )
            {
                $k = array_search( $criteriaName, $fieldNames );
                if ( isset( $dataValues[$k] ) )
                {
                    $dataValue = $dataValues[$k];
                    $dataValue = is_string( $dataValue ) ? ( strtoupper( $dataValue ) ) : $dataValue;
                    $testConditionList = str_replace( "[:".$criteriaName."]", $dataValue, $testConditionList );
                }
            }
            $result = ( )->_calculateFormulaValue( "=".$testConditionList );
            if ( $result )
            {
                unset( $database[$dataRow] );
            }
        }
        return $database;
    }

    public static function DAVERAGE( $database, $field, $criteria )
    {
        $field = ( $database, $field );
        if ( is_null( $field ) )
        {
        }
        else
        {
            $database = ( $database, $criteria );
            $colData = array( );
            foreach ( $database as $row )
            {
                $colData[] = $row[$field];
            }
            return ( $colData );
        }
    }

    public static function DCOUNT( $database, $field, $criteria )
    {
        $field = ( $database, $field );
        if ( is_null( $field ) )
        {
        }
        else
        {
            $database = ( $database, $criteria );
            $colData = array( );
            foreach ( $database as $row )
            {
                $colData[] = $row[$field];
            }
            return ( $colData );
        }
    }

    public static function DCOUNTA( $database, $field, $criteria )
    {
        $field = ( $database, $field );
        if ( is_null( $field ) )
        {
        }
        else
        {
            $database = ( $database, $criteria );
            $colData = array( );
            foreach ( $database as $row )
            {
                $colData[] = $row[$field];
            }
            return ( $colData );
        }
    }

    public static function DGET( $database, $field, $criteria )
    {
        $field = ( $database, $field );
        if ( is_null( $field ) )
        {
        }
        else
        {
            $database = ( $database, $criteria );
            $colData = array( );
            foreach ( $database as $row )
            {
                $colData[] = $row[$field];
            }
            if ( 1 < count( $colData ) )
            {
                return ( );
            }
            return $colData[0];
        }
    }

    public static function DMAX( $database, $field, $criteria )
    {
        $field = ( $database, $field );
        if ( is_null( $field ) )
        {
        }
        else
        {
            $database = ( $database, $criteria );
            $colData = array( );
            foreach ( $database as $row )
            {
                $colData[] = $row[$field];
            }
            return ( $colData );
        }
    }

    public static function DMIN( $database, $field, $criteria )
    {
        $field = ( $database, $field );
        if ( is_null( $field ) )
        {
        }
        else
        {
            $database = ( $database, $criteria );
            $colData = array( );
            foreach ( $database as $row )
            {
                $colData[] = $row[$field];
            }
            return ( $colData );
        }
    }

    public static function DPRODUCT( $database, $field, $criteria )
    {
        $field = ( $database, $field );
        if ( is_null( $field ) )
        {
        }
        else
        {
            $database = ( $database, $criteria );
            $colData = array( );
            foreach ( $database as $row )
            {
                $colData[] = $row[$field];
            }
            return ( $colData );
        }
    }

    public static function DSTDEV( $database, $field, $criteria )
    {
        $field = ( $database, $field );
        if ( is_null( $field ) )
        {
        }
        else
        {
            $database = ( $database, $criteria );
            $colData = array( );
            foreach ( $database as $row )
            {
                $colData[] = $row[$field];
            }
            return ( $colData );
        }
    }

    public static function DSTDEVP( $database, $field, $criteria )
    {
        $field = ( $database, $field );
        if ( is_null( $field ) )
        {
        }
        else
        {
            $database = ( $database, $criteria );
            $colData = array( );
            foreach ( $database as $row )
            {
                $colData[] = $row[$field];
            }
            return ( $colData );
        }
    }

    public static function DSUM( $database, $field, $criteria )
    {
        $field = ( $database, $field );
        if ( is_null( $field ) )
        {
        }
        else
        {
            $database = ( $database, $criteria );
            $colData = array( );
            foreach ( $database as $row )
            {
                $colData[] = $row[$field];
            }
            return ( $colData );
        }
    }

    public static function DVAR( $database, $field, $criteria )
    {
        $field = ( $database, $field );
        if ( is_null( $field ) )
        {
        }
        else
        {
            $database = ( $database, $criteria );
            $colData = array( );
            foreach ( $database as $row )
            {
                $colData[] = $row[$field];
            }
            return ( $colData );
        }
    }

    public static function DVARP( $database, $field, $criteria )
    {
        $field = ( $database, $field );
        if ( is_null( $field ) )
        {
        }
        else
        {
            $database = ( $database, $criteria );
            $colData = array( );
            foreach ( $database as $row )
            {
                $colData[] = $row[$field];
            }
            return ( $colData );
        }
    }

}

if ( defined( "PHPEXCEL_ROOT" ) )
{
    define( "PHPEXCEL_ROOT", dirname( __FILE__ )."/../../" );
    require( PHPEXCEL_ROOT."PHPExcel/Autoloader.php" );
}
?>
