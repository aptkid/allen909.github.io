<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
interface PHPExcel_Reader_IReader
{

    public abstract function canRead( );
$pFilename )
    {

    public abstract function load( );
$pFilename )
    {

}

?>
