<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
if ( defined( "PHPEXCEL_ROOT" ) )
{
    define( "PHPEXCEL_ROOT", dirname( __FILE__ )."/../../" );
    require( PHPEXCEL_ROOT."PHPExcel/Autoloader.php" );
}
class PHPExcel_Reader_Gnumeric extends PHPExcel_Reader_IReader implements PHPExcel_Reader_IReader
{

    private $_styles = array( );
    private $_expressions = array( );
    private $_referenceHelper;

    public function __construct( )
    {
        $this->_readFilter = new PHPExcel_Reader_DefaultReadFilter( );
        $this->_referenceHelper = ( );
    }

    public function canRead( $pFilename )
    {
        if ( file_exists( $pFilename ) )
        {
            throw new PHPExcel_Reader_Exception( "Could not open ".$pFilename." for reading! File does not exist." );
        }
        if ( function_exists( "gzread" ) )
        {
            throw new PHPExcel_Reader_Exception( "gzlib library is not enabled" );
        }
        $fh = fopen( $pFilename, "r" );
        $data = fread( $fh, 2 );
        fclose( $fh );
        if ( $data != chr( 31 ).chr( 139 ) )
        {
            return FALSE;
        }
        return TRUE;
    }

    public function listWorksheetNames( $pFilename )
    {
        if ( file_exists( $pFilename ) )
        {
            throw new PHPExcel_Reader_Exception( "Could not open ".$pFilename." for reading! File does not exist." );
        }
        $xml = new XMLReader( );
        $xml->open( "compress.zlib://".realpath( $pFilename ) );
        $xml->setParserProperty( 2, TRUE );
        $worksheetNames = array( );
        while ( $xml->read( ) )
        {
            if ( $xml->name == "gnm:SheetName" && $xml->nodeType == XMLReader::ELEMENT )
            {
                $xml->read( );
                $worksheetNames[] = ( boolean );
            }
            else if ( $xml->name == "gnm:Sheets" )
            {
            }
        }
        return $worksheetNames;
    }

    public function listWorksheetInfo( $pFilename )
    {
        if ( file_exists( $pFilename ) )
        {
            throw new PHPExcel_Reader_Exception( "Could not open ".$pFilename." for reading! File does not exist." );
        }
        $xml = new XMLReader( );
        $xml->open( "compress.zlib://".realpath( $pFilename ) );
        $xml->setParserProperty( 2, TRUE );
        $worksheetInfo = array( );
        while ( $xml->read( ) )
        {
            if ( !( $xml->name == "gnm:Sheet" ) || !( $xml->nodeType == XMLReader::ELEMENT ) )
            {
                $tmpInfo = array( "worksheetName" => "", "lastColumnLetter" => "A", "lastColumnIndex" => 0, "totalRows" => 0, "totalColumns" => 0 );
                do
                {
                    while ( $xml->read( ) )
                    {
                        if ( $xml->name == "gnm:Name" && $xml->nodeType == XMLReader::ELEMENT )
                        {
                            $xml->read( );
                            $tmpInfo['worksheetName'] = ( boolean );
                        }
                        else if ( !( $xml->name == "gnm:MaxCol" ) || !( $xml->nodeType == XMLReader::ELEMENT ) )
                        {
                            $xml->read( );
                            $tmpInfo['lastColumnIndex'] = ( integer );
                            $tmpInfo['totalColumns'] = ( integer ) + 1;
                        }
                    }
                } while ( !( $xml->name == "gnm:MaxRow" ) || !( $xml->nodeType == XMLReader::ELEMENT ) );
                $xml->read( );
                $tmpInfo['totalRows'] = ( integer ) + 1;
                $tmpInfo['lastColumnLetter'] = ( $tmpInfo['lastColumnIndex'] );
                $worksheetInfo[] = $tmpInfo;
            }
        }
        return $worksheetInfo;
    }

    private function _gzfileGetContents( $filename )
    {
        $file = @gzopen( $filename, "rb" );
        if ( $file !== FALSE )
        {
            $data = "";
            while ( !gzeof( $file ) )
            {
                $data .= gzread( $file, 1024 );
            }
            gzclose( $file );
        }
        return $data;
    }

    public function load( $pFilename )
    {
        $objPHPExcel = new PHPExcel( );
        return $this->loadIntoExisting( $pFilename, $objPHPExcel );
    }

    public function loadIntoExisting( $pFilename, $objPHPExcel )
    {
        if ( file_exists( $pFilename ) )
        {
            throw new PHPExcel_Reader_Exception( "Could not open ".$pFilename." for reading! File does not exist." );
        }
        $timezoneObj = new DateTimeZone( "Europe/London" );
        $GMT = new DateTimeZone( "UTC" );
        $gFileData = $this->_gzfileGetContents( $pFilename );
        $xml = simplexml_load_string( $gFileData );
        $namespacesMeta = $xml->getNamespaces( TRUE );
        $gnmXML = $namespacesMeta['gnm']( $namespacesMeta['gnm'] );
        $docProps = $objPHPExcel->getProperties( );
        if ( isset( $namespacesMeta['office'] ) )
        {
            $officeXML = $namespacesMeta['office']( $namespacesMeta['office'] );
            $officeDocXML = $officeXML->document-meta;
            $officeDocMetaXML = $officeDocXML->meta;
            foreach ( $officeDocMetaXML as $officePropertyData )
            {
                $officePropertyDC = array( );
                if ( isset( $namespacesMeta['dc'] ) )
                {
                    $officePropertyDC = $namespacesMeta['dc']( $namespacesMeta['dc'] );
                }
        }
}
}
}
}
foreach ( $officePropertyDC as $propertyName => $propertyValue )
{
    $propertyValue = ( boolean );
case "title" :
    switch ( $propertyName )
    {
            trim( $propertyValue )( trim( $propertyValue ) );
            continue;
        case "subject" :
            switch ( $propertyName )
            {
                    trim( $propertyValue )( trim( $propertyValue ) );
                    continue;
                case "creator" :
                    switch ( $propertyName )
                    {
                            trim( $propertyValue )( trim( $propertyValue ) );
                            trim( $propertyValue )( trim( $propertyValue ) );
                            continue;
                        case "date" :
                            switch ( $propertyName )
                            {
                                    $creationDate = strtotime( trim( $propertyValue ) );
                                    $docProps->setCreated( $creationDate );
                                    $docProps->setModified( $creationDate );
                                    continue;
                                    switch ( $propertyName )
                                    {
                                        case "description" :
                                            trim( $propertyValue )( trim( $propertyValue ) );
                                        }
                                        $officePropertyMeta = array( );
                                        if ( isset( $namespacesMeta['meta'] ) )
                                        {
                                            $officePropertyMeta = $namespacesMeta['meta']( $namespacesMeta['meta'] );
                                        }
                                }
                        }
                }
        }
}
}
}
foreach ( $officePropertyMeta as $propertyName => $propertyValue )
{
    $attributes = $namespacesMeta['meta']( $namespacesMeta['meta'] );
    $propertyValue = ( boolean );
case "keyword" :
    switch ( $propertyName )
    {
            trim( $propertyValue )( trim( $propertyValue ) );
            continue;
        case "initial-creator" :
            switch ( $propertyName )
            {
                    trim( $propertyValue )( trim( $propertyValue ) );
                    trim( $propertyValue )( trim( $propertyValue ) );
                    continue;
                case "creation-date" :
                    switch ( $propertyName )
                    {
                            $creationDate = strtotime( trim( $propertyValue ) );
                            $docProps->setCreated( $creationDate );
                            $docProps->setModified( $creationDate );
                            continue;
                            switch ( $propertyName )
                            {
                                case "user-defined" :
                                    $attrName = explode( ":", $attributes['name'] )[1];
                                case "publisher" :
                                    switch ( $attrName )
                                    {
                                            trim( $propertyValue )( trim( $propertyValue ) );
                                            continue;
                                        case "category" :
                                            switch ( $attrName )
                                            {
                                                    trim( $propertyValue )( trim( $propertyValue ) );
                                                    continue;
                                                    switch ( $attrName )
                                                    {
                                                        case "manager" :
                                                            trim( $propertyValue )( trim( $propertyValue ) );
                                                        }
                                                    }
                                                }
                                                else if ( isset( $gnmXML->Summary ) )
                                                {
                                            }
                                    }
                            }
                    }
            }
    }
}
foreach ( $gnmXML->Summary->Item as $summaryItem )
{
    $propertyName = $summaryItem->name;
    $propertyValue = $summaryItem->val-string;
case "title" :
    switch ( $propertyName )
    {
            trim( $propertyValue )( trim( $propertyValue ) );
            continue;
        case "comments" :
            switch ( $propertyName )
            {
                    trim( $propertyValue )( trim( $propertyValue ) );
                    continue;
                case "keywords" :
                    switch ( $propertyName )
                    {
                            trim( $propertyValue )( trim( $propertyValue ) );
                            continue;
                        case "category" :
                            switch ( $propertyName )
                            {
                                    trim( $propertyValue )( trim( $propertyValue ) );
                                    continue;
                                case "manager" :
                                    switch ( $propertyName )
                                    {
                                            trim( $propertyValue )( trim( $propertyValue ) );
                                            continue;
                                        case "author" :
                                            switch ( $propertyName )
                                            {
                                                    trim( $propertyValue )( trim( $propertyValue ) );
                                                    trim( $propertyValue )( trim( $propertyValue ) );
                                                    continue;
                                                    switch ( $propertyName )
                                                    {
                                                        case "company" :
                                                            trim( $propertyValue )( trim( $propertyValue ) );
                                                        }
                                                    }
                                                    $worksheetID = 0;
                                                    foreach ( $gnmXML->Sheets->Sheet as $sheet )
                                                    {
                                                        $worksheetName = ( boolean );
                                                        if ( isset( $this->_loadSheetsOnly ) && !in_array( $worksheetName, $this->_loadSheetsOnly ) )
                                                        {
                                                        }
                                                        else
                                                        {
                                                            $maxRow = $maxCol = 0;
                                                            $objPHPExcel->createSheet( );
                                                            $objPHPExcel->setActiveSheetIndex( $worksheetID );
                                                            $objPHPExcel->getActiveSheet( )->setTitle( $worksheetName, FALSE );
                                                            if ( !$this->_readDataOnly && isset( $sheet->PrintInformation, $sheet->PrintInformation->Margins ) )
                                                            {
                                                        }
                                                }
                                        }
                                }
                        }
                }
                foreach ( $sheet->PrintInformation->Margins->children( "gnm", TRUE ) as $key => $margin )
                {
                    $marginAttributes = $margin->attributes( );
                    $marginSize = 0.72;
                    switch ( $marginAttributes['PrefUnit'] )
                    {
                        case "mm" :
                            $marginSize = intval( $marginAttributes['Points'] ) / 100;
                    }
                case "top" :
                    switch ( $key )
                    {
                            $objPHPExcel->getActiveSheet( )->getPageMargins( )->setTop( $marginSize );
                            continue;
                        case "bottom" :
                            switch ( $key )
                            {
                                    $objPHPExcel->getActiveSheet( )->getPageMargins( )->setBottom( $marginSize );
                                    continue;
                                case "left" :
                                    switch ( $key )
                                    {
                                            $objPHPExcel->getActiveSheet( )->getPageMargins( )->setLeft( $marginSize );
                                            continue;
                                        case "right" :
                                            switch ( $key )
                                            {
                                                    $objPHPExcel->getActiveSheet( )->getPageMargins( )->setRight( $marginSize );
                                                    continue;
                                                case "header" :
                                                    switch ( $key )
                                                    {
                                                            $objPHPExcel->getActiveSheet( )->getPageMargins( )->setHeader( $marginSize );
                                                            continue;
                                                            switch ( $key )
                                                            {
                                                                case "footer" :
                                                                    $objPHPExcel->getActiveSheet( )->getPageMargins( )->setFooter( $marginSize );
                                                                }
                                                            }
                                                            foreach ( $sheet->Cells->Cell as $cell )
                                                            {
                                                                $cellAttributes = $cell->attributes( );
                                                                $row = ( integer ) + 1;
                                                                $column = ( integer );
                                                                if ( $maxRow < $row )
                                                                {
                                                                    $maxRow = $row;
                                                                }
                                                                if ( $maxCol < $column )
                                                                {
                                                                    $maxCol = $column;
                                                                }
                                                                $column = ( $column );
                                                                if ( $this->getReadFilter( ) !== NULL && !$this->getReadFilter( )->readCell( $column, $row, $worksheetName ) )
                                                                {
                                                                }
                                                                else
                                                                {
                                                                    $ValueType = $cellAttributes->ValueType;
                                                                    $ExprID = ( boolean );
                                                                    $type = PHPExcel_Cell_DataType::TYPE_FORMULA;
                                                                    if ( "" < $ExprID )
                                                                    {
                                                                        if ( "" < ( boolean ) )
                                                                        {
                                                                            $this->_expressions[$ExprID] = array( "column" => $cellAttributes->Col, "row" => $cellAttributes->Row, "formula" => ( boolean ) );
                                                                        }
                                                                        else
                                                                        {
                                                                            $expression = $this->_expressions[$ExprID];
                                                                            $cell = $cellAttributes->Row( $expression['formula'], "A1", $cellAttributes->Col - $expression['column'], $cellAttributes->Row - $expression['row'], $worksheetName );
                                                                        }
                                                                        $type = PHPExcel_Cell_DataType::TYPE_FORMULA;
                                                                    }
                                                                    else
                                                                    {
                                                                        switch ( $ValueType )
                                                                        {
                                                                            case "10" :
                                                                                $type = PHPExcel_Cell_DataType::TYPE_NULL;
                                                                            case "20" :
                                                                                $type = PHPExcel_Cell_DataType::TYPE_BOOL;
                                                                                $cell = $cell == "TRUE" ? TRUE : FALSE;
                                                                            case "30" :
                                                                                $cell = intval( $cell );
                                                                            case "40" :
                                                                                $type = PHPExcel_Cell_DataType::TYPE_NUMERIC;
                                                                            case "50" :
                                                                                $type = PHPExcel_Cell_DataType::TYPE_ERROR;
                                                                            case "60" :
                                                                                $type = PHPExcel_Cell_DataType::TYPE_STRING;
                                                                            case "70" :
                                                                            case "80" :
                                                                            default :
                                                                                ( )->getCell( $column.$row )->setValueExplicit( $cell, $type );
                                                                            }
                                                                            if ( !$this->_readDataOnly && isset( $sheet->Objects ) )
                                                                            {
                                                                                foreach ( $sheet->Objects->children( "gnm", TRUE ) as $key => $comment )
                                                                                {
                                                                                    $commentAttributes = $comment->attributes( );
                                                                                    if ( $commentAttributes->Text )
                                                                                    {
                                                                                        $commentAttributes->Author( ( boolean ) )->setText( $this->_parseRichText( ( boolean ) ) );
                                                                                    }
                                                                                }
                                                                            }
                                                                            foreach ( $sheet->Styles->StyleRegion as $styleRegion )
                                                                            {
                                                                                $styleAttributes = $styleRegion->attributes( );
                                                                                if ( !( $styleAttributes['startRow'] <= $maxRow ) || !( $styleAttributes['startCol'] <= $maxCol ) )
                                                                                {
                                                                                    $startColumn = ( ( integer ) );
                                                                                    $startRow = $styleAttributes['startRow'] + 1;
                                                                                    $endColumn = $maxCol < $styleAttributes['endCol'] ? $maxCol : ( integer );
                                                                                    $endColumn = ( $endColumn );
                                                                                    $endRow = $maxRow < $styleAttributes['endRow'] ? $maxRow : $styleAttributes['endRow'];
                                                                                    $endRow += 1;
                                                                                    $cellRange = $startColumn.$startRow.":".$endColumn.$endRow;
                                                                                    $styleAttributes = $styleRegion->Style->attributes( );
                                                                                    if ( $this->_readDataOnly && !( $styleArray['numberformat']['code'] ) )
                                                                                    {
                                                                                        $styleArray = array( );
                                                                                        $styleArray['numberformat']['code'] = ( boolean );
                                                                                        if ( $this->_readDataOnly )
                                                                                        {
                                                                                            switch ( $styleAttributes['HAlign'] )
                                                                                            {
                                                                                                case "1" :
                                                                                                    $styleArray['alignment']['horizontal'] = PHPExcel_Style_Alignment::HORIZONTAL_GENERAL;
                                                                                                    break;
                                                                                                case "2" :
                                                                                                    $styleArray['alignment']['horizontal'] = PHPExcel_Style_Alignment::HORIZONTAL_LEFT;
                                                                                                    break;
                                                                                                case "4" :
                                                                                                    $styleArray['alignment']['horizontal'] = PHPExcel_Style_Alignment::HORIZONTAL_RIGHT;
                                                                                                    break;
                                                                                                case "8" :
                                                                                                    $styleArray['alignment']['horizontal'] = PHPExcel_Style_Alignment::HORIZONTAL_CENTER;
                                                                                                    break;
                                                                                                case "16" :
                                                                                                case "64" :
                                                                                                    $styleArray['alignment']['horizontal'] = PHPExcel_Style_Alignment::HORIZONTAL_CENTER_CONTINUOUS;
                                                                                                    break;
                                                                                                case "32" :
                                                                                                    $styleArray['alignment']['horizontal'] = PHPExcel_Style_Alignment::HORIZONTAL_JUSTIFY;
                                                                                            }
                                                                                            switch ( $styleAttributes['VAlign'] )
                                                                                            {
                                                                                                case "1" :
                                                                                                    $styleArray['alignment']['vertical'] = PHPExcel_Style_Alignment::VERTICAL_TOP;
                                                                                                    break;
                                                                                                case "2" :
                                                                                                    $styleArray['alignment']['vertical'] = PHPExcel_Style_Alignment::VERTICAL_BOTTOM;
                                                                                                    break;
                                                                                                case "4" :
                                                                                                    $styleArray['alignment']['vertical'] = PHPExcel_Style_Alignment::VERTICAL_CENTER;
                                                                                                    break;
                                                                                                case "8" :
                                                                                                    $styleArray['alignment']['vertical'] = PHPExcel_Style_Alignment::VERTICAL_JUSTIFY;
                                                                                            }
                                                                                            $styleArray['alignment']['wrap'] = $styleAttributes['WrapText'] == "1" ? TRUE : FALSE;
                                                                                            $styleArray['alignment']['shrinkToFit'] = $styleAttributes['ShrinkToFit'] == "1" ? TRUE : FALSE;
                                                                                            $styleArray['alignment']['indent'] = 0 < intval( $styleAttributes['Indent'] ) ? $styleAttributes['indent'] : 0;
                                                                                            $RGB = ( $styleAttributes['Fore'] );
                                                                                            $styleArray['font']['color']['rgb'] = $RGB;
                                                                                            $RGB = ( $styleAttributes['Back'] );
                                                                                            $shade = $styleAttributes['Shade'];
                                                                                            if ( !( $RGB != "000000" ) && !( $shade != "0" ) )
                                                                                            {
                                                                                                $styleArray['fill']['color']['rgb'] = $styleArray['fill']['startcolor']['rgb'] = $RGB;
                                                                                                $RGB2 = ( $styleAttributes['PatternColor'] );
                                                                                                $styleArray['fill']['endcolor']['rgb'] = $RGB2;
                                                                                                switch ( $shade )
                                                                                                {
                                                                                                    case "1" :
                                                                                                        $styleArray['fill']['type'] = PHPExcel_Style_Fill::FILL_SOLID;
                                                                                                        break;
                                                                                                    case "2" :
                                                                                                        $styleArray['fill']['type'] = PHPExcel_Style_Fill::FILL_GRADIENT_LINEAR;
                                                                                                        break;
                                                                                                    case "3" :
                                                                                                        $styleArray['fill']['type'] = PHPExcel_Style_Fill::FILL_GRADIENT_PATH;
                                                                                                        break;
                                                                                                    case "4" :
                                                                                                        $styleArray['fill']['type'] = PHPExcel_Style_Fill::FILL_PATTERN_DARKDOWN;
                                                                                                        break;
                                                                                                    case "5" :
                                                                                                        $styleArray['fill']['type'] = PHPExcel_Style_Fill::FILL_PATTERN_DARKGRAY;
                                                                                                        break;
                                                                                                    case "6" :
                                                                                                        $styleArray['fill']['type'] = PHPExcel_Style_Fill::FILL_PATTERN_DARKGRID;
                                                                                                        break;
                                                                                                    case "7" :
                                                                                                        $styleArray['fill']['type'] = PHPExcel_Style_Fill::FILL_PATTERN_DARKHORIZONTAL;
                                                                                                        break;
                                                                                                    case "8" :
                                                                                                        $styleArray['fill']['type'] = PHPExcel_Style_Fill::FILL_PATTERN_DARKTRELLIS;
                                                                                                        break;
                                                                                                    case "9" :
                                                                                                        $styleArray['fill']['type'] = PHPExcel_Style_Fill::FILL_PATTERN_DARKUP;
                                                                                                        break;
                                                                                                    case "10" :
                                                                                                        $styleArray['fill']['type'] = PHPExcel_Style_Fill::FILL_PATTERN_DARKVERTICAL;
                                                                                                        break;
                                                                                                    case "11" :
                                                                                                        $styleArray['fill']['type'] = PHPExcel_Style_Fill::FILL_PATTERN_GRAY0625;
                                                                                                        break;
                                                                                                    case "12" :
                                                                                                        $styleArray['fill']['type'] = PHPExcel_Style_Fill::FILL_PATTERN_GRAY125;
                                                                                                        break;
                                                                                                    case "13" :
                                                                                                        $styleArray['fill']['type'] = PHPExcel_Style_Fill::FILL_PATTERN_LIGHTDOWN;
                                                                                                        break;
                                                                                                    case "14" :
                                                                                                        $styleArray['fill']['type'] = PHPExcel_Style_Fill::FILL_PATTERN_LIGHTGRAY;
                                                                                                        break;
                                                                                                    case "15" :
                                                                                                        $styleArray['fill']['type'] = PHPExcel_Style_Fill::FILL_PATTERN_LIGHTGRID;
                                                                                                        break;
                                                                                                    case "16" :
                                                                                                        $styleArray['fill']['type'] = PHPExcel_Style_Fill::FILL_PATTERN_LIGHTHORIZONTAL;
                                                                                                        break;
                                                                                                    case "17" :
                                                                                                        $styleArray['fill']['type'] = PHPExcel_Style_Fill::FILL_PATTERN_LIGHTTRELLIS;
                                                                                                        break;
                                                                                                    case "18" :
                                                                                                        $styleArray['fill']['type'] = PHPExcel_Style_Fill::FILL_PATTERN_LIGHTUP;
                                                                                                        break;
                                                                                                    case "19" :
                                                                                                        $styleArray['fill']['type'] = PHPExcel_Style_Fill::FILL_PATTERN_LIGHTVERTICAL;
                                                                                                        break;
                                                                                                    case "20" :
                                                                                                        $styleArray['fill']['type'] = PHPExcel_Style_Fill::FILL_PATTERN_MEDIUMGRAY;
                                                                                                }
                                                                                            }
                                                                                            $fontAttributes = $styleRegion->Style->Font->attributes( );
                                                                                            $styleArray['font']['name'] = ( boolean );
                                                                                            $styleArray['font']['size'] = intval( $fontAttributes['Unit'] );
                                                                                            $styleArray['font']['bold'] = $fontAttributes['Bold'] == "1" ? TRUE : FALSE;
                                                                                            $styleArray['font']['italic'] = $fontAttributes['Italic'] == "1" ? TRUE : FALSE;
                                                                                            $styleArray['font']['strike'] = $fontAttributes['StrikeThrough'] == "1" ? TRUE : FALSE;
                                                                                            switch ( $fontAttributes['Underline'] )
                                                                                            {
                                                                                                case "1" :
                                                                                                    $styleArray['font']['underline'] = PHPExcel_Style_Font::UNDERLINE_SINGLE;
                                                                                                    break;
                                                                                                case "2" :
                                                                                                    $styleArray['font']['underline'] = PHPExcel_Style_Font::UNDERLINE_DOUBLE;
                                                                                                    break;
                                                                                                case "3" :
                                                                                                    $styleArray['font']['underline'] = PHPExcel_Style_Font::UNDERLINE_SINGLEACCOUNTING;
                                                                                                    break;
                                                                                                case "4" :
                                                                                                    $styleArray['font']['underline'] = PHPExcel_Style_Font::UNDERLINE_DOUBLEACCOUNTING;
                                                                                                    break;
                                                                                                default :
                                                                                                    $styleArray['font']['underline'] = PHPExcel_Style_Font::UNDERLINE_NONE;
                                                                                            }
                                                                                            switch ( $fontAttributes['Script'] )
                                                                                            {
                                                                                                case "1" :
                                                                                                    $styleArray['font']['superScript'] = TRUE;
                                                                                                    break;
                                                                                                case "-1" :
                                                                                                    $styleArray['font']['subScript'] = TRUE;
                                                                                            }
                                                                                            if ( $fontAttributes['StrikeThrough'] == "1" ? TRUE : FALSE )
                                                                                            {
                                                                                                if ( isset( $styleRegion->Style->StyleBorder, $styleRegion->Style->StyleBorder->Top ) )
                                                                                                {
                                                                                                    $styleArray['borders']['top'] = ( $styleRegion->Style->StyleBorder->Top->attributes( ) );
                                                                                                }
                                                                                                if ( isset( $styleRegion->Style->StyleBorder->Bottom ) )
                                                                                                {
                                                                                                    $styleArray['borders']['bottom'] = ( $styleRegion->Style->StyleBorder->Bottom->attributes( ) );
                                                                                                }
                                                                                                if ( isset( $styleRegion->Style->StyleBorder->Left ) )
                                                                                                {
                                                                                                    $styleArray['borders']['left'] = ( $styleRegion->Style->StyleBorder->Left->attributes( ) );
                                                                                                }
                                                                                                if ( isset( $styleRegion->Style->StyleBorder->Right ) )
                                                                                                {
                                                                                                    $styleArray['borders']['right'] = ( $styleRegion->Style->StyleBorder->Right->attributes( ) );
                                                                                                }
                                                                                                if ( isset( $styleRegion->Style->StyleBorder->Diagonal, $styleRegion->Style->StyleBorder->Rev-Diagonal ) )
                                                                                                {
                                                                                                    $styleArray['borders']['diagonal'] = ( $styleRegion->Style->StyleBorder->Diagonal->attributes( ) );
                                                                                                    $styleArray['borders']['diagonaldirection'] = PHPExcel_Style_Borders::DIAGONAL_BOTH;
                                                                                                }
                                                                                                else if ( isset( $styleRegion->Style->StyleBorder->Diagonal ) )
                                                                                                {
                                                                                                    $styleArray['borders']['diagonal'] = ( $styleRegion->Style->StyleBorder->Diagonal->attributes( ) );
                                                                                                    $styleArray['borders']['diagonaldirection'] = PHPExcel_Style_Borders::DIAGONAL_UP;
                                                                                                }
                                                                                                else if ( isset( $styleRegion->Style->StyleBorder->Rev-Diagonal ) )
                                                                                                {
                                                                                                    $styleArray['borders']['diagonal'] = ( $styleRegion->Style->StyleBorder->Rev-Diagonal->attributes( ) );
                                                                                                    $styleArray['borders']['diagonaldirection'] = PHPExcel_Style_Borders::DIAGONAL_DOWN;
                                                                                                }
                                                                                            }
                                                                                            if ( isset( $styleRegion->Style->HyperLink ) )
                                                                                            {
                                                                                                $hyperlink = $styleRegion->Style->HyperLink->attributes( );
                                                                                            }
                                                                                        }
                                                                                        $objPHPExcel->getActiveSheet( )->getStyle( $cellRange )->applyFromArray( $styleArray );
                                                                                    }
                                                                                }
                                                                            }
                                                                            if ( $this->_readDataOnly || !isset( $sheet->Cols ) )
                                                                            {
                                                                                $columnAttributes = $sheet->Cols->attributes( );
                                                                                $defaultWidth = $columnAttributes['DefaultSizePts'] / 5.4;
                                                                                $c = 0;
                                                                                foreach ( $sheet->Cols->ColInfo as $columnOverride )
                                                                                {
                                                                                    $columnAttributes = $columnOverride->attributes( );
                                                                                    $column = $columnAttributes['No'];
                                                                                    $columnWidth = $columnAttributes['Unit'] / 5.4;
                                                                                    $hidden = isset( $columnAttributes['Hidden'] ) && $columnAttributes['Hidden'] == "1" ? TRUE : FALSE;
                                                                                    $columnCount = isset( $columnAttributes['Count'] ) ? $columnAttributes['Count'] : 1;
                                                                                    while ( $c < $column )
                                                                                    {
                                                                                        $objPHPExcel->getActiveSheet( )->getColumnDimension( ( $c ) )->setWidth( $defaultWidth );
                                                                                        ++$c;
                                                                                    }
                                                                                    do
                                                                                    {
                                                                                        if ( !( $c < $column + $columnCount ) || !( $c <= $maxCol ) )
                                                                                        {
                                                                                            $objPHPExcel->getActiveSheet( )->getColumnDimension( ( $c ) )->setWidth( $columnWidth );
                                                                                            if ( $hidden )
                                                                                            {
                                                                                                $objPHPExcel->getActiveSheet( )->getColumnDimension( ( $c ) )->setVisible( FALSE );
                                                                                            }
                                                                                            ++$c;
                                                                                            break;
                                                                                        }
                                                                                    } while ( 1 );
                                                                                }
                                                                                while ( $c <= $maxCol )
                                                                                {
                                                                                    $objPHPExcel->getActiveSheet( )->getColumnDimension( ( $c ) )->setWidth( $defaultWidth );
                                                                                    ++$c;
                                                                                }
                                                                            }
                                                                            if ( $this->_readDataOnly || !isset( $sheet->Rows ) )
                                                                            {
                                                                                $rowAttributes = $sheet->Rows->attributes( );
                                                                                $defaultHeight = $rowAttributes['DefaultSizePts'];
                                                                                $r = 0;
                                                                                foreach ( $sheet->Rows->RowInfo as $rowOverride )
                                                                                {
                                                                                    $rowAttributes = $rowOverride->attributes( );
                                                                                    $row = $rowAttributes['No'];
                                                                                    $rowHeight = $rowAttributes['Unit'];
                                                                                    $hidden = isset( $rowAttributes['Hidden'] ) && $rowAttributes['Hidden'] == "1" ? TRUE : FALSE;
                                                                                    $rowCount = isset( $rowAttributes['Count'] ) ? $rowAttributes['Count'] : 1;
                                                                                    while ( $r < $row )
                                                                                    {
                                                                                        ++$r;
                                                                                        $objPHPExcel->getActiveSheet( )->getRowDimension( $r )->setRowHeight( $defaultHeight );
                                                                                    }
                                                                                    do
                                                                                    {
                                                                                        if ( !( $r < $row + $rowCount ) || !( $r < $maxRow ) )
                                                                                        {
                                                                                            ++$r;
                                                                                            $objPHPExcel->getActiveSheet( )->getRowDimension( $r )->setRowHeight( $rowHeight );
                                                                                            if ( $hidden )
                                                                                            {
                                                                                                $objPHPExcel->getActiveSheet( )->getRowDimension( $r )->setVisible( FALSE );
                                                                                            }
                                                                                        }
                                                                                    } while ( 1 );
                                                                                    break;
                                                                                }
                                                                                while ( $r < $maxRow )
                                                                                {
                                                                                    ++$r;
                                                                                    $objPHPExcel->getActiveSheet( )->getRowDimension( $r )->setRowHeight( $defaultHeight );
                                                                                }
                                                                            }
                                                                            if ( isset( $sheet->MergedRegions ) )
                                                                            {
                                                                                foreach ( $sheet->MergedRegions->Merge as $mergeCells )
                                                                                {
                                                                                    if ( strpos( $mergeCells, ":" ) !== FALSE )
                                                                                    {
                                                                                        $objPHPExcel->getActiveSheet( )->mergeCells( $mergeCells );
                                                                                    }
                                                                                }
                                                                            }
                                                                            ++$worksheetID;
                                                                        }
                                                                        if ( isset( $gnmXML->Names ) )
                                                                        {
                                                                            foreach ( $gnmXML->Names->Name as $namedRange )
                                                                            {
                                                                                $name = ( boolean );
                                                                                $range = ( boolean );
                                                                                if ( stripos( $range, "#REF!" ) !== FALSE )
                                                                                {
                                                                                    $range = explode( "!", $range );
                                                                                    $range[0] = trim( $range[0], "'" );
                                                                                    if ( $worksheet = $range[0]( $range[0] ) )
                                                                                    {
                                                                                        $extractedRange = str_replace( "\$", "", $range[1] );
                                                                                        new PHPExcel_NamedRange( $name, $worksheet, $extractedRange )( new PHPExcel_NamedRange( $name, $worksheet, $extractedRange ) );
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                        return $objPHPExcel;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }

    private static function _parseBorderAttributes( $borderAttributes )
    {
        $styleArray = array( );
        if ( isset( $borderAttributes['Color'] ) )
        {
            $RGB = ( $borderAttributes['Color'] );
            $styleArray['color']['rgb'] = $RGB;
        }
        switch ( $borderAttributes['Style'] )
        {
            case "0" :
                $styleArray['style'] = PHPExcel_Style_Border::BORDER_NONE;
                break;
            case "1" :
                $styleArray['style'] = PHPExcel_Style_Border::BORDER_THIN;
                break;
            case "2" :
                $styleArray['style'] = PHPExcel_Style_Border::BORDER_MEDIUM;
                break;
            case "4" :
                $styleArray['style'] = PHPExcel_Style_Border::BORDER_DASHED;
                break;
            case "5" :
                $styleArray['style'] = PHPExcel_Style_Border::BORDER_THICK;
                break;
            case "6" :
                $styleArray['style'] = PHPExcel_Style_Border::BORDER_DOUBLE;
                break;
            case "7" :
                $styleArray['style'] = PHPExcel_Style_Border::BORDER_DOTTED;
                break;
            case "9" :
                $styleArray['style'] = PHPExcel_Style_Border::BORDER_DASHDOT;
                break;
            case "10" :
                $styleArray['style'] = PHPExcel_Style_Border::BORDER_MEDIUMDASHDOT;
                break;
            case "11" :
                $styleArray['style'] = PHPExcel_Style_Border::BORDER_DASHDOTDOT;
                break;
            case "12" :
                $styleArray['style'] = PHPExcel_Style_Border::BORDER_MEDIUMDASHDOTDOT;
                break;
            case "13" :
                $styleArray['style'] = PHPExcel_Style_Border::BORDER_MEDIUMDASHDOTDOT;
                break;
            case "3" :
                $styleArray['style'] = PHPExcel_Style_Border::BORDER_SLANTDASHDOT;
                break;
            case "8" :
                $styleArray['style'] = PHPExcel_Style_Border::BORDER_MEDIUMDASHED;
        }
        return $styleArray;
    }

    private function _parseRichText( $is = "" )
    {
        $value = new PHPExcel_RichText( );
        $value->createText( $is );
        return $value;
    }

    private static function _parseGnumericColour( $gnmColour )
    {
        list( $gnmR, $gnmG, $gnmB ) = explode( ":", $gnmColour );
        $gnmR = substr( str_pad( $gnmR, 4, "0", STR_PAD_RIGHT ), 0, 2 );
        $gnmG = substr( str_pad( $gnmG, 4, "0", STR_PAD_RIGHT ), 0, 2 );
        $gnmB = substr( str_pad( $gnmB, 4, "0", STR_PAD_RIGHT ), 0, 2 );
        $RGB = $gnmR.$gnmG.$gnmB;
        return $RGB;
    }

}

?>
