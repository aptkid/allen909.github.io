<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
if ( defined( "PHPEXCEL_ROOT" ) )
{
    define( "PHPEXCEL_ROOT", dirname( __FILE__ )."/../../" );
    require( PHPEXCEL_ROOT."PHPExcel/Autoloader.php" );
}
class PHPExcel_Reader_Excel2007 extends PHPExcel_Reader_IReader implements PHPExcel_Reader_IReader
{

    private $_referenceHelper;
    private static $_theme;

    public function __construct( )
    {
        $this->_readFilter = new PHPExcel_Reader_DefaultReadFilter( );
        $this->_referenceHelper = ( );
    }

    public function canRead( $pFilename )
    {
        if ( file_exists( $pFilename ) )
        {
            throw new PHPExcel_Reader_Exception( "Could not open ".$pFilename." for reading! File does not exist." );
        }
        if ( class_exists( "ZipArchive", FALSE ) )
        {
            throw new PHPExcel_Reader_Exception( "ZipArchive library is not enabled" );
        }
        $xl = FALSE;
        $zip = new ZipArchive( );
        if ( $zip->open( $pFilename ) === TRUE )
        {
            $rels = simplexml_load_string( $this->_getFromZipArchive( $zip, "_rels/.rels" ) );
            if ( $rels !== FALSE )
            {
                foreach ( $rels->Relationship as $rel )
                {
                    switch ( $rel['Type'] )
                    {
                        case "http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" :
                            if ( basename( $rel['Target'] ) == "workbook.xml" )
                            {
                                $xl = TRUE;
                            }
                    }
                }
            }
            $zip->close( );
        }
        return $xl;
    }

    public function listWorksheetNames( $pFilename )
    {
        if ( file_exists( $pFilename ) )
        {
            throw new PHPExcel_Reader_Exception( "Could not open ".$pFilename." for reading! File does not exist." );
        }
        $worksheetNames = array( );
        $zip = new ZipArchive( );
        $zip->open( $pFilename );
        $rels = simplexml_load_string( $this->_getFromZipArchive( $zip, "_rels/.rels" ) );
        foreach ( $rels->Relationship as $rel )
        {
            switch ( $rel['Type'] )
            {
                case "http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" :
                    $xmlWorkbook = simplexml_load_string( $this->_getFromZipArchive( $zip, "{$rel['Target']}" ) );
                    if ( $xmlWorkbook->sheets )
                    {
                        foreach ( $xmlWorkbook->sheets->sheet as $eleSheet )
                        {
                            $worksheetNames[] = ( boolean );
                        }
                    }
            }
        }
        $zip->close( );
        return $worksheetNames;
    }

    public function listWorksheetInfo( $pFilename )
    {
        if ( file_exists( $pFilename ) )
        {
            throw new PHPExcel_Reader_Exception( "Could not open ".$pFilename." for reading! File does not exist." );
        }
        $worksheetInfo = array( );
        $zip = new ZipArchive( );
        $zip->open( $pFilename );
        $rels = simplexml_load_string( $this->_getFromZipArchive( $zip, "_rels/.rels" ) );
        foreach ( $rels->Relationship as $rel )
        {
            if ( $rel['Type'] == "http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" )
            {
                $dir = dirname( $rel['Target'] );
                $relsWorkbook = simplexml_load_string( $this->_getFromZipArchive( $zip, "{$dir}/_rels/".basename( $rel['Target'] ).".rels" ) );
                $relsWorkbook->registerXPathNamespace( "rel", "http://schemas.openxmlformats.org/package/2006/relationships" );
                $worksheets = array( );
                foreach ( $relsWorkbook->Relationship as $ele )
                {
                    if ( $ele['Type'] == "http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" )
                    {
                        $worksheets[( boolean )] = $ele['Target'];
                    }
                }
                $xmlWorkbook = simplexml_load_string( $this->_getFromZipArchive( $zip, "{$rel['Target']}" ) );
                if ( $xmlWorkbook->sheets )
                {
                    $dir = dirname( $rel['Target'] );
                    foreach ( $xmlWorkbook->sheets->sheet as $eleSheet )
                    {
                        $tmpInfo = array( "worksheetName" => ( boolean ), "lastColumnLetter" => "A", "lastColumnIndex" => 0, "totalRows" => 0, "totalColumns" => 0 );
                        $fileWorksheet = $worksheets[( boolean )];
                        $xml = new XMLReader( );
                        $res = $xml->open( "zip://".( $pFilename )."#"."{$dir}/{$fileWorksheet}" );
                        $xml->setParserProperty( 2, TRUE );
                        $currCells = 0;
                        while ( $xml->read( ) )
                        {
                            if ( $xml->name == "row" && $xml->nodeType == XMLReader::ELEMENT )
                            {
                                $row = $xml->getAttribute( "r" );
                                $tmpInfo['totalRows'] = $row;
                                $tmpInfo['totalColumns'] = max( $tmpInfo['totalColumns'], $currCells );
                                $currCells = 0;
                            }
                            else if ( !( $xml->name == "c" ) || !( $xml->nodeType == XMLReader::ELEMENT ) )
                            {
                                ++$currCells;
                            }
                        }
                        $tmpInfo['totalColumns'] = max( $tmpInfo['totalColumns'], $currCells );
                        $xml->close( );
                        $tmpInfo['lastColumnIndex'] = $tmpInfo['totalColumns'] - 1;
                        $tmpInfo['lastColumnLetter'] = ( $tmpInfo['lastColumnIndex'] );
                        $worksheetInfo[] = $tmpInfo;
                    }
                }
            }
        }
        $zip->close( );
        return $worksheetInfo;
    }

    private static function _castToBool( $c )
    {
        $value = isset( $c->v ) ? ( boolean ) : NULL;
        if ( $value == "0" )
        {
            return FALSE;
        }
        if ( $value == "1" )
        {
            return TRUE;
        }
        return $c->v;
    }

    private static function _castToError( $c )
    {
        if ( isset( $c->v ) )
        {
            return ( boolean );
        }
    }

    private static function _castToString( $c )
    {
        if ( isset( $c->v ) )
        {
            return ( boolean );
        }
    }

    private function _castToFormula( $c, $r, &$cellDataType, &$value, &$calculatedValue, &$sharedFormulas, $castBaseType )
    {
        $cellDataType = "f";
        $value = "=".$c->f;
        $calculatedValue = ( $c );
        if ( isset( $c->f['t'] ) && strtolower( ( boolean ) ) == "shared" )
        {
            $instance = ( boolean );
            if ( isset( $sharedFormulas[( boolean )] ) )
            {
                $sharedFormulas[$instance] = array( "master" => $r, "formula" => $value );
            }
            else
            {
                $master = ( $sharedFormulas[$instance]['master'] );
                $current = ( $r );
                $difference = array( 0, 0 );
                $difference[0] = ( $current[0] ) - ( $master[0] );
                $difference[1] = $current[1] - $master[1];
                $value = $sharedFormulas[$instance]( $sharedFormulas[$instance]['formula'], "A1", $difference[0], $difference[1] );
            }
        }
    }

    public function _getFromZipArchive( $archive, $fileName = "" )
    {
        if ( strpos( $fileName, "//" ) !== FALSE )
        {
            $fileName = substr( $fileName, strpos( $fileName, "//" ) + 1 );
        }
        $fileName = ( $fileName );
        $contents = $archive->getFromName( $fileName );
        if ( $contents === FALSE )
        {
            $contents = substr( $fileName, 1 )( substr( $fileName, 1 ) );
        }
        return $contents;
    }

    public function load( $pFilename )
    {
        if ( file_exists( $pFilename ) )
        {
            throw new PHPExcel_Reader_Exception( "Could not open ".$pFilename." for reading! File does not exist." );
        }
        $excel = new PHPExcel( );
        $excel->removeSheetByIndex( 0 );
        if ( $this->_readDataOnly )
        {
            $excel->removeCellStyleXfByIndex( 0 );
            $excel->removeCellXfByIndex( 0 );
        }
        $zip = new ZipArchive( );
        $zip->open( $pFilename );
        $wbRels = simplexml_load_string( $this->_getFromZipArchive( $zip, "xl/_rels/workbook.xml.rels" ) );
        foreach ( $wbRels->Relationship as $rel )
        {
            switch ( $rel['Type'] )
            {
                case "http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme" :
                    $themeOrderArray = array( "lt1", "dk1", "lt2", "dk2" );
                    $themeOrderAdditional = count( $themeOrderArray );
                    $xmlTheme = simplexml_load_string( $this->_getFromZipArchive( $zip, "xl/".$rel['Target'] ) );
                    if ( is_object( $xmlTheme ) )
                    {
                        $xmlThemeName = $xmlTheme->attributes( );
                        $xmlTheme = $xmlTheme->children( "http://schemas.openxmlformats.org/drawingml/2006/main" );
                        $themeName = ( boolean );
                        $colourScheme = $xmlTheme->themeElements->clrScheme->attributes( );
                        $colourSchemeName = ( boolean );
                        $colourScheme = $xmlTheme->themeElements->clrScheme->children( "http://schemas.openxmlformats.org/drawingml/2006/main" );
                        $themeColours = array( );
                        foreach ( $colourScheme as $k => $xmlColour )
                        {
                            $themePos = array_search( $k, $themeOrderArray );
                            if ( $themePos === FALSE )
                            {
                                $themePos = $themeOrderAdditional++;
                            }
                            if ( isset( $xmlColour->sysClr ) )
                            {
                                $xmlColourData = $xmlColour->sysClr->attributes( );
                                $themeColours[$themePos] = $xmlColourData['lastClr'];
                            }
                            else if ( isset( $xmlColour->srgbClr ) )
                            {
                                $xmlColourData = $xmlColour->srgbClr->attributes( );
                                $themeColours[$themePos] = $xmlColourData['val'];
                            }
                        }
                        self::$_theme = new PHPExcel_Reader_Excel2007_Theme( $themeName, $colourSchemeName, $themeColours );
                    }
            }
        }
        $rels = simplexml_load_string( $this->_getFromZipArchive( $zip, "_rels/.rels" ) );
        foreach ( $rels->Relationship as $rel )
        {
            switch ( $rel['Type'] )
            {
                case "http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" :
                    $xmlCore = simplexml_load_string( $this->_getFromZipArchive( $zip, "{$rel['Target']}" ) );
                    if ( is_object( $xmlCore ) )
                    {
                        $xmlCore->registerXPathNamespace( "dc", "http://purl.org/dc/elements/1.1/" );
                        $xmlCore->registerXPathNamespace( "dcterms", "http://purl.org/dc/terms/" );
                        $xmlCore->registerXPathNamespace( "cp", "http://schemas.openxmlformats.org/package/2006/metadata/core-properties" );
                        $docProps = $excel->getProperties( );
                        ( $xmlCore->xpath( "dc:creator" ) )( ( boolean ) );
                        ( $xmlCore->xpath( "cp:lastModifiedBy" ) )( ( boolean ) );
                        $docProps->setCreated( strtotime( ( $xmlCore->xpath( "dcterms:created" ) ) ) );
                        $docProps->setModified( strtotime( ( $xmlCore->xpath( "dcterms:modified" ) ) ) );
                        ( $xmlCore->xpath( "dc:title" ) )( ( boolean ) );
                        ( $xmlCore->xpath( "dc:description" ) )( ( boolean ) );
                        ( $xmlCore->xpath( "dc:subject" ) )( ( boolean ) );
                        ( $xmlCore->xpath( "cp:keywords" ) )( ( boolean ) );
                        ( $xmlCore->xpath( "cp:category" ) )( ( boolean ) );
                        break;
                    }
                case "http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" :
                    $xmlCore = simplexml_load_string( $this->_getFromZipArchive( $zip, "{$rel['Target']}" ) );
                    if ( is_object( $xmlCore ) )
                    {
                        $docProps = $excel->getProperties( );
                        if ( isset( $xmlCore->Company ) )
                        {
                            $docProps->setCompany( ( boolean ) );
                        }
                        if ( isset( $xmlCore->Manager ) )
                        {
                            $docProps->setManager( ( boolean ) );
                            break;
                        }
                    }
                case "http://schemas.openxmlformats.org/officeDocument/2006/relationships/custom-properties" :
                    $xmlCore = simplexml_load_string( $this->_getFromZipArchive( $zip, "{$rel['Target']}" ) );
                    if ( is_object( $xmlCore ) )
                    {
                        $docProps = $excel->getProperties( );
                        foreach ( $xmlCore as $xmlProperty )
                        {
                            $cellDataOfficeAttributes = $xmlProperty->attributes( );
                            if ( isset( $cellDataOfficeAttributes['name'] ) )
                            {
                                $propertyName = ( boolean );
                                $cellDataOfficeChildren = $xmlProperty->children( "http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes" );
                                $attributeType = $cellDataOfficeChildren->getName( );
                                $attributeValue = ( boolean );
                                $attributeValue = ( $attributeValue, $attributeType );
                                $attributeType = ( $attributeType );
                                $docProps->setCustomProperty( $propertyName, $attributeValue, $attributeType );
                            }
                        }
                        break;
                    }
                case "http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" :
                    $dir = dirname( $rel['Target'] );
                    $relsWorkbook = simplexml_load_string( $this->_getFromZipArchive( $zip, "{$dir}/_rels/".basename( $rel['Target'] ).".rels" ) );
                    $relsWorkbook->registerXPathNamespace( "rel", "http://schemas.openxmlformats.org/package/2006/relationships" );
                    $sharedStrings = array( );
                    $xpath = ( $relsWorkbook->xpath( "rel:Relationship[@Type='http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings']" ) );
                    $xmlStrings = simplexml_load_string( $this->_getFromZipArchive( $zip, "{$dir}/{$xpath['Target']}" ) );
                    if ( isset( $xmlStrings ) && isset( $xmlStrings->si ) )
                    {
                        foreach ( $xmlStrings->si as $val )
                        {
                            if ( isset( $val->t ) )
                            {
                                $sharedStrings[] = ( ( boolean ) );
                            }
                            else if ( isset( $val->r ) )
                            {
                                $sharedStrings[] = $this->_parseRichText( $val );
                            }
                        }
                    }
                    $worksheets = array( );
                    foreach ( $relsWorkbook->Relationship as $ele )
                    {
                        if ( $ele['Type'] == "http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" )
                        {
                            $worksheets[( boolean )] = $ele['Target'];
                        }
                    }
                    $styles = array( );
                    $cellStyles = array( );
                    $xpath = ( $relsWorkbook->xpath( "rel:Relationship[@Type='http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles']" ) );
                    $xmlStyles = simplexml_load_string( $this->_getFromZipArchive( $zip, "{$dir}/{$xpath['Target']}" ) );
                    $numFmts = NULL;
                    if ( $xmlStyles && $xmlStyles->numFmts[0] )
                    {
                        $numFmts = $xmlStyles->numFmts[0];
                    }
                    if ( isset( $numFmts ) && $numFmts !== NULL )
                    {
                        $numFmts->registerXPathNamespace( "sml", "http://schemas.openxmlformats.org/spreadsheetml/2006/main" );
                    }
                    if ( !$this->_readDataOnly && $xmlStyles )
                    {
                        foreach ( $xmlStyles->cellXfs->xf as $xf )
                        {
                            $numFmt = PHPExcel_Style_NumberFormat::FORMAT_GENERAL;
                            if ( $xf['numFmtId'] )
                            {
                                if ( isset( $numFmts ) )
                                {
                                    $tmpNumFmt = ( $numFmts->xpath( "sml:numFmt[@numFmtId=".$xf['numFmtId']."]" ) );
                                    if ( isset( $tmpNumFmt['formatCode'] ) )
                                    {
                                        $numFmt = ( boolean );
                                    }
                                }
                                if ( ( integer ) < 164 )
                                {
                                    $numFmt = ( ( integer ) );
                                }
                            }
                            $style = ( object );
                            $styles[] = $style;
                            $objStyle = new PHPExcel_Style( );
                            ( $objStyle, $style );
                            $excel->addCellXf( $objStyle );
                        }
                        foreach ( $xmlStyles->cellStyleXfs->xf as $xf )
                        {
                            $numFmt = PHPExcel_Style_NumberFormat::FORMAT_GENERAL;
                            if ( $numFmts && $xf['numFmtId'] )
                            {
                                $tmpNumFmt = ( $numFmts->xpath( "sml:numFmt[@numFmtId=".$xf['numFmtId']."]" ) );
                                if ( isset( $tmpNumFmt['formatCode'] ) )
                                {
                                    $numFmt = ( boolean );
                                }
                                else if ( ( integer ) < 165 )
                                {
                                    $numFmt = ( ( integer ) );
                                }
                            }
                            $cellStyle = ( object );
                            $cellStyles[] = $cellStyle;
                            $objStyle = new PHPExcel_Style( );
                            ( $objStyle, $cellStyle );
                            $excel->addCellStyleXf( $objStyle );
                        }
                    }
                    $dxfs = array( );
                    if ( !$this->_readDataOnly && $xmlStyles )
                    {
                        if ( $xmlStyles->dxfs )
                        {
                            foreach ( $xmlStyles->dxfs->dxf as $dxf )
                            {
                                $style = new PHPExcel_Style( FALSE, TRUE );
                                ( $style, $dxf );
                                $dxfs[] = $style;
                            }
                        }
                        if ( $xmlStyles->cellStyles )
                        {
                            foreach ( $xmlStyles->cellStyles->cellStyle as $cellStyle )
                            {
                                if ( !( intval( $cellStyle['builtinId'] ) == 0 ) || !isset( $cellStyles[intval( $cellStyle['xfId'] )] ) )
                                {
                                    $style = new PHPExcel_Style( );
                                    ( $style, $cellStyles[intval( $cellStyle['xfId'] )] );
                                }
                            }
                        }
                    }
                    $xmlWorkbook = simplexml_load_string( $this->_getFromZipArchive( $zip, "{$rel['Target']}" ) );
                    if ( $xmlWorkbook->workbookPr )
                    {
                        ( PHPExcel_Shared_Date::CALENDAR_WINDOWS_1900 );
                        if ( isset( $xmlWorkbook->workbookPr['date1904'] ) )
                        {
                            if ( ( ( boolean ) ) )
                            {
                                ( PHPExcel_Shared_Date::CALENDAR_MAC_1904 );
                            }
                        }
                    }
                    $sheetId = 0;
                    $oldSheetId = -1;
                    $countSkippedSheets = 0;
                    $mapSheetId = array( );
                    $charts = $chartDetails = array( );
                    if ( $xmlWorkbook->sheets )
                    {
                        foreach ( $xmlWorkbook->sheets->sheet as $eleSheet )
                        {
                            ++$oldSheetId;
                            if ( isset( $this->_loadSheetsOnly ) && !in_array( ( boolean ), $this->_loadSheetsOnly ) )
                            {
                                ++$countSkippedSheets;
                                $mapSheetId[$oldSheetId] = NULL;
                            }
                            else
                            {
                                $mapSheetId[$oldSheetId] = $oldSheetId - $countSkippedSheets;
                                $docSheet = $excel->createSheet( );
                                $docSheet->setTitle( ( boolean ), FALSE );
                                $fileWorksheet = $worksheets[( boolean )];
                                $xmlSheet = simplexml_load_string( $this->_getFromZipArchive( $zip, "{$dir}/{$fileWorksheet}" ) );
                                $sharedFormulas = array( );
                                if ( isset( $eleSheet['state'] ) && ( boolean ) != "" )
                                {
                                    $docSheet->setSheetState( ( boolean ) );
                                }
                                if ( isset( $xmlSheet->sheetViews, $xmlSheet->sheetViews->sheetView ) )
                                {
                                    if ( isset( $xmlSheet->sheetViews->sheetView['zoomScale'] ) )
                                    {
                                        $xmlSheet->sheetViews->sheetView( intval( $xmlSheet->sheetViews->sheetView['zoomScale'] ) );
                                    }
                                    if ( isset( $xmlSheet->sheetViews->sheetView['zoomScaleNormal'] ) )
                                    {
                                        $xmlSheet->sheetViews->sheetView( intval( $xmlSheet->sheetViews->sheetView['zoomScaleNormal'] ) );
                                    }
                                    if ( isset( $xmlSheet->sheetViews->sheetView['view'] ) )
                                    {
                                        $xmlSheet->sheetViews->sheetView['view']( ( boolean ) );
                                    }
                                    if ( isset( $xmlSheet->sheetViews->sheetView['showGridLines'] ) )
                                    {
                                        ( ( boolean ) )( ( ( boolean ) ) );
                                    }
                                    if ( isset( $xmlSheet->sheetViews->sheetView['showRowColHeaders'] ) )
                                    {
                                        ( ( boolean ) )( ( ( boolean ) ) );
                                    }
                                    if ( isset( $xmlSheet->sheetViews->sheetView['rightToLeft'] ) )
                                    {
                                        ( ( boolean ) )( ( ( boolean ) ) );
                                    }
                                    if ( isset( $xmlSheet->sheetViews->sheetView->pane ) )
                                    {
                                        if ( isset( $xmlSheet->sheetViews->sheetView->pane['topLeftCell'] ) )
                                        {
                                            $xmlSheet->sheetViews->sheetView->pane( ( boolean ) );
                                        }
                                        else
                                        {
                                            $xSplit = 0;
                                            $ySplit = 0;
                                            if ( isset( $xmlSheet->sheetViews->sheetView->pane['xSplit'] ) )
                                            {
                                                $xSplit = 1 + intval( $xmlSheet->sheetViews->sheetView->pane['xSplit'] );
                                            }
                                            if ( isset( $xmlSheet->sheetViews->sheetView->pane['ySplit'] ) )
                                            {
                                                $ySplit = 1 + intval( $xmlSheet->sheetViews->sheetView->pane['ySplit'] );
                                            }
                                            $docSheet->freezePaneByColumnAndRow( $xSplit, $ySplit );
                                        }
                                    }
                                    if ( isset( $xmlSheet->sheetViews->sheetView->selection ) && isset( $xmlSheet->sheetViews->sheetView->selection['sqref'] ) )
                                    {
                                        $sqref = ( boolean );
                                        $sqref = explode( " ", $sqref );
                                        $sqref = $sqref[0];
                                        $docSheet->setSelectedCells( $sqref );
                                    }
                                }
                                if ( isset( $xmlSheet->sheetPr->tabColor['rgb'] ) )
                                {
                                    $xmlSheet->sheetPr->tabColor['rgb']( ( boolean ) );
                                }
                                if ( isset( $xmlSheet->sheetPr, $xmlSheet->sheetPr->outlinePr ) )
                                {
                                    if ( isset( $xmlSheet->sheetPr->outlinePr['summaryRight'] ) )
                                    {
                                        if ( ( ( boolean ) ) )
                                        {
                                            $docSheet->setShowSummaryRight( FALSE );
                                        }
                                    }
                                    else
                                    {
                                        $docSheet->setShowSummaryRight( TRUE );
                                    }
                                    if ( isset( $xmlSheet->sheetPr->outlinePr['summaryBelow'] ) )
                                    {
                                        if ( ( ( boolean ) ) )
                                        {
                                            $docSheet->setShowSummaryBelow( FALSE );
                                        }
                                    }
                                    else
                                    {
                                        $docSheet->setShowSummaryBelow( TRUE );
                                    }
                                }
                                if ( isset( $xmlSheet->sheetPr, $xmlSheet->sheetPr->pageSetUpPr ) )
                                {
                                    if ( isset( $xmlSheet->sheetPr->pageSetUpPr['fitToPage'] ) )
                                    {
                                        if ( ( ( boolean ) ) )
                                        {
                                            $docSheet->getPageSetup( )->setFitToPage( FALSE );
                                        }
                                    }
                                    else
                                    {
                                        $docSheet->getPageSetup( )->setFitToPage( TRUE );
                                    }
                                }
                                if ( isset( $xmlSheet->sheetFormatPr ) )
                                {
                                    if ( isset( $xmlSheet->sheetFormatPr['customHeight'] ) )
                                    {
                                        if ( ( ( boolean ) ) && isset( $xmlSheet->sheetFormatPr['defaultRowHeight'] ) )
                                        {
                                            $xmlSheet->sheetFormatPr['defaultRowHeight']( ( double ) );
                                        }
                                    }
                                    if ( isset( $xmlSheet->sheetFormatPr['defaultColWidth'] ) )
                                    {
                                        $xmlSheet->sheetFormatPr['defaultColWidth']( ( double ) );
                                    }
                                    if ( isset( $xmlSheet->sheetFormatPr['zeroHeight'] ) && ( boolean ) == "1" )
                                    {
                                        $docSheet->getDefaultRowDimension( )->setzeroHeight( TRUE );
                                    }
                                }
                                if ( isset( $xmlSheet->cols ) && !$this->_readDataOnly )
                                {
                                    foreach ( $docSheet->getDefaultRowDimension( )->setzeroHeight as $col )
                                    {
                                        $i = intval( $col['min'] ) - 1;
                                        for ( ; $i < intval( $col['max'] ); if ( $i )
 break;
 do
 {
 ++$i )
                                            {
                                                if ( $col['style'] && !$this->_readDataOnly )
                                                {
                                                    ( $i )( ( $i ) )->setXfIndex( intval( $col['style'] ) );
                                                }
                                                ( $col['bestFit'] );
                                                if ( ( $col['hidden'] ) )
                                                {
                                                    ( $i )( ( $i ) )->setVisible( FALSE );
                                                }
                                                if ( ( $col['collapsed'] ) )
                                                {
                                                    ( $i )( ( $i ) )->setCollapsed( TRUE );
                                                }
                                                if ( 0 < $col['outlineLevel'] )
                                                {
                                                    ( $i )( ( $i ) )->setOutlineLevel( intval( $col['outlineLevel'] ) );
                                                }
                                                ( $i )( ( $i ) )->setWidth( floatval( $col['width'] ) );
                                            } while ( 1 );
                                            break;
                                        }
                                    }
                                }
                                if ( isset( $xmlSheet->printOptions ) && !$this->_readDataOnly )
                                {
                                    if ( ( ( boolean ) ) )
                                    {
                                        $docSheet->setShowGridlines( TRUE );
                                    }
                                    if ( ( ( boolean ) ) )
                                    {
                                        $docSheet->setPrintGridlines( TRUE );
                                    }
                                    if ( ( ( boolean ) ) )
                                    {
                                        $docSheet->getPageSetup( )->setHorizontalCentered( TRUE );
                                    }
                                    if ( ( ( boolean ) ) )
                                    {
                                        $docSheet->getPageSetup( )->setVerticalCentered( TRUE );
                                    }
                                }
                                if ( $xmlSheet && $xmlSheet->sheetData && $xmlSheet->sheetData->row )
                                {
                                    foreach ( $xmlSheet->sheetData->row as $row )
                                    {
                                        if ( $row['ht'] && !$this->_readDataOnly )
                                        {
                                            intval( $row['r'] )( intval( $row['r'] ) )->setRowHeight( floatval( $row['ht'] ) );
                                        }
                                        if ( ( $row['hidden'] ) && !$this->_readDataOnly )
                                        {
                                            intval( $row['r'] )( intval( $row['r'] ) )->setVisible( FALSE );
                                        }
                                        if ( ( $row['collapsed'] ) )
                                        {
                                            intval( $row['r'] )( intval( $row['r'] ) )->setCollapsed( TRUE );
                                        }
                                        if ( 0 < $row['outlineLevel'] )
                                        {
                                            intval( $row['r'] )( intval( $row['r'] ) )->setOutlineLevel( intval( $row['outlineLevel'] ) );
                                        }
                                        if ( $row['s'] && !$this->_readDataOnly )
                                        {
                                            intval( $row['r'] )( intval( $row['r'] ) )->setXfIndex( intval( $row['s'] ) );
                                        }
                                        foreach ( $row->c as $c )
                                        {
                                            $r = ( boolean );
                                            $cellDataType = ( boolean );
                                            $value = NULL;
                                            $calculatedValue = NULL;
                                            if ( $this->getReadFilter( ) !== NULL )
                                            {
                                                $coordinates = ( $r );
                                                if ( $this->getReadFilter( )->readCell( $coordinates[0], $coordinates[1], $docSheet->getTitle( ) ) )
                                                {
                                                }
                                            }
                                            else
                                            {
                                                switch ( $cellDataType )
                                                {
                                                    case "s" :
                                                        if ( ( boolean ) != "" )
                                                        {
                                                            $value = $sharedStrings[intval( $c->v )];
                                                            if ( $value instanceof PHPExcel_RichText )
                                                            {
                                                                $value = clone $value;
                                                                break;
                                                            }
                                                        }
                                                        else
                                                        {
                                                            $value = "";
                                                            break;
                                                        }
                                                    case "b" :
                                                        if ( isset( $c->f ) )
                                                        {
                                                            $value = ( $c );
                                                            break;
                                                        }
                                                        else
                                                        {
                                                            $this->_castToFormula( $c, $r, $cellDataType, $value, $calculatedValue, $sharedFormulas, "_castToBool" );
                                                            if ( isset( $c->f['t'] ) )
                                                            {
                                                                $att = array( );
                                                                $att = $c->f;
                                                                $docSheet->getCell( $r )->setFormulaAttributes( $att );
                                                                break;
                                                            }
                                                        }
                                                    case "inlineStr" :
                                                        $value = $c->is( $c->is );
                                                        break;
                                                    case "e" :
                                                        if ( isset( $c->f ) )
                                                        {
                                                            $value = ( $c );
                                                            break;
                                                        }
                                                        else
                                                        {
                                                            $this->_castToFormula( $c, $r, $cellDataType, $value, $calculatedValue, $sharedFormulas, "_castToError" );
                                                            break;
                                                        }
                                                    default :
                                                        if ( isset( $c->f ) )
                                                        {
                                                            $value = ( $c );
                                                        }
                                                        else
                                                        {
                                                            $this->_castToFormula( $c, $r, $cellDataType, $value, $calculatedValue, $sharedFormulas, "_castToString" );
                                                        }
                                                }
                                                if ( is_numeric( $value ) && $cellDataType != "s" )
                                                {
                                                    if ( $value == ( integer ) )
                                                    {
                                                        $value = ( integer );
                                                    }
                                                    else if ( $value == ( double ) )
                                                    {
                                                        $value = ( double );
                                                    }
                                                    else if ( $value == ( double ) )
                                                    {
                                                        $value = ( double );
                                                    }
                                                }
                                                if ( $value instanceof PHPExcel_RichText && $this->_readDataOnly )
                                                {
                                                    $value = $value->getPlainText( );
                                                }
                                                $cell = $docSheet->getCell( $r );
                                                if ( $cellDataType != "" )
                                                {
                                                    $cell->setValueExplicit( $value, $cellDataType );
                                                }
                                                else
                                                {
                                                    $cell->setValue( $value );
                                                }
                                                if ( $calculatedValue !== NULL )
                                                {
                                                    $cell->setCalculatedValue( $calculatedValue );
                                                }
                                                if ( !$c['s'] || $this->_readDataOnly )
                                                {
                                                    $c['s']( isset( $styles[intval( $c['s'] )] ) ? intval( $c['s'] ) : 0 );
                                                }
                                            }
                                        }
                                    }
                                }
                                $conditionals = array( );
                                if ( !$this->_readDataOnly && $xmlSheet && $xmlSheet->conditionalFormatting )
                                {
                                    foreach ( $xmlSheet->conditionalFormatting as $conditional )
                                    {
                                        foreach ( $conditional->cfRule as $cfRule )
                                        {
                                            if ( !( ( boolean ) == PHPExcel_Style_Conditional::CONDITION_NONE ) && !( ( boolean ) == PHPExcel_Style_Conditional::CONDITION_CELLIS ) && !( ( boolean ) == PHPExcel_Style_Conditional::CONDITION_CONTAINSTEXT ) && !( ( boolean ) == PHPExcel_Style_Conditional::CONDITION_EXPRESSION ) || !isset( $dxfs[intval( $cfRule['dxfId'] )] ) )
                                            {
                                                $conditionals[( boolean )][intval( $cfRule['priority'] )] = $cfRule;
                                            }
                                        }
                                    }
                                    foreach ( $conditionals as $ref => $cfRules )
                                    {
                                        ksort( &$cfRules );
                                        $conditionalStyles = array( );
                                        foreach ( $cfRules as $cfRule )
                                        {
                                            $objConditional = new PHPExcel_Style_Conditional( );
                                            $objConditional->setConditionType( ( boolean ) );
                                            $objConditional->setOperatorType( ( boolean ) );
                                            if ( ( boolean ) != "" )
                                            {
                                                $objConditional->setText( ( boolean ) );
                                            }
                                            if ( 1 < count( $cfRule->formula ) )
                                            {
                                                foreach ( $cfRule->formula as $formula )
                                                {
                                                    $objConditional->addCondition( ( boolean ) );
                                                }
                                            }
                                            else
                                            {
                                                $objConditional->addCondition( ( boolean ) );
                                            }
                                            clone $dxfs[intval( $cfRule['dxfId'] )]( clone $dxfs[intval( $cfRule['dxfId'] )] );
                                            $conditionalStyles[] = $objConditional;
                                        }
                                        $aReferences = ( $ref );
                                        foreach ( $aReferences as $reference )
                                        {
                                            $docSheet->getStyle( $reference )->setConditionalStyles( $conditionalStyles );
                                        }
                                    }
                                }
                                $aKeys = array( "sheet", "objects", "scenarios", "formatCells", "formatColumns", "formatRows", "insertColumns", "insertRows", "insertHyperlinks", "deleteColumns", "deleteRows", "selectLockedCells", "sort", "autoFilter", "pivotTables", "selectUnlockedCells" );
                                if ( !$this->_readDataOnly && $xmlSheet && $xmlSheet->sheetProtection )
                                {
                                    foreach ( $aKeys as $key )
                                    {
                                        $method = "set".ucfirst( $key );
                                        $xmlSheet->sheetProtection[$key]( ( ( boolean ) ) );
                                    }
                                }
                                if ( $this->_readDataOnly )
                                {
                                    if ( $xmlSheet )
                                    {
                                        if ( $xmlSheet->sheetProtection )
                                        {
                                            $xmlSheet->sheetProtection['password']( ( boolean ), TRUE );
                                            if ( $xmlSheet->protectedRanges->protectedRange )
                                            {
                                                foreach ( $xmlSheet->protectedRanges->protectedRange as $protectedRange )
                                                {
                                                    $docSheet->protectCells( ( boolean ), ( boolean ), TRUE );
                                                }
                                            }
                                        }
                                    }
                                }
                                if ( $xmlSheet )
                                {
                                    if ( $xmlSheet->autoFilter && !$this->_readDataOnly )
                                    {
                                        $autoFilter = $docSheet->getAutoFilter( );
                                        $xmlSheet->autoFilter( ( boolean ) );
                                        foreach ( $xmlSheet->autoFilter->filterColumn as $filterColumn )
                                        {
                                            $column = $autoFilter->getColumnByOffset( ( integer ) );
                                            if ( $filterColumn->filters )
                                            {
                                                $column->setFilterType( PHPExcel_Worksheet_AutoFilter_Column::AUTOFILTER_FILTERTYPE_FILTER );
                                                $filters = $filterColumn->filters;
                                                if ( isset( $filters['blank'] ) && $filters['blank'] == 1 )
                                                {
                                                    $column->createRule( )->setRule( NULL, "" )->setRuleType( PHPExcel_Worksheet_AutoFilter_Column_Rule::AUTOFILTER_RULETYPE_FILTER );
                                                }
                                                foreach ( $filters->filter as $filterRule )
                                                {
                                                    $filterRule['val']( NULL, ( boolean ) )->setRuleType( PHPExcel_Worksheet_AutoFilter_Column_Rule::AUTOFILTER_RULETYPE_FILTER );
                                                }
                                                foreach ( $filters->dateGroupItem as $dateGroupItem )
                                                {
                                                    $dateGroupItem['dateTimeGrouping']( NULL, array( "year" => ( boolean ), "month" => ( boolean ), "day" => ( boolean ), "hour" => ( boolean ), "minute" => ( boolean ), "second" => ( boolean ) ), ( boolean ) )->setRuleType( PHPExcel_Worksheet_AutoFilter_Column_Rule::AUTOFILTER_RULETYPE_DATEGROUP );
                                                }
                                            }
                                            if ( $filterColumn->customFilters )
                                            {
                                                $column->setFilterType( PHPExcel_Worksheet_AutoFilter_Column::AUTOFILTER_FILTERTYPE_CUSTOMFILTER );
                                                $customFilters = $filterColumn->customFilters;
                                                if ( isset( $customFilters['and'] ) && $customFilters['and'] == 1 )
                                                {
                                                    $column->setJoin( PHPExcel_Worksheet_AutoFilter_Column::AUTOFILTER_COLUMN_JOIN_AND );
                                                }
                                                foreach ( $customFilters->customFilter as $filterRule )
                                                {
                                                    $filterRule['val']( ( boolean ), ( boolean ) )->setRuleType( PHPExcel_Worksheet_AutoFilter_Column_Rule::AUTOFILTER_RULETYPE_CUSTOMFILTER );
                                                }
                                            }
                                            if ( $filterColumn->dynamicFilter )
                                            {
                                                $column->setFilterType( PHPExcel_Worksheet_AutoFilter_Column::AUTOFILTER_FILTERTYPE_DYNAMICFILTER );
                                                foreach ( $filterColumn->dynamicFilter as $filterRule )
                                                {
                                                    $filterRule['type']( NULL, ( boolean ), ( boolean ) )->setRuleType( PHPExcel_Worksheet_AutoFilter_Column_Rule::AUTOFILTER_RULETYPE_DYNAMICFILTER );
                                                    if ( isset( $filterRule['val'] ) )
                                                    {
                                                        $column->setAttribute( "val", ( boolean ) );
                                                    }
                                                    if ( isset( $filterRule['maxVal'] ) )
                                                    {
                                                        $column->setAttribute( "maxVal", ( boolean ) );
                                                    }
                                                }
                                            }
                                            if ( $filterColumn->top10 )
                                            {
                                                $column->setFilterType( PHPExcel_Worksheet_AutoFilter_Column::AUTOFILTER_FILTERTYPE_TOPTENFILTER );
                                                foreach ( $filterColumn->top10 as $filterRule )
                                                {
                                                    $filterRule['top']( isset( $filterRule['percent'] ) && $filterRule['percent'] == 1 ? PHPExcel_Worksheet_AutoFilter_Column_Rule::AUTOFILTER_COLUMN_RULE_TOPTEN_PERCENT : PHPExcel_Worksheet_AutoFilter_Column_Rule::AUTOFILTER_COLUMN_RULE_TOPTEN_BY_VALUE, ( boolean ), isset( $filterRule['top'] ) && $filterRule['top'] == 1 ? PHPExcel_Worksheet_AutoFilter_Column_Rule::AUTOFILTER_COLUMN_RULE_TOPTEN_TOP : PHPExcel_Worksheet_AutoFilter_Column_Rule::AUTOFILTER_COLUMN_RULE_TOPTEN_BOTTOM )->setRuleType( PHPExcel_Worksheet_AutoFilter_Column_Rule::AUTOFILTER_RULETYPE_TOPTENFILTER );
                                                }
                                            }
                                        }
                                    }
                                    if ( $xmlSheet )
                                    {
                                        if ( $xmlSheet->mergeCells && $xmlSheet->mergeCells->mergeCell && !$this->_readDataOnly )
                                        {
                                            foreach ( $xmlSheet->mergeCells->mergeCell as $mergeCell )
                                            {
                                                $mergeRef = ( boolean );
                                                if ( strpos( $mergeRef, ":" ) !== FALSE )
                                                {
                                                    $docSheet->mergeCells( ( boolean ) );
                                                }
                                            }
                                        }
                                        if ( $xmlSheet )
                                        {
                                            if ( $xmlSheet->pageMargins && !$this->_readDataOnly )
                                            {
                                                $docPageMargins = $docSheet->getPageMargins( );
                                                floatval( $xmlSheet->pageMargins['left'] )( floatval( $xmlSheet->pageMargins['left'] ) );
                                                floatval( $xmlSheet->pageMargins['right'] )( floatval( $xmlSheet->pageMargins['right'] ) );
                                                floatval( $xmlSheet->pageMargins['top'] )( floatval( $xmlSheet->pageMargins['top'] ) );
                                                floatval( $xmlSheet->pageMargins['bottom'] )( floatval( $xmlSheet->pageMargins['bottom'] ) );
                                                floatval( $xmlSheet->pageMargins['header'] )( floatval( $xmlSheet->pageMargins['header'] ) );
                                                floatval( $xmlSheet->pageMargins['footer'] )( floatval( $xmlSheet->pageMargins['footer'] ) );
                                            }
                                            if ( $xmlSheet )
                                            {
                                                if ( $xmlSheet->pageSetup && !$this->_readDataOnly )
                                                {
                                                    $docPageSetup = $docSheet->getPageSetup( );
                                                    if ( isset( $xmlSheet->pageSetup['orientation'] ) )
                                                    {
                                                        $xmlSheet->pageSetup( ( boolean ) );
                                                    }
                                                    if ( isset( $xmlSheet->pageSetup['paperSize'] ) )
                                                    {
                                                        intval( $xmlSheet->pageSetup['paperSize'] )( intval( $xmlSheet->pageSetup['paperSize'] ) );
                                                    }
                                                    if ( isset( $xmlSheet->pageSetup['scale'] ) )
                                                    {
                                                        intval( $xmlSheet->pageSetup['scale'] )( intval( $xmlSheet->pageSetup['scale'] ), FALSE );
                                                    }
                                                    if ( isset( $xmlSheet->pageSetup['fitToHeight'] ) && 0 <= intval( $xmlSheet->pageSetup['fitToHeight'] ) )
                                                    {
                                                        intval( $xmlSheet->pageSetup['fitToHeight'] )( intval( $xmlSheet->pageSetup['fitToHeight'] ), FALSE );
                                                    }
                                                    if ( isset( $xmlSheet->pageSetup['fitToWidth'] ) && 0 <= intval( $xmlSheet->pageSetup['fitToWidth'] ) )
                                                    {
                                                        intval( $xmlSheet->pageSetup['fitToWidth'] )( intval( $xmlSheet->pageSetup['fitToWidth'] ), FALSE );
                                                    }
                                                    if ( isset( $xmlSheet->pageSetup['firstPageNumber'], $xmlSheet->pageSetup['useFirstPageNumber'] ) )
                                                    {
                                                        if ( ( ( boolean ) ) )
                                                        {
                                                            intval( $xmlSheet->pageSetup['firstPageNumber'] )( intval( $xmlSheet->pageSetup['firstPageNumber'] ) );
                                                        }
                                                    }
                                                }
                                                if ( $xmlSheet )
                                                {
                                                    if ( $xmlSheet->headerFooter && !$this->_readDataOnly )
                                                    {
                                                        $docHeaderFooter = $docSheet->getHeaderFooter( );
                                                        if ( isset( $xmlSheet->headerFooter['differentOddEven'] ) )
                                                        {
                                                            if ( ( ( boolean ) ) )
                                                            {
                                                                $docHeaderFooter->setDifferentOddEven( TRUE );
                                                            }
                                                        }
                                                        else
                                                        {
                                                            $docHeaderFooter->setDifferentOddEven( FALSE );
                                                        }
                                                        if ( isset( $xmlSheet->headerFooter['differentFirst'] ) )
                                                        {
                                                            if ( ( ( boolean ) ) )
                                                            {
                                                                $docHeaderFooter->setDifferentFirst( TRUE );
                                                            }
                                                        }
                                                        else
                                                        {
                                                            $docHeaderFooter->setDifferentFirst( FALSE );
                                                        }
                                                        if ( isset( $xmlSheet->headerFooter['scaleWithDoc'] ) )
                                                        {
                                                            if ( ( ( boolean ) ) )
                                                            {
                                                                $docHeaderFooter->setScaleWithDocument( FALSE );
                                                            }
                                                        }
                                                        else
                                                        {
                                                            $docHeaderFooter->setScaleWithDocument( TRUE );
                                                        }
                                                        if ( isset( $xmlSheet->headerFooter['alignWithMargins'] ) )
                                                        {
                                                            if ( ( ( boolean ) ) )
                                                            {
                                                                $docHeaderFooter->setAlignWithMargins( FALSE );
                                                            }
                                                        }
                                                        else
                                                        {
                                                            $docHeaderFooter->setAlignWithMargins( TRUE );
                                                        }
                                                        $xmlSheet->headerFooter( ( boolean ) );
                                                        $xmlSheet->headerFooter( ( boolean ) );
                                                        $xmlSheet->headerFooter( ( boolean ) );
                                                        $xmlSheet->headerFooter( ( boolean ) );
                                                        $xmlSheet->headerFooter( ( boolean ) );
                                                        $xmlSheet->headerFooter( ( boolean ) );
                                                    }
                                                    if ( $xmlSheet )
                                                    {
                                                        if ( $xmlSheet->rowBreaks && $xmlSheet->rowBreaks->brk && !$this->_readDataOnly )
                                                        {
                                                            foreach ( $xmlSheet->rowBreaks->brk as $brk )
                                                            {
                                                                if ( $brk['man'] )
                                                                {
                                                                    $docSheet->setBreak( "A".$brk['id'], PHPExcel_Worksheet::BREAK_ROW );
                                                                }
                                                            }
                                                        }
                                                        if ( $xmlSheet )
                                                        {
                                                            if ( $xmlSheet->colBreaks && $xmlSheet->colBreaks->brk && !$this->_readDataOnly )
                                                            {
                                                                foreach ( $xmlSheet->colBreaks->brk as $brk )
                                                                {
                                                                    if ( $brk['man'] )
                                                                    {
                                                                        $docSheet->setBreak( ( ( boolean ) )."1", PHPExcel_Worksheet::BREAK_COLUMN );
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                if ( $xmlSheet && $xmlSheet->dataValidations && !$this->_readDataOnly )
                                {
                                    foreach ( $xmlSheet->dataValidations->dataValidation as $dataValidation )
                                    {
                                        $range = strtoupper( $dataValidation['sqref'] );
                                        $rangeSet = explode( " ", $range );
                                        foreach ( $rangeSet as $range )
                                        {
                                            $stRange = $docSheet->shrinkRangeToFit( $range );
                                            $aReferences = ( $stRange );
                                            foreach ( $aReferences as $reference )
                                            {
                                                $docValidation = $docSheet->getCell( $reference )->getDataValidation( );
                                                $docValidation->setType( ( boolean ) );
                                                $docValidation->setErrorStyle( ( boolean ) );
                                                $docValidation->setOperator( ( boolean ) );
                                                $docValidation->setAllowBlank( $dataValidation['allowBlank'] != 0 );
                                                $docValidation->setShowDropDown( $dataValidation['showDropDown'] == 0 );
                                                $docValidation->setShowInputMessage( $dataValidation['showInputMessage'] != 0 );
                                                $docValidation->setShowErrorMessage( $dataValidation['showErrorMessage'] != 0 );
                                                $docValidation->setErrorTitle( ( boolean ) );
                                                $docValidation->setError( ( boolean ) );
                                                $docValidation->setPromptTitle( ( boolean ) );
                                                $docValidation->setPrompt( ( boolean ) );
                                                $docValidation->setFormula1( ( boolean ) );
                                                $docValidation->setFormula2( ( boolean ) );
                                            }
                                        }
                                    }
                                }
                                $hyperlinks = array( );
                                if ( $this->_readDataOnly )
                                {
                                    if ( $zip->locateName( dirname( "{$dir}/{$fileWorksheet}" )."/_rels/".basename( $fileWorksheet ).".rels" ) )
                                    {
                                        $relsWorksheet = simplexml_load_string( $this->_getFromZipArchive( $zip, dirname( "{$dir}/{$fileWorksheet}" )."/_rels/".basename( $fileWorksheet ).".rels" ) );
                                        foreach ( $relsWorksheet->Relationship as $ele )
                                        {
                                            if ( $ele['Type'] == "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink" )
                                            {
                                                $hyperlinks[( boolean )] = ( boolean );
                                            }
                                        }
                                    }
                                    if ( $xmlSheet && $xmlSheet->hyperlinks )
                                    {
                                        foreach ( $xmlSheet->hyperlinks->hyperlink as $hyperlink )
                                        {
                                            $linkRel = $hyperlink->attributes( "http://schemas.openxmlformats.org/officeDocument/2006/relationships" );
                                            foreach ( ( $hyperlink['ref'] ) as $cellReference )
                                            {
                                                $cell = $docSheet->getCell( $cellReference );
                                                if ( isset( $linkRel['id'] ) )
                                                {
                                                    $hyperlinkUrl = $hyperlinks[( boolean )];
                                                    if ( isset( $hyperlink['location'] ) )
                                                    {
                                                        $hyperlinkUrl .= "#".( boolean );
                                                    }
                                                    $cell->getHyperlink( )->setUrl( $hyperlinkUrl );
                                                }
                                                else if ( isset( $hyperlink['location'] ) )
                                                {
                                                    $cell->getHyperlink( )->setUrl( "sheet://".( boolean ) );
                                                }
                                                if ( isset( $hyperlink['tooltip'] ) )
                                                {
                                                    $hyperlink['tooltip']( ( boolean ) );
                                                }
                                            }
                                        }
                                    }
                                }
                                $comments = array( );
                                $vmlComments = array( );
                                if ( $this->_readDataOnly )
                                {
                                    if ( $zip->locateName( dirname( "{$dir}/{$fileWorksheet}" )."/_rels/".basename( $fileWorksheet ).".rels" ) )
                                    {
                                        $relsWorksheet = simplexml_load_string( $this->_getFromZipArchive( $zip, dirname( "{$dir}/{$fileWorksheet}" )."/_rels/".basename( $fileWorksheet ).".rels" ) );
                                        foreach ( $relsWorksheet->Relationship as $ele )
                                        {
                                            if ( $ele['Type'] == "http://schemas.openxmlformats.org/officeDocument/2006/relationships/comments" )
                                            {
                                                $comments[( boolean )] = ( boolean );
                                            }
                                            if ( $ele['Type'] == "http://schemas.openxmlformats.org/officeDocument/2006/relationships/vmlDrawing" )
                                            {
                                                $vmlComments[( boolean )] = ( boolean );
                                            }
                                        }
                                    }
                                    foreach ( $comments as $relName => $relPath )
                                    {
                                        $relPath = ( dirname( "{$dir}/{$fileWorksheet}" )."/".$relPath );
                                        $commentsFile = simplexml_load_string( $this->_getFromZipArchive( $zip, $relPath ) );
                                        $authors = array( );
                                        foreach ( $commentsFile->authors->author as $author )
                                        {
                                            $authors[] = ( boolean );
                                        }
                                        foreach ( $commentsFile->commentList->comment as $comment )
                                        {
                                            $docSheet->getComment( ( boolean ) )->setAuthor( $authors[( boolean )] );
                                            $docSheet->getComment( ( boolean ) )->setText( $comment->text( $comment->text ) );
                                        }
                                    }
                                    foreach ( $vmlComments as $relName => $relPath )
                                    {
                                        $relPath = ( dirname( "{$dir}/{$fileWorksheet}" )."/".$relPath );
                                        $vmlCommentsFile = simplexml_load_string( $this->_getFromZipArchive( $zip, $relPath ) );
                                        $vmlCommentsFile->registerXPathNamespace( "v", "urn:schemas-microsoft-com:vml" );
                                        $shapes = $vmlCommentsFile->xpath( "//v:shape" );
                                        foreach ( $shapes as $shape )
                                        {
                                            $shape->registerXPathNamespace( "v", "urn:schemas-microsoft-com:vml" );
                                            if ( isset( $shape['style'] ) )
                                            {
                                                $style = ( boolean );
                                                $fillColor = strtoupper( substr( ( boolean ), 1 ) );
                                                $column = NULL;
                                                $row = NULL;
                                                $clientData = $shape->xpath( ".//x:ClientData" );
                                                if ( is_array( $clientData ) && !empty( $clientData ) )
                                                {
                                                    $clientData = $clientData[0];
                                                    if ( isset( $clientData['ObjectType'] ) && ( boolean ) == "Note" )
                                                    {
                                                        $temp = $clientData->xpath( ".//x:Row" );
                                                        if ( is_array( $temp ) )
                                                        {
                                                            $row = $temp[0];
                                                        }
                                                        $temp = $clientData->xpath( ".//x:Column" );
                                                        if ( is_array( $temp ) )
                                                        {
                                                            $column = $temp[0];
                                                        }
                                                    }
                                                }
                                                if ( !( $column !== NULL ) || !( $row !== NULL ) )
                                                {
                                                    $comment = $docSheet->getCommentByColumnAndRow( ( boolean ), $row + 1 );
                                                    $comment->getFillColor( )->setRGB( $fillColor );
                                                    $styleArray = explode( ";", str_replace( " ", "", $style ) );
                                                    foreach ( $styleArray as $stylePair )
                                                    {
                                                        $stylePair = explode( ":", $stylePair );
                                                        if ( $stylePair[0] == "margin-left" )
                                                        {
                                                            $stylePair[1]( $stylePair[1] );
                                                        }
                                                        if ( $stylePair[0] == "margin-top" )
                                                        {
                                                            $stylePair[1]( $stylePair[1] );
                                                        }
                                                        if ( $stylePair[0] == "width" )
                                                        {
                                                            $stylePair[1]( $stylePair[1] );
                                                        }
                                                        if ( $stylePair[0] == "height" )
                                                        {
                                                            $stylePair[1]( $stylePair[1] );
                                                        }
                                                        if ( $stylePair[0] == "visibility" )
                                                        {
                                                            $comment->setVisible( $stylePair[1] == "visible" );
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    if ( $xmlSheet && $xmlSheet->legacyDrawingHF && !$this->_readDataOnly && $zip->locateName( dirname( "{$dir}/{$fileWorksheet}" )."/_rels/".basename( $fileWorksheet ).".rels" ) )
                                    {
                                        $relsWorksheet = simplexml_load_string( $this->_getFromZipArchive( $zip, dirname( "{$dir}/{$fileWorksheet}" )."/_rels/".basename( $fileWorksheet ).".rels" ) );
                                        $vmlRelationship = "";
                                        foreach ( $relsWorksheet->Relationship as $ele )
                                        {
                                            if ( $ele['Type'] == "http://schemas.openxmlformats.org/officeDocument/2006/relationships/vmlDrawing" )
                                            {
                                                $vmlRelationship = ( "{$dir}/{$fileWorksheet}", $ele['Target'] );
                                            }
                                        }
                                        if ( $vmlRelationship != "" )
                                        {
                                            $relsVML = simplexml_load_string( $this->_getFromZipArchive( $zip, dirname( $vmlRelationship )."/_rels/".basename( $vmlRelationship ).".rels" ) );
                                            $drawings = array( );
                                            foreach ( $relsVML->Relationship as $ele )
                                            {
                                                if ( $ele['Type'] == "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" )
                                                {
                                                    $drawings[( boolean )] = ( $vmlRelationship, $ele['Target'] );
                                                }
                                            }
                                            $vmlDrawing = simplexml_load_string( $this->_getFromZipArchive( $zip, $vmlRelationship ) );
                                            $vmlDrawing->registerXPathNamespace( "v", "urn:schemas-microsoft-com:vml" );
                                            $hfImages = array( );
                                            $shapes = $vmlDrawing->xpath( "//v:shape" );
                                            foreach ( $shapes as $shape )
                                            {
                                                $shape->registerXPathNamespace( "v", "urn:schemas-microsoft-com:vml" );
                                                $imageData = $shape->xpath( "//v:imagedata" );
                                                $imageData = $imageData[0];
                                                $imageData = $imageData->attributes( "urn:schemas-microsoft-com:office:office" );
                                                $style = ( ( boolean ) );
                                                $hfImages[( boolean )] = new PHPExcel_Worksheet_HeaderFooterDrawing( );
                                                if ( isset( $imageData['title'] ) )
                                                {
                                                    $imageData['title']( ( boolean ) );
                                                }
                                                ( $pFilename )( "zip://".( $pFilename )."#".$drawings[( boolean )], FALSE );
                                                $hfImages[( boolean )]->setResizeProportional( FALSE );
                                                $hfImages[( boolean )]->setWidth( $style['width'] );
                                                $hfImages[( boolean )]->setHeight( $style['height'] );
                                                $hfImages[( boolean )]->setOffsetX( $style['margin-left'] );
                                                $hfImages[( boolean )]->setOffsetY( $style['margin-top'] );
                                                $hfImages[( boolean )]->setResizeProportional( TRUE );
                                            }
                                            $docSheet->getHeaderFooter( )->setImages( $hfImages );
                                        }
                                    }
                                }
                                if ( $zip->locateName( dirname( "{$dir}/{$fileWorksheet}" )."/_rels/".basename( $fileWorksheet ).".rels" ) )
                                {
                                    $relsWorksheet = simplexml_load_string( $this->_getFromZipArchive( $zip, dirname( "{$dir}/{$fileWorksheet}" )."/_rels/".basename( $fileWorksheet ).".rels" ) );
                                    $drawings = array( );
                                    foreach ( $relsWorksheet->Relationship as $ele )
                                    {
                                        if ( $ele['Type'] == "http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing" )
                                        {
                                            $drawings[( boolean )] = ( "{$dir}/{$fileWorksheet}", $ele['Target'] );
                                        }
                                    }
                                    if ( $xmlSheet->drawing && !$this->_readDataOnly )
                                    {
                                        foreach ( $xmlSheet->drawing as $drawing )
                                        {
                                            $fileDrawing = $drawings[( boolean )];
                                            $relsDrawing = simplexml_load_string( $this->_getFromZipArchive( $zip, dirname( $fileDrawing )."/_rels/".basename( $fileDrawing ).".rels" ) );
                                            $images = array( );
                                            if ( $relsDrawing && $relsDrawing->Relationship )
                                            {
                                                foreach ( $relsDrawing->Relationship as $ele )
                                                {
                                                    if ( $ele['Type'] == "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" )
                                                    {
                                                        $images[( boolean )] = ( $fileDrawing, $ele['Target'] );
                                                    }
                                                    else if ( !( $ele['Type'] == "http://schemas.openxmlformats.org/officeDocument/2006/relationships/chart" ) || !$this->_includeCharts )
                                                    {
                                                        $charts[( $fileDrawing, $ele['Target'] )] = array( "id" => ( boolean ), "sheet" => $docSheet->getTitle( ) );
                                                    }
                                                }
                                            }
                                            $xmlDrawing = simplexml_load_string( $this->_getFromZipArchive( $zip, $fileDrawing ) )->children( "http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing" );
                                            if ( $xmlDrawing->oneCellAnchor )
                                            {
                                                foreach ( $xmlDrawing->oneCellAnchor as $oneCellAnchor )
                                                {
                                                    if ( $oneCellAnchor->pic->blipFill )
                                                    {
                                                        $blip = $oneCellAnchor->pic->blipFill->children( "http://schemas.openxmlformats.org/drawingml/2006/main" )->blip;
                                                        $xfrm = $oneCellAnchor->pic->spPr->children( "http://schemas.openxmlformats.org/drawingml/2006/main" )->xfrm;
                                                        $outerShdw = $oneCellAnchor->pic->spPr->children( "http://schemas.openxmlformats.org/drawingml/2006/main" )->effectLst->outerShdw;
                                                        $objDrawing = new PHPExcel_Worksheet_Drawing( );
                                                        $oneCellAnchor->pic->nvPicPr->cNvPr->attributes( )( ( boolean ) );
                                                        $oneCellAnchor->pic->nvPicPr->cNvPr->attributes( )( ( boolean ) );
                                                        ( $pFilename )( "zip://".( $pFilename )."#".$images[( boolean )], FALSE );
                                                        $oneCellAnchor->from->row( ( ( boolean ) ).( $oneCellAnchor->from->row + 1 ) );
                                                        ( $oneCellAnchor->from->colOff )( ( $oneCellAnchor->from->colOff ) );
                                                        ( $oneCellAnchor->from->rowOff )( ( $oneCellAnchor->from->rowOff ) );
                                                        $objDrawing->setResizeProportional( FALSE );
                                                        ( ( $oneCellAnchor->ext->attributes( ), "cx" ) )( ( ( $oneCellAnchor->ext->attributes( ), "cx" ) ) );
                                                        ( ( $oneCellAnchor->ext->attributes( ), "cy" ) )( ( ( $oneCellAnchor->ext->attributes( ), "cy" ) ) );
                                                        if ( $xfrm )
                                                        {
                                                            $objDrawing->setRotation( ( ( $xfrm->attributes( ), "rot" ) ) );
                                                        }
                                                        if ( $outerShdw )
                                                        {
                                                            $shadow = $objDrawing->getShadow( );
                                                            $shadow->setVisible( TRUE );
                                                            $shadow->setBlurRadius( ( ( $outerShdw->attributes( ), "blurRad" ) ) );
                                                            $shadow->setDistance( ( ( $outerShdw->attributes( ), "dist" ) ) );
                                                            $shadow->setDirection( ( ( $outerShdw->attributes( ), "dir" ) ) );
                                                            ( $outerShdw->attributes( ), "algn" )( ( boolean ) );
                                                            $shadow->getColor( )->setRGB( ( $outerShdw->srgbClr->attributes( ), "val" ) );
                                                            $outerShdw->srgbClr->alpha->attributes( )( ( $outerShdw->srgbClr->alpha->attributes( ), "val" ) / 1000 );
                                                        }
                                                        $objDrawing->setWorksheet( $docSheet );
                                                    }
                                                    else
                                                    {
                                                        $coordinates = ( ( boolean ) ).( $oneCellAnchor->from->row + 1 );
                                                        $offsetX = ( $oneCellAnchor->from->colOff );
                                                        $offsetY = ( $oneCellAnchor->from->rowOff );
                                                        $width = ( ( $oneCellAnchor->ext->attributes( ), "cx" ) );
                                                        $height = ( ( $oneCellAnchor->ext->attributes( ), "cy" ) );
                                                    }
                                                }
                                            }
                                            if ( $xmlDrawing->twoCellAnchor )
                                            {
                                                foreach ( $xmlDrawing->twoCellAnchor as $twoCellAnchor )
                                                {
                                                    if ( $twoCellAnchor->pic->blipFill )
                                                    {
                                                        $blip = $twoCellAnchor->pic->blipFill->children( "http://schemas.openxmlformats.org/drawingml/2006/main" )->blip;
                                                        $xfrm = $twoCellAnchor->pic->spPr->children( "http://schemas.openxmlformats.org/drawingml/2006/main" )->xfrm;
                                                        $outerShdw = $twoCellAnchor->pic->spPr->children( "http://schemas.openxmlformats.org/drawingml/2006/main" )->effectLst->outerShdw;
                                                        $objDrawing = new PHPExcel_Worksheet_Drawing( );
                                                        $twoCellAnchor->pic->nvPicPr->cNvPr->attributes( )( ( boolean ) );
                                                        $twoCellAnchor->pic->nvPicPr->cNvPr->attributes( )( ( boolean ) );
                                                        ( $pFilename )( "zip://".( $pFilename )."#".$images[( boolean )], FALSE );
                                                        $twoCellAnchor->from->row( ( ( boolean ) ).( $twoCellAnchor->from->row + 1 ) );
                                                        ( $twoCellAnchor->from->colOff )( ( $twoCellAnchor->from->colOff ) );
                                                        ( $twoCellAnchor->from->rowOff )( ( $twoCellAnchor->from->rowOff ) );
                                                        $objDrawing->setResizeProportional( FALSE );
                                                        ( ( $xfrm->ext->attributes( ), "cx" ) )( ( ( $xfrm->ext->attributes( ), "cx" ) ) );
                                                        ( ( $xfrm->ext->attributes( ), "cy" ) )( ( ( $xfrm->ext->attributes( ), "cy" ) ) );
                                                        if ( $xfrm )
                                                        {
                                                            $objDrawing->setRotation( ( ( $xfrm->attributes( ), "rot" ) ) );
                                                        }
                                                        if ( $outerShdw )
                                                        {
                                                            $shadow = $objDrawing->getShadow( );
                                                            $shadow->setVisible( TRUE );
                                                            $shadow->setBlurRadius( ( ( $outerShdw->attributes( ), "blurRad" ) ) );
                                                            $shadow->setDistance( ( ( $outerShdw->attributes( ), "dist" ) ) );
                                                            $shadow->setDirection( ( ( $outerShdw->attributes( ), "dir" ) ) );
                                                            ( $outerShdw->attributes( ), "algn" )( ( boolean ) );
                                                            $shadow->getColor( )->setRGB( ( $outerShdw->srgbClr->attributes( ), "val" ) );
                                                            $outerShdw->srgbClr->alpha->attributes( )( ( $outerShdw->srgbClr->alpha->attributes( ), "val" ) / 1000 );
                                                        }
                                                        $objDrawing->setWorksheet( $docSheet );
                                                    }
                                                    else if ( !$this->_includeCharts || !$twoCellAnchor->graphicFrame )
                                                    {
                                                        $fromCoordinate = ( ( boolean ) ).( $twoCellAnchor->from->row + 1 );
                                                        $fromOffsetX = ( $twoCellAnchor->from->colOff );
                                                        $fromOffsetY = ( $twoCellAnchor->from->rowOff );
                                                        $toCoordinate = ( ( boolean ) ).( $twoCellAnchor->to->row + 1 );
                                                        $toOffsetX = ( $twoCellAnchor->to->colOff );
                                                        $toOffsetY = ( $twoCellAnchor->to->rowOff );
                                                        $graphic = $twoCellAnchor->graphicFrame->children( "http://schemas.openxmlformats.org/drawingml/2006/main" )->graphic;
                                                        $chartRef = $graphic->graphicData->children( "http://schemas.openxmlformats.org/drawingml/2006/chart" )->chart;
                                                        $thisChart = ( boolean );
                                                        $chartDetails[$docSheet->getTitle( )."!".$thisChart] = array( "fromCoordinate" => $fromCoordinate, "fromOffsetX" => $fromOffsetX, "fromOffsetY" => $fromOffsetY, "toCoordinate" => $toCoordinate, "toOffsetX" => $toOffsetX, "toOffsetY" => $toOffsetY, "worksheetTitle" => $docSheet->getTitle( ) );
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                if ( $xmlWorkbook->definedNames )
                                {
                                    foreach ( $xmlWorkbook->definedNames->definedName as $definedName )
                                    {
                                        $extractedRange = ( boolean );
                                        $extractedRange = preg_replace( "/'(\\w+)'\\!/", "", $extractedRange );
                                        if ( ( $spos = strpos( $extractedRange, "!" ) ) !== FALSE )
                                        {
                                            $extractedRange = substr( $extractedRange, 0, $spos ).str_replace( "\$", "", substr( $extractedRange, $spos ) );
                                        }
                                        else
                                        {
                                            $extractedRange = str_replace( "\$", "", $extractedRange );
                                        }
                                        if ( stripos( ( boolean ), "#REF!" ) !== FALSE )
                                        {
                                        }
                                        else
                                        {
                                            break;
                                        }
                                        if ( !( ( boolean ) != "" ) || !( ( boolean ) == $sheetId ) )
                                        {
                                            switch ( ( boolean ) )
                                            {
                                                case "_xlnm._FilterDatabase" :
                                                    if ( ( boolean ) !== "1" )
                                                    {
                                                        $docSheet->getAutoFilter( )->setRange( $extractedRange );
                                                        break;
                                                    }
                                                case "_xlnm.Print_Titles" :
                                                    $extractedRange = explode( ",", $extractedRange );
                                                    foreach ( $extractedRange as $range )
                                                    {
                                                        $matches = array( );
                                                        $range = str_replace( "\$", "", $range );
                                                        if ( preg_match( "/!?([A-Z]+)\\:([A-Z]+)$/", $range, $matches ) )
                                                        {
                                                            $matches[2]( array( $matches[1], $matches[2] ) );
                                                        }
                                                        else if ( preg_match( "/!?(\\d+)\\:(\\d+)$/", $range, $matches ) )
                                                        {
                                                            $matches[2]( array( $matches[1], $matches[2] ) );
                                                        }
                                                    }
                                                    break;
                                                case "_xlnm.Print_Area" :
                                                    $rangeSets = explode( ",", $extractedRange );
                                                    $newRangeSets = array( );
                                                    foreach ( $rangeSets as $rangeSet )
                                                    {
                                                        $range = explode( "!", $rangeSet );
                                                        $rangeSet = isset( $range[1] ) ? $range[1] : $range[0];
                                                        if ( strpos( $rangeSet, ":" ) === FALSE )
                                                        {
                                                            $rangeSet = $rangeSet.":".$rangeSet;
                                                        }
                                                        $newRangeSets[] = str_replace( "\$", "", $rangeSet );
                                                    }
                                                    $docSheet->getPageSetup( )->setPrintArea( implode( ",", $newRangeSets ) );
                                            }
                                        }
                                    }
                                }
                                ++$sheetId;
                            }
                        }
                        if ( $xmlWorkbook->definedNames )
                        {
                            foreach ( $xmlWorkbook->definedNames->definedName as $definedName )
                            {
                                $extractedRange = ( boolean );
                                $extractedRange = preg_replace( "/'(\\w+)'\\!/", "", $extractedRange );
                                if ( ( $spos = strpos( $extractedRange, "!" ) ) !== FALSE )
                                {
                                    $extractedRange = substr( $extractedRange, 0, $spos ).str_replace( "\$", "", substr( $extractedRange, $spos ) );
                                }
                                else
                                {
                                    $extractedRange = str_replace( "\$", "", $extractedRange );
                                }
                                if ( stripos( ( boolean ), "#REF!" ) !== FALSE )
                                {
                                }
                                else
                                {
                                    break;
                                }
                                if ( ( boolean ) != "" )
                                {
                                    switch ( ( boolean ) )
                                    {
                                        case "_xlnm._FilterDatabase" :
                                        case "_xlnm.Print_Titles" :
                                        case "_xlnm.Print_Area" :
                                            if ( $mapSheetId[( integer )] !== NULL )
                                            {
                                                $range = explode( "!", ( boolean ) );
                                                if ( count( $range ) == 2 )
                                                {
                                                    $range[0] = str_replace( "''", "'", $range[0] );
                                                    $range[0] = str_replace( "'", "", $range[0] );
                                                    if ( $worksheet = $docSheet->getParent( )->getSheetByName( $range[0] ) )
                                                    {
                                                        $extractedRange = str_replace( "\$", "", $range[1] );
                                                        $scope = $docSheet->getParent( )->getSheet( $mapSheetId[( integer )] );
                                                        new PHPExcel_NamedRange( ( boolean ), $worksheet, $extractedRange, TRUE, $scope )( new PHPExcel_NamedRange( ( boolean ), $worksheet, $extractedRange, TRUE, $scope ) );
                                                    }
                                                }
                                            }
                                    }
                                }
                                else if ( isset( $definedName['localSheetId'] ) )
                                {
                                    $locatedSheet = NULL;
                                    $extractedSheetName = "";
                                    $extractedSheetName = ( ( boolean ), TRUE );
                                    $extractedSheetName = $extractedSheetName[0];
                                    $locatedSheet = $excel->getSheetByName( $extractedSheetName );
                                    $range = explode( "!", $extractedRange );
                                    $extractedRange = $range[0];
                                    if ( $locatedSheet !== NULL )
                                    {
                                        new PHPExcel_NamedRange( ( boolean ), $locatedSheet, $extractedRange, FALSE )( new PHPExcel_NamedRange( ( boolean ), $locatedSheet, $extractedRange, FALSE ) );
                                    }
                                }
                            }
                        }
                    }
                    if ( empty( $this->_loadSheetsOnly ) )
                    {
                        $activeTab = intval( $xmlWorkbook->bookViews->workbookView['activeTab'] );
                        if ( $mapSheetId[$activeTab] !== NULL )
                        {
                            $mapSheetId[$activeTab]( $mapSheetId[$activeTab] );
                        }
                        else
                        {
                            if ( $excel->getSheetCount( ) == 0 )
                            {
                                $excel->createSheet( );
                            }
                            $excel->setActiveSheetIndex( 0 );
                        }
                    }
            }
        }
        if ( $this->_readDataOnly )
        {
            $contentTypes = simplexml_load_string( $this->_getFromZipArchive( $zip, "[Content_Types].xml" ) );
            foreach ( $contentTypes->Override as $contentType )
            {
                switch ( $contentType['ContentType'] )
                {
                    case "application/vnd.openxmlformats-officedocument.drawingml.chart+xml" :
                        if ( $this->_includeCharts )
                        {
                            $chartEntryRef = ltrim( $contentType['PartName'], "/" );
                            $chartElements = simplexml_load_string( $this->_getFromZipArchive( $zip, $chartEntryRef ) );
                            $objChart = ( $chartElements, basename( $chartEntryRef, ".xml" ) );
                            if ( isset( $charts[$chartEntryRef] ) )
                            {
                                $chartPositionRef = $charts[$chartEntryRef]['sheet']."!".$charts[$chartEntryRef]['id'];
                                if ( isset( $chartDetails[$chartPositionRef] ) )
                                {
                                    $charts[$chartEntryRef]['sheet']( $charts[$chartEntryRef]['sheet'] )->addChart( $objChart );
                                    $charts[$chartEntryRef]( $charts[$chartEntryRef]['sheet']( $charts[$chartEntryRef]['sheet'] ) );
                                    $chartDetails[$chartPositionRef]['fromOffsetY']( $chartDetails[$chartPositionRef]['fromCoordinate'], $chartDetails[$chartPositionRef]['fromOffsetX'], $chartDetails[$chartPositionRef]['fromOffsetY'] );
                                    $chartDetails[$chartPositionRef]['toOffsetY']( $chartDetails[$chartPositionRef]['toCoordinate'], $chartDetails[$chartPositionRef]['toOffsetX'], $chartDetails[$chartPositionRef]['toOffsetY'] );
                                }
                            }
                        }
                }
            }
        }
        $zip->close( );
        return $excel;
    }

    private static function _readColor( $color, $background = FALSE )
    {
        if ( isset( $color['rgb'] ) )
        {
            return ( boolean );
        }
        if ( isset( $color['indexed'] ) )
        {
            return ( $color['indexed'] - 7, $background )->getARGB( );
        }
        if ( isset( $color['theme'] ) )
        {
            if ( self::$_theme !== NULL )
            {
                $returnColour = $color['theme']( ( integer ) );
                if ( isset( $color['tint'] ) )
                {
                    $tintAdjust = ( double );
                    $returnColour = ( $returnColour, $tintAdjust );
                }
                return "FF".$returnColour;
            }
        }
        if ( $background )
        {
            return "FFFFFFFF";
        }
        return "FF000000";
    }

    private static function _readStyle( $docStyle, $style )
    {
        $docStyle->getNumberFormat( )->setFormatCode( $style->numFmt );
        if ( isset( $style->font ) )
        {
            $style->font->name['val']( ( boolean ) );
            $style->font->sz['val']( ( boolean ) );
            if ( isset( $style->font->b ) )
            {
                ( ( boolean ) )( !isset( $style->font->b['val'] ) || ( ( boolean ) ) );
            }
            if ( isset( $style->font->i ) )
            {
                ( ( boolean ) )( !isset( $style->font->i['val'] ) || ( ( boolean ) ) );
            }
            if ( isset( $style->font->strike ) )
            {
                ( ( boolean ) )( !isset( $style->font->strike['val'] ) || ( ( boolean ) ) );
            }
            $style->font( ( $style->font->color ) );
            if ( isset( $style->font->u ) && !isset( $style->font->u['val'] ) )
            {
                $docStyle->getFont( )->setUnderline( PHPExcel_Style_Font::UNDERLINE_SINGLE );
            }
            else if ( isset( $style->font->u ) && isset( $style->font->u['val'] ) )
            {
                $style->font->u['val']( ( boolean ) );
            }
            if ( isset( $style->font->vertAlign ) && isset( $style->font->vertAlign['val'] ) )
            {
                $vertAlign = strtolower( ( boolean ) );
                if ( $vertAlign == "superscript" )
                {
                    $docStyle->getFont( )->setSuperScript( TRUE );
                }
                if ( $vertAlign == "subscript" )
                {
                    $docStyle->getFont( )->setSubScript( TRUE );
                }
            }
        }
        if ( isset( $style->fill ) )
        {
            if ( $style->fill->gradientFill )
            {
                $gradientFill = $style->fill->gradientFill[0];
                if ( empty( $gradientFill['type'] ) )
                {
                    $gradientFill['type']( ( boolean ) );
                }
                $docStyle->getFill( )->setRotation( floatval( $gradientFill['degree'] ) );
                $gradientFill->registerXPathNamespace( "sml", "http://schemas.openxmlformats.org/spreadsheetml/2006/main" );
                $docStyle->getFill( )->getStartColor( )->setARGB( ( ( $gradientFill->xpath( "sml:stop[@position=0]" ) )->color ) );
                $docStyle->getFill( )->getEndColor( )->setARGB( ( ( $gradientFill->xpath( "sml:stop[@position=1]" ) )->color ) );
            }
            else if ( $style->fill->patternFill )
            {
                $patternType = ( boolean ) != "" ? ( boolean ) : "solid";
                $docStyle->getFill( )->setFillType( $patternType );
                if ( $style->fill->patternFill->fgColor )
                {
                    $style->fill->patternFill( ( $style->fill->patternFill->fgColor, TRUE ) );
                }
                else
                {
                    $docStyle->getFill( )->getStartColor( )->setARGB( "FF000000" );
                }
                if ( $style->fill->patternFill->bgColor )
                {
                    $style->fill->patternFill( ( $style->fill->patternFill->bgColor, TRUE ) );
                }
            }
        }
        if ( isset( $style->border ) )
        {
            $diagonalUp = ( ( boolean ) );
            $diagonalDown = ( ( boolean ) );
            if ( !$diagonalUp && !$diagonalDown )
            {
                $docStyle->getBorders( )->setDiagonalDirection( PHPExcel_Style_Borders::DIAGONAL_NONE );
            }
            else if ( $diagonalUp && !$diagonalDown )
            {
                $docStyle->getBorders( )->setDiagonalDirection( PHPExcel_Style_Borders::DIAGONAL_UP );
            }
            else if ( !$diagonalUp && $diagonalDown )
            {
                $docStyle->getBorders( )->setDiagonalDirection( PHPExcel_Style_Borders::DIAGONAL_DOWN );
            }
            else
            {
                $docStyle->getBorders( )->setDiagonalDirection( PHPExcel_Style_Borders::DIAGONAL_BOTH );
            }
            ( $docStyle->getBorders( )->getLeft( ), $style->border->left );
            ( $docStyle->getBorders( )->getRight( ), $style->border->right );
            ( $docStyle->getBorders( )->getTop( ), $style->border->top );
            ( $docStyle->getBorders( )->getBottom( ), $style->border->bottom );
            ( $docStyle->getBorders( )->getDiagonal( ), $style->border->diagonal );
        }
        if ( isset( $style->alignment ) )
        {
            $style->alignment['horizontal']( ( boolean ) );
            $style->alignment['vertical']( ( boolean ) );
            $textRotation = 0;
            if ( ( integer ) <= 90 )
            {
                $textRotation = ( integer );
            }
            else if ( 90 < ( integer ) )
            {
                $textRotation = 90 - ( integer );
            }
            $docStyle->getAlignment( )->setTextRotation( intval( $textRotation ) );
            $style->alignment['wrapText']( ( ( boolean ) ) );
            $style->alignment['shrinkToFit']( ( ( boolean ) ) );
            intval( ( boolean ) )( 0 < intval( ( boolean ) ) ? intval( ( boolean ) ) : 0 );
        }
        if ( isset( $style->protection ) )
        {
            if ( isset( $style->protection['locked'] ) )
            {
                if ( ( ( boolean ) ) )
                {
                    $docStyle->getProtection( )->setLocked( PHPExcel_Style_Protection::PROTECTION_PROTECTED );
                }
                else
                {
                    $docStyle->getProtection( )->setLocked( PHPExcel_Style_Protection::PROTECTION_UNPROTECTED );
                }
            }
            if ( isset( $style->protection['hidden'] ) )
            {
                if ( ( ( boolean ) ) )
                {
                    $docStyle->getProtection( )->setHidden( PHPExcel_Style_Protection::PROTECTION_PROTECTED );
                }
                else
                {
                    $docStyle->getProtection( )->setHidden( PHPExcel_Style_Protection::PROTECTION_UNPROTECTED );
                }
            }
        }
    }

    private static function _readBorder( $docBorder, $eleBorder )
    {
        if ( isset( $eleBorder['style'] ) )
        {
            $docBorder->setBorderStyle( ( boolean ) );
        }
        if ( isset( $eleBorder->color ) )
        {
            $docBorder->getColor( )->setARGB( ( $eleBorder->color ) );
        }
    }

    private function _parseRichText( $is = NULL )
    {
        $value = new PHPExcel_RichText( );
        if ( isset( $is->t ) )
        {
            ( ( boolean ) )( ( ( boolean ) ) );
            return $value;
        }
        foreach ( $is->r as $run )
        {
            if ( isset( $run->rPr ) )
            {
                $objText = ( ( boolean ) )( ( ( boolean ) ) );
            }
            else
            {
                $objText = ( ( boolean ) )( ( ( boolean ) ) );
                if ( isset( $run->rPr->rFont['val'] ) )
                {
                    $run->rPr->rFont['val']( ( boolean ) );
                }
                if ( isset( $run->rPr->sz['val'] ) )
                {
                    $run->rPr->sz['val']( ( boolean ) );
                }
                if ( isset( $run->rPr->color ) )
                {
                    ( $run->rPr->color )( new self( ( $run->rPr->color ) ) );
                }
                if ( isset( $run->rPr->b['val'] ) )
                {
                }
                if ( ( ( boolean ) ) || isset( $run->rPr->b ) && !isset( $run->rPr->b['val'] ) )
                {
                    $objText->getFont( )->setBold( TRUE );
                }
                if ( isset( $run->rPr->i['val'] ) )
                {
                }
                if ( ( ( boolean ) ) || isset( $run->rPr->i ) && !isset( $run->rPr->i['val'] ) )
                {
                    $objText->getFont( )->setItalic( TRUE );
                }
                if ( isset( $run->rPr->vertAlign ) && isset( $run->rPr->vertAlign['val'] ) )
                {
                    $vertAlign = strtolower( ( boolean ) );
                    if ( $vertAlign == "superscript" )
                    {
                        $objText->getFont( )->setSuperScript( TRUE );
                    }
                    if ( $vertAlign == "subscript" )
                    {
                        $objText->getFont( )->setSubScript( TRUE );
                    }
                }
                if ( isset( $run->rPr->u ) && !isset( $run->rPr->u['val'] ) )
                {
                    $objText->getFont( )->setUnderline( PHPExcel_Style_Font::UNDERLINE_SINGLE );
                }
                else if ( isset( $run->rPr->u ) && isset( $run->rPr->u['val'] ) )
                {
                    $run->rPr->u['val']( ( boolean ) );
                }
                if ( isset( $run->rPr->strike['val'] ) )
                {
                }
                if ( !( ( boolean ) ) && ( !isset( $run->rPr->strike ) || isset( $run->rPr->strike['val'] ) ) )
                {
                    $objText->getFont( )->setStrikethrough( TRUE );
                }
            }
        }
        return $value;
    }

    private static function array_item( $array, $key = 0 )
    {
        if ( isset( $array[$key] ) )
        {
            return $array[$key];
        }
    }

    private static function dir_add( $base, $add )
    {
        return preg_replace( "~[^/]+/\\.\\./~", "", dirname( $base ).( "/".$add ) );
    }

    private static function toCSSArray( $style )
    {
        $style = str_replace( array( "\r", "\n" ), "", $style );
        $temp = explode( ";", $style );
        $style = array( );
        foreach ( $temp as $item )
        {
            $item = explode( ":", $item );
            if ( strpos( $item[1], "px" ) !== FALSE )
            {
                $item[1] = str_replace( "px", "", $item[1] );
            }
            if ( strpos( $item[1], "pt" ) !== FALSE )
            {
                $item[1] = str_replace( "pt", "", $item[1] );
                $item[1] = ( $item[1] );
            }
            if ( strpos( $item[1], "in" ) !== FALSE )
            {
                $item[1] = str_replace( "in", "", $item[1] );
                $item[1] = ( $item[1] );
            }
            if ( strpos( $item[1], "cm" ) !== FALSE )
            {
                $item[1] = str_replace( "cm", "", $item[1] );
                $item[1] = ( $item[1] );
            }
            $style[$item[0]] = $item[1];
        }
        return $style;
    }

    private static function boolean( $value = NULL )
    {
        if ( is_numeric( $value ) )
        {
            return $value;
        }
        if ( $value === "true" || $value === "TRUE" )
        {
            return TRUE;
        }
        return FALSE;
    }

}

?>
