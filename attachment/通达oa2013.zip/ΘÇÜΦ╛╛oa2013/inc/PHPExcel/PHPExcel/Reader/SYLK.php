<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
if ( defined( "PHPEXCEL_ROOT" ) )
{
    define( "PHPEXCEL_ROOT", dirname( __FILE__ )."/../../" );
    require( PHPEXCEL_ROOT."PHPExcel/Autoloader.php" );
}
class PHPExcel_Reader_SYLK extends PHPExcel_Reader_IReader implements PHPExcel_Reader_IReader
{

    private $_inputEncoding = "ANSI";
    private $_sheetIndex = 0;
    private $_formats = array( );
    private $_format = 0;

    public function __construct( )
    {
        $this->_readFilter = new PHPExcel_Reader_DefaultReadFilter( );
    }

    protected function _isValidFormat( )
    {
        $data = fread( $this->_fileHandle, 2048 );
        $delimiterCount = substr_count( $data, ";" );
        if ( $delimiterCount < 1 )
        {
            return FALSE;
        }
        $lines = explode( "\n", $data );
        if ( substr( $lines[0], 0, 4 ) != "ID;P" )
        {
            return FALSE;
        }
        return TRUE;
    }

    public function setInputEncoding( $pValue = "ANSI" )
    {
        $this->_inputEncoding = $pValue;
        return $this;
    }

    public function getInputEncoding( )
    {
        return $this->_inputEncoding;
    }

    public function listWorksheetInfo( $pFilename )
    {
        $this->_openFile( $pFilename );
        if ( $this->_isValidFormat( ) )
        {
            fclose( $this->_fileHandle );
            throw new PHPExcel_Reader_Exception( $pFilename." is an Invalid Spreadsheet file." );
        }
        $fileHandle = $this->_fileHandle;
        rewind( $fileHandle );
        $worksheetInfo = array( );
        $worksheetInfo[0]['worksheetName'] = "Worksheet";
        $worksheetInfo[0]['lastColumnLetter'] = "A";
        $worksheetInfo[0]['lastColumnIndex'] = 0;
        $worksheetInfo[0]['totalRows'] = 0;
        $worksheetInfo[0]['totalColumns'] = 0;
        $rowData = array( );
        $rowIndex = 0;
        while ( ( $rowData = fgets( $fileHandle ) ) !== FALSE )
        {
            $columnIndex = 0;
            $rowData = ( $rowData );
            $rowData = explode( "\t", str_replace( "¤", ";", str_replace( ";", "\t", str_replace( ";;", "¤", rtrim( $rowData ) ) ) ) );
            $dataType = array_shift( &$rowData );
            if ( $dataType == "C" )
            {
                foreach ( $rowData as $rowDatum )
                {
                    switch ( $rowDatum[0] )
                    {
                        case "C" :
                        case "X" :
                            $columnIndex = substr( $rowDatum, 1 ) - 1;
                            break;
                        case "R" :
                        case "Y" :
                            $rowIndex = substr( $rowDatum, 1 );
                    }
                    $worksheetInfo[0]['totalRows'] = max( $worksheetInfo[0]['totalRows'], $rowIndex );
                    $worksheetInfo[0]['lastColumnIndex'] = max( $worksheetInfo[0]['lastColumnIndex'], $columnIndex );
                }
            }
        }
        $worksheetInfo[0]['lastColumnLetter'] = ( $worksheetInfo[0]['lastColumnIndex'] );
        $worksheetInfo[0]['totalColumns'] = $worksheetInfo[0]['lastColumnIndex'] + 1;
        fclose( $fileHandle );
        return $worksheetInfo;
    }

    public function load( $pFilename )
    {
        $objPHPExcel = new PHPExcel( );
        return $this->loadIntoExisting( $pFilename, $objPHPExcel );
    }

    public function loadIntoExisting( $pFilename, $objPHPExcel )
    {
        $this->_openFile( $pFilename );
        if ( $this->_isValidFormat( ) )
        {
            fclose( $this->_fileHandle );
            throw new PHPExcel_Reader_Exception( $pFilename." is an Invalid Spreadsheet file." );
        }
        $fileHandle = $this->_fileHandle;
        rewind( $fileHandle );
        while ( $objPHPExcel->getSheetCount( ) <= $this->_sheetIndex )
        {
            $objPHPExcel->createSheet( );
        }
        $this->_sheetIndex( $this->_sheetIndex );
        $fromFormats = array( "\\-", "\\ " );
        $toFormats = array( "-", " " );
        $rowData = array( );
        $column = $row = "";
        while ( ( $rowData = fgets( $fileHandle ) ) !== FALSE )
        {
            $rowData = ( $rowData );
            $rowData = explode( "\t", str_replace( "¤", ";", str_replace( ";", "\t", str_replace( ";;", "¤", rtrim( $rowData ) ) ) ) );
            $dataType = array_shift( &$rowData );
            if ( $dataType == "P" )
            {
                $formatArray = array( );
                foreach ( $rowData as $rowDatum )
                {
                    switch ( $rowDatum[0] )
                    {
                        case "P" :
                            $formatArray['numberformat']['code'] = str_replace( $fromFormats, $toFormats, substr( $rowDatum, 1 ) );
                            break;
                        case "E" :
                        case "F" :
                            $formatArray['font']['name'] = substr( $rowDatum, 1 );
                            break;
                        case "L" :
                            $formatArray['font']['size'] = substr( $rowDatum, 1 );
                            break;
                        case "S" :
                            $styleSettings = substr( $rowDatum, 1 );
                            $i = 0;
                            for ( ; $i < strlen( $styleSettings ); ++$i )
                            {
                                switch ( $styleSettings[$i] )
                                {
                                    case "I" :
                                        $formatArray['font']['italic'] = TRUE;
                                        break;
                                    case "D" :
                                        $formatArray['font']['bold'] = TRUE;
                                        break;
                                    case "T" :
                                        $formatArray['borders']['top']['style'] = PHPExcel_Style_Border::BORDER_THIN;
                                        break;
                                    case "B" :
                                        $formatArray['borders']['bottom']['style'] = PHPExcel_Style_Border::BORDER_THIN;
                                        break;
                                    case "L" :
                                        $formatArray['borders']['left']['style'] = PHPExcel_Style_Border::BORDER_THIN;
                                        break;
                                    case "R" :
                                        $formatArray['borders']['right']['style'] = PHPExcel_Style_Border::BORDER_THIN;
                                }
                            }
                    }
                }
                $this->_formats["P".$this->_format++] = $formatArray;
            }
            else
            {
                if ( $dataType == "C" )
                {
                    $hasCalculatedValue = FALSE;
                    $cellData = $cellDataFormula = "";
                    foreach ( $rowData as $rowDatum )
                    {
                        switch ( $rowDatum[0] )
                        {
                            case "C" :
                            case "X" :
                                $column = substr( $rowDatum, 1 );
                                break;
                            case "R" :
                            case "Y" :
                                $row = substr( $rowDatum, 1 );
                                break;
                            case "K" :
                                $cellData = substr( $rowDatum, 1 );
                                break;
                            case "E" :
                                $cellDataFormula = "=".substr( $rowDatum, 1 );
                                $temp = explode( "\"", $cellDataFormula );
                                $key = FALSE;
                                foreach ( $temp as $key )
                                {
                                    if ( substr( $rowDatum, 1 ) )
                                    {
                                        preg_match_all( "/(R(\\[?-?\\d*\\]?))(C(\\[?-?\\d*\\]?))/", $value, $cellReferences, PREG_SET_ORDER + PREG_OFFSET_CAPTURE );
                                        $cellReferences = array_reverse( $cellReferences );
                                        foreach ( $cellReferences as $cellReference )
                                        {
                                            $rowReference = $cellReference[2][0];
                                            if ( $rowReference == "" )
                                            {
                                                $rowReference = $row;
                                            }
                                            if ( $rowReference[0] == "[" )
                                            {
                                                $rowReference = $row + trim( $rowReference, "[]" );
                                            }
                                            $columnReference = $cellReference[4][0];
                                            if ( $columnReference == "" )
                                            {
                                                $columnReference = $column;
                                            }
                                            if ( $columnReference[0] == "[" )
                                            {
                                                $columnReference = $column + trim( $columnReference, "[]" );
                                            }
                                            $A1CellReference = ( $columnReference - 1 ).$rowReference;
                                            $value = substr_replace( $value, $A1CellReference, $cellReference[0][1], strlen( $cellReference[0][0] ) );
                                        }
                                    }
                                }
                                unset( $value );
                                $cellDataFormula = implode( "\"", $temp );
                                $hasCalculatedValue = TRUE;
                        }
                    }
                    $columnLetter = ( $column - 1 );
                    $cellData = ( $cellData );
                    $objPHPExcel->getActiveSheet( )->getCell( $columnLetter.$row )->setValue( $hasCalculatedValue ? $cellDataFormula : $cellData );
                    if ( $hasCalculatedValue )
                    {
                        $cellData = ( $cellData );
                        $objPHPExcel->getActiveSheet( )->getCell( $columnLetter.$row )->setCalculatedValue( $cellData );
                    }
                }
                else
                {
                    if ( !( $dataType == "F" ) )
                    {
                        break;
                    }
                    else
                    {
                        $formatStyle = $columnWidth = $styleSettings = "";
                        $styleData = array( );
                        foreach ( $rowData as $rowDatum )
                        {
                            switch ( $rowDatum[0] )
                            {
                                case "C" :
                                case "X" :
                                    $column = substr( $rowDatum, 1 );
                                    break;
                                case "R" :
                                case "Y" :
                                    $row = substr( $rowDatum, 1 );
                                    break;
                                case "P" :
                                    $formatStyle = $rowDatum;
                                    break;
                                case "W" :
                                    $columnWidth = explode( " ", substr( $rowDatum, 1 ) )[2];
                                    $endCol = explode( " ", substr( $rowDatum, 1 ) )[1];
                                    $startCol = explode( " ", substr( $rowDatum, 1 ) )[0];
                                    break;
                                case "S" :
                                    $styleSettings = substr( $rowDatum, 1 );
                                    $i = 0;
                                    for ( ; $i < strlen( $styleSettings ); ++$i )
                                    {
                                        switch ( $styleSettings[$i] )
                                        {
                                            case "I" :
                                                $styleData['font']['italic'] = TRUE;
                                                break;
                                            case "D" :
                                                $styleData['font']['bold'] = TRUE;
                                                break;
                                            case "T" :
                                                $styleData['borders']['top']['style'] = PHPExcel_Style_Border::BORDER_THIN;
                                                break;
                                            case "B" :
                                                $styleData['borders']['bottom']['style'] = PHPExcel_Style_Border::BORDER_THIN;
                                                break;
                                            case "L" :
                                                $styleData['borders']['left']['style'] = PHPExcel_Style_Border::BORDER_THIN;
                                                break;
                                            case "R" :
                                                $styleData['borders']['right']['style'] = PHPExcel_Style_Border::BORDER_THIN;
                                        }
                                    }
                            }
                        }
                    }
                    if ( "" < $formatStyle && "" < $column && "" < $row )
                    {
                        $columnLetter = ( $column - 1 );
                        if ( isset( $this->_formats[$formatStyle] ) )
                        {
                            $this->_formats( $this->_formats[$formatStyle] );
                        }
                    }
                    if ( !empty( $styleData ) && "" < $column && "" < $row )
                    {
                        $columnLetter = ( $column - 1 );
                        $objPHPExcel->getActiveSheet( )->getStyle( $columnLetter.$row )->applyFromArray( $styleData );
                    }
                    if ( !( "" < $columnWidth ) )
                    {
                        continue;
                    }
                    else if ( $startCol == $endCol )
                    {
                        $startCol = ( $startCol - 1 );
                        $objPHPExcel->getActiveSheet( )->getColumnDimension( $startCol )->setWidth( $columnWidth );
                    }
                    else
                    {
                        $startCol = ( $startCol - 1 );
                        $endCol = ( $endCol - 1 );
                        $objPHPExcel->getActiveSheet( )->getColumnDimension( $startCol )->setWidth( $columnWidth );
                        do
                        {
                            $objPHPExcel->getActiveSheet( )->getColumnDimension( ++$startCol )->setWidth( $columnWidth );
                        } while ( $startCol != $endCol );
                        foreach ( $rowData as $rowDatum )
                        {
                            switch ( $rowDatum[0] )
                            {
                                case "C" :
                                case "X" :
                                    $column = substr( $rowDatum, 1 );
                                    break;
                                case "R" :
                                case "Y" :
                                    $row = substr( $rowDatum, 1 );
                            }
                        }
                    }
                }
            }
        }
        fclose( $fileHandle );
        return $objPHPExcel;
    }

    public function getSheetIndex( )
    {
        return $this->_sheetIndex;
    }

    public function setSheetIndex( $pValue = 0 )
    {
        $this->_sheetIndex = $pValue;
        return $this;
    }

}

?>
