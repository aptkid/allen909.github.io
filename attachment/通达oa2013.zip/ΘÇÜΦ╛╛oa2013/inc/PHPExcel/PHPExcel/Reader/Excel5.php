<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
if ( defined( "PHPEXCEL_ROOT" ) )
{
    define( "PHPEXCEL_ROOT", dirname( __FILE__ )."/../../" );
    require( PHPEXCEL_ROOT."PHPExcel/Autoloader.php" );
}
class PHPExcel_Reader_Excel5 extends PHPExcel_Reader_IReader implements PHPExcel_Reader_IReader
{

    private $_summaryInformation;
    private $_documentSummaryInformation;
    private $_userDefinedProperties;
    private $_data;
    private $_dataSize;
    private $_pos;
    private $_phpExcel;
    private $_phpSheet;
    private $_version;
    private $_codepage;
    private $_formats;
    private $_objFonts;
    private $_palette;
    private $_sheets;
    private $_externalBooks;
    private $_ref;
    private $_externalNames;
    private $_definedname;
    private $_sst;
    private $_frozen;
    private $_isFitToPages;
    private $_objs;
    private $_textObjects;
    private $_cellNotes;
    private $_drawingGroupData;
    private $_drawingData;
    private $_xfIndex;
    private $_mapCellXfIndex;
    private $_mapCellStyleXfIndex;
    private $_sharedFormulas;
    private $_sharedFormulaParts;

    const XLS_BIFF8 = 1536;
    const XLS_BIFF7 = 1280;
    const XLS_WorkbookGlobals = 5;
    const XLS_Worksheet = 16;
    const XLS_Type_FORMULA = 6;
    const XLS_Type_EOF = 10;
    const XLS_Type_PROTECT = 18;
    const XLS_Type_OBJECTPROTECT = 99;
    const XLS_Type_SCENPROTECT = 221;
    const XLS_Type_PASSWORD = 19;
    const XLS_Type_HEADER = 20;
    const XLS_Type_FOOTER = 21;
    const XLS_Type_EXTERNSHEET = 23;
    const XLS_Type_DEFINEDNAME = 24;
    const XLS_Type_VERTICALPAGEBREAKS = 26;
    const XLS_Type_HORIZONTALPAGEBREAKS = 27;
    const XLS_Type_NOTE = 28;
    const XLS_Type_SELECTION = 29;
    const XLS_Type_DATEMODE = 34;
    const XLS_Type_EXTERNNAME = 35;
    const XLS_Type_LEFTMARGIN = 38;
    const XLS_Type_RIGHTMARGIN = 39;
    const XLS_Type_TOPMARGIN = 40;
    const XLS_Type_BOTTOMMARGIN = 41;
    const XLS_Type_PRINTGRIDLINES = 43;
    const XLS_Type_FILEPASS = 47;
    const XLS_Type_FONT = 49;
    const XLS_Type_CONTINUE = 60;
    const XLS_Type_PANE = 65;
    const XLS_Type_CODEPAGE = 66;
    const XLS_Type_DEFCOLWIDTH = 85;
    const XLS_Type_OBJ = 93;
    const XLS_Type_COLINFO = 125;
    const XLS_Type_IMDATA = 127;
    const XLS_Type_SHEETPR = 129;
    const XLS_Type_HCENTER = 131;
    const XLS_Type_VCENTER = 132;
    const XLS_Type_SHEET = 133;
    const XLS_Type_PALETTE = 146;
    const XLS_Type_SCL = 160;
    const XLS_Type_PAGESETUP = 161;
    const XLS_Type_MULRK = 189;
    const XLS_Type_MULBLANK = 190;
    const XLS_Type_DBCELL = 215;
    const XLS_Type_XF = 224;
    const XLS_Type_MERGEDCELLS = 229;
    const XLS_Type_MSODRAWINGGROUP = 235;
    const XLS_Type_MSODRAWING = 236;
    const XLS_Type_SST = 252;
    const XLS_Type_LABELSST = 253;
    const XLS_Type_EXTSST = 255;
    const XLS_Type_EXTERNALBOOK = 430;
    const XLS_Type_DATAVALIDATIONS = 434;
    const XLS_Type_TXO = 438;
    const XLS_Type_HYPERLINK = 440;
    const XLS_Type_DATAVALIDATION = 446;
    const XLS_Type_DIMENSION = 512;
    const XLS_Type_BLANK = 513;
    const XLS_Type_NUMBER = 515;
    const XLS_Type_LABEL = 516;
    const XLS_Type_BOOLERR = 517;
    const XLS_Type_STRING = 519;
    const XLS_Type_ROW = 520;
    const XLS_Type_INDEX = 523;
    const XLS_Type_ARRAY = 545;
    const XLS_Type_DEFAULTROWHEIGHT = 549;
    const XLS_Type_WINDOW2 = 574;
    const XLS_Type_RK = 638;
    const XLS_Type_STYLE = 659;
    const XLS_Type_FORMAT = 1054;
    const XLS_Type_SHAREDFMLA = 1212;
    const XLS_Type_BOF = 2057;
    const XLS_Type_SHEETPROTECTION = 2151;
    const XLS_Type_RANGEPROTECTION = 2152;
    const XLS_Type_SHEETLAYOUT = 2146;
    const XLS_Type_XFEXT = 2173;
    const XLS_Type_PAGELAYOUTVIEW = 2187;
    const XLS_Type_UNKNOWN = 65535;

    public function __construct( )
    {
        $this->_readFilter = new PHPExcel_Reader_DefaultReadFilter( );
    }

    public function canRead( $pFilename )
    {
        if ( file_exists( $pFilename ) )
        {
            throw new PHPExcel_Reader_Exception( "Could not open ".$pFilename." for reading! File does not exist." );
        }
        try
        {
            $ole = new PHPExcel_Shared_OLERead( );
            $res = $ole->read( $pFilename );
            return TRUE;
        }
        catch ( PHPExcel_Exception $e )
        {
            return FALSE;
    }
}

    public function listWorksheetNames( $pFilename )
    {
        if ( file_exists( $pFilename ) )
        {
            throw new PHPExcel_Reader_Exception( "Could not open ".$pFilename." for reading! File does not exist." );
        }
        $worksheetNames = array( );
        $this->_loadOLE( $pFilename );
        $this->_dataSize = strlen( $this->_data );
        $this->_pos = 0;
        $this->_sheets = array( );
}
}
while ( $this->_pos < $this->_dataSize )
{
    $code = ( $this->_data, $this->_pos );
case self::XLS_Type_BOF :
    switch ( $code )
    {
            $this->_readBof( );
            continue;
        case self::XLS_Type_SHEET :
            switch ( $code )
            {
                    $this->_readSheet( );
                    continue;
                    switch ( $code )
                    {
                        case self::XLS_Type_EOF :
                            $this->_readDefault( );
                            break;
                        default :
                            $this->_readDefault( );
                    }
                }
                foreach ( $this->_sheets as $sheet )
                {
                    if ( $sheet['sheetType'] != 0 )
                    {
                        $worksheetNames[] = $sheet['name'];
                    }
                }
                return $worksheetNames;
            }

    public function listWorksheetInfo( $pFilename )
    {
        if ( file_exists( $pFilename ) )
        {
            throw new PHPExcel_Reader_Exception( "Could not open ".$pFilename." for reading! File does not exist." );
        }
        $worksheetInfo = array( );
        $this->_loadOLE( $pFilename );
        $this->_dataSize = strlen( $this->_data );
        $this->_pos = 0;
        $this->_sheets = array( );
}
}
while ( $this->_pos < $this->_dataSize )
{
    $code = ( $this->_data, $this->_pos );
case self::XLS_Type_BOF :
    switch ( $code )
    {
            $this->_readBof( );
            continue;
        case self::XLS_Type_SHEET :
            switch ( $code )
            {
                    $this->_readSheet( );
                    continue;
                    switch ( $code )
                    {
                        case self::XLS_Type_EOF :
                            $this->_readDefault( );
                            break;
                        default :
                            $this->_readDefault( );
                    }
                }
                foreach ( $this->_sheets as $sheet )
                {
                    if ( $sheet['sheetType'] != 0 )
                    {
                        $tmpInfo = array( );
                        $tmpInfo['worksheetName'] = $sheet['name'];
                        $tmpInfo['lastColumnLetter'] = "A";
                        $tmpInfo['lastColumnIndex'] = 0;
                        $tmpInfo['totalRows'] = 0;
                        $tmpInfo['totalColumns'] = 0;
                        $this->_pos = $sheet['offset'];
                }
        }
        while ( $this->_pos <= $this->_dataSize - 4 )
        {
            $code = ( $this->_data, $this->_pos );
            switch ( $code )
            {
                case self::XLS_Type_RK :
                    switch ( $code )
                    {
                        case self::XLS_Type_LABELSST :
                            switch ( $code )
                            {
                                case self::XLS_Type_NUMBER :
                                    switch ( $code )
                                    {
                                        case self::XLS_Type_FORMULA :
                                            switch ( $code )
                                            {
                                                case self::XLS_Type_BOOLERR :
                                                case self::XLS_Type_LABEL :
                                                    switch ( $code )
                                                    {
                                                    }
                                            }
                                    }
                            }
                    }
                    $length = ( $this->_data, $this->_pos + 2 );
                    $recordData = substr( $this->_data, $this->_pos + 4, $length );
                    $ && _737133392 += "_pos";
                    $rowIndex = ( $recordData, 0 ) + 1;
                    $columnIndex = ( $recordData, 2 );
                    $tmpInfo['totalRows'] = max( $tmpInfo['totalRows'], $rowIndex );
                    $tmpInfo['lastColumnIndex'] = max( $tmpInfo['lastColumnIndex'], $columnIndex );
                    continue;
                case self::XLS_Type_BOF :
                    switch ( $code )
                    {
                            $this->_readBof( );
                            continue;
                            switch ( $code )
                            {
                                case self::XLS_Type_EOF :
                                    $this->_readDefault( );
                                    break;
                                default :
                                    $this->_readDefault( );
                            }
                        }
                        $tmpInfo['lastColumnLetter'] = ( $tmpInfo['lastColumnIndex'] );
                        $tmpInfo['totalColumns'] = $tmpInfo['lastColumnIndex'] + 1;
                        $worksheetInfo[] = $tmpInfo;
                    }
                }
                return $worksheetInfo;
            }

    public function load( $pFilename )
    {
        $this->_loadOLE( $pFilename );
        $this->_phpExcel = new PHPExcel( );
        $this->_phpExcel->removeSheetByIndex( 0 );
        if ( $this->_readDataOnly )
        {
            $this->_phpExcel->removeCellStyleXfByIndex( 0 );
            $this->_phpExcel->removeCellXfByIndex( 0 );
        }
        $this->_readSummaryInformation( );
        $this->_readDocumentSummaryInformation( );
        $this->_dataSize = strlen( $this->_data );
        $this->_pos = 0;
        $this->_codepage = "CP1252";
        $this->_formats = array( );
        $this->_objFonts = array( );
        $this->_palette = array( );
        $this->_sheets = array( );
        $this->_externalBooks = array( );
        $this->_ref = array( );
        $this->_definedname = array( );
        $this->_sst = array( );
        $this->_drawingGroupData = "";
        $this->_xfIndex = "";
        $this->_mapCellXfIndex = array( );
        $this->_mapCellStyleXfIndex = array( );
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
while ( $this->_pos < $this->_dataSize )
{
    $code = ( $this->_data, $this->_pos );
case self::XLS_Type_BOF :
    switch ( $code )
    {
            $this->_readBof( );
            continue;
        case self::XLS_Type_FILEPASS :
            switch ( $code )
            {
                    $this->_readFilepass( );
                    continue;
                case self::XLS_Type_CODEPAGE :
                    switch ( $code )
                    {
                            $this->_readCodepage( );
                            continue;
                        case self::XLS_Type_DATEMODE :
                            switch ( $code )
                            {
                                    $this->_readDateMode( );
                                    continue;
                                case self::XLS_Type_FONT :
                                    switch ( $code )
                                    {
                                            $this->_readFont( );
                                            continue;
                                        case self::XLS_Type_FORMAT :
                                            switch ( $code )
                                            {
                                                    $this->_readFormat( );
                                                    continue;
                                                case self::XLS_Type_XF :
                                                    switch ( $code )
                                                    {
                                                            $this->_readXf( );
                                                            continue;
                                                        case self::XLS_Type_XFEXT :
                                                            switch ( $code )
                                                            {
                                                                    $this->_readXfExt( );
                                                                    continue;
                                                                case self::XLS_Type_STYLE :
                                                                    switch ( $code )
                                                                    {
                                                                            $this->_readStyle( );
                                                                            continue;
                                                                        case self::XLS_Type_PALETTE :
                                                                            switch ( $code )
                                                                            {
                                                                                    $this->_readPalette( );
                                                                                    continue;
                                                                                case self::XLS_Type_SHEET :
                                                                                    switch ( $code )
                                                                                    {
                                                                                            $this->_readSheet( );
                                                                                            continue;
                                                                                        case self::XLS_Type_EXTERNALBOOK :
                                                                                            switch ( $code )
                                                                                            {
                                                                                                    $this->_readExternalBook( );
                                                                                                    continue;
                                                                                                case self::XLS_Type_EXTERNNAME :
                                                                                                    switch ( $code )
                                                                                                    {
                                                                                                            $this->_readExternName( );
                                                                                                            continue;
                                                                                                        case self::XLS_Type_EXTERNSHEET :
                                                                                                            switch ( $code )
                                                                                                            {
                                                                                                                    $this->_readExternSheet( );
                                                                                                                    continue;
                                                                                                                case self::XLS_Type_DEFINEDNAME :
                                                                                                                    switch ( $code )
                                                                                                                    {
                                                                                                                            $this->_readDefinedName( );
                                                                                                                            continue;
                                                                                                                        case self::XLS_Type_MSODRAWINGGROUP :
                                                                                                                            switch ( $code )
                                                                                                                            {
                                                                                                                                    $this->_readMsoDrawingGroup( );
                                                                                                                                    continue;
                                                                                                                                case self::XLS_Type_SST :
                                                                                                                                    switch ( $code )
                                                                                                                                    {
                                                                                                                                            $this->_readSst( );
                                                                                                                                            continue;
                                                                                                                                            switch ( $code )
                                                                                                                                            {
                                                                                                                                                case self::XLS_Type_EOF :
                                                                                                                                                    $this->_readDefault( );
                                                                                                                                                    break;
                                                                                                                                                default :
                                                                                                                                                    $this->_readDefault( );
                                                                                                                                            }
                                                                                                                                        }
                                                                                                                                        if ( $this->_readDataOnly )
                                                                                                                                        {
                                                                                                                                            foreach ( $this->_objFonts as $objFont )
                                                                                                                                            {
                                                                                                                                                if ( isset( $objFont->colorIndex ) )
                                                                                                                                                {
                                                                                                                                                    $color = ( $objFont->colorIndex, $this->_palette, $this->_version );
                                                                                                                                                    $objFont->getColor( )->setRGB( $color['rgb'] );
                                                                                                                                                }
                                                                                                                                            }
                                                                                                                                            foreach ( $this->_phpExcel->getCellXfCollection( ) as $objStyle )
                                                                                                                                            {
                                                                                                                                                $fill = $objStyle->getFill( );
                                                                                                                                                if ( isset( $fill->startcolorIndex ) )
                                                                                                                                                {
                                                                                                                                                    $startColor = ( $fill->startcolorIndex, $this->_palette, $this->_version );
                                                                                                                                                    $fill->getStartColor( )->setRGB( $startColor['rgb'] );
                                                                                                                                                }
                                                                                                                                                if ( isset( $fill->endcolorIndex ) )
                                                                                                                                                {
                                                                                                                                                    $endColor = ( $fill->endcolorIndex, $this->_palette, $this->_version );
                                                                                                                                                    $fill->getEndColor( )->setRGB( $endColor['rgb'] );
                                                                                                                                                }
                                                                                                                                                $top = $objStyle->getBorders( )->getTop( );
                                                                                                                                                $right = $objStyle->getBorders( )->getRight( );
                                                                                                                                                $bottom = $objStyle->getBorders( )->getBottom( );
                                                                                                                                                $left = $objStyle->getBorders( )->getLeft( );
                                                                                                                                                $diagonal = $objStyle->getBorders( )->getDiagonal( );
                                                                                                                                                if ( isset( $top->colorIndex ) )
                                                                                                                                                {
                                                                                                                                                    $borderTopColor = ( $top->colorIndex, $this->_palette, $this->_version );
                                                                                                                                                    $top->getColor( )->setRGB( $borderTopColor['rgb'] );
                                                                                                                                                }
                                                                                                                                                if ( isset( $right->colorIndex ) )
                                                                                                                                                {
                                                                                                                                                    $borderRightColor = ( $right->colorIndex, $this->_palette, $this->_version );
                                                                                                                                                    $right->getColor( )->setRGB( $borderRightColor['rgb'] );
                                                                                                                                                }
                                                                                                                                                if ( isset( $bottom->colorIndex ) )
                                                                                                                                                {
                                                                                                                                                    $borderBottomColor = ( $bottom->colorIndex, $this->_palette, $this->_version );
                                                                                                                                                    $bottom->getColor( )->setRGB( $borderBottomColor['rgb'] );
                                                                                                                                                }
                                                                                                                                                if ( isset( $left->colorIndex ) )
                                                                                                                                                {
                                                                                                                                                    $borderLeftColor = ( $left->colorIndex, $this->_palette, $this->_version );
                                                                                                                                                    $left->getColor( )->setRGB( $borderLeftColor['rgb'] );
                                                                                                                                                }
                                                                                                                                                if ( isset( $diagonal->colorIndex ) )
                                                                                                                                                {
                                                                                                                                                    $borderDiagonalColor = ( $diagonal->colorIndex, $this->_palette, $this->_version );
                                                                                                                                                    $diagonal->getColor( )->setRGB( $borderDiagonalColor['rgb'] );
                                                                                                                                                }
                                                                                                                                            }
                                                                                                                                        }
                                                                                                                                        if ( !$this->_readDataOnly && $this->_drawingGroupData )
                                                                                                                                        {
                                                                                                                                            $escherWorkbook = new PHPExcel_Shared_Escher( );
                                                                                                                                            $reader = new PHPExcel_Reader_Excel5_Escher( $escherWorkbook );
                                                                                                                                            $escherWorkbook = $this->_drawingGroupData( $this->_drawingGroupData );
                                                                                                                                        }
                                                                                                                                        foreach ( $this->_sheets as $sheet )
                                                                                                                                        {
                                                                                                                                            if ( $sheet['sheetType'] != 0 )
                                                                                                                                            {
                                                                                                                                                continue;
                                                                                                                                            }
                                                                                                                                            else if ( isset( $this->_loadSheetsOnly ) && !in_array( $sheet['name'], $this->_loadSheetsOnly ) )
                                                                                                                                            {
                                                                                                                                            }
                                                                                                                                            else
                                                                                                                                            {
                                                                                                                                                $this->_phpSheet = $this->_phpExcel->createSheet( );
                                                                                                                                                $this->_phpSheet->setTitle( $sheet['name'], FALSE );
                                                                                                                                                $this->_phpSheet->setSheetState( $sheet['sheetState'] );
                                                                                                                                                $this->_pos = $sheet['offset'];
                                                                                                                                                $this->_isFitToPages = FALSE;
                                                                                                                                                $this->_drawingData = "";
                                                                                                                                                $this->_objs = array( );
                                                                                                                                                $this->_sharedFormulaParts = array( );
                                                                                                                                                $this->_sharedFormulas = array( );
                                                                                                                                                $this->_textObjects = array( );
                                                                                                                                                $this->_cellNotes = array( );
                                                                                                                                                $this->textObjRef = -1;
                                                                                                                                        }
                                                                                                                                }
                                                                                                                        }
                                                                                                                }
                                                                                                        }
                                                                                                }
                                                                                        }
                                                                                }
                                                                        }
                                                                }
                                                        }
                                                }
                                        }
                                }
                        }
                }
        }
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
while ( $this->_pos <= $this->_dataSize - 4 )
{
    $code = ( $this->_data, $this->_pos );
case self::XLS_Type_BOF :
    switch ( $code )
    {
            $this->_readBof( );
            continue;
        case self::XLS_Type_PRINTGRIDLINES :
            switch ( $code )
            {
                    $this->_readPrintGridlines( );
                    continue;
                case self::XLS_Type_DEFAULTROWHEIGHT :
                    switch ( $code )
                    {
                            $this->_readDefaultRowHeight( );
                            continue;
                        case self::XLS_Type_SHEETPR :
                            switch ( $code )
                            {
                                    $this->_readSheetPr( );
                                    continue;
                                case self::XLS_Type_HORIZONTALPAGEBREAKS :
                                    switch ( $code )
                                    {
                                            $this->_readHorizontalPageBreaks( );
                                            continue;
                                        case self::XLS_Type_VERTICALPAGEBREAKS :
                                            switch ( $code )
                                            {
                                                    $this->_readVerticalPageBreaks( );
                                                    continue;
                                                case self::XLS_Type_HEADER :
                                                    switch ( $code )
                                                    {
                                                            $this->_readHeader( );
                                                            continue;
                                                        case self::XLS_Type_FOOTER :
                                                            switch ( $code )
                                                            {
                                                                    $this->_readFooter( );
                                                                    continue;
                                                                case self::XLS_Type_HCENTER :
                                                                    switch ( $code )
                                                                    {
                                                                            $this->_readHcenter( );
                                                                            continue;
                                                                        case self::XLS_Type_VCENTER :
                                                                            switch ( $code )
                                                                            {
                                                                                    $this->_readVcenter( );
                                                                                    continue;
                                                                                case self::XLS_Type_LEFTMARGIN :
                                                                                    switch ( $code )
                                                                                    {
                                                                                            $this->_readLeftMargin( );
                                                                                            continue;
                                                                                        case self::XLS_Type_RIGHTMARGIN :
                                                                                            switch ( $code )
                                                                                            {
                                                                                                    $this->_readRightMargin( );
                                                                                                    continue;
                                                                                                case self::XLS_Type_TOPMARGIN :
                                                                                                    switch ( $code )
                                                                                                    {
                                                                                                            $this->_readTopMargin( );
                                                                                                            continue;
                                                                                                        case self::XLS_Type_BOTTOMMARGIN :
                                                                                                            switch ( $code )
                                                                                                            {
                                                                                                                    $this->_readBottomMargin( );
                                                                                                                    continue;
                                                                                                                case self::XLS_Type_PAGESETUP :
                                                                                                                    switch ( $code )
                                                                                                                    {
                                                                                                                            $this->_readPageSetup( );
                                                                                                                            continue;
                                                                                                                        case self::XLS_Type_PROTECT :
                                                                                                                            switch ( $code )
                                                                                                                            {
                                                                                                                                    $this->_readProtect( );
                                                                                                                                    continue;
                                                                                                                                case self::XLS_Type_SCENPROTECT :
                                                                                                                                    switch ( $code )
                                                                                                                                    {
                                                                                                                                            $this->_readScenProtect( );
                                                                                                                                            continue;
                                                                                                                                        case self::XLS_Type_OBJECTPROTECT :
                                                                                                                                            switch ( $code )
                                                                                                                                            {
                                                                                                                                                    $this->_readObjectProtect( );
                                                                                                                                                    continue;
                                                                                                                                                case self::XLS_Type_PASSWORD :
                                                                                                                                                    switch ( $code )
                                                                                                                                                    {
                                                                                                                                                            $this->_readPassword( );
                                                                                                                                                            continue;
                                                                                                                                                        case self::XLS_Type_DEFCOLWIDTH :
                                                                                                                                                            switch ( $code )
                                                                                                                                                            {
                                                                                                                                                                    $this->_readDefColWidth( );
                                                                                                                                                                    continue;
                                                                                                                                                                case self::XLS_Type_COLINFO :
                                                                                                                                                                    switch ( $code )
                                                                                                                                                                    {
                                                                                                                                                                            $this->_readColInfo( );
                                                                                                                                                                            continue;
                                                                                                                                                                        case self::XLS_Type_DIMENSION :
                                                                                                                                                                            switch ( $code )
                                                                                                                                                                            {
                                                                                                                                                                                    $this->_readDefault( );
                                                                                                                                                                                    continue;
                                                                                                                                                                                case self::XLS_Type_ROW :
                                                                                                                                                                                    switch ( $code )
                                                                                                                                                                                    {
                                                                                                                                                                                            $this->_readRow( );
                                                                                                                                                                                            continue;
                                                                                                                                                                                        case self::XLS_Type_DBCELL :
                                                                                                                                                                                            switch ( $code )
                                                                                                                                                                                            {
                                                                                                                                                                                                    $this->_readDefault( );
                                                                                                                                                                                                    continue;
                                                                                                                                                                                                case self::XLS_Type_RK :
                                                                                                                                                                                                    switch ( $code )
                                                                                                                                                                                                    {
                                                                                                                                                                                                            $this->_readRk( );
                                                                                                                                                                                                            continue;
                                                                                                                                                                                                        case self::XLS_Type_LABELSST :
                                                                                                                                                                                                            switch ( $code )
                                                                                                                                                                                                            {
                                                                                                                                                                                                                    $this->_readLabelSst( );
                                                                                                                                                                                                                    continue;
                                                                                                                                                                                                                case self::XLS_Type_MULRK :
                                                                                                                                                                                                                    switch ( $code )
                                                                                                                                                                                                                    {
                                                                                                                                                                                                                            $this->_readMulRk( );
                                                                                                                                                                                                                            continue;
                                                                                                                                                                                                                        case self::XLS_Type_NUMBER :
                                                                                                                                                                                                                            switch ( $code )
                                                                                                                                                                                                                            {
                                                                                                                                                                                                                                    $this->_readNumber( );
                                                                                                                                                                                                                                    continue;
                                                                                                                                                                                                                                case self::XLS_Type_FORMULA :
                                                                                                                                                                                                                                    switch ( $code )
                                                                                                                                                                                                                                    {
                                                                                                                                                                                                                                            $this->_readFormula( );
                                                                                                                                                                                                                                            continue;
                                                                                                                                                                                                                                        case self::XLS_Type_SHAREDFMLA :
                                                                                                                                                                                                                                            switch ( $code )
                                                                                                                                                                                                                                            {
                                                                                                                                                                                                                                                    $this->_readSharedFmla( );
                                                                                                                                                                                                                                                    continue;
                                                                                                                                                                                                                                                case self::XLS_Type_BOOLERR :
                                                                                                                                                                                                                                                    switch ( $code )
                                                                                                                                                                                                                                                    {
                                                                                                                                                                                                                                                            $this->_readBoolErr( );
                                                                                                                                                                                                                                                            continue;
                                                                                                                                                                                                                                                        case self::XLS_Type_MULBLANK :
                                                                                                                                                                                                                                                            switch ( $code )
                                                                                                                                                                                                                                                            {
                                                                                                                                                                                                                                                                    $this->_readMulBlank( );
                                                                                                                                                                                                                                                                    continue;
                                                                                                                                                                                                                                                                case self::XLS_Type_LABEL :
                                                                                                                                                                                                                                                                    switch ( $code )
                                                                                                                                                                                                                                                                    {
                                                                                                                                                                                                                                                                            $this->_readLabel( );
                                                                                                                                                                                                                                                                            continue;
                                                                                                                                                                                                                                                                        case self::XLS_Type_BLANK :
                                                                                                                                                                                                                                                                            switch ( $code )
                                                                                                                                                                                                                                                                            {
                                                                                                                                                                                                                                                                                    $this->_readBlank( );
                                                                                                                                                                                                                                                                                    continue;
                                                                                                                                                                                                                                                                                case self::XLS_Type_MSODRAWING :
                                                                                                                                                                                                                                                                                    switch ( $code )
                                                                                                                                                                                                                                                                                    {
                                                                                                                                                                                                                                                                                            $this->_readMsoDrawing( );
                                                                                                                                                                                                                                                                                            continue;
                                                                                                                                                                                                                                                                                        case self::XLS_Type_OBJ :
                                                                                                                                                                                                                                                                                            switch ( $code )
                                                                                                                                                                                                                                                                                            {
                                                                                                                                                                                                                                                                                                    $this->_readObj( );
                                                                                                                                                                                                                                                                                                    continue;
                                                                                                                                                                                                                                                                                                case self::XLS_Type_WINDOW2 :
                                                                                                                                                                                                                                                                                                    switch ( $code )
                                                                                                                                                                                                                                                                                                    {
                                                                                                                                                                                                                                                                                                            $this->_readWindow2( );
                                                                                                                                                                                                                                                                                                            continue;
                                                                                                                                                                                                                                                                                                        case self::XLS_Type_PAGELAYOUTVIEW :
                                                                                                                                                                                                                                                                                                            switch ( $code )
                                                                                                                                                                                                                                                                                                            {
                                                                                                                                                                                                                                                                                                                    $this->_readPageLayoutView( );
                                                                                                                                                                                                                                                                                                                    continue;
                                                                                                                                                                                                                                                                                                                case self::XLS_Type_SCL :
                                                                                                                                                                                                                                                                                                                    switch ( $code )
                                                                                                                                                                                                                                                                                                                    {
                                                                                                                                                                                                                                                                                                                            $this->_readScl( );
                                                                                                                                                                                                                                                                                                                            continue;
                                                                                                                                                                                                                                                                                                                        case self::XLS_Type_PANE :
                                                                                                                                                                                                                                                                                                                            switch ( $code )
                                                                                                                                                                                                                                                                                                                            {
                                                                                                                                                                                                                                                                                                                                    $this->_readPane( );
                                                                                                                                                                                                                                                                                                                                    continue;
                                                                                                                                                                                                                                                                                                                                case self::XLS_Type_SELECTION :
                                                                                                                                                                                                                                                                                                                                    switch ( $code )
                                                                                                                                                                                                                                                                                                                                    {
                                                                                                                                                                                                                                                                                                                                            $this->_readSelection( );
                                                                                                                                                                                                                                                                                                                                            continue;
                                                                                                                                                                                                                                                                                                                                        case self::XLS_Type_MERGEDCELLS :
                                                                                                                                                                                                                                                                                                                                            switch ( $code )
                                                                                                                                                                                                                                                                                                                                            {
                                                                                                                                                                                                                                                                                                                                                    $this->_readMergedCells( );
                                                                                                                                                                                                                                                                                                                                                    continue;
                                                                                                                                                                                                                                                                                                                                                case self::XLS_Type_HYPERLINK :
                                                                                                                                                                                                                                                                                                                                                    switch ( $code )
                                                                                                                                                                                                                                                                                                                                                    {
                                                                                                                                                                                                                                                                                                                                                            $this->_readHyperLink( );
                                                                                                                                                                                                                                                                                                                                                            continue;
                                                                                                                                                                                                                                                                                                                                                        case self::XLS_Type_DATAVALIDATIONS :
                                                                                                                                                                                                                                                                                                                                                            switch ( $code )
                                                                                                                                                                                                                                                                                                                                                            {
                                                                                                                                                                                                                                                                                                                                                                    $this->_readDataValidations( );
                                                                                                                                                                                                                                                                                                                                                                    continue;
                                                                                                                                                                                                                                                                                                                                                                case self::XLS_Type_DATAVALIDATION :
                                                                                                                                                                                                                                                                                                                                                                    switch ( $code )
                                                                                                                                                                                                                                                                                                                                                                    {
                                                                                                                                                                                                                                                                                                                                                                            $this->_readDataValidation( );
                                                                                                                                                                                                                                                                                                                                                                            continue;
                                                                                                                                                                                                                                                                                                                                                                        case self::XLS_Type_SHEETLAYOUT :
                                                                                                                                                                                                                                                                                                                                                                            switch ( $code )
                                                                                                                                                                                                                                                                                                                                                                            {
                                                                                                                                                                                                                                                                                                                                                                                    $this->_readSheetLayout( );
                                                                                                                                                                                                                                                                                                                                                                                    continue;
                                                                                                                                                                                                                                                                                                                                                                                case self::XLS_Type_SHEETPROTECTION :
                                                                                                                                                                                                                                                                                                                                                                                    switch ( $code )
                                                                                                                                                                                                                                                                                                                                                                                    {
                                                                                                                                                                                                                                                                                                                                                                                            $this->_readSheetProtection( );
                                                                                                                                                                                                                                                                                                                                                                                            continue;
                                                                                                                                                                                                                                                                                                                                                                                        case self::XLS_Type_RANGEPROTECTION :
                                                                                                                                                                                                                                                                                                                                                                                            switch ( $code )
                                                                                                                                                                                                                                                                                                                                                                                            {
                                                                                                                                                                                                                                                                                                                                                                                                    $this->_readRangeProtection( );
                                                                                                                                                                                                                                                                                                                                                                                                    continue;
                                                                                                                                                                                                                                                                                                                                                                                                case self::XLS_Type_NOTE :
                                                                                                                                                                                                                                                                                                                                                                                                    switch ( $code )
                                                                                                                                                                                                                                                                                                                                                                                                    {
                                                                                                                                                                                                                                                                                                                                                                                                            $this->_readNote( );
                                                                                                                                                                                                                                                                                                                                                                                                            continue;
                                                                                                                                                                                                                                                                                                                                                                                                        case self::XLS_Type_TXO :
                                                                                                                                                                                                                                                                                                                                                                                                            switch ( $code )
                                                                                                                                                                                                                                                                                                                                                                                                            {
                                                                                                                                                                                                                                                                                                                                                                                                                    $this->_readTextObject( );
                                                                                                                                                                                                                                                                                                                                                                                                                    continue;
                                                                                                                                                                                                                                                                                                                                                                                                                case self::XLS_Type_CONTINUE :
                                                                                                                                                                                                                                                                                                                                                                                                                    switch ( $code )
                                                                                                                                                                                                                                                                                                                                                                                                                    {
                                                                                                                                                                                                                                                                                                                                                                                                                            $this->_readContinue( );
                                                                                                                                                                                                                                                                                                                                                                                                                            continue;
                                                                                                                                                                                                                                                                                                                                                                                                                            switch ( $code )
                                                                                                                                                                                                                                                                                                                                                                                                                            {
                                                                                                                                                                                                                                                                                                                                                                                                                                case self::XLS_Type_EOF :
                                                                                                                                                                                                                                                                                                                                                                                                                                    $this->_readDefault( );
                                                                                                                                                                                                                                                                                                                                                                                                                                    break;
                                                                                                                                                                                                                                                                                                                                                                                                                                default :
                                                                                                                                                                                                                                                                                                                                                                                                                                    $this->_readDefault( );
                                                                                                                                                                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                                                                                                                                        if ( !$this->_readDataOnly && $this->_drawingData )
                                                                                                                                                                                                                                                                                                                                                                                                                        {
                                                                                                                                                                                                                                                                                                                                                                                                                            $escherWorksheet = new PHPExcel_Shared_Escher( );
                                                                                                                                                                                                                                                                                                                                                                                                                            $reader = new PHPExcel_Reader_Excel5_Escher( $escherWorksheet );
                                                                                                                                                                                                                                                                                                                                                                                                                            $escherWorksheet = $this->_drawingData( $this->_drawingData );
                                                                                                                                                                                                                                                                                                                                                                                                                            $allSpContainers = $escherWorksheet->getDgContainer( )->getSpgrContainer( )->getAllSpContainers( );
                                                                                                                                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                                                                                                                                        foreach ( $this->_objs as $n => $obj )
                                                                                                                                                                                                                                                                                                                                                                                                                        {
                                                                                                                                                                                                                                                                                                                                                                                                                            if ( !isset( $allSpContainers[$n + 1] ) || !is_object( $allSpContainers[$n + 1] ) )
                                                                                                                                                                                                                                                                                                                                                                                                                            {
                                                                                                                                                                                                                                                                                                                                                                                                                                $spContainer = $allSpContainers[$n + 1];
                                                                                                                                                                                                                                                                                                                                                                                                                                if ( 1 < $spContainer->getNestingLevel( ) )
                                                                                                                                                                                                                                                                                                                                                                                                                                {
                                                                                                                                                                                                                                                                                                                                                                                                                                    $startRow = ( $spContainer->getStartCoordinates( ) )[1];
                                                                                                                                                                                                                                                                                                                                                                                                                                    $startColumn = ( $spContainer->getStartCoordinates( ) )[0];
                                                                                                                                                                                                                                                                                                                                                                                                                                    $endRow = ( $spContainer->getEndCoordinates( ) )[1];
                                                                                                                                                                                                                                                                                                                                                                                                                                    $endColumn = ( $spContainer->getEndCoordinates( ) )[0];
                                                                                                                                                                                                                                                                                                                                                                                                                                    $startOffsetX = $spContainer->getStartOffsetX( );
                                                                                                                                                                                                                                                                                                                                                                                                                                    $startOffsetY = $spContainer->getStartOffsetY( );
                                                                                                                                                                                                                                                                                                                                                                                                                                    $endOffsetX = $spContainer->getEndOffsetX( );
                                                                                                                                                                                                                                                                                                                                                                                                                                    $endOffsetY = $spContainer->getEndOffsetY( );
                                                                                                                                                                                                                                                                                                                                                                                                                                    $width = ( $this->_phpSheet, $startColumn, $startOffsetX, $endColumn, $endOffsetX );
                                                                                                                                                                                                                                                                                                                                                                                                                                    $height = ( $this->_phpSheet, $startRow, $startOffsetY, $endRow, $endOffsetY );
                                                                                                                                                                                                                                                                                                                                                                                                                                    $offsetX = $startOffsetX * ( $this->_phpSheet, $startColumn ) / 1024;
                                                                                                                                                                                                                                                                                                                                                                                                                                    $offsetY = $startOffsetY * ( $this->_phpSheet, $startRow ) / 256;
                                                                                                                                                                                                                                                                                                                                                                                                                                    switch ( $obj['otObjType'] )
                                                                                                                                                                                                                                                                                                                                                                                                                                    {
                                                                                                                                                                                                                                                                                                                                                                                                                                        case 25 :
                                                                                                                                                                                                                                                                                                                                                                                                                                            if ( isset( $this->_cellNotes[$obj['idObjID']] ) )
                                                                                                                                                                                                                                                                                                                                                                                                                                            {
                                                                                                                                                                                                                                                                                                                                                                                                                                                $cellNote = $this->_cellNotes[$obj['idObjID']];
                                                                                                                                                                                                                                                                                                                                                                                                                                                if ( isset( $this->_textObjects[$obj['idObjID']] ) )
                                                                                                                                                                                                                                                                                                                                                                                                                                                {
                                                                                                                                                                                                                                                                                                                                                                                                                                                    $textObject = $this->_textObjects[$obj['idObjID']];
                                                                                                                                                                                                                                                                                                                                                                                                                                                    $this->_cellNotes[$obj['idObjID']]['objTextData'] = $textObject;
                                                                                                                                                                                                                                                                                                                                                                                                                                                    break;
                                                                                                                                                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                                                                                                                                                                                        case 8 :
                                                                                                                                                                                                                                                                                                                                                                                                                                            $BSEindex = $spContainer->getOPT( 260 );
                                                                                                                                                                                                                                                                                                                                                                                                                                            $BSECollection = $escherWorkbook->getDggContainer( )->getBstoreContainer( )->getBSECollection( );
                                                                                                                                                                                                                                                                                                                                                                                                                                            $BSE = $BSECollection[$BSEindex - 1];
                                                                                                                                                                                                                                                                                                                                                                                                                                            $blipType = $BSE->getBlipType( );
                                                                                                                                                                                                                                                                                                                                                                                                                                            if ( $blip = $BSE->getBlip( ) )
                                                                                                                                                                                                                                                                                                                                                                                                                                            {
                                                                                                                                                                                                                                                                                                                                                                                                                                                $ih = imagecreatefromstring( $blip->getData( ) );
                                                                                                                                                                                                                                                                                                                                                                                                                                                $drawing = new PHPExcel_Worksheet_MemoryDrawing( );
                                                                                                                                                                                                                                                                                                                                                                                                                                                $drawing->setImageResource( $ih );
                                                                                                                                                                                                                                                                                                                                                                                                                                                $drawing->setResizeProportional( FALSE );
                                                                                                                                                                                                                                                                                                                                                                                                                                                $drawing->setWidth( $width );
                                                                                                                                                                                                                                                                                                                                                                                                                                                $drawing->setHeight( $height );
                                                                                                                                                                                                                                                                                                                                                                                                                                                $drawing->setOffsetX( $offsetX );
                                                                                                                                                                                                                                                                                                                                                                                                                                                $drawing->setOffsetY( $offsetY );
                                                                                                                                                                                                                                                                                                                                                                                                                                                switch ( $blipType )
                                                                                                                                                                                                                                                                                                                                                                                                                                                {
                                                                                                                                                                                                                                                                                                                                                                                                                                                    case PHPExcel_Shared_Escher_DggContainer_BstoreContainer_BSE::BLIPTYPE_JPEG :
                                                                                                                                                                                                                                                                                                                                                                                                                                                        $drawing->setRenderingFunction( PHPExcel_Worksheet_MemoryDrawing::RENDERING_JPEG );
                                                                                                                                                                                                                                                                                                                                                                                                                                                        $drawing->setMimeType( PHPExcel_Worksheet_MemoryDrawing::MIMETYPE_JPEG );
                                                                                                                                                                                                                                                                                                                                                                                                                                                        break;
                                                                                                                                                                                                                                                                                                                                                                                                                                                    case PHPExcel_Shared_Escher_DggContainer_BstoreContainer_BSE::BLIPTYPE_PNG :
                                                                                                                                                                                                                                                                                                                                                                                                                                                        $drawing->setRenderingFunction( PHPExcel_Worksheet_MemoryDrawing::RENDERING_PNG );
                                                                                                                                                                                                                                                                                                                                                                                                                                                        $drawing->setMimeType( PHPExcel_Worksheet_MemoryDrawing::MIMETYPE_PNG );
                                                                                                                                                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                                                                                                                                                                $this->_phpSheet( $this->_phpSheet );
                                                                                                                                                                                                                                                                                                                                                                                                                                                $drawing->setCoordinates( $spContainer->getStartCoordinates( ) );
                                                                                                                                                                                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                                                                                                                                        if ( $this->_version == self::XLS_BIFF8 )
                                                                                                                                                                                                                                                                                                                                                                                                                        {
                                                                                                                                                                                                                                                                                                                                                                                                                            foreach ( $this->_sharedFormulaParts as $cell => $baseCell )
                                                                                                                                                                                                                                                                                                                                                                                                                            {
                                                                                                                                                                                                                                                                                                                                                                                                                                $row = ( $cell )[1];
                                                                                                                                                                                                                                                                                                                                                                                                                                $column = ( $cell )[0];
                                                                                                                                                                                                                                                                                                                                                                                                                                if ( !( $this->getReadFilter( ) !== NULL ) || !$this->getReadFilter( )->readCell( $column, $row, $this->_phpSheet->getTitle( ) ) )
                                                                                                                                                                                                                                                                                                                                                                                                                                {
                                                                                                                                                                                                                                                                                                                                                                                                                                    $formula = $this->_sharedFormulas[$baseCell]( $this->_sharedFormulas[$baseCell], $cell );
                                                                                                                                                                                                                                                                                                                                                                                                                                    $this->_phpSheet->getCell( $cell )->setValueExplicit( "=".$formula, PHPExcel_Cell_DataType::TYPE_FORMULA );
                                                                                                                                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                                                                                                                                        if ( empty( $this->_cellNotes ) )
                                                                                                                                                                                                                                                                                                                                                                                                                        {
                                                                                                                                                                                                                                                                                                                                                                                                                            foreach ( $this->_cellNotes as $note => $noteDetails )
                                                                                                                                                                                                                                                                                                                                                                                                                            {
                                                                                                                                                                                                                                                                                                                                                                                                                                if ( isset( $noteDetails['objTextData'] ) )
                                                                                                                                                                                                                                                                                                                                                                                                                                {
                                                                                                                                                                                                                                                                                                                                                                                                                                    if ( isset( $this->_textObjects[$note] ) )
                                                                                                                                                                                                                                                                                                                                                                                                                                    {
                                                                                                                                                                                                                                                                                                                                                                                                                                        $textObject = $this->_textObjects[$note];
                                                                                                                                                                                                                                                                                                                                                                                                                                        $noteDetails['objTextData'] = $textObject;
                                                                                                                                                                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                                                                                                                                                    else
                                                                                                                                                                                                                                                                                                                                                                                                                                    {
                                                                                                                                                                                                                                                                                                                                                                                                                                        $noteDetails['objTextData']['text'] = "";
                                                                                                                                                                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                                                                                                                                                $cellAddress = str_replace( "\$", "", $noteDetails['cellRef'] );
                                                                                                                                                                                                                                                                                                                                                                                                                                $this->_phpSheet->getComment( $cellAddress )->setAuthor( $noteDetails['author'] )->setText( $noteDetails['objTextData']['text']( $noteDetails['objTextData']['text'] ) );
                                                                                                                                                                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                                                                                                                                foreach ( $this->_definedname as $definedName )
                                                                                                                                                                                                                                                                                                                                                                                                                {
                                                                                                                                                                                                                                                                                                                                                                                                                    if ( $definedName['isBuiltInName'] )
                                                                                                                                                                                                                                                                                                                                                                                                                    {
                                                                                                                                                                                                                                                                                                                                                                                                                        switch ( $definedName['name'] )
                                                                                                                                                                                                                                                                                                                                                                                                                        {
                                                                                                                                                                                                                                                                                                                                                                                                                            case pack( "C", 6 ) :
                                                                                                                                                                                                                                                                                                                                                                                                                                $ranges = explode( ",", $definedName['formula'] );
                                                                                                                                                                                                                                                                                                                                                                                                                                $extractedRanges = array( );
                                                                                                                                                                                                                                                                                                                                                                                                                                foreach ( $ranges as $range )
                                                                                                                                                                                                                                                                                                                                                                                                                                {
                                                                                                                                                                                                                                                                                                                                                                                                                                    $explodes = explode( "!", $range );
                                                                                                                                                                                                                                                                                                                                                                                                                                    $sheetName = trim( $explodes[0], "'" );
                                                                                                                                                                                                                                                                                                                                                                                                                                    if ( count( $explodes ) == 2 )
                                                                                                                                                                                                                                                                                                                                                                                                                                    {
                                                                                                                                                                                                                                                                                                                                                                                                                                        if ( strpos( $explodes[1], ":" ) === FALSE )
                                                                                                                                                                                                                                                                                                                                                                                                                                        {
                                                                                                                                                                                                                                                                                                                                                                                                                                            $explodes[1] = $explodes[1].":".$explodes[1];
                                                                                                                                                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                                                                                                                                                        $extractedRanges[] = str_replace( "\$", "", $explodes[1] );
                                                                                                                                                                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                                                                                                                                                if ( $docSheet = $this->_phpExcel->getSheetByName( $sheetName ) )
                                                                                                                                                                                                                                                                                                                                                                                                                                {
                                                                                                                                                                                                                                                                                                                                                                                                                                    $docSheet->getPageSetup( )->setPrintArea( implode( ",", $extractedRanges ) );
                                                                                                                                                                                                                                                                                                                                                                                                                                    break;
                                                                                                                                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                                                                                                                                            case pack( "C", 7 ) :
                                                                                                                                                                                                                                                                                                                                                                                                                                $ranges = explode( ",", $definedName['formula'] );
                                                                                                                                                                                                                                                                                                                                                                                                                                foreach ( $ranges as $range )
                                                                                                                                                                                                                                                                                                                                                                                                                                {
                                                                                                                                                                                                                                                                                                                                                                                                                                    $explodes = explode( "!", $range );
                                                                                                                                                                                                                                                                                                                                                                                                                                    if ( !( count( $explodes ) == 2 ) || !( $docSheet = $this->_phpExcel->getSheetByName( $explodes[0] ) ) )
                                                                                                                                                                                                                                                                                                                                                                                                                                    {
                                                                                                                                                                                                                                                                                                                                                                                                                                        $extractedRange = $explodes[1];
                                                                                                                                                                                                                                                                                                                                                                                                                                        $extractedRange = str_replace( "\$", "", $extractedRange );
                                                                                                                                                                                                                                                                                                                                                                                                                                        $coordinateStrings = explode( ":", $extractedRange );
                                                                                                                                                                                                                                                                                                                                                                                                                                        if ( !( count( $coordinateStrings ) == 2 ) )
                                                                                                                                                                                                                                                                                                                                                                                                                                        {
                                                                                                                                                                                                                                                                                                                                                                                                                                            continue;
                                                                                                                                                                                                                                                                                                                                                                                                                                            $firstRow = ( $coordinateStrings[0] )[1];
                                                                                                                                                                                                                                                                                                                                                                                                                                            $firstColumn = ( $coordinateStrings[0] )[0];
                                                                                                                                                                                                                                                                                                                                                                                                                                            $lastRow = ( $coordinateStrings[1] )[1];
                                                                                                                                                                                                                                                                                                                                                                                                                                            $lastColumn = ( $coordinateStrings[1] )[0];
                                                                                                                                                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                                                                                                                                                        else if ( $firstColumn == "A" && $lastColumn == "IV" )
                                                                                                                                                                                                                                                                                                                                                                                                                                        {
                                                                                                                                                                                                                                                                                                                                                                                                                                            $docSheet->getPageSetup( )->setRowsToRepeatAtTop( array( $firstRow, $lastRow ) );
                                                                                                                                                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                                                                                                                                                        else if ( !( $firstRow == 1 ) || !( $lastRow == 65536 ) )
                                                                                                                                                                                                                                                                                                                                                                                                                                        {
                                                                                                                                                                                                                                                                                                                                                                                                                                            $docSheet->getPageSetup( )->setColumnsToRepeatAtLeft( array( $firstColumn, $lastColumn ) );
                                                                                                                                                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                                                                                                                                    else
                                                                                                                                                                                                                                                                                                                                                                                                                    {
                                                                                                                                                                                                                                                                                                                                                                                                                        $explodes = explode( "!", $definedName['formula'] );
                                                                                                                                                                                                                                                                                                                                                                                                                        if ( !( count( $explodes ) == 2 ) || !( $docSheet = $this->_phpExcel->getSheetByName( $explodes[0] ) ) && !( $docSheet = $this->_phpExcel->getSheetByName( trim( $explodes[0], "'" ) ) ) )
                                                                                                                                                                                                                                                                                                                                                                                                                        {
                                                                                                                                                                                                                                                                                                                                                                                                                            $extractedRange = $explodes[1];
                                                                                                                                                                                                                                                                                                                                                                                                                            $extractedRange = str_replace( "\$", "", $extractedRange );
                                                                                                                                                                                                                                                                                                                                                                                                                            $localOnly = TRUE;
                                                                                                                                                                                                                                                                                                                                                                                                                            $scope = $definedName['scope'] == 0 ? NULL : $this->_sheets[$definedName['scope'] - 1]( $this->_sheets[$definedName['scope'] - 1]['name'] );
                                                                                                                                                                                                                                                                                                                                                                                                                            $this->_phpExcel->addNamedRange( new PHPExcel_NamedRange( ( boolean ), $docSheet, $extractedRange, $localOnly, $scope ) );
                                                                                                                                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                                                                                                                                return $this->_phpExcel;
                                                                                                                                                                                                                                                                                                                                                                                                            }

    private function _loadOLE( $pFilename )
    {
        $ole = new PHPExcel_Shared_OLERead( );
        $res = $ole->read( $pFilename );
        $this->_data = $ole->wrkbook( $ole->wrkbook );
        $this->_summaryInformation = $ole->summaryInformation( $ole->summaryInformation );
        $this->_documentSummaryInformation = $ole->documentSummaryInformation( $ole->documentSummaryInformation );
    }

    private function _readSummaryInformation( )
    {
        if ( isset( $this->_summaryInformation ) )
        {
        }
        else
        {
            $secCount = ( $this->_summaryInformation, 24 );
            $secOffset = ( $this->_summaryInformation, 44 );
            $secLength = ( $this->_summaryInformation, $secOffset );
            $countProperties = ( $this->_summaryInformation, $secOffset + 4 );
            $codePage = "CP1252";
            $i = 0;
            for ( ; $i < $countProperties; }
 }
 }
 }
 }
 }
 }
 }
 ++$i )
{
    $id = ( $this->_summaryInformation, $secOffset + 8 + 8 * $i );
    $offset = ( $this->_summaryInformation, $secOffset + 12 + 8 * $i );
    $type = ( $this->_summaryInformation, $secOffset + $offset );
    $value = NULL;
    switch ( $type )
    {
        case 2 :
            $value = ( $this->_summaryInformation, $secOffset + 4 + $offset );
        case 3 :
            $value = ( $this->_summaryInformation, $secOffset + 4 + $offset );
        case 19 :
        case 30 :
            $byteLength = ( $this->_summaryInformation, $secOffset + 4 + $offset );
            $value = substr( $this->_summaryInformation, $secOffset + 8 + $offset, $byteLength );
            $value = ( $value, "UTF-8", $codePage );
            $value = rtrim( $value );
        case 64 :
            $value = ( substr( $this->_summaryInformation, $secOffset + 4 + $offset, 8 ) );
        default :
        case 71 :
            if ( $secOffset + $offset )
            {
                $codePage = ( $value );
            }
            else
            {
            case 2 :
                switch ( $id )
                {
                        $this->_phpExcel->getProperties( )->setTitle( $value );
                        continue;
                        break;
                    case 3 :
                        switch ( $id )
                        {
                                $this->_phpExcel->getProperties( )->setSubject( $value );
                                continue;
                                break;
                            case 4 :
                                switch ( $id )
                                {
                                        $this->_phpExcel->getProperties( )->setCreator( $value );
                                        continue;
                                        break;
                                    case 5 :
                                        switch ( $id )
                                        {
                                                $this->_phpExcel->getProperties( )->setKeywords( $value );
                                                continue;
                                                break;
                                            case 6 :
                                                switch ( $id )
                                                {
                                                        $this->_phpExcel->getProperties( )->setDescription( $value );
                                                        continue;
                                                        break;
                                                        switch ( $id )
                                                        {
                                                            case 7 :
                                                            case 8 :
                                                                $this->_phpExcel->getProperties( )->setLastModifiedBy( $value );
                                                                continue;
                                                                break;
                                                                switch ( $id )
                                                                {
                                                                    case 9 :
                                                                    case 10 :
                                                                    case 11 :
                                                                    case 12 :
                                                                        $this->_phpExcel->getProperties( )->setCreated( $value );
                                                                        continue;
                                                                        break;
                                                                    case 13 :
                                                                        switch ( $id )
                                                                        {
                                                                                $this->_phpExcel->getProperties( )->setModified( $value );
                                                                                continue;
                                                                                break;
                                                                            case 14 :
                                                                            case 15 :
                                                                            case 16 :
                                                                            case 17 :
                                                                            case 18 :
                                                                            }
                                                                        }
                                                                }
                                                            }
                                                        }

    private function _readDocumentSummaryInformation( )
    {
        if ( isset( $this->_documentSummaryInformation ) )
        {
        }
        else
        {
            $secCount = ( $this->_documentSummaryInformation, 24 );
            $secOffset = ( $this->_documentSummaryInformation, 44 );
            $secLength = ( $this->_documentSummaryInformation, $secOffset );
            $countProperties = ( $this->_documentSummaryInformation, $secOffset + 4 );
            $codePage = "CP1252";
            $i = 0;
            for ( ; $i < $countProperties; }
 }
 }
 ++$i )
{
    $id = ( $this->_documentSummaryInformation, $secOffset + 8 + 8 * $i );
    $offset = ( $this->_documentSummaryInformation, $secOffset + 12 + 8 * $i );
    $type = ( $this->_documentSummaryInformation, $secOffset + $offset );
    $value = NULL;
    switch ( $type )
    {
        case 2 :
            $value = ( $this->_documentSummaryInformation, $secOffset + 4 + $offset );
        case 3 :
            $value = ( $this->_documentSummaryInformation, $secOffset + 4 + $offset );
        case 11 :
            $value = ( $this->_documentSummaryInformation, $secOffset + 4 + $offset );
            $value = TRUE;
        case 19 :
        case 30 :
            $byteLength = ( $this->_documentSummaryInformation, $secOffset + 4 + $offset );
            $value = substr( $this->_documentSummaryInformation, $secOffset + 8 + $offset, $byteLength );
            $value = ( $value, "UTF-8", $codePage );
            $value = rtrim( $value );
        case 64 :
            $value = ( substr( $this->_documentSummaryInformation, $secOffset + 4 + $offset, 8 ) );
        default :
        case 71 :
            if ( $secOffset + $offset )
            {
                $codePage = ( $value );
            }
            else
            {
            case 2 :
                switch ( $id )
                {
                        $this->_phpExcel->getProperties( )->setCategory( $value );
                        continue;
                        break;
                        switch ( $id )
                        {
                            case 3 :
                            case 4 :
                            case 5 :
                            case 6 :
                            case 7 :
                            case 8 :
                            case 9 :
                            case 10 :
                            case 11 :
                            case 12 :
                            case 13 :
                            case 14 :
                                $this->_phpExcel->getProperties( )->setManager( $value );
                                continue;
                                break;
                            case 15 :
                                switch ( $id )
                                {
                                        $this->_phpExcel->getProperties( )->setCompany( $value );
                                        continue;
                                        break;
                                    }
                                }
                        }
                    }
                }

    private function _readDefault( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $ && _775855072 += "_pos";
    }

    private function _readNote( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _723988824 += "_pos";
        if ( $this->_readDataOnly )
        {
        }
        else
        {
            $cellAddress = substr( $recordData, 0, 4 )( substr( $recordData, 0, 4 ) );
            if ( $this->_version == self::XLS_BIFF8 )
            {
                $noteObjID = ( $recordData, 6 );
                $noteAuthor = ( substr( $recordData, 8 ) );
                $noteAuthor = $noteAuthor['value'];
                $this->_cellNotes[$noteObjID] = array( "cellRef" => $cellAddress, "objectID" => $noteObjID, "author" => $noteAuthor );
            }
            else
            {
                $extension = FALSE;
                if ( $cellAddress == "\$B$65536" )
                {
                    $row = ( $recordData, 0 );
                    $extension = TRUE;
                    $cellAddress = array_pop( array_keys( $this->_phpSheet->getComments( ) ) );
                }
                $cellAddress = str_replace( "\$", "", $cellAddress );
                $noteLength = ( $recordData, 4 );
                $noteText = trim( substr( $recordData, 6 ) );
                if ( $extension )
                {
                    $comment = $this->_phpSheet->getComment( $cellAddress );
                    $commentText = $comment->getText( )->getPlainText( );
                    $comment->setText( $this->_parseRichText( $commentText.$noteText ) );
                }
                else
                {
                    $this->_phpSheet->getComment( $cellAddress )->setText( $this->_parseRichText( $noteText ) );
                }
            }
        }
    }

    private function _readTextObject( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _723994720 += "_pos";
        if ( $this->_readDataOnly )
        {
        }
        else
        {
            $grbitOpts = ( $recordData, 0 );
            $rot = ( $recordData, 2 );
            $cchText = ( $recordData, 10 );
            $cbRuns = ( $recordData, 12 );
            $text = $this->_getSplicedRecordData( );
            $this->_textObjects[$this->textObjRef] = array( "text" => substr( $text['recordData'], $text['spliceOffsets'][0] + 1, $cchText ), "format" => substr( $text['recordData'], $text['spliceOffsets'][1], $cbRuns ), "alignment" => $grbitOpts, "rotation" => $rot );
        }
    }

    private function _readBof( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _775854528 += "_pos";
        $substreamType = ( $recordData, 2 );
        switch ( $substreamType )
        {
            case self::XLS_WorkbookGlobals :
                $version = ( $recordData, 0 );
                if ( $version != self::XLS_BIFF8 )
                {
                    if ( $version != self::XLS_BIFF7 )
                    {
                        throw new PHPExcel_Reader_Exception( "Cannot read this Excel file. Version is too old." );
                    }
                }
                $this->_version = $version;
                return;
        }
        switch ( $substreamType )
        {
            case self::XLS_Worksheet :
                do
                {
                    $code = ( $this->_data, $this->_pos );
                    $this->_readDefault( );
                } while ( $code != self::XLS_Type_EOF && $this->_pos < $this->_dataSize );
        }
    }

    private function _readFilepass( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $ && _737126864 += "_pos";
        throw new PHPExcel_Reader_Exception( "Cannot read encrypted file" );
    }

    private function _readCodepage( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _775854656 += "_pos";
        $codepage = ( $recordData, 0 );
        $this->_codepage = ( $codepage );
    }

    private function _readDateMode( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _737127056 += "_pos";
        ( PHPExcel_Shared_Date::CALENDAR_WINDOWS_1900 );
        if ( ord( $recordData[0] ) == 1 )
        {
            ( PHPExcel_Shared_Date::CALENDAR_MAC_1904 );
        }
    }

    private function _readFont( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _723994160 += "_pos";
        if ( $this->_readDataOnly )
        {
            $objFont = new PHPExcel_Style_Font( );
            $size = ( $recordData, 0 );
            $objFont->setSize( $size / 20 );
            $isItalic = ( 2 & ( $recordData, 2 ) ) >> 1;
            if ( $isItalic )
            {
                $objFont->setItalic( TRUE );
            }
            $isStrike = ( 8 & ( $recordData, 2 ) ) >> 3;
            if ( $isStrike )
            {
                $objFont->setStrikethrough( TRUE );
            }
            $colorIndex = ( $recordData, 4 );
            $objFont->colorIndex = $colorIndex;
            $weight = ( $recordData, 6 );
            switch ( $weight )
            {
                case 700 :
                    $objFont->setBold( TRUE );
            }
            $escapement = ( $recordData, 8 );
            switch ( $escapement )
            {
                case 1 :
                    $objFont->setSuperScript( TRUE );
                    break;
                case 2 :
                    $objFont->setSubScript( TRUE );
            }
            $underlineType = ord( $recordData[10] );
            switch ( $underlineType )
            {
                case 0 :
                case 1 :
                    $objFont->setUnderline( PHPExcel_Style_Font::UNDERLINE_SINGLE );
                    break;
                case 2 :
                    $objFont->setUnderline( PHPExcel_Style_Font::UNDERLINE_DOUBLE );
                    break;
                case 33 :
                    $objFont->setUnderline( PHPExcel_Style_Font::UNDERLINE_SINGLEACCOUNTING );
                    break;
                case 34 :
                    $objFont->setUnderline( PHPExcel_Style_Font::UNDERLINE_DOUBLEACCOUNTING );
            }
            if ( $this->_version == self::XLS_BIFF8 )
            {
                $string = ( substr( $recordData, 14 ) );
            }
            else
            {
                $string = substr( $recordData, 14 )( substr( $recordData, 14 ) );
            }
            $string['value']( $string['value'] );
            $this->_objFonts[] = $objFont;
        }
    }

    private function _readFormat( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _775855232 += "_pos";
        if ( $this->_readDataOnly )
        {
            $indexCode = ( $recordData, 0 );
            if ( $this->_version == self::XLS_BIFF8 )
            {
                $string = ( substr( $recordData, 2 ) );
            }
            else
            {
                $string = substr( $recordData, 2 )( substr( $recordData, 2 ) );
            }
            $formatString = $string['value'];
            $this->_formats[$indexCode] = $formatString;
        }
    }

    private function _readXf( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _775855216 += "_pos";
        $objStyle = new PHPExcel_Style( );
        if ( $this->_readDataOnly )
        {
            if ( ( $recordData, 0 ) < 4 )
            {
                $fontIndex = ( $recordData, 0 );
            }
            else
            {
                $fontIndex = ( $recordData, 0 ) - 1;
            }
            $this->_objFonts[$fontIndex]( $this->_objFonts[$fontIndex] );
            $numberFormatIndex = ( $recordData, 2 );
            if ( isset( $this->_formats[$numberFormatIndex] ) )
            {
                $numberformat = array( "code" => $this->_formats[$numberFormatIndex] );
            }
            else if ( ( $code = ( $numberFormatIndex ) ) !== "" )
            {
                $numberformat = array( "code" => $code );
            }
            else
            {
                $numberformat = array( "code" => "General" );
            }
            $objStyle->getNumberFormat( )->setFormatCode( $numberformat['code'] );
            $xfTypeProt = ( $recordData, 4 );
            $isLocked = ( 1 & $xfTypeProt ) >> 0;
            $objStyle->getProtection( )->setLocked( $isLocked ? PHPExcel_Style_Protection::PROTECTION_INHERIT : PHPExcel_Style_Protection::PROTECTION_UNPROTECTED );
            $isHidden = ( 2 & $xfTypeProt ) >> 1;
            $objStyle->getProtection( )->setHidden( $isHidden ? PHPExcel_Style_Protection::PROTECTION_PROTECTED : PHPExcel_Style_Protection::PROTECTION_UNPROTECTED );
            $isCellStyleXf = ( 4 & $xfTypeProt ) >> 2;
            $horAlign = ( 7 & ord( $recordData[6] ) ) >> 0;
            switch ( $horAlign )
            {
                case 0 :
                    $objStyle->getAlignment( )->setHorizontal( PHPExcel_Style_Alignment::HORIZONTAL_GENERAL );
                    break;
                case 1 :
                    $objStyle->getAlignment( )->setHorizontal( PHPExcel_Style_Alignment::HORIZONTAL_LEFT );
                    break;
                case 2 :
                    $objStyle->getAlignment( )->setHorizontal( PHPExcel_Style_Alignment::HORIZONTAL_CENTER );
                    break;
                case 3 :
                    $objStyle->getAlignment( )->setHorizontal( PHPExcel_Style_Alignment::HORIZONTAL_RIGHT );
                    break;
                case 5 :
                    $objStyle->getAlignment( )->setHorizontal( PHPExcel_Style_Alignment::HORIZONTAL_JUSTIFY );
                    break;
                case 6 :
                    $objStyle->getAlignment( )->setHorizontal( PHPExcel_Style_Alignment::HORIZONTAL_CENTER_CONTINUOUS );
            }
            $wrapText = ( 8 & ord( $recordData[6] ) ) >> 3;
            switch ( $wrapText )
            {
                case 0 :
                    $objStyle->getAlignment( )->setWrapText( FALSE );
                    break;
                case 1 :
                    $objStyle->getAlignment( )->setWrapText( TRUE );
            }
            $vertAlign = ( 112 & ord( $recordData[6] ) ) >> 4;
            switch ( $vertAlign )
            {
                case 0 :
                    $objStyle->getAlignment( )->setVertical( PHPExcel_Style_Alignment::VERTICAL_TOP );
                    break;
                case 1 :
                    $objStyle->getAlignment( )->setVertical( PHPExcel_Style_Alignment::VERTICAL_CENTER );
                    break;
                case 2 :
                    $objStyle->getAlignment( )->setVertical( PHPExcel_Style_Alignment::VERTICAL_BOTTOM );
                    break;
                case 3 :
                    $objStyle->getAlignment( )->setVertical( PHPExcel_Style_Alignment::VERTICAL_JUSTIFY );
            }
            if ( $this->_version == self::XLS_BIFF8 )
            {
                $angle = ord( $recordData[7] );
                $rotation = 0;
                if ( $angle <= 90 )
                {
                    $rotation = $angle;
                }
                else if ( $angle <= 180 )
                {
                    $rotation = 90 - $angle;
                }
                else if ( $angle == 255 )
                {
                    $rotation = -165;
                }
                $objStyle->getAlignment( )->setTextRotation( $rotation );
                $indent = ( 15 & ord( $recordData[8] ) ) >> 0;
                $objStyle->getAlignment( )->setIndent( $indent );
                $shrinkToFit = ( 16 & ord( $recordData[8] ) ) >> 4;
                switch ( $shrinkToFit )
                {
                    case 0 :
                        $objStyle->getAlignment( )->setShrinkToFit( FALSE );
                        break;
                    case 1 :
                        $objStyle->getAlignment( )->setShrinkToFit( TRUE );
                }
                if ( $bordersLeftStyle = ( ( 15 & ( $recordData, 10 ) ) >> 0 ) )
                {
                    $objStyle->getBorders( )->getLeft( )->setBorderStyle( $bordersLeftStyle );
                }
                if ( $bordersRightStyle = ( ( 240 & ( $recordData, 10 ) ) >> 4 ) )
                {
                    $objStyle->getBorders( )->getRight( )->setBorderStyle( $bordersRightStyle );
                }
                if ( $bordersTopStyle = ( ( 3840 & ( $recordData, 10 ) ) >> 8 ) )
                {
                    $objStyle->getBorders( )->getTop( )->setBorderStyle( $bordersTopStyle );
                }
                if ( $bordersBottomStyle = ( ( 61440 & ( $recordData, 10 ) ) >> 12 ) )
                {
                    $objStyle->getBorders( )->getBottom( )->setBorderStyle( $bordersBottomStyle );
                }
                $objStyle->getBorders( )->getLeft( )->colorIndex = ( 8323072 & ( $recordData, 10 ) ) >> 16;
                $objStyle->getBorders( )->getRight( )->colorIndex = ( 1065353216 & ( $recordData, 10 ) ) >> 23;
                $diagonalDown = ( 1073741824 & ( $recordData, 10 ) ) >> 30 ? TRUE : FALSE;
                $diagonalUp = ( 2.14748e+009 & ( $recordData, 10 ) ) >> 31 ? TRUE : FALSE;
                if ( !$diagonalUp && !$diagonalDown )
                {
                    $objStyle->getBorders( )->setDiagonalDirection( PHPExcel_Style_Borders::DIAGONAL_NONE );
                }
                else if ( $diagonalUp && !$diagonalDown )
                {
                    $objStyle->getBorders( )->setDiagonalDirection( PHPExcel_Style_Borders::DIAGONAL_UP );
                }
                else if ( !$diagonalUp && $diagonalDown )
                {
                    $objStyle->getBorders( )->setDiagonalDirection( PHPExcel_Style_Borders::DIAGONAL_DOWN );
                }
                else if ( $diagonalUp && $diagonalDown )
                {
                    $objStyle->getBorders( )->setDiagonalDirection( PHPExcel_Style_Borders::DIAGONAL_BOTH );
                }
                $objStyle->getBorders( )->getTop( )->colorIndex = ( 127 & ( $recordData, 14 ) ) >> 0;
                $objStyle->getBorders( )->getBottom( )->colorIndex = ( 16256 & ( $recordData, 14 ) ) >> 7;
                $objStyle->getBorders( )->getDiagonal( )->colorIndex = ( 2080768 & ( $recordData, 14 ) ) >> 14;
                if ( $bordersDiagonalStyle = ( ( 31457280 & ( $recordData, 14 ) ) >> 21 ) )
                {
                    $objStyle->getBorders( )->getDiagonal( )->setBorderStyle( $bordersDiagonalStyle );
                }
                if ( $fillType = ( ( 4.22786e+009 & ( $recordData, 14 ) ) >> 26 ) )
                {
                    $objStyle->getFill( )->setFillType( $fillType );
                }
                $objStyle->getFill( )->startcolorIndex = ( 127 & ( $recordData, 18 ) ) >> 0;
                $objStyle->getFill( )->endcolorIndex = ( 16256 & ( $recordData, 18 ) ) >> 7;
            }
            else
            {
                $orientationAndFlags = ord( $recordData[7] );
                $xfOrientation = ( 3 & $orientationAndFlags ) >> 0;
                switch ( $xfOrientation )
                {
                    case 0 :
                        $objStyle->getAlignment( )->setTextRotation( 0 );
                        break;
                    case 1 :
                        $objStyle->getAlignment( )->setTextRotation( -165 );
                        break;
                    case 2 :
                        $objStyle->getAlignment( )->setTextRotation( 90 );
                        break;
                    case 3 :
                        $objStyle->getAlignment( )->setTextRotation( -90 );
                }
                $borderAndBackground = ( $recordData, 8 );
                $objStyle->getFill( )->startcolorIndex = ( 127 & $borderAndBackground ) >> 0;
                $objStyle->getFill( )->endcolorIndex = ( 16256 & $borderAndBackground ) >> 7;
                $objStyle->getFill( )->setFillType( ( ( 4128768 & $borderAndBackground ) >> 16 ) );
                $objStyle->getBorders( )->getBottom( )->setBorderStyle( ( ( 29360128 & $borderAndBackground ) >> 22 ) );
                $objStyle->getBorders( )->getBottom( )->colorIndex = ( 4.26141e+009 & $borderAndBackground ) >> 25;
                $borderLines = ( $recordData, 12 );
                $objStyle->getBorders( )->getTop( )->setBorderStyle( ( ( 7 & $borderLines ) >> 0 ) );
                $objStyle->getBorders( )->getLeft( )->setBorderStyle( ( ( 56 & $borderLines ) >> 3 ) );
                $objStyle->getBorders( )->getRight( )->setBorderStyle( ( ( 448 & $borderLines ) >> 6 ) );
                $objStyle->getBorders( )->getTop( )->colorIndex = ( 65024 & $borderLines ) >> 9;
                $objStyle->getBorders( )->getLeft( )->colorIndex = ( 8323072 & $borderLines ) >> 16;
                $objStyle->getBorders( )->getRight( )->colorIndex = ( 1065353216 & $borderLines ) >> 23;
            }
            if ( $isCellStyleXf )
            {
                if ( $this->_xfIndex == 0 )
                {
                    $this->_phpExcel->addCellStyleXf( $objStyle );
                    $this->_mapCellStyleXfIndex[$this->_xfIndex] = 0;
                }
            }
            else
            {
                $this->_phpExcel->addCellXf( $objStyle );
                $this->_mapCellXfIndex[$this->_xfIndex] = count( $this->_phpExcel->getCellXfCollection( ) ) - 1;
            }
            ++$this->_xfIndex;
        }
    }

    private function _readXfExt( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _515288888 += "_pos";
        if ( $this->_readDataOnly )
        {
            $ixfe = ( $recordData, 14 );
            $cexts = ( $recordData, 18 );
            $offset = 20;
            while ( $offset < $length )
            {
                $extType = ( $recordData, $offset );
                $cb = ( $recordData, $offset + 2 );
                $extData = substr( $recordData, $offset + 4, $cb );
                switch ( $extType )
                {
                    case 4 :
                        $xclfType = ( $extData, 0 );
                        $xclrValue = substr( $extData, 4, 4 );
                        if ( $xclfType == 2 )
                        {
                            $rgb = sprintf( "%02X%02X%02X", ord( $xclrValue[0] ), ord( $xclrValue[1] ), ord( $xclrValue[2] ) );
                            if ( isset( $this->_mapCellXfIndex[$ixfe] ) )
                            {
                                $fill = $this->_mapCellXfIndex( $this->_mapCellXfIndex[$ixfe] )->getFill( );
                                $fill->getStartColor( )->setRGB( $rgb );
                                break;
                            }
                        }
                    case 5 :
                        $xclfType = ( $extData, 0 );
                        $xclrValue = substr( $extData, 4, 4 );
                        if ( $xclfType == 2 )
                        {
                            $rgb = sprintf( "%02X%02X%02X", ord( $xclrValue[0] ), ord( $xclrValue[1] ), ord( $xclrValue[2] ) );
                            if ( isset( $this->_mapCellXfIndex[$ixfe] ) )
                            {
                                $fill = $this->_mapCellXfIndex( $this->_mapCellXfIndex[$ixfe] )->getFill( );
                                $fill->getEndColor( )->setRGB( $rgb );
                                break;
                            }
                        }
                    case 7 :
                        $xclfType = ( $extData, 0 );
                        $xclrValue = substr( $extData, 4, 4 );
                        if ( $xclfType == 2 )
                        {
                            $rgb = sprintf( "%02X%02X%02X", ord( $xclrValue[0] ), ord( $xclrValue[1] ), ord( $xclrValue[2] ) );
                            if ( isset( $this->_mapCellXfIndex[$ixfe] ) )
                            {
                                $top = $this->_mapCellXfIndex( $this->_mapCellXfIndex[$ixfe] )->getBorders( )->getTop( );
                                $top->getColor( )->setRGB( $rgb );
                                break;
                            }
                        }
                    case 8 :
                        $xclfType = ( $extData, 0 );
                        $xclrValue = substr( $extData, 4, 4 );
                        if ( $xclfType == 2 )
                        {
                            $rgb = sprintf( "%02X%02X%02X", ord( $xclrValue[0] ), ord( $xclrValue[1] ), ord( $xclrValue[2] ) );
                            if ( isset( $this->_mapCellXfIndex[$ixfe] ) )
                            {
                                $bottom = $this->_mapCellXfIndex( $this->_mapCellXfIndex[$ixfe] )->getBorders( )->getBottom( );
                                $bottom->getColor( )->setRGB( $rgb );
                                break;
                            }
                        }
                    case 9 :
                        $xclfType = ( $extData, 0 );
                        $xclrValue = substr( $extData, 4, 4 );
                        if ( $xclfType == 2 )
                        {
                            $rgb = sprintf( "%02X%02X%02X", ord( $xclrValue[0] ), ord( $xclrValue[1] ), ord( $xclrValue[2] ) );
                            if ( isset( $this->_mapCellXfIndex[$ixfe] ) )
                            {
                                $left = $this->_mapCellXfIndex( $this->_mapCellXfIndex[$ixfe] )->getBorders( )->getLeft( );
                                $left->getColor( )->setRGB( $rgb );
                                break;
                            }
                        }
                    case 10 :
                        $xclfType = ( $extData, 0 );
                        $xclrValue = substr( $extData, 4, 4 );
                        if ( $xclfType == 2 )
                        {
                            $rgb = sprintf( "%02X%02X%02X", ord( $xclrValue[0] ), ord( $xclrValue[1] ), ord( $xclrValue[2] ) );
                            if ( isset( $this->_mapCellXfIndex[$ixfe] ) )
                            {
                                $right = $this->_mapCellXfIndex( $this->_mapCellXfIndex[$ixfe] )->getBorders( )->getRight( );
                                $right->getColor( )->setRGB( $rgb );
                                break;
                            }
                        }
                    case 11 :
                        $xclfType = ( $extData, 0 );
                        $xclrValue = substr( $extData, 4, 4 );
                        if ( $xclfType == 2 )
                        {
                            $rgb = sprintf( "%02X%02X%02X", ord( $xclrValue[0] ), ord( $xclrValue[1] ), ord( $xclrValue[2] ) );
                            if ( isset( $this->_mapCellXfIndex[$ixfe] ) )
                            {
                                $diagonal = $this->_mapCellXfIndex( $this->_mapCellXfIndex[$ixfe] )->getBorders( )->getDiagonal( );
                                $diagonal->getColor( )->setRGB( $rgb );
                                break;
                            }
                        }
                    case 13 :
                        $xclfType = ( $extData, 0 );
                        $xclrValue = substr( $extData, 4, 4 );
                        if ( $xclfType == 2 )
                        {
                            $rgb = sprintf( "%02X%02X%02X", ord( $xclrValue[0] ), ord( $xclrValue[1] ), ord( $xclrValue[2] ) );
                            if ( isset( $this->_mapCellXfIndex[$ixfe] ) )
                            {
                                $font = $this->_mapCellXfIndex( $this->_mapCellXfIndex[$ixfe] )->getFont( );
                                $font->getColor( )->setRGB( $rgb );
                            }
                        }
                }
                $offset += $cb;
            }
        }
    }

    private function _readStyle( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _735375624 += "_pos";
        if ( $this->_readDataOnly )
        {
            $ixfe = ( $recordData, 0 );
            $xfIndex = ( 4095 & $ixfe ) >> 0;
            $isBuiltIn = ( 32768 & $ixfe ) >> 15;
            if ( $isBuiltIn )
            {
                $builtInId = ord( $recordData[2] );
            }
        }
    }

    private function _readPalette( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _515289336 += "_pos";
        if ( $this->_readDataOnly )
        {
            $nm = ( $recordData, 0 );
            $i = 0;
            for ( ; $i < $nm; ++$i )
            {
                $rgb = substr( $recordData, 2 + 4 * $i, 4 );
                $this->_palette[] = ( $rgb );
            }
        }
    }

    private function _readSheet( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _515288856 += "_pos";
        $rec_offset = ( $recordData, 0 );
        switch ( ord( $recordData[4] ) )
        {
            case 0 :
                $sheetState = PHPExcel_Worksheet::SHEETSTATE_VISIBLE;
                break;
            case 1 :
                $sheetState = PHPExcel_Worksheet::SHEETSTATE_HIDDEN;
                break;
            case 2 :
                $sheetState = PHPExcel_Worksheet::SHEETSTATE_VERYHIDDEN;
                break;
            default :
                $sheetState = PHPExcel_Worksheet::SHEETSTATE_VISIBLE;
        }
        $sheetType = ord( $recordData[5] );
        if ( $this->_version == self::XLS_BIFF8 )
        {
            $string = ( substr( $recordData, 6 ) );
            $rec_name = $string['value'];
        }
        else
        {
            if ( $this->_version == self::XLS_BIFF7 )
            {
                $string = substr( $recordData, 6 )( substr( $recordData, 6 ) );
                $rec_name = $string['value'];
            }
        }
        $this->_sheets[] = array( "name" => $rec_name, "offset" => $rec_offset, "sheetState" => $sheetState, "sheetType" => $sheetType );
    }

    private function _readExternalBook( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _515024048 += "_pos";
        $offset = 0;
        if ( 4 < strlen( $recordData ) )
        {
            $nm = ( $recordData, 0 );
            $offset += 2;
            $encodedUrlString = ( substr( $recordData, 2 ) );
            $offset += $encodedUrlString['size'];
            $externalSheetNames = array( );
            $i = 0;
            for ( ; $i < $nm; ++$i )
            {
                $externalSheetNameString = ( substr( $recordData, $offset ) );
                $externalSheetNames[] = $externalSheetNameString['value'];
                $offset += $externalSheetNameString['size'];
            }
            $this->_externalBooks[] = array( "type" => "external", "encodedUrl" => $encodedUrlString['value'], "externalSheetNames" => $externalSheetNames );
        }
        else if ( substr( $recordData, 2, 2 ) == pack( "CC", 1, 4 ) )
        {
            $this->_externalBooks[] = array( "type" => "internal" );
        }
        else
        {
            if ( substr( $recordData, 0, 4 ) == pack( "vCC", 1, 1, 58 ) )
            {
                $this->_externalBooks[] = array( "type" => "addInFunction" );
            }
            else
            {
                if ( substr( $recordData, 0, 2 ) == pack( "v", 0 ) )
                {
                    $this->_externalBooks[] = array( "type" => "DDEorOLE" );
                }
            }
        }
    }

    private function _readExternName( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _723989032 += "_pos";
        if ( $this->_version == self::XLS_BIFF8 )
        {
            $options = ( $recordData, 0 );
            $nameString = ( substr( $recordData, 6 ) );
            $offset = 6 + $nameString['size'];
            $formula = substr( $recordData, $offset )( substr( $recordData, $offset ) );
            $this->_externalNames[] = array( "name" => $nameString['value'], "formula" => $formula );
        }
    }

    private function _readExternSheet( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _514756304 += "_pos";
        if ( $this->_version == self::XLS_BIFF8 )
        {
            $nm = ( $recordData, 0 );
            $i = 0;
            for ( ; $i < $nm; ++$i )
            {
                $this->_ref[] = array( "externalBookIndex" => ( $recordData, 2 + 6 * $i ), "firstSheetIndex" => ( $recordData, 4 + 6 * $i ), "lastSheetIndex" => ( $recordData, 6 + 6 * $i ) );
            }
        }
    }

    private function _readDefinedName( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _515289144 += "_pos";
        if ( $this->_version == self::XLS_BIFF8 )
        {
            $opts = ( $recordData, 0 );
            $isBuiltInName = ( 32 & $opts ) >> 5;
            $nlen = ord( $recordData[3] );
            $flen = ( $recordData, 4 );
            $scope = ( $recordData, 8 );
            $string = ( substr( $recordData, 14 ), $nlen );
            $offset = 14 + $string['size'];
            $formulaStructure = pack( "v", $flen ).substr( $recordData, $offset );
            try
            {
                $formula = $this->_getFormulaFromStructure( $formulaStructure );
            }
            catch ( PHPExcel_Exception $e )
            {
                $formula = "";
        }
        $this->_definedname[] = array( "isBuiltInName" => $isBuiltInName, "name" => $string['value'], "formula" => $formula, "scope" => $scope );
    }
}

    private function _readMsoDrawingGroup( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $splicedRecordData = $this->_getSplicedRecordData( );
        $recordData = $splicedRecordData['recordData'];
        $ && _775870048 .= "_drawingGroupData";
    }

    private function _readSst( )
    {
        $pos = 0;
        $splicedRecordData = $this->_getSplicedRecordData( );
        $recordData = $splicedRecordData['recordData'];
        $spliceOffsets = $splicedRecordData['spliceOffsets'];
        $pos += 4;
        $nm = ( $recordData, 4 );
        $pos += 4;
        $i = 0;
        for ( ; $i < $nm; ++$i )
        {
            $numChars = ( $recordData, $pos );
            $pos += 2;
            $optionFlags = ord( $recordData[$pos] );
            ++$pos;
            $isCompressed = ( $optionFlags & 1 ) == 0;
            $hasAsian = ( $optionFlags & 4 ) != 0;
            $hasRichText = ( $optionFlags & 8 ) != 0;
            if ( $hasRichText )
            {
                $formattingRuns = ( $recordData, $pos );
                $pos += 2;
            }
            if ( $hasAsian )
            {
                $extendedRunLength = ( $recordData, $pos );
                $pos += 4;
            }
            $len = $isCompressed ? $numChars : $numChars * 2;
            foreach ( $spliceOffsets as $spliceOffset )
            {
                if ( $pos <= $spliceOffset )
                {
                    $limitpos = $spliceOffset;
                    break;
                }
            }
            if ( $pos + $len <= $limitpos )
            {
                $retstr = substr( $recordData, $pos, $len );
                $pos += $len;
            }
            else
            {
                $retstr = substr( $recordData, $pos, $limitpos - $pos );
                $bytesRead = $limitpos - $pos;
                $charsLeft = $numChars - ( $isCompressed ? $bytesRead : $bytesRead / 2 );
                $pos = $limitpos;
                while ( 0 < $charsLeft )
                {
                    foreach ( $spliceOffsets as $spliceOffset )
                    {
                        if ( $pos < $spliceOffset )
                        {
                            $limitpos = $spliceOffset;
                            break;
                        }
                    }
                    $option = ord( $recordData[$pos] );
                    ++$pos;
                    if ( $isCompressed && $option == 0 )
                    {
                        $len = min( $charsLeft, $limitpos - $pos );
                        $retstr .= substr( $recordData, $pos, $len );
                        $charsLeft -= $len;
                        $isCompressed = TRUE;
                    }
                    else if ( !$isCompressed && $option != 0 )
                    {
                        $len = min( $charsLeft * 2, $limitpos - $pos );
                        $retstr .= substr( $recordData, $pos, $len );
                        $charsLeft -= $len / 2;
                        $isCompressed = FALSE;
                    }
                    else if ( !$isCompressed && $option == 0 )
                    {
                        $len = min( $charsLeft, $limitpos - $pos );
                        $j = 0;
                        for ( ; $j < $len; ++$j )
                        {
                            $retstr .= $recordData[$pos + $j].chr( 0 );
                        }
                        $charsLeft -= $len;
                        $isCompressed = FALSE;
                    }
                    else
                    {
                        $newstr = "";
                        $j = 0;
                        for ( ; $j < strlen( $retstr ); ++$j )
                        {
                            $newstr .= $retstr[$j].chr( 0 );
                        }
                        $retstr = $newstr;
                        $len = min( $charsLeft * 2, $limitpos - $pos );
                        $retstr .= substr( $recordData, $pos, $len );
                        $charsLeft -= $len / 2;
                        $isCompressed = FALSE;
                    }
                    $pos += $len;
                }
            }
            $retstr = ( $retstr, $isCompressed );
            $fmtRuns = array( );
            if ( $hasRichText )
            {
                $j = 0;
                for ( ; $j < $formattingRuns; ++$j )
                {
                    $charPos = ( $recordData, $pos + $j * 4 );
                    $fontIndex = ( $recordData, $pos + 2 + $j * 4 );
                    $fmtRuns[] = array( "charPos" => $charPos, "fontIndex" => $fontIndex );
                }
                $pos += 4 * $formattingRuns;
            }
            if ( $hasAsian )
            {
                $pos += $extendedRunLength;
            }
            $this->_sst[] = array( "value" => $retstr, "fmtRuns" => $fmtRuns );
        }
    }

    private function _readPrintGridlines( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _737141168 += "_pos";
        if ( $this->_version == self::XLS_BIFF8 && !$this->_readDataOnly )
        {
            $printGridlines = ( $recordData, 0 );
            $this->_phpSheet->setPrintGridlines( $printGridlines );
        }
    }

    private function _readDefaultRowHeight( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _514489144 += "_pos";
        $height = ( $recordData, 2 );
        $this->_phpSheet->getDefaultRowDimension( )->setRowHeight( $height / 20 );
    }

    private function _readSheetPr( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _733680824 += "_pos";
        $isSummaryBelow = ( 64 & ( $recordData, 0 ) ) >> 6;
        $this->_phpSheet->setShowSummaryBelow( $isSummaryBelow );
        $isSummaryRight = ( 128 & ( $recordData, 0 ) ) >> 7;
        $this->_phpSheet->setShowSummaryRight( $isSummaryRight );
        $this->_isFitToPages = ( 256 & ( $recordData, 0 ) ) >> 8;
    }

    private function _readHorizontalPageBreaks( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _737143016 += "_pos";
        if ( !( $this->_version == self::XLS_BIFF8 ) || $this->_readDataOnly )
        {
            $nm = ( $recordData, 0 );
            $i = 0;
            for ( ; $i < $nm; ++$i )
            {
                $r = ( $recordData, 2 + 6 * $i );
                $cf = ( $recordData, 2 + 6 * $i + 2 );
                $cl = ( $recordData, 2 + 6 * $i + 4 );
                $this->_phpSheet->setBreakByColumnAndRow( $cf, $r, PHPExcel_Worksheet::BREAK_ROW );
            }
        }
    }

    private function _readVerticalPageBreaks( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _761199504 += "_pos";
        if ( !( $this->_version == self::XLS_BIFF8 ) || $this->_readDataOnly )
        {
            $nm = ( $recordData, 0 );
            $i = 0;
            for ( ; $i < $nm; ++$i )
            {
                $c = ( $recordData, 2 + 6 * $i );
                $rf = ( $recordData, 2 + 6 * $i + 2 );
                $rl = ( $recordData, 2 + 6 * $i + 4 );
                $this->_phpSheet->setBreakByColumnAndRow( $c, $rf, PHPExcel_Worksheet::BREAK_COLUMN );
            }
        }
    }

    private function _readHeader( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _514486256 += "_pos";
        if ( !$this->_readDataOnly && $recordData )
        {
            if ( $this->_version == self::XLS_BIFF8 )
            {
                $string = ( $recordData );
            }
            else
            {
                $string = $this->_readByteStringShort( $recordData );
            }
            $this->_phpSheet->getHeaderFooter( )->setOddHeader( $string['value'] );
            $this->_phpSheet->getHeaderFooter( )->setEvenHeader( $string['value'] );
        }
    }

    private function _readFooter( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _775861984 += "_pos";
        if ( !$this->_readDataOnly && $recordData )
        {
            if ( $this->_version == self::XLS_BIFF8 )
            {
                $string = ( $recordData );
            }
            else
            {
                $string = $this->_readByteStringShort( $recordData );
            }
            $this->_phpSheet->getHeaderFooter( )->setOddFooter( $string['value'] );
            $this->_phpSheet->getHeaderFooter( )->setEvenFooter( $string['value'] );
        }
    }

    private function _readHcenter( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _775854464 += "_pos";
        if ( $this->_readDataOnly )
        {
            $isHorizontalCentered = ( $recordData, 0 );
            $this->_phpSheet->getPageSetup( )->setHorizontalCentered( $isHorizontalCentered );
        }
    }

    private function _readVcenter( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _514970280 += "_pos";
        if ( $this->_readDataOnly )
        {
            $isVerticalCentered = ( $recordData, 0 );
            $this->_phpSheet->getPageSetup( )->setVerticalCentered( $isVerticalCentered );
        }
    }

    private function _readLeftMargin( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _737206032 += "_pos";
        if ( $this->_readDataOnly )
        {
            $this->_phpSheet->getPageMargins( )->setLeft( ( $recordData ) );
        }
    }

    private function _readRightMargin( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _514516248 += "_pos";
        if ( $this->_readDataOnly )
        {
            $this->_phpSheet->getPageMargins( )->setRight( ( $recordData ) );
        }
    }

    private function _readTopMargin( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _737140968 += "_pos";
        if ( $this->_readDataOnly )
        {
            $this->_phpSheet->getPageMargins( )->setTop( ( $recordData ) );
        }
    }

    private function _readBottomMargin( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _737144216 += "_pos";
        if ( $this->_readDataOnly )
        {
            $this->_phpSheet->getPageMargins( )->setBottom( ( $recordData ) );
        }
    }

    private function _readPageSetup( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _775854816 += "_pos";
        if ( $this->_readDataOnly )
        {
            $paperSize = ( $recordData, 0 );
            $scale = ( $recordData, 2 );
            $fitToWidth = ( $recordData, 6 );
            $fitToHeight = ( $recordData, 8 );
            $isPortrait = ( 2 & ( $recordData, 10 ) ) >> 1;
            $isNotInit = ( 4 & ( $recordData, 10 ) ) >> 2;
            if ( $isNotInit )
            {
                $this->_phpSheet->getPageSetup( )->setPaperSize( $paperSize );
                switch ( $isPortrait )
                {
                    case 0 :
                        $this->_phpSheet->getPageSetup( )->setOrientation( PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE );
                        break;
                    case 1 :
                        $this->_phpSheet->getPageSetup( )->setOrientation( PHPExcel_Worksheet_PageSetup::ORIENTATION_PORTRAIT );
                }
                $this->_phpSheet->getPageSetup( )->setScale( $scale, FALSE );
                $this->_isFitToPages( $this->_isFitToPages );
                $this->_phpSheet->getPageSetup( )->setFitToWidth( $fitToWidth, FALSE );
                $this->_phpSheet->getPageSetup( )->setFitToHeight( $fitToHeight, FALSE );
            }
            $marginHeader = ( substr( $recordData, 16, 8 ) );
            $this->_phpSheet->getPageMargins( )->setHeader( $marginHeader );
            $marginFooter = ( substr( $recordData, 24, 8 ) );
            $this->_phpSheet->getPageMargins( )->setFooter( $marginFooter );
        }
    }

    private function _readProtect( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _775861912 += "_pos";
        if ( $this->_readDataOnly )
        {
        }
        else
        {
            $bool = ( 1 & ( $recordData, 0 ) ) >> 0;
            $this->_phpSheet->getProtection( )->setSheet( $bool );
        }
    }

    private function _readScenProtect( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _776404768 += "_pos";
        if ( $this->_readDataOnly )
        {
        }
        else
        {
            $bool = ( 1 & ( $recordData, 0 ) ) >> 0;
            $this->_phpSheet->getProtection( )->setScenarios( $bool );
        }
    }

    private function _readObjectProtect( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _515245736 += "_pos";
        if ( $this->_readDataOnly )
        {
        }
        else
        {
            $bool = ( 1 & ( $recordData, 0 ) ) >> 0;
            $this->_phpSheet->getProtection( )->setObjects( $bool );
        }
    }

    private function _readPassword( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _514516736 += "_pos";
        if ( $this->_readDataOnly )
        {
            $password = strtoupper( dechex( ( $recordData, 0 ) ) );
            $this->_phpSheet->getProtection( )->setPassword( $password, TRUE );
        }
    }

    private function _readDefColWidth( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _514486928 += "_pos";
        $width = ( $recordData, 0 );
        if ( $width != 8 )
        {
            $this->_phpSheet->getDefaultColumnDimension( )->setWidth( $width );
        }
    }

    private function _readColInfo( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _514781144 += "_pos";
        if ( $this->_readDataOnly )
        {
            $fc = ( $recordData, 0 );
            $lc = ( $recordData, 2 );
            $width = ( $recordData, 4 );
            $xfIndex = ( $recordData, 6 );
            $isHidden = ( 1 & ( $recordData, 8 ) ) >> 0;
            $level = ( 1792 & ( $recordData, 8 ) ) >> 8;
            $isCollapsed = ( 4096 & ( $recordData, 8 ) ) >> 12;
            $i = $fc;
            for ( ; $i <= $lc; ++$i )
            {
                if ( $lc == 255 || $lc == 256 )
                {
                    $this->_phpSheet->getDefaultColumnDimension( )->setWidth( $width / 256 );
                }
                else
                {
                    $this->_phpSheet->getColumnDimensionByColumn( $i )->setWidth( $width / 256 );
                    $this->_phpSheet->getColumnDimensionByColumn( $i )->setVisible( !$isHidden );
                    $this->_phpSheet->getColumnDimensionByColumn( $i )->setOutlineLevel( $level );
                    $this->_phpSheet->getColumnDimensionByColumn( $i )->setCollapsed( $isCollapsed );
                    $this->_mapCellXfIndex( $this->_mapCellXfIndex[$xfIndex] );
                }
            }
        }
    }

    private function _readRow( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _514760560 += "_pos";
        if ( $this->_readDataOnly )
        {
            $r = ( $recordData, 0 );
            $height = ( 32767 & ( $recordData, 6 ) ) >> 0;
            $useDefaultHeight = ( 32768 & ( $recordData, 6 ) ) >> 15;
            if ( $useDefaultHeight )
            {
                $this->_phpSheet->getRowDimension( $r + 1 )->setRowHeight( $height / 20 );
            }
            $level = ( 7 & ( $recordData, 12 ) ) >> 0;
            $this->_phpSheet->getRowDimension( $r + 1 )->setOutlineLevel( $level );
            $isCollapsed = ( 16 & ( $recordData, 12 ) ) >> 4;
            $this->_phpSheet->getRowDimension( $r + 1 )->setCollapsed( $isCollapsed );
            $isHidden = ( 32 & ( $recordData, 12 ) ) >> 5;
            $this->_phpSheet->getRowDimension( $r + 1 )->setVisible( !$isHidden );
            $hasExplicitFormat = ( 128 & ( $recordData, 12 ) ) >> 7;
            $xfIndex = ( 268369920 & ( $recordData, 12 ) ) >> 16;
            if ( $hasExplicitFormat )
            {
                $this->_mapCellXfIndex( $this->_mapCellXfIndex[$xfIndex] );
            }
        }
    }

    private function _readRk( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _723946112 += "_pos";
        $row = ( $recordData, 0 );
        $column = ( $recordData, 2 );
        $columnString = ( $column );
        if ( $this->getReadFilter( ) !== NULL && $this->getReadFilter( )->readCell( $columnString, $row + 1, $this->_phpSheet->getTitle( ) ) )
        {
            $xfIndex = ( $recordData, 4 );
            $rknum = ( $recordData, 6 );
            $numValue = ( $rknum );
            $cell = $this->_phpSheet->getCell( $columnString.( $row + 1 ) );
            if ( $this->_readDataOnly )
            {
                $this->_mapCellXfIndex[$xfIndex]( $this->_mapCellXfIndex[$xfIndex] );
            }
            $cell->setValueExplicit( $numValue, PHPExcel_Cell_DataType::TYPE_NUMERIC );
        }
    }

    private function _readLabelSst( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _514487552 += "_pos";
        $row = ( $recordData, 0 );
        $column = ( $recordData, 2 );
        $columnString = ( $column );
        if ( $this->getReadFilter( ) !== NULL && $this->getReadFilter( )->readCell( $columnString, $row + 1, $this->_phpSheet->getTitle( ) ) )
        {
            $xfIndex = ( $recordData, 4 );
            $index = ( $recordData, 6 );
            if ( ( $fmtRuns = $this->_sst[$index]['fmtRuns'] ) && !$this->_readDataOnly )
            {
                $richText = new PHPExcel_RichText( );
                $charPos = 0;
                $sstCount = count( $this->_sst[$index]['fmtRuns'] );
                $i = 0;
                for ( ; $i <= $sstCount; ++$i )
                {
                    if ( isset( $fmtRuns[$i] ) )
                    {
                        $text = ( $this->_sst[$index]['value'], $charPos, $fmtRuns[$i]['charPos'] - $charPos );
                        $charPos = $fmtRuns[$i]['charPos'];
                    }
                    else
                    {
                        $text = ( $this->_sst[$index]['value'], $charPos, ( $this->_sst[$index]['value'] ) );
                    }
                    if ( !( 0 < ( $text ) ) )
                    {
                        continue;
                    }
                    else if ( $i == 0 )
                    {
                        $richText->createText( $text );
                    }
                    else
                    {
                        $textRun = $richText->createTextRun( $text );
                        if ( isset( $fmtRuns[$i - 1] ) )
                        {
                            if ( $fmtRuns[$i - 1]['fontIndex'] < 4 )
                            {
                                $fontIndex = $fmtRuns[$i - 1]['fontIndex'];
                            }
                            else
                            {
                                $fontIndex = $fmtRuns[$i - 1]['fontIndex'] - 1;
                            }
                            clone $this->_objFonts[$fontIndex]( clone $this->_objFonts[$fontIndex] );
                        }
                    }
                }
                $cell = $this->_phpSheet->getCell( $columnString.( $row + 1 ) );
                $cell->setValueExplicit( $richText, PHPExcel_Cell_DataType::TYPE_STRING );
            }
            else
            {
                $cell = $this->_phpSheet->getCell( $columnString.( $row + 1 ) );
                $this->_sst[$index]['value']( $this->_sst[$index]['value'], PHPExcel_Cell_DataType::TYPE_STRING );
            }
            if ( $this->_readDataOnly )
            {
                $this->_mapCellXfIndex[$xfIndex]( $this->_mapCellXfIndex[$xfIndex] );
            }
        }
    }

    private function _readMulRk( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _732877720 += "_pos";
        $row = ( $recordData, 0 );
        $colFirst = ( $recordData, 2 );
        $colLast = ( $recordData, $length - 2 );
        $columns = $colLast - $colFirst + 1;
        $offset = 4;
        $i = 0;
        for ( ; $i < $columns; ++$i )
        {
            $columnString = ( $colFirst + $i );
            if ( $this->getReadFilter( ) !== NULL && $this->getReadFilter( )->readCell( $columnString, $row + 1, $this->_phpSheet->getTitle( ) ) )
            {
                $xfIndex = ( $recordData, $offset );
                $numValue = ( ( $recordData, $offset + 2 ) );
                $cell = $this->_phpSheet->getCell( $columnString.( $row + 1 ) );
                if ( $this->_readDataOnly )
                {
                    $this->_mapCellXfIndex[$xfIndex]( $this->_mapCellXfIndex[$xfIndex] );
                }
                $cell->setValueExplicit( $numValue, PHPExcel_Cell_DataType::TYPE_NUMERIC );
            }
            $offset += 6;
        }
    }

    private function _readNumber( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _736357096 += "_pos";
        $row = ( $recordData, 0 );
        $column = ( $recordData, 2 );
        $columnString = ( $column );
        if ( $this->getReadFilter( ) !== NULL && $this->getReadFilter( )->readCell( $columnString, $row + 1, $this->_phpSheet->getTitle( ) ) )
        {
            $xfIndex = ( $recordData, 4 );
            $numValue = ( substr( $recordData, 6, 8 ) );
            $cell = $this->_phpSheet->getCell( $columnString.( $row + 1 ) );
            if ( $this->_readDataOnly )
            {
                $this->_mapCellXfIndex[$xfIndex]( $this->_mapCellXfIndex[$xfIndex] );
            }
            $cell->setValueExplicit( $numValue, PHPExcel_Cell_DataType::TYPE_NUMERIC );
        }
    }

    private function _readFormula( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _514519888 += "_pos";
        $row = ( $recordData, 0 );
        $column = ( $recordData, 2 );
        $columnString = ( $column );
        $formulaStructure = substr( $recordData, 20 );
        $options = ( $recordData, 14 );
        $isPartOfSharedFormula = 8 & $options;
        $isPartOfSharedFormula = ord( $formulaStructure[2] ) == 1;
        if ( $isPartOfSharedFormula )
        {
            $baseRow = ( $formulaStructure, 3 );
            $baseCol = ( $formulaStructure, 5 );
            $this->_baseCell = ( $baseCol ).( $baseRow + 1 );
        }
        if ( $this->getReadFilter( ) !== NULL && $this->getReadFilter( )->readCell( $columnString, $row + 1, $this->_phpSheet->getTitle( ) ) )
        {
            if ( $isPartOfSharedFormula )
            {
                $this->_sharedFormulaParts[$columnString.( $row + 1 )] = $this->_baseCell;
            }
            $xfIndex = ( $recordData, 4 );
            if ( ord( $recordData[6] ) == 0 && ord( $recordData[12] ) == 255 && ord( $recordData[13] ) == 255 )
            {
                $dataType = PHPExcel_Cell_DataType::TYPE_STRING;
                $code = ( $this->_data, $this->_pos );
                if ( $code == self::XLS_Type_SHAREDFMLA )
                {
                    $this->_readSharedFmla( );
                }
                $value = $this->_readString( );
            }
            else if ( ord( $recordData[6] ) == 1 && ord( $recordData[12] ) == 255 && ord( $recordData[13] ) == 255 )
            {
                $dataType = PHPExcel_Cell_DataType::TYPE_BOOL;
                $value = ord( $recordData[8] );
            }
            else if ( ord( $recordData[6] ) == 2 && ord( $recordData[12] ) == 255 && ord( $recordData[13] ) == 255 )
            {
                $dataType = PHPExcel_Cell_DataType::TYPE_ERROR;
                $value = ( ord( $recordData[8] ) );
            }
            else if ( ord( $recordData[6] ) == 3 && ord( $recordData[12] ) == 255 && ord( $recordData[13] ) == 255 )
            {
                $dataType = PHPExcel_Cell_DataType::TYPE_NULL;
                $value = "";
            }
            else
            {
                $dataType = PHPExcel_Cell_DataType::TYPE_NUMERIC;
                $value = ( substr( $recordData, 6, 8 ) );
            }
            $cell = $this->_phpSheet->getCell( $columnString.( $row + 1 ) );
            if ( $this->_readDataOnly )
            {
                $this->_mapCellXfIndex[$xfIndex]( $this->_mapCellXfIndex[$xfIndex] );
            }
            if ( $isPartOfSharedFormula )
            {
                try
                {
                    if ( $this->_version != self::XLS_BIFF8 )
                    {
                        throw new PHPExcel_Reader_Exception( "Not BIFF8. Can only read BIFF8 formulas" );
                    }
                    $formula = $this->_getFormulaFromStructure( $formulaStructure );
                    $cell->setValueExplicit( "=".$formula, PHPExcel_Cell_DataType::TYPE_FORMULA );
                }
                catch ( PHPExcel_Exception $e )
                {
                    $cell->setValueExplicit( $value, $dataType );
            }
        }
        else
        {
            if ( $this->_version == self::XLS_BIFF8 )
            {
                $cell->setValueExplicit( $value, $dataType );
            }
        }
        $cell->setCalculatedValue( $value );
    }
}

    private function _readSharedFmla( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _517858304 += "_pos";
        $cellRange = substr( $recordData, 0, 6 );
        $cellRange = $this->_readBIFF5CellRangeAddressFixed( $cellRange );
        $no = ord( $recordData[7] );
        $formula = substr( $recordData, 8 );
        $this->_sharedFormulas[$this->_baseCell] = $formula;
    }

    private function _readString( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _517858416 += "_pos";
        if ( $this->_version == self::XLS_BIFF8 )
        {
            $string = ( $recordData );
            $value = $string['value'];
            return $value;
        }
        $string = $this->_readByteStringLong( $recordData );
        $value = $string['value'];
        return $value;
    }

    private function _readBoolErr( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _517858528 += "_pos";
        $row = ( $recordData, 0 );
        $column = ( $recordData, 2 );
        $columnString = ( $column );
        if ( $this->getReadFilter( ) !== NULL && $this->getReadFilter( )->readCell( $columnString, $row + 1, $this->_phpSheet->getTitle( ) ) )
        {
            $xfIndex = ( $recordData, 4 );
            $boolErr = ord( $recordData[6] );
            $isError = ord( $recordData[7] );
            $cell = $this->_phpSheet->getCell( $columnString.( $row + 1 ) );
            switch ( $isError )
            {
                case 0 :
                    $value = $boolErr;
                    $cell->setValueExplicit( $value, PHPExcel_Cell_DataType::TYPE_BOOL );
                    break;
                case 1 :
                    $value = ( $boolErr );
                    $cell->setValueExplicit( $value, PHPExcel_Cell_DataType::TYPE_ERROR );
            }
            if ( $this->_readDataOnly )
            {
                $this->_mapCellXfIndex[$xfIndex]( $this->_mapCellXfIndex[$xfIndex] );
            }
        }
    }

    private function _readMulBlank( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _517857984 += "_pos";
        $row = ( $recordData, 0 );
        $fc = ( $recordData, 2 );
        if ( $this->_readDataOnly )
        {
            $i = 0;
            for ( ; $i < $length / 2 - 3; ++$i )
            {
                $columnString = ( $fc + $i );
                if ( !( $this->getReadFilter( ) !== NULL ) || !$this->getReadFilter( )->readCell( $columnString, $row + 1, $this->_phpSheet->getTitle( ) ) )
                {
                    $xfIndex = ( $recordData, 4 + 2 * $i );
                    $this->_mapCellXfIndex( $this->_mapCellXfIndex[$xfIndex] );
                }
            }
        }
    }

    private function _readLabel( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _517858112 += "_pos";
        $row = ( $recordData, 0 );
        $column = ( $recordData, 2 );
        $columnString = ( $column );
        if ( $this->getReadFilter( ) !== NULL && $this->getReadFilter( )->readCell( $columnString, $row + 1, $this->_phpSheet->getTitle( ) ) )
        {
            $xfIndex = ( $recordData, 4 );
            if ( $this->_version == self::XLS_BIFF8 )
            {
                $string = ( substr( $recordData, 6 ) );
                $value = $string['value'];
            }
            else
            {
                $string = substr( $recordData, 6 )( substr( $recordData, 6 ) );
                $value = $string['value'];
            }
            $cell = $this->_phpSheet->getCell( $columnString.( $row + 1 ) );
            $cell->setValueExplicit( $value, PHPExcel_Cell_DataType::TYPE_STRING );
            if ( $this->_readDataOnly )
            {
                $this->_mapCellXfIndex[$xfIndex]( $this->_mapCellXfIndex[$xfIndex] );
            }
        }
    }

    private function _readBlank( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _781049568 += "_pos";
        $row = ( $recordData, 0 );
        $col = ( $recordData, 2 );
        $columnString = ( $col );
        if ( $this->getReadFilter( ) !== NULL && $this->getReadFilter( )->readCell( $columnString, $row + 1, $this->_phpSheet->getTitle( ) ) )
        {
            $xfIndex = ( $recordData, 4 );
            if ( $this->_readDataOnly )
            {
                $this->_mapCellXfIndex( $this->_mapCellXfIndex[$xfIndex] );
            }
        }
    }

    private function _readMsoDrawing( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $splicedRecordData = $this->_getSplicedRecordData( );
        $recordData = $splicedRecordData['recordData'];
        $ && _781044416 .= "_drawingData";
    }

    private function _readObj( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _781044664 += "_pos";
        do
        {
            if ( $this->_readDataOnly )
            {
                if ( !( $this->_version != self::XLS_BIFF8 ) )
                {
                }
                else
                {
                    break;
                }
            }
            return;
        } while ( 0 );
        $ftCmoType = ( $recordData, 0 );
        $cbCmoSize = ( $recordData, 2 );
        $otObjType = ( $recordData, 4 );
        $idObjID = ( $recordData, 6 );
        $grbitOpts = ( $recordData, 6 );
        $this->_objs[] = array( "ftCmoType" => $ftCmoType, "cbCmoSize" => $cbCmoSize, "otObjType" => $otObjType, "idObjID" => $idObjID, "grbitOpts" => $grbitOpts );
        $this->textObjRef = $idObjID;
    }

    private function _readWindow2( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _781047536 += "_pos";
        $options = ( $recordData, 0 );
        $firstVisibleRow = ( $recordData, 2 );
        $firstVisibleColumn = ( $recordData, 4 );
        if ( $this->_version === self::XLS_BIFF8 )
        {
            $zoomscaleInPageBreakPreview = ( $recordData, 10 );
            if ( $zoomscaleInPageBreakPreview === 0 )
            {
                $zoomscaleInPageBreakPreview = 60;
            }
            $zoomscaleInNormalView = ( $recordData, 12 );
            if ( $zoomscaleInNormalView === 0 )
            {
                $zoomscaleInNormalView = 100;
            }
        }
        $showGridlines = ( 2 & $options ) >> 1;
        $this->_phpSheet->setShowGridlines( $showGridlines );
        $showRowColHeaders = ( 4 & $options ) >> 2;
        $this->_phpSheet->setShowRowColHeaders( $showRowColHeaders );
        $this->_frozen = ( 8 & $options ) >> 3;
        $this->_phpSheet->setRightToLeft( ( 64 & $options ) >> 6 );
        $isActive = ( 1024 & $options ) >> 10;
        if ( $isActive )
        {
            $this->_phpExcel->setActiveSheetIndex( $this->_phpExcel->getIndex( $this->_phpSheet ) );
        }
        $isPageBreakPreview = ( 2048 & $options ) >> 11;
        if ( $this->_phpSheet->getSheetView( )->getView( ) !== PHPExcel_Worksheet_SheetView::SHEETVIEW_PAGE_LAYOUT )
        {
            $view = $isPageBreakPreview ? PHPExcel_Worksheet_SheetView::SHEETVIEW_PAGE_BREAK_PREVIEW : PHPExcel_Worksheet_SheetView::SHEETVIEW_NORMAL;
            $this->_phpSheet->getSheetView( )->setView( $view );
            if ( $this->_version === self::XLS_BIFF8 )
            {
                $zoomScale = $isPageBreakPreview ? $zoomscaleInPageBreakPreview : $zoomscaleInNormalView;
                $this->_phpSheet->getSheetView( )->setZoomScale( $zoomScale );
                $this->_phpSheet->getSheetView( )->setZoomScaleNormal( $zoomscaleInNormalView );
            }
        }
    }

    private function _readPageLayoutView( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _515758736 += "_pos";
        $rt = ( $recordData, 0 );
        $grbitFrt = ( $recordData, 2 );
        $wScalePLV = ( $recordData, 12 );
        $grbit = ( $recordData, 14 );
        $fPageLayoutView = $grbit & 1;
        $fRulerVisible = $grbit >> 1 & 1;
        $fWhitespaceHidden = $grbit >> 3 & 1;
        if ( $fPageLayoutView === 1 )
        {
            $this->_phpSheet->getSheetView( )->setView( PHPExcel_Worksheet_SheetView::SHEETVIEW_PAGE_LAYOUT );
            $this->_phpSheet->getSheetView( )->setZoomScale( $wScalePLV );
        }
    }

    private function _readScl( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _515758896 += "_pos";
        $numerator = ( $recordData, 0 );
        $denumerator = ( $recordData, 2 );
        $this->_phpSheet->getSheetView( )->setZoomScale( $numerator * 100 / $denumerator );
    }

    private function _readPane( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _515759008 += "_pos";
        if ( $this->_readDataOnly )
        {
            $px = ( $recordData, 0 );
            $py = ( $recordData, 2 );
            if ( $this->_frozen )
            {
                ( $px )( ( $px ).( $py + 1 ) );
            }
        }
    }

    private function _readSelection( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _515760064 += "_pos";
        if ( $this->_readDataOnly )
        {
            $paneId = ord( $recordData[0] );
            $r = ( $recordData, 1 );
            $c = ( $recordData, 3 );
            $index = ( $recordData, 5 );
            $data = substr( $recordData, 7 );
            $cellRangeAddressList = $this->_readBIFF5CellRangeAddressList( $data );
            $selectedCells = $cellRangeAddressList['cellRangeAddresses'][0];
            if ( preg_match( "/^([A-Z]+1\\:[A-Z]+)16384$/", $selectedCells ) )
            {
                $selectedCells = preg_replace( "/^([A-Z]+1\\:[A-Z]+)16384$/", "${1}1048576", $selectedCells );
            }
            if ( preg_match( "/^([A-Z]+1\\:[A-Z]+)65536$/", $selectedCells ) )
            {
                $selectedCells = preg_replace( "/^([A-Z]+1\\:[A-Z]+)65536$/", "${1}1048576", $selectedCells );
            }
            if ( preg_match( "/^(A[0-9]+\\:)IV([0-9]+)$/", $selectedCells ) )
            {
                $selectedCells = preg_replace( "/^(A[0-9]+\\:)IV([0-9]+)$/", "${1}XFD${2}", $selectedCells );
            }
            $this->_phpSheet->setSelectedCells( $selectedCells );
        }
    }

    private function _includeCellRangeFiltered( $cellRangeAddress )
    {
        $includeCellRange = TRUE;
        if ( $this->getReadFilter( ) !== NULL )
        {
            $includeCellRange = FALSE;
            $rangeBoundaries = ( $cellRangeAddress );
            ++$rangeBoundaries[1][0];
            list( list( , $row ) ) = $rangeBoundaries[0];
            for ( ; $row <= $rangeBoundaries[0]; ++$row )
            {
                list( $column ) = $rangeBoundaries[0];
                for ( ; $column != $rangeBoundaries[1][0]; ++$column )
                {
                    if ( $this->getReadFilter( )->readCell( $column, $row, $this->_phpSheet->getTitle( ) ) )
                    {
                        $includeCellRange = TRUE;
                    }
                }
            }
        }
        return $includeCellRange;
    }

    private function _readMergedCells( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _515760960 += "_pos";
        if ( $this->_version == self::XLS_BIFF8 && !$this->_readDataOnly )
        {
            $cellRangeAddressList = $this->_readBIFF8CellRangeAddressList( $recordData );
            foreach ( $cellRangeAddressList['cellRangeAddresses'] as $cellRangeAddress )
            {
                if ( !( strpos( $cellRangeAddress, ":" ) !== FALSE ) || !$this->_includeCellRangeFiltered( $cellRangeAddress ) )
                {
                    $this->_phpSheet->mergeCells( $cellRangeAddress );
                }
            }
        }
    }

    private function _readHyperLink( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _515774416 += "_pos";
        if ( $this->_readDataOnly )
        {
            try
            {
                $cellRange = $this->_readBIFF8CellRangeAddressFixed( $recordData, 0, 8 );
            }
            catch ( PHPExcel_Exception $e )
            {
                return;
        }
        $isFileLinkOrUrl = ( 1 & ( $recordData, 28 ) ) >> 0;
        $isAbsPathOrUrl = ( 1 & ( $recordData, 28 ) ) >> 1;
        $hasDesc = ( 20 & ( $recordData, 28 ) ) >> 2;
        $hasText = ( 8 & ( $recordData, 28 ) ) >> 3;
        $hasFrame = ( 128 & ( $recordData, 28 ) ) >> 7;
        $isUNC = ( 256 & ( $recordData, 28 ) ) >> 8;
        $offset = 32;
        if ( $hasDesc )
        {
            $dl = ( $recordData, 32 );
            $desc = ( substr( $recordData, 36, 2 * ( $dl - 1 ) ), FALSE );
            $offset += 4 + 2 * $dl;
        }
        if ( $hasFrame )
        {
            $fl = ( $recordData, $offset );
            $offset += 4 + 2 * $fl;
        }
        $hyperlinkType = NULL;
        if ( $isUNC )
        {
            $hyperlinkType = "UNC";
        }
        else if ( $isFileLinkOrUrl )
        {
            $hyperlinkType = "workbook";
        }
        else if ( ord( $recordData[$offset] ) == 3 )
        {
            $hyperlinkType = "local";
        }
        else if ( ord( $recordData[$offset] ) == 224 )
        {
            $hyperlinkType = "URL";
        }
        switch ( $hyperlinkType )
        {
            case "URL" :
                $offset += 16;
                $us = ( $recordData, $offset );
                $offset += 4;
                $url = ( substr( $recordData, $offset, $us - 2 ), FALSE );
                $url .= $hasText ? "#" : "";
                $offset += $us;
                break;
            case "local" :
                $offset += 16;
                $upLevelCount = ( $recordData, $offset );
                $offset += 2;
                $sl = ( $recordData, $offset );
                $offset += 4;
                $shortenedFilePath = substr( $recordData, $offset, $sl );
                $shortenedFilePath = ( $shortenedFilePath, TRUE );
                $shortenedFilePath = substr( $shortenedFilePath, 0, -1 );
                $offset += $sl;
                $offset += 24;
                $sz = ( $recordData, $offset );
                $offset += 4;
                if ( 0 < $sz )
                {
                    $xl = ( $recordData, $offset );
                    $offset += 4;
                    $offset += 2;
                    $extendedFilePath = substr( $recordData, $offset, $xl );
                    $extendedFilePath = ( $extendedFilePath, FALSE );
                    $offset += $xl;
                }
                $url = str_repeat( "..\\", $upLevelCount );
                $url .= 0 < $sz ? $extendedFilePath : $shortenedFilePath;
                $url .= $hasText ? "#" : "";
                break;
            case "UNC" :
                return;
            case "workbook" :
                $url = "sheet://";
                break;
            default :
                return;
        }
        if ( $hasText )
        {
            $tl = ( $recordData, $offset );
            $offset += 4;
            $text = ( substr( $recordData, $offset, 2 * ( $tl - 1 ) ), FALSE );
            $url .= $text;
        }
        foreach ( ( $cellRange ) as $coordinate )
        {
            $this->_phpSheet->getCell( $coordinate )->getHyperLink( )->setUrl( $url );
        }
    }
}

    private function _readDataValidations( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _515804720 += "_pos";
    }

    private function _readDataValidation( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _515803144 += "_pos";
        if ( $this->_readDataOnly )
        {
        }
        else
        {
            $options = ( $recordData, 0 );
            $type = ( 15 & $options ) >> 0;
            switch ( $type )
            {
                case 0 :
                    $type = PHPExcel_Cell_DataValidation::TYPE_NONE;
                    break;
                case 1 :
                    $type = PHPExcel_Cell_DataValidation::TYPE_WHOLE;
                    break;
                case 2 :
                    $type = PHPExcel_Cell_DataValidation::TYPE_DECIMAL;
                    break;
                case 3 :
                    $type = PHPExcel_Cell_DataValidation::TYPE_LIST;
                    break;
                case 4 :
                    $type = PHPExcel_Cell_DataValidation::TYPE_DATE;
                    break;
                case 5 :
                    $type = PHPExcel_Cell_DataValidation::TYPE_TIME;
                    break;
                case 6 :
                    $type = PHPExcel_Cell_DataValidation::TYPE_TEXTLENGTH;
                    break;
                case 7 :
                    $type = PHPExcel_Cell_DataValidation::TYPE_CUSTOM;
            }
            $errorStyle = ( 112 & $options ) >> 4;
            switch ( $errorStyle )
            {
                case 0 :
                    $errorStyle = PHPExcel_Cell_DataValidation::STYLE_STOP;
                    break;
                case 1 :
                    $errorStyle = PHPExcel_Cell_DataValidation::STYLE_WARNING;
                    break;
                case 2 :
                    $errorStyle = PHPExcel_Cell_DataValidation::STYLE_INFORMATION;
            }
            $explicitFormula = ( 128 & $options ) >> 7;
            $allowBlank = ( 256 & $options ) >> 8;
            $suppressDropDown = ( 512 & $options ) >> 9;
            $showInputMessage = ( 262144 & $options ) >> 18;
            $showErrorMessage = ( 524288 & $options ) >> 19;
            $operator = ( 15728640 & $options ) >> 20;
            switch ( $operator )
            {
                case 0 :
                    $operator = PHPExcel_Cell_DataValidation::OPERATOR_BETWEEN;
                    break;
                case 1 :
                    $operator = PHPExcel_Cell_DataValidation::OPERATOR_NOTBETWEEN;
                    break;
                case 2 :
                    $operator = PHPExcel_Cell_DataValidation::OPERATOR_EQUAL;
                    break;
                case 3 :
                    $operator = PHPExcel_Cell_DataValidation::OPERATOR_NOTEQUAL;
                    break;
                case 4 :
                    $operator = PHPExcel_Cell_DataValidation::OPERATOR_GREATERTHAN;
                    break;
                case 5 :
                    $operator = PHPExcel_Cell_DataValidation::OPERATOR_LESSTHAN;
                    break;
                case 6 :
                    $operator = PHPExcel_Cell_DataValidation::OPERATOR_GREATERTHANOREQUAL;
                    break;
                case 7 :
                    $operator = PHPExcel_Cell_DataValidation::OPERATOR_LESSTHANOREQUAL;
            }
            $offset = 4;
            $string = ( substr( $recordData, $offset ) );
            $promptTitle = $string['value'] !== chr( 0 ) ? $string['value'] : "";
            $offset += $string['size'];
            $string = ( substr( $recordData, $offset ) );
            $errorTitle = $string['value'] !== chr( 0 ) ? $string['value'] : "";
            $offset += $string['size'];
            $string = ( substr( $recordData, $offset ) );
            $prompt = $string['value'] !== chr( 0 ) ? $string['value'] : "";
            $offset += $string['size'];
            $string = ( substr( $recordData, $offset ) );
            $error = $string['value'] !== chr( 0 ) ? $string['value'] : "";
            $offset += $string['size'];
            $sz1 = ( $recordData, $offset );
            $offset += 2;
            $offset += 2;
            $formula1 = substr( $recordData, $offset, $sz1 );
            $formula1 = pack( "v", $sz1 ).$formula1;
            do
            {
                try
                {
                    $formula1 = $this->_getFormulaFromStructure( $formula1 );
                    if ( !( $type == PHPExcel_Cell_DataValidation::TYPE_LIST ) )
                    {
                        break;
                    }
                    else
                    {
                        $formula1 = str_replace( chr( 0 ), ",", $formula1 );
                        break;
                    }
                }
                catch ( PHPExcel_Exception $e )
                {
                    return;
            }
        } while ( 0 );
        $offset += $sz1;
        $sz2 = ( $recordData, $offset );
        $offset += 2;
        $offset += 2;
        $formula2 = substr( $recordData, $offset, $sz2 );
        $formula2 = pack( "v", $sz2 ).$formula2;
        try
        {
            $formula2 = $this->_getFormulaFromStructure( $formula2 );
        }
        catch ( PHPExcel_Exception $e )
        {
            return;
    }
    $offset += $sz2;
    $cellRangeAddressList = substr( $recordData, $offset )( substr( $recordData, $offset ) );
    $cellRangeAddresses = $cellRangeAddressList['cellRangeAddresses'];
    foreach ( $cellRangeAddresses as $cellRange )
    {
        $stRange = $this->_phpSheet->shrinkRangeToFit( $cellRange );
        $stRange = ( $stRange );
        foreach ( $stRange as $coordinate )
        {
            $objValidation = $this->_phpSheet->getCell( $coordinate )->getDataValidation( );
            $objValidation->setType( $type );
            $objValidation->setErrorStyle( $errorStyle );
            $objValidation->setAllowBlank( $allowBlank );
            $objValidation->setShowInputMessage( $showInputMessage );
            $objValidation->setShowErrorMessage( $showErrorMessage );
            $objValidation->setShowDropDown( !$suppressDropDown );
            $objValidation->setOperator( $operator );
            $objValidation->setErrorTitle( $errorTitle );
            $objValidation->setError( $error );
            $objValidation->setPromptTitle( $promptTitle );
            $objValidation->setPrompt( $prompt );
            $objValidation->setFormula1( $formula1 );
            $objValidation->setFormula2( $formula2 );
        }
    }
}
}

    private function _readSheetLayout( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _515809896 += "_pos";
        $offset = 0;
        if ( $this->_readDataOnly )
        {
            $sz = ( $recordData, 12 );
            switch ( $sz )
            {
                case 20 :
                    $colorIndex = ( $recordData, 16 );
                    $color = ( $colorIndex, $this->_palette, $this->_version );
                    $this->_phpSheet->getTabColor( )->setRGB( $color['rgb'] );
                    return;
                case 40 :
            }
        }
        else
        {
        }
    }

    private function _readSheetProtection( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _515772160 += "_pos";
        if ( $this->_readDataOnly )
        {
        }
        else
        {
            $isf = ( $recordData, 12 );
            if ( $isf != 2 )
            {
            }
            else
            {
                $options = ( $recordData, 19 );
                $bool = ( 1 & $options ) >> 0;
                $this->_phpSheet->getProtection( )->setObjects( !$bool );
                $bool = ( 2 & $options ) >> 1;
                $this->_phpSheet->getProtection( )->setScenarios( !$bool );
                $bool = ( 4 & $options ) >> 2;
                $this->_phpSheet->getProtection( )->setFormatCells( !$bool );
                $bool = ( 8 & $options ) >> 3;
                $this->_phpSheet->getProtection( )->setFormatColumns( !$bool );
                $bool = ( 16 & $options ) >> 4;
                $this->_phpSheet->getProtection( )->setFormatRows( !$bool );
                $bool = ( 32 & $options ) >> 5;
                $this->_phpSheet->getProtection( )->setInsertColumns( !$bool );
                $bool = ( 64 & $options ) >> 6;
                $this->_phpSheet->getProtection( )->setInsertRows( !$bool );
                $bool = ( 128 & $options ) >> 7;
                $this->_phpSheet->getProtection( )->setInsertHyperlinks( !$bool );
                $bool = ( 256 & $options ) >> 8;
                $this->_phpSheet->getProtection( )->setDeleteColumns( !$bool );
                $bool = ( 512 & $options ) >> 9;
                $this->_phpSheet->getProtection( )->setDeleteRows( !$bool );
                $bool = ( 1024 & $options ) >> 10;
                $this->_phpSheet->getProtection( )->setSelectLockedCells( !$bool );
                $bool = ( 2048 & $options ) >> 11;
                $this->_phpSheet->getProtection( )->setSort( !$bool );
                $bool = ( 4096 & $options ) >> 12;
                $this->_phpSheet->getProtection( )->setAutoFilter( !$bool );
                $bool = ( 8192 & $options ) >> 13;
                $this->_phpSheet->getProtection( )->setPivotTables( !$bool );
                $bool = ( 16384 & $options ) >> 14;
                $this->_phpSheet->getProtection( )->setSelectUnlockedCells( !$bool );
            }
        }
    }

    private function _readRangeProtection( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        $ && _515770992 += "_pos";
        $offset = 0;
        if ( $this->_readDataOnly )
        {
            $offset += 12;
            $isf = ( $recordData, 12 );
            if ( $isf != 2 )
            {
            }
            else
            {
                $offset += 2;
                $offset += 5;
                $cref = ( $recordData, 19 );
                $offset += 2;
                $offset += 6;
                $cellRanges = array( );
                $i = 0;
                for ( ; $i < $cref; ++$i )
                {
                    try
                    {
                        $cellRange = substr( $recordData, 27 + 8 * $i, 8 )( substr( $recordData, 27 + 8 * $i, 8 ) );
                    }
                    catch ( PHPExcel_Exception $e )
                    {
                        return;
                }
                $cellRanges[] = $cellRange;
                $offset += 8;
            }
            $rgbFeat = substr( $recordData, $offset );
            $offset += 4;
            $wPassword = ( $recordData, $offset );
            $offset += 4;
            if ( $cellRanges )
            {
                $this->_phpSheet->protectCells( implode( " ", $cellRanges ), strtoupper( dechex( $wPassword ) ), TRUE );
            }
        }
    }
}

    private function _readImData( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $splicedRecordData = $this->_getSplicedRecordData( );
        $recordData = $splicedRecordData['recordData'];
        $cf = ( $recordData, 0 );
        $env = ( $recordData, 2 );
        $lcb = ( $recordData, 4 );
        $iData = substr( $recordData, 8 );
        switch ( $cf )
        {
            case 9 :
                $bcSize = ( $iData, 0 );
                $bcWidth = ( $iData, 4 );
                $bcHeight = ( $iData, 6 );
                $ih = imagecreatetruecolor( $bcWidth, $bcHeight );
                $bcBitCount = ( $iData, 10 );
                $rgbString = substr( $iData, 12 );
                $rgbTriples = array( );
                while ( 0 < strlen( $rgbString ) )
                {
                    $rgbTriples[] = unpack( "Cb/Cg/Cr", $rgbString );
                    $rgbString = substr( $rgbString, 3 );
                }
                $x = 0;
                $y = 0;
                foreach ( $rgbTriples as $i => $rgbTriple )
                {
                    $color = imagecolorallocate( $ih, $rgbTriple['r'], $rgbTriple['g'], $rgbTriple['b'] );
                    imagesetpixel( $ih, $x, $bcHeight - 1 - $y, $color );
                    $x = ( $x + 1 ) % $bcWidth;
                    $y += floor( ( $x + 1 ) / $bcWidth );
                }
                $drawing = new PHPExcel_Worksheet_Drawing( );
                $drawing->setPath( $filename );
                $this->_phpSheet( $this->_phpSheet );
                return;
            case 2 :
            case 14 :
        }
    }

    private function _readContinue( )
    {
        $length = ( $this->_data, $this->_pos + 2 );
        $recordData = substr( $this->_data, $this->_pos + 4, $length );
        if ( $this->_drawingData == "" )
        {
            $ && _515771552 += "_pos";
        }
        else if ( $length < 4 )
        {
            $ && _515771552 += "_pos";
        }
        else
        {
            $validSplitPoints = array( 61443, 61444, 61453 );
            $splitPoint = ( $recordData, 2 );
            if ( in_array( $splitPoint, $validSplitPoints ) )
            {
                $splicedRecordData = $this->_getSplicedRecordData( );
                $ && _515771552 .= "_drawingData";
            }
            else
            {
                $ && _515771552 += "_pos";
            }
        }
    }

    private function _getSplicedRecordData( )
    {
        $data = "";
        $spliceOffsets = array( );
        $i = 0;
        $spliceOffsets[0] = 0;
        do
        {
            ++$i;
            $identifier = ( $this->_data, $this->_pos );
            $length = ( $this->_data, $this->_pos + 2 );
            $data .= substr( $this->_data, $this->_pos + 4, $length );
            $spliceOffsets[$i] = $spliceOffsets[$i - 1] + $length;
            $ && _515772016 += "_pos";
            $nextIdentifier = ( $this->_data, $this->_pos );
        } while ( $nextIdentifier == self::XLS_Type_CONTINUE );
        $splicedData = array( "recordData" => $data, "spliceOffsets" => $spliceOffsets );
        return $splicedData;
    }

    private function _getFormulaFromStructure( $formulaStructure, $baseCell = "A1" )
    {
        $sz = ( $formulaStructure, 0 );
        $formulaData = substr( $formulaStructure, 2, $sz );
        if ( 2 + $sz < strlen( $formulaStructure ) )
        {
            $additionalData = substr( $formulaStructure, 2 + $sz );
        }
        else
        {
            $additionalData = "";
        }
        return $this->_getFormulaFromData( $formulaData, $additionalData, $baseCell );
    }

    private function _getFormulaFromData( $formulaData, $additionalData = "", $baseCell = "A1" )
    {
        $tokens = array( );
        while ( !( 0 < strlen( $formulaData ) ) || !( $token = $this->_getNextToken( $formulaData, $baseCell ) ) )
        {
            $tokens[] = $token;
            $formulaData = substr( $formulaData, $token['size'] );
        }
        $formulaString = $this->_createFormulaFromTokens( $tokens, $additionalData );
        return $formulaString;
    }

    private function _createFormulaFromTokens( $tokens, $additionalData )
    {
        if ( empty( $tokens ) )
        {
            return "";
        }
        $formulaStrings = array( );
        foreach ( $tokens as $token )
        {
            $space0 = isset( $space0 ) ? $space0 : "";
            $space1 = isset( $space1 ) ? $space1 : "";
            $space2 = isset( $space2 ) ? $space2 : "";
            $space3 = isset( $space3 ) ? $space3 : "";
            $space4 = isset( $space4 ) ? $space4 : "";
            $space5 = isset( $space5 ) ? $space5 : "";
            switch ( $token['name'] )
            {
                case "tAdd" :
                case "tConcat" :
                case "tDiv" :
                case "tEQ" :
                case "tGE" :
                case "tGT" :
                case "tIsect" :
                case "tLE" :
                case "tList" :
                case "tLT" :
                case "tMul" :
                case "tNE" :
                case "tPower" :
                case "tRange" :
                case "tSub" :
                    $op2 = array_pop( &$formulaStrings );
                    $op1 = array_pop( &$formulaStrings );
                    $formulaStrings[] = "{$op1}{$space1}{$space0}{$token['data']}{$op2}";
                    unset( $space0 );
                    unset( $space1 );
                    break;
                case "tUplus" :
                case "tUminus" :
                    $op = array_pop( &$formulaStrings );
                    $formulaStrings[] = "{$space1}{$space0}{$token['data']}{$op}";
                    unset( $space0 );
                    unset( $space1 );
                    break;
                case "tPercent" :
                    $op = array_pop( &$formulaStrings );
                    $formulaStrings[] = "{$op}{$space1}{$space0}{$token['data']}";
                    unset( $space0 );
                    unset( $space1 );
                    break;
                case "tAttrVolatile" :
                case "tAttrIf" :
                case "tAttrSkip" :
                case "tAttrChoose" :
                case "tAttrSpace" :
                    switch ( $token['data']['spacetype'] )
                    {
                        case "type0" :
                            $space0 = str_repeat( " ", $token['data']['spacecount'] );
                            break;
                        case "type1" :
                            $space1 = str_repeat( "\n", $token['data']['spacecount'] );
                            break;
                        case "type2" :
                            $space2 = str_repeat( " ", $token['data']['spacecount'] );
                            break;
                        case "type3" :
                            $space3 = str_repeat( "\n", $token['data']['spacecount'] );
                            break;
                        case "type4" :
                            $space4 = str_repeat( " ", $token['data']['spacecount'] );
                            break;
                        case "type5" :
                            $space5 = str_repeat( "\n", $token['data']['spacecount'] );
                    }
                    break;
                case "tAttrSum" :
                    $op = array_pop( &$formulaStrings );
                    $formulaStrings[] = "{$space1}{$space0}SUM({$op})";
                    unset( $space0 );
                    unset( $space1 );
                    break;
                case "tFunc" :
                case "tFuncV" :
                    if ( $token['data']['function'] != "" )
                    {
                        $ops = array( );
                        $i = 0;
                        for ( ; $i < $token['data']['args']; ++$i )
                        {
                            $ops[] = array_pop( &$formulaStrings );
                        }
                        $ops = array_reverse( $ops );
                        $formulaStrings[] = "{$space1}{$space0}{$token['data']['function']}(".implode( ",", $ops ).")";
                        unset( $space0 );
                        unset( $space1 );
                        break;
                    }
                    else
                    {
                        $ops = array( );
                        $i = 0;
                        for ( ; $i < $token['data']['args'] - 1; ++$i )
                        {
                            $ops[] = array_pop( &$formulaStrings );
                        }
                        $ops = array_reverse( $ops );
                        $function = array_pop( &$formulaStrings );
                        $formulaStrings[] = "{$space1}{$space0}{$function}(".implode( ",", $ops ).")";
                        unset( $space0 );
                        unset( $space1 );
                        break;
                    }
                case "tParen" :
                    $expression = array_pop( &$formulaStrings );
                    $formulaStrings[] = "{$space3}{$space2}({$expression}{$space5}{$space4})";
                    unset( $space2 );
                    unset( $space3 );
                    unset( $space4 );
                    unset( $space5 );
                    break;
                case "tArray" :
                    $constantArray = ( $additionalData );
                    $formulaStrings[] = $space1.$space0.$constantArray['value'];
                    $additionalData = substr( $additionalData, $constantArray['size'] );
                    unset( $space0 );
                    unset( $space1 );
                    break;
                case "tMemArea" :
                    $cellRangeAddressList = $this->_readBIFF8CellRangeAddressList( $additionalData );
                    $additionalData = substr( $additionalData, $cellRangeAddressList['size'] );
                    $formulaStrings[] = "{$space1}{$space0}{$token['data']}";
                    unset( $space0 );
                    unset( $space1 );
                    break;
                case "tArea" :
                case "tBool" :
                case "tErr" :
                case "tInt" :
                case "tMemErr" :
                case "tMemFunc" :
                case "tMissArg" :
                case "tName" :
                case "tNameX" :
                case "tNum" :
                case "tRef" :
                case "tRef3d" :
                case "tArea3d" :
                case "tRefN" :
                case "tAreaN" :
                case "tStr" :
                    $formulaStrings[] = "{$space1}{$space0}{$token['data']}";
                    unset( $space0 );
                    unset( $space1 );
            }
        }
        $formulaString = $formulaStrings[0];
        return $formulaString;
    }

    private function _getNextToken( $formulaData, $baseCell = "A1" )
    {
        $id = ord( $formulaData[0] );
        $name = FALSE;
        switch ( $id )
        {
            case 3 :
                $name = "tAdd";
                $size = 1;
                $data = "+";
                break;
            case 4 :
                $name = "tSub";
                $size = 1;
                $data = "-";
                break;
            case 5 :
                $name = "tMul";
                $size = 1;
                $data = "*";
                break;
            case 6 :
                $name = "tDiv";
                $size = 1;
                $data = "/";
                break;
            case 7 :
                $name = "tPower";
                $size = 1;
                $data = "^";
                break;
            case 8 :
                $name = "tConcat";
                $size = 1;
                $data = "&";
                break;
            case 9 :
                $name = "tLT";
                $size = 1;
                $data = "<";
                break;
            case 10 :
                $name = "tLE";
                $size = 1;
                $data = "<=";
                break;
            case 11 :
                $name = "tEQ";
                $size = 1;
                $data = "=";
                break;
            case 12 :
                $name = "tGE";
                $size = 1;
                $data = ">=";
                break;
            case 13 :
                $name = "tGT";
                $size = 1;
                $data = ">";
                break;
            case 14 :
                $name = "tNE";
                $size = 1;
                $data = "<>";
                break;
            case 15 :
                $name = "tIsect";
                $size = 1;
                $data = " ";
                break;
            case 16 :
                $name = "tList";
                $size = 1;
                $data = ",";
                break;
            case 17 :
                $name = "tRange";
                $size = 1;
                $data = ":";
                break;
            case 18 :
                $name = "tUplus";
                $size = 1;
                $data = "+";
                break;
            case 19 :
                $name = "tUminus";
                $size = 1;
                $data = "-";
                break;
            case 20 :
                $name = "tPercent";
                $size = 1;
                $data = "%";
                break;
            case 21 :
                $name = "tParen";
                $size = 1;
                $data = NULL;
                break;
            case 22 :
                $name = "tMissArg";
                $size = 1;
                $data = "";
                break;
            case 23 :
                $name = "tStr";
                $string = ( substr( $formulaData, 1 ) );
                $size = 1 + $string['size'];
                $data = ( $string['value'] );
                break;
            case 25 :
                switch ( ord( $formulaData[1] ) )
                {
                    case 1 :
                        $name = "tAttrVolatile";
                        $size = 4;
                        $data = NULL;
                        break;
                    case 2 :
                        $name = "tAttrIf";
                        $size = 4;
                        $data = NULL;
                        break;
                    case 4 :
                        $name = "tAttrChoose";
                        $nc = ( $formulaData, 2 );
                        $size = 2 * $nc + 6;
                        $data = NULL;
                        break;
                    case 8 :
                        $name = "tAttrSkip";
                        $size = 4;
                        $data = NULL;
                        break;
                    case 16 :
                        $name = "tAttrSum";
                        $size = 4;
                        $data = NULL;
                        break;
                    case 64 :
                    case 65 :
                        $name = "tAttrSpace";
                        $size = 4;
                        switch ( ord( $formulaData[2] ) )
                        {
                            case 0 :
                                $spacetype = "type0";
                                break;
                            case 1 :
                                $spacetype = "type1";
                                break;
                            case 2 :
                                $spacetype = "type2";
                                break;
                            case 3 :
                                $spacetype = "type3";
                                break;
                            case 4 :
                                $spacetype = "type4";
                                break;
                            case 5 :
                                $spacetype = "type5";
                                break;
                            default :
                                throw new PHPExcel_Reader_Exception( "Unrecognized space type in tAttrSpace token" );
                        }
                        $spacecount = ord( $formulaData[3] );
                        $data = array( "spacetype" => $spacetype, "spacecount" => $spacecount );
                        break;
                    default :
                        throw new PHPExcel_Reader_Exception( "Unrecognized attribute flag in tAttr token" );
                }
                break;
            case 28 :
                $name = "tErr";
                $size = 2;
                $data = ( ord( $formulaData[1] ) );
                break;
            case 29 :
                $name = "tBool";
                $size = 2;
                $data = ord( $formulaData[1] ) ? "TRUE" : "FALSE";
                break;
            case 30 :
                $name = "tInt";
                $size = 3;
                $data = ( $formulaData, 1 );
                break;
            case 31 :
                $name = "tNum";
                $size = 9;
                $data = ( substr( $formulaData, 1 ) );
                $data = str_replace( ",", ".", ( boolean ) );
                break;
            case 32 :
            case 64 :
            case 96 :
                $name = "tArray";
                $size = 8;
                $data = NULL;
                break;
            case 33 :
            case 65 :
            case 97 :
                $name = "tFunc";
                $size = 3;
                switch ( ( $formulaData, 1 ) )
                {
                    case 2 :
                        $function = "ISNA";
                        $args = 1;
                        break;
                    case 3 :
                        $function = "ISERROR";
                        $args = 1;
                        break;
                    case 10 :
                        $function = "NA";
                        $args = 0;
                        break;
                    case 15 :
                        $function = "SIN";
                        $args = 1;
                        break;
                    case 16 :
                        $function = "COS";
                        $args = 1;
                        break;
                    case 17 :
                        $function = "TAN";
                        $args = 1;
                        break;
                    case 18 :
                        $function = "ATAN";
                        $args = 1;
                        break;
                    case 19 :
                        $function = "PI";
                        $args = 0;
                        break;
                    case 20 :
                        $function = "SQRT";
                        $args = 1;
                        break;
                    case 21 :
                        $function = "EXP";
                        $args = 1;
                        break;
                    case 22 :
                        $function = "LN";
                        $args = 1;
                        break;
                    case 23 :
                        $function = "LOG10";
                        $args = 1;
                        break;
                    case 24 :
                        $function = "ABS";
                        $args = 1;
                        break;
                    case 25 :
                        $function = "INT";
                        $args = 1;
                        break;
                    case 26 :
                        $function = "SIGN";
                        $args = 1;
                        break;
                    case 27 :
                        $function = "ROUND";
                        $args = 2;
                        break;
                    case 30 :
                        $function = "REPT";
                        $args = 2;
                        break;
                    case 31 :
                        $function = "MID";
                        $args = 3;
                        break;
                    case 32 :
                        $function = "LEN";
                        $args = 1;
                        break;
                    case 33 :
                        $function = "VALUE";
                        $args = 1;
                        break;
                    case 34 :
                        $function = "TRUE";
                        $args = 0;
                        break;
                    case 35 :
                        $function = "FALSE";
                        $args = 0;
                        break;
                    case 38 :
                        $function = "NOT";
                        $args = 1;
                        break;
                    case 39 :
                        $function = "MOD";
                        $args = 2;
                        break;
                    case 40 :
                        $function = "DCOUNT";
                        $args = 3;
                        break;
                    case 41 :
                        $function = "DSUM";
                        $args = 3;
                        break;
                    case 42 :
                        $function = "DAVERAGE";
                        $args = 3;
                        break;
                    case 43 :
                        $function = "DMIN";
                        $args = 3;
                        break;
                    case 44 :
                        $function = "DMAX";
                        $args = 3;
                        break;
                    case 45 :
                        $function = "DSTDEV";
                        $args = 3;
                        break;
                    case 48 :
                        $function = "TEXT";
                        $args = 2;
                        break;
                    case 61 :
                        $function = "MIRR";
                        $args = 3;
                        break;
                    case 63 :
                        $function = "RAND";
                        $args = 0;
                        break;
                    case 65 :
                        $function = "DATE";
                        $args = 3;
                        break;
                    case 66 :
                        $function = "TIME";
                        $args = 3;
                        break;
                    case 67 :
                        $function = "DAY";
                        $args = 1;
                        break;
                    case 68 :
                        $function = "MONTH";
                        $args = 1;
                        break;
                    case 69 :
                        $function = "YEAR";
                        $args = 1;
                        break;
                    case 71 :
                        $function = "HOUR";
                        $args = 1;
                        break;
                    case 72 :
                        $function = "MINUTE";
                        $args = 1;
                        break;
                    case 73 :
                        $function = "SECOND";
                        $args = 1;
                        break;
                    case 74 :
                        $function = "NOW";
                        $args = 0;
                        break;
                    case 75 :
                        $function = "AREAS";
                        $args = 1;
                        break;
                    case 76 :
                        $function = "ROWS";
                        $args = 1;
                        break;
                    case 77 :
                        $function = "COLUMNS";
                        $args = 1;
                        break;
                    case 83 :
                        $function = "TRANSPOSE";
                        $args = 1;
                        break;
                    case 86 :
                        $function = "TYPE";
                        $args = 1;
                        break;
                    case 97 :
                        $function = "ATAN2";
                        $args = 2;
                        break;
                    case 98 :
                        $function = "ASIN";
                        $args = 1;
                        break;
                    case 99 :
                        $function = "ACOS";
                        $args = 1;
                        break;
                    case 105 :
                        $function = "ISREF";
                        $args = 1;
                        break;
                    case 111 :
                        $function = "CHAR";
                        $args = 1;
                        break;
                    case 112 :
                        $function = "LOWER";
                        $args = 1;
                        break;
                    case 113 :
                        $function = "UPPER";
                        $args = 1;
                        break;
                    case 114 :
                        $function = "PROPER";
                        $args = 1;
                        break;
                    case 117 :
                        $function = "EXACT";
                        $args = 2;
                        break;
                    case 118 :
                        $function = "TRIM";
                        $args = 1;
                        break;
                    case 119 :
                        $function = "REPLACE";
                        $args = 4;
                        break;
                    case 121 :
                        $function = "CODE";
                        $args = 1;
                        break;
                    case 126 :
                        $function = "ISERR";
                        $args = 1;
                        break;
                    case 127 :
                        $function = "ISTEXT";
                        $args = 1;
                        break;
                    case 128 :
                        $function = "ISNUMBER";
                        $args = 1;
                        break;
                    case 129 :
                        $function = "ISBLANK";
                        $args = 1;
                        break;
                    case 130 :
                        $function = "T";
                        $args = 1;
                        break;
                    case 131 :
                        $function = "N";
                        $args = 1;
                        break;
                    case 140 :
                        $function = "DATEVALUE";
                        $args = 1;
                        break;
                    case 141 :
                        $function = "TIMEVALUE";
                        $args = 1;
                        break;
                    case 142 :
                        $function = "SLN";
                        $args = 3;
                        break;
                    case 143 :
                        $function = "SYD";
                        $args = 4;
                        break;
                    case 162 :
                        $function = "CLEAN";
                        $args = 1;
                        break;
                    case 163 :
                        $function = "MDETERM";
                        $args = 1;
                        break;
                    case 164 :
                        $function = "MINVERSE";
                        $args = 1;
                        break;
                    case 165 :
                        $function = "MMULT";
                        $args = 2;
                        break;
                    case 184 :
                        $function = "FACT";
                        $args = 1;
                        break;
                    case 189 :
                        $function = "DPRODUCT";
                        $args = 3;
                        break;
                    case 190 :
                        $function = "ISNONTEXT";
                        $args = 1;
                        break;
                    case 195 :
                        $function = "DSTDEVP";
                        $args = 3;
                        break;
                    case 196 :
                        $function = "DVARP";
                        $args = 3;
                        break;
                    case 198 :
                        $function = "ISLOGICAL";
                        $args = 1;
                        break;
                    case 199 :
                        $function = "DCOUNTA";
                        $args = 3;
                        break;
                    case 207 :
                        $function = "REPLACEB";
                        $args = 4;
                        break;
                    case 210 :
                        $function = "MIDB";
                        $args = 3;
                        break;
                    case 211 :
                        $function = "LENB";
                        $args = 1;
                        break;
                    case 212 :
                        $function = "ROUNDUP";
                        $args = 2;
                        break;
                    case 213 :
                        $function = "ROUNDDOWN";
                        $args = 2;
                        break;
                    case 214 :
                        $function = "ASC";
                        $args = 1;
                        break;
                    case 215 :
                        $function = "DBCS";
                        $args = 1;
                        break;
                    case 221 :
                        $function = "TODAY";
                        $args = 0;
                        break;
                    case 229 :
                        $function = "SINH";
                        $args = 1;
                        break;
                    case 230 :
                        $function = "COSH";
                        $args = 1;
                        break;
                    case 231 :
                        $function = "TANH";
                        $args = 1;
                        break;
                    case 232 :
                        $function = "ASINH";
                        $args = 1;
                        break;
                    case 233 :
                        $function = "ACOSH";
                        $args = 1;
                        break;
                    case 234 :
                        $function = "ATANH";
                        $args = 1;
                        break;
                    case 235 :
                        $function = "DGET";
                        $args = 3;
                        break;
                    case 244 :
                        $function = "INFO";
                        $args = 1;
                        break;
                    case 252 :
                        $function = "FREQUENCY";
                        $args = 2;
                        break;
                    case 261 :
                        $function = "ERROR.TYPE";
                        $args = 1;
                        break;
                    case 271 :
                        $function = "GAMMALN";
                        $args = 1;
                        break;
                    case 273 :
                        $function = "BINOMDIST";
                        $args = 4;
                        break;
                    case 274 :
                        $function = "CHIDIST";
                        $args = 2;
                        break;
                    case 275 :
                        $function = "CHIINV";
                        $args = 2;
                        break;
                    case 276 :
                        $function = "COMBIN";
                        $args = 2;
                        break;
                    case 277 :
                        $function = "CONFIDENCE";
                        $args = 3;
                        break;
                    case 278 :
                        $function = "CRITBINOM";
                        $args = 3;
                        break;
                    case 279 :
                        $function = "EVEN";
                        $args = 1;
                        break;
                    case 280 :
                        $function = "EXPONDIST";
                        $args = 3;
                        break;
                    case 281 :
                        $function = "FDIST";
                        $args = 3;
                        break;
                    case 282 :
                        $function = "FINV";
                        $args = 3;
                        break;
                    case 283 :
                        $function = "FISHER";
                        $args = 1;
                        break;
                    case 284 :
                        $function = "FISHERINV";
                        $args = 1;
                        break;
                    case 285 :
                        $function = "FLOOR";
                        $args = 2;
                        break;
                    case 286 :
                        $function = "GAMMADIST";
                        $args = 4;
                        break;
                    case 287 :
                        $function = "GAMMAINV";
                        $args = 3;
                        break;
                    case 288 :
                        $function = "CEILING";
                        $args = 2;
                        break;
                    case 289 :
                        $function = "HYPGEOMDIST";
                        $args = 4;
                        break;
                    case 290 :
                        $function = "LOGNORMDIST";
                        $args = 3;
                        break;
                    case 291 :
                        $function = "LOGINV";
                        $args = 3;
                        break;
                    case 292 :
                        $function = "NEGBINOMDIST";
                        $args = 3;
                        break;
                    case 293 :
                        $function = "NORMDIST";
                        $args = 4;
                        break;
                    case 294 :
                        $function = "NORMSDIST";
                        $args = 1;
                        break;
                    case 295 :
                        $function = "NORMINV";
                        $args = 3;
                        break;
                    case 296 :
                        $function = "NORMSINV";
                        $args = 1;
                        break;
                    case 297 :
                        $function = "STANDARDIZE";
                        $args = 3;
                        break;
                    case 298 :
                        $function = "ODD";
                        $args = 1;
                        break;
                    case 299 :
                        $function = "PERMUT";
                        $args = 2;
                        break;
                    case 300 :
                        $function = "POISSON";
                        $args = 3;
                        break;
                    case 301 :
                        $function = "TDIST";
                        $args = 3;
                        break;
                    case 302 :
                        $function = "WEIBULL";
                        $args = 4;
                        break;
                    case 303 :
                        $function = "SUMXMY2";
                        $args = 2;
                        break;
                    case 304 :
                        $function = "SUMX2MY2";
                        $args = 2;
                        break;
                    case 305 :
                        $function = "SUMX2PY2";
                        $args = 2;
                        break;
                    case 306 :
                        $function = "CHITEST";
                        $args = 2;
                        break;
                    case 307 :
                        $function = "CORREL";
                        $args = 2;
                        break;
                    case 308 :
                        $function = "COVAR";
                        $args = 2;
                        break;
                    case 309 :
                        $function = "FORECAST";
                        $args = 3;
                        break;
                    case 310 :
                        $function = "FTEST";
                        $args = 2;
                        break;
                    case 311 :
                        $function = "INTERCEPT";
                        $args = 2;
                        break;
                    case 312 :
                        $function = "PEARSON";
                        $args = 2;
                        break;
                    case 313 :
                        $function = "RSQ";
                        $args = 2;
                        break;
                    case 314 :
                        $function = "STEYX";
                        $args = 2;
                        break;
                    case 315 :
                        $function = "SLOPE";
                        $args = 2;
                        break;
                    case 316 :
                        $function = "TTEST";
                        $args = 4;
                        break;
                    case 325 :
                        $function = "LARGE";
                        $args = 2;
                        break;
                    case 326 :
                        $function = "SMALL";
                        $args = 2;
                        break;
                    case 327 :
                        $function = "QUARTILE";
                        $args = 2;
                        break;
                    case 328 :
                        $function = "PERCENTILE";
                        $args = 2;
                        break;
                    case 331 :
                        $function = "TRIMMEAN";
                        $args = 2;
                        break;
                    case 332 :
                        $function = "TINV";
                        $args = 2;
                        break;
                    case 337 :
                        $function = "POWER";
                        $args = 2;
                        break;
                    case 342 :
                        $function = "RADIANS";
                        $args = 1;
                        break;
                    case 343 :
                        $function = "DEGREES";
                        $args = 1;
                        break;
                    case 346 :
                        $function = "COUNTIF";
                        $args = 2;
                        break;
                    case 347 :
                        $function = "COUNTBLANK";
                        $args = 1;
                        break;
                    case 350 :
                        $function = "ISPMT";
                        $args = 4;
                        break;
                    case 351 :
                        $function = "DATEDIF";
                        $args = 3;
                        break;
                    case 352 :
                        $function = "DATESTRING";
                        $args = 1;
                        break;
                    case 353 :
                        $function = "NUMBERSTRING";
                        $args = 2;
                        break;
                    case 360 :
                        $function = "PHONETIC";
                        $args = 1;
                        break;
                    case 368 :
                        $function = "BAHTTEXT";
                        $args = 1;
                        break;
                    default :
                        throw new PHPExcel_Reader_Exception( "Unrecognized function in formula" );
                }
                $data = array( "function" => $function, "args" => $args );
                break;
            case 34 :
            case 66 :
            case 98 :
                $name = "tFuncV";
                $size = 4;
                $args = ord( $formulaData[1] );
                $index = ( $formulaData, 2 );
                switch ( $index )
                {
                    case 0 :
                        $function = "COUNT";
                        break;
                    case 1 :
                        $function = "IF";
                        break;
                    case 4 :
                        $function = "SUM";
                        break;
                    case 5 :
                        $function = "AVERAGE";
                        break;
                    case 6 :
                        $function = "MIN";
                        break;
                    case 7 :
                        $function = "MAX";
                        break;
                    case 8 :
                        $function = "ROW";
                        break;
                    case 9 :
                        $function = "COLUMN";
                        break;
                    case 11 :
                        $function = "NPV";
                        break;
                    case 12 :
                        $function = "STDEV";
                        break;
                    case 13 :
                        $function = "DOLLAR";
                        break;
                    case 14 :
                        $function = "FIXED";
                        break;
                    case 28 :
                        $function = "LOOKUP";
                        break;
                    case 29 :
                        $function = "INDEX";
                        break;
                    case 36 :
                        $function = "AND";
                        break;
                    case 37 :
                        $function = "OR";
                        break;
                    case 46 :
                        $function = "VAR";
                        break;
                    case 49 :
                        $function = "LINEST";
                        break;
                    case 50 :
                        $function = "TREND";
                        break;
                    case 51 :
                        $function = "LOGEST";
                        break;
                    case 52 :
                        $function = "GROWTH";
                        break;
                    case 56 :
                        $function = "PV";
                        break;
                    case 57 :
                        $function = "FV";
                        break;
                    case 58 :
                        $function = "NPER";
                        break;
                    case 59 :
                        $function = "PMT";
                        break;
                    case 60 :
                        $function = "RATE";
                        break;
                    case 62 :
                        $function = "IRR";
                        break;
                    case 64 :
                        $function = "MATCH";
                        break;
                    case 70 :
                        $function = "WEEKDAY";
                        break;
                    case 78 :
                        $function = "OFFSET";
                        break;
                    case 82 :
                        $function = "SEARCH";
                        break;
                    case 100 :
                        $function = "CHOOSE";
                        break;
                    case 101 :
                        $function = "HLOOKUP";
                        break;
                    case 102 :
                        $function = "VLOOKUP";
                        break;
                    case 109 :
                        $function = "LOG";
                        break;
                    case 115 :
                        $function = "LEFT";
                        break;
                    case 116 :
                        $function = "RIGHT";
                        break;
                    case 120 :
                        $function = "SUBSTITUTE";
                        break;
                    case 124 :
                        $function = "FIND";
                        break;
                    case 125 :
                        $function = "CELL";
                        break;
                    case 144 :
                        $function = "DDB";
                        break;
                    case 148 :
                        $function = "INDIRECT";
                        break;
                    case 167 :
                        $function = "IPMT";
                        break;
                    case 168 :
                        $function = "PPMT";
                        break;
                    case 169 :
                        $function = "COUNTA";
                        break;
                    case 183 :
                        $function = "PRODUCT";
                        break;
                    case 193 :
                        $function = "STDEVP";
                        break;
                    case 194 :
                        $function = "VARP";
                        break;
                    case 197 :
                        $function = "TRUNC";
                        break;
                    case 204 :
                        $function = "USDOLLAR";
                        break;
                    case 205 :
                        $function = "FINDB";
                        break;
                    case 206 :
                        $function = "SEARCHB";
                        break;
                    case 208 :
                        $function = "LEFTB";
                        break;
                    case 209 :
                        $function = "RIGHTB";
                        break;
                    case 216 :
                        $function = "RANK";
                        break;
                    case 219 :
                        $function = "ADDRESS";
                        break;
                    case 220 :
                        $function = "DAYS360";
                        break;
                    case 222 :
                        $function = "VDB";
                        break;
                    case 227 :
                        $function = "MEDIAN";
                        break;
                    case 228 :
                        $function = "SUMPRODUCT";
                        break;
                    case 247 :
                        $function = "DB";
                        break;
                    case 255 :
                        $function = "";
                        break;
                    case 269 :
                        $function = "AVEDEV";
                        break;
                    case 270 :
                        $function = "BETADIST";
                        break;
                    case 272 :
                        $function = "BETAINV";
                        break;
                    case 317 :
                        $function = "PROB";
                        break;
                    case 318 :
                        $function = "DEVSQ";
                        break;
                    case 319 :
                        $function = "GEOMEAN";
                        break;
                    case 320 :
                        $function = "HARMEAN";
                        break;
                    case 321 :
                        $function = "SUMSQ";
                        break;
                    case 322 :
                        $function = "KURT";
                        break;
                    case 323 :
                        $function = "SKEW";
                        break;
                    case 324 :
                        $function = "ZTEST";
                        break;
                    case 329 :
                        $function = "PERCENTRANK";
                        break;
                    case 330 :
                        $function = "MODE";
                        break;
                    case 336 :
                        $function = "CONCATENATE";
                        break;
                    case 344 :
                        $function = "SUBTOTAL";
                        break;
                    case 345 :
                        $function = "SUMIF";
                        break;
                    case 354 :
                        $function = "ROMAN";
                        break;
                    case 358 :
                        $function = "GETPIVOTDATA";
                        break;
                    case 359 :
                        $function = "HYPERLINK";
                        break;
                    case 361 :
                        $function = "AVERAGEA";
                        break;
                    case 362 :
                        $function = "MAXA";
                        break;
                    case 363 :
                        $function = "MINA";
                        break;
                    case 364 :
                        $function = "STDEVPA";
                        break;
                    case 365 :
                        $function = "VARPA";
                        break;
                    case 366 :
                        $function = "STDEVA";
                        break;
                    case 367 :
                        $function = "VARA";
                        break;
                    default :
                        throw new PHPExcel_Reader_Exception( "Unrecognized function in formula" );
                }
                $data = array( "function" => $function, "args" => $args );
                break;
            case 35 :
            case 67 :
            case 99 :
                $name = "tName";
                $size = 5;
                $definedNameIndex = ( $formulaData, 1 ) - 1;
                $data = $this->_definedname[$definedNameIndex]['name'];
                break;
            case 36 :
            case 68 :
            case 100 :
                $name = "tRef";
                $size = 5;
                $data = substr( $formulaData, 1, 4 )( substr( $formulaData, 1, 4 ) );
                break;
            case 37 :
            case 69 :
            case 101 :
                $name = "tArea";
                $size = 9;
                $data = substr( $formulaData, 1, 8 )( substr( $formulaData, 1, 8 ) );
                break;
            case 38 :
            case 70 :
            case 102 :
                $name = "tMemArea";
                $subSize = ( $formulaData, 5 );
                $size = 7 + $subSize;
                $data = substr( $formulaData, 7, $subSize )( substr( $formulaData, 7, $subSize ) );
                break;
            case 39 :
            case 71 :
            case 103 :
                $name = "tMemErr";
                $subSize = ( $formulaData, 5 );
                $size = 7 + $subSize;
                $data = substr( $formulaData, 7, $subSize )( substr( $formulaData, 7, $subSize ) );
                break;
            case 41 :
            case 73 :
            case 105 :
                $name = "tMemFunc";
                $subSize = ( $formulaData, 1 );
                $size = 3 + $subSize;
                $data = substr( $formulaData, 3, $subSize )( substr( $formulaData, 3, $subSize ) );
                break;
            case 44 :
            case 76 :
            case 108 :
                $name = "tRefN";
                $size = 5;
                $data = substr( $formulaData, 1, 4 )( substr( $formulaData, 1, 4 ), $baseCell );
                break;
            case 45 :
            case 77 :
            case 109 :
                $name = "tAreaN";
                $size = 9;
                $data = substr( $formulaData, 1, 8 )( substr( $formulaData, 1, 8 ), $baseCell );
                break;
            case 57 :
            case 89 :
            case 121 :
                $name = "tNameX";
                $size = 7;
                $index = ( $formulaData, 3 );
                $data = $this->_externalNames[$index - 1]['name'];
                break;
            case 58 :
            case 90 :
            case 122 :
                $name = "tRef3d";
                $size = 7;
                try
                {
                    $sheetRange = ( $formulaData, 1 )( ( $formulaData, 1 ) );
                    $cellAddress = substr( $formulaData, 3, 4 )( substr( $formulaData, 3, 4 ) );
                    $data = "{$sheetRange}!{$cellAddress}";
                    break;
                }
                catch ( PHPExcel_Exception $e )
                {
                    $data = "#REF!";
            }
            break;
        case 59 :
        case 91 :
        case 123 :
            $name = "tArea3d";
            $size = 11;
            try
            {
                $sheetRange = ( $formulaData, 1 )( ( $formulaData, 1 ) );
                $cellRangeAddress = substr( $formulaData, 3, 8 )( substr( $formulaData, 3, 8 ) );
                $data = "{$sheetRange}!{$cellRangeAddress}";
                break;
            }
            catch ( PHPExcel_Exception $e )
            {
                $data = "#REF!";
        }
        break;
    default :
        throw new PHPExcel_Reader_Exception( "Unrecognized token ".sprintf( "%02X", $id )." in formula" );
}
return array( "id" => $id, "name" => $name, "size" => $size, "data" => $data );
}

    private function _readBIFF8CellAddress( $cellAddressStructure )
    {
        $row = ( $cellAddressStructure, 0 ) + 1;
        $column = ( 255 & ( $cellAddressStructure, 2 ) );
        if ( 16384 & ( $cellAddressStructure, 2 ) )
        {
            $column = "\$".$column;
        }
        if ( 32768 & ( $cellAddressStructure, 2 ) )
        {
            $row = "\$".$row;
        }
        return $column.$row;
    }

    private function _readBIFF8CellAddressB( $cellAddressStructure, $baseCell = "A1" )
    {
        list( $baseCol, $baseRow ) = ( $baseCell );
        $baseCol = ( $baseCol ) - 1;
        $rowIndex = ( $cellAddressStructure, 0 );
        $row = ( $cellAddressStructure, 0 ) + 1;
        $colIndex = 255 & ( $cellAddressStructure, 2 );
        if ( 16384 & ( $cellAddressStructure, 2 ) )
        {
            $column = ( $colIndex );
            $column = "\$".$column;
        }
        else
        {
            $colIndex = $colIndex <= 127 ? $colIndex : $colIndex - 256;
            $column = ( $baseCol + $colIndex );
        }
        if ( 32768 & ( $cellAddressStructure, 2 ) )
        {
            $row = "\$".$row;
        }
        else
        {
            $rowIndex = $rowIndex <= 32767 ? $rowIndex : $rowIndex - 65536;
            $row = $baseRow + $rowIndex;
        }
        return $column.$row;
    }

    private function _readBIFF5CellRangeAddressFixed( $subData )
    {
        $fr = ( $subData, 0 ) + 1;
        $lr = ( $subData, 2 ) + 1;
        $fc = ord( $subData[4] );
        $lc = ord( $subData[5] );
        if ( $lr < $fr || $lc < $fc )
        {
            throw new PHPExcel_Reader_Exception( "Not a cell range address" );
        }
        $fc = ( $fc );
        $lc = ( $lc );
        if ( $fr == $lr && $fc == $lc )
        {
            return "{$fc}{$fr}";
        }
        return "{$fc}{$fr}:{$lc}{$lr}";
    }

    private function _readBIFF8CellRangeAddressFixed( $subData )
    {
        $fr = ( $subData, 0 ) + 1;
        $lr = ( $subData, 2 ) + 1;
        $fc = ( $subData, 4 );
        $lc = ( $subData, 6 );
        if ( $lr < $fr || $lc < $fc )
        {
            throw new PHPExcel_Reader_Exception( "Not a cell range address" );
        }
        $fc = ( $fc );
        $lc = ( $lc );
        if ( $fr == $lr && $fc == $lc )
        {
            return "{$fc}{$fr}";
        }
        return "{$fc}{$fr}:{$lc}{$lr}";
    }

    private function _readBIFF8CellRangeAddress( $subData )
    {
        $fr = ( $subData, 0 ) + 1;
        $lr = ( $subData, 2 ) + 1;
        $fc = ( 255 & ( $subData, 4 ) );
        if ( 16384 & ( $subData, 4 ) )
        {
            $fc = "\$".$fc;
        }
        if ( 32768 & ( $subData, 4 ) )
        {
            $fr = "\$".$fr;
        }
        $lc = ( 255 & ( $subData, 6 ) );
        if ( 16384 & ( $subData, 6 ) )
        {
            $lc = "\$".$lc;
        }
        if ( 32768 & ( $subData, 6 ) )
        {
            $lr = "\$".$lr;
        }
        return "{$fc}{$fr}:{$lc}{$lr}";
    }

    private function _readBIFF8CellRangeAddressB( $subData, $baseCell = "A1" )
    {
        list( $baseCol, $baseRow ) = ( $baseCell );
        $baseCol = ( $baseCol ) - 1;
        $frIndex = ( $subData, 0 );
        $lrIndex = ( $subData, 2 );
        $fcIndex = 255 & ( $subData, 4 );
        if ( 16384 & ( $subData, 4 ) )
        {
            $fc = ( $fcIndex );
            $fc = "\$".$fc;
        }
        else
        {
            $fcIndex = $fcIndex <= 127 ? $fcIndex : $fcIndex - 256;
            $fc = ( $baseCol + $fcIndex );
        }
        if ( 32768 & ( $subData, 4 ) )
        {
            $fr = $frIndex + 1;
            $fr = "\$".$fr;
        }
        else
        {
            $frIndex = $frIndex <= 32767 ? $frIndex : $frIndex - 65536;
            $fr = $baseRow + $frIndex;
        }
        $lcIndex = 255 & ( $subData, 6 );
        $lcIndex = $lcIndex <= 127 ? $lcIndex : $lcIndex - 256;
        $lc = ( $baseCol + $lcIndex );
        if ( 16384 & ( $subData, 6 ) )
        {
            $lc = ( $lcIndex );
            $lc = "\$".$lc;
        }
        else
        {
            $lcIndex = $lcIndex <= 127 ? $lcIndex : $lcIndex - 256;
            $lc = ( $baseCol + $lcIndex );
        }
        if ( 32768 & ( $subData, 6 ) )
        {
            $lr = $lrIndex + 1;
            $lr = "\$".$lr;
        }
        else
        {
            $lrIndex = $lrIndex <= 32767 ? $lrIndex : $lrIndex - 65536;
            $lr = $baseRow + $lrIndex;
        }
        return "{$fc}{$fr}:{$lc}{$lr}";
    }

    private function _readBIFF8CellRangeAddressList( $subData )
    {
        $cellRangeAddresses = array( );
        $nm = ( $subData, 0 );
        $offset = 2;
        $i = 0;
        for ( ; $i < $nm; ++$i )
        {
            $cellRangeAddresses[] = substr( $subData, $offset, 8 )( substr( $subData, $offset, 8 ) );
            $offset += 8;
        }
        return array( "size" => 2 + 8 * $nm, "cellRangeAddresses" => $cellRangeAddresses );
    }

    private function _readBIFF5CellRangeAddressList( $subData )
    {
        $cellRangeAddresses = array( );
        $nm = ( $subData, 0 );
        $offset = 2;
        $i = 0;
        for ( ; $i < $nm; ++$i )
        {
            $cellRangeAddresses[] = substr( $subData, $offset, 6 )( substr( $subData, $offset, 6 ) );
            $offset += 6;
        }
        return array( "size" => 2 + 6 * $nm, "cellRangeAddresses" => $cellRangeAddresses );
    }

    private function _readSheetRangeByRefIndex( $index )
    {
        if ( isset( $this->_ref[$index] ) )
        {
            $type = $this->_externalBooks[$this->_ref[$index]['externalBookIndex']]['type'];
            switch ( $type )
            {
                case "internal" :
                    if ( $this->_ref[$index]['firstSheetIndex'] == 65535 || $this->_ref[$index]['lastSheetIndex'] == 65535 )
                    {
                        throw new PHPExcel_Reader_Exception( "Deleted sheet reference" );
                    }
                    $firstSheetName = $this->_sheets[$this->_ref[$index]['firstSheetIndex']]['name'];
                    $lastSheetName = $this->_sheets[$this->_ref[$index]['lastSheetIndex']]['name'];
                    if ( $firstSheetName == $lastSheetName )
                    {
                        $sheetRange = $firstSheetName;
                    }
                    else
                    {
                        $sheetRange = "{$firstSheetName}:{$lastSheetName}";
                    }
                    $sheetRange = str_replace( "'", "''", $sheetRange );
                    if ( preg_match( "/[ !\"@#£$%&{()}<>=+'|^,;-]/", $sheetRange ) )
                    {
                        $sheetRange = "'".$sheetRange."'";
                    }
                    return $sheetRange;
            }
            throw new PHPExcel_Reader_Exception( "Excel5 reader only supports internal sheets in fomulas" );
        }
        return FALSE;
    }

    private static function _readBIFF8ConstantArray( $arrayData )
    {
        $nc = ord( $arrayData[0] );
        $nr = ( $arrayData, 1 );
        $size = 3;
        $arrayData = substr( $arrayData, 3 );
        $matrixChunks = array( );
        $r = 1;
        for ( ; $r <= $nr + 1; ++$r )
        {
            $items = array( );
            $c = 1;
            for ( ; $c <= $nc + 1; ++$c )
            {
                $constant = ( $arrayData );
                $items[] = $constant['value'];
                $arrayData = substr( $arrayData, $constant['size'] );
                $size += $constant['size'];
            }
            $matrixChunks[] = implode( ",", $items );
        }
        $matrix = "{".implode( ";", $matrixChunks )."}";
        return array( "value" => $matrix, "size" => $size );
    }

    private static function _readBIFF8Constant( $valueData )
    {
        $identifier = ord( $valueData[0] );
        switch ( $identifier )
        {
            case 0 :
                $value = "";
                $size = 9;
            case 1 :
                $value = ( substr( $valueData, 1, 8 ) );
                $size = 9;
            case 2 :
                $string = ( substr( $valueData, 1 ) );
                $value = "\"".$string['value']."\"";
                $size = 1 + $string['size'];
            case 4 :
                if ( ord( $valueData[1] ) )
                {
                    $value = "TRUE";
                }
                else
                {
                    $value = "FALSE";
                }
                $size = 9;
            case 16 :
                $value = ( ord( $valueData[1] ) );
                $size = 9;
            default :
                return array( "value" => $value, "size" => $size );
        }
    }

    private static function _readRGB( $rgb )
    {
        $r = ord( $rgb[0] );
        $g = ord( $rgb[1] );
        $b = ord( $rgb[2] );
        $rgb = sprintf( "%02X%02X%02X", $r, $g, $b );
        return array( "rgb" => $rgb );
    }

    private function _readByteStringShort( $subData )
    {
        $ln = ord( $subData[0] );
        $value = substr( $subData, 1, $ln )( substr( $subData, 1, $ln ) );
        return array( "value" => $value, "size" => 1 + $ln );
    }

    private function _readByteStringLong( $subData )
    {
        $ln = ( $subData, 0 );
        $value = substr( $subData, 2 )( substr( $subData, 2 ) );
        return array( "value" => $value, "size" => 2 + $ln );
    }

    private static function _readUnicodeStringShort( $subData )
    {
        $value = "";
        $characterCount = ord( $subData[0] );
        $string = ( substr( $subData, 1 ), $characterCount );
        $string += "size";
        return $string;
    }

    private static function _readUnicodeStringLong( $subData )
    {
        $value = "";
        $characterCount = ( $subData, 0 );
        $string = ( substr( $subData, 2 ), $characterCount );
        $string += "size";
        return $string;
    }

    private static function _readUnicodeString( $subData, $characterCount )
    {
        $value = "";
        $isCompressed = !( ( 1 & ord( $subData[0] ) ) >> 0 );
        $hasAsian = 4 & ord( $subData[0] ) >> 2;
        $hasRichText = 8 & ord( $subData[0] ) >> 3;
        $value = ( substr( $subData, 1, $isCompressed ? $characterCount : 2 * $characterCount ), $isCompressed );
        return array( "value" => $value, "size" => $isCompressed ? 1 + $characterCount : 1 + 2 * $characterCount );
    }

    private static function _UTF8toExcelDoubleQuoted( $value )
    {
        return "\"".str_replace( "\"", "\"\"", $value )."\"";
    }

    private static function _extractNumber( $data )
    {
        $rknumhigh = ( $data, 4 );
        $rknumlow = ( $data, 0 );
        $sign = ( $rknumhigh & 2.14748e+009 ) >> 31;
        $exp = ( ( $rknumhigh & 2146435072 ) >> 20 ) - 1023;
        $mantissa = 1048576 | $rknumhigh & 1048575;
        $mantissalow1 = ( $rknumlow & 2.14748e+009 ) >> 31;
        $mantissalow2 = $rknumlow & 2147483647;
        $value = $mantissa / pow( 2, 20 - $exp );
        if ( $mantissalow1 != 0 )
        {
            $value += 1 / pow( 2, 21 - $exp );
        }
        $value += $mantissalow2 / pow( 2, 52 - $exp );
        if ( $sign )
        {
            $value *= -1;
        }
        return $value;
    }

    private static function _GetIEEE754( $rknum )
    {
        if ( ( $rknum & 2 ) != 0 )
        {
            $value = $rknum >> 2;
        }
        else
        {
            $sign = ( $rknum & 2.14748e+009 ) >> 31;
            $exp = ( $rknum & 2146435072 ) >> 20;
            $mantissa = 1048576 | $rknum & 1048572;
            $value = $mantissa / pow( 2, 20 - ( $exp - 1023 ) );
            if ( $sign )
            {
                $value = 0 - 1 * $value;
            }
        }
        if ( ( $rknum & 1 ) != 0 )
        {
            $value /= 100;
        }
        return $value;
    }

    private static function _encodeUTF16( $string, $compressed = "" )
    {
        if ( $compressed )
        {
            $string = ( $string );
        }
        return ( $string, "UTF-8", "UTF-16LE" );
    }

    private static function _uncompressByteString( $string )
    {
        $uncompressedString = "";
        $strLen = strlen( $string );
        $i = 0;
        for ( ; $i < $strLen; ++$i )
        {
            $uncompressedString .= $string[$i]."\x00";
        }
        return $uncompressedString;
    }

    private function _decodeCodepage( $string )
    {
        return ( $string, "UTF-8", $this->_codepage );
    }

    public static function _GetInt2d( $data, $pos )
    {
        return ord( $data[$pos] ) | ord( $data[$pos + 1] ) << 8;
    }

    public static function _GetInt4d( $data, $pos )
    {
        $_or_24 = ord( $data[$pos + 3] );
        if ( 128 <= $_or_24 )
        {
            $_ord_24 = 0 - abs( 256 - $_or_24 << 24 );
        }
        else
        {
            $_ord_24 = ( $_or_24 & 127 ) << 24;
        }
        return ord( $data[$pos] ) | ord( $data[$pos + 1] ) << 8 | ord( $data[$pos + 2] ) << 16 | $_ord_24;
    }

    private static function _readColor( $color, $palette, $version )
    {
        if ( $color <= 7 || 64 <= $color )
        {
            return ( $color );
        }
        if ( isset( $palette ) && isset( $palette[$color - 8] ) )
        {
            return $palette[$color - 8];
        }
        if ( $version == self::XLS_BIFF8 )
        {
            return ( $color );
        }
        return ( $color );
    }

    private static function _mapBorderStyle( $index )
    {
        switch ( $index )
        {
            case 0 :
                return PHPExcel_Style_Border::BORDER_NONE;
            case 1 :
                return PHPExcel_Style_Border::BORDER_THIN;
            case 2 :
                return PHPExcel_Style_Border::BORDER_MEDIUM;
            case 3 :
                return PHPExcel_Style_Border::BORDER_DASHED;
            case 4 :
                return PHPExcel_Style_Border::BORDER_DOTTED;
            case 5 :
                return PHPExcel_Style_Border::BORDER_THICK;
            case 6 :
                return PHPExcel_Style_Border::BORDER_DOUBLE;
            case 7 :
                return PHPExcel_Style_Border::BORDER_HAIR;
            case 8 :
                return PHPExcel_Style_Border::BORDER_MEDIUMDASHED;
            case 9 :
                return PHPExcel_Style_Border::BORDER_DASHDOT;
            case 10 :
                return PHPExcel_Style_Border::BORDER_MEDIUMDASHDOT;
            case 11 :
                return PHPExcel_Style_Border::BORDER_DASHDOTDOT;
            case 12 :
                return PHPExcel_Style_Border::BORDER_MEDIUMDASHDOTDOT;
            case 13 :
                return PHPExcel_Style_Border::BORDER_SLANTDASHDOT;
            default :
                return PHPExcel_Style_Border::BORDER_NONE;
        }
    }

    private static function _mapFillPattern( $index )
    {
        switch ( $index )
        {
            case 0 :
                return PHPExcel_Style_Fill::FILL_NONE;
            case 1 :
                return PHPExcel_Style_Fill::FILL_SOLID;
            case 2 :
                return PHPExcel_Style_Fill::FILL_PATTERN_MEDIUMGRAY;
            case 3 :
                return PHPExcel_Style_Fill::FILL_PATTERN_DARKGRAY;
            case 4 :
                return PHPExcel_Style_Fill::FILL_PATTERN_LIGHTGRAY;
            case 5 :
                return PHPExcel_Style_Fill::FILL_PATTERN_DARKHORIZONTAL;
            case 6 :
                return PHPExcel_Style_Fill::FILL_PATTERN_DARKVERTICAL;
            case 7 :
                return PHPExcel_Style_Fill::FILL_PATTERN_DARKDOWN;
            case 8 :
                return PHPExcel_Style_Fill::FILL_PATTERN_DARKUP;
            case 9 :
                return PHPExcel_Style_Fill::FILL_PATTERN_DARKGRID;
            case 10 :
                return PHPExcel_Style_Fill::FILL_PATTERN_DARKTRELLIS;
            case 11 :
                return PHPExcel_Style_Fill::FILL_PATTERN_LIGHTHORIZONTAL;
            case 12 :
                return PHPExcel_Style_Fill::FILL_PATTERN_LIGHTVERTICAL;
            case 13 :
                return PHPExcel_Style_Fill::FILL_PATTERN_LIGHTDOWN;
            case 14 :
                return PHPExcel_Style_Fill::FILL_PATTERN_LIGHTUP;
            case 15 :
                return PHPExcel_Style_Fill::FILL_PATTERN_LIGHTGRID;
            case 16 :
                return PHPExcel_Style_Fill::FILL_PATTERN_LIGHTTRELLIS;
            case 17 :
                return PHPExcel_Style_Fill::FILL_PATTERN_GRAY125;
            case 18 :
                return PHPExcel_Style_Fill::FILL_PATTERN_GRAY0625;
            default :
                return PHPExcel_Style_Fill::FILL_NONE;
        }
    }

    private static function _mapErrorCode( $subData )
    {
        switch ( $subData )
        {
            case 0 :
                return "#NULL!";
            case 7 :
                return "#DIV/0!";
            case 15 :
                return "#VALUE!";
            case 23 :
                return "#REF!";
            case 29 :
                return "#NAME?";
            case 36 :
                return "#NUM!";
            case 42 :
                return "#N/A";
            default :
                return FALSE;
        }
    }

    private static function _mapBuiltInColor( $color )
    {
        switch ( $color )
        {
            case 0 :
                return array( "rgb" => "000000" );
            case 1 :
                return array( "rgb" => "FFFFFF" );
            case 2 :
                return array( "rgb" => "FF0000" );
            case 3 :
                return array( "rgb" => "00FF00" );
            case 4 :
                return array( "rgb" => "0000FF" );
            case 5 :
                return array( "rgb" => "FFFF00" );
            case 6 :
                return array( "rgb" => "FF00FF" );
            case 7 :
                return array( "rgb" => "00FFFF" );
            case 64 :
                return array( "rgb" => "000000" );
            case 65 :
                return array( "rgb" => "FFFFFF" );
            default :
                return array( "rgb" => "000000" );
        }
    }

    private static function _mapColorBIFF5( $subData )
    {
        switch ( $subData )
        {
            case 8 :
                return array( "rgb" => "000000" );
            case 9 :
                return array( "rgb" => "FFFFFF" );
            case 10 :
                return array( "rgb" => "FF0000" );
            case 11 :
                return array( "rgb" => "00FF00" );
            case 12 :
                return array( "rgb" => "0000FF" );
            case 13 :
                return array( "rgb" => "FFFF00" );
            case 14 :
                return array( "rgb" => "FF00FF" );
            case 15 :
                return array( "rgb" => "00FFFF" );
            case 16 :
                return array( "rgb" => "800000" );
            case 17 :
                return array( "rgb" => "008000" );
            case 18 :
                return array( "rgb" => "000080" );
            case 19 :
                return array( "rgb" => "808000" );
            case 20 :
                return array( "rgb" => "800080" );
            case 21 :
                return array( "rgb" => "008080" );
            case 22 :
                return array( "rgb" => "C0C0C0" );
            case 23 :
                return array( "rgb" => "808080" );
            case 24 :
                return array( "rgb" => "8080FF" );
            case 25 :
                return array( "rgb" => "802060" );
            case 26 :
                return array( "rgb" => "FFFFC0" );
            case 27 :
                return array( "rgb" => "A0E0F0" );
            case 28 :
                return array( "rgb" => "600080" );
            case 29 :
                return array( "rgb" => "FF8080" );
            case 30 :
                return array( "rgb" => "0080C0" );
            case 31 :
                return array( "rgb" => "C0C0FF" );
            case 32 :
                return array( "rgb" => "000080" );
            case 33 :
                return array( "rgb" => "FF00FF" );
            case 34 :
                return array( "rgb" => "FFFF00" );
            case 35 :
                return array( "rgb" => "00FFFF" );
            case 36 :
                return array( "rgb" => "800080" );
            case 37 :
                return array( "rgb" => "800000" );
            case 38 :
                return array( "rgb" => "008080" );
            case 39 :
                return array( "rgb" => "0000FF" );
            case 40 :
                return array( "rgb" => "00CFFF" );
            case 41 :
                return array( "rgb" => "69FFFF" );
            case 42 :
                return array( "rgb" => "E0FFE0" );
            case 43 :
                return array( "rgb" => "FFFF80" );
            case 44 :
                return array( "rgb" => "A6CAF0" );
            case 45 :
                return array( "rgb" => "DD9CB3" );
            case 46 :
                return array( "rgb" => "B38FEE" );
            case 47 :
                return array( "rgb" => "E3E3E3" );
            case 48 :
                return array( "rgb" => "2A6FF9" );
            case 49 :
                return array( "rgb" => "3FB8CD" );
            case 50 :
                return array( "rgb" => "488436" );
            case 51 :
                return array( "rgb" => "958C41" );
            case 52 :
                return array( "rgb" => "8E5E42" );
            case 53 :
                return array( "rgb" => "A0627A" );
            case 54 :
                return array( "rgb" => "624FAC" );
            case 55 :
                return array( "rgb" => "969696" );
            case 56 :
                return array( "rgb" => "1D2FBE" );
            case 57 :
                return array( "rgb" => "286676" );
            case 58 :
                return array( "rgb" => "004500" );
            case 59 :
                return array( "rgb" => "453E01" );
            case 60 :
                return array( "rgb" => "6A2813" );
            case 61 :
                return array( "rgb" => "85396A" );
            case 62 :
                return array( "rgb" => "4A3285" );
            case 63 :
                return array( "rgb" => "424242" );
            default :
                return array( "rgb" => "000000" );
        }
    }

    private static function _mapColor( $subData )
    {
        switch ( $subData )
        {
            case 8 :
                return array( "rgb" => "000000" );
            case 9 :
                return array( "rgb" => "FFFFFF" );
            case 10 :
                return array( "rgb" => "FF0000" );
            case 11 :
                return array( "rgb" => "00FF00" );
            case 12 :
                return array( "rgb" => "0000FF" );
            case 13 :
                return array( "rgb" => "FFFF00" );
            case 14 :
                return array( "rgb" => "FF00FF" );
            case 15 :
                return array( "rgb" => "00FFFF" );
            case 16 :
                return array( "rgb" => "800000" );
            case 17 :
                return array( "rgb" => "008000" );
            case 18 :
                return array( "rgb" => "000080" );
            case 19 :
                return array( "rgb" => "808000" );
            case 20 :
                return array( "rgb" => "800080" );
            case 21 :
                return array( "rgb" => "008080" );
            case 22 :
                return array( "rgb" => "C0C0C0" );
            case 23 :
                return array( "rgb" => "808080" );
            case 24 :
                return array( "rgb" => "9999FF" );
            case 25 :
                return array( "rgb" => "993366" );
            case 26 :
                return array( "rgb" => "FFFFCC" );
            case 27 :
                return array( "rgb" => "CCFFFF" );
            case 28 :
                return array( "rgb" => "660066" );
            case 29 :
                return array( "rgb" => "FF8080" );
            case 30 :
                return array( "rgb" => "0066CC" );
            case 31 :
                return array( "rgb" => "CCCCFF" );
            case 32 :
                return array( "rgb" => "000080" );
            case 33 :
                return array( "rgb" => "FF00FF" );
            case 34 :
                return array( "rgb" => "FFFF00" );
            case 35 :
                return array( "rgb" => "00FFFF" );
            case 36 :
                return array( "rgb" => "800080" );
            case 37 :
                return array( "rgb" => "800000" );
            case 38 :
                return array( "rgb" => "008080" );
            case 39 :
                return array( "rgb" => "0000FF" );
            case 40 :
                return array( "rgb" => "00CCFF" );
            case 41 :
                return array( "rgb" => "CCFFFF" );
            case 42 :
                return array( "rgb" => "CCFFCC" );
            case 43 :
                return array( "rgb" => "FFFF99" );
            case 44 :
                return array( "rgb" => "99CCFF" );
            case 45 :
                return array( "rgb" => "FF99CC" );
            case 46 :
                return array( "rgb" => "CC99FF" );
            case 47 :
                return array( "rgb" => "FFCC99" );
            case 48 :
                return array( "rgb" => "3366FF" );
            case 49 :
                return array( "rgb" => "33CCCC" );
            case 50 :
                return array( "rgb" => "99CC00" );
            case 51 :
                return array( "rgb" => "FFCC00" );
            case 52 :
                return array( "rgb" => "FF9900" );
            case 53 :
                return array( "rgb" => "FF6600" );
            case 54 :
                return array( "rgb" => "666699" );
            case 55 :
                return array( "rgb" => "969696" );
            case 56 :
                return array( "rgb" => "003366" );
            case 57 :
                return array( "rgb" => "339966" );
            case 58 :
                return array( "rgb" => "003300" );
            case 59 :
                return array( "rgb" => "333300" );
            case 60 :
                return array( "rgb" => "993300" );
            case 61 :
                return array( "rgb" => "993366" );
            case 62 :
                return array( "rgb" => "333399" );
            case 63 :
                return array( "rgb" => "333333" );
            default :
                return array( "rgb" => "000000" );
        }
    }

    private function _parseRichText( $is = "" )
    {
        $value = new PHPExcel_RichText( );
        $value->createText( $is );
        return $value;
    }

}

?>
