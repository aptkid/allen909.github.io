<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class PHPExcel_Reader_Excel2007_Chart
{

    private static function _getAttribute( $component, $name, $format )
    {
        $attributes = $component->attributes( );
        if ( isset( $attributes[$name] ) )
        {
            if ( $format == "string" )
            {
                return ( boolean );
            }
            if ( $format == "integer" )
            {
                return ( integer );
            }
            if ( $format == "boolean" )
            {
                if ( $attributes[$name] === "0" || $attributes[$name] !== "true" )
                {
                    return FALSE;
                }
                return TRUE;
            }
            return ( double );
        }
    }

    private static function _readColor( $color, $background = FALSE )
    {
        if ( isset( $color['rgb'] ) )
        {
            return ( boolean );
        }
        if ( isset( $color['indexed'] ) )
        {
            return ( $color['indexed'] - 7, $background )->getARGB( );
        }
    }

    public static function readChart( $chartElements, $chartName )
    {
        $namespacesChartMeta = $chartElements->getNamespaces( TRUE );
        $chartElementsC = $namespacesChartMeta['c']( $namespacesChartMeta['c'] );
        $XaxisLabel = $YaxisLabel = $legend = $title = NULL;
        $dispBlanksAs = $plotVisOnly = NULL;
}
foreach ( $chartElementsC as $chartElementKey => $chartElement )
{
    switch ( $chartElementKey )
    {
        case "chart" :
    }
}
}
}
}
foreach ( $chartElement as $chartDetailsKey => $chartDetails )
{
    $chartDetailsC = $namespacesChartMeta['c']( $namespacesChartMeta['c'] );
case "plotArea" :
    switch ( $chartDetailsKey )
    {
            $plotAreaLayout = $XaxisLable = $YaxisLable = NULL;
            $plotSeries = $plotAttributes = array( );
    }
}
}
}
}
}
}
}
}
}
}
}
}
foreach ( $chartDetails as $chartDetailKey => $chartDetail )
{
case "layout" :
    switch ( $chartDetailKey )
    {
            $plotAreaLayout = ( $chartDetail, $namespacesChartMeta, "plotArea" );
            continue;
        case "catAx" :
            switch ( $chartDetailKey )
            {
                    if ( isset( $chartDetail->title ) )
                    {
                        $XaxisLabel = ( $chartDetail->title->children( $namespacesChartMeta['c'] ), $namespacesChartMeta, "cat" );
                        continue;
                    }
                case "dateAx" :
                    switch ( $chartDetailKey )
                    {
                            if ( isset( $chartDetail->title ) )
                            {
                                $XaxisLabel = ( $chartDetail->title->children( $namespacesChartMeta['c'] ), $namespacesChartMeta, "cat" );
                                continue;
                            }
                        case "valAx" :
                            switch ( $chartDetailKey )
                            {
                                    if ( isset( $chartDetail->title ) )
                                    {
                                        $YaxisLabel = ( $chartDetail->title->children( $namespacesChartMeta['c'] ), $namespacesChartMeta, "cat" );
                                        continue;
                                    }
                                case "barChart" :
                                    switch ( $chartDetailKey )
                                    {
                                        case "bar3DChart" :
                                            $barDirection = ( $chartDetail->barDir, "val", "string" );
                                            $plotSer = ( $chartDetail, $namespacesChartMeta, $chartDetailKey );
                                            $plotSer->setPlotDirection( $barDirection );
                                            $plotSeries[] = $plotSer;
                                            $plotAttributes = ( $chartDetail );
                                            continue;
                                        case "lineChart" :
                                            switch ( $chartDetailKey )
                                            {
                                                case "line3DChart" :
                                                    $plotSeries[] = ( $chartDetail, $namespacesChartMeta, $chartDetailKey );
                                                    $plotAttributes = ( $chartDetail );
                                                    continue;
                                                case "areaChart" :
                                                    switch ( $chartDetailKey )
                                                    {
                                                        case "area3DChart" :
                                                            $plotSeries[] = ( $chartDetail, $namespacesChartMeta, $chartDetailKey );
                                                            $plotAttributes = ( $chartDetail );
                                                            continue;
                                                        case "doughnutChart" :
                                                            switch ( $chartDetailKey )
                                                            {
                                                                case "pieChart" :
                                                                case "pie3DChart" :
                                                                    $explosion = isset( $chartDetail->ser->explosion );
                                                                    $plotSer = ( $chartDetail, $namespacesChartMeta, $chartDetailKey );
                                                                    $plotSer->setPlotStyle( $explosion );
                                                                    $plotSeries[] = $plotSer;
                                                                    $plotAttributes = ( $chartDetail );
                                                                    continue;
                                                                case "scatterChart" :
                                                                    switch ( $chartDetailKey )
                                                                    {
                                                                            $scatterStyle = ( $chartDetail->scatterStyle, "val", "string" );
                                                                            $plotSer = ( $chartDetail, $namespacesChartMeta, $chartDetailKey );
                                                                            $plotSer->setPlotStyle( $scatterStyle );
                                                                            $plotSeries[] = $plotSer;
                                                                            $plotAttributes = ( $chartDetail );
                                                                            continue;
                                                                        case "bubbleChart" :
                                                                            switch ( $chartDetailKey )
                                                                            {
                                                                                    $bubbleScale = ( $chartDetail->bubbleScale, "val", "integer" );
                                                                                    $plotSer = ( $chartDetail, $namespacesChartMeta, $chartDetailKey );
                                                                                    $plotSer->setPlotStyle( $bubbleScale );
                                                                                    $plotSeries[] = $plotSer;
                                                                                    $plotAttributes = ( $chartDetail );
                                                                                    continue;
                                                                                case "radarChart" :
                                                                                    switch ( $chartDetailKey )
                                                                                    {
                                                                                            $radarStyle = ( $chartDetail->radarStyle, "val", "string" );
                                                                                            $plotSer = ( $chartDetail, $namespacesChartMeta, $chartDetailKey );
                                                                                            $plotSer->setPlotStyle( $radarStyle );
                                                                                            $plotSeries[] = $plotSer;
                                                                                            $plotAttributes = ( $chartDetail );
                                                                                            continue;
                                                                                        case "surfaceChart" :
                                                                                            switch ( $chartDetailKey )
                                                                                            {
                                                                                                case "surface3DChart" :
                                                                                                    $wireFrame = ( $chartDetail->wireframe, "val", "boolean" );
                                                                                                    $plotSer = ( $chartDetail, $namespacesChartMeta, $chartDetailKey );
                                                                                                    $plotSer->setPlotStyle( $wireFrame );
                                                                                                    $plotSeries[] = $plotSer;
                                                                                                    $plotAttributes = ( $chartDetail );
                                                                                                    continue;
                                                                                                    switch ( $chartDetailKey )
                                                                                                    {
                                                                                                        case "stockChart" :
                                                                                                            $plotSeries[] = ( $chartDetail, $namespacesChartMeta, $chartDetailKey );
                                                                                                            $plotAttributes = ( $plotAreaLayout );
                                                                                                        }
                                                                                                        if ( $plotAreaLayout == NULL )
                                                                                                        {
                                                                                                            $plotAreaLayout = new PHPExcel_Chart_Layout( );
                                                                                                        }
                                                                                                        $plotArea = new PHPExcel_Chart_PlotArea( $plotAreaLayout, $plotSeries );
                                                                                                        ( $plotAreaLayout, $plotAttributes );
                                                                                                        continue;
                                                                                                    case "plotVisOnly" :
                                                                                                        switch ( $chartDetailsKey )
                                                                                                        {
                                                                                                                $plotVisOnly = ( $chartDetails, "val", "string" );
                                                                                                                continue;
                                                                                                            case "dispBlanksAs" :
                                                                                                                switch ( $chartDetailsKey )
                                                                                                                {
                                                                                                                        $dispBlanksAs = ( $chartDetails, "val", "string" );
                                                                                                                        continue;
                                                                                                                    case "title" :
                                                                                                                        switch ( $chartDetailsKey )
                                                                                                                        {
                                                                                                                                $title = ( $chartDetails, $namespacesChartMeta, "title" );
                                                                                                                                continue;
                                                                                                                                switch ( $chartDetailsKey )
                                                                                                                                {
                                                                                                                                    case "legend" :
                                                                                                                                        $legendPos = "r";
                                                                                                                                        $legendLayout = NULL;
                                                                                                                                        $legendOverlay = FALSE;
                                                                                                                                }
                                                                                                                        }
                                                                                                                }
                                                                                                                foreach ( $chartDetails as $chartDetailKey => $chartDetail )
                                                                                                                {
                                                                                                                case "legendPos" :
                                                                                                                    switch ( $chartDetailKey )
                                                                                                                    {
                                                                                                                            $legendPos = ( $chartDetail, "val", "string" );
                                                                                                                            continue;
                                                                                                                        case "overlay" :
                                                                                                                            switch ( $chartDetailKey )
                                                                                                                            {
                                                                                                                                    $legendOverlay = ( $chartDetail, "val", "boolean" );
                                                                                                                                    continue;
                                                                                                                                    switch ( $chartDetailKey )
                                                                                                                                    {
                                                                                                                                        case "layout" :
                                                                                                                                            $legendLayout = ( $chartDetail, $namespacesChartMeta, "legend" );
                                                                                                                                        }
                                                                                                                                        $legend = new PHPExcel_Chart_Legend( $legendPos, $legendLayout, $legendOverlay );
                                                                                                                                    }
                                                                                                                                }
                                                                                                                                $chart = new PHPExcel_Chart( $chartName, $title, $legend, $plotArea, $plotVisOnly, $dispBlanksAs, $XaxisLabel, $YaxisLabel );
                                                                                                                                return $chart;
                                                                                                                            }

    private static function _chartTitle( $titleDetails, $namespacesChartMeta, $type )
    {
        $caption = array( );
        $titleLayout = NULL;
}
}
foreach ( $titleDetails as $titleDetailKey => $chartDetail )
{
case "tx" :
    switch ( $titleDetailKey )
    {
            $titleDetails = $chartDetail->rich->children( $namespacesChartMeta['a'] );
    }
    foreach ( $titleDetails as $titleKey => $titleDetail )
    {
        switch ( $titleKey )
        {
            case "p" :
                $titleDetailPart = $namespacesChartMeta['a']( $namespacesChartMeta['a'] );
                $caption[] = ( $titleDetailPart );
            }
            continue;
            switch ( $titleDetailKey )
            {
                case "layout" :
                    $titleLayout = ( $chartDetail, $namespacesChartMeta );
                }
                return new PHPExcel_Chart_Title( $caption, $titleLayout );
            }

    private static function _chartLayoutDetails( $chartDetail, $namespacesChartMeta )
    {
        if ( isset( $chartDetail->manualLayout ) )
        {
        }
        else
        {
            $details = $chartDetail->manualLayout->children( $namespacesChartMeta['c'] );
            if ( is_null( $details ) )
            {
            }
            else
            {
                $layout = array( );
                foreach ( $details as $detailKey => $detail )
                {
                    $layout[$detailKey] = ( $detail, "val", "string" );
                }
                return new PHPExcel_Chart_Layout( $layout );
            }
        }
    }

    private static function _chartDataSeries( $chartDetail, $namespacesChartMeta, $plotType )
    {
        $multiSeriesType = NULL;
        $smoothLine = FALSE;
        $seriesLabel = $seriesCategory = $seriesValues = $plotOrder = array( );
        $seriesDetailSet = $namespacesChartMeta['c']( $namespacesChartMeta['c'] );
}
}
foreach ( $seriesDetailSet as $seriesDetailKey => $seriesDetails )
{
case "grouping" :
    switch ( $seriesDetailKey )
    {
            $multiSeriesType = ( $chartDetail->grouping, "val", "string" );
            continue;
            switch ( $seriesDetailKey )
            {
                case "ser" :
                    $marker = NULL;
            }
    }
}
}
}
}
}
}
}
foreach ( $seriesDetails as $seriesKey => $seriesDetail )
{
case "idx" :
    switch ( $seriesKey )
    {
            $seriesIndex = ( $seriesDetail, "val", "integer" );
            continue;
        case "order" :
            switch ( $seriesKey )
            {
                    $seriesOrder = ( $seriesDetail, "val", "integer" );
                    $plotOrder[$seriesIndex] = $seriesOrder;
                    continue;
                case "tx" :
                    switch ( $seriesKey )
                    {
                            $seriesLabel[$seriesIndex] = ( $seriesDetail, $namespacesChartMeta );
                            continue;
                        case "marker" :
                            switch ( $seriesKey )
                            {
                                    $marker = ( $seriesDetail->symbol, "val", "string" );
                                    continue;
                                case "smooth" :
                                    switch ( $seriesKey )
                                    {
                                            $smoothLine = ( $seriesDetail, "val", "boolean" );
                                            continue;
                                        case "cat" :
                                            switch ( $seriesKey )
                                            {
                                                    $seriesCategory[$seriesIndex] = ( $seriesDetail, $namespacesChartMeta );
                                                    continue;
                                                case "val" :
                                                    switch ( $seriesKey )
                                                    {
                                                            $seriesValues[$seriesIndex] = ( $seriesDetail, $namespacesChartMeta, $marker );
                                                            continue;
                                                        case "xVal" :
                                                            switch ( $seriesKey )
                                                            {
                                                                    $seriesCategory[$seriesIndex] = ( $seriesDetail, $namespacesChartMeta, $marker );
                                                                    continue;
                                                                    switch ( $seriesKey )
                                                                    {
                                                                        case "yVal" :
                                                                            $seriesValues[$seriesIndex] = ( $seriesDetail, $namespacesChartMeta, $marker );
                                                                        }
                                                                    }
                                                                    return new PHPExcel_Chart_DataSeries( $plotType, $multiSeriesType, $plotOrder, $seriesLabel, $seriesCategory, $seriesValues, $smoothLine );
                                                                }

    private static function _chartDataSeriesValueSet( $seriesDetail, $namespacesChartMeta, $marker = NULL, $smoothLine = FALSE )
    {
        if ( isset( $seriesDetail->strRef ) )
        {
            $seriesSource = ( boolean );
            $seriesData = ( $seriesDetail->strRef->strCache->children( $namespacesChartMeta['c'] ), "s" );
            return new PHPExcel_Chart_DataSeriesValues( "String", $seriesSource, $seriesData['formatCode'], $seriesData['pointCount'], $seriesData['dataValues'], $marker, $smoothLine );
        }
        if ( isset( $seriesDetail->numRef ) )
        {
            $seriesSource = ( boolean );
            $seriesData = ( $seriesDetail->numRef->numCache->children( $namespacesChartMeta['c'] ) );
            return new PHPExcel_Chart_DataSeriesValues( "Number", $seriesSource, $seriesData['formatCode'], $seriesData['pointCount'], $seriesData['dataValues'], $marker, $smoothLine );
        }
        if ( isset( $seriesDetail->multiLvlStrRef ) )
        {
            $seriesSource = ( boolean );
            $seriesData = ( $seriesDetail->multiLvlStrRef->multiLvlStrCache->children( $namespacesChartMeta['c'] ), "s" );
            $seriesData['pointCount'] = count( $seriesData['dataValues'] );
            return new PHPExcel_Chart_DataSeriesValues( "String", $seriesSource, $seriesData['formatCode'], $seriesData['pointCount'], $seriesData['dataValues'], $marker, $smoothLine );
        }
        if ( isset( $seriesDetail->multiLvlNumRef ) )
        {
            $seriesSource = ( boolean );
            $seriesData = ( $seriesDetail->multiLvlNumRef->multiLvlNumCache->children( $namespacesChartMeta['c'] ), "s" );
            $seriesData['pointCount'] = count( $seriesData['dataValues'] );
            return new PHPExcel_Chart_DataSeriesValues( "String", $seriesSource, $seriesData['formatCode'], $seriesData['pointCount'], $seriesData['dataValues'], $marker, $smoothLine );
        }
    }

    private static function _chartDataSeriesValues( $seriesValueSet, $dataType = "n" )
    {
        $seriesVal = array( );
        $formatCode = "";
        $pointCount = 0;
}
}
}
foreach ( $seriesValueSet as $seriesValueIdx => $seriesValue )
{
case "ptCount" :
    switch ( $seriesValueIdx )
    {
            $pointCount = ( $seriesValue, "val", "integer" );
            continue;
        case "formatCode" :
            switch ( $seriesValueIdx )
            {
                    $formatCode = ( boolean );
                    continue;
                    switch ( $seriesValueIdx )
                    {
                        case "pt" :
                            $pointVal = ( $seriesValue, "idx", "integer" );
                            if ( $dataType == "s" )
                            {
                                $seriesVal[$pointVal] = ( boolean );
                            }
                            else
                            {
                                $seriesVal[$pointVal] = ( double );
                            }
                        }
                        if ( empty( $seriesVal ) )
                        {
                            $seriesVal = NULL;
                        }
                        return array( "formatCode" => $formatCode, "pointCount" => $pointCount, "dataValues" => $seriesVal );
                    }

    private static function _chartDataSeriesValuesMultiLevel( $seriesValueSet, $dataType = "n" )
    {
        $seriesVal = array( );
        $formatCode = "";
        $pointCount = 0;
        foreach ( $seriesValueSet->lvl as $seriesLevelIdx => $seriesLevel )
        {
    }
}
}
foreach ( $seriesLevel as $seriesValueIdx => $seriesValue )
{
case "ptCount" :
    switch ( $seriesValueIdx )
    {
            $pointCount = ( $seriesValue, "val", "integer" );
            continue;
        case "formatCode" :
            switch ( $seriesValueIdx )
            {
                    $formatCode = ( boolean );
                    continue;
                    switch ( $seriesValueIdx )
                    {
                        case "pt" :
                            $pointVal = ( $seriesValue, "idx", "integer" );
                            if ( $dataType == "s" )
                            {
                                $seriesVal[$pointVal][] = ( boolean );
                            }
                            else
                            {
                                $seriesVal[$pointVal][] = ( double );
                            }
                        }
                    }
                    return array( "formatCode" => $formatCode, "pointCount" => $pointCount, "dataValues" => $seriesVal );
                }

    private static function _parseRichText( $titleDetailPart = NULL )
    {
        $value = new PHPExcel_RichText( );
        foreach ( $titleDetailPart as $titleDetailElementKey => $titleDetailElement )
        {
            if ( isset( $titleDetailElement->t ) )
            {
                $objText = $value->createTextRun( ( boolean ) );
            }
            if ( isset( $titleDetailElement->rPr ) )
            {
                if ( isset( $titleDetailElement->rPr->rFont['val'] ) )
                {
                    $titleDetailElement->rPr->rFont['val']( ( boolean ) );
                }
                $fontSize = ( $titleDetailElement->rPr, "sz", "integer" );
                if ( is_null( $fontSize ) )
                {
                    $objText->getFont( )->setSize( floor( $fontSize / 100 ) );
                }
                $fontColor = ( $titleDetailElement->rPr, "color", "string" );
                if ( is_null( $fontColor ) )
                {
                    ( $fontColor )( new self( ( $fontColor ) ) );
                }
                $bold = ( $titleDetailElement->rPr, "b", "boolean" );
                if ( is_null( $bold ) )
                {
                    $objText->getFont( )->setBold( $bold );
                }
                $italic = ( $titleDetailElement->rPr, "i", "boolean" );
                if ( is_null( $italic ) )
                {
                    $objText->getFont( )->setItalic( $italic );
                }
                $baseline = ( $titleDetailElement->rPr, "baseline", "integer" );
                if ( is_null( $baseline ) )
                {
                    if ( 0 < $baseline )
                    {
                        $objText->getFont( )->setSuperScript( TRUE );
                    }
                    else if ( $baseline < 0 )
                    {
                        $objText->getFont( )->setSubScript( TRUE );
                    }
                }
                $underscore = ( $titleDetailElement->rPr, "u", "string" );
                if ( is_null( $underscore ) )
                {
                    if ( $underscore == "sng" )
                    {
                        $objText->getFont( )->setUnderline( PHPExcel_Style_Font::UNDERLINE_SINGLE );
                    }
                    else if ( $underscore == "dbl" )
                    {
                        $objText->getFont( )->setUnderline( PHPExcel_Style_Font::UNDERLINE_DOUBLE );
                    }
                    else
                    {
                        $objText->getFont( )->setUnderline( PHPExcel_Style_Font::UNDERLINE_NONE );
                    }
                }
                $strikethrough = ( $titleDetailElement->rPr, "s", "string" );
                if ( is_null( $strikethrough ) )
                {
                    continue;
                }
                else if ( $strikethrough == "noStrike" )
                {
                    $objText->getFont( )->setStrikethrough( FALSE );
                }
                else
                {
                    $objText->getFont( )->setStrikethrough( TRUE );
                }
            }
        }
        return $value;
    }

    private static function _readChartAttributes( $chartDetail )
    {
        $plotAttributes = array( );
        if ( array( ) )
        {
            if ( isset( $chartDetail->dLbls, $chartDetail->dLbls->howLegendKey ) )
            {
                $plotAttributes['showLegendKey'] = ( $chartDetail->dLbls->showLegendKey, "val", "string" );
            }
            if ( isset( $chartDetail->dLbls->showVal ) )
            {
                $plotAttributes['showVal'] = ( $chartDetail->dLbls->showVal, "val", "string" );
            }
            if ( isset( $chartDetail->dLbls->showCatName ) )
            {
                $plotAttributes['showCatName'] = ( $chartDetail->dLbls->showCatName, "val", "string" );
            }
            if ( isset( $chartDetail->dLbls->showSerName ) )
            {
                $plotAttributes['showSerName'] = ( $chartDetail->dLbls->showSerName, "val", "string" );
            }
            if ( isset( $chartDetail->dLbls->showPercent ) )
            {
                $plotAttributes['showPercent'] = ( $chartDetail->dLbls->showPercent, "val", "string" );
            }
            if ( isset( $chartDetail->dLbls->showBubbleSize ) )
            {
                $plotAttributes['showBubbleSize'] = ( $chartDetail->dLbls->showBubbleSize, "val", "string" );
            }
            if ( isset( $chartDetail->dLbls->showLeaderLines ) )
            {
                $plotAttributes['showLeaderLines'] = ( $chartDetail->dLbls->showLeaderLines, "val", "string" );
            }
        }
        return $plotAttributes;
    }

    private static function _setChartAttributes( $plotArea, $plotAttributes )
    {
}
}
}
}
}
}
}
foreach ( $plotAttributes as $plotAttributeKey => $plotAttributeValue )
{
case "showLegendKey" :
    switch ( $plotAttributeKey )
    {
            $plotArea->setShowLegendKey( $plotAttributeValue );
            continue;
        case "showVal" :
            switch ( $plotAttributeKey )
            {
                    $plotArea->setShowVal( $plotAttributeValue );
                    continue;
                case "showCatName" :
                    switch ( $plotAttributeKey )
                    {
                            $plotArea->setShowCatName( $plotAttributeValue );
                            continue;
                        case "showSerName" :
                            switch ( $plotAttributeKey )
                            {
                                    $plotArea->setShowSerName( $plotAttributeValue );
                                    continue;
                                case "showPercent" :
                                    switch ( $plotAttributeKey )
                                    {
                                            $plotArea->setShowPercent( $plotAttributeValue );
                                            continue;
                                        case "showBubbleSize" :
                                            switch ( $plotAttributeKey )
                                            {
                                                    $plotArea->setShowBubbleSize( $plotAttributeValue );
                                                    continue;
                                                    switch ( $plotAttributeKey )
                                                    {
                                                        case "showLeaderLines" :
                                                            $plotArea->setShowLeaderLines( $plotAttributeValue );
                                                        }
                                                    }

}

?>
