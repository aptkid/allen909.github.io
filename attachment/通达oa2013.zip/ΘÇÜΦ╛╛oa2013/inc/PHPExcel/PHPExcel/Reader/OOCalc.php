<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
if ( defined( "PHPEXCEL_ROOT" ) )
{
    define( "PHPEXCEL_ROOT", dirname( __FILE__ )."/../../" );
    require( PHPEXCEL_ROOT."PHPExcel/Autoloader.php" );
}
class PHPExcel_Reader_OOCalc extends PHPExcel_Reader_IReader implements PHPExcel_Reader_IReader
{

    private $_styles = array( );

    public function __construct( )
    {
        $this->_readFilter = new PHPExcel_Reader_DefaultReadFilter( );
    }

    public function canRead( $pFilename )
    {
        if ( file_exists( $pFilename ) )
        {
            throw new PHPExcel_Reader_Exception( "Could not open ".$pFilename." for reading! File does not exist." );
        }
        if ( class_exists( "ZipArchive", FALSE ) )
        {
            throw new PHPExcel_Reader_Exception( "ZipArchive library is not enabled" );
        }
        $mimeType = "UNKNOWN";
        $zip = new ZipArchive( );
        if ( $zip->open( $pFilename ) === TRUE )
        {
            $stat = $zip->statName( "mimetype" );
            if ( $stat && $stat['size'] <= 255 )
            {
                $mimeType = $stat['name']( $stat['name'] );
            }
            else if ( $stat = $zip->statName( "META-INF/manifest.xml" ) )
            {
                $xml = simplexml_load_string( $zip->getFromName( "META-INF/manifest.xml" ) );
                $namespacesContent = $xml->getNamespaces( TRUE );
                if ( isset( $namespacesContent['manifest'] ) )
                {
                    $manifest = $namespacesContent['manifest']( $namespacesContent['manifest'] );
                    foreach ( $manifest as $manifestDataSet )
                    {
                        $manifestAttributes = $namespacesContent['manifest']( $namespacesContent['manifest'] );
                        if ( $manifestAttributes->full-path == "/" )
                        {
                            $mimeType = ( boolean );
                            break;
                        }
                    }
                }
            }
            $zip->close( );
            return $mimeType === "application/vnd.oasis.opendocument.spreadsheet";
        }
        return FALSE;
    }

    public function listWorksheetNames( $pFilename )
    {
        if ( file_exists( $pFilename ) )
        {
            throw new PHPExcel_Reader_Exception( "Could not open ".$pFilename." for reading! File does not exist." );
        }
        $zip = new ZipArchive( );
        if ( $zip->open( $pFilename ) )
        {
            throw new PHPExcel_Reader_Exception( "Could not open ".$pFilename." for reading! Error opening file." );
        }
        $worksheetNames = array( );
        $xml = new XMLReader( );
        $res = realpath( $pFilename )( "zip://".realpath( $pFilename )."#content.xml" );
        $xml->setParserProperty( 2, TRUE );
        $xml->read( );
        do
        {
            if ( $xml->read( ) )
            {
                while ( $xml->name !== "office:body" )
                {
                    if ( $xml->isEmptyElement )
                    {
                        $xml->read( );
                    }
                    else
                    {
                        $xml->next( );
                    }
                }
                do
                {
                } while ( !$xml->read( ) );
            } while ( !( $xml->name == "table:table" ) || !( $xml->nodeType == XMLReader::ELEMENT ) );
        }
        $worksheetNames[] = $xml->getAttribute( "table:name" );
        $xml->next( );
        break;
        return $worksheetNames;
    }

    public function listWorksheetInfo( $pFilename )
    {
        if ( file_exists( $pFilename ) )
        {
            throw new PHPExcel_Reader_Exception( "Could not open ".$pFilename." for reading! File does not exist." );
        }
        $worksheetInfo = array( );
        $zip = new ZipArchive( );
        if ( $zip->open( $pFilename ) )
        {
            throw new PHPExcel_Reader_Exception( "Could not open ".$pFilename." for reading! Error opening file." );
        }
        $xml = new XMLReader( );
        $res = realpath( $pFilename )( "zip://".realpath( $pFilename )."#content.xml" );
        $xml->setParserProperty( 2, TRUE );
        $xml->read( );
        do
        {
            if ( $xml->read( ) )
            {
                while ( $xml->name !== "office:body" )
                {
                    if ( $xml->isEmptyElement )
                    {
                        $xml->read( );
                    }
                    else
                    {
                        $xml->next( );
                    }
                }
                do
                {
                } while ( !$xml->read( ) );
                if ( !( $xml->name == "table:table" ) || !( $xml->nodeType == XMLReader::ELEMENT ) )
                {
                    $worksheetNames[] = $xml->getAttribute( "table:name" );
                    $tmpInfo = array( "worksheetName" => $xml->getAttribute( "table:name" ), "lastColumnLetter" => "A", "lastColumnIndex" => 0, "totalRows" => 0, "totalColumns" => 0 );
                    $currCells = 0;
                    do
                    {
                        $xml->read( );
                        if ( !( $xml->name == "table:table-row" ) || !( $xml->nodeType == XMLReader::ELEMENT ) )
                        {
                            $rowspan = $xml->getAttribute( "table:number-rows-repeated" );
                            $rowspan = empty( $rowspan ) ? 1 : $rowspan;
                            $tmpInfo += "totalRows";
                            $tmpInfo['totalColumns'] = max( $tmpInfo['totalColumns'], $currCells );
                            $currCells = 0;
                            $xml->read( );
                            do
                            {
                                if ( $xml->name == "table:table-cell" && $xml->nodeType == XMLReader::ELEMENT )
                                {
                                    if ( $xml->isEmptyElement )
                                    {
                                        ++$currCells;
                                        $xml->next( );
                                    }
                                    else
                                    {
                                        $xml->read( );
                                    }
                                }
                                else if ( $xml->name == "table:covered-table-cell" && $xml->nodeType == XMLReader::ELEMENT )
                                {
                                    $mergeSize = $xml->getAttribute( "table:number-columns-repeated" );
                                    $currCells += $mergeSize;
                                    $xml->read( );
                                }
                            } while ( $xml->name != "table:table-row" );
                        }
                    } while ( $xml->name != "table:table" );
                    $tmpInfo['totalColumns'] = max( $tmpInfo['totalColumns'], $currCells );
                    $tmpInfo['lastColumnIndex'] = $tmpInfo['totalColumns'] - 1;
                    $tmpInfo['lastColumnLetter'] = ( $tmpInfo['lastColumnIndex'] );
                    $worksheetInfo[] = $tmpInfo;
                }
            } while ( 1 );
        }
        return $worksheetInfo;
    }

    public function load( $pFilename )
    {
        $objPHPExcel = new PHPExcel( );
        return $this->loadIntoExisting( $pFilename, $objPHPExcel );
    }

    private static function identifyFixedStyleValue( $styleList, &$styleAttributeValue )
    {
        $styleAttributeValue = strtolower( $styleAttributeValue );
        foreach ( $styleList as $style )
        {
            if ( $styleAttributeValue == strtolower( $style ) )
            {
                $styleAttributeValue = $style;
                return TRUE;
                break;
            }
        }
        return FALSE;
    }

    public function loadIntoExisting( $pFilename, $objPHPExcel )
    {
        if ( file_exists( $pFilename ) )
        {
            throw new PHPExcel_Reader_Exception( "Could not open ".$pFilename." for reading! File does not exist." );
        }
        $timezoneObj = new DateTimeZone( "Europe/London" );
        $GMT = new DateTimeZone( "UTC" );
        $zip = new ZipArchive( );
        if ( $zip->open( $pFilename ) )
        {
            throw new PHPExcel_Reader_Exception( "Could not open ".$pFilename." for reading! Error opening file." );
        }
        $xml = simplexml_load_string( $zip->getFromName( "meta.xml" ) );
        $namespacesMeta = $xml->getNamespaces( TRUE );
        $docProps = $objPHPExcel->getProperties( );
        $officeProperty = $namespacesMeta['office']( $namespacesMeta['office'] );
        foreach ( $officeProperty as $officePropertyData )
        {
            $officePropertyDC = array( );
            if ( isset( $namespacesMeta['dc'] ) )
            {
                $officePropertyDC = $namespacesMeta['dc']( $namespacesMeta['dc'] );
            }
    }
}
}
}
}
foreach ( $officePropertyDC as $propertyName => $propertyValue )
{
case "title" :
    switch ( $propertyName )
    {
            $docProps->setTitle( $propertyValue );
            continue;
        case "subject" :
            switch ( $propertyName )
            {
                    $docProps->setSubject( $propertyValue );
                    continue;
                case "creator" :
                    switch ( $propertyName )
                    {
                            $docProps->setCreator( $propertyValue );
                            $docProps->setLastModifiedBy( $propertyValue );
                            continue;
                        case "date" :
                            switch ( $propertyName )
                            {
                                    $creationDate = strtotime( $propertyValue );
                                    $docProps->setCreated( $creationDate );
                                    $docProps->setModified( $creationDate );
                                    continue;
                                    switch ( $propertyName )
                                    {
                                        case "description" :
                                            $docProps->setDescription( $propertyValue );
                                        }
                                        $officePropertyMeta = array( );
                                        if ( isset( $namespacesMeta['dc'] ) )
                                        {
                                            $officePropertyMeta = $namespacesMeta['meta']( $namespacesMeta['meta'] );
                                        }
                                }
                        }
                }
        }
        foreach ( $officePropertyMeta as $propertyName => $propertyValue )
        {
            $propertyValueAttributes = $namespacesMeta['meta']( $namespacesMeta['meta'] );
        case "initial-creator" :
            switch ( $propertyName )
            {
                    $docProps->setCreator( $propertyValue );
                    continue;
                case "keyword" :
                    switch ( $propertyName )
                    {
                            $docProps->setKeywords( $propertyValue );
                            continue;
                        case "creation-date" :
                            switch ( $propertyName )
                            {
                                    $creationDate = strtotime( $propertyValue );
                                    $docProps->setCreated( $creationDate );
                                    continue;
                                    switch ( $propertyName )
                                    {
                                        case "user-defined" :
                                            $propertyValueType = PHPExcel_DocumentProperties::PROPERTY_TYPE_STRING;
                                    }
                            }
                    }
                    foreach ( $propertyValueAttributes as $key => $value )
                    {
                        if ( $key == "name" )
                        {
                            $propertyValueName = ( boolean );
                        }
                        else if ( $key == "value-type" )
                        {
                        case "date" :
                            switch ( $value )
                            {
                                    $propertyValue = ( $propertyValue, "date" );
                                    $propertyValueType = PHPExcel_DocumentProperties::PROPERTY_TYPE_DATE;
                                    continue;
                                case "boolean" :
                                    switch ( $value )
                                    {
                                            $propertyValue = ( $propertyValue, "bool" );
                                            $propertyValueType = PHPExcel_DocumentProperties::PROPERTY_TYPE_BOOLEAN;
                                            continue;
                                        case "float" :
                                            switch ( $value )
                                            {
                                                    $propertyValue = ( $propertyValue, "r4" );
                                                    $propertyValueType = PHPExcel_DocumentProperties::PROPERTY_TYPE_FLOAT;
                                                    continue;
                                                    $propertyValueType = PHPExcel_DocumentProperties::PROPERTY_TYPE_STRING;
                                                }
                                            }
                                            $docProps->setCustomProperty( $propertyValueName, $propertyValue, $propertyValueType );
                                        }
                                    }
                                    $xml = simplexml_load_string( $zip->getFromName( "content.xml" ) );
                                    $namespacesContent = $xml->getNamespaces( TRUE );
                                    $workbook = $namespacesContent['office']( $namespacesContent['office'] );
                                    foreach ( $workbook->body->spreadsheet as $workbookData )
                                    {
                                        $workbookData = $namespacesContent['table']( $namespacesContent['table'] );
                                        $worksheetID = 0;
                                        foreach ( $workbookData->table as $worksheetDataSet )
                                        {
                                            $worksheetData = $namespacesContent['table']( $namespacesContent['table'] );
                                            $worksheetDataAttributes = $namespacesContent['table']( $namespacesContent['table'] );
                                            if ( isset( $this->_loadSheetsOnly ) && isset( $worksheetDataAttributes['name'] ) && !in_array( $worksheetDataAttributes['name'], $this->_loadSheetsOnly ) )
                                            {
                                            }
                                            else
                                            {
                                                $objPHPExcel->createSheet( );
                                                $objPHPExcel->setActiveSheetIndex( $worksheetID );
                                                if ( isset( $worksheetDataAttributes['name'] ) )
                                                {
                                                    $worksheetName = ( boolean );
                                                    $objPHPExcel->getActiveSheet( )->setTitle( $worksheetName, FALSE );
                                                }
                                                $rowID = 1;
                                            default :
                                                foreach ( $worksheetData as $key => $rowData )
                                                {
                                                    switch ( $key )
                                                    {
                                                        case "table-header-rows" :
                                                            foreach ( $rowData as $key => $cellData )
                                                            {
                                                                $rowData = $cellData;
                                                                break;
                                                            }
                                                            break;
                                                        case "table-row" :
                                                    }
                                                    $rowDataTableAttributes = $namespacesContent['table']( $namespacesContent['table'] );
                                                    $rowRepeats = isset( $rowDataTableAttributes['number-rows-repeated'] ) ? $rowDataTableAttributes['number-rows-repeated'] : 1;
                                                    $columnID = "A";
                                                    foreach ( $rowData as $key => $cellData )
                                                    {
                                                        if ( $this->getReadFilter( ) !== NULL && !$this->getReadFilter( )->readCell( $columnID, $rowID, $worksheetName ) )
                                                        {
                                                        }
                                                        else
                                                        {
                                                            $cellDataText = isset( $namespacesContent['text'] ) ? $namespacesContent['text']( $namespacesContent['text'] ) : "";
                                                            $cellDataOffice = $namespacesContent['office']( $namespacesContent['office'] );
                                                            $cellDataOfficeAttributes = $namespacesContent['office']( $namespacesContent['office'] );
                                                            $cellDataTableAttributes = $namespacesContent['table']( $namespacesContent['table'] );
                                                            $type = $formatting = $hyperlink = NULL;
                                                            $hasCalculatedValue = FALSE;
                                                            $cellDataFormula = "";
                                                            if ( isset( $cellDataTableAttributes['formula'] ) )
                                                            {
                                                                $cellDataFormula = $cellDataTableAttributes['formula'];
                                                                $hasCalculatedValue = TRUE;
                                                            }
                                                            if ( isset( $cellDataOffice->annotation ) )
                                                            {
                                                                $annotationText = $cellDataOffice->annotation->children( $namespacesContent['text'] );
                                                                $textArray = array( );
                                                                foreach ( $annotationText as $t )
                                                                {
                                                                    foreach ( $t->span as $text )
                                                                    {
                                                                        $textArray[] = ( boolean );
                                                                    }
                                                                }
                                                                $text = implode( "\n", $textArray );
                                                                $objPHPExcel->getActiveSheet( )->getComment( $columnID.$rowID )->setText( $this->_parseRichText( $text ) );
                                                            }
                                                            if ( isset( $cellDataText->p ) )
                                                            {
                                                                $dataArray = array( );
                                                                foreach ( $cellDataText->p as $pData )
                                                                {
                                                                    if ( isset( $pData->span ) )
                                                                    {
                                                                        $spanSection = "";
                                                                        foreach ( $pData->span as $spanData )
                                                                        {
                                                                            $spanSection .= $spanData;
                                                                        }
                                                                        array_push( &$dataArray, $spanSection );
                                                                    }
                                                                    else
                                                                    {
                                                                        array_push( &$dataArray, $pData );
                                                                    }
                                                                }
                                                                $allCellDataText = implode( $dataArray, "\n" );
                                                                switch ( $cellDataOfficeAttributes['value-type'] )
                                                                {
                                                                    case "string" :
                                                                        $type = PHPExcel_Cell_DataType::TYPE_STRING;
                                                                        $dataValue = $allCellDataText;
                                                                        if ( isset( $dataValue->a ) )
                                                                        {
                                                                            $dataValue = $dataValue->a;
                                                                            $cellXLinkAttributes = $namespacesContent['xlink']( $namespacesContent['xlink'] );
                                                                            $hyperlink = $cellXLinkAttributes['href'];
                                                                            break;
                                                                        }
                                                                    case "boolean" :
                                                                        $type = PHPExcel_Cell_DataType::TYPE_BOOL;
                                                                        $dataValue = $allCellDataText == "TRUE" ? TRUE : FALSE;
                                                                        break;
                                                                    case "percentage" :
                                                                        $type = PHPExcel_Cell_DataType::TYPE_NUMERIC;
                                                                        $dataValue = ( double );
                                                                        if ( floor( $dataValue ) == $dataValue )
                                                                        {
                                                                            $dataValue = ( integer );
                                                                        }
                                                                        $formatting = PHPExcel_Style_NumberFormat::FORMAT_PERCENTAGE_00;
                                                                        break;
                                                                    case "currency" :
                                                                        $type = PHPExcel_Cell_DataType::TYPE_NUMERIC;
                                                                        $dataValue = ( double );
                                                                        if ( floor( $dataValue ) == $dataValue )
                                                                        {
                                                                            $dataValue = ( integer );
                                                                        }
                                                                        $formatting = PHPExcel_Style_NumberFormat::FORMAT_CURRENCY_USD_SIMPLE;
                                                                        break;
                                                                    case "float" :
                                                                        $type = PHPExcel_Cell_DataType::TYPE_NUMERIC;
                                                                        $dataValue = ( double );
                                                                        if ( floor( $dataValue ) == $dataValue )
                                                                        {
                                                                            if ( $dataValue = ( integer ) )
                                                                            {
                                                                                $dataValue = ( integer );
                                                                                break;
                                                                            }
                                                                            else
                                                                            {
                                                                                $dataValue = ( double );
                                                                                break;
                                                                            }
                                                                        }
                                                                    case "date" :
                                                                        $type = PHPExcel_Cell_DataType::TYPE_NUMERIC;
                                                                        $dateObj = new DateTime( $cellDataOfficeAttributes['date-value'], $GMT );
                                                                        $dateObj->setTimeZone( $timezoneObj );
                                                                        $second = explode( " ", $dateObj->format( "Y m d H i s" ) )[5];
                                                                        $minute = explode( " ", $dateObj->format( "Y m d H i s" ) )[4];
                                                                        $hour = explode( " ", $dateObj->format( "Y m d H i s" ) )[3];
                                                                        $day = explode( " ", $dateObj->format( "Y m d H i s" ) )[2];
                                                                        $month = explode( " ", $dateObj->format( "Y m d H i s" ) )[1];
                                                                        $year = explode( " ", $dateObj->format( "Y m d H i s" ) )[0];
                                                                        $dataValue = ( $year, $month, $day, $hour, $minute, $second );
                                                                        if ( $dataValue != floor( $dataValue ) )
                                                                        {
                                                                            $formatting = PHPExcel_Style_NumberFormat::FORMAT_DATE_XLSX15." ".PHPExcel_Style_NumberFormat::FORMAT_DATE_TIME4;
                                                                            break;
                                                                        }
                                                                        else
                                                                        {
                                                                            $formatting = PHPExcel_Style_NumberFormat::FORMAT_DATE_XLSX15;
                                                                            break;
                                                                        }
                                                                    case "time" :
                                                                        $type = PHPExcel_Cell_DataType::TYPE_NUMERIC;
                                                                        $dataValue = ( strtotime( "01-01-1970 ".implode( ":", sscanf( $cellDataOfficeAttributes['time-value'], "PT%dH%dM%dS" ) ) ) );
                                                                        $formatting = PHPExcel_Style_NumberFormat::FORMAT_DATE_TIME4;
                                                                }
                                                            }
                                                            else
                                                            {
                                                                $type = PHPExcel_Cell_DataType::TYPE_NULL;
                                                                $dataValue = NULL;
                                                            }
                                                            if ( $hasCalculatedValue )
                                                            {
                                                                $type = PHPExcel_Cell_DataType::TYPE_FORMULA;
                                                                $cellDataFormula = substr( $cellDataFormula, strpos( $cellDataFormula, ":=" ) + 1 );
                                                                $temp = explode( "\"", $cellDataFormula );
                                                                $tKey = FALSE;
                                                                foreach ( $temp as $tKey )
                                                                {
                                                                    if ( strpos( $cellDataFormula, ":=" ) )
                                                                    {
                                                                        $value = preg_replace( "/\\[\\.(.*):\\.(.*)\\]/Ui", "$1:$2", $value );
                                                                        $value = preg_replace( "/\\[\\.(.*)\\]/Ui", "$1", $value );
                                                                        $value = ( ";", ",", $value, $inBraces );
                                                                    }
                                                                }
                                                                unset( $value );
                                                                $cellDataFormula = implode( "\"", $temp );
                                                            }
                                                            $colRepeats = isset( $cellDataTableAttributes['number-columns-repeated'] ) ? $cellDataTableAttributes['number-columns-repeated'] : 1;
                                                            if ( $type !== NULL )
                                                            {
                                                                $i = 0;
                                                                for ( ; $i < $colRepeats; ++$i )
                                                                {
                                                                    if ( 0 < $i )
                                                                    {
                                                                        ++$columnID;
                                                                    }
                                                                    if ( $type !== PHPExcel_Cell_DataType::TYPE_NULL )
                                                                    {
                                                                        $rowAdjust = 0;
                                                                        for ( ; $rowAdjust < $rowRepeats; ++$rowAdjust )
                                                                        {
                                                                            $rID = $rowID + $rowAdjust;
                                                                            $objPHPExcel->getActiveSheet( )->getCell( $columnID.$rID )->setValueExplicit( $hasCalculatedValue ? $cellDataFormula : $dataValue, $type );
                                                                            if ( $hasCalculatedValue )
                                                                            {
                                                                                $objPHPExcel->getActiveSheet( )->getCell( $columnID.$rID )->setCalculatedValue( $dataValue );
                                                                            }
                                                                            if ( $formatting !== NULL )
                                                                            {
                                                                                $objPHPExcel->getActiveSheet( )->getStyle( $columnID.$rID )->getNumberFormat( )->setFormatCode( $formatting );
                                                                            }
                                                                            else
                                                                            {
                                                                                $objPHPExcel->getActiveSheet( )->getStyle( $columnID.$rID )->getNumberFormat( )->setFormatCode( PHPExcel_Style_NumberFormat::FORMAT_GENERAL );
                                                                            }
                                                                            if ( $hyperlink !== NULL )
                                                                            {
                                                                                $objPHPExcel->getActiveSheet( )->getCell( $columnID.$rID )->getHyperlink( )->setUrl( $hyperlink );
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                            if ( ( isset( $cellDataTableAttributes['number-columns-spanned'] ) || isset( $cellDataTableAttributes['number-rows-spanned'] ) ) && ( $type !== PHPExcel_Cell_DataType::TYPE_NULL || !$this->_readDataOnly ) )
                                                            {
                                                                $columnTo = $columnID;
                                                                if ( isset( $cellDataTableAttributes['number-columns-spanned'] ) )
                                                                {
                                                                    $columnTo = ( ( $columnID ) + $cellDataTableAttributes['number-columns-spanned'] - 2 );
                                                                }
                                                                $rowTo = $rowID;
                                                                if ( isset( $cellDataTableAttributes['number-rows-spanned'] ) )
                                                                {
                                                                    $rowTo = $rowTo + $cellDataTableAttributes['number-rows-spanned'] - 1;
                                                                }
                                                                $cellRange = $columnID.$rowID.":".$columnTo.$rowTo;
                                                                $objPHPExcel->getActiveSheet( )->mergeCells( $cellRange );
                                                            }
                                                            ++$columnID;
                                                        }
                                                    }
                                                    $rowID += $rowRepeats;
                                                }
                                                ++$worksheetID;
                                            }
                                        }
                                    }
                                    return $objPHPExcel;
                                }

    private function _parseRichText( $is = "" )
    {
        $value = new PHPExcel_RichText( );
        $value->createText( $is );
        return $value;
    }

}

?>
