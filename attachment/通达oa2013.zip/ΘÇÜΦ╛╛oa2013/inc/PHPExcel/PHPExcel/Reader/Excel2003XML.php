<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
if ( defined( "PHPEXCEL_ROOT" ) )
{
    define( "PHPEXCEL_ROOT", dirname( __FILE__ )."/../../" );
    require( PHPEXCEL_ROOT."PHPExcel/Autoloader.php" );
}
class PHPExcel_Reader_Excel2003XML extends PHPExcel_Reader_IReader implements PHPExcel_Reader_IReader
{

    private $_styles = array( );
    private $_charSet = "UTF-8";

    public function __construct( )
    {
        $this->_readFilter = new PHPExcel_Reader_DefaultReadFilter( );
    }

    public function canRead( $pFilename )
    {
        $signature = array( "<?xml version=\"1.0\"", "<?mso-application progid=\"Excel.Sheet\"?>" );
        $this->_openFile( $pFilename );
        $fileHandle = $this->_fileHandle;
        $data = fread( $fileHandle, 2048 );
        fclose( $fileHandle );
        $valid = TRUE;
        foreach ( $signature as $match )
        {
            if ( strpos( $data, $match ) === FALSE )
            {
                $valid = FALSE;
                break;
            }
        }
        if ( preg_match( "/<?xml.*encoding=['\"](.*?)['\"].*?>/um", $data, $matches ) )
        {
            $this->_charSet = strtoupper( $matches[1] );
        }
        return $valid;
    }

    public function listWorksheetNames( $pFilename )
    {
        if ( file_exists( $pFilename ) )
        {
            throw new PHPExcel_Reader_Exception( "Could not open ".$pFilename." for reading! File does not exist." );
        }
        if ( $this->canRead( $pFilename ) )
        {
            throw new PHPExcel_Reader_Exception( $pFilename." is an Invalid Spreadsheet file." );
        }
        $worksheetNames = array( );
        $xml = simplexml_load_file( $pFilename );
        $namespaces = $xml->getNamespaces( TRUE );
        $xml_ss = $namespaces['ss']( $namespaces['ss'] );
        foreach ( $xml_ss->Worksheet as $worksheet )
        {
            $worksheet_ss = $namespaces['ss']( $namespaces['ss'] );
            $worksheetNames[] = ( ( boolean ), $this->_charSet );
        }
        return $worksheetNames;
    }

    public function listWorksheetInfo( $pFilename )
    {
        if ( file_exists( $pFilename ) )
        {
            throw new PHPExcel_Reader_Exception( "Could not open ".$pFilename." for reading! File does not exist." );
        }
        $worksheetInfo = array( );
        $xml = simplexml_load_file( $pFilename );
        $namespaces = $xml->getNamespaces( TRUE );
        $worksheetID = 1;
        $xml_ss = $namespaces['ss']( $namespaces['ss'] );
        foreach ( $xml_ss->Worksheet as $worksheet )
        {
            $worksheet_ss = $namespaces['ss']( $namespaces['ss'] );
            $tmpInfo = array( );
            $tmpInfo['worksheetName'] = "";
            $tmpInfo['lastColumnLetter'] = "A";
            $tmpInfo['lastColumnIndex'] = 0;
            $tmpInfo['totalRows'] = 0;
            $tmpInfo['totalColumns'] = 0;
            if ( isset( $worksheet_ss['Name'] ) )
            {
                $tmpInfo['worksheetName'] = ( boolean );
            }
            else
            {
                $tmpInfo['worksheetName'] = "Worksheet_".$worksheetID;
            }
            if ( isset( $worksheet->Table->Row ) )
            {
                $rowIndex = 0;
                foreach ( $worksheet->Table->Row as $columnIndex => $rowData )
                {
                    $rowHasData = FALSE;
                    foreach ( $rowData->Cell as $cell )
                    {
                        if ( isset( $cell->Data ) )
                        {
                            $tmpInfo['lastColumnIndex'] = max( $tmpInfo['lastColumnIndex'], $columnIndex );
                            $rowHasData = TRUE;
                        }
                        ++$columnIndex;
                    }
                    ++$rowIndex;
                    if ( $rowHasData )
                    {
                        $tmpInfo['totalRows'] = max( $tmpInfo['totalRows'], $rowIndex );
                    }
                }
            }
            $tmpInfo['lastColumnLetter'] = ( $tmpInfo['lastColumnIndex'] );
            $tmpInfo['totalColumns'] = $tmpInfo['lastColumnIndex'] + 1;
            $worksheetInfo[] = $tmpInfo;
            ++$worksheetID;
        }
        return $worksheetInfo;
    }

    public function load( $pFilename )
    {
        $objPHPExcel = new PHPExcel( );
        return $this->loadIntoExisting( $pFilename, $objPHPExcel );
    }

    private static function identifyFixedStyleValue( $styleList, &$styleAttributeValue )
    {
        $styleAttributeValue = strtolower( $styleAttributeValue );
        foreach ( $styleList as $style )
        {
            if ( $styleAttributeValue == strtolower( $style ) )
            {
                $styleAttributeValue = $style;
                return TRUE;
                break;
            }
        }
        return FALSE;
    }

    private static function _pixel2WidthUnits( $pxs )
    {
        $UNIT_OFFSET_MAP = array( 0, 36, 73, 109, 146, 182, 219 );
        $widthUnits = 256 * ( $pxs / 7 );
        $widthUnits += $UNIT_OFFSET_MAP[$pxs % 7];
        return $widthUnits;
    }

    private static function _widthUnits2Pixel( $widthUnits )
    {
        $pixels = $widthUnits / 256 * 7;
        $offsetWidthUnits = $widthUnits % 256;
        $pixels += round( $offsetWidthUnits / 36.5714 );
        return $pixels;
    }

    private static function _hex2str( $hex )
    {
        return chr( hexdec( $hex[1] ) );
    }

    public function loadIntoExisting( $pFilename, $objPHPExcel )
    {
        $fromFormats = array( "\\-", "\\ " );
        $toFormats = array( "-", " " );
        $underlineStyles = array( PHPExcel_Style_Font::UNDERLINE_NONE, PHPExcel_Style_Font::UNDERLINE_DOUBLE, PHPExcel_Style_Font::UNDERLINE_DOUBLEACCOUNTING, PHPExcel_Style_Font::UNDERLINE_SINGLE, PHPExcel_Style_Font::UNDERLINE_SINGLEACCOUNTING );
        $verticalAlignmentStyles = array( PHPExcel_Style_Alignment::VERTICAL_BOTTOM, PHPExcel_Style_Alignment::VERTICAL_TOP, PHPExcel_Style_Alignment::VERTICAL_CENTER, PHPExcel_Style_Alignment::VERTICAL_JUSTIFY );
        $horizontalAlignmentStyles = array( PHPExcel_Style_Alignment::HORIZONTAL_GENERAL, PHPExcel_Style_Alignment::HORIZONTAL_LEFT, PHPExcel_Style_Alignment::HORIZONTAL_RIGHT, PHPExcel_Style_Alignment::HORIZONTAL_CENTER, PHPExcel_Style_Alignment::HORIZONTAL_CENTER_CONTINUOUS, PHPExcel_Style_Alignment::HORIZONTAL_JUSTIFY );
        $timezoneObj = new DateTimeZone( "Europe/London" );
        $GMT = new DateTimeZone( "UTC" );
        if ( file_exists( $pFilename ) )
        {
            throw new PHPExcel_Reader_Exception( "Could not open ".$pFilename." for reading! File does not exist." );
        }
        if ( $this->canRead( $pFilename ) )
        {
            throw new PHPExcel_Reader_Exception( $pFilename." is an Invalid Spreadsheet file." );
        }
        $xml = simplexml_load_file( $pFilename );
        $namespaces = $xml->getNamespaces( TRUE );
        $docProps = $objPHPExcel->getProperties( );
        if ( isset( $xml->DocumentProperties[0] ) )
        {
    }
}
}
}
}
}
}
}
}
}
}
foreach ( $xml->DocumentProperties[0] as $propertyName => $propertyValue )
{
case "Title" :
    switch ( $propertyName )
    {
            ( $propertyValue, $this->_charSet )( ( $propertyValue, $this->_charSet ) );
            continue;
        case "Subject" :
            switch ( $propertyName )
            {
                    ( $propertyValue, $this->_charSet )( ( $propertyValue, $this->_charSet ) );
                    continue;
                case "Author" :
                    switch ( $propertyName )
                    {
                            ( $propertyValue, $this->_charSet )( ( $propertyValue, $this->_charSet ) );
                            continue;
                        case "Created" :
                            switch ( $propertyName )
                            {
                                    $creationDate = strtotime( $propertyValue );
                                    $docProps->setCreated( $creationDate );
                                    continue;
                                case "LastAuthor" :
                                    switch ( $propertyName )
                                    {
                                            ( $propertyValue, $this->_charSet )( ( $propertyValue, $this->_charSet ) );
                                            continue;
                                        case "LastSaved" :
                                            switch ( $propertyName )
                                            {
                                                    $lastSaveDate = strtotime( $propertyValue );
                                                    $docProps->setModified( $lastSaveDate );
                                                    continue;
                                                case "Company" :
                                                    switch ( $propertyName )
                                                    {
                                                            ( $propertyValue, $this->_charSet )( ( $propertyValue, $this->_charSet ) );
                                                            continue;
                                                        case "Category" :
                                                            switch ( $propertyName )
                                                            {
                                                                    ( $propertyValue, $this->_charSet )( ( $propertyValue, $this->_charSet ) );
                                                                    continue;
                                                                case "Manager" :
                                                                    switch ( $propertyName )
                                                                    {
                                                                            ( $propertyValue, $this->_charSet )( ( $propertyValue, $this->_charSet ) );
                                                                            continue;
                                                                        case "Keywords" :
                                                                            switch ( $propertyName )
                                                                            {
                                                                                    ( $propertyValue, $this->_charSet )( ( $propertyValue, $this->_charSet ) );
                                                                                    continue;
                                                                                    switch ( $propertyName )
                                                                                    {
                                                                                        case "Description" :
                                                                                            ( $propertyValue, $this->_charSet )( ( $propertyValue, $this->_charSet ) );
                                                                                        }
                                                                                    }
                                                                                    if ( isset( $xml->CustomDocumentProperties ) )
                                                                                    {
                                                                                        foreach ( $xml->CustomDocumentProperties[0] as $propertyName => $propertyValue )
                                                                                        {
                                                                                            $propertyAttributes = $namespaces['dt']( $namespaces['dt'] );
                                                                                            $propertyName = preg_replace_callback( "/_x([0-9a-z]{4})_/", "PHPExcel_Reader_Excel2003XML::_hex2str", $propertyName );
                                                                                            $propertyType = PHPExcel_DocumentProperties::PROPERTY_TYPE_UNKNOWN;
                                                                                            switch ( ( boolean ) )
                                                                                            {
                                                                                                case "string" :
                                                                                                    $propertyType = PHPExcel_DocumentProperties::PROPERTY_TYPE_STRING;
                                                                                                    $propertyValue = trim( $propertyValue );
                                                                                                    break;
                                                                                                case "boolean" :
                                                                                                    $propertyType = PHPExcel_DocumentProperties::PROPERTY_TYPE_BOOLEAN;
                                                                                                    $propertyValue = $propertyValue;
                                                                                                    break;
                                                                                                case "integer" :
                                                                                                    $propertyType = PHPExcel_DocumentProperties::PROPERTY_TYPE_INTEGER;
                                                                                                    $propertyValue = intval( $propertyValue );
                                                                                                    break;
                                                                                                case "float" :
                                                                                                    $propertyType = PHPExcel_DocumentProperties::PROPERTY_TYPE_FLOAT;
                                                                                                    $propertyValue = floatval( $propertyValue );
                                                                                                    break;
                                                                                                case "dateTime.tz" :
                                                                                                    $propertyType = PHPExcel_DocumentProperties::PROPERTY_TYPE_DATE;
                                                                                                    $propertyValue = strtotime( trim( $propertyValue ) );
                                                                                            }
                                                                                            $docProps->setCustomProperty( $propertyName, $propertyValue, $propertyType );
                                                                                        }
                                                                                    }
                                                                                    foreach ( $xml->Styles[0] as $style )
                                                                                    {
                                                                                        $style_ss = $namespaces['ss']( $namespaces['ss'] );
                                                                                        $styleID = ( boolean );
                                                                                        if ( $styleID == "Default" )
                                                                                        {
                                                                                            $this->_styles['Default'] = array( );
                                                                                        }
                                                                                        else
                                                                                        {
                                                                                            $this->_styles[$styleID] = $this->_styles['Default'];
                                                                                        }
                                                                                }
                                                                        }
                                                                }
                                                        }
                                                }
                                        }
                                        foreach ( $style as $styleType => $styleData )
                                        {
                                            $styleAttributes = $namespaces['ss']( $namespaces['ss'] );
                                        case "Alignment" :
                                            switch ( $styleType )
                                            {
                                            }
                                    }
                            }
                            foreach ( $styleAttributes as $styleAttributeKey => $styleAttributeValue )
                            {
                                $styleAttributeValue = ( boolean );
                            case "Vertical" :
                                switch ( $styleAttributeKey )
                                {
                                        if ( ( $verticalAlignmentStyles, $styleAttributeValue ) )
                                        {
                                            $this->_styles[$styleID]['alignment']['vertical'] = $styleAttributeValue;
                                            continue;
                                        }
                                    case "Horizontal" :
                                        switch ( $styleAttributeKey )
                                        {
                                                if ( ( $horizontalAlignmentStyles, $styleAttributeValue ) )
                                                {
                                                    $this->_styles[$styleID]['alignment']['horizontal'] = $styleAttributeValue;
                                                    continue;
                                                }
                                                switch ( $styleAttributeKey )
                                                {
                                                    case "WrapText" :
                                                        $this->_styles[$styleID]['alignment']['wrap'] = TRUE;
                                                    }
                                                    continue;
                                                case "Borders" :
                                                    switch ( $styleType )
                                                    {
                                                            foreach ( $styleData->Border as $borderStyle )
                                                            {
                                                                $borderAttributes = $namespaces['ss']( $namespaces['ss'] );
                                                                $thisBorder = array( );
                                                        }
                                                }
                                        }
                                        foreach ( $borderAttributes as $borderStyleKey => $borderStyleValue )
                                        {
                                        case "LineStyle" :
                                            switch ( $borderStyleKey )
                                            {
                                                    $thisBorder['style'] = PHPExcel_Style_Border::BORDER_MEDIUM;
                                                    continue;
                                                    switch ( $borderStyleKey )
                                                    {
                                                        case "Weight" :
                                                        case "Position" :
                                                            $borderPosition = strtolower( $borderStyleValue );
                                                            continue;
                                                            switch ( $borderStyleKey )
                                                            {
                                                                case "Color" :
                                                                    $borderColour = substr( $borderStyleValue, 1 );
                                                                    $thisBorder['color']['rgb'] = $borderColour;
                                                                }
                                                                if ( empty( $thisBorder ) || !( $borderPosition == "left" ) && !( $borderPosition == "right" ) && !( $borderPosition == "top" ) && !( $borderPosition == "bottom" ) )
                                                                {
                                                                    $this->_styles[$styleID]['borders'][$borderPosition] = $thisBorder;
                                                                }
                                                            }
                                                            continue;
                                                        case "Font" :
                                                            switch ( $styleType )
                                                            {
                                                            }
                                                    }
                                            }
                                    }
                            }
                    }
                    foreach ( $styleAttributes as $styleAttributeKey => $styleAttributeValue )
                    {
                        $styleAttributeValue = ( boolean );
                    case "FontName" :
                        switch ( $styleAttributeKey )
                        {
                                $this->_styles[$styleID]['font']['name'] = $styleAttributeValue;
                                continue;
                            case "Size" :
                                switch ( $styleAttributeKey )
                                {
                                        $this->_styles[$styleID]['font']['size'] = $styleAttributeValue;
                                        continue;
                                    case "Color" :
                                        switch ( $styleAttributeKey )
                                        {
                                                $this->_styles[$styleID]['font']['color']['rgb'] = substr( $styleAttributeValue, 1 );
                                                continue;
                                            case "Bold" :
                                                switch ( $styleAttributeKey )
                                                {
                                                        $this->_styles[$styleID]['font']['bold'] = TRUE;
                                                        continue;
                                                    case "Italic" :
                                                        switch ( $styleAttributeKey )
                                                        {
                                                                $this->_styles[$styleID]['font']['italic'] = TRUE;
                                                                continue;
                                                                switch ( $styleAttributeKey )
                                                                {
                                                                    case "Underline" :
                                                                        if ( ( $underlineStyles, $styleAttributeValue ) )
                                                                        {
                                                                            $this->_styles[$styleID]['font']['underline'] = $styleAttributeValue;
                                                                        }
                                                                    }
                                                                    continue;
                                                                case "Interior" :
                                                                    switch ( $styleType )
                                                                    {
                                                                    }
                                                                    foreach ( $styleAttributes as $styleAttributeKey => $styleAttributeValue )
                                                                    {
                                                                        switch ( $styleAttributeKey )
                                                                        {
                                                                            case "Color" :
                                                                                $this->_styles[$styleID]['fill']['color']['rgb'] = substr( $styleAttributeValue, 1 );
                                                                            }
                                                                            continue;
                                                                        case "NumberFormat" :
                                                                            switch ( $styleType )
                                                                            {
                                                                                    foreach ( $styleAttributes as $styleAttributeKey => $styleAttributeValue )
                                                                                    {
                                                                                        $styleAttributeValue = str_replace( $fromFormats, $toFormats, $styleAttributeValue );
                                                                                        switch ( $styleAttributeValue )
                                                                                        {
                                                                                            case "Short Date" :
                                                                                                $styleAttributeValue = "dd/mm/yyyy";
                                                                                        }
                                                                                        if ( "" < $styleAttributeValue )
                                                                                        {
                                                                                            $this->_styles[$styleID]['numberformat']['code'] = $styleAttributeValue;
                                                                                        }
                                                                                    }
                                                                                    continue;
                                                                                    switch ( $styleType )
                                                                                    {
                                                                                        case "Protection" :
                                                                                            foreach ( $styleAttributes as $styleAttributeKey => $styleAttributeValue )
                                                                                            {
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                    $worksheetID = 0;
                                                                                    $xml_ss = $namespaces['ss']( $namespaces['ss'] );
                                                                                    foreach ( $xml_ss->Worksheet as $worksheet )
                                                                                    {
                                                                                        $worksheet_ss = $namespaces['ss']( $namespaces['ss'] );
                                                                                        if ( isset( $this->_loadSheetsOnly ) && isset( $worksheet_ss['Name'] ) && !in_array( $worksheet_ss['Name'], $this->_loadSheetsOnly ) )
                                                                                        {
                                                                                        }
                                                                                        else
                                                                                        {
                                                                                            $objPHPExcel->createSheet( );
                                                                                            $objPHPExcel->setActiveSheetIndex( $worksheetID );
                                                                                            if ( isset( $worksheet_ss['Name'] ) )
                                                                                            {
                                                                                                $worksheetName = ( ( boolean ), $this->_charSet );
                                                                                                $objPHPExcel->getActiveSheet( )->setTitle( $worksheetName, FALSE );
                                                                                            }
                                                                                            $columnID = "A";
                                                                                            if ( isset( $worksheet->Table->Column ) )
                                                                                            {
                                                                                                foreach ( $worksheet->Table->Column as $columnData )
                                                                                                {
                                                                                                    $columnData_ss = $namespaces['ss']( $namespaces['ss'] );
                                                                                                    if ( isset( $columnData_ss['Index'] ) )
                                                                                                    {
                                                                                                        $columnID = ( $columnData_ss['Index'] - 1 );
                                                                                                    }
                                                                                                    if ( isset( $columnData_ss['Width'] ) )
                                                                                                    {
                                                                                                        $columnWidth = $columnData_ss['Width'];
                                                                                                        $objPHPExcel->getActiveSheet( )->getColumnDimension( $columnID )->setWidth( $columnWidth / 5.4 );
                                                                                                    }
                                                                                                    ++$columnID;
                                                                                                }
                                                                                            }
                                                                                            $rowID = 1;
                                                                                            if ( isset( $worksheet->Table->Row ) )
                                                                                            {
                                                                                                foreach ( $worksheet->Table->Row as $rowHasData => $rowData )
                                                                                                {
                                                                                                    $row_ss = $namespaces['ss']( $namespaces['ss'] );
                                                                                                    if ( isset( $row_ss['Index'] ) )
                                                                                                    {
                                                                                                        $rowID = ( integer );
                                                                                                    }
                                                                                                    $columnID = "A";
                                                                                                    foreach ( $rowData->Cell as $cell )
                                                                                                    {
                                                                                                        $cell_ss = $namespaces['ss']( $namespaces['ss'] );
                                                                                                        if ( isset( $cell_ss['Index'] ) )
                                                                                                        {
                                                                                                            $columnID = ( $cell_ss['Index'] - 1 );
                                                                                                        }
                                                                                                        $cellRange = $columnID.$rowID;
                                                                                                        if ( $this->getReadFilter( ) !== NULL && !$this->getReadFilter( )->readCell( $columnID, $rowID, $worksheetName ) )
                                                                                                        {
                                                                                                        }
                                                                                                        else
                                                                                                        {
                                                                                                            if ( isset( $cell_ss['MergeAcross'] ) || isset( $cell_ss['MergeDown'] ) )
                                                                                                            {
                                                                                                                $columnTo = $columnID;
                                                                                                                if ( isset( $cell_ss['MergeAcross'] ) )
                                                                                                                {
                                                                                                                    $columnTo = ( ( $columnID ) + $cell_ss['MergeAcross'] - 1 );
                                                                                                                }
                                                                                                                $rowTo = $rowID;
                                                                                                                if ( isset( $cell_ss['MergeDown'] ) )
                                                                                                                {
                                                                                                                    $rowTo += $cell_ss['MergeDown'];
                                                                                                                }
                                                                                                                $cellRange .= ":".$columnTo.$rowTo;
                                                                                                                $objPHPExcel->getActiveSheet( )->mergeCells( $cellRange );
                                                                                                            }
                                                                                                            $cellIsSet = $hasCalculatedValue = FALSE;
                                                                                                            $cellDataFormula = "";
                                                                                                            if ( isset( $cell_ss['Formula'] ) )
                                                                                                            {
                                                                                                                $cellDataFormula = $cell_ss['Formula'];
                                                                                                                if ( isset( $cell_ss['ArrayRange'] ) )
                                                                                                                {
                                                                                                                    $cellDataCSEFormula = $cell_ss['ArrayRange'];
                                                                                                                }
                                                                                                                $hasCalculatedValue = TRUE;
                                                                                                            }
                                                                                                            if ( isset( $cell->Data ) )
                                                                                                            {
                                                                                                                $cellValue = $cellData = $cell->Data;
                                                                                                                $type = PHPExcel_Cell_DataType::TYPE_NULL;
                                                                                                                $cellData_ss = $namespaces['ss']( $namespaces['ss'] );
                                                                                                                if ( isset( $cellData_ss['Type'] ) )
                                                                                                                {
                                                                                                                    $cellDataType = $cellData_ss['Type'];
                                                                                                                    switch ( $cellDataType )
                                                                                                                    {
                                                                                                                        case "String" :
                                                                                                                            $cellValue = ( $cellValue, $this->_charSet );
                                                                                                                            $type = PHPExcel_Cell_DataType::TYPE_STRING;
                                                                                                                        case "Number" :
                                                                                                                            $type = PHPExcel_Cell_DataType::TYPE_NUMERIC;
                                                                                                                            $cellValue = ( double );
                                                                                                                            if ( floor( $cellValue ) == $cellValue )
                                                                                                                            {
                                                                                                                                $cellValue = ( integer );
                                                                                                                            }
                                                                                                                        case "Boolean" :
                                                                                                                            $type = PHPExcel_Cell_DataType::TYPE_BOOL;
                                                                                                                            $cellValue = $cellValue != 0;
                                                                                                                        case "DateTime" :
                                                                                                                            $type = PHPExcel_Cell_DataType::TYPE_NUMERIC;
                                                                                                                            $cellValue = ( strtotime( $cellValue ) );
                                                                                                                        case "Error" :
                                                                                                                            $type = PHPExcel_Cell_DataType::TYPE_ERROR;
                                                                                                                            if ( $hasCalculatedValue )
                                                                                                                            {
                                                                                                                            }
                                                                                                                            else
                                                                                                                            {
                                                                                                                            }
                                                                                                                    }
                                                                                                                    $type = PHPExcel_Cell_DataType::TYPE_FORMULA;
                                                                                                                    $columnNumber = ( $columnID );
                                                                                                                    if ( substr( $cellDataFormula, 0, 3 ) == "of:" )
                                                                                                                    {
                                                                                                                        $cellDataFormula = substr( $cellDataFormula, 3 );
                                                                                                                        $temp = explode( "\"", $cellDataFormula );
                                                                                                                        $key = FALSE;
                                                                                                                        foreach ( $temp as $key )
                                                                                                                        {
                                                                                                                            if ( substr( $cellDataFormula, 0, 3 ) )
                                                                                                                            {
                                                                                                                                $value = str_replace( array( "[.", ".", "]" ), "", $value );
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }
                                                                                                                    else
                                                                                                                    {
                                                                                                                        $temp = explode( "\"", $cellDataFormula );
                                                                                                                        $key = FALSE;
                                                                                                                        foreach ( $temp as $key )
                                                                                                                        {
                                                                                                                            if ( str_replace( array( "[.", ".", "]" ), "", $value ) )
                                                                                                                            {
                                                                                                                                preg_match_all( "/(R(\\[?-?\\d*\\]?))(C(\\[?-?\\d*\\]?))/", $value, $cellReferences, PREG_SET_ORDER + PREG_OFFSET_CAPTURE );
                                                                                                                                $cellReferences = array_reverse( $cellReferences );
                                                                                                                                foreach ( $cellReferences as $cellReference )
                                                                                                                                {
                                                                                                                                    $rowReference = $cellReference[2][0];
                                                                                                                                    if ( $rowReference == "" )
                                                                                                                                    {
                                                                                                                                        $rowReference = $rowID;
                                                                                                                                    }
                                                                                                                                    if ( $rowReference[0] == "[" )
                                                                                                                                    {
                                                                                                                                        $rowReference = $rowID + trim( $rowReference, "[]" );
                                                                                                                                    }
                                                                                                                                    $columnReference = $cellReference[4][0];
                                                                                                                                    if ( $columnReference == "" )
                                                                                                                                    {
                                                                                                                                        $columnReference = $columnNumber;
                                                                                                                                    }
                                                                                                                                    if ( $columnReference[0] == "[" )
                                                                                                                                    {
                                                                                                                                        $columnReference = $columnNumber + trim( $columnReference, "[]" );
                                                                                                                                    }
                                                                                                                                    $A1CellReference = ( $columnReference - 1 ).$rowReference;
                                                                                                                                    $value = substr_replace( $value, $A1CellReference, $cellReference[0][1], strlen( $cellReference[0][0] ) );
                                                                                                                                }
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }
                                                                                                                    unset( $value );
                                                                                                                    $cellDataFormula = implode( "\"", $temp );
                                                                                                                }
                                                                                                                $objPHPExcel->getActiveSheet( )->getCell( $columnID.$rowID )->setValueExplicit( $hasCalculatedValue ? $cellDataFormula : $cellValue, $type );
                                                                                                                if ( $hasCalculatedValue )
                                                                                                                {
                                                                                                                    $objPHPExcel->getActiveSheet( )->getCell( $columnID.$rowID )->setCalculatedValue( $cellValue );
                                                                                                                }
                                                                                                                $cellIsSet = $rowHasData = TRUE;
                                                                                                            }
                                                                                                            if ( isset( $cell->Comment ) )
                                                                                                            {
                                                                                                                $commentAttributes = $cell->Comment->attributes( $namespaces['ss'] );
                                                                                                                $author = "unknown";
                                                                                                                if ( isset( $commentAttributes->Author ) )
                                                                                                                {
                                                                                                                    $author = ( boolean );
                                                                                                                }
                                                                                                                $node = $cell->Comment->Data->asXML( );
                                                                                                                $annotation = strip_tags( $node );
                                                                                                                $objPHPExcel->getActiveSheet( )->getComment( $columnID.$rowID )->setAuthor( ( $author, $this->_charSet ) )->setText( $this->_parseRichText( $annotation ) );
                                                                                                            }
                                                                                                            if ( $cellIsSet && isset( $cell_ss['StyleID'] ) )
                                                                                                            {
                                                                                                                $style = ( boolean );
                                                                                                                if ( [$style]isset( $this->_styles[$style], $this->_styles ) )
                                                                                                                {
                                                                                                                    if ( $objPHPExcel->getActiveSheet( )->cellExists( $columnID.$rowID ) )
                                                                                                                    {
                                                                                                                        $objPHPExcel->getActiveSheet( )->getCell( $columnID.$rowID )->setValue( NULL );
                                                                                                                    }
                                                                                                                    $this->_styles( $this->_styles[$style] );
                                                                                                                }
                                                                                                            }
                                                                                                            ++$columnID;
                                                                                                        }
                                                                                                    }
                                                                                                    if ( $rowHasData )
                                                                                                    {
                                                                                                        if ( isset( $row_ss['StyleID'] ) )
                                                                                                        {
                                                                                                            $rowStyle = $row_ss['StyleID'];
                                                                                                        }
                                                                                                        if ( isset( $row_ss['Height'] ) )
                                                                                                        {
                                                                                                            $rowHeight = $row_ss['Height'];
                                                                                                            $objPHPExcel->getActiveSheet( )->getRowDimension( $rowID )->setRowHeight( $rowHeight );
                                                                                                        }
                                                                                                    }
                                                                                                    ++$rowID;
                                                                                                }
                                                                                            }
                                                                                            ++$worksheetID;
                                                                                        }
                                                                                    }
                                                                                    return $objPHPExcel;
                                                                                }

    private static function _convertStringEncoding( $string, $charset )
    {
        if ( $charset != "UTF-8" )
        {
            return ( $string, "UTF-8", $charset );
        }
        return $string;
    }

    private function _parseRichText( $is = "" )
    {
        $value = new PHPExcel_RichText( );
        ( $is, $this->_charSet )( ( $is, $this->_charSet ) );
        return $value;
    }

}

?>
