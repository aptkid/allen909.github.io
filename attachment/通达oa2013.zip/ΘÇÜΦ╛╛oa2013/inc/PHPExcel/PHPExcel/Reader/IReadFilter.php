<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
interface PHPExcel_Reader_IReadFilter
{

    public abstract function readCell( );
$column, $row, $worksheetName = "" )
    {

}

?>
