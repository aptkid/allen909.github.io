<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
function archive_table( $TABLE_SRC, $WHERE_STR = "", $DEL_SRC_DATA = FALSE, $TABLE_DEST = "", $DB_DEST = "" )
{
    $TABLE_SRC = td_trim( $TABLE_SRC );
    if ( $TABLE_SRC == "" )
    {
        return _( "��ָ��Ҫ�鵵�ı���" );
    }
    $OA_DB = TD::$_arr_db_master['db'];
    $OA_DB_ARCHIVE = TD::$_arr_db_master['db_archive'];
    if ( $TABLE_DEST == "" )
    {
        $TABLE_DEST = $TABLE_SRC."_".date( "Ymd" );
    }
    if ( $DB_DEST == "" )
    {
        $DB_DEST = $OA_DB_ARCHIVE;
    }
    $query = "show tables from ".$DB_DEST." like '".$TABLE_DEST."'";
    $cursor = exequery( ( ), $query, TRUE );
    if ( 0 < mysql_num_rows( $cursor ) )
    {
        return sprintf( _( "���ݿ�[%s]���Ѵ�������Ϊ[%s]�ı�" ), $DB_DEST, $TABLE_DEST );
    }
    $query = "create table `".$DB_DEST."`.`".$TABLE_DEST."` like `".$OA_DB."`.`".$TABLE_SRC."`;";
    if ( exequery( ( ), $query, TRUE, TRUE ) === FALSE )
    {
        return sprintf( _( "������ %s ʧ��" ), $TABLE_DEST );
    }
    $query = "insert into `".$DB_DEST."`.`".$TABLE_DEST."` select * from `".$OA_DB."`.`".$TABLE_SRC."`";
    $WHERE_STR = td_trim( $WHERE_STR );
    if ( $WHERE_STR != "" )
    {
        $query .= " where ".$WHERE_STR;
    }
    $cursor = exequery( ( ), $query, TRUE, TRUE );
    if ( $cursor )
    {
        $query = "drop table if exists `".$DB_DEST."`.`".$TABLE_DEST."`;";
        exequery( ( ), $query, TRUE, TRUE );
        return _( "���Ʊ����ݴ���" );
    }
    if ( $DEL_SRC_DATA )
    {
        if ( $WHERE_STR != "" )
        {
            $query = "delete from `".$OA_DB."`.`".$TABLE_SRC."` where ".$WHERE_STR;
        }
        else
        {
            $query = "truncate table `".$OA_DB."`.`".$TABLE_SRC."`";
        }
        exequery( ( ), $query, TRUE, TRUE );
    }
    return TRUE;
}

function drop_table( $TABLE_NAME )
{
    $query = "drop table if exists ".$TABLE_NAME;
    return exequery( ( ), $query, TRUE, TRUE );
}

function table_exists( $tableName, $database = "" )
{
    $tableName = trim( $tableName );
    if ( $tableName == "" )
    {
        return FALSE;
    }
    if ( $database == "" )
    {
        $sql = "SHOW TABLES LIKE '".$tableName."'";
    }
    else
    {
        $sql = "SHOW TABLES FROM ".$database." LIKE '{$tableName}'";
    }
    $cursor = exequery( ( ), $sql, TRUE );
    if ( 0 < mysql_num_rows( $cursor ) )
    {
        return TRUE;
    }
    return FALSE;
}

function field_exists( $tableName, $fieldName )
{
    $tableName = trim( $tableName );
    $fieldName = trim( $fieldName );
    if ( $tableName == "" || $fieldName == "" )
    {
        return FALSE;
    }
    if ( table_exists( $tableName ) )
    {
        return FALSE;
    }
    $sql = "SHOW COLUMNS FROM ".$tableName." LIKE '{$fieldName}'";
    $cursor = exequery( ( ), $sql, TRUE );
    if ( 0 < mysql_num_rows( $cursor ) )
    {
        return TRUE;
    }
    return FALSE;
}

function index_exists( $tableName, $indexName )
{
    $tableName = trim( $tableName );
    $indexName = trim( $indexName );
    if ( $tableName == "" || $indexName == "" )
    {
        return FALSE;
    }
    if ( table_exists( $tableName ) )
    {
        return FALSE;
    }
    $sql = "SHOW INDEX FROM ".$tableName;
    $cursor = exequery( ( ), $sql, TRUE );
    do
    {
        if ( $ROW = mysql_fetch_array( $cursor ) )
        {
        }
    } while ( !( $ROW['Key_name'] == $indexName ) );
    return TRUE;
    return FALSE;
}

function add_index( $TABLE_NAME, $INDEX_NAME, $FIELD_NAME = "" )
{
    if ( $FIELD_NAME == "" )
    {
        $FIELD_NAME = $INDEX_NAME;
    }
    if ( table_exists( $TABLE_NAME ) && !index_exists( $TABLE_NAME, $INDEX_NAME ) )
    {
        $query = "ALTER TABLE `".$TABLE_NAME."` ADD INDEX `".$INDEX_NAME."` (".$FIELD_NAME.");";
        return exequery( ( ), $query, TRUE, TRUE );
    }
    return FALSE;
}

function drop_index( $TABLE_NAME, $INDEX_NAME_STR )
{
    $RESULT = array( );
    $INDEXE_ARRAY = explode( ",", $INDEX_NAME_STR );
    foreach ( $INDEXE_ARRAY as $INDEX_NAME )
    {
        $INDEX_NAME = trim( $INDEX_NAME );
        if ( !( $INDEX_NAME != "" ) || !index_exists( $TABLE_NAME, $INDEX_NAME ) )
        {
            $query = "ALTER TABLE `".$TABLE_NAME."` DROP INDEX `".$INDEX_NAME."`;";
            $RESULT[$INDEX_NAME] = exequery( ( ), $query, TRUE, TRUE );
        }
    }
    return $RESULT;
}

function constraint_exists( $constraint_name )
{
    $sql = "SELECT 1 FROM `information_schema`.`KEY_COLUMN_USAGE` WHERE constraint_name='".$constraint_name."'";
    $cursor = exequery( ( ), $sql, TRUE );
    return 0 < mysql_num_rows( $cursor );
}

function sys_menu_exists( $menu )
{
    if ( is_array( $menu ) )
    {
        return FALSE;
    }
    $where_str = "";
    if ( $menu['mid'] != "" )
    {
        $where_str = " and MENU_ID='".$menu['mid']."'";
    }
    if ( $menu['name'] != "" )
    {
        $where_str = " and MENU_NAME='".$menu['name']."'";
    }
    if ( $menu['image'] != "" )
    {
        $where_str = " and IMAGE='".$menu['image']."'";
    }
    if ( $where_str == "" )
    {
        return FALSE;
    }
    $query = "select MENU_ID from SYS_MENU where 1=1 ".$where_str;
    $cursor = exequery( ( ), $query, TRUE );
    if ( 0 < mysql_num_rows( $cursor ) )
    {
        return TRUE;
    }
    return FALSE;
}

function sys_func_exists( $menu )
{
    if ( is_array( $menu ) )
    {
        return FALSE;
    }
    $where_str = "";
    if ( $menu['fid'] != "" )
    {
        $where_str = " and FUNC_ID='".$menu['fid']."'";
    }
    if ( $menu['mid'] != "" )
    {
        $where_str = " and MENU_ID='".$menu['mid']."'";
    }
    if ( $menu['name'] != "" )
    {
        $where_str = " and FUNC_NAME='".$menu['name']."'";
    }
    if ( $menu['code'] != "" )
    {
        $where_str = " and FUNC_CODE='".$menu['code']."'";
    }
    if ( $where_str == "" )
    {
        return FALSE;
    }
    $query = "select FUNC_ID from SYS_FUNCTION where 1=1 ".$where_str;
    $cursor = exequery( ( ), $query, TRUE );
    if ( 0 < mysql_num_rows( $cursor ) )
    {
        return TRUE;
    }
    return FALSE;
}

function sys_code_exists( $CODE_NO, $PARENT_NO )
{
    include_once( "inc/utility_all.php" );
    return get_code_name( $CODE_NO, $PARENT_NO ) != "";
}

function add_templates( $ARRAY )
{
    $INI_FILE = MYOA_ATTACH_PATH."config/template.ini";
    if ( !file_exists( $INI_FILE ) || !is_writable( $INI_FILE ) || !is_array( $ARRAY ) )
    {
        return FALSE;
    }
    $TEMPLATES_ARRAY = parse_ini_file( $INI_FILE );
    $TEMPLATES_DATA = trim( file_get_contents( $INI_FILE ) );
    if ( $TEMPLATES_DATA != "" )
    {
        $TEMPLATES_DATA .= "\r\n";
    }
    while ( list( $KEY, $VALUE ) = each( &$ARRAY ) )
    {
        if ( array_key_exists( $KEY, $TEMPLATES_ARRAY ) )
        {
            $TEMPLATES_DATA .= $KEY."=".$VALUE."\r\n";
        }
    }
    file_put_contents( $INI_FILE, $TEMPLATES_DATA );
    return TRUE;
}

function add_sys_code( $CODE_ARRAY )
{
    if ( !is_array( $CODE_ARRAY ) || sizeof( $CODE_ARRAY ) < 1 )
    {
    }
    else
    {
        foreach ( $CODE_ARRAY as $SYS_CODE )
        {
            $query = "SELECT 1 from SYS_CODE where CODE_NO='".$SYS_CODE['CODE_NO']."' and PARENT_NO='".$SYS_CODE['PARENT_NO']."'";
            $cursor = exequery( ( ), $query, TRUE );
            if ( mysql_num_rows( $cursor ) == 0 )
            {
                $query = "insert into SYS_CODE (`CODE_NO`, `CODE_NAME`, `CODE_ORDER`, `PARENT_NO`, `CODE_FLAG`, `CODE_EXT`) values('".$SYS_CODE['CODE_NO']."', '".$SYS_CODE['CODE_NAME']."', '".$SYS_CODE['CODE_ORDER']."', '".$SYS_CODE['PARENT_NO']."', '".$SYS_CODE['CODE_FLAG']."', '".mysql_escape_string( $SYS_CODE['CODE_EXT'] )."')";
                exequery( ( ), $query, TRUE, TRUE );
            }
        }
    }
}

function add_attachment_module( $MODULES )
{
    foreach ( $MODULES as $MODULE )
    {
        $MODULE_ID = $MODULE['MODULE_ID'];
        $MODULE_NAME = $MODULE['MODULE_NAME'];
        $MODULE_CODE = $MODULE['MODULE_CODE'];
        $query = "select MODULE_ID from ATTACHMENT_MODULE where MODULE_CODE='".$MODULE_CODE."'";
        $cursor = exequery( ( ), $query, TRUE );
        if ( $ROW = mysql_fetch_array( $cursor ) )
        {
            $MODULE_ID_NEW = $ROW['MODULE_ID'];
            if ( $MODULE_ID != $MODULE_ID_NEW )
            {
                $query = "update ATTACHMENT set MODULE='".$MODULE_ID."' where MODULE='{$MODULE_ID_NEW}'";
                exequery( ( ), $query, TRUE, TRUE );
                $query = "update ATTACHMENT_MODULE set MODULE_ID='".$MODULE_ID."',MODULE_NAME='{$MODULE_NAME}' where MODULE_ID='{$MODULE_ID_NEW}'";
                exequery( ( ), $query, TRUE, TRUE );
            }
        }
        else
        {
            $query = "INSERT INTO `ATTACHMENT_MODULE` (`MODULE_ID`, `MODULE_NAME`, `MODULE_CODE`) VALUES (".$MODULE_ID.", '{$MODULE_NAME}', '{$MODULE_CODE}');";
            exequery( ( ), $query, TRUE, TRUE );
        }
    }
}

function update_lock( $UPDATE_LOCK_FILE, $FLAG )
{
    if ( $FLAG )
    {
        file_put_contents( $UPDATE_LOCK_FILE, date( "Ymd" ) );
    }
    else
    {
        if ( file_exists( $UPDATE_LOCK_FILE ) )
        {
            unlink( $UPDATE_LOCK_FILE );
        }
    }
}

function remove_files( $files_array )
{
    foreach ( $files_array as $file )
    {
        if ( !file_exists( $file ) || !is_writable( $file ) )
        {
            @unlink( $file );
        }
    }
}

function remove_dirs( $dirs_array )
{
    include_once( "inc/utility_file.php" );
    foreach ( $dirs_array as $dir )
    {
        if ( !file_exists( $dir ) || !is_dir( $dir ) )
        {
            delete_dir( $dir, FALSE );
        }
    }
}

?>
