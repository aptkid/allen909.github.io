<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
function add_user( $USER_ARRAY )
{
    $USER_KEY_STR = "";
    $USER_KEY_VALUE = "";
    foreach ( $USER_ARRAY as $key => $value )
    {
        if ( $key == "NOT_LOGIN" )
        {
            $NOT_LOGIN = $value;
            $value = 1;
        }
        if ( $key == "DEPT_ID" )
        {
            $DEPT_ID = $value;
            $value = 0;
        }
        $USER_KEY_STR .= $key.",";
        $USER_KEY_VALUE .= "'".$value."',";
        if ( $key == "USER_ID" )
        {
            $USER_ID = $value;
        }
    }
    $USER_KEY_STR = td_trim( $USER_KEY_STR );
    $USER_KEY_VALUE = td_trim( $USER_KEY_VALUE );
    $query = "insert into USER (".$USER_KEY_STR.") values({$USER_KEY_VALUE})";
    exequery( ( ), $query );
    $UID = mysql_insert_id( );
    if ( $NOT_LOGIN_SIGN != 1 && !file_exists( MYOA_ATTACH_PATH."new_sms/".$UID.".sms" ) )
    {
        new_sms_remind( $UID, 0 );
    }
    add_log( 6, $USER_ID, $_SESSION['LOGIN_USER_ID'] );
    return $UID;
}

function set_user( $USER_ARRAY, $USER_ID, $UID )
{
    if ( !is_array( $USER_ARRAY ) || sizeof( $USER_ARRAY ) < 1 || $USER_ID == "" )
    {
    }
    else
    {
        $SQL = "";
        foreach ( $USER_ARRAY as $key => $value )
        {
            if ( $key == "NOT_LOGIN" )
            {
                $NOT_LOGIN = $value;
                $value = 1;
            }
            if ( $key == "DEPT_ID" )
            {
                $DEPT_ID = $value;
                $value = 0;
            }
            $SQL .= $key."='".$value."',";
            if ( $key == "NOT_LOGIN" && $value == 1 )
            {
                $NOT_LOGIN_SIGN = 1;
            }
            else
            {
                $NOT_LOGIN_SIGN = 0;
            }
        }
        $SQL = td_trim( $SQL );
        $query = "update USER set ".$SQL.( " where UID='".$UID."'" );
        exequery( ( ), $query );
        if ( $NOT_LOGIN_SIGN != 1 && !file_exists( MYOA_ATTACH_PATH."new_sms/".$UID.".sms" ) )
        {
            new_sms_remind( $UID, 0 );
        }
        add_log( 7, $USER_ID, $_SESSION['LOGIN_USER_ID'] );
    }
}

function bin2guid( $bin )
{
    $hex_guid = bin2hex( $bin );
    $hex_guid_to_guid_str = "";
    $k = 1;
    for ( ; $k <= 4; ++$k )
    {
        $hex_guid_to_guid_str .= substr( $hex_guid, 8 - 2 * $k, 2 );
    }
    $hex_guid_to_guid_str .= "-";
    $k = 1;
    for ( ; $k <= 2; ++$k )
    {
        $hex_guid_to_guid_str .= substr( $hex_guid, 12 - 2 * $k, 2 );
    }
    $hex_guid_to_guid_str .= "-";
    $k = 1;
    for ( ; $k <= 2; ++$k )
    {
        $hex_guid_to_guid_str .= substr( $hex_guid, 16 - 2 * $k, 2 );
    }
    $hex_guid_to_guid_str .= "-".substr( $hex_guid, 16, 4 );
    $hex_guid_to_guid_str .= "-".substr( $hex_guid, 20 );
    return strtoupper( $hex_guid_to_guid_str );
}

function get_org_array( $folder_list, $base_dn )
{
    $org_dn_array = array( );
    $org_guid_array = array( );
    $i = 0;
    for ( ; $i < $folder_list['count']; ++$i )
    {
        $dn = $folder_list[$i]['dn'];
        if ( substr( $dn, 0, 22 ) == "OU=Domain Controllers," )
        {
            $org_dn_array[] = iconv( "utf-8", MYOA_CHARSET, $dn );
            $org_guid_array[] = bin2guid( $folder_list[$i]['objectguid'][0] );
        }
    }
    $org_dn_new_array = array( );
    $i = 0;
    for ( ; $i < count( $org_dn_array ); ++$i )
    {
        $string = substr( $org_dn_array[$i], 0, 0 - strlen( $base_dn ) );
        $array = get_ou_array( $string );
        $array = array_reverse( $array );
        $org_dn_new_array[$i] = implode( ",", $array );
    }
    asort( &$org_dn_new_array );
    $org_array = array( );
    $tmp_array = array( );
}
$value = each( &$org_dn_new_array )[1];
$key = each( &$org_dn_new_array )[0];
if ( each( &$org_dn_new_array ) )
{
    $array = get_ou_array( $value );
    $j = 0;
    do
    {
        for ( ; $j < count( $array ); do
 {
 ++$j, } while ( 1 ) )
        {
            $parent = $j == 0 ? -1 : array_search( ( ( ( ( $j - 1 )."_" ).$parent )."_" ).$array[$j - 1], $tmp_array );
            if ( in_array( $j."_".$parent."_".$array[$j], $tmp_array ) )
            {
                $org_array[] = array( "name" => $array[$j], "level" => $j, "parent" => $parent, "islast" => 1, "line" => "", "dn" => $org_dn_array[$key], "guid" => $org_guid_array[$key] );
                $tmp_array[] = $j."_".$parent."_".$array[$j];
            }
        } while ( 1 );
    }
    $i = 0;
    for ( ; $i < count( $org_array ); ++$i )
    {
        $j = $i + 1;
        for ( ; $j < count( $org_array ); ++$j )
        {
            if ( $org_array[$j]['level'] < $org_array[$i]['level'] )
            {
                if ( $org_array[$i]['level'] == $org_array[$j]['level'] )
                {
                    $org_array[$i]['islast'] = 0;
                }
            }
        }
        $org_array[$i]['line'] = $org_array[$i]['islast'] ? "��" : "��";
        $parent = $org_array[$i]['parent'];
        do
        {
            if ( 0 <= $parent )
            {
                $org_array[$i]['line'] = ( $org_array[$parent]['islast'] ? _( "��" ) : "��" ).$org_array[$i]['line'];
                $parent = $org_array[$parent]['parent'];
            }
        } while ( 1 );
    }
    return $org_array;
}

function ldap_slashes( $str )
{
    return preg_replace( "/([\\x00-\\x1F\\*\\(\\)\\\\])/e", "\"\\\\\\\".join(\"\",unpack(\"H2\",\"$1\"))", $str );
}

function get_ldap_option( $config )
{
    $dc_array = explode( ".", $config['DOMAIN_NAME'] );
    $base_dn = "DC=".implode( ",DC=", $dc_array );
    return array( "account_suffix" => "@".$config['DOMAIN_NAME'], "base_dn" => $base_dn, "domain_controllers" => array( $config['DOMAIN_CONTROLLERS'] ) );
}

function get_ou_array( $string, $separator = "," )
{
    $array = array( );
    $count = 0;
    $i = 0;
    for ( ; $i < strlen( $string ); ++$i )
    {
        if ( $string[$i] == $separator && $string[$i - 1] != "\\" )
        {
            ++$count;
        }
        else
        {
            $array .= $count;
        }
    }
    $i = 0;
    for ( ; $i < count( $array ); ++$i )
    {
        if ( stristr( $array[$i], "=" ) )
        {
            $array[$i] = substr( $array[$i], strpos( $array[$i], "=" ) + 1 );
        }
    }
    return $array;
}

include_once( "inc/conn.php" );
include_once( "inc/utility.php" );
include_once( "inc/utility_cache.php" );
?>
