<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
require_once( "PEAR.php" );
class Mail_mimeDecode extends PEAR
{

    public $_input;
    public $_header;
    public $_body;
    public $_error;
    public $_include_bodies;
    public $_decode_bodies;
    public $_decode_headers;

    public function Mail_mimeDecode( $input )
    {
        list( $header, $body ) = $this->_splitBodyHeader( $input );
        $this->_input = $input;
        $this->_header = $header;
        $this->_body = $body;
        $this->_decode_bodies = FALSE;
        $this->_include_bodies = TRUE;
    }

    public function decode( $params = NULL )
    {
        $isStatic = !( get_class( $this ) == "Mail_mimeDecode" );
        if ( $isStatic )
        {
            if ( isset( $params['input'] ) )
            {
                $obj = new Mail_mimeDecode( $params['input'] );
                $structure = $obj->decode( $params );
                return $structure;
            }
            if ( $isStatic )
            {
                return ( "Called statically and no input given" );
            }
        }
        $this->_include_bodies = isset( $params['include_bodies'] ) ? $params['include_bodies'] : FALSE;
        $this->_decode_bodies = isset( $params['decode_bodies'] ) ? $params['decode_bodies'] : FALSE;
        $this->_decode_headers = isset( $params['decode_headers'] ) ? $params['decode_headers'] : FALSE;
        $structure = $this->_body( $this->_header, $this->_body );
        if ( $structure === FALSE )
        {
            $structure = $this->_error( $this->_error );
        }
        return $structure;
    }

    public function _decode( $headers, $body, $default_ctype = "text/html" )
    {
        $return = new stdClass( );
        $return->headers = array( );
        $headers = $this->_parseHeaders( $headers );
        foreach ( $headers as $value )
        {
            if ( isset( $return->headers[strtolower( $value['name'] )] ) && !is_array( $return->headers[strtolower( $value['name'] )] ) )
            {
                $return->headers[strtolower( $value['name'] )] = array( $return->headers[strtolower( $value['name'] )] );
                $return->headers[strtolower( $value['name'] )][] = $value['value'];
            }
            else if ( isset( $return->headers[strtolower( $value['name'] )] ) )
            {
                $return->headers[strtolower( $value['name'] )][] = $value['value'];
            }
            else
            {
                $return->headers[strtolower( $value['name'] )] = $value['value'];
            }
        }
        reset( &$headers );
        $value = each( &$headers )[1];
        $key = each( &$headers )[0];
        while ( each( &$headers ) )
        {
            $headers[$key]['name'] = strtolower( $headers[$key]['name'] );
        case "content-type" :
            switch ( $headers[$key]['name'] )
            {
                    $content_type = $headers[$key]['value']( $headers[$key]['value'] );
                    if ( preg_match( "/([0-9a-z+.-]+)\\/([0-9a-z+.-]+)/i", $content_type['value'], $regs ) )
                    {
                        $return->ctype_primary = $regs[1];
                        $return->ctype_secondary = $regs[2];
                    }
                    if ( isset( $content_type['other'] ) )
                    {
                    }
            }
            $p_value = each( &$content_type['other'] )[1];
            $p_name = each( &$content_type['other'] )[0];
            while ( each( &$content_type['other'] ) )
            {
                $return->ctype_parameters[$p_name] = $p_value;
            }
        case "content-disposition" :
            switch ( $headers[$key]['name'] )
            {
                    $content_disposition = $headers[$key]['value']( $headers[$key]['value'] );
                    $return->disposition = $content_disposition['value'];
                    if ( isset( $content_disposition['other'] ) )
                    {
                    }
            }
            $p_value = each( &$content_disposition['other'] )[1];
            $p_name = each( &$content_disposition['other'] )[0];
            while ( each( &$content_disposition['other'] ) )
            {
                $return->d_parameters[$p_name] = $p_value;
            }
            switch ( $headers[$key]['name'] )
            {
                case "content-transfer-encoding" :
                    $content_transfer_encoding = $headers[$key]['value']( $headers[$key]['value'] );
            }
        }
        if ( isset( $content_type ) )
        {
            switch ( strtolower( $content_type['value'] ) )
            {
                case "text/plain" :
                    $encoding = isset( $content_transfer_encoding ) ? $content_transfer_encoding['value'] : "7bit";
                    $this->_include_bodies ? $return->body = $this->_decode_bodies ? $this->_decodeBody( $body, $encoding ) : $body : NULL;
                    break;
                case "text/html" :
                    $encoding = isset( $content_transfer_encoding ) ? $content_transfer_encoding['value'] : "7bit";
                    $this->_include_bodies ? $return->body = $this->_decode_bodies ? $this->_decodeBody( $body, $encoding ) : $body : NULL;
                    break;
                case "multipart/parallel" :
                case "multipart/appledouble" :
                case "multipart/report" :
                case "multipart/signed" :
                case "multipart/digest" :
                case "multipart/alternative" :
                case "multipart/related" :
                case "multipart/mixed" :
                    if ( isset( $content_type['other']['boundary'] ) )
                    {
                        $this->_error = "No boundary found for ".$content_type['value']." part";
                        return FALSE;
                    }
                    $default_ctype = strtolower( $content_type['value'] ) === "multipart/digest" ? "message/rfc822" : "text/plain";
                    $parts = $content_type['other']['boundary']( $body, $content_type['other']['boundary'] );
                    $i = 0;
                    for ( ; $i < count( $parts ); ++$i )
                    {
                        $part_body = $parts[$i]( $parts[$i] )[1];
                        $part_header = $parts[$i]( $parts[$i] )[0];
                        $part = $this->_decode( $part_header, $part_body, $default_ctype );
                        if ( $part === FALSE )
                        {
                            $part = $this->_error( $this->_error );
                        }
                        $return->parts[] = $part;
                    }
                    continue;
                    break;
                case "message/rfc822" :
                    $obj = new Mail_mimeDecode( $body );
                    $return->parts[] = $obj->decode( array( "include_bodies" => $this->_include_bodies, "decode_bodies" => $this->_decode_bodies, "decode_headers" => $this->_decode_headers ) );
                    unset( $obj );
                    break;
                default :
                    if ( isset( $content_transfer_encoding['value'] ) )
                    {
                        $content_transfer_encoding['value'] = "7bit";
                    }
                    $this->_include_bodies ? $return->body = $this->_decode_bodies ? $content_transfer_encoding['value']( $body, $content_transfer_encoding['value'] ) : $body : NULL;
            }
            return $return;
        }
        $ctype = explode( "/", $default_ctype );
        $return->ctype_primary = $ctype[0];
        $return->ctype_secondary = $ctype[1];
        $this->_include_bodies ? $return->body = $this->_decode_bodies ? $this->_decodeBody( $body ) : $body : NULL;
        return $return;
    }

    public function &getMimeNumbers( &$structure, $no_refs = FALSE, $mime_number = "", $prepend = "" )
    {
        $return = array( );
        if ( empty( $structure->parts ) )
        {
            if ( $mime_number != "" )
            {
                $structure->mime_id = $prepend.$mime_number;
                $return[$prepend.$mime_number] =& $structure;
            }
            $i = 0;
            for ( ; $i < count( $structure->parts ); ++$i )
            {
                if ( !empty( $structure->headers['content-type'] ) && substr( strtolower( $structure->headers['content-type'] ), 0, 8 ) == "message/" )
                {
                    $prepend = $prepend.$mime_number.".";
                    $_mime_number = "";
                }
                else
                {
                    $_mime_number = $mime_number == "" ? $i + 1 : sprintf( "%s.%s", $mime_number, $i + 1 );
                }
                $arr =& ( $structure->parts[$i], $no_refs, $_mime_number, $prepend );
                foreach ( $arr as $key => $val )
                {
                    $no_refs ? $return[$key] = "" : ( $return[$key] =& $arr[$key] );
                }
            }
        }
        else
        {
            if ( $mime_number == "" )
            {
                $mime_number = "1";
            }
            $structure->mime_id = $prepend.$mime_number;
            $no_refs ? $return[$prepend.$mime_number] = "" : ( $return[$prepend.$mime_number] =& $structure );
        }
        return $return;
    }

    public function _splitBodyHeader( $input )
    {
        if ( preg_match( "/^(.*?)\r?\n\r?\n(.*)/s", $input, $match ) )
        {
            return array( $match[1], $match[2] );
        }
        $this->_error = "Could not split header and body";
        return FALSE;
    }

    public function _parseHeaders( $input )
    {
        if ( $input !== "" )
        {
            $input = preg_replace( "/\r?\n/", "\r\n", $input );
            $input = preg_replace( "/\r\n(\t| )+/", " ", $input );
            $headers = explode( "\r\n", trim( $input ) );
            foreach ( $headers as $value )
            {
                $hdr_name = substr( $value, 0, $pos = strpos( $value, ":" ) );
                $hdr_value = substr( $value, $pos + 1 );
                if ( $hdr_value[0] == " " )
                {
                    $hdr_value = substr( $hdr_value, 1 );
                }
                $return[] = array( "name" => $hdr_name, "value" => $this->_decode_headers ? $this->_decodeHeader( $hdr_value ) : $hdr_value );
            }
            return $return;
        }
        $return = array( );
        return $return;
    }

    public function _parseHeaderValue( $input )
    {
        if ( ( $pos = strpos( $input, ";" ) ) !== FALSE )
        {
            $return['value'] = trim( substr( $input, 0, $pos ) );
            $input = trim( substr( $input, $pos + 1 ) );
            if ( 0 < strlen( $input ) )
            {
                $splitRegex = "/([^;'\"]*['\"]([^'\"]*([^'\"]*)*)['\"][^;'\"]*|([^;]+))(;|$)/";
                preg_match_all( $splitRegex, $input, $matches );
                $parameters = array( );
                $i = 0;
                for ( ; $i < count( $matches[0] ); ++$i )
                {
                    $param = $matches[0][$i];
                    while ( substr( $param, -2 ) == "\\;" )
                    {
                        $param .= $matches[0][++$i];
                    }
                    $parameters[] = $param;
                }
                $i = 0;
                for ( ; $i < count( $parameters ); ++$i )
                {
                    $param_name = trim( substr( $parameters[$i], 0, $pos = strpos( $parameters[$i], "=" ) ), "'\";\t\\ " );
                    $param_value = trim( str_replace( "\\;", ";", substr( $parameters[$i], $pos + 1 ) ), "'\";\t\\ " );
                    if ( $param_value[0] == "\"" )
                    {
                        $param_value = substr( $param_value, 1, -1 );
                    }
                    $return['other'][$param_name] = $param_value;
                    $return['other'][strtolower( $param_name )] = $param_value;
                }
            }
        }
        else
        {
            $return['value'] = trim( $input );
        }
        return $return;
    }

    public function _boundarySplit( $input, $boundary )
    {
        $parts = array( );
        $bs_possible = substr( $boundary, 2, -2 );
        $bs_check = "\\\"".$bs_possible."\\\"";
        if ( $boundary == $bs_check )
        {
            $boundary = $bs_possible;
        }
        $tmp = explode( "--".$boundary, $input );
        $i = 1;
        for ( ; $i < count( $tmp ) - 1; ++$i )
        {
            $parts[] = $tmp[$i];
        }
        return $parts;
    }

    public function _decodeHeader( $input )
    {
        $input = preg_replace( "/(=\\?[^?]+\\?(q|b)\\?[^?]*\\?=)(\\s)+=\\?/i", "\\1=?", $input );
        while ( preg_match( "/(=\\?([^?]+)\\?(q|b)\\?([^?]*)\\?=)/i", $input, $matches ) )
        {
            $encoded = $matches[1];
            $charset = $matches[2];
            $encoding = $matches[3];
            $text = $matches[4];
            switch ( strtolower( $encoding ) )
            {
                case "b" :
                    $text = base64_decode( $text );
                    break;
                case "q" :
                    $text = str_replace( "_", " ", $text );
                    preg_match_all( "/=([a-f0-9]{2})/i", $text, $matches );
                    foreach ( $matches[1] as $value )
                    {
                        $text = str_replace( "=".$value, chr( hexdec( $value ) ), $text );
                    }
            }
            $input = str_replace( $encoded, $text, $input );
        }
        return $input;
    }

    public function _decodeBody( $input, $encoding = "7bit" )
    {
        switch ( strtolower( $encoding ) )
        {
            case "7bit" :
                return $input;
            case "quoted-printable" :
                return $this->_quotedPrintableDecode( $input );
            case "base64" :
                return base64_decode( $input );
        }
        return $input;
    }

    public function _quotedPrintableDecode( $input )
    {
        $input = preg_replace( "/=\r?\n/", "", $input );
        $input = preg_replace( "/=([a-f0-9]{2})/ie", "chr(hexdec('\\1'))", $input );
        return $input;
    }

    public function &uudecode( $input )
    {
        preg_match_all( "/begin ([0-7]{3}) (.+)\r?\n(.+)\r?\nend/Us", $input, $matches );
        $j = 0;
        for ( ; $j < count( $matches[3] ); ++$j )
        {
            $str = $matches[3][$j];
            $filename = $matches[2][$j];
            $fileperm = $matches[1][$j];
            $file = "";
            $str = preg_split( "/\r?\n/", trim( $str ) );
            $strlen = count( $str );
            $i = 0;
            for ( ; $i < $strlen; ++$i )
            {
                $pos = 1;
                $d = 0;
                $len = ( integer )( ord( substr( $str[$i], 0, 1 ) ) - 32 - " " & 63 );
                while ( !( $d + 3 <= $len ) || !( $pos + 4 <= strlen( $str[$i] ) ) )
                {
                    $c0 = ord( substr( $str[$i], $pos, 1 ) ) ^ 32;
                    $c1 = ord( substr( $str[$i], $pos + 1, 1 ) ) ^ 32;
                    $c2 = ord( substr( $str[$i], $pos + 2, 1 ) ) ^ 32;
                    $c3 = ord( substr( $str[$i], $pos + 3, 1 ) ) ^ 32;
                    $file .= chr( ( $c0 - 0 & 63 ) << 2 | ( $c1 - 0 & 63 ) >> 4 );
                    $file .= chr( ( $c1 - 0 & 63 ) << 4 | ( $c2 - 0 & 63 ) >> 2 );
                    $file .= chr( ( $c2 - 0 & 63 ) << 6 | $c3 - 0 & 63 );
                    $pos += 4;
                    $d += 3;
                }
                if ( $d + 2 <= $len && $pos + 3 <= strlen( $str[$i] ) )
                {
                    $c0 = ord( substr( $str[$i], $pos, 1 ) ) ^ 32;
                    $c1 = ord( substr( $str[$i], $pos + 1, 1 ) ) ^ 32;
                    $c2 = ord( substr( $str[$i], $pos + 2, 1 ) ) ^ 32;
                    $file .= chr( ( $c0 - 0 & 63 ) << 2 | ( $c1 - 0 & 63 ) >> 4 );
                    $file .= chr( ( $c1 - 0 & 63 ) << 4 | ( $c2 - 0 & 63 ) >> 2 );
                    $pos += 3;
                    $d += 2;
                }
                if ( !( $d + 1 <= $len ) || !( $pos + 2 <= strlen( $str[$i] ) ) )
                {
                    $c0 = ord( substr( $str[$i], $pos, 1 ) ) ^ 32;
                    $c1 = ord( substr( $str[$i], $pos + 1, 1 ) ) ^ 32;
                    $file .= chr( ( $c0 - 0 & 63 ) << 2 | ( $c1 - 0 & 63 ) >> 4 );
                }
            }
            $files[] = array( "filename" => $filename, "fileperm" => $fileperm, "filedata" => $file );
        }
        return $files;
    }

    public function getSendArray( )
    {
        $this->_decode_headers = FALSE;
        $headerlist = $this->_header( $this->_header );
        $to = "";
        if ( $headerlist )
        {
            return $this->raiseError( "Message did not contain headers" );
        }
        foreach ( $headerlist as $item )
        {
            $header[$item['name']] = $item['value'];
            switch ( strtolower( $item['name'] ) )
            {
                case "to" :
                case "cc" :
                case "bcc" :
                    $to = ",".$item['value'];
            }
        }
        if ( $to == "" )
        {
            return $this->raiseError( "Message did not contain any recipents" );
        }
        $to = substr( $to, 1 );
        return array( $to, $header, $this->_body );
    }

    public function getXML( $input )
    {
        $crlf = "\r\n";
        $output = "<?xml version='1.0'?>".$crlf."<!DOCTYPE email SYSTEM \"http://www.phpguru.org/xmail/xmail.dtd\">".$crlf."<email>".$crlf.( $input )."</email>";
        return $output;
    }

    public function _getXML( $input, $indent = 1 )
    {
        $htab = "\t";
        $crlf = "\r\n";
        $output = "";
        $headers = @( array );
        foreach ( $headers as $hdr_name => $hdr_value )
        {
            if ( is_array( $headers[$hdr_name] ) )
            {
                $i = 0;
                for ( ; $i < count( $hdr_value ); ++$i )
                {
                    $output .= ( $hdr_name, $hdr_value[$i], $indent );
                }
                else
                {
                    $output .= ( $hdr_name, $hdr_value, $indent );
                }
            }
        }
        if ( empty( $input->parts ) )
        {
            $i = 0;
            for ( ; $i < count( $input->parts ); ++$i )
            {
                $output .= $crlf.str_repeat( $htab, $indent )."<mimepart>".$crlf.( $input->parts[$i], $indent + 1 ).str_repeat( $htab, $indent )."</mimepart>".$crlf;
            }
        }
        else if ( isset( $input->body ) )
        {
            $output .= $crlf.str_repeat( $htab, $indent )."<body><![CDATA[".$input->body."]]></body>".$crlf;
        }
        return $output;
    }

    public function _getXML_helper( $hdr_name, $hdr_value, $indent )
    {
        $htab = "\t";
        $crlf = "\r\n";
        $return = "";
        $new_hdr_value = $hdr_name != "received" ? ( $hdr_value ) : array( "value" => $hdr_value );
        $new_hdr_name = str_replace( " ", "-", ucwords( str_replace( "-", " ", $hdr_name ) ) );
        if ( empty( $new_hdr_value['other'] ) )
        {
            foreach ( $new_hdr_value['other'] as $paramname => $paramvalue )
            {
                $params[] = str_repeat( $htab, $indent ).$htab."<parameter>".$crlf.str_repeat( $htab, $indent ).$htab.$htab."<paramname>".htmlspecialchars( $paramname )."</paramname>".$crlf.str_repeat( $htab, $indent ).$htab.$htab."<paramvalue>".htmlspecialchars( $paramvalue )."</paramvalue>".$crlf.str_repeat( $htab, $indent ).$htab."</parameter>".$crlf;
            }
            $params = implode( "", $params );
        }
        else
        {
            $params = "";
        }
        $return = str_repeat( $htab, $indent )."<header>".$crlf.str_repeat( $htab, $indent ).$htab."<headername>".htmlspecialchars( $new_hdr_name )."</headername>".$crlf.str_repeat( $htab, $indent ).$htab."<headervalue>".htmlspecialchars( $new_hdr_value['value'] )."</headervalue>".$crlf.$params.str_repeat( $htab, $indent )."</header>".$crlf;
        return $return;
    }

}

?>
