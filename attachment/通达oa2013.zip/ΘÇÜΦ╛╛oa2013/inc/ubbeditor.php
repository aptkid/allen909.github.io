<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class UBBEditor
{

    public $InstanceName;
    public $BasePath;
    public $Width;
    public $Height;
    public $StartFocus;
    public $CtrlEnter;
    public $Value;

    public function __construct( $instanceName )
    {
        $this->InstanceName = $instanceName;
        $this->BasePath = MYOA_JS_SERVER."/module/ubbeditor/";
        $this->Width = "100%";
        $this->Height = "200";
        $this->StartFocus = "0";
        $this->CtrlEnter = "";
        $this->Value = "";
        $this->Language = MYOA_LANG_COOKIE;
    }

    public function Create( )
    {
        if ( $this->IsCompatible( ) )
        {
            $Html = "<input type=\"hidden\" name=\"".$this->InstanceName."\" id=\"".$this->InstanceName."\" value=\"".htmlspecialchars( $this->Value )."\" />";
            $Html .= "<iframe id=\"".$this->InstanceName."_iframe\" src=\"".$this->BasePath."index.html?InstanceName=".urlencode( $this->InstanceName )."&amp;Height=".urlencode( $this->Height )."&amp;Width=".urlencode( $this->Width )."&amp;BasePath=".urlencode( $this->BasePath )."&amp;StartFocus=".urlencode( $this->StartFocus )."&amp;CtrlEnter=".urlencode( $this->CtrlEnter )."&amp;Language=".urlencode( $this->Language )."\" style=\"width:".$this->Width.";height:".$this->Height.";\" frameborder=\"0\" scrolling=\"no\"></iframe>";
        }
        else
        {
            $Html = "<textarea name=\"".$this->InstanceName."\" id=\"".$this->InstanceName."\" style=\"width:".$this->Width.";height:".$this->Height.";\">".htmlspecialchars( $this->Value )."</textarea>";
        }
        echo $Html;
    }

    public function IsCompatible( )
    {
        $HTTP_USER_AGENT = $_SERVER['HTTP_USER_AGENT'];
        if ( isset( $HTTP_USER_AGENT ) )
        {
            $sAgent = $HTTP_USER_AGENT;
        }
        else
        {
            $sAgent = $_SERVER['HTTP_USER_AGENT'];
        }
        if ( stripos( $sAgent, "Safari/" ) !== FALSE && stripos( $sAgent, "Mobile" ) !== FALSE )
        {
            return FALSE;
        }
        return TRUE;
    }

}

?>
