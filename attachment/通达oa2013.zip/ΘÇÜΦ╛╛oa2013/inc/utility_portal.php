<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
function get_link_target_desc( $link_target )
{
    switch ( $link_target )
    {
        case "1" :
            return "_blank";
        case "2" :
            return "_self";
        case "3" :
            return "_parent";
        case "4" :
            return "_top";
    }
}

function get_my_portals_info( )
{
    $arr_templates = array( );
    $query = "select * from portal_templates";
    $cursor = exequery( ( ), $query );
    while ( $row = mysql_fetch_array( $cursor ) )
    {
        $arr_templates[$row['template_id']] = $row;
    }
    $arr_my_portals = array( );
    $query = "select * from portals where use_flag='1' order by portal_no";
    $cursor = exequery( ( ), $query );
    while ( $row = mysql_fetch_array( $cursor ) )
    {
        if ( $row['access_flag'] == "2" )
        {
            $access_priv_dept = $row['access_priv_dept'];
            $access_priv_priv = $row['access_priv_priv'];
            $access_priv_user = $row['access_priv_user'];
            $my_dept_id_str = $_SESSION['LOGIN_DEPT_ID'].",".$_SESSION['LOGIN_DEPT_ID_OTHER'];
            $my_priv_id_str = $_SESSION['LOGIN_USER_PRIV'].",".$_SESSION['LOGIN_USER_PRIV_OTHER'];
            if ( $access_priv_dept != "ALL_DEPT" && check_id( $my_dept_id_str, $access_priv_dept, TRUE ) == "" && check_id( $my_priv_id_str, $access_priv_priv, TRUE ) == "" && !find_id( $access_priv_user, $_SESSION['LOGIN_UID'] ) )
            {
            }
        }
        else
        {
            if ( $row['portal_type'] == "0" )
            {
                $row['portal_link'] = $arr_templates[$row['template_id']]['template_link']."?portal_id=".$row['portal_id'];
            }
            $arr_my_portals[$row['portal_id']] = $row;
        }
    }
    return $arr_my_portals;
}

function portal_manage_priv( $portal_id )
{
    if ( $_SESSION['LOGIN_SYS_ADMIN'] == "1" )
    {
        return TRUE;
    }
    $query = "select 1 from portals where portal_id='".$portal_id."' and find_in_set('{$_SESSION['LOGIN_UID']}', manage_priv_user)";
    $cursor = exequery( ( ), $query );
    if ( 0 < mysql_num_rows( $cursor ) )
    {
        return TRUE;
    }
    return FALSE;
}

function column_manage_priv( $portal_id, $column_id )
{
    if ( $_SESSION['LOGIN_SYS_ADMIN'] == "1" )
    {
        return array( TRUE, TRUE );
    }
    $arr_manage_priv = array( FALSE, FALSE );
    $query = "select priv_type from portal_priv where portal_id='".$portal_id."' and column_id='{$column_id}' AND (dept_id_str='ALL_DEPT' OR find_in_set('{$_SESSION['LOGIN_DEPT_ID']}', dept_id_str) OR find_in_set('{$_SESSION['LOGIN_USER_PRIV']}', priv_id_str) OR find_in_set('{$_SESSION['LOGIN_UID']}', uid_str) ".priv_other_sql( "priv_id_str" ).dept_other_sql( "dept_id_str" ).")";
    $cursor = exequery( ( ), $query );
    while ( $row = mysql_fetch_array( $cursor ) )
    {
        $arr_manage_priv[$row['priv_type']] = TRUE;
    }
    return $arr_manage_priv;
}

function portal_admin_log( $op, $remark )
{
}

function get_column_type( )
{
    $column_type = array( "0" => _( "�����б����������ݹ���ģ�飩" ), "4" => _( "�Զ���ҳ�棨�������ݹ���ģ�飩" ), "5" => _( "��һ������Ŀ" ), "1" => _( "�ⲿ����" ), "2" => _( "OAҵ������" ), "3" => _( "RSS��������" ) );
    return $column_type;
}

function get_content_type( )
{
    $content_type = array( "0" => _( "����" ), "1" => _( "����" ), "2" => _( "ͼƬ��" ), "3" => _( "��Ƶ" ) );
    return $content_type;
}

function get_link_target( )
{
    $content_target = array( "0" => _( "Ĭ��" ), "1" => _( "�´���" ), "2" => _( "��ǰ����" ), "3" => _( "������" ), "4" => _( "���㴰��" ) );
    return $content_target;
}

function get_column_link( $arr_columns_info, $portal_id, $column_id, $default_target = "_self" )
{
    $a_link = array( );
    $link_target = $arr_columns_info[$column_id]['link_target'];
    $column_type = $arr_columns_info[$column_id]['column_type'];
    $column_link = $arr_columns_info[$column_id]['column_link'];
    if ( $column_type != "1" )
    {
        $column_link = "column.php?portal_id=".$portal_id."&column_id=".$column_id;
    }
    if ( $link_target == 0 )
    {
        $link_target_property = $default_target;
    }
    else
    {
        $link_target_property = get_link_target_desc( $link_target );
    }
    $a_link['column_link'] = $column_link;
    $a_link['link_target'] = $link_target_property;
    return $a_link;
}

function get_content_link( $arr_content_info, $portal_id, $column_id, $default_target = "_blank" )
{
    $a_link = array( );
    $content_id = $arr_content_info['content_id'];
    $content_type = $arr_content_info['content_type'];
    $content_link = $arr_content_info['content_link'];
    $link_target = $arr_content_info['link_target'];
    if ( $content_type == "0" )
    {
        $content_link = "articl.php?portal_id=".$portal_id."&column_id=".$column_id."&content_id=".$content_id;
    }
    else if ( $content_type == "2" )
    {
        $content_link = "images.php?portal_id=".$portal_id."&column_id=".$column_id."&content_id=".$content_id;
    }
    else if ( $content_type == "3" )
    {
        $content_link = "video.php?portal_id=".$portal_id."&column_id=".$column_id."&content_id=".$content_id;
    }
    if ( $link_target == 0 )
    {
        $link_target_property = $default_target;
    }
    else
    {
        $link_target_property = get_link_target_desc( $link_target );
    }
    $a_link['content_link'] = $content_link;
    $a_link['link_target'] = $link_target_property;
    return $a_link;
}

include_once( "inc/utility.php" );
include_once( "inc/utility_all.php" );
?>
