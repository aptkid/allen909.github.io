<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class adLDAP
{

    protected $_account_suffix = "@mydomain.local";
    protected $_base_dn = "DC=mydomain,DC=local";
    protected $_domain_controllers = array( "dc01.mydomain.local" );
    protected $_ad_username;
    protected $_ad_password;
    protected $_real_primarygroup = TRUE;
    protected $_use_ssl = FALSE;
    protected $_use_tls = FALSE;
    protected $_recursive_groups = TRUE;
    protected $_conn;
    protected $_bind;

    public function set_account_suffix( $_account_suffix )
    {
        $this->_account_suffix = $_account_suffix;
    }

    public function get_account_suffix( )
    {
        return $this->_account_suffix;
    }

    public function set_domain_controllers( $_domain_controllers )
    {
        $this->_domain_controllers = $_domain_controllers;
    }

    public function get_domain_controllers( )
    {
        return $this->_domain_controllers;
    }

    public function set_ad_username( $_ad_username )
    {
        $this->_ad_username = $_ad_username;
    }

    public function get_ad_username( )
    {
        throw new adLDAPException( "For security reasons you cannot access the domain administrator account details" );
    }

    public function set_ad_password( $_ad_password )
    {
        $this->_ad_password = $_ad_password;
    }

    public function get_ad_password( )
    {
        throw new adLDAPException( "For security reasons you cannot access the domain administrator account details" );
    }

    public function set_real_primarygroup( $_real_primarygroup )
    {
        $this->_real_primarygroup = $_real_primarygroup;
    }

    public function get_real_primarygroup( )
    {
        return $this->_real_primarygroup;
    }

    public function set_use_ssl( $_use_ssl )
    {
        $this->_use_ssl = $_use_ssl;
    }

    public function get_use_ssl( )
    {
        return $this->_use_ssl;
    }

    public function set_use_tls( $_use_tls )
    {
        $this->_use_tls = $_use_tls;
    }

    public function get_use_tls( )
    {
        return $this->_use_tls;
    }

    public function set_recursive_groups( $_recursive_groups )
    {
        $this->_recursive_groups = $_recursive_groups;
    }

    public function get_recursive_groups( )
    {
        return $this->_recursive_groups;
    }

    public function __construct( $options = array( ) )
    {
        if ( 0 < count( $options ) )
        {
            if ( array_key_exists( "account_suffix", $options ) )
            {
                $this->_account_suffix = $options['account_suffix'];
            }
            if ( array_key_exists( "base_dn", $options ) )
            {
                $this->_base_dn = $options['base_dn'];
            }
            if ( array_key_exists( "domain_controllers", $options ) )
            {
                $this->_domain_controllers = $options['domain_controllers'];
            }
            if ( array_key_exists( "ad_username", $options ) )
            {
                $this->_ad_username = $options['ad_username'];
            }
            if ( array_key_exists( "ad_password", $options ) )
            {
                $this->_ad_password = $options['ad_password'];
            }
            if ( array_key_exists( "real_primarygroup", $options ) )
            {
                $this->_real_primarygroup = $options['real_primarygroup'];
            }
            if ( array_key_exists( "use_ssl", $options ) )
            {
                $this->_use_ssl = $options['use_ssl'];
            }
            if ( array_key_exists( "use_tls", $options ) )
            {
                $this->_use_tls = $options['use_tls'];
            }
            if ( array_key_exists( "recursive_groups", $options ) )
            {
                $this->_recursive_groups = $options['recursive_groups'];
            }
        }
        if ( $this->ldap_supported( ) === FALSE )
        {
            throw new adLDAPException( "No LDAP support for PHP.  See: http://www.php.net/ldap" );
        }
        return $this->connect( );
    }

    public function __destruct( )
    {
        $this->close( );
    }

    public function connect( )
    {
        $dc = $this->random_controller( );
        if ( $this->_use_ssl )
        {
            $this->_conn = ldap_connect( "ldaps://".$dc, 636 );
        }
        else
        {
            $this->_conn = ldap_connect( $dc );
        }
        ldap_set_option( $this->_conn, LDAP_OPT_PROTOCOL_VERSION, 3 );
        ldap_set_option( $this->_conn, LDAP_OPT_REFERRALS, 0 );
        if ( $this->_use_tls )
        {
            ldap_start_tls( $this->_conn );
        }
        if ( $this->_ad_username != NULL && $this->_ad_password != NULL )
        {
            $this->_bind = ldap_bind( @$this->_conn, @$this->_ad_username.@$this->_account_suffix, @$this->_ad_password );
            if ( $this->_bind )
            {
                if ( $this->_use_ssl && !$this->_use_tls )
                {
                    throw new adLDAPException( "Bind to Active Directory failed. Either the LDAPs connection failed or the login credentials are incorrect. AD said: ".$this->get_last_error( ) );
                }
                throw new adLDAPException( "Bind to Active Directory failed. Check the login credentials and/or server details. AD said: ".$this->get_last_error( ) );
            }
        }
        if ( $this->_base_dn == NULL )
        {
            $this->_base_dn = $this->find_base_dn( );
        }
        return TRUE;
    }

    public function close( )
    {
        ldap_close( $this->_conn );
    }

    public function authenticate( $username, $password, $prevent_rebind = FALSE )
    {
        if ( $username === NULL || $password === NULL )
        {
            return FALSE;
        }
        if ( empty( $username ) || empty( $password ) )
        {
            return FALSE;
        }
        $this->_bind = ldap_bind( @$this->_conn, @$username.@$this->_account_suffix, $password );
        if ( $this->_bind )
        {
            return FALSE;
        }
        if ( $this->_ad_username != NULL && !$prevent_rebind )
        {
            $this->_bind = ldap_bind( @$this->_conn, @$this->_ad_username.@$this->_account_suffix, @$this->_ad_password );
            if ( $this->_bind )
            {
                throw new adLDAPException( "Rebind to Active Directory failed. AD said: ".$this->get_last_error( ) );
            }
        }
        return TRUE;
    }

    public function group_add_group( $parent, $child )
    {
        $parent_group = $this->group_info( $parent, array( "cn" ) );
        if ( $parent_group[0]['dn'] === NULL )
        {
            return FALSE;
        }
        $parent_dn = $parent_group[0]['dn'];
        $child_group = $this->group_info( $child, array( "cn" ) );
        if ( $child_group[0]['dn'] === NULL )
        {
            return FALSE;
        }
        $child_dn = $child_group[0]['dn'];
        $add = array( );
        $add['member'] = $child_dn;
        $result = @ldap_mod_add( @$this->_conn, $parent_dn, $add );
        if ( $result )
        {
            return FALSE;
        }
        return TRUE;
    }

    public function group_add_user( $group, $user, $isGUID = FALSE )
    {
        $user_dn = $this->user_dn( $user, $isGUID );
        if ( $user_dn === FALSE )
        {
            return FALSE;
        }
        $group_info = $this->group_info( $group, array( "cn" ) );
        if ( $group_info[0]['dn'] === NULL )
        {
            return FALSE;
        }
        $group_dn = $group_info[0]['dn'];
        $add = array( );
        $add['member'] = $user_dn;
        $result = @ldap_mod_add( @$this->_conn, $group_dn, $add );
        if ( $result )
        {
            return FALSE;
        }
        return TRUE;
    }

    public function group_add_contact( $group, $contact_dn )
    {
        $group_info = $this->group_info( $group, array( "cn" ) );
        if ( $group_info[0]['dn'] === NULL )
        {
            return FALSE;
        }
        $group_dn = $group_info[0]['dn'];
        $add = array( );
        $add['member'] = $contact_dn;
        $result = @ldap_mod_add( @$this->_conn, $group_dn, $add );
        if ( $result )
        {
            return FALSE;
        }
        return TRUE;
    }

    public function group_create( $attributes )
    {
        if ( is_array( $attributes ) )
        {
            return "Attributes must be an array";
        }
        if ( array_key_exists( "group_name", $attributes ) )
        {
            return "Missing compulsory field [group_name]";
        }
        if ( array_key_exists( "container", $attributes ) )
        {
            return "Missing compulsory field [container]";
        }
        if ( array_key_exists( "description", $attributes ) )
        {
            return "Missing compulsory field [description]";
        }
        if ( is_array( $attributes['container'] ) )
        {
            return "Container attribute must be an array.";
        }
        $attributes['container'] = array_reverse( $attributes['container'] );
        $add = array( );
        $add['cn'] = $attributes['group_name'];
        $add['samaccountname'] = $attributes['group_name'];
        $add['objectClass'] = "Group";
        $add['description'] = $attributes['description'];
        $container = "OU=".implode( ",OU=", $attributes['container'] );
        $result = ldap_add( $this->_conn, "CN=".$add['cn'].", ".$container.",".$this->_base_dn, $add );
        if ( $result )
        {
            return FALSE;
        }
        return TRUE;
    }

    public function group_del_group( $parent, $child )
    {
        $parent_group = $this->group_info( $parent, array( "cn" ) );
        if ( $parent_group[0]['dn'] === NULL )
        {
            return FALSE;
        }
        $parent_dn = $parent_group[0]['dn'];
        $child_group = $this->group_info( $child, array( "cn" ) );
        if ( $child_group[0]['dn'] === NULL )
        {
            return FALSE;
        }
        $child_dn = $child_group[0]['dn'];
        $del = array( );
        $del['member'] = $child_dn;
        $result = @ldap_mod_del( @$this->_conn, $parent_dn, $del );
        if ( $result )
        {
            return FALSE;
        }
        return TRUE;
    }

    public function group_del_user( $group, $user, $isGUID = FALSE )
    {
        $group_info = $this->group_info( $group, array( "cn" ) );
        if ( $group_info[0]['dn'] === NULL )
        {
            return FALSE;
        }
        $group_dn = $group_info[0]['dn'];
        $user_dn = $this->user_dn( $user, $isGUID );
        if ( $user_dn === FALSE )
        {
            return FALSE;
        }
        $del = array( );
        $del['member'] = $user_dn;
        $result = @ldap_mod_del( @$this->_conn, $group_dn, $del );
        if ( $result )
        {
            return FALSE;
        }
        return TRUE;
    }

    public function group_del_contact( $group, $contact_dn )
    {
        $group_info = $this->group_info( $group, array( "cn" ) );
        if ( $group_info[0]['dn'] === NULL )
        {
            return FALSE;
        }
        $group_dn = $group_info[0]['dn'];
        $del = array( );
        $del['member'] = $contact_dn;
        $result = @ldap_mod_del( @$this->_conn, $group_dn, $del );
        if ( $result )
        {
            return FALSE;
        }
        return TRUE;
    }

    public function groups_in_group( $group, $recursive = NULL )
    {
        if ( $this->_bind )
        {
            return FALSE;
        }
        if ( $recursive === NULL )
        {
            $recursive = $this->_recursive_groups;
        }
        $info = $this->group_info( $group, array( "member", "cn" ) );
        $groups = $info[0]['member'];
        if ( is_array( $groups ) )
        {
            return FALSE;
        }
        $group_array = array( );
        $i = 0;
        for ( ; $i < $groups['count']; ++$i )
        {
            $filter = "(&(objectCategory=group)(distinguishedName=".$groups[$i]( $groups[$i] )."))";
            $fields = array( "samaccountname", "distinguishedname", "objectClass" );
            $sr = ldap_search( $this->_conn, $this->_base_dn, $filter, $fields );
            $entries = ldap_get_entries( $this->_conn, $sr );
            if ( $entries['count'] == 0 && $recursive )
            {
                $filter = "(&(objectCategory=group)(distinguishedName=".$groups[$i]( $groups[$i] )."))";
                $fields = array( "distinguishedname" );
                $sr = ldap_search( $this->_conn, $this->_base_dn, $filter, $fields );
                $entries = ldap_get_entries( $this->_conn, $sr );
                if ( isset( $entries[0]['distinguishedname'][0] ) )
                {
                }
                else
                {
                    $sub_groups = $entries[0]['distinguishedname'][0]( $entries[0]['distinguishedname'][0], $recursive );
                    if ( is_array( $sub_groups ) )
                    {
                        $group_array = array_merge( $group_array, $sub_groups );
                        $group_array = array_unique( $group_array );
                    }
                }
            }
            else
            {
                $group_array[] = $entries[0]['distinguishedname'][0];
            }
        }
        return $group_array;
    }

    public function group_members( $group, $recursive = NULL )
    {
        if ( $this->_bind )
        {
            return FALSE;
        }
        if ( $recursive === NULL )
        {
            $recursive = $this->_recursive_groups;
        }
        $info = $this->group_info( $group, array( "member", "cn" ) );
        $users = $info[0]['member'];
        if ( is_array( $users ) )
        {
            return FALSE;
        }
        $user_array = array( );
        $i = 0;
        for ( ; $i < $users['count']; ++$i )
        {
            $filter = "(&(objectCategory=person)(distinguishedName=".$users[$i]( $users[$i] )."))";
            $fields = array( "samaccountname", "distinguishedname", "objectClass" );
            $sr = ldap_search( $this->_conn, $this->_base_dn, $filter, $fields );
            $entries = ldap_get_entries( $this->_conn, $sr );
            if ( $entries['count'] == 0 && $recursive )
            {
                $filter = "(&(objectCategory=group)(distinguishedName=".$users[$i]( $users[$i] )."))";
                $fields = array( "samaccountname" );
                $sr = ldap_search( $this->_conn, $this->_base_dn, $filter, $fields );
                $entries = ldap_get_entries( $this->_conn, $sr );
                if ( isset( $entries[0]['samaccountname'][0] ) )
                {
                }
                else
                {
                    $sub_users = $entries[0]['samaccountname'][0]( $entries[0]['samaccountname'][0], $recursive );
                    if ( is_array( $sub_users ) )
                    {
                        $user_array = array_merge( $user_array, $sub_users );
                        $user_array = array_unique( $user_array );
                    }
                }
            }
            else if ( $entries[0]['samaccountname'][0] === NULL && $entries[0]['distinguishedname'][0] !== NULL )
            {
                $user_array[] = $entries[0]['distinguishedname'][0];
            }
            else if ( $entries[0]['samaccountname'][0] !== NULL )
            {
                $user_array[] = $entries[0]['samaccountname'][0];
            }
        }
        return $user_array;
    }

    public function group_info( $group_name, $fields = NULL )
    {
        if ( $group_name === NULL )
        {
            return FALSE;
        }
        if ( $this->_bind )
        {
            return FALSE;
        }
        if ( stristr( $group_name, "+" ) )
        {
            $group_name = stripslashes( $group_name );
        }
        $filter = "(&(objectCategory=group)(name=".$this->ldap_slashes( $group_name )."))";
        if ( $fields === NULL )
        {
            $fields = array( "member", "memberof", "cn", "description", "distinguishedname", "objectcategory", "samaccountname" );
        }
        $sr = ldap_search( $this->_conn, $this->_base_dn, $filter, $fields );
        $entries = ldap_get_entries( $this->_conn, $sr );
        return $entries;
    }

    public function recursive_groups( $group )
    {
        if ( $group === NULL )
        {
            return FALSE;
        }
        $ret_groups = array( );
        $groups = $this->group_info( $group, array( "memberof" ) );
        if ( is_array( $groups[0]['memberof'] ) )
        {
            $groups = $groups[0]['memberof'];
            if ( $groups )
            {
                $group_names = $this->nice_names( $groups );
                $ret_groups = array_merge( $ret_groups, $group_names );
                foreach ( $group_names as $id => $group_name )
                {
                    $child_groups = $this->recursive_groups( $group_name );
                    $ret_groups = array_merge( $ret_groups, $child_groups );
                }
            }
        }
        return $ret_groups;
    }

    public function search_groups( $samaccounttype = ADLDAP_SECURITY_GLOBAL_GROUP, $include_desc = FALSE, $search = "*", $sorted = TRUE )
    {
        if ( $this->_bind )
        {
            return FALSE;
        }
        $filter = "(&(objectCategory=group)";
        if ( $samaccounttype !== NULL )
        {
            $filter .= "(samaccounttype=".$samaccounttype.")";
        }
        $filter .= "(cn=".$search."))";
        $fields = array( "samaccountname", "description" );
        $sr = ldap_search( $this->_conn, $this->_base_dn, $filter, $fields );
        $entries = ldap_get_entries( $this->_conn, $sr );
        $groups_array = array( );
        $i = 0;
        for ( ; $i < $entries['count']; ++$i )
        {
            if ( $include_desc )
            {
                if ( 0 < strlen( $entries[$i]['description'][0] ) )
                {
                    $groups_array[$entries[$i]['samaccountname'][0]] = $entries[$i]['description'][0];
                    if ( $include_desc )
                    {
                    }
                    else
                    {
                        $groups_array[$entries[$i]['samaccountname'][0]] = $entries[$i]['samaccountname'][0];
                    }
                }
            }
            else
            {
                array_push( &$groups_array, $entries[$i]['samaccountname'][0] );
            }
        }
        if ( $sorted )
        {
            asort( &$groups_array );
        }
        return $groups_array;
    }

    public function all_groups( $include_desc = FALSE, $search = "*", $sorted = TRUE )
    {
        $groups_array = $this->search_groups( NULL, $include_desc, $search, $sorted );
        return $groups_array;
    }

    public function all_security_groups( $include_desc = FALSE, $search = "*", $sorted = TRUE )
    {
        $groups_array = $this->search_groups( ADLDAP_SECURITY_GLOBAL_GROUP, $include_desc, $search, $sorted );
        return $groups_array;
    }

    public function all_distribution_groups( $include_desc = FALSE, $search = "*", $sorted = TRUE )
    {
        $groups_array = $this->search_groups( ADLDAP_DISTRIBUTION_GROUP, $include_desc, $search, $sorted );
        return $groups_array;
    }

    public function user_create( $attributes )
    {
        if ( array_key_exists( "username", $attributes ) )
        {
            return "Missing compulsory field [username]";
        }
        if ( array_key_exists( "firstname", $attributes ) )
        {
            return "Missing compulsory field [firstname]";
        }
        if ( array_key_exists( "surname", $attributes ) )
        {
            return "Missing compulsory field [surname]";
        }
        if ( array_key_exists( "email", $attributes ) )
        {
            return "Missing compulsory field [email]";
        }
        if ( array_key_exists( "container", $attributes ) )
        {
            return "Missing compulsory field [container]";
        }
        if ( is_array( $attributes['container'] ) )
        {
            return "Container attribute must be an array.";
        }
        if ( array_key_exists( "password", $attributes ) && !$this->_use_ssl && !$this->_use_tls )
        {
            throw new adLDAPException( "SSL must be configured on your webserver and enabled in the class to set passwords." );
        }
        if ( array_key_exists( "display_name", $attributes ) )
        {
            $attributes['display_name'] = $attributes['firstname']." ".$attributes['surname'];
        }
        $add = $this->adldap_schema( $attributes );
        $add['cn'][0] = $attributes['display_name'];
        $add['samaccountname'][0] = $attributes['username'];
        $add['objectclass'][0] = "top";
        $add['objectclass'][1] = "person";
        $add['objectclass'][2] = "organizationalPerson";
        $add['objectclass'][3] = "user";
        $control_options = array( "NORMAL_ACCOUNT" );
        if ( $attributes['enabled'] )
        {
            $control_options[] = "ACCOUNTDISABLE";
        }
        $add['userAccountControl'][0] = $this->account_control( $control_options );
        $attributes['container'] = array_reverse( $attributes['container'] );
        $container = "OU=".implode( ",OU=", $attributes['container'] );
        $result = @ldap_add( @$this->_conn, @"CN=".@$add['cn'][0].", ".$container.",".@$this->_base_dn, $add );
        if ( $result )
        {
            return FALSE;
        }
        return TRUE;
    }

    public function user_delete( $username, $isGUID = FALSE )
    {
        $userinfo = $this->user_info( $username, array( "*" ), $isGUID );
        $dn = $userinfo[0]['distinguishedname'][0];
        $result = $this->dn_delete( $dn );
        if ( $result )
        {
            return FALSE;
        }
        return TRUE;
    }

    public function user_groups( $username, $recursive = NULL, $isGUID = FALSE )
    {
        if ( $username === NULL )
        {
            return FALSE;
        }
        if ( $recursive === NULL )
        {
            $recursive = $this->_recursive_groups;
        }
        if ( $this->_bind )
        {
            return FALSE;
        }
        $info = @$this->user_info( $username, @array( "memberof", "primarygroupid" ), $isGUID );
        $groups = $info[0]['memberof']( $info[0]['memberof'] );
        if ( $recursive === TRUE )
        {
            foreach ( $groups as $id => $group_name )
            {
                $extra_groups = $this->recursive_groups( $group_name );
                $groups = array_merge( $groups, $extra_groups );
            }
        }
        return $groups;
    }

    public function user_info( $username, $fields = NULL, $isGUID = FALSE )
    {
        if ( $username === NULL )
        {
            return FALSE;
        }
        if ( $this->_bind )
        {
            return FALSE;
        }
        if ( $isGUID === TRUE )
        {
            $username = $this->strguid2hex( $username );
            $filter = "objectguid=".$username;
        }
        else
        {
            $filter = "samaccountname=".$username;
        }
        if ( $fields === NULL )
        {
            $fields = array( "samaccountname", "mail", "memberof", "department", "displayname", "telephonenumber", "primarygroupid", "objectsid" );
        }
        $sr = ldap_search( $this->_conn, $this->_base_dn, $filter, $fields );
        $entries = ldap_get_entries( $this->_conn, $sr );
        if ( 1 <= $entries[0]['count'] )
        {
            if ( $this->_real_primarygroup && isset( $entries[0]['primarygroupid'][0], $entries[0]['objectsid'][0] ) )
            {
                $entries[0]['memberof'][] = $entries[0]['objectsid'][0]( $entries[0]['primarygroupid'][0], $entries[0]['objectsid'][0] );
            }
            else
            {
                $entries[0]['memberof'][] = "CN=Domain Users,CN=Users,".$this->_base_dn;
            }
        }
        ++$entries[0]['memberof']['count'];
        return $entries;
    }

    public function user_ingroup( $username, $group, $recursive = NULL, $isGUID = FALSE )
    {
        if ( $username === NULL )
        {
            return FALSE;
        }
        if ( $group === NULL )
        {
            return FALSE;
        }
        if ( $this->_bind )
        {
            return FALSE;
        }
        if ( $recursive === NULL )
        {
            $recursive = $this->_recursive_groups;
        }
        $groups = $this->user_groups( $username, $recursive, $isGUID );
        if ( in_array( $group, $groups ) )
        {
            return TRUE;
        }
        return FALSE;
    }

    public function user_password_expiry( $username, $isGUID = FALSE )
    {
        if ( $username === NULL )
        {
            return "Missing compulsory field [username]";
        }
        if ( $this->_bind )
        {
            return FALSE;
        }
        if ( function_exists( "bcmod" ) )
        {
            return "Missing function support [bcmod] http://www.php.net/manual/en/book.bc.php";
        }
        $userinfo = $this->user_info( $username, array( "pwdlastset", "useraccountcontrol" ), $isGUID );
        $pwdlastset = $userinfo[0]['pwdlastset'][0];
        $status = array( );
        if ( $userinfo[0]['useraccountcontrol'][0] == "66048" )
        {
            return "Does not expire";
        }
        if ( $pwdlastset === "0" )
        {
            return "Password has expired";
        }
        $sr = ldap_read( $this->_conn, $this->_base_dn, "objectclass=*", array( "maxPwdAge" ) );
        if ( $sr )
        {
            return FALSE;
        }
        $info = ldap_get_entries( $this->_conn, $sr );
        $maxpwdage = $info[0]['maxpwdage'][0];
        if ( bcmod( $maxpwdage, 4.29497e+009 ) === "0" )
        {
            return "Domain does not expire passwords";
        }
        $pwdexpire = bcsub( $pwdlastset, $maxpwdage );
        $status['expiryts'] = bcsub( bcdiv( $pwdexpire, "10000000" ), "11644473600" );
        $status['expiryformat'] = date( "Y-m-d H:i:s", bcsub( bcdiv( $pwdexpire, "10000000" ), "11644473600" ) );
        return $status;
    }

    public function user_modify( $username, $attributes, $isGUID = FALSE )
    {
        if ( $username === NULL )
        {
            return "Missing compulsory field [username]";
        }
        if ( array_key_exists( "password", $attributes ) && !$this->_use_ssl )
        {
            throw new adLDAPException( "SSL must be configured on your webserver and enabled in the class to set passwords." );
        }
        $user_dn = $this->user_dn( $username, $isGUID );
        if ( $user_dn === FALSE )
        {
            return FALSE;
        }
        $mod = $this->adldap_schema( $attributes );
        if ( !$mod && !array_key_exists( "enabled", $attributes ) )
        {
            return FALSE;
        }
        if ( array_key_exists( "enabled", $attributes ) )
        {
            if ( $attributes['enabled'] )
            {
                $control_options = array( "NORMAL_ACCOUNT" );
            }
            else
            {
                $control_options = array( "NORMAL_ACCOUNT", "ACCOUNTDISABLE" );
            }
            $mod['userAccountControl'][0] = $this->account_control( $control_options );
        }
        $result = @ldap_modify( @$this->_conn, $user_dn, $mod );
        if ( $result )
        {
            return FALSE;
        }
        return TRUE;
    }

    public function user_disable( $username, $isGUID = FALSE )
    {
        if ( $username === NULL )
        {
            return "Missing compulsory field [username]";
        }
        $attributes = array( "enabled" => 0 );
        $result = $this->user_modify( $username, $attributes, $isGUID );
        if ( $result )
        {
            return FALSE;
        }
        return TRUE;
    }

    public function user_enable( $username, $isGUID = FALSE )
    {
        if ( $username === NULL )
        {
            return "Missing compulsory field [username]";
        }
        $attributes = array( "enabled" => 1 );
        $result = $this->user_modify( $username, $attributes, $isGUID );
        if ( $result )
        {
            return FALSE;
        }
        return TRUE;
    }

    public function user_password( $username, $password, $isGUID = FALSE )
    {
        if ( $username === NULL )
        {
            return FALSE;
        }
        if ( $password === NULL )
        {
            return FALSE;
        }
        if ( $this->_bind )
        {
            return FALSE;
        }
        if ( !$this->_use_ssl && !$this->_use_tls )
        {
            throw new adLDAPException( "SSL must be configured on your webserver and enabled in the class to set passwords." );
        }
        $user_dn = $this->user_dn( $username, $isGUID );
        if ( $user_dn === FALSE )
        {
            return FALSE;
        }
        $add = array( );
        $add['unicodePwd'][0] = $this->encode_password( $password );
        $result = ldap_mod_replace( $this->_conn, $user_dn, $add );
        if ( $result )
        {
            return FALSE;
        }
        return TRUE;
    }

    public function all_users( $include_desc = FALSE, $search = "*", $sorted = TRUE )
    {
        if ( $this->_bind )
        {
            return FALSE;
        }
        $filter = "(&(objectClass=user)(samaccounttype=".ADLDAP_NORMAL_ACCOUNT.")(objectCategory=person)(cn=".$search."))";
        $fields = array( "samaccountname", "displayname" );
        $sr = ldap_search( $this->_conn, $this->_base_dn, $filter, $fields );
        $entries = ldap_get_entries( $this->_conn, $sr );
        $users_array = array( );
        $i = 0;
        for ( ; $i < $entries['count']; ++$i )
        {
            if ( $include_desc )
            {
                if ( 0 < strlen( $entries[$i]['displayname'][0] ) )
                {
                    $users_array[$entries[$i]['samaccountname'][0]] = $entries[$i]['displayname'][0];
                    if ( $include_desc )
                    {
                    }
                    else
                    {
                        $users_array[$entries[$i]['samaccountname'][0]] = $entries[$i]['samaccountname'][0];
                    }
                }
            }
            else
            {
                array_push( &$users_array, $entries[$i]['samaccountname'][0] );
            }
        }
        if ( $sorted )
        {
            asort( &$users_array );
        }
        return $users_array;
    }

    public function username2guid( $username )
    {
        if ( $this->_bind )
        {
            return FALSE;
        }
        if ( $username === NULL )
        {
            return "Missing compulsory field [username]";
        }
        $filter = "samaccountname=".$username;
        $fields = array( "objectGUID" );
        $sr = @ldap_search( @$this->_conn, @$this->_base_dn, $filter, $fields );
        if ( 0 < ldap_count_entries( $this->_conn, $sr ) )
        {
            $entry = @ldap_first_entry( @$this->_conn, $sr );
            $guid = @ldap_get_values_len( @$this->_conn, $entry, "objectGUID" );
            $strGUID = $guid[0]( $guid[0] );
            return $strGUID;
        }
        return FALSE;
    }

    public function contact_create( $attributes )
    {
        if ( array_key_exists( "display_name", $attributes ) )
        {
            return "Missing compulsory field [display_name]";
        }
        if ( array_key_exists( "email", $attributes ) )
        {
            return "Missing compulsory field [email]";
        }
        if ( array_key_exists( "container", $attributes ) )
        {
            return "Missing compulsory field [container]";
        }
        if ( is_array( $attributes['container'] ) )
        {
            return "Container attribute must be an array.";
        }
        $add = $this->adldap_schema( $attributes );
        $add['cn'][0] = $attributes['display_name'];
        $add['objectclass'][0] = "top";
        $add['objectclass'][1] = "person";
        $add['objectclass'][2] = "organizationalPerson";
        $add['objectclass'][3] = "contact";
        if ( isset( $attributes['exchange_hidefromlists'] ) )
        {
            $add['msExchHideFromAddressLists'][0] = "TRUE";
        }
        $attributes['container'] = array_reverse( $attributes['container'] );
        $container = "OU=".implode( ",OU=", $attributes['container'] );
        $result = @ldap_add( @$this->_conn, @"CN=".@$add['cn'][0].", ".$container.",".@$this->_base_dn, $add );
        if ( $result )
        {
            return FALSE;
        }
        return TRUE;
    }

    public function contact_groups( $distinguishedname, $recursive = NULL )
    {
        if ( $distinguishedname === NULL )
        {
            return FALSE;
        }
        if ( $recursive === NULL )
        {
            $recursive = $this->_recursive_groups;
        }
        if ( $this->_bind )
        {
            return FALSE;
        }
        $info = @$this->contact_info( $distinguishedname, @array( "memberof", "primarygroupid" ) );
        $groups = $info[0]['memberof']( $info[0]['memberof'] );
        if ( $recursive === TRUE )
        {
            foreach ( $groups as $id => $group_name )
            {
                $extra_groups = $this->recursive_groups( $group_name );
                $groups = array_merge( $groups, $extra_groups );
            }
        }
        return $groups;
    }

    public function contact_info( $distinguishedname, $fields = NULL )
    {
        if ( $distinguishedname === NULL )
        {
            return FALSE;
        }
        if ( $this->_bind )
        {
            return FALSE;
        }
        $filter = "distinguishedName=".$distinguishedname;
        if ( $fields === NULL )
        {
            $fields = array( "distinguishedname", "mail", "memberof", "department", "displayname", "telephonenumber", "primarygroupid", "objectsid" );
        }
        $sr = ldap_search( $this->_conn, $this->_base_dn, $filter, $fields );
        $entries = ldap_get_entries( $this->_conn, $sr );
        if ( 1 <= $entries[0]['count'] )
        {
            if ( $this->_real_primarygroup && isset( $entries[0]['primarygroupid'][0], $entries[0]['primarygroupid'][0] ) )
            {
                $entries[0]['memberof'][] = $entries[0]['objectsid'][0]( $entries[0]['primarygroupid'][0], $entries[0]['objectsid'][0] );
            }
            else
            {
                $entries[0]['memberof'][] = "CN=Domain Users,CN=Users,".$this->_base_dn;
            }
        }
        ++$entries[0]['memberof']['count'];
        return $entries;
    }

    public function contact_ingroup( $distinguisedname, $group, $recursive = NULL )
    {
        if ( $distinguisedname === NULL )
        {
            return FALSE;
        }
        if ( $group === NULL )
        {
            return FALSE;
        }
        if ( $this->_bind )
        {
            return FALSE;
        }
        if ( $recursive === NULL )
        {
            $recursive = $this->_recursive_groups;
        }
        $groups = $this->contact_groups( $distinguisedname, array( "memberof" ), $recursive );
        if ( in_array( $group, $groups ) )
        {
            return TRUE;
        }
        return FALSE;
    }

    public function contact_modify( $distinguishedname, $attributes )
    {
        if ( $distinguishedname === NULL )
        {
            return "Missing compulsory field [distinguishedname]";
        }
        $mod = $this->adldap_schema( $attributes );
        if ( $mod )
        {
            return FALSE;
        }
        $result = ldap_modify( $this->_conn, $distinguishedname, $mod );
        if ( $result )
        {
            return FALSE;
        }
        return TRUE;
    }

    public function contact_delete( $distinguishedname )
    {
        $result = $this->dn_delete( $distinguishedname );
        if ( $result )
        {
            return FALSE;
        }
        return TRUE;
    }

    public function all_contacts( $include_desc = FALSE, $search = "*", $sorted = TRUE )
    {
        if ( $this->_bind )
        {
            return FALSE;
        }
        $filter = "(&(objectClass=contact)(cn=".$search."))";
        $fields = array( "displayname", "distinguishedname" );
        $sr = ldap_search( $this->_conn, $this->_base_dn, $filter, $fields );
        $entries = ldap_get_entries( $this->_conn, $sr );
        $users_array = array( );
        $i = 0;
        for ( ; $i < $entries['count']; ++$i )
        {
            if ( $include_desc )
            {
                if ( 0 < strlen( $entries[$i]['displayname'][0] ) )
                {
                    $users_array[$entries[$i]['distinguishedname'][0]] = $entries[$i]['displayname'][0];
                    if ( $include_desc )
                    {
                    }
                    else
                    {
                        $users_array[$entries[$i]['distinguishedname'][0]] = $entries[$i]['distinguishedname'][0];
                    }
                }
            }
            else
            {
                array_push( &$users_array, $entries[$i]['distinguishedname'][0] );
            }
        }
        if ( $sorted )
        {
            asort( &$users_array );
        }
        return $users_array;
    }

    public function folder_list( $folder_name = NULL, $dn_type = ADLDAP_FOLDER, $recursive = NULL, $type = NULL )
    {
        if ( $recursive === NULL )
        {
            $recursive = $this->_recursive_groups;
        }
        if ( $this->_bind )
        {
            return FALSE;
        }
        $filter = "(&";
        if ( $type !== NULL )
        {
            switch ( $type )
            {
                case "contact" :
                    $filter .= "(objectClass=contact)";
                    break;
                case "computer" :
                    $filter .= "(objectClass=computer)";
                    break;
                case "group" :
                    $filter .= "(objectClass=group)";
                    break;
                case "folder" :
                    $filter .= "(objectClass=organizationalUnit)";
                    break;
                case "container" :
                    $filter .= "(objectClass=container)";
                    break;
                case "domain" :
                    $filter .= "(objectClass=builtinDomain)";
                    break;
                default :
                    $filter .= "(objectClass=user)";
                }
                else
                {
                    $filter .= "(objectClass=*)";
            }
        }
        $searchou = $this->_base_dn;
        if ( is_array( $folder_name ) )
        {
            $ou = $dn_type."=".implode( ",".$dn_type."=", $folder_name );
            $filter .= "(!(distinguishedname=".$ou.",".$this->_base_dn.")))";
            $searchou = $ou.",".$this->_base_dn;
        }
        else
        {
            $filter .= "(!(distinguishedname=".$this->_base_dn.")))";
        }
        if ( $recursive === TRUE )
        {
            $sr = ldap_search( $this->_conn, $searchou, $filter, array( "objectguid", "objectclass", "distinguishedname", "samaccountname" ) );
            $entries = @ldap_get_entries( @$this->_conn, $sr );
            if ( is_array( $entries ) )
            {
                return $entries;
            }
        }
        $sr = ldap_list( $this->_conn, $searchou, $filter, array( "objectguid", "objectclass", "distinguishedname", "samaccountname" ) );
        $entries = @ldap_get_entries( @$this->_conn, $sr );
        if ( is_array( $entries ) )
        {
            return $entries;
        }
        return FALSE;
    }

    public function computer_info( $computer_name, $fields = NULL )
    {
        if ( $computer_name === NULL )
        {
            return FALSE;
        }
        if ( $this->_bind )
        {
            return FALSE;
        }
        $filter = "(&(objectClass=computer)(cn=".$computer_name."))";
        if ( $fields === NULL )
        {
            $fields = array( "memberof", "cn", "displayname", "dnshostname", "distinguishedname", "objectcategory", "operatingsystem", "operatingsystemservicepack", "operatingsystemversion" );
        }
        $sr = ldap_search( $this->_conn, $this->_base_dn, $filter, $fields );
        $entries = ldap_get_entries( $this->_conn, $sr );
        return $entries;
    }

    public function computer_ingroup( $computer_name, $group, $recursive = NULL )
    {
        if ( $computer_name === NULL )
        {
            return FALSE;
        }
        if ( $group === NULL )
        {
            return FALSE;
        }
        if ( $this->_bind )
        {
            return FALSE;
        }
        if ( $recursive === NULL )
        {
            $recursive = $this->_recursive_groups;
        }
        $groups = $this->computer_groups( $computer_name, array( "memberof" ), $recursive );
        if ( in_array( $group, $groups ) )
        {
            return TRUE;
        }
        return FALSE;
    }

    public function computer_groups( $computer_name, $recursive = NULL )
    {
        if ( $computer_name === NULL )
        {
            return FALSE;
        }
        if ( $recursive === NULL )
        {
            $recursive = $this->_recursive_groups;
        }
        if ( $this->_bind )
        {
            return FALSE;
        }
        $info = @$this->computer_info( $computer_name, @array( "memberof", "primarygroupid" ) );
        $groups = $info[0]['memberof']( $info[0]['memberof'] );
        if ( $recursive === TRUE )
        {
            foreach ( $groups as $id => $group_name )
            {
                $extra_groups = $this->recursive_groups( $group_name );
                $groups = array_merge( $groups, $extra_groups );
            }
        }
        return $groups;
    }

    public function exchange_create_mailbox( $username, $storagegroup, $emailaddress, $mailnickname = NULL, $usedefaults = TRUE, $base_dn = NULL, $isGUID = FALSE )
    {
        if ( $username === NULL )
        {
            return "Missing compulsory field [username]";
        }
        if ( $storagegroup === NULL )
        {
            return "Missing compulsory array [storagegroup]";
        }
        if ( is_array( $storagegroup ) )
        {
            return "[storagegroup] must be an array";
        }
        if ( $emailaddress === NULL )
        {
            return "Missing compulsory field [emailaddress]";
        }
        if ( $base_dn === NULL )
        {
            $base_dn = $this->_base_dn;
        }
        $container = "CN=".implode( ",CN=", $storagegroup );
        if ( $mailnickname === NULL )
        {
            $mailnickname = $username;
        }
        $mdbUseDefaults = $this->bool2str( $usedefaults );
        $attributes = array( "exchange_homemdb" => $container.",".$base_dn, "exchange_proxyaddress" => "SMTP:".$emailaddress, "exchange_mailnickname" => $mailnickname, "exchange_usedefaults" => $mdbUseDefaults );
        $result = $this->user_modify( $username, $attributes, $isGUID );
        if ( $result )
        {
            return FALSE;
        }
        return TRUE;
    }

    public function exchange_add_X400( $username, $country, $admd, $pdmd, $org, $surname, $givenname, $isGUID = FALSE )
    {
        if ( $username === NULL )
        {
            return "Missing compulsory field [username]";
        }
        $proxyvalue = "X400:";
        $user = $this->user_info( $username, array( "cn", "proxyaddresses" ), $isGUID );
        if ( $user[0]['dn'] === NULL )
        {
            return FALSE;
        }
        $user_dn = $user[0]['dn'];
        $attributes['exchange_proxyaddress'] = $proxyvalue."c=".$country.";a=".$admd.";p=".$pdmd.";o=".$org.";s=".$surname.";g=".$givenname.";";
        $add = $this->adldap_schema( $attributes );
        if ( $add )
        {
            return FALSE;
        }
        $result = @ldap_mod_add( @$this->_conn, $user_dn, $add );
        if ( $result )
        {
            return FALSE;
        }
        return TRUE;
    }

    public function exchange_add_address( $username, $emailaddress, $default = FALSE, $isGUID = FALSE )
    {
        if ( $username === NULL )
        {
            return "Missing compulsory field [username]";
        }
        if ( $emailaddress === NULL )
        {
            return "Missing compulsory fields [emailaddress]";
        }
        $proxyvalue = "smtp:";
        if ( $default === TRUE )
        {
            $proxyvalue = "SMTP:";
        }
        $user = $this->user_info( $username, array( "cn", "proxyaddresses" ), $isGUID );
        if ( $user[0]['dn'] === NULL )
        {
            return FALSE;
        }
        $user_dn = $user[0]['dn'];
        if ( is_array( $user[0]['proxyaddresses'] ) && $default === TRUE )
        {
            $modaddresses = array( );
            $i = 0;
            for ( ; $i < sizeof( $user[0]['proxyaddresses'] ); ++$i )
            {
                if ( strstr( $user[0]['proxyaddresses'][$i], "SMTP:" ) !== FALSE )
                {
                    $user[0]['proxyaddresses'][$i] = str_replace( "SMTP:", "smtp:", $user[0]['proxyaddresses'][$i] );
                }
                if ( $user[0]['proxyaddresses'][$i] != "" )
                {
                    $modaddresses['proxyAddresses'][$i] = $user[0]['proxyaddresses'][$i];
                }
            }
            $modaddresses['proxyAddresses'][sizeof( $user[0]['proxyaddresses'] ) - 1] = "SMTP:".$emailaddress;
            $result = @ldap_mod_replace( @$this->_conn, $user_dn, $modaddresses );
            if ( $result )
            {
                return FALSE;
            }
            return TRUE;
        }
        $attributes['exchange_proxyaddress'] = $proxyvalue.$emailaddress;
        $add = $this->adldap_schema( $attributes );
        if ( $add )
        {
            return FALSE;
        }
        $result = @ldap_mod_add( @$this->_conn, $user_dn, $add );
        if ( $result )
        {
            return FALSE;
        }
        return TRUE;
    }

    public function exchange_del_address( $username, $emailaddress, $isGUID = FALSE )
    {
        if ( $username === NULL )
        {
            return "Missing compulsory field [username]";
        }
        if ( $emailaddress === NULL )
        {
            return "Missing compulsory fields [emailaddress]";
        }
        $user = $this->user_info( $username, array( "cn", "proxyaddresses" ), $isGUID );
        if ( $user[0]['dn'] === NULL )
        {
            return FALSE;
        }
        $user_dn = $user[0]['dn'];
        if ( is_array( $user[0]['proxyaddresses'] ) )
        {
            $mod = array( );
            $i = 0;
            for ( ; $i < sizeof( $user[0]['proxyaddresses'] ); ++$i )
            {
                if ( strstr( $user[0]['proxyaddresses'][$i], "SMTP:" ) !== FALSE && $user[0]['proxyaddresses'][$i] == "SMTP:".$emailaddress )
                {
                    $mod['proxyAddresses'][0] = "SMTP:".$emailaddress;
                }
                else if ( !( strstr( $user[0]['proxyaddresses'][$i], "smtp:" ) !== FALSE ) || !( $user[0]['proxyaddresses'][$i] == "smtp:".$emailaddress ) )
                {
                    $mod['proxyAddresses'][0] = "smtp:".$emailaddress;
                }
            }
            $result = @ldap_mod_del( @$this->_conn, $user_dn, $mod );
            if ( $result )
            {
                return FALSE;
            }
            return TRUE;
        }
        return FALSE;
    }

    public function exchange_primary_address( $username, $emailaddress, $isGUID = FALSE )
    {
        if ( $username === NULL )
        {
            return "Missing compulsory field [username]";
        }
        if ( $emailaddress === NULL )
        {
            return "Missing compulsory fields [emailaddress]";
        }
        $user = $this->user_info( $username, array( "cn", "proxyaddresses" ), $isGUID );
        if ( $user[0]['dn'] === NULL )
        {
            return FALSE;
        }
        $user_dn = $user[0]['dn'];
        if ( is_array( $user[0]['proxyaddresses'] ) )
        {
            $modaddresses = array( );
            $i = 0;
            for ( ; $i < sizeof( $user[0]['proxyaddresses'] ); ++$i )
            {
                if ( strstr( $user[0]['proxyaddresses'][$i], "SMTP:" ) !== FALSE )
                {
                    $user[0]['proxyaddresses'][$i] = str_replace( "SMTP:", "smtp:", $user[0]['proxyaddresses'][$i] );
                }
                if ( $user[0]['proxyaddresses'][$i] == "smtp:".$emailaddress )
                {
                    $user[0]['proxyaddresses'][$i] = str_replace( "smtp:", "SMTP:", $user[0]['proxyaddresses'][$i] );
                }
                if ( $user[0]['proxyaddresses'][$i] != "" )
                {
                    $modaddresses['proxyAddresses'][$i] = $user[0]['proxyaddresses'][$i];
                }
            }
            $result = @ldap_mod_replace( @$this->_conn, $user_dn, $modaddresses );
            if ( $result )
            {
                return FALSE;
            }
            return TRUE;
        }
    }

    public function exchange_contact_mailenable( $distinguishedname, $emailaddress, $mailnickname = NULL )
    {
        if ( $distinguishedname === NULL )
        {
            return "Missing compulsory field [distinguishedname]";
        }
        if ( $emailaddress === NULL )
        {
            return "Missing compulsory field [emailaddress]";
        }
        if ( $mailnickname !== NULL )
        {
            $user = $this->contact_info( $distinguishedname, array( "cn", "displayname" ) );
            if ( $user[0]['displayname'] === NULL )
            {
                return FALSE;
            }
            $mailnickname = $user[0]['displayname'][0];
        }
        $attributes = array( "email" => $emailaddress, "contact_email" => "SMTP:".$emailaddress, "exchange_proxyaddress" => "SMTP:".$emailaddress, "exchange_mailnickname" => $mailnickname );
        $mod = $this->adldap_schema( $attributes );
        if ( $mod )
        {
            return FALSE;
        }
        $result = ldap_modify( $this->_conn, $distinguishedname, $mod );
        if ( $result )
        {
            return FALSE;
        }
        return TRUE;
    }

    public function exchange_servers( $attributes = array( "cn", "distinguishedname", "serialnumber" ) )
    {
        if ( $this->_bind )
        {
            return FALSE;
        }
        $configurationNamingContext = $this->get_root_dse( array( "configurationnamingcontext" ) );
        $sr = @ldap_search( @$this->_conn, @$configurationNamingContext[0]['configurationnamingcontext'][0], "(&(objectCategory=msExchExchangeServer))", $attributes );
        $entries = @ldap_get_entries( @$this->_conn, $sr );
        return $entries;
    }

    public function exchange_storage_groups( $exchangeServer, $attributes = array( "cn", "distinguishedname" ), $recursive = NULL )
    {
        if ( $this->_bind )
        {
            return FALSE;
        }
        if ( $exchangeServer === NULL )
        {
            return "Missing compulsory field [exchangeServer]";
        }
        if ( $recursive === NULL )
        {
            $recursive = $this->_recursive_groups;
        }
        $filter = "(&(objectCategory=msExchStorageGroup))";
        $sr = @ldap_search( @$this->_conn, $exchangeServer, $filter, $attributes );
        $entries = @ldap_get_entries( @$this->_conn, $sr );
        if ( $recursive === TRUE )
        {
            $i = 0;
            for ( ; $i < $entries['count']; ++$i )
            {
                $entries[$i]['msexchprivatemdb'] = $entries[$i]['distinguishedname'][0]( $entries[$i]['distinguishedname'][0] );
            }
        }
        return $entries;
    }

    public function exchange_storage_databases( $storageGroup, $attributes = array( "cn", "distinguishedname", "displayname" ) )
    {
        if ( $this->_bind )
        {
            return FALSE;
        }
        if ( $storageGroup === NULL )
        {
            return "Missing compulsory field [storageGroup]";
        }
        $filter = "(&(objectCategory=msExchPrivateMDB))";
        $sr = @ldap_search( @$this->_conn, $storageGroup, $filter, $attributes );
        $entries = @ldap_get_entries( @$this->_conn, $sr );
        return $entries;
    }

    public function find_base_dn( )
    {
        $namingContext = $this->get_root_dse( array( "defaultnamingcontext" ) );
        return $namingContext[0]['defaultnamingcontext'][0];
    }

    public function get_root_dse( $attributes = array( "*", "+" ) )
    {
        if ( $this->_bind )
        {
            return FALSE;
        }
        $sr = @ldap_read( @$this->_conn, NULL, "objectClass=*", $attributes );
        $entries = @ldap_get_entries( @$this->_conn, $sr );
        return $entries;
    }

    public function get_last_error( )
    {
        return ldap_error( @$this->_conn );
    }

    protected function ldap_supported( )
    {
        if ( function_exists( "ldap_connect" ) )
        {
            return FALSE;
        }
        return TRUE;
    }

    protected function adldap_schema( $attributes )
    {
        $mod = array( );
        array_walk( &$attributes, array( $this, "encode8bit" ) );
        if ( $attributes['address_city'] )
        {
            $mod['l'][0] = $attributes['address_city'];
        }
        if ( $attributes['address_code'] )
        {
            $mod['postalCode'][0] = $attributes['address_code'];
        }
        if ( $attributes['address_country'] )
        {
            $mod['c'][0] = $attributes['address_country'];
        }
        if ( $attributes['address_pobox'] )
        {
            $mod['postOfficeBox'][0] = $attributes['address_pobox'];
        }
        if ( $attributes['address_state'] )
        {
            $mod['st'][0] = $attributes['address_state'];
        }
        if ( $attributes['address_street'] )
        {
            $mod['streetAddress'][0] = $attributes['address_street'];
        }
        if ( $attributes['company'] )
        {
            $mod['company'][0] = $attributes['company'];
        }
        if ( $attributes['change_password'] )
        {
            $mod['pwdLastSet'][0] = 0;
        }
        if ( $attributes['department'] )
        {
            $mod['department'][0] = $attributes['department'];
        }
        if ( $attributes['description'] )
        {
            $mod['description'][0] = $attributes['description'];
        }
        if ( $attributes['display_name'] )
        {
            $mod['displayName'][0] = $attributes['display_name'];
        }
        if ( $attributes['email'] )
        {
            $mod['mail'][0] = $attributes['email'];
        }
        if ( $attributes['expires'] )
        {
            $mod['accountExpires'][0] = $attributes['expires'];
        }
        if ( $attributes['firstname'] )
        {
            $mod['givenName'][0] = $attributes['firstname'];
        }
        if ( $attributes['home_directory'] )
        {
            $mod['homeDirectory'][0] = $attributes['home_directory'];
        }
        if ( $attributes['home_drive'] )
        {
            $mod['homeDrive'][0] = $attributes['home_drive'];
        }
        if ( $attributes['initials'] )
        {
            $mod['initials'][0] = $attributes['initials'];
        }
        if ( $attributes['logon_name'] )
        {
            $mod['userPrincipalName'][0] = $attributes['logon_name'];
        }
        if ( $attributes['manager'] )
        {
            $mod['manager'][0] = $attributes['manager'];
        }
        if ( $attributes['office'] )
        {
            $mod['physicalDeliveryOfficeName'][0] = $attributes['office'];
        }
        if ( $attributes['password'] )
        {
            $mod['unicodePwd'][0] = $attributes['password']( $attributes['password'] );
        }
        if ( $attributes['profile_path'] )
        {
            $mod['profilepath'][0] = $attributes['profile_path'];
        }
        if ( $attributes['script_path'] )
        {
            $mod['scriptPath'][0] = $attributes['script_path'];
        }
        if ( $attributes['surname'] )
        {
            $mod['sn'][0] = $attributes['surname'];
        }
        if ( $attributes['title'] )
        {
            $mod['title'][0] = $attributes['title'];
        }
        if ( $attributes['telephone'] )
        {
            $mod['telephoneNumber'][0] = $attributes['telephone'];
        }
        if ( $attributes['mobile'] )
        {
            $mod['mobile'][0] = $attributes['mobile'];
        }
        if ( $attributes['pager'] )
        {
            $mod['pager'][0] = $attributes['pager'];
        }
        if ( $attributes['ipphone'] )
        {
            $mod['ipphone'][0] = $attributes['ipphone'];
        }
        if ( $attributes['web_page'] )
        {
            $mod['wWWHomePage'][0] = $attributes['web_page'];
        }
        if ( $attributes['fax'] )
        {
            $mod['facsimileTelephoneNumber'][0] = $attributes['fax'];
        }
        if ( $attributes['enabled'] )
        {
            $mod['userAccountControl'][0] = $attributes['enabled'];
        }
        if ( $attributes['group_sendpermission'] )
        {
            $mod['dlMemSubmitPerms'][0] = $attributes['group_sendpermission'];
        }
        if ( $attributes['group_rejectpermission'] )
        {
            $mod['dlMemRejectPerms'][0] = $attributes['group_rejectpermission'];
        }
        if ( $attributes['exchange_homemdb'] )
        {
            $mod['homeMDB'][0] = $attributes['exchange_homemdb'];
        }
        if ( $attributes['exchange_mailnickname'] )
        {
            $mod['mailNickname'][0] = $attributes['exchange_mailnickname'];
        }
        if ( $attributes['exchange_proxyaddress'] )
        {
            $mod['proxyAddresses'][0] = $attributes['exchange_proxyaddress'];
        }
        if ( $attributes['exchange_usedefaults'] )
        {
            $mod['mDBUseDefaults'][0] = $attributes['exchange_usedefaults'];
        }
        if ( $attributes['exchange_policyexclude'] )
        {
            $mod['msExchPoliciesExcluded'][0] = $attributes['exchange_policyexclude'];
        }
        if ( $attributes['exchange_policyinclude'] )
        {
            $mod['msExchPoliciesIncluded'][0] = $attributes['exchange_policyinclude'];
        }
        if ( $attributes['exchange_hidefromlists'] )
        {
            $mod['msExchHideFromAddressLists'][0] = $attributes['exchange_hidefromlists'];
        }
        if ( $attributes['contact_email'] )
        {
            $mod['targetAddress'][0] = $attributes['contact_email'];
        }
        if ( count( $mod ) == 0 )
        {
            return FALSE;
        }
        return $mod;
    }

    protected function group_cn( $gid )
    {
        if ( $gid === NULL )
        {
            return FALSE;
        }
        $r = FALSE;
        $filter = "(&(objectCategory=group)(samaccounttype=".ADLDAP_SECURITY_GLOBAL_GROUP."))";
        $fields = array( "primarygrouptoken", "samaccountname", "distinguishedname" );
        $sr = ldap_search( $this->_conn, $this->_base_dn, $filter, $fields );
        $entries = ldap_get_entries( $this->_conn, $sr );
        $i = 0;
        for ( ; $i < $entries['count']; ++$i )
        {
            if ( $entries[$i]['primarygrouptoken'][0] == $gid )
            {
                $r = $entries[$i]['distinguishedname'][0];
                $i = $entries['count'];
            }
        }
        return $r;
    }

    protected function get_primary_group( $gid, $usersid )
    {
        if ( $gid === NULL || $usersid === NULL )
        {
            return FALSE;
        }
        $r = FALSE;
        $gsid = substr_replace( $usersid, pack( "V", $gid ), strlen( $usersid ) - 4, 4 );
        $filter = "(objectsid=".$this->getTextSID( $gsid ).")";
        $fields = array( "samaccountname", "distinguishedname" );
        $sr = ldap_search( $this->_conn, $this->_base_dn, $filter, $fields );
        $entries = ldap_get_entries( $this->_conn, $sr );
        return $entries[0]['distinguishedname'][0];
    }

    protected function getTextSID( $binsid )
    {
        $hex_sid = bin2hex( $binsid );
        $rev = hexdec( substr( $hex_sid, 0, 2 ) );
        $subcount = hexdec( substr( $hex_sid, 2, 2 ) );
        $auth = hexdec( substr( $hex_sid, 4, 12 ) );
        $result = "{$rev}-{$auth}";
        $x = 0;
        for ( ; $x < $subcount; ++$x )
        {
            $subauth[$x] = hexdec( substr( $hex_sid, 16 + $x * 8, 8 )( substr( $hex_sid, 16 + $x * 8, 8 ) ) );
            $result .= "-".$subauth[$x];
        }
        return "S-".$result;
    }

    protected function little_endian( $hex )
    {
        $result = "";
        $x = strlen( $hex ) - 2;
        for ( ; 0 <= $x; $x -= 2 )
        {
            $result .= substr( $hex, $x, 2 );
        }
        return $result;
    }

    protected function binary2text( $bin )
    {
        $hex_guid = bin2hex( $bin );
        $hex_guid_to_guid_str = "";
        $k = 1;
        for ( ; $k <= 4; ++$k )
        {
            $hex_guid_to_guid_str .= substr( $hex_guid, 8 - 2 * $k, 2 );
        }
        $hex_guid_to_guid_str .= "-";
        $k = 1;
        for ( ; $k <= 2; ++$k )
        {
            $hex_guid_to_guid_str .= substr( $hex_guid, 12 - 2 * $k, 2 );
        }
        $hex_guid_to_guid_str .= "-";
        $k = 1;
        for ( ; $k <= 2; ++$k )
        {
            $hex_guid_to_guid_str .= substr( $hex_guid, 16 - 2 * $k, 2 );
        }
        $hex_guid_to_guid_str .= "-".substr( $hex_guid, 16, 4 );
        $hex_guid_to_guid_str .= "-".substr( $hex_guid, 20 );
        return strtoupper( $hex_guid_to_guid_str );
    }

    public function decodeGuid( $binaryGuid )
    {
        if ( $binaryGuid === NULL )
        {
            return "Missing compulsory field [binaryGuid]";
        }
        $strGUID = $this->binary2text( $binaryGuid );
        return $strGUID;
    }

    protected function strguid2hex( $strGUID )
    {
        $strGUID = str_replace( "-", "", $strGUID );
        $octet_str = "\\".substr( $strGUID, 6, 2 );
        $octet_str .= "\\".substr( $strGUID, 4, 2 );
        $octet_str .= "\\".substr( $strGUID, 2, 2 );
        $octet_str .= "\\".substr( $strGUID, 0, 2 );
        $octet_str .= "\\".substr( $strGUID, 10, 2 );
        $octet_str .= "\\".substr( $strGUID, 8, 2 );
        $octet_str .= "\\".substr( $strGUID, 14, 2 );
        $octet_str .= "\\".substr( $strGUID, 12, 2 );
        $i = 16;
        for ( ; $i <= strlen( $strGUID ) - 2; ++$i )
        {
            if ( $i % 2 == 0 )
            {
                $octet_str .= "\\".substr( $strGUID, $i, 2 );
            }
        }
        return $octet_str;
    }

    protected function user_dn( $username, $isGUID = FALSE )
    {
        $user = $this->user_info( $username, array( "cn" ), $isGUID );
        if ( $user[0]['dn'] === NULL )
        {
            return FALSE;
        }
        $user_dn = $user[0]['dn'];
        return $user_dn;
    }

    protected function encode_password( $password )
    {
        $password = "\"".$password."\"";
        $encoded = "";
        $i = 0;
        for ( ; $i < strlen( $password ); ++$i )
        {
            $encoded .= "{$password[$i]}\x00";
        }
        return $encoded;
    }

    protected function ldap_slashes( $str )
    {
        return preg_replace( "/([\\x00-\\x1F\\*\\(\\)\\\\])/e", "\"\\\\\\\".join(\"\",unpack(\"H2\",\"$1\"))", $str );
    }

    protected function random_controller( )
    {
        mt_srand( doubleval( microtime( ) ) * 100000000 );
        return $this->_domain_controllers[array_rand( $this->_domain_controllers )];
    }

    protected function account_control( $options )
    {
        $val = 0;
        if ( is_array( $options ) )
        {
            if ( in_array( "SCRIPT", $options ) )
            {
                $val += 1;
            }
            if ( in_array( "ACCOUNTDISABLE", $options ) )
            {
                $val += 2;
            }
            if ( in_array( "HOMEDIR_REQUIRED", $options ) )
            {
                $val += 8;
            }
            if ( in_array( "LOCKOUT", $options ) )
            {
                $val += 16;
            }
            if ( in_array( "PASSWD_NOTREQD", $options ) )
            {
                $val += 32;
            }
            if ( in_array( "ENCRYPTED_TEXT_PWD_ALLOWED", $options ) )
            {
                $val += 128;
            }
            if ( in_array( "TEMP_DUPLICATE_ACCOUNT", $options ) )
            {
                $val += 256;
            }
            if ( in_array( "NORMAL_ACCOUNT", $options ) )
            {
                $val += 512;
            }
            if ( in_array( "INTERDOMAIN_TRUST_ACCOUNT", $options ) )
            {
                $val += 2048;
            }
            if ( in_array( "WORKSTATION_TRUST_ACCOUNT", $options ) )
            {
                $val += 4096;
            }
            if ( in_array( "SERVER_TRUST_ACCOUNT", $options ) )
            {
                $val += 8192;
            }
            if ( in_array( "DONT_EXPIRE_PASSWORD", $options ) )
            {
                $val += 65536;
            }
            if ( in_array( "MNS_LOGON_ACCOUNT", $options ) )
            {
                $val += 131072;
            }
            if ( in_array( "SMARTCARD_REQUIRED", $options ) )
            {
                $val += 262144;
            }
            if ( in_array( "TRUSTED_FOR_DELEGATION", $options ) )
            {
                $val += 524288;
            }
            if ( in_array( "NOT_DELEGATED", $options ) )
            {
                $val += 1048576;
            }
            if ( in_array( "USE_DES_KEY_ONLY", $options ) )
            {
                $val += 2097152;
            }
            if ( in_array( "DONT_REQ_PREAUTH", $options ) )
            {
                $val += 4194304;
            }
            if ( in_array( "PASSWORD_EXPIRED", $options ) )
            {
                $val += 8388608;
            }
            if ( in_array( "TRUSTED_TO_AUTH_FOR_DELEGATION", $options ) )
            {
                $val += 16777216;
            }
        }
        return $val;
    }

    protected function nice_names( $groups )
    {
        $group_array = array( );
        $i = 0;
        for ( ; $i < $groups['count']; ++$i )
        {
            $line = $groups[$i];
            if ( 0 < strlen( $line ) )
            {
                $bits = explode( ",", $line );
                $group_array[] = substr( $bits[0], 3, strlen( $bits[0] ) - 3 );
            }
        }
        return $group_array;
    }

    protected function dn_delete( $dn )
    {
        $result = ldap_delete( $this->_conn, $dn );
        if ( $result )
        {
            return FALSE;
        }
        return TRUE;
    }

    protected function bool2str( $bool )
    {
        if ( $bool )
        {
            return "TRUE";
        }
        return "FALSE";
    }

    protected function encode8bit( &$item, $key )
    {
        $encode = FALSE;
        if ( is_string( $item ) )
        {
            $i = 0;
            for ( ; $i < strlen( $item ); ++$i )
            {
                if ( ord( $item[$i] ) >> 7 )
                {
                    $encode = TRUE;
                }
            }
        }
        if ( $encode === TRUE && $key != "password" )
        {
            $item = utf8_encode( $item );
        }
    }

}

define( "ADLDAP_NORMAL_ACCOUNT", 805306368 );
define( "ADLDAP_WORKSTATION_TRUST", 805306369 );
define( "ADLDAP_INTERDOMAIN_TRUST", 805306370 );
define( "ADLDAP_SECURITY_GLOBAL_GROUP", 268435456 );
define( "ADLDAP_DISTRIBUTION_GROUP", 268435457 );
define( "ADLDAP_SECURITY_LOCAL_GROUP", 536870912 );
define( "ADLDAP_DISTRIBUTION_LOCAL_GROUP", 536870913 );
define( "ADLDAP_FOLDER", "OU" );
define( "ADLDAP_CONTAINER", "CN" );
class adLDAPException extends Exception
{

}

?>
