<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
function get_my_news( $type = 0, $start = 0, $limit = 10, $order_by = "" )
{
    $CUR_TIME = time( );
    $arr_return = array( );
    $sql = "SELECT NEWS_ID,SUBJECT,NEWS_TIME,FORMAT,TYPE_ID,READERS,TOP,SUBJECT_COLOR from NEWS where PUBLISH='1' \r\n            and (TO_ID='ALL_DEPT' or find_in_set('".$_SESSION['LOGIN_DEPT_ID']."',TO_ID)\r\n                                  or find_in_set('".$_SESSION['LOGIN_USER_PRIV']."',PRIV_ID)\r\n                                  or find_in_set('".$_SESSION['LOGIN_USER_ID']."',USER_ID)".priv_other_sql( "PRIV_ID" ).dept_other_sql( "TO_ID" ).")";
    if ( $type != 0 )
    {
        $sql .= " and TYPE_ID='".$type."'";
    }
    $order_by = $order_by == "" ? "TOP desc,NEWS_TIME desc" : $order_by;
    $sql .= " order by ".$order_by." limit {$start},{$limit}";
    $cursor = exequery( ( ), $sql );
    while ( $row = mysql_fetch_array( $cursor ) )
    {
        $arr_return[] = $row;
    }
    return $arr_return;
}

?>
