<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
include_once( "inc/auth.inc.php" );
include_once( "inc/utility_all.php" );
if ( strstr( $FILE_NAME, ":" ) || strstr( $FILE_NAME, "../" ) || strstr( $FILE_NAME, "..\\" ) || strstr( $FILE_NAME, "./" ) || strstr( $FILE_NAME, ".\\" ) || strstr( $FILE_NAME, "/." ) || strstr( $FILE_NAME, "\\." ) )
{
    exit( );
}
$query = "select * from NETDISK where DISK_ID='".$DISK_ID."'";
$cursor = exequery( ( ), $query );
if ( $ROW = mysql_fetch_array( $cursor ) )
{
    $DISK_PATH = $ROW['DISK_PATH'];
}
else
{
    exit( );
}
$PATH = $DISK_PATH."/".$FILE_NAME;
$PATH = str_replace( "//", "/", $PATH );
if ( file_exists( iconv2os( $PATH ) ) )
{
    echo _( "�Ҳ����ļ�" );
    exit( );
}
$FILE_NAME = substr( $FILE_NAME, strrpos( $FILE_NAME, "/" ) + 1 );
ob_end_clean( );
header( "Cache-control: private" );
header( "Content-type: application/octet-stream;" );
header( "Accept-Ranges: bytes" );
header( "Accept-Length: ".sprintf( "%u", filesize( iconv2os( $PATH ) ) ) );
header( "Content-Disposition: attachment; ".get_attachment_filename( $FILE_NAME ) );
readfile( iconv2os( $PATH ) );
?>
