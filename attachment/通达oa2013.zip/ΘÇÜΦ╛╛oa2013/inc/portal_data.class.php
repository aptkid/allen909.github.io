<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
class PortalData
{

    private $_portal_id = 0;
    private $_arr_portal_info = array( );
    private $_arr_all_columns = array( );
    private $_unit_name = "";
    private $_miitbeian_no = "";
    private $_org_name = "";

    public function __construct( $portal_id )
    {
        $this->_portal_id = $portal_id;
    }

    public function get_portal_info( )
    {
        if ( count( $this->_arr_portal_info ) == 0 )
        {
            $query = "SELECT * FROM portals WHERE portal_id='".$this->_portal_id."' AND portal_type='0' AND template_id!='0' AND use_flag='1'";
            $cursor = exequery( ( ), $query );
            if ( $row = mysql_fetch_array( $cursor ) )
            {
                $this->_arr_portal_info['portal_name'] = $row['portal_name'];
                $this->_arr_portal_info['logo_img'] = $row['logo_img_name']( $row['logo_img_id'], $row['logo_img_name'] );
                $this->_arr_portal_info['logo_text'] = $row['logo_text'];
                $this->_arr_portal_info['logo_link'] = $row['logo_link'];
                $this->_arr_portal_info['template_id'] = $row['template_id'];
                $this->_arr_portal_info['access_flag'] = $row['access_flag'];
                $this->_arr_portal_info['access_priv_dept'] = $row['access_priv_dept'];
                $this->_arr_portal_info['access_priv_priv'] = $row['access_priv_priv'];
                $this->_arr_portal_info['access_priv_user'] = $row['access_priv_user'];
            }
        }
        return $this->_arr_portal_info;
    }

    public function get_nav_list( )
    {
        if ( count( $this->_arr_all_columns ) == 0 )
        {
            $this->fetch_all_columns( );
        }
        $arr_nav_list = array( );
        foreach ( $this->_arr_all_columns as $column_id => $column )
        {
            if ( !( $column['nav_flag'] == "1" ) || !( strlen( $column['column_no'] ) == 3 ) )
            {
                $arr_nav_list[$column_id] = $column;
            }
        }
        return $arr_nav_list;
    }

    public function get_columns_info( $column_id_str )
    {
        if ( count( $this->_arr_all_columns ) == 0 )
        {
            $this->fetch_all_columns( );
        }
        $arr_columns_info = array( );
        $arr_column_id = explode( ",", $column_id_str );
        foreach ( $arr_column_id as $column_id )
        {
            if ( isset( $this->_arr_all_columns[$column_id] ) )
            {
                $arr_columns_info[$column_id] = $this->_arr_all_columns[$column_id];
            }
        }
        return $arr_columns_info;
    }

    public function get_column_page( $column_id )
    {
        if ( count( $this->_arr_all_columns ) == 0 )
        {
            $this->fetch_all_columns( );
        }
        $arr_columns_page = array( );
        if ( !isset( $this->_arr_all_columns[$column_id] ) || $this->_arr_all_columns[$column_id]['column_type'] != "4" )
        {
            return $arr_columns_page;
        }
        $sql = "SELECT * FROM portal_column_pages WHERE portal_id='".$this->_portal_id."' AND column_id='{$column_id}'";
        $cursor = exequery( ( ), $sql );
        if ( $row = mysql_fetch_array( $cursor ) )
        {
            $content = $row['content'];
            $attach_id = $row['attach_id'];
            $attach_name = $row['attach_name'];
            $arr_files = array( );
            if ( !( $attach_id != "" ) || !( $attach_name != "" ) )
            {
                $arr_attach_id = explode( ",", $attach_id );
                $arr_attach_name = explode( "*", $attach_name );
                $i = 0;
                for ( ; $i < count( $arr_attach_id ); ++$i )
                {
                    $id = $arr_attach_id[$i];
                    $name = $arr_attach_name[$i];
                    if ( !( $id != "" ) || !( $name != "" ) )
                    {
                        $arr_files[] = array( "file_name" => $name, "file_url_down" => $this->get_attach_url( $id, $name, "down" ) );
                    }
                }
            }
            $arr_columns_page = array( "content" => $content, "files" => $arr_files );
        }
        return $arr_columns_page;
    }

    public function get_child_columns( $column_id )
    {
        if ( count( $this->_arr_all_columns ) == 0 )
        {
            $this->fetch_all_columns( );
        }
        $arr_child_columns = array( );
        if ( !isset( $this->_arr_all_columns[$column_id] ) || $this->_arr_all_columns[$column_id]['column_no'] == "" )
        {
            return $arr_child_columns;
        }
        $column_no = $this->_arr_all_columns[$column_id]['column_no'];
        $column_no_len = strlen( $column_no );
        foreach ( $this->_arr_all_columns as $column_id => $column )
        {
            if ( !( $column_no == substr( $column['column_no'], 0, $column_no_len ) ) || !( strlen( $column['column_no'] ) == $column_no_len + 3 ) )
            {
                $arr_child_columns[$column_id] = $column;
            }
        }
        return $arr_child_columns;
    }

    public function get_contents_list( $column_id, $start = 0, $limit = 10, $order_by = "" )
    {
        $arr_contents_list = array( );
        if ( isset( $this->_arr_all_columns[$column_id] ) )
        {
            return $arr_contents_list;
        }
        $column_type = $this->_arr_all_columns[$column_id]['column_type'];
        $content_params = $this->_arr_all_columns[$column_id]['content_params'];
        if ( $column_type == "0" )
        {
            $order_by = $order_by == "" ? "publish_time desc" : $order_by;
            $order_by_field = substr( $order_by, 0, strpos( $order_by, " " ) );
            $sql = "SELECT * FROM portal_contents WHERE portal_id='".$this->_portal_id."' AND column_id='{$column_id}' ";
            $sql .= "ORDER BY ".$order_by." LIMIT {$start},{$limit}";
            $cursor = exequery( ( ), $sql );
            while ( $row = mysql_fetch_array( $cursor ) )
            {
                $arr_contents_list[] = array( "content_id" => $row['content_id'], "subject" => $row['subject'], "content_type" => $row['content_type'], "content_link" => $row['content_link'], "link_target" => $row['link_target'], "link_img" => $row['link_img_name']( $row['link_img_id'], $row['link_img_name'] ), "time" => $row[$order_by_field] );
            }
        }
        if ( $column_type == "2" )
        {
            $params = unserialize( $content_params );
            if ( $params['module'] == "0" )
            {
                include_once( "inc/utility_notify.php" );
                $arr_notify = get_my_notify( $params['type'], $start, $limit, $order_by );
                foreach ( $arr_notify as $row )
                {
                    $arr_contents_list[] = array( "content_id" => 0, "subject" => $row['SUBJECT'], "content_type" => 1, "content_link" => "/general/notify/show/read_notify.php?NOTIFY_ID=".$row['NOTIFY_ID'], "link_target" => 0, "link_img" => "", "time" => $row['BEGIN_DATE'] );
                    return $arr_contents_list;
                }
                else
                {
                    if ( $params['module'] == "1" )
                    {
                        include_once( "inc/utility_news.php" );
                        $arr_news = get_my_news( $params['type'], $start, $limit, $order_by );
                        foreach ( $arr_news as $row )
                        {
                            $arr_contents_list[] = array( "content_id" => 0, "subject" => $row['SUBJECT'], "content_type" => 1, "content_link" => "/general/news/show/read_news.php?NEWS_ID=".$row['NEWS_ID'], "link_target" => 0, "link_img" => "", "time" => strtotime( $row['NEWS_TIME'] ) );
                            return $arr_contents_list;
                        }
                        else
                        {
                            if ( $column_type == "3" )
                            {
                                $arr_rss_items = $this->get_rss( $content_params, $start, $limit );
                                foreach ( $arr_rss_items as $rss_item )
                                {
                                    $arr_contents_list[] = array( "content_id" => "0", "subject" => mb_convert_encoding( $rss_item['title'], MYOA_CHARSET, "utf-8" ), "content_type" => "1", "content_link" => mb_convert_encoding( $rss_item['link'], MYOA_CHARSET, "utf-8" ), "link_target" => "0", "link_img" => "", "time" => strtotime( $rss_item['pubDate'] ) );
                                }
                            }
                        }
                    }
                }
            }
        }
        return $arr_contents_list;
    }

    public function get_contents_info( $content_id_str )
    {
        if ( $content_id_str == "" || !td_verify_ids( $content_id_str ) )
        {
            echo _( "������Ч" );
            exit( );
        }
        $arr_contents_info = array( );
        $content_id_str = td_trim( $content_id_str );
        if ( $content_id_str == "" )
        {
            return $arr_contents_info;
        }
        $sql = "SELECT * FROM portal_contents WHERE portal_id='".$this->_portal_id."' AND content_id in ({$content_id_str})";
        $cursor = exequery( ( ), $sql );
        while ( $row = mysql_fetch_array( $cursor ) )
        {
            $content_id = $row['content_id'];
            $content_type = $row['content_type'];
            $arr_content_info = array( "subject" => $row['subject'], "content_type" => $row['content_type'], "content_link" => $row['content_link'], "link_img" => $row['link_img_name']( $row['link_img_id'], $row['link_img_name'] ), "time" => $row['publish_time'], "content_text" => "", "files" => array( ) );
            if ( $content_type == 0 )
            {
                $sql = "SELECT content_text FROM portal_content_text WHERE content_id='".$content_id."'";
                $cursor1 = exequery( ( ), $sql );
                if ( $row1 = mysql_fetch_array( $cursor1 ) )
                {
                    $arr_content_info['content_text'] = $row1['content_text'];
                }
            }
            if ( !( $content_type == 0 ) && !( $content_type == 2 ) && !( $content_type == 3 ) )
            {
                $sql = "SELECT file_id,attach_id,attach_name,description,download FROM portal_content_files WHERE content_id='".$content_id."' order by file_no";
                $cursor1 = exequery( ( ), $sql );
                while ( $row1 = mysql_fetch_array( $cursor1 ) )
                {
                    $arr_content_info['files'][$row1['file_id']] = array( "file_name" => $row1['attach_name'], "file_url_view" => $row1['attach_name']( $row1['attach_id'], $row1['attach_name'], "view" ), "file_url_down" => $row1['attach_name']( $row1['attach_id'], $row1['attach_name'], "down" ), "description" => $row1['description'], "download" => $row1['download'] );
                }
            }
            $arr_contents_info[$content_id] = $arr_content_info;
        }
        return $arr_contents_info;
    }

    public function get_unit_name( )
    {
        if ( $this->_unit_name == "" )
        {
            $this->_unit_name = ( "SYS_UNIT" );
        }
        return $this->_unit_name;
    }

    public function get_miitbeian_no( )
    {
        if ( $this->_miitbeian_no == "" )
        {
            include_once( "inc/utility_all.php" );
            $sys_para = get_sys_para( "MIIBEIAN" );
            $this->_miitbeian_no = $sys_para['MIIBEIAN'];
        }
        return $this->_miitbeian_no;
    }

    private function fetch_all_columns( )
    {
        if ( count( $this->_arr_all_columns ) == 0 )
        {
            $arr_portal_info = $this->get_portal_info( );
            $template_id = $arr_portal_info['template_id'];
            $query = "SELECT * FROM portal_template_columns WHERE template_id='".$template_id."' AND use_flag='1' order by column_no";
            $cursor = exequery( ( ), $query );
            while ( $row = mysql_fetch_array( $cursor ) )
            {
                $this->_arr_all_columns[$row['column_id']] = array( "column_no" => $row['column_no'], "column_name" => $row['column_name'], "column_type" => $row['column_type'], "column_link" => $row['column_link'], "content_params" => $row['content_params'], "link_target" => $row['link_target'], "link_img" => $row['link_img_name']( $row['link_img_id'], $row['link_img_name'] ), "nav_flag" => $row['nav_flag'] );
            }
        }
    }

    private function get_attach_url( $attach_id, $attach_name, $type = "view" )
    {
        if ( $attach_id == "" || $attach_name == "" )
        {
            return "";
        }
        include_once( "inc/utility_file.php" );
        $arrach_url = attach_url( $attach_id, $attach_name, "portal" );
        return $arrach_url[$type]."&portal_id=".$this->_portal_id;
    }

    private function get_rss( $url, $start = 0, $limit = 10 )
    {
        $arr_rss_cache = ( "RSS_CACHE_".md5( $url ) );
        if ( $arr_rss_cache === FALSE )
        {
            include_once( "inc/rss_php.class.php" );
            $rss = new rss_php( );
            $rss->load( $url );
            $arr_rss_cache = $rss->getItems( );
            ( "RSS_CACHE_".md5( $url ), $arr_rss_cache, 3600 );
        }
        $arr_rss_items = array( );
        if ( is_array( $arr_rss_cache ) )
        {
            $count = 0;
            foreach ( $arr_rss_cache as $rss_item )
            {
                ++$count;
                if ( $start < $count && $count <= $start + $limit )
                {
                    $arr_rss_items[] = $rss_item;
                }
                else if ( $start + $limit < $count )
                {
                    break;
                }
            }
        }
        return $arr_rss_items;
    }

}

include_once( "inc/conn.php" );
?>
