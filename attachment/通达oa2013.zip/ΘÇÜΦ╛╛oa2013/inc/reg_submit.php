<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
function Message_reg( $type, $title, $tips, $button = NULL )
{
    if ( $type == "" )
    {
        $type = "error";
    }
    $html = "";
    if ( $button[0]['href'] )
    {
        $html = " href=\"".$button[0]['href']."\" ";
    }
    else if ( $button[0]['click'] )
    {
        $html = " href=\"javascript:;\" onclick=\"".$button[0]['click']."\" ";
    }
    echo "<div class=\"bd-msg-box\"><div class=\"msg-box-bd ".$type."\"><div class=\"msg-box-bd-title\"><div class=\"msg-box-bd-title-a\">".$title."</div></div><div class=\"msg-box-bd-title-b\">".$tips."</div></div><div class=\"msg-box-ft\"><a class=\"hd-reg-btn normal\" ".$html."><span>".$button[0]['value']."</span></a></div></div>";
}

ob_start( );
include_once( "inc/td_core.php" );
$SYS_VERSION = ( "SYS_VERSION" );
$HTML_PAGE_TITLE = TD_MYOA_PRODUCT_NAME;
include_once( "inc/header.inc.php" );
echo "<body class=\"reg-body\">\r\n<link rel=\"stylesheet\" type=\"text/css\" href=\"";
echo MYOA_STATIC_SERVER;
echo "/static/modules/system/reg/style.css\">\r\n<div class=\"hd\">\r\n  <div class=\"hd-wrapper clearfix\">\r\n      <div class=\"hd-title-wrapper\">\r\n          <div class=\"hd-title\">";
echo TD_MYOA_PRODUCT_NAME;
echo " ";
echo _( "����ע��" );
echo "</div>\r\n          <div class=\"hd-subtitle\">\r\n            ";
echo _( "Web����汾�ţ�" );
echo TD_MYOA_VERSION;
echo "&nbsp;\r\n            ";
echo _( "�ڲ��汾�ţ�" );
echo $SYS_VERSION['VER'];
echo "&nbsp;\r\n            ";
echo TD_MYOA_COMPANY_NAME;
echo " ";
echo _( "��Ȩ����" );
echo "&nbsp;\r\n            <a href=\"http://";
echo TD_MYOA_WEB_SITE;
echo "\" target=\"_blank\">";
echo TD_MYOA_WEB_SITE;
echo "</a>\r\n          </div>\r\n      </div>\r\n    <div class=\"hd-desc\">\r\n      ";
if ( MYOA_IS_UN != 1 )
{
    echo "        <a class=\"hd-reg-btn reg\" href=\"reg_trial.php\" title=\"";
    echo _( "�ӳ�������" );
    echo "\"><span>";
    echo _( "�ӳ�������" );
    echo "</span></a>\r\n      ";
}
echo "        <a class=\"hd-reg-btn buy\" href=\"http://www.tongda2000.com/buy/\" target=\"_blank\" title=\"";
echo _( "��������" );
echo "\"><span>";
echo _( "��������" );
echo "</span></a>\r\n        <a class=\"hd-reg-btn homepage\" href=\"http://";
echo TD_MYOA_WEB_SITE;
echo "\" target=\"_blank\" title=\"";
echo _( "ͨ�����" );
echo "\"><span>";
echo _( "ͨ�����" );
echo "</span></a>\r\n        <span class=\"hd-help-btn\">\r\n          ";
echo help( "001", "new/system_regist" );
echo "        </span>\r\n    </div>\r\n  </div>\r\n</div>\r\n\r\n<div class=\"bd\">\r\n";
if ( tdoa_check_reg( ) )
{
    include_once( "inc/auth.inc.php" );
    if ( find_id( $USER_FUNC_ID_STR, "38" ) )
    {
        message_reg( "", _( "��ʾ" ), _( "��ע��Ȩ��" ), array( array( "value" => _( "����" ), "click" => "history.back();" ) ) );
        exit( );
    }
}
if ( $USER_READ != "on" )
{
    message_reg( "", _( "ע��ʧ��" ), _( "������ͬ������ʹ��������ܽ�������ע�ᣡ" ), $BUTTON_BACK );
    exit( );
}
$ATTACHMENT_NAME = $_FILES['REGISTER_FILE']['name'];
$ATTACHMENT = $_FILES['REGISTER_FILE']['tmp_name'];
if ( file_exists( $ATTACHMENT ) )
{
    message_reg( "", _( "ע��ʧ��" ), _( "ע���ļ�������" ), $BUTTON_BACK );
    exit( );
}
if ( $ATTACHMENT_NAME != "tdkey7.dat" )
{
    message_reg( "", _( "ע��ʧ��" ), _( "ע���ļ�������" ), $BUTTON_BACK );
    exit( );
}
$REGISTER_CODE = @file_get_contents( $ATTACHMENT );
$REGISTER_CODE = trim( $REGISTER_CODE );
if ( $REGISTER_CODE === FALSE || strlen( $REGISTER_CODE ) < 256 || 512 < strlen( $REGISTER_CODE ) )
{
    message_reg( "", _( "ע��ʧ��" ), _( "ע���ļ�����" ), $BUTTON_BACK );
    exit( );
}
@unlink( $ATTACHMENT );
$RESULT = get_reg_info( $REGISTER_CODE, $REG_INFO );
if ( $RESULT !== TRUE )
{
    message_reg( "", _( "ע��ʧ��" ), $RESULT, $BUTTON_BACK );
    exit( );
}
$SN_INFO = $UNIT_INFO = "";
$query = "select * from VERSION";
$cursor = exequery( ( ), $query );
if ( $ROW = mysql_fetch_array( $cursor ) )
{
    $SN_INFO = $ROW['SN'];
}
$query = "select UNIT_NAME from UNIT";
$cursor = exequery( ( ), $query );
if ( $ROW = mysql_fetch_array( $cursor ) )
{
    $UNIT_INFO = $ROW['UNIT_NAME'];
}
$REG_INFO_ARRAY = explode( "*", $REG_INFO );
if ( $SN_INFO != $REG_INFO_ARRAY[1] || $UNIT_INFO != $REG_INFO_ARRAY[2] )
{
    message_reg( "", _( "ע��ʧ��" ), _( "ע���ļ����������Ϣ��һ�£�����ϵ������Ա��" ), $BUTTON_BACK );
    exit( );
}
if ( count( $REG_INFO_ARRAY ) < 7 )
{
    message_reg( "", _( "ע��ʧ��" ), _( "ע���ļ����󣬴������#1" ), $BUTTON_BACK );
    exit( );
}
if ( preg_match( "/^[0-9]{8}-[0-9]{4}$/", substr( $SN_INFO, 6 ) ) )
{
    $query = "ALTER TABLE `EMAIL_BODY` CHANGE `FROM_ID` `FROM_ID��` VARCHAR( 20 ) NOT NULL";
    @db_query( $query, @( ) );
    $query = "ALTER TABLE `FILE_CONTENT` CHANGE `SORT_ID` `SORT_ID��` INT( 11 ) DEFAULT '0' NOT NULL";
    @db_query( $query, @( ) );
    $query = "ALTER TABLE `FLOW_RUN` CHANGE `RUN_NAME` `RUN_NAME��` VARCHAR( 200 ) NOT NULL";
    @db_query( $query, @( ) );
}
$STR = strtok( $SN_INFO, "-" );
$SN_HEAD = $STR;
$STR = strtok( "-" );
$SN_CODE = $STR;
$STR = strtok( "-" );
$SN_TAIL = $STR;
$SN_MID = substr( $SN_INFO, 4, 1 );
if ( !strstr( $SN_INFO, "TD20" ) || strlen( $SN_HEAD ) != 5 || strlen( $SN_CODE ) != 8 || strlen( $SN_TAIL ) != 4 || !is_numeric( $SN_CODE ) || !is_numeric( $SN_TAIL ) )
{
    message_reg( "", _( "ע��ʧ��" ), _( "ע���ļ����󣬴������#2" ), $BUTTON_BACK );
    exit( );
}
if ( ( $SN_CODE - 1 ) % 11 != 0 && ( $SN_CODE - 2 ) % 11 != 0 && ( $SN_CODE - 3 ) % 11 != 0 )
{
    message_reg( "", _( "ע��ʧ��" ), _( "ע���ļ����󣬴������#3" ), $BUTTON_BACK );
    exit( );
}
$query = "update VERSION set `CODE`='".$REGISTER_CODE."';";
$cursor = exequery( ( ), $query );
if ( $cursor === FALSE )
{
    message_reg( "", _( "ע��ʧ��" ), _( "�������ݿ����" ), $BUTTON_BACK );
    exit( );
}
cache_version( );
login_check( "[TDCORE_REGCHECK_AUTO]", "[TDCORE_REGCHECK_AUTO]" );
add_log( 18, $_SESSION['LOGIN_USER_ID'], "admin" );
message_reg( "success", _( "��ʾ" ), _( "ͨ��OAע��ɹ���" ), array( array( "value" => _( "��¼ͨ��OA�칫ϵͳ" ), "click" => "window.open('/')" ) ) );
echo "</div>\r\n</body>\r\n</html>";
?>
