<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
$CRC32_SMS_ID = strtoupper( dechex( crc32( $SMS_ID ) ) );
$CRC32_UID = strtoupper( dechex( crc32( $UID ) ) );
$CRC32_SMS_UID = strtoupper( dechex( crc32( $SMS_ID.$UID ) ) );
if ( strtoupper( dechex( crc32( $CRC32_SMS_ID.$CRC32_UID.$CRC32_SMS_UID ) ) ) != $VALID_CODE )
{
    echo "-ERR "._( "��֤�����" );
    exit( );
}
include_once( "inc/td_config.php" );
include_once( "inc/utility.php" );
new_sms_remind( $UID, 1 );
echo "+OK";
?>
