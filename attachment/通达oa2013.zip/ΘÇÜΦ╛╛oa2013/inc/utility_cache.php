<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
function cache_org_xml( )
{
    $UNIT_NAME = "";
    $query = "SELECT UNIT_NAME from UNIT";
    $cursor = exequery( ( ), $query, TRUE );
    if ( $ROW = mysql_fetch_array( $cursor ) )
    {
        $UNIT_NAME = $ROW['UNIT_NAME'];
    }
    $MODULE_PRIV_ARRAY = array( );
    $query = "select * from MODULE_PRIV";
    $cursor = exequery( ( ), $query, TRUE );
    while ( $ROW = mysql_fetch_array( $cursor ) )
    {
        $UID = $ROW['UID'];
        $MODULE_ID = $ROW['MODULE_ID'];
        $DEPT_PRIV = $ROW['DEPT_PRIV'];
        $ROLE_PRIV = $ROW['ROLE_PRIV'];
        $PRIV_ID = $ROW['PRIV_ID'];
        $USER_ID = $ROW['USER_ID'];
        $DEPT_ID = $ROW['DEPT_ID'];
        if ( $MODULE_ID == 0 )
        {
            if ( $PRIV_ID != "" )
            {
                $MODULE_PRIV_ARRAY[$UID] = $PRIV_ID;
            }
            if ( $USER_ID != "" )
            {
                $MODULE_USER_ARRAY[$UID] = $USER_ID;
            }
            if ( $DEPT_ID != "" )
            {
                $MODULE_DEPT_ARRAY[$UID] = $DEPT_ID;
            }
        }
        else if ( $MODULE_ID == 1 )
        {
            if ( $DEPT_PRIV == "0" )
            {
                $query_el = "select DEPT_ID from user where UID='".$UID."'";
                $cursor_el = exequery( ( ), $query_el, TRUE );
                if ( $row_el = mysql_fetch_array( $cursor_el ) )
                {
                    $MODULE_DEPT1_ARRAY[$UID] = $row_el['DEPT_ID'];
                }
            }
            else if ( $DEPT_PRIV == "2" )
            {
                if ( $DEPT_ID != "ALL_DEPT" )
                {
                    $MODULE_DEPT1_ARRAY[$UID] = $DEPT_ID;
                }
            }
            else if ( $DEPT_PRIV == "3" || $DEPT_PRIV == "4" )
            {
                $MODULE_USER1_ARRAY[$UID] = $USER_ID;
            }
            $MODULE_ROLE1_ARRAY[$UID] = $ROLE_PRIV;
            if ( !( $DEPT_PRIV != "4" ) || !( $ROLE_PRIV == "3" ) )
            {
                $MODULE_PRIV1_ARRAY[$UID] = $PRIV_ID;
            }
        }
        else if ( $MODULE_ID == 2 )
        {
            if ( $DEPT_PRIV == "0" )
            {
                $query_el = "select DEPT_ID from user where UID='".$UID."'";
                $cursor_el = exequery( ( ), $query_el, TRUE );
                if ( $row_el = mysql_fetch_array( $cursor_el ) )
                {
                    $MODULE_DEPT2_ARRAY[$UID] = $row_el['DEPT_ID'];
                }
            }
            else if ( $DEPT_PRIV == "2" )
            {
                if ( $DEPT_ID != "ALL_DEPT" )
                {
                    $MODULE_DEPT2_ARRAY[$UID] = $DEPT_ID;
                }
            }
            else if ( $DEPT_PRIV == "3" || $DEPT_PRIV == "4" )
            {
                $MODULE_USER2_ARRAY[$UID] = $USER_ID;
            }
            $MODULE_ROLE2_ARRAY[$UID] = $ROLE_PRIV;
            if ( !( $DEPT_PRIV != "4" ) || !( $ROLE_PRIV == "3" ) )
            {
                $MODULE_PRIV2_ARRAY[$UID] = $PRIV_ID;
            }
        }
    }
    $DEPT_XML = "";
    $USER_ARRAY = array( );
    $C_DEPT = ( "C_DEPT" );
    if ( is_array( $C_DEPT ) )
    {
        rebuildusercache( );
        $C_DEPT = ( "C_DEPT" );
    }
    $DEPARTMENT_ARRAY = ( "SYS_DEPARTMENT" );
    if ( is_array( $DEPARTMENT_ARRAY ) )
    {
        $DEPT_NO_PREV = "";
        while ( list( $DEPT_ID, $ROW ) = each( &$DEPARTMENT_ARRAY ) )
        {
            $DEPT_NO = $ROW['DEPT_NO'];
            $DEPT_NAME = $ROW['DEPT_NAME'];
            $IS_ORG = $ROW['IS_ORG'];
            $DEPT_XML .= @str_repeat( "</d>", @floor( @strlen( $DEPT_NO_PREV ) / 3 ) - @floor( @strlen( $DEPT_NO ) / 3 ) + 1 )."\n";
            $DEPT_XML .= "<d a=\"".$DEPT_ID."\" b=\"".htmlspecialchars( $DEPT_NAME )."\" c=\"".$IS_ORG."\">\n";
            if ( is_array( $C_DEPT ) )
            {
                $UID_STR = $C_DEPT[$DEPT_ID];
                $UID_ARRAY = array_unique( explode( ",", $UID_STR ) );
                foreach ( $UID_ARRAY as $UID )
                {
                    if ( $UID == "" )
                    {
                        if ( is_array( $USER_ARRAY[$UID] ) )
                        {
                            $ARRAY = ( "C_USER_".floor( $UID / MYOA_C_USER_GROUP_BY ) );
                            if ( is_array( $ARRAY ) )
                            {
                                foreach ( $ARRAY as $KEY => $USER )
                                {
                                    $USER_ARRAY[$KEY] = $USER;
                                }
                            }
                        }
                        $USER = $USER_ARRAY[$UID];
                        if ( !is_array( $USER ) || !( $USER['DEPT_ID'] != 0 ) )
                        {
                            $DEPT_XML .= "<u a=\"".$USER['UID']."\" b=\"".htmlspecialchars( $USER['USER_NAME'] )."\" c=\"".$USER['USER_PRIV']."\" d=\"".( $USER['SEX'] != "1" ? "0" : "1" )."\" e=\"".$USER['ON_STATUS']."\"".( $MODULE_PRIV_ARRAY[$UID] != "" ? " g=\"".$MODULE_PRIV_ARRAY[$UID]."\"" : "" ).( $MODULE_USER_ARRAY[$UID] != "" ? " g1=\"".$MODULE_USER_ARRAY[$UID]."\"" : "" ).( $MODULE_DEPT_ARRAY[$UID] != "" ? " g2=\"".$MODULE_DEPT_ARRAY[$UID]."\"" : "" )." h=\"".htmlspecialchars( $USER['USER_ID'] )."\" i=\"".$DEPT_ID."\"".( $DEPT_ID != $USER['DEPT_ID'] ? " o=\"1\"" : "" ).( $USER['USER_PRIV_OTHER'] != "" ? " c1=\"".$USER['USER_PRIV_OTHER']."\"" : "" ).( $MODULE_DEPT1_ARRAY[$UID] != "" ? " m1=\"".$MODULE_DEPT1_ARRAY[$UID]."\"" : "" ).( $MODULE_USER1_ARRAY[$UID] != "" ? " m2=\"".$MODULE_USER1_ARRAY[$UID]."\"" : "" ).( $MODULE_ROLE1_ARRAY[$UID] != "" ? " m3=\"".$MODULE_ROLE1_ARRAY[$UID]."\"" : "" ).( $MODULE_PRIV1_ARRAY[$UID] != "" ? " m4=\"".$MODULE_PRIV1_ARRAY[$UID]."\"" : "" ).( $MODULE_DEPT2_ARRAY[$UID] != "" ? " m5=\"".$MODULE_DEPT2_ARRAY[$UID]."\"" : "" ).( $MODULE_USER2_ARRAY[$UID] != "" ? " m6=\"".$MODULE_USER2_ARRAY[$UID]."\"" : "" ).( $MODULE_ROLE2_ARRAY[$UID] != "" ? " m7=\"".$MODULE_ROLE2_ARRAY[$UID]."\"" : "" ).( $MODULE_PRIV2_ARRAY[$UID] != "" ? " m8=\"".$MODULE_PRIV2_ARRAY[$UID]."\"" : "" ).( $USER['MOBIL_NO'] != "" ? " k=\"".htmlspecialchars( $USER['MOBIL_NO'] )."\"" : "" ).( $USER['TEL_NO_DEPT'] != "" ? " j=\"".htmlspecialchars( $USER['TEL_NO_DEPT'] )."\"" : "" ).( $USER['OICQ_NO'] != "" ? " m=\"".htmlspecialchars( $USER['OICQ_NO'] )."\"" : "" ).( $USER['EMAIL'] != "" ? " l=\"".htmlspecialchars( $USER['EMAIL'] )."\"" : "" )."/>\n";
                        }
                    }
                }
            }
            $DEPT_NO_PREV = $DEPT_NO;
        }
        if ( $DEPT_XML != "" )
        {
            $DEPT_XML .= str_repeat( "</d>", floor( strlen( $DEPT_NO_PREV ) / 3 ) );
        }
    }
    $XML = "<?xml version=\"1.0\" encoding=\"".MYOA_CHARSET."\" ?>\n";
    $XML .= "<org a=\"0\" b=\"".htmlspecialchars( $UNIT_NAME )."\">\n";
    $XML .= str_replace( "\n", "", $DEPT_XML )."\n";
    $XML .= "</org>";
    if ( !file_exists( MYOA_CACHE_PATH ) && !mkdir( @MYOA_CACHE_PATH, 448 ) )
    {
        return _( "��������Ŀ¼ʧ��" );
    }
    $ORG_FILE = MYOA_CACHE_PATH."/org.zip";
    $zip = new ZipArchive( );
    $res = $zip->open( $ORG_FILE, ZipArchive::CREATE | ZIPARCHIVE::OVERWRITE );
    if ( $res === TRUE )
    {
        $zip->addFromString( "org.xml", $XML );
        $zip->close( );
        return TRUE;
    }
    return _( "����zip�ļ�ʧ��" );
}

function cache_users( )
{
    rebuildusercache( );
    cache_org_xml( );
}

function cache_user_priv( )
{
    rebuildprivcache( );
    cache_org_xml( );
}

function updateUserCache( $UID, $UPDATE_XML = FALSE )
{
    $UID = intval( $UID );
    if ( $UID <= 0 )
    {
    }
    else
    {
        $CACHE_KEY = "C_USER_".floor( $UID / MYOA_C_USER_GROUP_BY );
        $USER_CACHE = ( $CACHE_KEY );
        if ( is_array( $USER_CACHE ) )
        {
            cache_users( );
        }
        else
        {
            $query = "SELECT * from USER where UID='".$UID."' and NOT_LOGIN=0";
            $cursor = exequery( ( ), $query, TRUE );
            if ( $ROW = mysql_fetch_array( $cursor, MYSQL_ASSOC ) )
            {
                $ROW['PRIV_NAME'] = $ROW['USER_PRIV_NAME'];
                $USER_CACHE[$UID] = $ROW;
                ( $CACHE_KEY, $USER_CACHE, 0 );
                if ( $UPDATE_XML )
                {
                    cache_org_xml( );
                }
            }
        }
    }
}

function rebuildUserCache( )
{
    $cache_type_array = array( "C_USER", "C_DEPT", "C_USERID_TO_UID", "C_USER_PRIV" );
    $cache_type_data = array( );
    $query = "SELECT * from USER order by USER_PRIV_NO,USER_NO,USER_NAME";
    $cursor = exequery( ( ), $query, TRUE );
    while ( $ROW = mysql_fetch_array( $cursor, MYSQL_ASSOC ) )
    {
        $UID = $ROW['UID'];
        $DEPT_ID_OTHER = $ROW['DEPT_ID_OTHER'];
        $DEPT_ID = $ROW['DEPT_ID'];
        $USER_ID = $ROW['USER_ID'];
        $USER_PRIV = $ROW['USER_PRIV'];
        $USER_PRIV_OTHER = $ROW['USER_PRIV_OTHER'];
        $ROW['PRIV_NAME'] = $ROW['USER_PRIV_NAME'];
        $cache_type_data['C_USER']["C_USER_".floor( $UID / MYOA_C_USER_GROUP_BY )][$UID] = $ROW;
        $DEPT_ID = td_trim( $DEPT_ID.",".check_id( $DEPT_ID, $DEPT_ID_OTHER, FALSE ) );
        $DEPT_ID_ARR = explode( ",", $DEPT_ID );
        foreach ( $DEPT_ID_ARR as $v )
        {
            if ( $v == "" )
            {
                $cache_type_data['C_DEPT'] .= $v;
            }
        }
        $cache_type_data['C_USERID_TO_UID'][$USER_ID] = $UID;
        $USER_PRIV = $USER_PRIV.",".$USER_PRIV_OTHER;
        $USER_PRIV = td_trim( $USER_PRIV.",".check_id( $USER_PRIV, $USER_PRIV_OTHER, FALSE ) );
        $USER_PRIV_ARR = explode( ",", $USER_PRIV );
        foreach ( $USER_PRIV_ARR as $v )
        {
            if ( $v == "" )
            {
                $cache_type_data['C_USER_PRIV'] .= $v;
            }
        }
    }
    foreach ( $cache_type_data['C_USER'] as $k => $v )
    {
        ( $k, $v, 0 );
    }
    ( "C_DEPT", $cache_type_data['C_DEPT'], 0 );
    ( "C_USERID_TO_UID", $cache_type_data['C_USERID_TO_UID'], 0 );
    ( "C_USER_PRIV", $cache_type_data['C_USER_PRIV'], 0 );
}

function rebuildPrivCache( $rebuildUserCache = FALSE )
{
    $cache_type_data = array( );
    $query = "SELECT * from USER_PRIV order by PRIV_NO";
    $cursor = exequery( ( ), $query, TRUE );
    while ( $ROW = mysql_fetch_array( $cursor, MYSQL_ASSOC ) )
    {
        $cache_type_data[$ROW['USER_PRIV']] = $ROW;
    }
    ( "C_PRIV", $cache_type_data, 0 );
    if ( $rebuildUserCache )
    {
        rebuildusercache( );
    }
}

function GetUserInfoByUID( $uid, $field = "", $return_arr = FALSE )
{
    $uid_str = "";
    if ( is_array( $uid ) )
    {
        foreach ( $uid as $v )
        {
            $uid_str .= $v.",";
        }
    }
    else
    {
        $uid_str = $uid;
    }
    if ( !isset( $uid_str ) || $uid_str == "" )
    {
        return "";
    }
    if ( strpos( $uid_str, "," ) !== FALSE )
    {
        $output = array( );
        $uid_group_id = 0;
        $uid_group_needle_arr = array( );
        $uid_group_data_arr = array( );
        $uid_arr = explode( ",", $uid_str );
        $uid_arr = array_unique( $uid_arr );
        foreach ( $uid_arr as $v )
        {
            if ( $v == "" )
            {
                $uid_group_id = floor( $v / MYOA_C_USER_GROUP_BY );
                if ( in_array( $uid_group_id, $uid_group_needle_arr ) )
                {
                    array_push( &$uid_group_needle_arr, $uid_group_id );
                }
            }
        }
        foreach ( $uid_group_needle_arr as $v )
        {
            $uid_group_data_arr_el = ( "C_USER_".$v );
            if ( is_array( $uid_group_data_arr_el ) )
            {
                rebuildusercache( );
                $uid_group_data_arr_el = ( "C_USER_".$v );
            }
            $uid_group_data_arr[$v] = $uid_group_data_arr_el;
        }
        foreach ( $uid_arr as $v )
        {
            if ( $v == "" )
            {
                if ( $field == "" )
                {
                    $outputs[$v] = $uid_group_data_arr[floor( $v / MYOA_C_USER_GROUP_BY )][$v];
                }
                else
                {
                    if ( strpos( $field, "," ) !== FALSE )
                    {
                        $field = explode( ",", $field );
                    }
                    if ( is_array( $field ) )
                    {
                        foreach ( $field as $k )
                        {
                            if ( $k == "" )
                            {
                                $outputs[$v][$k] = $uid_group_data_arr[floor( $v / MYOA_C_USER_GROUP_BY )][$v][$k];
                            }
                        }
                    }
                    else
                    {
                        if ( $return_arr )
                        {
                            $outputs .= $uid_group_data_arr[floor( $v / MYOA_C_USER_GROUP_BY )][$v][$field].",";
                        }
                        else
                        {
                            $outputs[$v][$field] = $uid_group_data_arr[floor( $v / MYOA_C_USER_GROUP_BY )][$v][$field];
                            return $outputs;
                        }
                    }
                }
            }
        }
        else
        {
            $uid_str = intval( $uid_str );
            $_ceil_users = ( "C_USER_".floor( $uid_str / MYOA_C_USER_GROUP_BY ) );
            if ( is_array( $_ceil_users ) )
            {
                rebuildusercache( );
                $_ceil_users = ( "C_USER_".floor( $uid_str / MYOA_C_USER_GROUP_BY ) );
            }
            if ( $_ceil_users[$uid_str] )
            {
                if ( $field == "" )
                {
                    return $_ceil_users[$uid_str];
                }
                if ( strpos( $field, "," ) !== FALSE )
                {
                    $_field_arr = explode( ",", $field );
                    foreach ( $_field_arr as $k )
                    {
                        if ( $k == "" )
                        {
                            $outputs[$k] = $_ceil_users[$uid_str][$k];
                        }
                    }
                }
            }
        }
    }
    return $outputs;
    if ( $return_arr )
    {
        $outputs[$uid_str] = array( $field => $_ceil_users[$uid_str][$field] );
        return $outputs;
    }
    $outputs = $_ceil_users[$uid_str][$field];
    return $outputs;
    return "";
}

function GetUidByDeptId( $dept = NULL )
{
    if ( isset( $dept ) && $dept == "" )
    {
        return "";
    }
    $_ceil_dept = ( "C_DEPT" );
    if ( is_array( $_ceil_dept ) )
    {
        rebuildusercache( );
        $_ceil_dept = ( "C_DEPT" );
    }
    if ( !isset( $dept ) || $dept == "ALL_DEPT" )
    {
        return $_ceil_dept;
    }
    $dept_id = "";
    if ( is_array( $dept ) )
    {
        foreach ( $dept as $v )
        {
            $dept_id .= $v.",";
        }
    }
    else
    {
        $dept_id = $dept;
    }
    if ( strpos( $dept_id, "," ) !== FALSE )
    {
        $_ceil_dept_arr = array( );
        $dept_id_arr = explode( ",", $dept_id );
        foreach ( $dept_id_arr as $v )
        {
            if ( $v == "" )
            {
                $_ceil_dept_arr[$v] = $_ceil_dept[$v];
            }
        }
        return $_ceil_dept_arr;
    }
    $dept_id = intval( $dept_id );
    if ( $_ceil_dept[$dept_id] )
    {
        return $_ceil_dept[$dept_id];
    }
}

function UserId2Uid( $user_id = NULL, $return_arr = FALSE )
{
    if ( isset( $user_id ) && $user_id == "" )
    {
        return "";
    }
    $_ceil_utu = ( "C_USERID_TO_UID" );
    if ( is_array( $_ceil_utu ) )
    {
        rebuildusercache( );
        $_ceil_utu = ( "C_USERID_TO_UID" );
    }
    if ( !isset( $user_id ) || $user_id == "ALL_USER" )
    {
        return $_ceil_utu;
    }
    $user_id_str = "";
    if ( is_array( $user_id ) )
    {
        foreach ( $user_id as $v )
        {
            $user_id_str .= $v.",";
        }
    }
    else
    {
        $user_id_str = $user_id;
    }
    if ( $user_id_str == "" )
    {
        return "";
    }
    if ( strpos( $user_id_str, "," ) !== FALSE )
    {
        if ( $return_arr )
        {
            $_ceil_utu_arr = array( );
            $user_id_arr = explode( ",", $user_id_str );
            foreach ( $user_id_arr as $v )
            {
                if ( $v == "" )
                {
                    $_ceil_utu_arr[$v] = $_ceil_utu[$v];
                    return $_ceil_utu_arr;
                }
            }
            else
            {
                $_ceil_utu_str = "";
                $user_id_arr = explode( ",", $user_id_str );
                foreach ( $user_id_arr as $v )
                {
                    if ( $v == "" )
                    {
                        $_ceil_utu_str .= $_ceil_utu[$v].",";
                    }
                }
            }
        }
        return $_ceil_utu_str;
    }
    if ( $_ceil_utu[$user_id_str] )
    {
        return $_ceil_utu[$user_id_str];
    }
}

function GetUidByUserPriv( $priv_id = NULL )
{
    if ( isset( $priv_id ) && $priv_id == "" )
    {
        return "";
    }
    $_ceil_priv = ( "C_USER_PRIV" );
    if ( is_array( $_ceil_priv ) )
    {
        rebuildusercache( );
        $_ceil_priv = ( "C_USER_PRIV" );
    }
    if ( !isset( $priv_id ) || $priv_id == "ALL_PRIV" )
    {
        return $_ceil_priv;
    }
    $priv_id_str = "";
    if ( is_array( $priv_id ) )
    {
        foreach ( $priv_id as $v )
        {
            $priv_id_str .= $v.",";
        }
    }
    else
    {
        $priv_id_str = $priv_id;
    }
    if ( strpos( $priv_id_str, "," ) !== FALSE )
    {
        $_ceil_priv_arr = array( );
        $priv_id_arr = explode( ",", $priv_id_str );
        foreach ( $priv_id_arr as $v )
        {
            if ( $v == "" )
            {
                $_ceil_priv_arr[$v] = $_ceil_priv[$v];
            }
        }
        return $_ceil_priv_arr;
    }
    if ( $_ceil_priv[$priv_id_str] )
    {
        return $_ceil_priv[$priv_id_str];
    }
}

function GetPrivInfoByUserPriv( $priv_id = "", $field = "", $return_arr = FALSE )
{
    $outputs = array( );
    $_priv_data = ( "C_PRIV" );
    if ( is_array( $_priv_data ) )
    {
        rebuildprivcache( );
        $_priv_data = ( "C_PRIV" );
    }
    if ( !isset( $priv_id ) || $priv_id == "" )
    {
        return $_priv_data;
    }
    if ( is_numeric( $priv_id ) )
    {
        if ( !isset( $field ) || $field == "" )
        {
            $outputs = $_priv_data[$priv_id];
        }
        if ( $field != "" && strpos( $field, "," ) === FALSE && !is_array( $field ) )
        {
            $outputs = "";
            $outputs = $_priv_data[$priv_id][$field];
        }
        if ( strpos( $field, "," ) !== FALSE )
        {
            $field = explode( ",", $field );
        }
        if ( is_array( $field ) )
        {
            foreach ( $field as $v )
            {
                if ( $v == "" )
                {
                    $outputs[$v] = $_priv_data[$priv_id][$v];
                }
            }
        }
    }
    if ( strpos( $priv_id, "," ) !== FALSE )
    {
        $priv_id = explode( ",", $priv_id );
    }
    if ( is_array( $priv_id ) )
    {
        if ( $field == "" )
        {
            foreach ( $priv_id as $v )
            {
                if ( $v == "" )
                {
                    $outputs[$v] = $_priv_data[$v];
                }
            }
        }
        if ( $field != "" && strpos( $field, "," ) === FALSE && !is_array( $field ) )
        {
            if ( $return_arr )
            {
                $outputs = "";
                foreach ( $priv_id as $v )
                {
                    if ( $v == "" )
                    {
                        $outputs .= $_priv_data[$v][$field].",";
                    }
                }
            }
            else
            {
                $field .= ",";
            }
        }
        if ( strpos( $field, "," ) !== FALSE )
        {
            $field = explode( ",", $field );
        }
        if ( is_array( $field ) )
        {
            foreach ( $priv_id as $v )
            {
                if ( $v == "" )
                {
                    foreach ( $field as $vf )
                    {
                        if ( $vf == "" )
                        {
                            $outputs[$v][$vf] = $_priv_data[$v][$vf];
                        }
                    }
                }
            }
        }
    }
    return $outputs;
}

function cache_workflow_all( )
{
    include_once( "inc/utility_flow.php" );
    include_once( "inc/workflow/inc/workflow.cache.php" );
    cache_form( );
    cache_flow_list( );
    cache_flow_type( );
    $query = "select flow_id from flow_type";
    $cursor = exequery( ( ), $query, TRUE );
    while ( $row = mysql_fetch_array( $cursor ) )
    {
        cache_flow_prcs( $row['flow_id'] );
    }
    cache_flow_category( );
    $query = "select SORT_ID from flow_sort";
    $cursor = exequery( ( ), $query, TRUE );
    while ( $row = mysql_fetch_array( $cursor ) )
    {
        cache_flow_type_list( $row['SORT_ID'] );
    }
}

function rebuildMobileCache( )
{
    $avail_time = time( ) - 2592000;
    $C_MOBILE_DEVICES = array( );
    $query = "SELECT * from user_mobile_devices where last_active > '".$avail_time."'";
    $cursor = exequery( ( ), $query, TRUE );
    while ( $ROW = mysql_fetch_array( $cursor ) )
    {
        $C_MOBILE_DEVICES[$ROW['uid']] = array( "device_token" => $ROW['device_token'], "client_ver" => $ROW['client_ver'] );
    }
    ( "C_MOBILE_DEVICES", $C_MOBILE_DEVICES, 2592000 );
}

include_once( "inc/td_config.php" );
?>
