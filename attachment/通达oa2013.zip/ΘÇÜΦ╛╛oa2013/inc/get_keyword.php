<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
include_once( "inc/auth.inc.php" );
include_once( "inc/utility_email.php" );
include_once( "inc/utility_cache.php" );
ob_end_clean( );
if ( extension_loaded( "scws" ) )
{
    dl( "scws.".PHP_SHLIB_SUFFIX );
    $THE_PATH2 = realpath( MYOA_ROOT_PATH."../" )."\\bin\\";
}
$module = "scws";
$functions = get_extension_funcs( $module );
$function = $module."_version";
if ( extension_loaded( $module ) )
{
    $str = $function( $module );
}
else
{
    $str = "Module ".$module." is not compiled into PHP";
}
$sh = scws_open( );
scws_set_charset( $sh, MYOA_IS_UN ? "utf8" : "gbk" );
scws_set_ignore( $sh, TRUE );
$sh_r = "n,v,nr";
if ( $MODULE_ID == "NEWS" )
{
    if ( $ID != "" )
    {
        $query = "SELECT CONTENT from NEWS where NEWS_ID='".$ID."'";
        $cursor = exequery( ( ), $query );
        if ( $ROW = mysql_fetch_array( $cursor ) )
        {
            $CONTENT = $ROW['CONTENT'];
            if ( $CONTENT != "" )
            {
                scws_send_text( $sh, $CONTENT );
                $top = scws_get_tops( $sh, 5, $sh_r );
                if ( 0 < sizeof( $top ) )
                {
                    $I = 0;
                    for ( ; $I < sizeof( $top ); ++$I )
                    {
                        $Keystring .= $top[$I]['word'].",";
                    }
                    $Keystring = td_trim( $Keystring );
                    $query = "update NEWS set KEYWORD='".$Keystring."' where NEWS_ID='{$ID}'";
                    exequery( ( ), $query );
                    $SHOW_KEYWORD = _( "���Ĺؼ��ʣ�" );
                    $KEYWORD_ARRAY = explode( ",", $Keystring );
                    foreach ( $KEYWORD_ARRAY as $KID )
                    {
                        if ( $KID != "" )
                        {
                            $SHOW_KEYWORD .= "<a href=javascript:open_news('".$KID."',2)>".$KID."</a> ";
                        }
                    }
                    echo $SHOW_KEYWORD;
                }
            }
        }
    }
    else if ( $CONTENT != "" )
    {
        scws_send_text( $sh, $CONTENT );
        $top = scws_get_tops( $sh, 5, $sh_r );
        if ( 0 < sizeof( $top ) )
        {
            $I = 0;
            for ( ; $I < sizeof( $top ); ++$I )
            {
                $Keystring .= $top[$I]['word'].",";
            }
            echo $Keystring;
        }
    }
}
if ( $MODULE_ID == "NOTIFY" )
{
    if ( $ID != "" )
    {
        $query = "SELECT CONTENT from NOTIFY where NOTIFY_ID='".$ID."'";
        $cursor = exequery( ( ), $query );
        if ( $ROW = mysql_fetch_array( $cursor ) )
        {
            $CONTENT = $ROW['CONTENT'];
            if ( $CONTENT != "" )
            {
                scws_send_text( $sh, $CONTENT );
                $top = scws_get_tops( $sh, 5, $sh_r );
                if ( 0 < sizeof( $top ) )
                {
                    $I = 0;
                    for ( ; $I < sizeof( $top ); ++$I )
                    {
                        $Keystring .= $top[$I]['word'].",";
                    }
                    $Keystring = td_trim( $Keystring );
                    $query = "update NOTIFY set KEYWORD='".$Keystring."' where NOTIFY_ID='{$ID}'";
                    exequery( ( ), $query );
                    $SHOW_KEYWORD = _( "���Ĺؼ��ʣ�" );
                    $KEYWORD_ARRAY = explode( ",", $Keystring );
                    foreach ( $KEYWORD_ARRAY as $KID )
                    {
                        if ( $KID != "" )
                        {
                            $SHOW_KEYWORD .= "<a href=javascript:open_notify('".$KID."',1)>".$KID."</a> ";
                        }
                    }
                    echo $SHOW_KEYWORD;
                }
            }
        }
    }
    else if ( $CONTENT != "" )
    {
        scws_send_text( $sh, $CONTENT );
        $top = scws_get_tops( $sh, 5, $sh_r );
        if ( 0 < sizeof( $top ) )
        {
            $I = 0;
            for ( ; $I < sizeof( $top ); ++$I )
            {
                $Keystring .= $top[$I]['word'].",";
            }
            echo $Keystring;
        }
    }
}
if ( $MODULE_ID == "FILE_FOLDER" )
{
    if ( $ID != "" )
    {
        $query = "SELECT CONTENT from FILE_CONTENT where CONTENT_ID='".$ID."'";
        $cursor = exequery( ( ), $query );
        if ( $ROW = mysql_fetch_array( $cursor ) )
        {
            $CONTENT = $ROW['CONTENT'];
            if ( $CONTENT != "" )
            {
                scws_send_text( $sh, $CONTENT );
                $top = scws_get_tops( $sh, 5, $sh_r );
                if ( 0 < sizeof( $top ) )
                {
                    $I = 0;
                    for ( ; $I < sizeof( $top ); ++$I )
                    {
                        $Keystring .= $top[$I]['word'].",";
                    }
                    $Keystring = td_trim( $Keystring );
                    $query = "update FILE_CONTENT set KEYWORD='".$Keystring."' where CONTENT_ID='{$ID}'";
                    exequery( ( ), $query );
                    $SHOW_KEYWORD = _( "���Ĺؼ��ʣ�" );
                    $KEYWORD_ARRAY = explode( ",", $Keystring );
                    foreach ( $KEYWORD_ARRAY as $KID )
                    {
                        if ( $KID != "" )
                        {
                            $SHOW_KEYWORD .= "<a href=javascript:open_file_folder('".$KID."',3)>".$KID."</a> ";
                        }
                    }
                    echo $SHOW_KEYWORD;
                }
            }
        }
    }
    else if ( $CONTENT != "" )
    {
        scws_send_text( $sh, $CONTENT );
        $top = scws_get_tops( $sh, 5, "n,v" );
        if ( 0 < sizeof( $top ) )
        {
            $I = 0;
            for ( ; $I < sizeof( $top ); ++$I )
            {
                $Keystring .= $top[$I]['word'].",";
            }
            echo $Keystring;
        }
    }
}
if ( $MODULE_ID == "EMAIL" )
{
    $uid = $_SESSION['LOGIN_UID'];
    $eid = $ID;
    if ( $ID != "" && $IS_WEBMAIL != 1 )
    {
        $query = " SELECT EMAIL_BODY.CONTENT,EMAIL_BODY.BODY_ID from EMAIL,EMAIL_BODY where  EMAIL_ID='".$ID."' and  EMAIL.BODY_ID=EMAIL_BODY.BODY_ID ";
        $cursor = exequery( ( ), $query );
        if ( $ROW = mysql_fetch_array( $cursor ) )
        {
            $CONTENT = $ROW['CONTENT'];
            $CONTENT = stripslashes( $CONTENT );
            $BODY_ID = $ROW['BODY_ID'];
            $query1 = "select EMAIL_ID from EMAIL where BODY_ID='".$BODY_ID."'";
            $cursor1 = exequery( ( ), $query1 );
            while ( $ROW1 = mysql_fetch_array( $cursor1 ) )
            {
                $EMAIL_ID .= $ROW1['EMAIL_ID'].",";
            }
            if ( $CONTENT != "" )
            {
                scws_send_text( $sh, $CONTENT );
                $top = scws_get_tops( $sh, 50, $sh_r );
                if ( 0 < sizeof( $top ) )
                {
                    $I = 0;
                    for ( ; $I < sizeof( $top ); ++$I )
                    {
                        $Keystring .= $top[$I]['word'].",";
                    }
                    $key_array = get_keywords( $Keystring );
                    $key_word_array = process( $key_array, $Keystring );
                    $Keystring = td_trim( $key_word_array[0] );
                    $tag_id = td_trim( $key_word_array[1] );
                    $query = "update EMAIL_BODY set KEYWORD='".$Keystring."' where BODY_ID='{$BODY_ID}'";
                    exequery( ( ), $query );
                    $KEYWORD_ARRAY = explode( ",", $Keystring );
                    $EMAIL_ARRAY = explode( ",", td_trim( $EMAIL_ID ) );
                    $query = "delete from email_keyword where uid = '".$_SESSION['LOGIN_UID'].( "' and EMAIL_ID = '".$ID."'" );
                    $cursor = exequery( ( ), $query );
                    foreach ( $KEYWORD_ARRAY as $KID )
                    {
                        if ( $KID != "" )
                        {
                            $I = 0;
                            for ( ; $I < sizeof( $EMAIL_ARRAY ); ++$I )
                            {
                                if ( $EMAIL_ARRAY[$I] == "" )
                                {
                                    $query2 = "select TO_ID from EMAIL where EMAIL_ID='".$EMAIL_ARRAY[$I]."'";
                                    $cursor2 = exequery( ( ), $query2 );
                                    $ROW2 = mysql_fetch_array( $cursor2 );
                                    $TO_IDS = $ROW2['TO_ID'];
                                    $TO_UID = userid2uid( $TO_IDS );
                                    $query3 = "select count(*) from `email_keyword` where UID='".$TO_UID."' and EMAIL_ID='{$EMAIL_ARRAY[$I]}' and KEYWORD='{$KID}'";
                                    $cursor3 = exequery( ( ), $query3 );
                                    $ROW3 = mysql_fetch_array( $cursor3 );
                                    $count = $ROW3[0];
                                    if ( !( $count == 0 ) || !( $TO_UID != "" ) )
                                    {
                                        $k_query = "INSERT INTO `email_keyword` (`UID`, `EMAIL_ID`, `KEYWORD`) VALUES (".$TO_UID.", {$EMAIL_ARRAY[$I]}, '{$KID}');";
                                        $k_cursor = exequery( ( ), $k_query );
                                    }
                                }
                            }
                            $SHOW_KEYWORD .= "<a href=javascript:open_email('".$KID."',4)><font color='blue'>".$KID."</font></a> ";
                        }
                    }
                    echo $SHOW_KEYWORD;
                }
            }
        }
    }
    if ( $ID != "" && $IS_WEBMAIL == 1 )
    {
        $query = " SELECT * from EMAIL_BODY where  BODY_ID='".$BODY_ID."' ";
        $cursor = exequery( ( ), $query );
        if ( $ROW = mysql_fetch_array( $cursor ) )
        {
            $CONTENT = $ROW['CONTENT'];
            $query1 = "select EMAIL_ID from EMAIL where BODY_ID='".$BODY_ID."'";
            $cursor1 = exequery( ( ), $query1 );
            while ( $ROW1 = mysql_fetch_array( $cursor1 ) )
            {
                $EMAIL_ID .= $ROW1['EMAIL_ID'].",";
            }
            $CONTENT = stripslashes( $CONTENT );
            $CONTENT = mysql_escape_string( strip_tags( $CONTENT ) );
            if ( $CONTENT != "" )
            {
                scws_send_text( $sh, $CONTENT );
                $top = scws_get_tops( $sh, 50, $sh_r );
                if ( 0 < sizeof( $top ) )
                {
                    $I = 0;
                    for ( ; $I < sizeof( $top ); ++$I )
                    {
                        $Keystring .= $top[$I]['word'].",";
                    }
                    $key_array = get_keywords( $Keystring );
                    $key_word_array = process( $key_array, $Keystring );
                    $Keystring = td_trim( $key_word_array[0] );
                    $query = "update EMAIL_BODY set KEYWORD='".$Keystring."' where BODY_ID='{$BODY_ID}'";
                    exequery( ( ), $query );
                    $KEYWORD_ARRAY = explode( ",", $Keystring );
                    $EMAIL_ARRAY = explode( ",", td_trim( $EMAIL_ID ) );
                    $query = "delete from email_keyword where uid = '".$_SESSION['LOGIN_UID'].( "' and EMAIL_ID = '".$ID."'" );
                    $cursor = exequery( ( ), $query );
                    foreach ( $KEYWORD_ARRAY as $KID )
                    {
                        if ( $KID != "" )
                        {
                            $I = 0;
                            for ( ; $I < sizeof( $EMAIL_ARRAY ); ++$I )
                            {
                                if ( $EMAIL_ARRAY[$I] == "" )
                                {
                                    $query2 = "select TO_ID from EMAIL where EMAIL_ID='".$EMAIL_ARRAY[$I]."'";
                                    $cursor2 = exequery( ( ), $query2 );
                                    $ROW2 = mysql_fetch_array( $cursor2 );
                                    $TO_IDS = $ROW2['TO_ID'];
                                    $TO_UID = userid2uid( $TO_IDS );
                                    $query3 = "select count(*) from `email_keyword` where UID='".$TO_UID."' and EMAIL_ID='{$EMAIL_ARRAY[$I]}' and KEYWORD='{$KID}'";
                                    $cursor3 = exequery( ( ), $query3 );
                                    $ROW3 = mysql_fetch_array( $cursor3 );
                                    $count = $ROW3[0];
                                    if ( !( $count == 0 ) || !( $TO_UID != "" ) )
                                    {
                                        $k_query = "INSERT INTO `email_keyword` (`UID`, `EMAIL_ID`, `KEYWORD`) VALUES (".$TO_UID.", {$EMAIL_ARRAY[$I]}, '{$KID}');";
                                        $k_cursor = exequery( ( ), $k_query );
                                    }
                                }
                            }
                            $SHOW_KEYWORD .= "<a href=javascript:open_email_web('".$KID."',4,1)><font color='blue'>".$KID."</font></a> ";
                        }
                    }
                    echo $SHOW_KEYWORD;
                }
            }
        }
    }
}
if ( $MODULE_ID == "ESB_INFO" )
{
    if ( $ID != "" )
    {
        $query = "SELECT INFO_CONTENT from ESB_INFO where INFO_ID='".$ID."'";
        $cursor = exequery( ( ), $query );
        if ( $ROW = mysql_fetch_array( $cursor ) )
        {
            $CONTENT = $ROW['INFO_CONTENT'];
            if ( $CONTENT != "" )
            {
                scws_send_text( $sh, $CONTENT );
                $top = scws_get_tops( $sh, 5, "n,v,nr" );
                if ( 0 < sizeof( $top ) )
                {
                    $I = 0;
                    for ( ; $I < sizeof( $top ); ++$I )
                    {
                        $Keystring .= $top[$I]['word'].",";
                    }
                    $Keystring = td_trim( $Keystring );
                    $query = "update ESB_INFO set KEYWORD='".$Keystring."' where INFO_ID='{$ID}'";
                    exequery( ( ), $query );
                    $SHOW_KEYWORD = "���Ĺؼ��ʣ�";
                    $KEYWORD_ARRAY = explode( ",", $Keystring );
                    foreach ( $KEYWORD_ARRAY as $KID )
                    {
                        if ( $KID != "" )
                        {
                            $SHOW_KEYWORD .= "<a href=javascript:open_info('".$KID.")>".$KID."</a> ";
                        }
                    }
                    echo $SHOW_KEYWORD;
                }
            }
        }
    }
    else
    {
        if ( $CONTENT != "" )
        {
            scws_send_text( $sh, $CONTENT );
            $top = scws_get_tops( $sh, 5, "n,v" );
            if ( 0 < sizeof( $top ) )
            {
                $I = 0;
                for ( ; $I < sizeof( $top ); ++$I )
                {
                    $Keystring .= $top[$I]['word'].",";
                }
                echo $Keystring;
            }
        }
    }
}
?>
