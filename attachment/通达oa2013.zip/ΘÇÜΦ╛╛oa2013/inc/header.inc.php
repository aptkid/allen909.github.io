<?php
/*********************/
/***Dezend for PHP5***/
/*** love-bady.com ***/
/*���ֹ��� QQ:9886165*/
/*********************/
include_once( "inc/td_config.php" );
include_once( "inc/common.inc.php" );
$HTML_RENDER_MODE = isset( $HTML_RENDER_MODE ) ? $HTML_RENDER_MODE : "webkit";
@header( "X-UA-Compatible: IE=10" );
@header( @"renderer: ".$HTML_RENDER_MODE );
echo "<!DOCTYPE html>\r\n<!--[if IE 6 ]> <html class=\"ie6 lte_ie6 lte_ie7 lte_ie8 lte_ie9\"> <![endif]--> \r\n<!--[if lte IE 6 ]> <html class=\"lte_ie6 lte_ie7 lte_ie8 lte_ie9\"> <![endif]--> \r\n<!--[if lte IE 7 ]> <html class=\"lte_ie7 lte_ie8 lte_ie9\"> <![endif]--> \r\n<!--[if lte IE 8 ]> <html class=\"lte_ie8 lte_ie9\"> <![endif]--> \r\n<!--[if lte IE 9 ]> <html class=\"lte_ie9\"> <![endif]--> \r\n<!--[if (gte IE 10)|!(IE)]><!--><html><!--<![endif]-->\r\n <head>\r\n    <title>";
echo htmlspecialchars( $HTML_PAGE_TITLE );
echo "</title>\r\n    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=";
echo !isset( $HTML_PAGE_CHARSET ) ? MYOA_CHARSET : htmlspecialchars( $HTML_PAGE_CHARSET );
echo "\" />\r\n    <meta name=\"renderer\" content=\"";
echo $HTML_RENDER_MODE;
echo "\">\r\n    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=10,chrome=1\" />\r\n";
if ( !isset( $HTML_PAGE_BASE_STYLE ) || $HTML_PAGE_BASE_STYLE )
{
    echo "    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
    echo MYOA_STATIC_SERVER;
    echo "/static/theme/";
    echo $_SESSION['LOGIN_THEME'] == "" ? "1" : htmlspecialchars( $_SESSION['LOGIN_THEME'] );
    echo "/style.css\" />\r\n    <script type=\"text/javascript\" src=\"";
    echo MYOA_JS_SERVER;
    echo "/static/js/ccorrect_btn.js\"></script>\r\n";
}
echo "<script type=\"text/javascript\" >\r\n   var MYOA_JS_SERVER = \"";
echo MYOA_JS_SERVER;
echo "\";\r\n   var MYOA_STATIC_SERVER = \"";
echo MYOA_STATIC_SERVER;
echo "\";\r\n</script>\r\n</head>\r\n";
?>
